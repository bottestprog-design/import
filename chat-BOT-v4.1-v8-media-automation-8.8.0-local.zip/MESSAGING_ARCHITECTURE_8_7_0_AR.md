# إعادة تصميم نظام الرسائل — Chat BOT 8.7.0

## الحدود المعمارية

- `src/messaging/dictionary.js`: تطبيع عربي، قاموس مرادفات، مطابقة عبارات، مطابقة تقريبية، والتحقق من مدخلات القاموس.
- `src/messaging/intent-resolver.js`: اقتراح النية ودرجة الثقة، واكتشاف الغموض، وإرجاع قائمة خيارات لا تنفذ أي إجراء بنفسها.
- `src/messaging/conversation-manager.js`: حفظ حالة الاختيار والمهلة الزمنية في بيانات الجلسة، واستهلاك الاختيار مرة واحدة.
- `src/messaging/command-registry.js`: سجل قدرات allowlist مع تحقق المدخلات والصلاحيات وعقد نتيجة موحّد.
- `src/local-command-engine.js`: نقطة الدمج مع أوامر Chat BOT الموجودة، ويستخدم resolver قبل تشغيل طلب قصير ملتبس.
- `src/store.js`: تخزين JSON الحالي متوافق مع الإصدارات السابقة؛ تمت إضافة `commandDictionary` و`messagingConversation` و`hiddenFromSend` دون نقل بيانات الجلسات أو حذفها.
- `server.js`: واجهات إدارة القاموس واختبار تفسير العبارة، وإخفاء جهة اتصال من شاشة الإرسال فقط.

## دورة الرسالة

1. تطبيع النص دون تغيير النص الأصلي الذي قد يُرسل لاحقًا.
2. فحص ما إذا كانت المحادثة تنتظر اختيارًا سابقًا.
3. البحث في المرادفات والعبارات المسجلة، مع مراعاة الأخطاء الإملائية البسيطة.
4. إذا تعددت التفسيرات المتقاربة، تُحفظ قائمة الخيارات ويُطلب من المستخدم الاختيار. لا يُنفّذ أي إجراء قبل الاختيار.
5. بعد الاختيار، تُفتح خطوة الحوار المناسبة لجمع الحقول الناقصة؛ الإرسال الفعلي يظل عبر خدمة الإرسال القائمة.
6. تُمسح حالة الاختيار بعد الاستهلاك أو الإلغاء، وتنتهي صلاحيتها بعد 15 دقيقة.

## مثال الغموض

`بعت` أو `وصل` يعرض:
1. إرسال رسالة جديدة
2. جدولة رسالة لوقت لاحق
3. تحويل رسالة موجودة

اختيار 1 يبدأ مسار الإرسال، واختيار 2 يبدأ مسار الجدولة. اختيار التحويل لا يرسل شيئًا تلقائيًا؛ يطلب تحديد المصدر والوجهة لأنهما غير متوفرين في العبارة القصيرة.

## إدارة القاموس

- `GET /api/messaging/dictionary`: عرض العبارات المخصصة وأسماء الأوامر المسجلة.
- `POST /api/messaging/dictionary`: إضافة أو تحديث إدخال `{ intent, phrases, weight, enabled }`.
- `DELETE /api/messaging/dictionary/:id`: حذف الإدخال المخصص.
- `POST /api/messaging/dictionary/test`: اختبار تفسير نص قبل اعتماده.

معرّف النية من حروف إنجليزية صغيرة وأرقام وشرطة سفلية، والعبارات بحد أقصى 120 حرفًا. الإدخالات لا تُنفّذ ككود ولا يمكنها تجاوز فحوص الصلاحيات.

## مخطط قاعدة بيانات مستقبلي

التخزين الفعلي في 8.7.0 ما زال JSON per-session حفاظًا على التوافق وعدم إتلاف بيانات المستخدم. عند الانتقال إلى SQLite، تكون الجداول المقترحة:

- `sessions(id, name, status, created_at)`
- `chats(id, session_id, platform_chat_id, type, title)` مع قيد `UNIQUE(session_id, platform_chat_id)`
- `contacts(id, session_id, whatsapp_jid, lid_id, phone_e164, whatsapp_name, local_name, whatsapp_photo_key, local_photo_path)`
- `chat_preferences(chat_id, mode, hidden_from_send, automation_enabled)`
- `contact_response_rules(id, chat_id, priority, trigger_type, trigger_value, response, enabled)`
- `dictionary_phrases(id, phrase, normalized_phrase, intent_key, match_type, weight, enabled)`
- `conversations(id, chat_id, state, context_json, expires_at)`
- `command_runs(id, intent_key, parameters_json, status, error_code, created_at)`
- `outbox_messages(id, session_id, chat_id, body, scheduled_at, status, idempotency_key, attempts, last_error)`
- `audit_logs(id, actor_id, action, entity_id, created_at)`

تستخدم معاملات وقيد idempotency للرسائل؛ لا تُخزن أرقام الهاتف داخل معرّفات LID بالتخمين. يجب فصل الاسم والصورة المحليين عن ملف WhatsApp.

## إخفاء جهات الإرسال

`hiddenFromSend` خاص بقائمة اختيار أهداف الإرسال فقط؛ لا يحذف الشخص، ولا يوقف الرد التلقائي، ولا يلغي المواعيد الموجودة. يمكن إظهاره مجددًا من بطاقة الشخص.

## حدود الإصدار

سجل الأوامر والخدمات الحالية لم يُستبدل دفعة واحدة؛ هذا إصدار تأسيسي يضيف حدودًا معيارية ومحرك قاموس وفضّ غموض مع الحفاظ على أوامر 8.6.0. تحويل جميع قدرات الموقع إلى سجلات تنفيذ موحدة بالكامل يحتاج مراحل إضافية واختبارات تكامل لكل قدرة، ولا يُدّعى اكتماله بمجرد وجود سجل الأوامر.
