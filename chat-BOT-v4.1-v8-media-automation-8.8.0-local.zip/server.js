"use strict";

const fs = require('node:fs');
const path = require('node:path');
const express = require('express');
const multer = require('multer');

const store = require('./src/store');
const media = require('./src/media');
const phones = require('./src/phones');
const groups = require('./src/groups');
const backgrounds = require('./src/backgrounds');
const { WhatsAppManager, safeError, groupFromMessage, chatIdFromMessage } = require('./src/whatsapp');
const { DeliveryService } = require('./src/delivery');
const { InteractionEngine } = require('./src/interaction');
const { ReliableScheduler, nextRun, due, nextRunForItem, zonedDateToUtc } = require('./src/scheduler');
const { OwnerAssistant } = require('./src/owner-assistant');
const { validateEntry, matchDictionary } = require('./src/messaging/dictionary');
const { CommandRegistry } = require('./src/messaging/command-registry');
const { MediaAutomationService } = require('./src/media-automation');
const { logFactory, replyError, randomId } = require('./src/serverlib');

const HOST = process.env.HOST || '127.0.0.1';
const PORT = store.toInt(process.env.PORT, 7005, 1, 65535);
const TEMP = path.join(store.DATA_DIR, '_temp');
fs.mkdirSync(TEMP, { recursive: true });

const log = logFactory(store);
const whatsapp = new WhatsAppManager({ store, log });
const delivery = new DeliveryService({ store, whatsapp, log });
const interaction = new InteractionEngine({ store, whatsapp, log });
const scheduler = new ReliableScheduler({ store, run: id => delivery.scheduledRun(id), runTask: (id, task) => delivery.scheduledTaskRun(id, task), log });
const ownerAssistant = new OwnerAssistant({ store, whatsapp, delivery, interaction, groups, phones, saveGroup, normalizeAutomationPayload, refreshRecipientProfile, log });
const mediaAutomation = new MediaAutomationService({ store, whatsapp, ownerAssistant, log });

function sid(req) {
  return store.safeSessionId(req.body?.sessionId || req.query?.sessionId || store.activeSessionId());
}
function boolValue(value, fallback = false) {
  if (value === undefined || value === null) return fallback;
  if (typeof value === 'boolean') return value;
  const x = String(value).trim().toLowerCase();
  if (['true', '1', 'yes', 'on', 'نعم', 'تشغيل', 'مفعّل'].includes(x)) return true;
  if (['false', '0', 'no', 'off', 'لا', 'إيقاف', 'متوقف'].includes(x)) return false;
  return fallback;
}
function uniqueStrings(values) {
  return [...new Set((Array.isArray(values) ? values : []).map(v => String(v || '').trim()).filter(Boolean))];
}
function validTargetKeys(session, keys) {
  const allowed = new Set([
    ...session.recipients.map(x => `r:${x.id}`),
    ...session.groups.map(x => `g:${x.id}`),
  ]);
  return uniqueStrings(keys).filter(k => allowed.has(k));
}
function normalizeRuleChatIds(chatIds) {
  return uniqueStrings(chatIds).map(v => v.toLowerCase());
}
function validIsoDate(value) {
  const x = String(value || '').trim(), m = x.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return false;
  const y = Number(m[1]), mo = Number(m[2]), d = Number(m[3]);
  if (mo < 1 || mo > 12 || d < 1 || d > 31) return false;
  const dt = new Date(Date.UTC(y, mo - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === mo - 1 && dt.getUTCDate() === d;
}
function saveGroup(id, info) {
  const s = store.loadSession(id);
  const n = store.normalizeGroup(info);
  n.gid = groups.normalizeGid(n.gid);
  if (!groups.isGroupId(n.gid)) throw new Error('GID المجموعة غير صالح.');
  const old = s.groups.find(x => x.gid === n.gid);
  if (old) {
    const enabled = old.enabled;
    const discoveredAt = old.discoveredAt;
    const before = JSON.stringify({ name: old.name, gid: old.gid, inviteCode: old.inviteCode, description: old.description, owner: old.owner, participantsCount: old.participantsCount, participants: old.participants, admins: old.admins, enabled });
    Object.assign(old, n, { enabled, discoveredAt, updatedAt: old.updatedAt || new Date().toISOString() });
    const after = JSON.stringify({ name: old.name, gid: old.gid, inviteCode: old.inviteCode, description: old.description, owner: old.owner, participantsCount: old.participantsCount, participants: old.participants, admins: old.admins, enabled });
    if (before !== after) { old.updatedAt = new Date().toISOString(); store.saveSession(s); log(id, 'INFO', `تم تحديث بيانات المجموعة: ${old.name || old.gid}`); }
    return old;
  }
  s.groups.push(n);
  s.setupComplete = true;
  store.saveSession(s);
  log(id, 'INFO', `تم ربط مجموعة جديدة: ${n.name || n.gid}`);
  return n;
}
function removeTargetFromSchedule(s, key) {
  s.settings.scheduleTargetKeys = (s.settings.scheduleTargetKeys || []).filter(x => x !== key);
}
function snapshot(id) {
  const s = store.loadSession(id);
  const scan = media.scan(store.getPaths(id).media, s.settings.maxImageSizeMB);
  return {
    version: store.APP_VERSION,
    session: { id: s.id, name: s.name, setupComplete: s.setupComplete },
    ownerAssistant: { ...s.ownerAssistant, messages: (s.ownerAssistant?.messages || []).slice(-100), issues: (s.ownerAssistant?.issues || []).slice(-80), activity: (s.ownerAssistant?.activity || []).slice(-150) },
    mediaAutomation: mediaAutomation.status(id),
    media: scan.files.map(x => ({ ...x, url: `/media/${encodeURIComponent(x.filename)}?sessionId=${encodeURIComponent(id)}` })),
    activeSessionId: store.activeSessionId(),
    sessions: store.listSessionIds().map(x => {
      const ss = store.loadSession(x);
      const runtime = whatsapp.listRuntime(x);
      const summary = media.quickSummary(store.getPaths(x).media);
      return { id: ss.id, name: ss.name, status: runtime.status, ready: runtime.ready, recipients: ss.recipients.filter(y => y.enabled !== false).length, groups: ss.groups.filter(y => y.enabled !== false).length, images: summary.images, files: summary.files };
    }),
    recipients: s.recipients.map(recipient => {
      const displayName = String(recipient.localName || recipient.whatsappName || recipient.name || '').trim() || recipient.phone || 'بدون اسم';
      const avatarUrl = recipient.localAvatarFile
        ? `/api/recipient/${encodeURIComponent(recipient.id)}/avatar?sessionId=${encodeURIComponent(id)}&v=${encodeURIComponent(s.updatedAt)}`
        : recipient.whatsappAvatarFile
          ? `/api/recipient/${encodeURIComponent(recipient.id)}/whatsapp-avatar?sessionId=${encodeURIComponent(id)}&v=${encodeURIComponent(recipient.profileCheckedAt || s.updatedAt)}`
          : String(recipient.whatsappAvatarUrl || '');
      return { ...recipient, name: displayName, displayName, avatarUrl, localName: recipient.localName || '' };
    }),
    groups: s.groups,
    images: scan.images.map(x => ({ ...x, url: `/media/${encodeURIComponent(x.filename)}?sessionId=${encodeURIComponent(id)}` })),
    invalidImages: scan.invalid,
    duplicates: scan.duplicates,
    currentImage: delivery.currentImage(id),
    cycle: s.cycle,
    settings: s.settings,
    interaction: s.interaction,
    whatsapp: whatsapp.listRuntime(id),
    schedule: { ...due(new Date(), s), nextRun: nextRun(s) },
    automation: { enabled: s.automation.enabled !== false, tasks: (s.automation.tasks || []).map(t => ({ ...t, nextRun: nextRunForItem({ ...t, timezone: s.settings.timezone }) })), recent: s.automation.recent || [] },
    scheduler: scheduler.status(id),
    background: {
      mode: s.settings.backgroundMode,
      imageName: s.settings.backgroundImage,
      imageUrl: s.settings.backgroundImage ? `/background/${encodeURIComponent(s.settings.backgroundImage)}?sessionId=${encodeURIComponent(id)}&v=${encodeURIComponent(s.updatedAt)}` : null,
      opacity: s.settings.backgroundOpacity,
      settings: s.settings.backgroundSettings,
    },
    stats: s.stats,
    lastRun: s.lastRun,
    logs: s.logs.slice(-60).reverse(),
  };
}

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '6mb' }));
app.use(express.urlencoded({ extended: true, limit: '6mb' }));
app.use(express.static(path.join(store.ROOT, 'public')));

// Asset URLs can be stale after deleting a session; return 404 instead of recreating its data folder.
app.use(['/media', '/background'], (req, res, next) => {
  const requested = req.query?.sessionId;
  const id = store.safeSessionId(requested || store.activeSessionId());
  if (!store.listSessionIds().includes(id)) return res.status(404).end();
  next();
});

// Do not silently recreate a deleted session when a stale tab sends its old sessionId.
app.use('/api', (req, res, next) => {
  const pathname = req.path || '';
  if ((req.method === 'GET' && ['/health', '/countries'].includes(pathname)) || (req.method === 'POST' && pathname === '/sessions')) return next();
  const explicit = req.body?.sessionId || req.query?.sessionId;
  const contextId = explicit ? store.safeSessionId(explicit) : store.activeSessionId();
  const match = pathname === '/sessions/switch' ? null : pathname.match(/^\/sessions\/([^/]+)$/);
  const routeId = match ? decodeURIComponent(match[1]) : '';
  const ids = store.listSessionIds();
  if (!ids.includes(contextId) || (routeId && !ids.includes(store.safeSessionId(routeId)))) {
    return res.status(404).json({ ok: false, error: 'الجلسة المحددة غير موجودة أو حُذفت. حدّث القائمة واختر جلسة صالحة؛ لن يعاد إنشاء الجلسة المحذوفة تلقائيًا.' });
  }
  next();
});

// Convert API failures into a persistent, actionable issue in the current session's private assistant center.
app.use('/api', (req, res, next) => {
  const apiRoute = `/api${req.path}`;
  const sendJson = res.json.bind(res);
  res.json = body => {
    const failed = res.statusCode >= 400 || body?.ok === false;
    if (failed && !req.path.startsWith('/assistant/')) {
      const explicit = req.body?.sessionId || req.query?.sessionId;
      const id = store.safeSessionId(explicit || store.activeSessionId());
      if (store.listSessionIds().includes(id)) {
        const detail = body?.error || body?.message || `HTTP ${res.statusCode}`;
        queueMicrotask(() => ownerAssistant.recordIssue(id, { code: body?.code || `${req.method}_${res.statusCode}`, route: apiRoute, error: detail, status: res.statusCode }).catch(() => {}));
      }
    }
    return sendJson(body);
  };
  next();
});

app.get('/api/health', (_req, res) => res.json({ ok: true, version: store.APP_VERSION, time: new Date().toISOString(), node: process.version }));

const messagingCommandRegistry = new CommandRegistry();
for (const [key, description, aliases, permission] of [
  ['send_message', 'إرسال رسالة جديدة', ['ابعت رسالة','ارسل رسالة'], 'owner'],
  ['schedule_message', 'جدولة رسالة', ['جدول رسالة','ارسل لاحقًا'], 'owner'],
  ['forward_message', 'تحويل رسالة موجودة', ['حول رسالة','فوروارد'], 'owner'],
  ['contact_list', 'عرض جهات الاتصال', ['وريني الناس','اعرض الاشخاص'], 'owner'],
]) messagingCommandRegistry.register({ key, description, aliases, permission, execute: async (_context, parameters) => parameters });

app.get('/api/messaging/dictionary', (req, res) => {
  try { const id = sid(req), s = store.loadSession(id); res.json({ ok:true, entries:s.commandDictionary || [], builtins:matchDictionary('ابعت رسالة').map(x=>({intent:x.intent,score:x.score,matchedPhrase:x.matchedPhrase})), commands:messagingCommandRegistry.list() }); }
  catch (e) { replyError(res, e, 500); }
});
app.post('/api/messaging/dictionary', (req, res) => {
  try {
    const id = sid(req), entry = validateEntry(req.body || {}), s = store.loadSession(id);
    const existing = (s.commandDictionary || []).findIndex(x => x.id === entry.id);
    if (existing >= 0) s.commandDictionary[existing] = entry; else s.commandDictionary = [...(s.commandDictionary || []), entry].slice(-1000);
    store.saveSession(s); res.json({ ok:true, entry, entries:s.commandDictionary, message:'تم حفظ عبارات القاموس. ستُستخدم في المطابقة التالية دون إعادة تشغيل.' });
  } catch (e) { replyError(res, e, 422); }
});
app.delete('/api/messaging/dictionary/:id', (req, res) => {
  try { const s = store.loadSession(sid(req)), before=(s.commandDictionary||[]).length; s.commandDictionary=(s.commandDictionary||[]).filter(x=>x.id!==req.params.id); if(s.commandDictionary.length===before) throw new Error('لم أجد عبارة قاموس بهذا المعرّف.'); store.saveSession(s); res.json({ok:true,entries:s.commandDictionary}); }
  catch(e) { replyError(res,e,404); }
});
app.post('/api/messaging/dictionary/test', (req, res) => {
  try { const s=store.loadSession(sid(req)), text=String(req.body?.text||''); const result=require('./src/messaging/intent-resolver').resolveIntent(text,s.commandDictionary||[]); res.json({ok:true,result}); }
  catch(e) { replyError(res,e,422); }
});


app.get('/api/state', (req, res) => { try { res.json({ ok: true, ...snapshot(sid(req)) }); } catch (e) { replyError(res, e, 500); } });
app.get('/api/countries', (_req, res) => { try { res.json({ ok: true, countries: phones.countries() }); } catch (e) { replyError(res, e, 500); } });
app.post('/api/phone/validate', (req, res) => { try { const country = String(req.body?.country || 'OM').toUpperCase(); const phone = phones.parse(req.body?.phone || '', country); res.json({ ok: true, valid: true, phone }); } catch (e) { res.status(422).json({ ok: false, valid: false, error: safeError(e) }); } });
app.get('/api/assistant/center', (req, res) => { try { const id=sid(req), s=store.loadSession(id); res.json({ ok:true, session:{id:s.id,name:s.name}, ownerAssistant:s.ownerAssistant, diagnostics:ownerAssistant.diagnostics(id), whatsapp:whatsapp.listRuntime(id) }); } catch(e) { replyError(res,e,500); } });
app.post('/api/assistant/activity', (req, res) => { try { const id=sid(req), body=req.body || {}; const message=String(body.message || '').trim(); if (!message) throw new Error('رسالة سجل المساعد فارغة.'); if (message.length > 1200) throw new Error('رسالة سجل المساعد أطول من الحد المسموح.'); const item=ownerAssistant.recordActivity(id,{message,type:body.type,page:body.page,issueId:body.issueId,source:body.source || 'ui'}); res.json({ok:true,activity:item,message:'حُفظت الرسالة في سجل المساعد.'}); } catch(e) { replyError(res,e,422); } });
app.post('/api/assistant/config', (req, res) => { try { const result=ownerAssistant.saveConfig(sid(req), req.body || {}); res.json({ok:true, ownerAssistant:result.ownerAssistant, message:'تم حفظ إعدادات مركز المساعد لهذه الجلسة.'}); } catch(e) { replyError(res,e,422); } });
app.post('/api/assistant/diagnostics', async (req, res) => { try { const id=sid(req), diagnostics=await ownerAssistant.runDiagnostics(id,{persist:true}); res.json({ok:true, diagnostics, ownerAssistant:store.loadSession(id).ownerAssistant, message:'اكتمل فحص الجلسة وحفظت المشكلات التي تحتاج متابعة.'}); } catch(e) { replyError(res,e,500); } });
app.post('/api/assistant/test-notification', async (req, res) => { try { const result=await ownerAssistant.testNotification(sid(req)); res.json(result); } catch(e) { replyError(res,e,422); } });
app.post('/api/assistant/issues/:id/resolve', async (req, res) => { try { const issue=await ownerAssistant.resolveIssue(sid(req), req.params.id); res.json({ok:true,issue,message:'تم تعليم المشكلة كمحلولة.'}); } catch(e) { replyError(res,e,404); } });
app.post('/api/assistant/chat', async (req, res) => { try {
  const id = sid(req), text = String(req.body?.text || '').trim();
  if (!text) throw new Error('اكتب سؤالك أو الأمر أولًا.');
  if (text.length > 1000) throw new Error('الرسالة أطول من الحد المسموح (1000 حرف).');
  const s = store.loadSession(id);
  ownerAssistant.addMessage(s, 'user', text, { page:'owner-center', kind:'local-chat' }); store.saveSession(s);
  const result = await ownerAssistant.executeCommand(id, text, { source:'local-chat' });
  const fresh = store.loadSession(id);
  ownerAssistant.addMessage(fresh, 'assistant', result.response, { page:'owner-center', kind:result.ok === false ? 'local-command-error' : 'local-chat-reply' }); store.saveSession(fresh);
  res.json({ ok:true, response:result.response, action:result.action || 'unknown', commandOk:result.ok === true, executed:result.executed === true, ownerAssistant:fresh.ownerAssistant });
} catch(e) { replyError(res,e,422); } });

app.get('/api/diagnostics', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), p = store.getPaths(id), scan = media.scan(p.media, s.settings.maxImageSizeMB), runtime = whatsapp.listRuntime(id);
    res.json({ ok: true, version: store.APP_VERSION, checks: {
      session: true, mediaFolder: fs.existsSync(p.media), authFolder: fs.existsSync(p.auth), mediaCount: scan.files.length,
      groups: s.groups.length, recipients: s.recipients.length, interactionRules: s.interaction.rules.length, whatsapp: !!runtime.ready,
      scheduleTargets: validTargetKeys(s, s.settings.scheduleTargetKeys).length, compatPatched: true,
    }, runtime, dependency: 'whatsapp-web.js 1.34.7' });
  } catch (e) { replyError(res, e, 500); }
});

const upload = multer({ dest: TEMP, limits: { files: 20, fileSize: 250 * 1024 * 1024 } });
const bgUpload = multer({ dest: TEMP, limits: { fileSize: 50 * 1024 * 1024, files: 1 } });
const avatarUpload = multer({ dest: TEMP, limits: { fileSize: 5 * 1024 * 1024, files: 1 } });
const activeProfileRefreshes = new Set();
const queuedProfileRefreshes = new Set();
const recipientProfileRefreshQueue = [];
let activeProfileRefreshWorkers = 0;
const MAX_PROFILE_REFRESH_WORKERS = 2;
function validWhatsAppAvatar(value) {
  try {
    if (!value) return '';
    const parsed = new URL(String(value));
    if (parsed.protocol !== 'https:' || !/(?:\.|^)(?:whatsapp\.net|fbcdn\.net)$/i.test(parsed.hostname)) return '';
    return parsed.toString().slice(0, 2000);
  } catch { return ''; }
}
function removeRecipientImageFile(sessionId, filename) {
  const safeName = path.basename(String(filename || ''));
  if (!/^recipient-[a-f0-9-]+\.(?:jpg|jpeg|png|webp)$/i.test(safeName)) return;
  try { fs.unlinkSync(path.join(store.getPaths(sessionId).avatars, safeName)); } catch {}
}
function removeRecipientAvatar(sessionId, recipient) { removeRecipientImageFile(sessionId, recipient?.localAvatarFile); }
function removeRecipientWhatsAppAvatar(sessionId, recipient) { removeRecipientImageFile(sessionId, recipient?.whatsappAvatarFile); }
function isAllowedWhatsAppImageUrl(value) {
  try { const url = new URL(String(value || '')); return url.protocol === 'https:' && /(?:^|\.)(?:whatsapp\.net|fbcdn\.net)$/i.test(url.hostname) ? url : null; } catch { return null; }
}
async function cacheWhatsAppAvatar(sessionId, recipientId, rawUrl) {
  let current = isAllowedWhatsAppImageUrl(rawUrl);
  if (!current) throw new Error('رابط صورة WhatsApp غير مسموح به.');
  let response = null;
  for (let redirects = 0; redirects <= 3; redirects++) {
    const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 9000);
    try { response = await fetch(current, { method:'GET', redirect:'manual', signal:controller.signal, headers:{ 'Accept':'image/avif,image/webp,image/png,image/jpeg;q=0.9,*/*;q=0.1', 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36' } }); }
    finally { clearTimeout(timer); }
    if ([301,302,303,307,308].includes(response.status)) {
      const location = response.headers.get('location');
      if (!location || redirects === 3) throw new Error('تجاوز رابط صورة WhatsApp عدد التحويلات المسموح.');
      current = isAllowedWhatsAppImageUrl(new URL(location, current).toString());
      if (!current) throw new Error('حُظر تحويل صورة WhatsApp إلى نطاق غير موثوق.');
      continue;
    }
    break;
  }
  if (!response?.ok) throw new Error(`تعذر تنزيل صورة WhatsApp (HTTP ${response?.status || 'غير معروف'}).`);
  const mime = String(response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  const extensions = { 'image/jpeg':'.jpg', 'image/png':'.png', 'image/webp':'.webp' };
  const ext = extensions[mime];
  if (!ext) throw new Error('صيغة صورة WhatsApp غير مدعومة للحفظ المحلي.');
  const size = Number(response.headers.get('content-length') || 0);
  if (size > 5 * 1024 * 1024) throw new Error('صورة WhatsApp أكبر من 5 ميجابايت.');
  const reader = response.body?.getReader();
  if (!reader) throw new Error('لم يرسل WhatsApp محتوى الصورة.');
  const chunks = []; let total = 0;
  while (true) {
    const item = await reader.read(); if (item.done) break;
    total += item.value.byteLength;
    if (total > 5 * 1024 * 1024) { try { await reader.cancel(); } catch {} throw new Error('صورة WhatsApp أكبر من 5 ميجابايت.'); }
    chunks.push(Buffer.from(item.value));
  }
  if (!total) throw new Error('صورة WhatsApp فارغة.');
  const filename = `recipient-${require('node:crypto').randomUUID()}${ext}`;
  const target = path.join(store.getPaths(sessionId).avatars, filename);
  fs.writeFileSync(target, Buffer.concat(chunks, total), { flag:'wx' });
  return filename;
}
async function refreshRecipientProfile(sessionId, recipientId) {
  const id = store.safeSessionId(sessionId), key = `${id}|${recipientId}`;
  if (activeProfileRefreshes.has(key) || !whatsapp.listRuntime(id).ready) return { skipped: true };
  activeProfileRefreshes.add(key);
  try {
    const initial = store.loadSession(id).recipients.find(item => item.id === recipientId);
    if (!initial) return { skipped: true };
    const profile = await whatsapp.lookupRecipientProfile(id, initial);
    const fresh = store.loadSession(id), recipient = fresh.recipients.find(item => item.id === recipientId);
    if (!recipient) return { skipped: true };
    recipient.profileError = '';
    if (profile.whatsappName) recipient.whatsappName = String(profile.whatsappName).slice(0, 120);
    if (profile.waChatId) recipient.waChatId = String(profile.waChatId).slice(0, 120);
    if (profile.avatarReadOk && profile.avatarStatus === 'available' && validWhatsAppAvatar(profile.whatsappAvatarUrl)) {
      const remoteUrl = validWhatsAppAvatar(profile.whatsappAvatarUrl);
      recipient.whatsappAvatarUrl = remoteUrl;
      try {
        const cachedFile = await cacheWhatsAppAvatar(id, recipient.id, remoteUrl);
        const oldFile = recipient.whatsappAvatarFile;
        recipient.whatsappAvatarFile = cachedFile;
        if (oldFile && oldFile !== cachedFile) removeRecipientImageFile(id, oldFile);
      } catch (avatarError) {
        // Keep a previously cached file if downloading a fresh WhatsApp URL failed, but expose the failure.
        recipient.profileError = `تعذر تحديث صورة WhatsApp: ${safeError(avatarError).slice(0, 300)}`;
      }
    } else if (profile.avatarReadOk && profile.avatarStatus === 'none') {
      removeRecipientWhatsAppAvatar(id, recipient);
      recipient.whatsappAvatarFile = ''; recipient.whatsappAvatarUrl = '';
    } else if (profile.avatarError) {
      recipient.profileError = String(profile.avatarError).slice(0, 600);
    }
    recipient.profileCheckedAt = profile.profileCheckedAt || new Date().toISOString();
    if (!recipient.localName && recipient.whatsappName) recipient.name = recipient.whatsappName;
    store.saveSession(fresh);
    log(id, 'INFO', `تم تحديث بيانات WhatsApp المحلية لجهة الاتصال: ${recipient.localName || recipient.whatsappName || recipient.name || recipient.phone}`);
    return { ok: true, profile };
  } catch (error) {
    const detail = safeError(error).slice(0, 600);
    try {
      const fresh = store.loadSession(id), recipient = fresh.recipients.find(item => item.id === recipientId);
      if (recipient) { recipient.profileCheckedAt = new Date().toISOString(); recipient.profileError = detail; store.saveSession(fresh); }
    } catch {}
    log(id, 'WARN', `تعذر جلب اسم/صورة WhatsApp لجهة ${recipientId}: ${detail}`);
    return { ok: false, error: detail };
  } finally { activeProfileRefreshes.delete(key); }
}
function pumpRecipientProfileRefreshQueue() {
  while (activeProfileRefreshWorkers < MAX_PROFILE_REFRESH_WORKERS && recipientProfileRefreshQueue.length) {
    const job = recipientProfileRefreshQueue.shift();
    if (!job) continue;
    activeProfileRefreshWorkers++;
    Promise.resolve().then(() => refreshRecipientProfile(job.sessionId, job.recipientId))
      .catch(error => log(job.sessionId, 'WARN', `تعذر تحديث ملف جهة الاتصال: ${safeError(error)}`))
      .finally(() => { activeProfileRefreshWorkers--; queuedProfileRefreshes.delete(job.key); pumpRecipientProfileRefreshQueue(); });
  }
}
function scheduleRecipientProfileRefresh(sessionId, recipientId) {
  const id = store.safeSessionId(sessionId), key = `${id}|${recipientId}`;
  if (queuedProfileRefreshes.has(key) || activeProfileRefreshes.has(key) || !whatsapp.listRuntime(id).ready) return;
  queuedProfileRefreshes.add(key);
  recipientProfileRefreshQueue.push({ sessionId:id, recipientId:String(recipientId), key });
  pumpRecipientProfileRefreshQueue();
}

app.post('/api/sessions', (req, res) => { try { const s = store.createSession(req.body?.name); res.json({ ok: true, session: { id: s.id, name: s.name }, activeSessionId: store.activeSessionId(), sessions: store.listSessionIds() }); } catch (e) { replyError(res, e); } });
app.post('/api/sessions/switch', async (req, res) => {
  try {
    const target = store.safeSessionId(req.body?.sessionId);
    if (!store.listSessionIds().includes(target)) throw new Error('الجلسة غير موجودة.');
    const s = store.setActiveSession(target);
    if (s.settings.autoStartSession && whatsapp.hasSavedAuth(target) && !whatsapp.listRuntime(target).ready) whatsapp.start(target).catch(err => log(target, 'WARN', `تعذر تشغيل الجلسة عند التبديل: ${safeError(err)}`));
    res.json({ ok: true, session: s.id });
  } catch (e) { replyError(res, e); }
});
app.put('/api/sessions/:id', (req, res) => { try { res.json({ ok: true, session: store.renameSession(req.params.id, req.body?.name) }); } catch (e) { replyError(res, e); } });
app.delete('/api/sessions/:id', async (req, res) => { try { const deleting = store.safeSessionId(req.params.id); if (!store.listSessionIds().includes(deleting)) throw new Error('الجلسة غير موجودة أو حُذفت بالفعل.'); await whatsapp.stop(deleting, { clearAuth: true }); res.json({ ok: true, ...store.deleteSession(deleting) }); } catch (e) { replyError(res, e); } });

app.post('/api/session/connect', async (req, res) => { try { const runtime = await whatsapp.start(sid(req)); const message = runtime.ready ? 'الجلسة جاهزة.' : runtime.status === 'recovering' ? 'حدث تعطل مؤقت أثناء انتقال صفحة WhatsApp؛ سيحاول النظام إعادة الاتصال تلقائيًا. لا تضغط الاتصال مرارًا.' : runtime.status === 'qr' ? 'ظهر رمز QR؛ امسحه من WhatsApp على الهاتف.' : 'تم بدء الاتصال؛ انتظر الحالة أو امسح QR إذا ظهر.'; res.json({ ok: true, runtime, message }); } catch (e) { replyError(res, e); } });
app.post('/api/session/stop', async (req, res) => { try { await whatsapp.stop(sid(req)); res.json({ ok: true }); } catch (e) { replyError(res, e); } });
app.post('/api/session/unlink', async (req, res) => { try { await whatsapp.stop(sid(req), { clearAuth: true }); res.json({ ok: true }); } catch (e) { replyError(res, e); } });

app.post('/api/recipient', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id);
    const parsed = phones.parse(req.body?.phone, String(req.body?.country || 'OM'));
    const name = String(req.body?.name || req.body?.whatsappName || '').trim();
    if (!name) throw new Error('اكتب اسم المستلم.');
    if (s.recipients.some(x => x.phone === parsed.digits || x.e164 === parsed.e164)) throw new Error('الرقم مكرر في الجلسة.');
    const recipient = { id: randomId(), name: name.slice(0, 80), ...parsed, whatsappName: String(req.body?.whatsappName || '').slice(0,120), waChatId: String(req.body?.waChatId || '').slice(0,120), whatsappAvatarUrl: validWhatsAppAvatar(req.body?.whatsappAvatarUrl), localName: '', localAvatarFile: '', profileCheckedAt: '', profileError: '', enabled: true };
    s.recipients.push(recipient); s.setupComplete = true;
    store.saveSession(s);
    // Save first: remote profile reads must not block the user's recipient workflow.
    res.json({ ok: true, recipient: { ...recipient, displayName: recipient.whatsappName || recipient.name } });
    scheduleRecipientProfileRefresh(id, recipient.id);
  } catch (e) { replyError(res, e); }
});
app.post('/api/recipient/from-whatsapp', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), selectedId = String(req.body?.contactId || '').trim().toLowerCase();
    if (!selectedId) throw new Error('اختر جهة اتصال من WhatsApp.');
    const contacts = await whatsapp.listWhatsAppContacts(id);
    const contact = contacts.find(item => String(item.id || '').toLowerCase() === selectedId || (Array.isArray(item.aliases) && item.aliases.includes(selectedId)));
    if (!contact) throw new Error('جهة الاتصال غير موجودة في قائمة WhatsApp الحالية. حدّث القائمة ثم أعد المحاولة.');
    const parsed = phones.parse(`+${contact.phone}`, 'OM');
    if (s.recipients.some(x => x.phone === parsed.digits || x.e164 === parsed.e164)) throw new Error('جهة الاتصال موجودة بالفعل في قائمة الإرسال.');
    const recipient = { id: randomId(), name: String(contact.name || parsed.international).slice(0, 120), whatsappName: String(contact.name || '').slice(0,120), whatsappAvatarUrl: validWhatsAppAvatar(contact.avatarUrl), waChatId: String(contact.id || '').slice(0,120), localName: '', localAvatarFile: '', profileCheckedAt: '', profileError: '', ...parsed, enabled: true };
    s.recipients.push(recipient); s.setupComplete = true; store.saveSession(s);
    res.json({ ok: true, recipient: { ...recipient, displayName: recipient.whatsappName || recipient.name }, message: 'تمت الإضافة باسم WhatsApp. جارٍ جلب الصورة الحالية إذا كانت متاحة.' });
    scheduleRecipientProfileRefresh(id, recipient.id);
  } catch (e) { replyError(res, e); }
});
app.patch('/api/recipient/:id/auto-reply', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), person = s.recipients.find(item => item.id === req.params.id);
    if (!person) throw new Error('المستلم غير موجود.');
    const body = req.body || {};
    const mode = ['inherit', 'off', 'custom'].includes(String(body.mode || '')) ? String(body.mode) : 'inherit';
    const allowed = new Set(['any', 'contains', 'exact', 'starts', 'ends']);
    const rules = (Array.isArray(body.rules) ? body.rules : []).slice(0, 30).map((item, index) => ({
      id: String(item.id || randomId()), enabled: item.enabled !== false, name: String(item.name || `قاعدة ${index + 1}`).trim().slice(0, 80),
      match: allowed.has(String(item.match || 'contains')) ? String(item.match || 'contains') : 'contains',
      value: String(item.value || '').trim().slice(0, 500), reply: String(item.reply || '').slice(0, 60000), cooldownSec: store.toInt(item.cooldownSec, 0, 0, 86400),
    })).filter(rule => rule.match === 'any' || (rule.value && rule.reply.trim()));
    person.autoReply = store.normalizeRecipientAutoReply({ mode, rules, fallbackReply: String(body.fallbackReply || '').slice(0, 60000), conversationEnabled: boolValue(body.conversationEnabled, false), fallbackToGlobal: boolValue(body.fallbackToGlobal, true), cooldownSec: store.toInt(body.cooldownSec, 0, 0, 86400) });
    store.saveSession(s);
    res.json({ ok: true, autoReply: person.autoReply, message: 'تم حفظ إعداد الرد الشخصي.' });
  } catch (e) { replyError(res, e); }
});
app.patch('/api/recipient/:id', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), recipient = s.recipients.find(item => item.id === req.params.id);
    if (!recipient) throw new Error('المستلم غير موجود.');
    if (!Object.prototype.hasOwnProperty.call(req.body || {}, 'localName')) throw new Error('لم يتم إرسال الاسم المحلي الجديد.');
    recipient.localName = String(req.body.localName ?? '').trim().slice(0, 120);
    store.saveSession(s);
    res.json({ ok: true, recipient: { ...recipient, displayName: recipient.localName || recipient.whatsappName || recipient.name } });
  } catch (e) { replyError(res, e); }
});
app.get('/api/whatsapp/contacts', async (req, res) => {
  try {
    const id = sid(req);
    if (!whatsapp.listRuntime(id).ready) throw new Error('اتصل بحساب WhatsApp أولًا لتحميل قائمة جهات الاتصال.');
    const contacts = await whatsapp.listWhatsAppContacts(id);
    const existing = new Set(store.loadSession(id).recipients.map(item => String(item.phone || item.digits || '').replace(/\D/g, '')));
    res.json({ ok: true, contacts: contacts.map(contact => ({ ...contact, exists: existing.has(String(contact.phone || '').replace(/\D/g, '')) })) });
  } catch (e) { replyError(res, e); }
});
app.post('/api/whatsapp/contacts/profile-batch', async (req, res) => {
  try {
    const id = sid(req);
    if (!whatsapp.listRuntime(id).ready) throw new Error('اتصل بحساب WhatsApp قبل جلب صور الملف الشخصي.');
    const source = Array.isArray(req.body?.contacts) ? req.body.contacts.slice(0, 40) : [];
    const input = source.map(item => ({ id: String(item?.id || '').trim().toLowerCase(), phone: String(item?.phone || '').replace(/\D/g, '') }))
      .filter(item => item.id && /^\d{6,15}$/.test(item.phone));
    if (!input.length) return res.json({ ok:true, profiles:[] });
    const results = new Array(input.length); let next = 0;
    async function worker() {
      while (next < input.length) {
        const index = next++, item = input[index];
        try {
          const profile = await whatsapp.lookupRecipientProfile(id, { phone:item.phone, digits:item.phone, e164:`+${item.phone}`, waChatId:item.id });
          results[index] = { id:item.id, whatsappName:profile.whatsappName || '', avatarUrl:profile.avatarReadOk ? validWhatsAppAvatar(profile.whatsappAvatarUrl) : '', avatarStatus:profile.avatarStatus || 'error', avatarError:profile.avatarError || '', profileCheckedAt:profile.profileCheckedAt || '' };
        } catch (error) {
          results[index] = { id:item.id, whatsappName:'', avatarUrl:'', avatarStatus:'error', avatarError:safeError(error).slice(0,240) };
        }
      }
    }
    await Promise.all(Array.from({ length:Math.min(4, input.length) }, () => worker()));
    res.json({ ok:true, profiles:results });
  } catch (e) { replyError(res, e); }
});

app.post('/api/recipients/sync-preview', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id);
    if (!whatsapp.listRuntime(id).ready) throw new Error('اتصل بحساب WhatsApp قبل فحص الأسماء والصور.');
    const requested = Array.isArray(req.body?.ids) ? [...new Set(req.body.ids.map(String))].slice(0, 200) : [];
    const people = s.recipients.filter(item => !requested.length || requested.includes(item.id)).slice(0, 200);
    if (!people.length) throw new Error('لا توجد جهات اتصال لفحصها.');
    let next = 0;
    const results = new Array(people.length);
    async function worker() {
      while (next < people.length) {
        const index = next++, person = people[index];
        const beforeName = String(person.whatsappName || person.name || person.phone || 'بدون اسم');
        const beforeAvatar = String(person.whatsappAvatarUrl || '');
        try {
          const profile = await whatsapp.lookupRecipientProfile(id, person);
          const afterName = String(profile.whatsappName || person.whatsappName || person.name || person.phone || 'بدون اسم');
          const afterAvatar = profile.avatarReadOk ? validWhatsAppAvatar(profile.whatsappAvatarUrl) : beforeAvatar;
          const changedName = Boolean(profile.whatsappName && profile.whatsappName !== String(person.whatsappName || person.name || ''));
          const changedAvatar = Boolean(profile.avatarReadOk && (profile.avatarStatus === 'none' ? Boolean(person.whatsappAvatarFile || beforeAvatar) : afterAvatar !== beforeAvatar));
          results[index] = { id: person.id, phone: person.international || person.e164 || person.phone, localName: person.localName || '', localAvatarFile: person.localAvatarFile || '', before: { name: beforeName, avatarUrl: beforeAvatar }, after: { name: afterName, avatarUrl: afterAvatar }, changedName, changedAvatar, changed: changedName || changedAvatar, profile: { waChatId: profile.waChatId || person.waChatId || '', whatsappName: profile.whatsappName || person.whatsappName || '', whatsappAvatarUrl: profile.avatarReadOk ? afterAvatar : beforeAvatar, avatarReadOk: profile.avatarReadOk, avatarStatus: profile.avatarStatus || 'error', avatarError: profile.avatarError || '', profileCheckedAt: profile.profileCheckedAt }, error: '' };
        } catch (error) {
          results[index] = { id: person.id, phone: person.international || person.e164 || person.phone, before: { name: beforeName, avatarUrl: beforeAvatar }, after: { name: beforeName, avatarUrl: beforeAvatar }, changedName: false, changedAvatar: false, changed: false, profile: null, error: safeError(error) };
        }
      }
    }
    await Promise.all(Array.from({ length: Math.min(3, people.length) }, () => worker()));
    res.json({ ok: true, scanned: results.length, changed: results.filter(item => item.changed).length, failed: results.filter(item => item.error).length, changes: results });
  } catch (e) { replyError(res, e); }
});
app.post('/api/recipients/sync-apply', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), updates = Array.isArray(req.body?.updates) ? req.body.updates.slice(0, 200) : [];
    if (!updates.length) throw new Error('حدد تغييرات لمزامنتها.');
    const applied = [], failed = [];
    for (const update of updates) {
      const recipient = s.recipients.find(item => item.id === String(update.id || ''));
      if (!recipient) { failed.push({ id: update.id, error: 'لم يتم العثور على جهة الاتصال.' }); continue; }
      const profile = update.profile || {};
      recipient.profileError = '';
      if (profile.avatarError && profile.avatarStatus === 'error') recipient.profileError = String(profile.avatarError).slice(0, 600);
      if (typeof profile.whatsappName === 'string' && profile.whatsappName.trim()) recipient.whatsappName = profile.whatsappName.trim().slice(0, 120);
      else if (profile.whatsappName === '') recipient.whatsappName = '';
      if (typeof profile.waChatId === 'string' && /^(?:\d{6,20}@c\.us|\d{6,30}@lid)$/.test(profile.waChatId)) recipient.waChatId = profile.waChatId;
      if (profile.avatarReadOk === true) {
        const remote = validWhatsAppAvatar(profile.whatsappAvatarUrl);
        if (remote) {
          recipient.whatsappAvatarUrl = remote;
          try {
            const file = await cacheWhatsAppAvatar(id, recipient.id, remote), oldFile = recipient.whatsappAvatarFile;
            recipient.whatsappAvatarFile = file;
            if (oldFile && oldFile !== file) removeRecipientImageFile(id, oldFile);
          } catch (avatarError) {
            recipient.profileError = `تعذر حفظ الصورة المتزامنة: ${safeError(avatarError).slice(0, 300)}`;
            failed.push({ id: recipient.id, error: recipient.profileError });
          }
        } else if (profile.avatarStatus === 'none') {
          removeRecipientWhatsAppAvatar(id, recipient); recipient.whatsappAvatarFile = ''; recipient.whatsappAvatarUrl = '';
        }
      }
      if (profile.profileCheckedAt) recipient.profileCheckedAt = String(profile.profileCheckedAt).slice(0, 80);
      if (!recipient.localName && recipient.whatsappName) recipient.name = recipient.whatsappName;
      applied.push(recipient.id);
    }
    store.saveSession(s);
    res.json({ ok: true, applied, failed, message: `تمت مزامنة ${applied.length} جهة اتصال. لم يتم تغيير الأسماء أو الصور المحلية المخصصة داخل المشروع.` });
  } catch (e) { replyError(res, e); }
});
app.get('/api/recipient/:id/profile-status', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), recipient = s.recipients.find(item => item.id === req.params.id);
    if (!recipient) throw new Error('المستلم غير موجود.');
    const key = `${id}|${recipient.id}`;
    res.json({ ok:true, busy:activeProfileRefreshes.has(key) || queuedProfileRefreshes.has(key), profileCheckedAt:recipient.profileCheckedAt || '', profileError:recipient.profileError || '', whatsappName:recipient.whatsappName || '', whatsappAvatarUrl:recipient.whatsappAvatarUrl || '' });
  } catch (e) { replyError(res, e, 404); }
});
app.get('/api/recipient/:id/avatar', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), recipient = s.recipients.find(item => item.id === req.params.id);
    if (!recipient?.localAvatarFile) return res.status(404).json({ ok: false, error: 'لا توجد صورة محلية لهذا الشخص.' });
    const file = path.join(store.getPaths(id).avatars, path.basename(recipient.localAvatarFile));
    if (!fs.existsSync(file)) return res.status(404).json({ ok: false, error: 'ملف الصورة المحلية غير موجود.' });
    res.setHeader('Cache-Control', 'private, max-age=300');
    res.sendFile(file, error => { if (error && !res.headersSent) res.status(404).json({ ok: false, error: 'تعذر قراءة الصورة المحلية.' }); });
  } catch (e) { replyError(res, e, 404); }
});

app.get('/api/recipient/:id/whatsapp-avatar', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), recipient = s.recipients.find(item => item.id === req.params.id);
    if (!recipient) return res.status(404).json({ ok:false, error:'المستلم غير موجود.' });
    const safeName = path.basename(String(recipient.whatsappAvatarFile || ''));
    if (safeName && /^recipient-[a-f0-9-]+\.(?:jpg|jpeg|png|webp)$/i.test(safeName)) {
      const file = path.join(store.getPaths(id).avatars, safeName);
      if (fs.existsSync(file)) { res.setHeader('Cache-Control','private, max-age=3600'); return res.sendFile(file, error => { if (error && !res.headersSent) res.status(404).end(); }); }
    }
    const remote = validWhatsAppAvatar(recipient.whatsappAvatarUrl);
    if (remote) return res.redirect(302, remote);
    return res.status(404).json({ ok:false, error:'لا توجد صورة ملف شخصي متاحة من WhatsApp.' });
  } catch (error) { replyError(res, error, 404); }
});

app.post('/api/recipient/:id/avatar', avatarUpload.single('file'), (req, res) => {
  let temp = req.file?.path || '';
  try {
    const id = sid(req), s = store.loadSession(id), recipient = s.recipients.find(item => item.id === req.params.id);
    if (!recipient) throw new Error('المستلم غير موجود.');
    if (!req.file) throw new Error('اختر صورة أولًا.');
    const extByMime = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' };
    const ext = extByMime[String(req.file.mimetype || '').toLowerCase()];
    if (!ext) throw new Error('صيغة الصورة غير مدعومة؛ استخدم JPG أو PNG أو WEBP.');
    const avatarName = `recipient-${String(recipient.id).replace(/[^a-f0-9-]/gi, '').toLowerCase()}${ext}`;
    const target = path.join(store.getPaths(id).avatars, avatarName);
    const previous = recipient.localAvatarFile;
    fs.renameSync(temp, target); temp = '';
    recipient.localAvatarFile = avatarName; store.saveSession(s);
    if (previous && previous !== avatarName) removeRecipientAvatar(id, { localAvatarFile: previous });
    res.json({ ok: true, avatarUrl: `/api/recipient/${encodeURIComponent(recipient.id)}/avatar?sessionId=${encodeURIComponent(id)}&v=${Date.now()}` });
  } catch (e) { if (temp) { try { fs.unlinkSync(temp); } catch {} } replyError(res, e); }
});
app.delete('/api/recipient/:id/avatar', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), recipient = s.recipients.find(item => item.id === req.params.id);
    if (!recipient) throw new Error('المستلم غير موجود.');
    removeRecipientAvatar(id, recipient); recipient.localAvatarFile = ''; store.saveSession(s);
    res.json({ ok: true, message: 'تمت إزالة الصورة المحلية؛ سيظهر ملف WhatsApp إذا كان متاحًا.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/recipients/bulk', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), parsed = phones.parseMany(req.body?.lines, String(req.body?.country || 'OM'));
    const added = [];
    for (const item of parsed.out) {
      if (s.recipients.some(x => x.phone === item.digits || x.e164 === item.e164)) continue;
      const { name, ...number } = item;
      added.push({ id: randomId(), name, ...number, whatsappName:'', whatsappAvatarUrl:'', localName:'', localAvatarFile:'', waChatId:'', profileCheckedAt:'', profileError:'', enabled: true });
    }
    s.recipients.push(...added); if (added.length) s.setupComplete = true; store.saveSession(s);
    res.json({ ok: true, added, failed: parsed.failed, skippedDuplicates: parsed.out.length - added.length });
    if (whatsapp.listRuntime(s.id).ready) added.slice(0, 100).forEach(person => scheduleRecipientProfileRefresh(s.id, person.id));
  } catch (e) { replyError(res, e); }
});
app.post('/api/recipient/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), r = s.recipients.find(x => x.id === req.params.id); if (!r) throw new Error('المستلم غير موجود.'); r.enabled = !r.enabled; store.saveSession(s); res.json({ ok: true, enabled: r.enabled }); } catch (e) { replyError(res, e); } });
app.post('/api/recipient/:id/hide-from-send', (req, res) => { try { const s=store.loadSession(sid(req)), r=s.recipients.find(x=>x.id===req.params.id); if(!r) throw new Error('المستلم غير موجود.'); r.hiddenFromSend=!r.hiddenFromSend; store.saveSession(s); res.json({ok:true,hiddenFromSend:r.hiddenFromSend,message:r.hiddenFromSend?'تم إخفاء المستلم من شاشة الإرسال فقط.':'تم إظهار المستلم في شاشة الإرسال.'}); } catch(e) { replyError(res,e); } });
app.delete('/api/recipient/:id', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), key = `r:${req.params.id}`, removed = s.recipients.find(x => x.id === req.params.id);
    if (!removed) throw new Error('المستلم غير موجود.');
    removeRecipientAvatar(id, removed); removeRecipientWhatsAppAvatar(id, removed);
    s.recipients = s.recipients.filter(x => x.id !== req.params.id); removeTargetFromSchedule(s, key);
    const deletedChatIds = new Set([String(removed.waChatId || '').toLowerCase(), `${String(removed.phone || removed.digits || '').replace(/\D/g, '')}@c.us`].filter(Boolean));
    s.settings.interactionChatIds = (s.settings.interactionChatIds || []).filter(value => !deletedChatIds.has(String(value).toLowerCase()));
    s.automation.tasks = (s.automation.tasks || []).map(task => { const oldKeys = Array.isArray(task.targetKeys) ? task.targetKeys : []; return { ...task, targetKeys: oldKeys.filter(k => k !== key), _removedTarget: oldKeys.includes(key) }; }).filter(task => !(task._removedTarget && !task.targetKeys.length)).map(({_removedTarget, ...task}) => task);
    store.saveSession(s); res.json({ ok: true, message: 'تم حذف الشخص وفك ارتباطه من الجداول وقواعد النطاق المحدد.' });
  } catch (e) { replyError(res, e); }
});

app.post('/api/recipients/bulk-delete', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id);
    const ids = [...new Set((Array.isArray(req.body?.ids) ? req.body.ids : []).map(String).filter(Boolean))].slice(0, 500);
    if (!ids.length) throw new Error('حدد شخصًا واحدًا على الأقل للحذف.');
    const wanted = new Set(ids), removed = s.recipients.filter(item => wanted.has(item.id));
    if (!removed.length) throw new Error('لم يتم العثور على الأشخاص المحددين.');
    for (const person of removed) { removeRecipientAvatar(id, person); removeRecipientWhatsAppAvatar(id, person); }
    const removedKeys = new Set(removed.map(person => `r:${person.id}`));
    s.recipients = s.recipients.filter(item => !wanted.has(item.id));
    s.settings.scheduleTargetKeys = (s.settings.scheduleTargetKeys || []).filter(key => !removedKeys.has(key));
    const deletedChatIds = new Set(removed.flatMap(person => [String(person.waChatId || '').toLowerCase(), `${String(person.phone || person.digits || '').replace(/\D/g, '')}@c.us`]).filter(Boolean));
    s.settings.interactionChatIds = (s.settings.interactionChatIds || []).filter(value => !deletedChatIds.has(String(value).toLowerCase()));
    const oldTasks = s.automation.tasks || [];
    s.automation.tasks = oldTasks.map(task => { const oldKeys = Array.isArray(task.targetKeys) ? task.targetKeys : []; return { ...task, targetKeys: oldKeys.filter(key => !removedKeys.has(key)), _removedTargets: oldKeys.some(key => removedKeys.has(key)) }; }).filter(task => !(task._removedTargets && !task.targetKeys.length)).map(({_removedTargets, ...task}) => task);
    const removedTasks = oldTasks.length - s.automation.tasks.length;
    store.saveSession(s);
    res.json({ ok: true, removed: removed.length, removedTasks, message: `تم حذف ${removed.length} شخص من قائمة الإرسال${removedTasks ? `، وإزالة ${removedTasks} موعد لم يعد لديه مستلمون` : ''}.` });
  } catch (e) { replyError(res, e); }
});

app.post('/api/groups/discover', async (req, res) => { try { const id = sid(req), found = await whatsapp.listGroups(id), saved = found.filter(x => x.gid).map(x => saveGroup(id, x)); res.json({ ok: true, found: found.length, saved, message: `تم اكتشاف ${saved.length} مجموعة في هذه الجلسة.` }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/refresh-all', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), saved = [], failed = [];
    for (const g of s.groups) { try { saved.push(saveGroup(id, await whatsapp.getGroupInfo(id, g.gid))); } catch (e) { failed.push({ id: g.id, name: g.name, error: safeError(e) }); } }
    res.json({ ok: true, saved, failed, message: failed.length ? `تم تحديث ${saved.length} مجموعة، وتعذر تحديث ${failed.length}.` : 'تم تحديث المجموعات.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/groups/add-gid', async (req, res) => { try { const id = sid(req), gid = groups.normalizeGid(req.body?.gid); if (!groups.isGroupId(gid)) throw new Error('GID المجموعة غير صالح.'); const info = await whatsapp.getGroupInfo(id, gid); res.json({ ok: true, group: saveGroup(id, info), message: 'تمت إضافة المجموعة إلى هذه الجلسة.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/connect', async (req, res) => {
  try {
    const id = sid(req), value = String(req.body?.value || '').trim();
    if (!value) throw new Error('أدخل GID أو رابط دعوة.');
    let info;
    if (/chat\.whatsapp\.com\//i.test(value)) {
      info = await whatsapp.analyzeGroupInvite(id, groups.extractInviteCode(value));
      if (info?.gid) { try { info = await whatsapp.getGroupInfo(id, groups.normalizeGid(info.gid)); } catch {} }
    } else {
      info = await whatsapp.getGroupInfo(id, groups.normalizeGid(value));
    }
    if (!info?.gid) throw new Error('لم أستطع الحصول على GID للمجموعة من WhatsApp.');
    const group = saveGroup(id, info);
    res.json({ ok: true, group, message: 'تم الربط والتحليل داخل الجلسة الحالية.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/groups/save', (req, res) => { try { const id = sid(req), g = req.body?.group || {}; if (!groups.isGroupId(g.gid)) throw new Error('GID المجموعة غير صالح.'); res.json({ ok: true, group: saveGroup(id, g), message: 'تم حفظ المجموعة داخل الجلسة الحالية.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/add-invite', async (req, res) => {
  try {
    const id = sid(req), code = groups.extractInviteCode(req.body?.url || req.body?.code), info = await whatsapp.analyzeGroupInvite(id, code);
    if (!info.gid) throw new Error('تم تحليل الدعوة لكن WhatsApp لم يعطِ GID لهذه المجموعة؛ افتح المجموعة أو استخدم الاكتشاف من الجلسة ثم أضفها.');
    res.json({ ok: true, group: saveGroup(id, info), message: 'تمت إضافة المجموعة إلى هذه الجلسة.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/groups/analyze-gid', async (req, res) => { try { const id=sid(req), info=await whatsapp.getGroupInfo(id, groups.normalizeGid(req.body?.gid)); res.json({ ok:true, group:saveGroup(id, info), message:'تم تحديث بيانات المجموعة داخل الجلسة.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/analyze-invite', async (req, res) => { try { const id=sid(req), info=await whatsapp.analyzeGroupInvite(id, groups.extractInviteCode(req.body?.url || req.body?.code)); res.json({ ok:true, group: info?.gid ? saveGroup(id, info) : info, message: info?.gid ? 'تم تحديث بيانات المجموعة.' : 'تم تحليل الدعوة؛ لم يوفر WhatsApp GID.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), g = s.groups.find(x => x.id === req.params.id); if (!g) throw new Error('المجموعة غير موجودة.'); g.enabled = !g.enabled; store.saveSession(s); res.json({ ok: true, enabled: g.enabled }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/:id/refresh', async (req, res) => { try { const id = sid(req), s = store.loadSession(id), g = s.groups.find(x => x.id === req.params.id); if (!g) throw new Error('المجموعة غير موجودة.'); res.json({ ok: true, group: saveGroup(id, await whatsapp.getGroupInfo(id, g.gid)) }); } catch (e) { replyError(res, e); } });
app.delete('/api/groups/:id', (req, res) => {
  try { const s = store.loadSession(sid(req)), key = `g:${req.params.id}`, removed = s.groups.find(x => x.id === req.params.id); if (!removed) throw new Error('المجموعة غير موجودة.'); s.groups = s.groups.filter(x => x.id !== req.params.id); removeTargetFromSchedule(s, key); const removedGid = String(removed.gid || '').toLowerCase(); s.settings.interactionChatIds = (s.settings.interactionChatIds || []).filter(x => String(x).toLowerCase() !== removedGid); s.automation.tasks = (s.automation.tasks || []).map(t => ({ ...t, targetKeys: (t.targetKeys || []).filter(k => k !== key) })).filter(t => (t.targetKeys || []).length || (t.preText || t.postText || (t.mediaIds || []).length)); store.saveSession(s); res.json({ ok: true }); }
  catch (e) { replyError(res, e); }
});

app.post('/api/groups/bulk', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), action = String(req.body?.action || ''), ids = [...new Set((Array.isArray(req.body?.ids) ? req.body.ids : []).map(String))].slice(0, 500);
    if (!ids.length) throw new Error('حدد مجموعة واحدة على الأقل.');
    if (!['enable','disable','delete'].includes(action)) throw new Error('الإجراء الجماعي غير صالح.');
    const selected = s.groups.filter(group => ids.includes(group.id));
    if (!selected.length) throw new Error('لم يتم العثور على المجموعات المحددة.');
    if (action === 'enable' || action === 'disable') {
      const enabled = action === 'enable'; selected.forEach(group => { group.enabled = enabled; group.updatedAt = new Date().toISOString(); });
    } else {
      const removedIds = new Set(selected.map(group => group.id)), removedGids = new Set(selected.map(group => String(group.gid || '').toLowerCase()));
      s.groups = s.groups.filter(group => !removedIds.has(group.id));
      s.settings.scheduleTargetKeys = (s.settings.scheduleTargetKeys || []).filter(key => ![...removedIds].some(id => key === `g:${id}`));
      s.settings.interactionChatIds = (s.settings.interactionChatIds || []).filter(value => !removedGids.has(String(value).toLowerCase()));
      s.automation.tasks = (s.automation.tasks || []).map(task => ({ ...task, targetKeys: (task.targetKeys || []).filter(key => ![...removedIds].some(id => key === `g:${id}`)) })).filter(task => (task.targetKeys || []).length || task.preText || task.postText || (task.mediaIds || []).length);
    }
    store.saveSession(s);
    res.json({ ok: true, affected: selected.length, action, message: action === 'enable' ? `تم تفعيل ${selected.length} مجموعة.` : action === 'disable' ? `تم إيقاف ${selected.length} مجموعة.` : `تم حذف ${selected.length} مجموعة من المكتبة المحلية.` });
  } catch (e) { replyError(res, e); }
});

app.post('/api/media', upload.array('files', 20), (req, res) => {
  try {
    const id = sid(req), dir = store.getPaths(id).media, saved = [], duplicates = [], rejected = [];
    const maxFileSizeMB = store.loadSession(id).settings.maxImageSizeMB;
    const maxFileBytes = Number(maxFileSizeMB) * 1024 * 1024;
    const replaceDuplicates = boolValue(req.body?.replaceDuplicates, false);
    const existing = new Map();
    for (const entry of media.scan(dir, store.loadSession(id).settings.maxImageSizeMB).files) {
      try { existing.set(`${entry.size}:${media.hashFile(media.safePath(dir, entry.filename))}`, entry.filename); } catch {}
    }
    for (const file of req.files || []) {
      const ext = path.extname(file.originalname || '').toLowerCase();
      if (Number(file.size) > maxFileBytes) { rejected.push({ filename: file.originalname, error: `حجم الملف يتجاوز الحد الحالي (${maxFileSizeMB} MB).` }); fs.rmSync(file.path, { force: true }); continue; }
      if (!media.MEDIA_EXT.has(ext)) { rejected.push({ filename: file.originalname, error: 'نوع غير مدعوم' }); fs.rmSync(file.path, { force: true }); continue; }
      const hash = media.hashFile(file.path);
      const duplicateName = existing.get(`${fs.statSync(file.path).size}:${hash}`);
      if (duplicateName && !replaceDuplicates) {
        duplicates.push({ incoming: file.originalname, existing: duplicateName }); fs.rmSync(file.path, { force: true }); continue;
      }
      if (duplicateName && replaceDuplicates) {
        fs.renameSync(file.path, media.safePath(dir, duplicateName)); saved.push(duplicateName); continue;
      }
      const name = media.IMAGE_EXT.has(ext) ? media.nextImageName(dir, ext) : media.uniqueFileName(dir, path.basename(file.originalname, path.extname(file.originalname)), ext);
      fs.renameSync(file.path, media.safePath(dir, name));
      existing.set(`${fs.statSync(media.safePath(dir, name)).size}:${media.hashFile(media.safePath(dir, name))}`, name);
      saved.push(name);
    }
    res.json({ ok: true, saved, duplicates, rejected, message: duplicates.length ? `تم رفع ${saved.length} ملف، ووجدت ${duplicates.length} ملفًا مكررًا لم يتم استبداله.` : `تم رفع ${saved.length} ملف.` });
  } catch (e) {
    for (const f of req.files || []) { try { fs.rmSync(f.path, { force: true }); } catch {} }
    replyError(res, e);
  }
});
app.get('/api/media/:filename/preview', (req, res) => {
  try {
    const filename = decodeURIComponent(req.params.filename), ext = path.extname(filename).toLowerCase();
    if (ext !== '.txt') return res.status(415).json({ ok: false, error: 'المعاينة النصية متاحة لملفات TXT فقط.' });
    const full = media.safePath(store.getPaths(sid(req)).media, filename), stat = fs.statSync(full);
    if (!stat.isFile()) throw new Error('الملف غير موجود.');
    const buffer = fs.readFileSync(full).subarray(0, 6000);
    const preview = buffer.toString('utf8').replace(/\u0000/g, '').replace(/[\x01-\x08\x0B\x0C\x0E-\x1F]/g, '').slice(0, 1200);
    res.setHeader('Cache-Control', 'no-store'); res.json({ ok: true, filename, preview, truncated: stat.size > buffer.length });
  } catch (e) { replyError(res, e, 404); }
});

app.delete('/api/media/:filename', (req, res) => { try { const id = sid(req), name = decodeURIComponent(req.params.filename); fs.rmSync(media.safePath(store.getPaths(id).media, name), { force: true }); const s = store.loadSession(id); s.automation.tasks = (s.automation.tasks || []).map(t => ({ ...t, mediaIds: (t.mediaIds || []).filter(x => String(x) !== name) })); if (s.settings.scheduleMediaId === name) s.settings.scheduleMediaId = ''; store.saveSession(s); res.json({ ok: true, message: 'تم حذف الملف.' }); } catch (e) { replyError(res, e); } });
app.get('/media/:filename', (req, res) => { try { res.sendFile(media.safePath(store.getPaths(sid(req)).media, decodeURIComponent(req.params.filename))); } catch { res.status(404).end(); } });

app.post('/api/send', async (req, res) => { try {
  const id = sid(req), result = await delivery.sendNow(id, req.body || {});
  const sent = Array.isArray(result.sent) ? result.sent.length : Number(result.sent || result.success || 0), failed = Array.isArray(result.failed) ? result.failed.length : Number(result.failed || 0);
  if (failed) ownerAssistant.recordIssue(id, { code:'SEND_PARTIAL_FAILURE', route:'/api/send', title:'تعذّر إرسال بعض الرسائل أو المرفقات', error:result.failed.slice(0, 8).map(x => `${x.target || 'هدف غير معروف'}: ${x.error || 'فشل غير محدد'}`).join(' | '), page:'send', steps:['افتح سجل النتيجة واقرأ خطأ كل مستلم.', 'تحقق من اتصال الجلسة الحالية.', 'تحقق من صحة الرقم أو GID وتفعيل الهدف.', 'جرّب إرسال نص إلى مستلم واحد فقط ثم جرّب الملف.', 'لا تضغط إعادة إرسال للجميع قبل مراجعة حالة الرسائل الناجحة لمنع التكرار.'] }).catch(() => {});
  res.json({ ...result, ok: true, complete: failed === 0, message: failed ? `نجح ${sent} إرسال، وتعذر ${failed}.` : `تم إرسال ${sent} عملية بنجاح.` });
} catch (e) { replyError(res, e); } });
app.post('/api/schedule', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), b = req.body || {}, time = String(b.scheduleTime || '17:30'), tm = time.match(/^(\d{2}):(\d{2})$/);
    const mode = ['weekly', 'monthly', 'once'].includes(b.scheduleMode) ? b.scheduleMode : 'weekly';
    if (!tm || Number(tm[1]) > 23 || Number(tm[2]) > 59) throw new Error('وقت الجدولة غير صالح.');
    if (mode === 'once' && !validIsoDate(b.scheduleDate)) throw new Error('أدخل تاريخًا تقويميًا صالحًا للجدولة مرة واحدة.');
    if (mode === 'monthly' && !(Number(b.scheduleMonthDay) >= 1 && Number(b.scheduleMonthDay) <= 31)) throw new Error('اختر يومًا صحيحًا من 1 إلى 31 للجدولة الشهرية.');
    const requestedTargets = Array.isArray(b.scheduleTargetKeys) ? b.scheduleTargetKeys : []; const targetKeys = validTargetKeys(s, requestedTargets.length ? requestedTargets : [...s.recipients.filter(x => x.enabled !== false).map(x => `r:${x.id}`), ...s.groups.filter(x => x.enabled !== false).map(x => `g:${x.id}`)]);
    Object.assign(s.settings, {
      scheduleMode: mode, scheduleTime: time,
      scheduleDay: store.toInt(b.scheduleDay, 5, 0, 6),
      scheduleMonthDay: store.toInt(b.scheduleMonthDay, 1, 1, 31),
      scheduleDate: String(b.scheduleDate || ''), scheduleEnabled: boolValue(b.scheduleEnabled, true),
      scheduledGroupsEnabled: true, scheduleTargetKeys: targetKeys,
      scheduleMediaId: String(b.scheduleMediaId || ''), schedulePreText: String(b.schedulePreText ?? ''), schedulePostText: String(b.schedulePostText ?? ''),
    });
    if (!targetKeys.length) throw new Error('أضف رقمًا أو مجموعة للجدولة.');
    if (s.settings.scheduleMediaId && !media.scan(store.getPaths(s.id).media, s.settings.maxImageSizeMB).files.some(x => x.id === s.settings.scheduleMediaId)) throw new Error('ملف الجدولة المحدد غير موجود.');
    s.scheduleState.lastRunKey = '';
    store.saveSession(s);
    res.json({ ok: true, nextRun: nextRun(s), targets: targetKeys.length, message: 'تم حفظ الجدولة.' });
  } catch (e) { replyError(res, e); }
});

app.post('/api/interaction/rules', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), b = req.body || {};
    const r = {
      id: randomId(), name: String(b.name || 'قاعدة').slice(0, 100), enabled: true, priority: store.toInt(b.priority, 0, -1000, 1000),
      when: { type: b.when?.type === 'reaction' ? 'reaction' : 'message', match: ['any', 'contains', 'exact', 'starts', 'ends', 'regex'].includes(b.when?.match) ? b.when.match : 'contains', value: String(b.when?.value || ''), ignoreCase: b.when?.ignoreCase !== false },
      then: { reply: String(b.then?.reply || '').trim().slice(0, 60000), reaction: String(b.then?.reaction || '').trim(), stopAfter: b.then?.stopAfter !== false },
      scope: ['all', 'groups', 'private', 'selected'].includes(b.scope) ? b.scope : 'all', chatIds: normalizeRuleChatIds(b.chatIds), cooldownSec: store.toInt(b.cooldownSec, 30, 0, 86400),
      schedule: { enabled: b.schedule?.enabled === true, start: String(b.schedule?.start || '09:00'), end: String(b.schedule?.end || '17:00'), days: Array.isArray(b.schedule?.days) ? [...new Set(b.schedule.days.map(Number).filter(x => Number.isInteger(x) && x >= 0 && x <= 6))] : [0,1,2,3,4,5,6], timezone: String(b.schedule?.timezone || s.settings.timezone || 'Asia/Muscat') },
    };
    if (!r.then.reply && !r.then.reaction) throw new Error('أضف ردًا واحدًا على الأقل.');
    require('./src/interaction').valid(r);
    s.interaction.rules.push(r); store.saveSession(s); res.json({ ok: true, rule: r });
  } catch (e) { replyError(res, e); }
});
app.post('/api/interaction/rules/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), r = s.interaction.rules.find(x => x.id === req.params.id); if (!r) throw new Error('القاعدة غير موجودة.'); r.enabled = !r.enabled; store.saveSession(s); res.json({ ok: true, enabled: r.enabled }); } catch (e) { replyError(res, e); } });
app.delete('/api/interaction/rules/:id', (req, res) => { try { const s = store.loadSession(sid(req)), before = s.interaction.rules.length; s.interaction.rules = s.interaction.rules.filter(x => x.id !== req.params.id); if (before === s.interaction.rules.length) throw new Error('القاعدة غير موجودة.'); store.saveSession(s); res.json({ ok: true }); } catch (e) { replyError(res, e); } });


function normalizeAutomationPayload(id, b, existing = null) {
  const base = existing || {};
  const raw = { ...base, ...(b || {}) };
  const mode = ['weekly', 'monthly', 'yearly', 'once'].includes(String(raw.mode || '')) ? String(raw.mode) : 'weekly';
  const time = String(raw.time || '17:30');
  if (!/^\d{2}:\d{2}$/.test(time) || Number(time.slice(0, 2)) > 23 || Number(time.slice(3)) > 59) throw new Error('وقت الموعد غير صالح.');
  if (mode === 'once' && !validIsoDate(raw.date)) throw new Error('أدخل تاريخًا تقويميًا صالحًا.');
  if (mode !== 'once' && mode !== 'weekly' && !(Number(raw.dayOfMonth) >= 1 && Number(raw.dayOfMonth) <= 31)) throw new Error('يوم الشهر يجب أن يكون بين 1 و31.');
  if (mode === 'yearly' && !(Number(raw.month) >= 1 && Number(raw.month) <= 12)) throw new Error('اختر الشهر السنوي.');
  const s = store.loadSession(id), targets = validTargetKeys(s, Array.isArray(raw.targetKeys) ? raw.targetKeys : []), mediaIds = uniqueStrings(raw.mediaIds);
  const graceMinutes = store.toInt(raw.graceMinutes, 30, 1, 180);
  if (mode === 'once') {
    const plannedAt = zonedDateToUtc(raw.date, time, s.settings.timezone);
    if (!plannedAt) throw new Error('تعذر حساب وقت الموعد حسب المنطقة الزمنية لهذه الجلسة.');
    if (plannedAt.getTime() < Date.now() - graceMinutes * 60000) throw new Error('وقت الموعد في الماضي خارج مهلة التنفيذ. اختر تاريخًا ووقتًا في المستقبل أو ضمن المهلة المحددة.');
  }
  const available = new Set(media.scan(store.getPaths(id).media, s.settings.maxImageSizeMB).files.map(x => x.id));
  const mediaOk = mediaIds.filter(x => available.has(x));
  if (mediaIds.length !== mediaOk.length) throw new Error('بعض ملفات الموعد غير موجودة.');
  const mediaKind = ['auto','image','video','document','voice','sticker','audio'].includes(String(raw.mediaKind || '')) ? String(raw.mediaKind) : 'auto';
  if (mediaKind !== 'auto' && mediaOk.length) { const entries = media.scan(store.getPaths(id).media, s.settings.maxImageSizeMB).files.filter(x => mediaOk.includes(x.id)); for (const entry of entries) { const ext = path.extname(entry.filename).toLowerCase(); if (mediaKind === 'sticker' && ext !== '.webp') throw new Error('نوع الملصق يجب أن يكون WebP.'); if (mediaKind === 'voice' && !['.ogg','.opus','.mp3','.m4a','.wav','.aac'].includes(ext)) throw new Error('الرسالة الصوتية تحتاج ملفًا صوتيًا مدعومًا.'); if (mediaKind === 'video' && !['.mp4','.webm','.mkv','.avi','.mov'].includes(ext)) throw new Error('نوع الفيديو لا يطابق امتداد الملف.'); if (mediaKind === 'image' && !media.IMAGE_EXT.has(ext)) throw new Error('نوع الصورة لا يطابق امتداد الملف.'); if (mediaKind === 'audio' && !['.ogg','.opus','.mp3','.m4a','.wav','.aac','.flac'].includes(ext)) throw new Error('اختر ملفًا صوتيًا.'); } }
  if (!targets.length) throw new Error('اختر مستلمًا أو مجموعة للموعد.');
  const mediaMode = raw.mediaMode === 'cycle' ? 'cycle' : 'selected';
  const text = String(raw.text ?? '');
  const textMode = ['auto', 'caption', 'before', 'after', 'none'].includes(String(raw.textMode || '')) ? String(raw.textMode) : (text.trim() ? 'auto' : 'before');
  const preText = String(raw.preText || ''), postText = String(raw.postText || '');
  const hasCycleImages = mediaMode === 'cycle' && media.scan(store.getPaths(id).media, s.settings.maxImageSizeMB).images.length > 0;
  const mainTextWillSend = text.trim() && textMode !== 'none';
  if (!mediaOk.length && !mainTextWillSend && !preText.trim() && !postText.trim() && !hasCycleImages) throw new Error('أضف نصًا فعّالًا أو ملفًا للموعد، أو فعّل دورة الصور مع وجود صور.');
  return store.normalizeAutomationTask({ ...raw, id: base.id || undefined, name: raw.name, mode, time, date: raw.date, day: store.toInt(raw.day, 5, 0, 6), dayOfMonth: store.toInt(raw.dayOfMonth, 1, 1, 31), month: raw.month === '' ? '' : store.toInt(raw.month, 1, 1, 12), year: raw.year === '' ? '' : store.toInt(raw.year, new Date().getFullYear(), 2020, 2100), targetKeys: targets, mediaIds: mediaMode === 'cycle' ? [] : mediaOk, mediaMode, mediaKind, text, textMode, captionMode: boolValue(raw.captionMode, true), sendAsDocument: boolValue(raw.sendAsDocument, false), sendDelayMs: store.toInt(raw.sendDelayMs, s.settings.sendDelayMs, 0, 60000), preText, postText, graceMinutes });
}
app.get('/api/media-automation/status', (req, res) => { try { res.json({ ok: true, ...mediaAutomation.status(sid(req)) }); } catch (e) { replyError(res, e); } });
app.post('/api/media-automation/react', async (req, res) => {
  try {
    const id = sid(req), raw = String(req.body?.reaction || req.body?.emoji || '').trim();
    const aliases = { like:'👍', 'اعجاب':'👍', 'إعجاب':'👍', love:'❤️', 'حب':'❤️', laugh:'😂', 'ضحك':'😂', fire:'🔥', 'نار':'🔥' };
    const emoji = aliases[raw.toLowerCase()] || raw;
    if (!emoji || emoji.length > 32 || /[\r\n]/.test(emoji)) throw new Error('حدد تفاعلًا صالحًا مثل like أو love أو laugh أو fire أو رمزًا مخصصًا.');
    const result = await whatsapp.reactToMessage(id, req.body?.messageId, emoji);
    res.json({ ok: true, reaction: emoji, ack: result?.__chatBotAck?.status || 'confirmed' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/media-automation/schedule', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), raw = req.body || {};
    const mediaId = String(raw.mediaId || raw.filename || '').trim();
    const found = media.scan(store.getPaths(id).media, s.settings.maxImageSizeMB).files.find(x => x.id === mediaId || x.filename === mediaId);
    if (!found) throw new Error('اختر ملف وسائط موجودًا في مكتبة هذه الجلسة.');
    const kind = ['image','video','document','voice','sticker','audio'].includes(String(raw.mediaKind || '')) ? String(raw.mediaKind) : media.mediaKind(found.filename);
    if (kind === 'sticker' && path.extname(found.filename).toLowerCase() !== '.webp') throw new Error('إرسال الملصق يتطلب ملف WebP.');
    const task = normalizeAutomationPayload(id, { ...raw, name: raw.name || `إرسال ${kind}`, mode: raw.mode || 'once', mediaIds: [found.id], mediaKind: kind, textMode: raw.text ? (raw.textMode || 'before') : 'none', captionMode: false, mediaMode: 'selected' });
    s.automation.tasks.push(task); s.automation.enabled = true; store.saveSession(s);
    res.json({ ok: true, task: { ...task, nextRun: nextRunForItem({ ...task, timezone: s.settings.timezone }) }, message: `تم حفظ جدولة ${kind} داخل التخزين المحلي لهذه الجلسة.` });
  } catch (e) { replyError(res, e); }
});
app.get('/api/automation/tasks', (req, res) => { try { const s = store.loadSession(sid(req)); res.json({ ok: true, tasks: (s.automation.tasks || []).map(t => ({ ...t, nextRun: nextRunForItem({ ...t, timezone: s.settings.timezone }) })) }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/task', (req, res) => { try { const id = sid(req), s = store.loadSession(id), task = normalizeAutomationPayload(id, req.body || {}); s.automation.tasks.push(task); s.automation.enabled = true; store.saveSession(s); res.json({ ok: true, task: { ...task, nextRun: nextRunForItem({ ...task, timezone: s.settings.timezone }) }, message: 'تم حفظ الموعد داخل الجلسة الحالية.' }); } catch (e) { replyError(res, e); } });
app.put('/api/automation/task/:id', (req, res) => { try { const id = sid(req), s = store.loadSession(id), task = s.automation.tasks.find(x => x.id === req.params.id); if (!task) throw new Error('الموعد غير موجود.'); const updated = normalizeAutomationPayload(id, req.body || {}, task); Object.assign(task, updated, { id: task.id, enabled: true, lastRunKey: '', lastFailureKey: '', lastResult: null, lastAttemptAt: '', updatedAt: new Date().toISOString() }); store.saveSession(s); res.json({ ok: true, task: { ...task, nextRun: nextRunForItem({ ...task, timezone: s.settings.timezone }) }, message: 'تم تحديث الموعد وإعادة تفعيله.' }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/task/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), t = s.automation.tasks.find(x => x.id === req.params.id); if (!t) throw new Error('الموعد غير موجود.'); const enabling = t.enabled === false; if (enabling && t.mode === 'once') { const plannedAt = zonedDateToUtc(t.date, t.time, s.settings.timezone); if (!plannedAt || plannedAt.getTime() < Date.now() - Number(t.graceMinutes || 30) * 60000) throw new Error('انتهى وقت هذا الموعد. افتحه للتعديل واختر وقتًا جديدًا قبل تفعيله.'); } t.enabled = enabling; t.updatedAt = new Date().toISOString(); store.saveSession(s); res.json({ ok: true, enabled: t.enabled, message: t.enabled ? 'تم تشغيل الموعد.' : 'تم إيقاف الموعد.' }); } catch (e) { replyError(res, e); } });
app.delete('/api/automation/task/:id', (req, res) => { try { const s = store.loadSession(sid(req)), before = s.automation.tasks.length; s.automation.tasks = s.automation.tasks.filter(x => x.id !== req.params.id); if (before === s.automation.tasks.length) throw new Error('الموعد غير موجود.'); store.saveSession(s); res.json({ ok: true, message: 'تم حذف الموعد.' }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/task/:id/run', async (req, res) => { try { const s = store.loadSession(sid(req)), t = s.automation.tasks.find(x => x.id === req.params.id); if (!t) throw new Error('الموعد غير موجود.'); const result = await delivery.scheduledTaskRun(s.id, t); res.json({ ...result, message: result?.ok === true ? 'تم تنفيذ الموعد بنجاح.' : result?.sent?.length ? 'اكتمل جزء من الموعد فقط؛ راجع نتيجة الإرسال قبل إعادة المحاولة.' : result?.message || result?.failed?.[0]?.error || 'لم ينجح الإرسال؛ راجع سجل الجلسة.' }); } catch (e) { replyError(res, e); } });

app.post('/api/interaction/test', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), body = String(req.body?.message || ''), chatId = String(req.body?.chatId || 'test@c.us').toLowerCase();
    const rule = req.body?.rule || {};
    if (!body && rule.when?.type === 'message' && rule.when?.match !== 'any') throw new Error('اكتب رسالة اختبار.');
    const interaction = require('./src/interaction');
    const syntaxMatch = interaction.match(rule, rule.when?.type === 'reaction' ? 'reaction' : 'message', body, String(req.body?.emoji || ''));
    const activeNow = interaction.ruleActiveNow(rule, s.settings.timezone || 'Asia/Muscat', new Date());
    const matched = syntaxMatch && activeNow;
    res.json({ ok: true, matched, syntaxMatch, activeNow, rendered: interaction.render(rule.then?.reply || '', { message: body, sender: String(req.body?.sender || 'مستخدم'), chat: chatId, type: rule.when?.type || 'message', emoji: String(req.body?.emoji || '') }, s.settings.timezone), message: !syntaxMatch ? 'الرسالة لا تطابق الشرط.' : !activeNow ? 'الشرط مطابق، لكن القاعدة خارج وقت التشغيل المحدد.' : 'الشرط والوقت مطابقان.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/settings', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), b = req.body || {};
    for (const key of ['timezone', 'sendOrder', 'interactionScope', 'interactionQuietStart', 'interactionQuietEnd']) {
      if (b[key] === undefined) continue;
      const value = String(b[key]).trim();
      if (key === 'timezone') { try { new Intl.DateTimeFormat('en-US', { timeZone: value }).format(); } catch { throw new Error('المنطقة الزمنية غير صالحة. استخدم اسمًا مثل Asia/Muscat.'); } }
      if (['interactionQuietStart','interactionQuietEnd'].includes(key) && !/^([01]\d|2[0-3]):[0-5]\d$/.test(value)) throw new Error('وقت فترة الهدوء يجب أن يكون بصيغة HH:MM.');
      s.settings[key] = value;
    }
    if (b.interactionQuietAction !== undefined) {
      const action = String(b.interactionQuietAction);
      if (!['silence','reply','rules'].includes(action)) throw new Error('اختر سلوكًا صالحًا لفترة الهدوء.');
      s.settings.interactionQuietAction = action;
    }
    if (b.interactionQuietReply !== undefined) s.settings.interactionQuietReply = String(b.interactionQuietReply).slice(0,60000);
    if (b.interactionQuietCooldownSec !== undefined) s.settings.interactionQuietCooldownSec = store.toInt(b.interactionQuietCooldownSec, 300, 30, 86400);
    if (b.interactionFallbackCooldownSec !== undefined) s.settings.interactionFallbackCooldownSec = store.toInt(b.interactionFallbackCooldownSec, 300, 30, 86400);
    if (b.interactionFallbackReply !== undefined) s.settings.interactionFallbackReply = String(b.interactionFallbackReply || '').slice(0, 60000);
    if (Array.isArray(b.interactionChatIds)) s.settings.interactionChatIds = normalizeRuleChatIds(b.interactionChatIds);
    if (b.appearance && typeof b.appearance === 'object') {
      const a = b.appearance, isHex = v => /^#[0-9a-f]{6}$/i.test(String(v || ''));
      const current = s.settings.appearance || {};
      s.settings.appearance = {
        ...current,
        accent: isHex(a.accent) ? String(a.accent) : current.accent,
        accent2: isHex(a.accent2) ? String(a.accent2) : current.accent2,
        panelOpacity: Number.isFinite(Number(a.panelOpacity)) ? Math.max(.72, Math.min(.97, Number(a.panelOpacity))) : current.panelOpacity,
        panelBlur: Number.isFinite(Number(a.panelBlur)) ? Math.max(4, Math.min(28, Number(a.panelBlur))) : current.panelBlur,
        radius: Number.isFinite(Number(a.radius)) ? Math.max(12, Math.min(28, Number(a.radius))) : current.radius,
        glow: Number.isFinite(Number(a.glow)) ? Math.max(0, Math.min(1, Number(a.glow))) : current.glow,
      };
    }
    for (const key of ['sendTimeoutMs', 'sendDelayMs', 'retryAttempts', 'retryDelayMs', 'maxImageSizeMB', 'maxActionsPerMinute']) if (b[key] !== undefined) s.settings[key] = store.toInt(b[key], s.settings[key], 1, key === 'retryAttempts' ? 4 : 1000000);
    for (const key of ['interactionEnabled', 'groupAssistantEnabled', 'interactionIgnoreOwn', 'interactionUseRecipientNames', 'interactionQuietEnabled', 'interactionFallbackEnabled', 'autoStartSession', 'automationEnabled', 'commandTriggerEnabled', 'commandTriggerRequired']) if (b[key] !== undefined) s.settings[key] = boolValue(b[key], s.settings[key]);
    if (b.commandTriggerWords !== undefined) {
      const words = (Array.isArray(b.commandTriggerWords) ? b.commandTriggerWords : String(b.commandTriggerWords || '').split(/[،,;|\n]/))
        .map(value => String(value || '').trim().slice(0, 50)).filter(Boolean);
      const unique = [...new Set(words)].slice(0, 12);
      if (!unique.length) throw new Error('اكتب كلمة تشغيل واحدة على الأقل، ويمكنك فصل الكلمات بفاصلة.');
      s.settings.commandTriggerWords = unique;
    }
    if (s.settings.commandTriggerRequired && s.settings.commandTriggerEnabled === false) throw new Error('لا يمكن اشتراط كلمة تشغيل بينما ميزة كلمات التشغيل معطّلة.');
    if (b.interactionEnabled !== undefined) s.interaction.enabled = boolValue(b.interactionEnabled, s.interaction.enabled);
    if (b.automationEnabled !== undefined) s.automation.enabled = boolValue(b.automationEnabled, s.automation.enabled);
    store.saveSession(s); res.json({ ok: true, message: 'تم حفظ الإعدادات.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/settings/background', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), b = req.body || {}, n = backgrounds.normalize(b.mode, b.settings, b.opacity);
    s.settings.backgroundMode = n.mode; s.settings.backgroundSettings = n.settings; s.settings.backgroundOpacity = n.opacity;
    if (b.removeImage && s.settings.backgroundImage) { try { fs.rmSync(media.safePath(store.getPaths(id).backgrounds, s.settings.backgroundImage), { force: true }); } catch {} s.settings.backgroundImage = ''; }
    store.saveSession(s); res.json({ ok: true, message: 'تم تطبيق المظهر فعليًا.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/background', bgUpload.single('file'), (req, res) => {
  try {
    const id = sid(req), file = req.file; if (!file) throw new Error('اختر صورة خلفية.');
    const ext = path.extname(file.originalname || '').toLowerCase(); if (!['.jpg', '.jpeg', '.png', '.webp'].includes(ext)) throw new Error('صيغة الخلفية غير مدعومة.');
    const s = store.loadSession(id), dir = store.getPaths(id).backgrounds, name = `background${ext}`;
    for (const oldExt of ['.jpg','.jpeg','.png','.webp']) { const oldName = `background${oldExt}`; if (oldName !== name) { try { fs.rmSync(media.safePath(dir, oldName), { force: true }); } catch {} } }
    fs.renameSync(file.path, media.safePath(dir, name)); s.settings.backgroundImage = name; store.saveSession(s); res.json({ ok: true, message: 'تم رفع الخلفية وتطبيقها.' });
  } catch (e) { try { if (req.file) fs.rmSync(req.file.path, { force: true }); } catch {} replyError(res, e); }
});
app.get('/background/:filename', (req, res) => { try { const s = store.loadSession(sid(req)), name = decodeURIComponent(req.params.filename); if (s.settings.backgroundImage !== name) return res.status(404).end(); res.sendFile(media.safePath(store.getPaths(s.id).backgrounds, name)); } catch { res.status(404).end(); } });

whatsapp.on('status', (id, runtime) => {
  if (runtime?.ready) ownerAssistant.onReady(id).catch(e => log(id,'WARN',`لم يكتمل تهيئة مركز المساعد: ${safeError(e)}`));
  else if (runtime?.status === 'auth_failure') ownerAssistant.recordIssue(id,{code:'WHATSAPP_AUTH_FAILURE',route:'/api/session/connect',error:'فشل توثيق WhatsApp. افحص الجلسة وأعد الربط بعد التأكد من الحساب.',status:401}).catch(()=>{});
  else if (runtime?.status === 'disconnected') ownerAssistant.recordIssue(id,{code:'WHATSAPP_DISCONNECTED',route:'/api/session/status',error:'انقطع اتصال WhatsApp. ستبقى المشكلة محفوظة محليًا، وسيعاد إرسال التنبيه عند عودة الاتصال إذا كانت الإشعارات مفعّلة.',status:503,steps:['افتح الجلسة وتحقق من حالة الاتصال.', 'أعد الاتصال وامسح QR عند الطلب.', 'انتظر حالة «متصل» وتحقق من سجل الأحداث.']}).catch(()=>{});
});
whatsapp.on('message_create', (id, msg) => {
  const fromMe = msg?.fromMe === true || msg?._data?.id?.fromMe === true || msg?.id?.fromMe === true;
  if (!fromMe) return;
  // Group tools take precedence only for an explicit group command or invite URL; normal messages go to the owner assistant.
  const ownBody = String(msg?.body || msg?.caption || '').trim();
  if (groups.parseGroupRequest(ownBody, groupFromMessage(msg) || '')) {
    groupCommand(id, msg).catch(error => log(id, 'WARN', `تعذر تنفيذ طلب المجموعة الصادر من الحساب: ${safeError(error)}`));
    return;
  }
  Promise.resolve().then(async () => {
    if (await mediaAutomation.handleSelfChatSticker(id, msg).then(x => x.handled)) return { mediaAutomationHandled: true };
    if (await mediaAutomation.handleSelfChatVoice(id, msg).then(x => x.handled)) return { mediaAutomationHandled: true };
    if (await mediaAutomation.handleSelfChatText(id, msg).then(x => x.handled)) return { mediaAutomationHandled: true };
    return ownerAssistant.handleSelfChatMessage(id, msg);
  }).then(outcome => {
    if (outcome?.sent === false) log(id, 'ERROR', `استقبل مركز المساعد الرسالة الذاتية لكن تعذر إرسال الرد: ${safeError(outcome.error || 'سبب غير محدد')}`);
    else if (outcome?.reason === 'unknown-command-no-rule') {
      const s = store.loadSession(id);
      log(id, 'INFO', `رسالة صادرة للمحادثة الذاتية لم تطابق أمرًا أو قاعدة رد تلقائي؛ قواعد=${s.interaction?.rules?.filter(rule => rule.enabled !== false).length || 0}، التفاعل=${s.settings?.interactionEnabled !== false && s.interaction?.enabled !== false ? 'مفعّل' : 'متوقف'}.`);
    }
  }).catch(e => log(id,'ERROR',`تعذر التعامل مع رسالة مركز المساعد: ${safeError(e)}`));
});
whatsapp.on('message', async (id, msg) => {
  try {
    // Incoming messages from the explicitly linked secondary account are accepted only
    // when they come from the primary account owner; otherwise keep normal automations.
    const linked = await ownerAssistant.handleLinkedReplyMessage(id, msg);
    if (linked?.handled) return;
    const body = String(msg?.body || msg?.caption || '').trim();
    const groupRequest = groups.parseGroupRequest(body, groupFromMessage(msg) || '');
    if (groupRequest) {
      await groupCommand(id, msg);
      return;
    }
    const auto = await interaction.onMessage(id, msg);
    if (auto?.reason === 'disabled') log(id, 'WARN', `وصلت رسالة من ${chatIdFromMessage(msg) || 'محادثة مجهولة'} لكن نظام التفاعل أو قواعده متوقف. فعّل «التفاعل» والقواعد المطلوبة.`);
    else if (auto?.reason === 'scope') log(id, 'INFO', `وصلت رسالة من ${chatIdFromMessage(msg) || 'محادثة مجهولة'} لكن نطاق التفاعل أو قائمة المحادثات لا تسمح بالرد عليها.`);
    else if (auto?.handled && auto?.reason === 'rate-limited') log(id, 'WARN', `تم تجاوز حد الردود في الدقيقة لهذه المحادثة: ${chatIdFromMessage(msg) || 'محادثة مجهولة'}.`);
    else if (auto?.handled === false && auto?.reason === 'no-rule-matched') log(id, 'INFO', `وصلت رسالة من ${chatIdFromMessage(msg) || 'محادثة مجهولة'} ولم تطابق قاعدة رد تلقائي فعّالة.`);
    else if (auto?.handled && auto?.action === 'error') log(id, 'ERROR', `فشل رد تلقائي على ${chatIdFromMessage(msg) || 'محادثة مجهولة'}: ${safeError(auto.error || 'تعذر الإرسال')}`);
    /* All ordinary inbound messages go through exactly one response engine. */
    return;
  } catch (error) { log(id, 'ERROR', `تعذر توجيه رسالة WhatsApp: ${safeError(error)}`); }
});
whatsapp.on('reaction', (id, reaction) => interaction.onReaction(id, reaction).catch(e => log(id, 'ERROR', safeError(e))));

async function groupCommand(id, msg) {
  const body = String(msg?.body || msg?.caption || '').trim();
  const currentGid = groupFromMessage(msg) || '';
  const request = groups.parseGroupRequest(body, currentGid);
  // Ordinary group conversations must never mutate the saved group list.
  if (!request) return;
  const s = store.loadSession(id);
  if (!s.settings.groupAssistantEnabled) return;
  try {
    if (request.kind === 'usage') {
      await whatsapp.replyToMessage(id, msg, 'أرسل رابط دعوة المجموعة، أو استخدم: معلومات المجموعة، أو معلومات المجموعة ثم ألصق GID المنتهي بـ @g.us.');
      return;
    }
    if (request.kind === 'invalid-target') {
      await whatsapp.replyToMessage(id, msg, 'لم أتعرف على الهدف. أرسل رابط chat.whatsapp.com أو معرّف مجموعة ينتهي بـ @g.us.');
      return;
    }
    let info = null;
    if (request.kind === 'invite') {
      info = await whatsapp.analyzeGroupInvite(id, request.code);
      if (info?.gid) {
        try { info = await whatsapp.getGroupInfo(id, groups.normalizeGid(info.gid)); }
        catch (error) { if (!info.name && !info.description) throw error; }
      }
    } else {
      info = await whatsapp.getGroupInfo(id, request.gid);
    }
    if (!info?.gid || !groups.isGroupId(info.gid)) throw new Error('واتساب لم يُرجع معرّفًا مؤكدًا لهذه المجموعة. تأكد أن رابط الدعوة صالح وأن الجلسة متصلة.');
    const saved = saveGroup(id, info);
    const report = groups.formatGroupAnalysis(saved);
    await whatsapp.replyToMessage(id, msg, `بيانات المجموعة\n${report}`);
  } catch (error) {
    try { await whatsapp.replyToMessage(id, msg, `لم أستطع جلب بيانات المجموعة: ${safeError(error)}\nتأكد من اتصال الجلسة وصلاحية رابط الدعوة، أو جرّب GID منتهٍ بـ @g.us.`); } catch {}
    log(id, 'WARN', `فشل طلب معلومات المجموعة: ${safeError(error)}`);
  }
}

app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  const message = err?.code === 'LIMIT_FILE_SIZE' ? 'حجم الملف أكبر من الحد المسموح.' : err?.code === 'LIMIT_FILE_COUNT' ? 'عدد الملفات أكبر من الحد المسموح.' : safeError(err);
  res.status(Number(err?.status) || 400).json({ ok: false, error: message });
});
process.on('unhandledRejection', reason => log(null, 'ERROR', `Unhandled Promise Rejection: ${safeError(reason)}`));

async function shutdown(signal) {
  log(null, 'INFO', `إيقاف الخادم (${signal})…`);
  scheduler.stop();
  await whatsapp.stopAll().catch(() => {});
  process.exit(0);
}
process.once('SIGINT', () => shutdown('SIGINT'));
process.once('SIGTERM', () => shutdown('SIGTERM'));

app.listen(PORT, HOST, () => { log(null, 'INFO', `لوحة التحكم تعمل على http://${HOST}:${PORT}`); setTimeout(() => { for (const id of store.listSessionIds()) { const s = store.loadSession(id); if (s.settings.autoStartSession && whatsapp.hasSavedAuth(id) && !whatsapp.listRuntime(id).ready) whatsapp.start(id).catch(err => log(id, 'WARN', `التشغيل التلقائي للجلسة لم يكتمل: ${safeError(err)}`)); } }, 500); });
