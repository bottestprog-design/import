'use strict';
// The full integration assertions live in self-chat-autoreply.js so that the
// default reply remains tested beside ordinary incoming messages and self chat.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const packageJson = require('../package.json');
const source = fs.readFileSync(require.resolve('../src/interaction'), 'utf8');
assert.equal(typeof require('../src/interaction').InteractionEngine, 'function');
assert.match(source, /sendDefaultFallback\(/, 'unknown messages must use the default conversational fallback');
assert.match(source, /interactionFallbackEnabled\s*===\s*false/, 'fallback must be user-configurable');
assert.match(source, /fallback-cooldown/, 'fallback must avoid spamming the same chat');
assert.equal(packageJson.version, '8.8.0', 'source package version must match this repair');
console.log('default-interaction-fallback: ok (fallback pipeline, toggle, cooldown, version)');
