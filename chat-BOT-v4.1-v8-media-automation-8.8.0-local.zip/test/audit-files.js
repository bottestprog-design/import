'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const excluded = new Set(['node_modules', '.git', 'data', 'coverage', '.cache']);
const files = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.isDirectory() && excluded.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.isFile()) files.push(full);
  }
}
walk(root);
let jsCount = 0, textCount = 0, lineCount = 0, failures = 0;
const report = [];
for (const file of files) {
  const rel = path.relative(root, file).replaceAll(path.sep, '/');
  const ext = path.extname(file).toLowerCase();
  if (!['.js', '.cjs', '.mjs', '.json', '.html', '.css', '.svg', '.md', '.py', '.yml', '.yaml', '.txt', '.example'].includes(ext)) continue;
  let content;
  try { content = fs.readFileSync(file, 'utf8'); } catch (error) { failures++; console.error(`READ_FAIL ${rel}: ${error.message}`); continue; }
  textCount++;
  lineCount += content.split(/\r?\n/).length;
  if (content.includes('\u0000')) { failures++; console.error(`NUL_BYTE ${rel}`); }
  if (['.js', '.cjs'].includes(ext) || (ext === '.mjs' && !/\bimport\s/.test(content))) {
    try { new vm.Script(content, { filename: rel }); jsCount++; }
    catch (error) { failures++; console.error(`SYNTAX_FAIL ${rel}:${error.lineNumber || ''}: ${error.message}`); }
  }
  if (ext === '.json') {
    try { JSON.parse(content); } catch (error) { failures++; console.error(`JSON_FAIL ${rel}: ${error.message}`); }
  }
  if (ext === '.svg') {
    if (!/^\s*<svg[\s>]/i.test(content) || !/<\/svg>\s*$/i.test(content)) { failures++; console.error(`SVG_SHAPE_FAIL ${rel}`); }
  }
  // Validate literal relative CommonJS imports without executing application code.
  if (['.js', '.cjs'].includes(ext)) {
    for (const match of content.matchAll(/require\(\s*['"](\.{1,2}\/[^'"]+)['"]\s*\)/g)) {
      const raw = path.resolve(path.dirname(file), match[1]);
      const candidates = [raw, `${raw}.js`, `${raw}.cjs`, `${raw}.json`, path.join(raw, 'index.js'), path.join(raw, 'index.cjs')];
      if (!candidates.some(candidate => fs.existsSync(candidate))) {
        failures++; console.error(`IMPORT_MISSING ${rel} -> ${match[1]}`);
      }
    }
  }
  report.push({ path: rel, bytes: Buffer.byteLength(content), lines: content.split(/\r?\n/).length, ext });
}
const indexPath = path.join(root, 'public', 'index.html');
if (!fs.existsSync(indexPath)) { failures++; console.error('PUBLIC_INDEX_MISSING'); }
else {
  const html = fs.readFileSync(indexPath, 'utf8');
  const ids = [...html.matchAll(/\bid\s*=\s*["']([^"']+)["']/g)].map(m => m[1]);
  const duplicates = ids.filter((id, index) => ids.indexOf(id) !== index);
  if (duplicates.length) { failures++; console.error(`DUPLICATE_STATIC_IDS ${[...new Set(duplicates)].join(',')}`); }
  if (!/lang="ar"\s+dir="rtl"/.test(html)) { failures++; console.error('ARABIC_RTL_DOCUMENT_MISSING'); }
}
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
assert.equal(pkg.version, '8.8.0', 'project package version mismatch');
assert.equal(pkg.engines?.node, '>=20.0.0', 'Node.js runtime requirement mismatch');
if (failures) process.exitCode = 1;
else console.log(`full file audit: ok (${files.length} total files inspected; ${textCount} text/config files; ${jsCount} JavaScript files parsed; ${lineCount.toLocaleString('en-US')} lines; relative imports and data files valid)`);
