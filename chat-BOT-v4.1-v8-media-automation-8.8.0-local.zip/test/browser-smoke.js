'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const publicDir = path.join(root, 'public');
const chrome = ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome'].find(p => fs.existsSync(p));
if (!chrome) { console.log('browser-smoke: SKIP (Chromium is not installed in this environment)'); process.exit(0); }
const session = {
  id: 'smoke', name: 'جلسة اختبار', setupComplete: true,
  ownerAssistant: { messages: [], issues: [], activity: [], pendingNotifications: [], notificationsEnabled: true, notificationMode: 'self' },
  recipients: [], groups: [], media: [], images: [], invalidImages: [], duplicates: [], logs: [],
  stats: {}, cycle: { imageOrder: [], currentIndex: 0 }, automation: { enabled: true, tasks: [], recent: [] },
  settings: { timezone: 'Asia/Muscat', appearance: { accent: '#5ed6c1', accent2: '#8b7cf6', panelOpacity: .9, panelBlur: 8, radius: 16, glow: .3 }, backgroundMode: 'aurora', backgroundImage: '', backgroundOpacity: .2, backgroundSettings: { interactive: false, trail: false, speed: 1, density: 1, intensity: 1, glow: .5, mouseStrength: 0 }, scheduleMode: 'weekly', sendOrder: 'target-first', sendDelayMs: 700, sendTimeoutMs: 30000, retryAttempts: 2, retryDelayMs: 1000, maxImageSizeMB: 20, preText: '', autoStartSession: false, automationEnabled: true, interactionEnabled: true, interactionQuietEnabled: false },
  whatsapp: { ready: false, status: 'disconnected' }, sessions: [{ id: 'smoke', name: 'جلسة اختبار', ready: false, status: 'disconnected' }], activeSessionId: 'smoke', currentImage: null, schedule: { enabled: false }, interaction: { enabled: true, rules: [], recent: [] },
};
const activities = [];
function sendJson(res, value, status = 200) { res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }); res.end(JSON.stringify(value)); }
const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://127.0.0.1');
  if (url.pathname.startsWith('/api/')) {
    if (url.pathname === '/api/health') return sendJson(res, { ok: true, version: '8.8.0' });
    if (url.pathname === '/api/countries') return sendJson(res, { ok: true, countries: { countries: [{ code: 'OM', callingCode: '968' }, { code: 'US', callingCode: '1' }] } });
    if (url.pathname === '/api/state') return sendJson(res, { ok: true, ...session, ownerAssistant: { ...session.ownerAssistant, activity: [...activities] } });
    if (url.pathname === '/api/assistant/activity' && req.method === 'POST') {
      let raw = ''; req.on('data', chunk => raw += chunk); req.on('end', () => {
        let body = {}; try { body = JSON.parse(raw || '{}'); } catch { return sendJson(res, { ok: false, error: 'invalid json' }, 400); }
        const item = { id: `act-${activities.length + 1}`, message: String(body.message || ''), type: body.type || 'info', page: body.page || 'dashboard', at: new Date().toISOString(), source: body.source || 'test' };
        activities.push(item); session.ownerAssistant.activity = [...activities]; return sendJson(res, { ok: true, activity: item });
      }); return;
    }
    return sendJson(res, { ok: false, error: `Unexpected API ${req.method} ${url.pathname}` }, 404);
  }
  let filePath = path.join(publicDir, decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname));
  if (!filePath.startsWith(publicDir)) { res.writeHead(403); res.end(); return; }
  if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) { res.writeHead(404); res.end('not found'); return; }
  const ext = path.extname(filePath).toLowerCase();
  const types = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.svg':'image/svg+xml' };
  res.writeHead(200, { 'content-type': types[ext] || 'application/octet-stream', 'cache-control': 'no-store' });
  if (path.basename(filePath) === 'index.html') {
    let html = fs.readFileSync(filePath, 'utf8');
    html = html.replace('<script src="local-assistant.js"></script>', '<script>window.requestAnimationFrame = () => 0;</script><script src="local-assistant.js"></script>');
    html = html.replace('</body>', `<script>
      window.__robotSmoke = { loaded:false, bubble:false, content:'', closeWorks:false, icon:false, eventSaved:false };
      (function waitForUi(){
        if (document.getElementById('assistantRobotButton') && document.getElementById('sessionSelect')) {
          window.__robotSmoke.loaded = true;
          window.__robotSmoke.icon = !!document.querySelector('link[rel="icon"][href="robot-icon.svg"]');
          var goSend = document.querySelector('[data-go="send"]');
          if (goSend) goSend.click();
          var attempt = function(){
            var send = document.getElementById('sendNowBtn');
            if (!send) return setTimeout(attempt, 35);
            send.click();
            setTimeout(function(){
              var bubble = document.getElementById('assistantSpeech');
              var text = document.getElementById('assistantSpeechText');
              window.__robotSmoke.bubble = !!bubble && !bubble.hidden;
              window.__robotSmoke.content = text ? text.textContent : '';
              var close = document.getElementById('assistantSpeechClose');
              if (close && bubble && !bubble.hidden) { close.click(); window.__robotSmoke.closeWorks = bubble.hidden; }
              setTimeout(function(){ window.__robotSmoke.eventSaved = document.body.innerText.includes('مركز المساعد'); document.documentElement.dataset.robotSmoke = JSON.stringify(window.__robotSmoke); }, 150);
            }, 120);
          };
          attempt();
        } else setTimeout(waitForUi, 25);
      })();
    </script></body>`);
    res.end(html);
  } else fs.createReadStream(filePath).pipe(res);
});
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const address = server.address(); const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-chrome-smoke-'));
  try {
    const args = ['--headless=new','--no-sandbox','--disable-gpu','--disable-dev-shm-usage','--disable-background-networking','--disable-extensions','--no-first-run','--no-default-browser-check','--no-zygote','--single-process',`--user-data-dir=${userDataDir}`,'--virtual-time-budget=3500','--dump-dom',`http://127.0.0.1:${address.port}/`];
    const result = spawnSync(chrome, args, { encoding:'utf8', timeout:7500, maxBuffer:8 * 1024 * 1024 });
    if (result.error?.code === 'ETIMEDOUT') { console.log('browser-smoke: SKIP (headless Chromium did not exit reliably in this sandbox; UI source and server contracts are covered by automated tests)'); return; }
    if (result.error) throw result.error;
    if (result.status !== 0) throw new Error(`Chromium exited ${result.status}: ${(result.stderr || '').slice(-1200)}`);
    const markup = result.stdout || '';
    const match = markup.match(/data-robot-smoke="([^"]+)"/);
    assert.ok(match, `Browser did not finish the smoke flow. stderr: ${(result.stderr || '').slice(-600)} DOM tail: ${markup.slice(-1200)}`);
    const resultData = JSON.parse(match[1].replaceAll('&quot;', '"').replaceAll('&amp;', '&'));
    assert.equal(resultData.loaded, true, 'app UI did not render');
    assert.equal(resultData.icon, true, 'robot icon must be referenced by the page');
    assert.equal(resultData.bubble, true, 'a missing-recipient failure should appear in the robot speech bubble');
    assert.match(resultData.content, /حدد شخصًا أو مجموعة/, 'robot speech bubble should show the actual action error');
    assert.equal(resultData.closeWorks, true, 'speech bubble close button should hide the notice');
    assert.ok(activities.some(item => item.type === 'error' && item.message.includes('حدد شخصًا')), 'UI notification should be saved into the independent assistant activity feed');
    assert.match(markup, /id="ownerActivityList"/, 'assistant activity list should be available in the private assistant center');
    console.log('browser-smoke: ok (Chromium rendered the app, robot error bubble, close control, icon, and saved activity log)');
  } finally {
    await new Promise(resolve => server.close(resolve));
    try { fs.rmSync(userDataDir, { recursive:true, force:true }); } catch {}
  }
})().catch(error => { console.error(error); process.exitCode = 1; server.close(); });
