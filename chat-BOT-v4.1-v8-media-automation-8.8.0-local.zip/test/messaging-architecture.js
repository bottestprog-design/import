'use strict';
const assert = require('node:assert/strict');
const { normalizeArabic, matchDictionary, validateEntry } = require('../src/messaging/dictionary');
const { resolveIntent, choiceFromReply } = require('../src/messaging/intent-resolver');
const { CommandRegistry } = require('../src/messaging/command-registry');
const { ConversationManager } = require('../src/messaging/conversation-manager');
const store = require('../src/store');

assert.equal(normalizeArabic('أَرْسِلْ رِسَالَةً'), 'ارسل رسالة');
assert.equal(matchDictionary('ارسل رسالة')[0].intent, 'send_message');
assert.equal(matchDictionary('ابعت رسالة')[0].intent, 'send_message');
assert.equal(resolveIntent('بعت').status, 'ambiguous');
assert.deepEqual(resolveIntent('بعت').candidates.map(x => x.intent), ['send_message','schedule_message','forward_message']);
assert.equal(resolveIntent('ارسل رسالة لأحمد: أهلا').status, 'resolved');
assert.equal(choiceFromReply('2', resolveIntent('بعت').candidates).intent, 'schedule_message');
const custom = validateEntry({ intent:'send_message', phrases:['وصّل','بعتلي'], weight:.9 });
assert.equal(matchDictionary('وصّل', [custom])[0].intent, 'send_message');
assert.throws(() => validateEntry({ intent:'bad intent', phrase:'test' }));

const registry = new CommandRegistry();
registry.register({ key:'send_message', permission:'owner', aliases:['send'], validate:p=>p.to?{ok:true,value:p}:{ok:false,message:'missing recipient'}, execute:async (_c,p)=>({sentTo:p.to}) });
async function run() {
assert.equal((await registry.execute('send_message',{permissions:['owner']},{to:'contact'})).status,'success');
assert.equal((await registry.execute('send_message',{permissions:[]},{to:'contact'})).errorCode,'PERMISSION_DENIED');
assert.equal((await registry.execute('send_message',{permissions:['owner']},{})).errorCode,'VALIDATION_FAILED');
assert.throws(() => registry.register({key:'send_message', execute:async()=>{}}));

const fakeStore = { state:{id:'main',messagingConversation:null}, loadSession(){ return structuredClone(this.state); }, saveSession(s){ this.state=structuredClone(s); return this.state; } };
const conversations = new ConversationManager({ store:fakeStore, ttlMs:60_000 });
conversations.save('main',{type:'intent-disambiguation',candidates:resolveIntent('بعت').candidates});
assert.equal(conversations.consumeChoice('main','2').choice.intent,'schedule_message');
assert.equal(conversations.load('main'),null);
fakeStore.state.messagingConversation={type:'intent-disambiguation',candidates:resolveIntent('بعت').candidates,expiresAt:'2000-01-01T00:00:00.000Z'};
assert.equal(conversations.consumeChoice('main','1').expired,true);
assert.ok(store.DEFAULT_SETTINGS.interactionEnabled !== undefined);
console.log('Messaging architecture tests passed: normalization, synonyms, ambiguity, custom dictionary, command permissions, conversation choices and expiry.');
}
run().catch(error => { console.error(error); process.exitCode=1; });
