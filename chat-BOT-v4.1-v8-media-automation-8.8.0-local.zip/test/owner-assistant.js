'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { OwnerAssistant, issueGuide, isFromMeMessage, messageChatIds } = require('../src/owner-assistant');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-owner-assistant-'));
const session = { id:'unit', name:'Unit session', settings:{maxImageSizeMB:20}, recipients:[], groups:[], ownerAssistant:{ownerPhone:'',ownerPhoneConfirmed:false,notificationsEnabled:true,notificationMode:'self',welcomeCreatedAt:'',welcomeSentAt:'',welcomeAttemptedAt:'',messages:[],issues:[],activity:[],pendingNotifications:[]}, stats:{}, logs:[] };
const sessions = new Map([['unit', session]]);
const store = {
  loadSession:id=>{const found=sessions.get(id);if(!found)throw new Error('session missing');return found;},
  saveSession:s=>{sessions.set(s.id,s);return s;},
  getPaths:id=>({id,dir:path.join(temp,id),media:path.join(temp,id,'media'),auth:path.join(temp,id,'auth'),backgrounds:path.join(temp,id,'backgrounds'),json:path.join(temp,id,'session.json')}),
  listSessionIds:()=>[...sessions.keys()],
};
let ready = false, failWelcomeOnce = true; const outgoing=[];
const whatsapp = {
  listRuntime:(id='unit')=>({ready,status:ready?'ready':'disconnected',info:{wid:{user:id==='secondary'?'96891112222':'96890000000',_serialized:(id==='secondary'?'96891112222':'96890000000')+'@c.us'}}}),
  selfChatId:(id='unit')=> (id==='secondary'?'96891112222':'96890000000')+'@c.us',
  resolveChatId:async(_id,target)=>`${target.digits}@c.us`,
  sendText:async(sessionId,chatId,text)=>{outgoing.push({text,opts:{sessionId,chatId,mode:'second-account'}});return {__chatBotAck:{status:'confirmed'}};},
  sendOwnerNotification:async (_id,text,opts)=>{if(!ready)throw new Error('WA not ready');if(failWelcomeOnce && text.startsWith('🤖 chat BOT — تم ربط WhatsApp')){failWelcomeOnce=false;throw new Error('self-chat not yet available');}outgoing.push({text,opts});return {ok:true,ack:'created'};},
};
const owner = new OwnerAssistant({store,whatsapp,log:()=>{}});
(async()=>{
  fs.mkdirSync(store.getPaths('unit').media,{recursive:true});
  const issue = await owner.recordIssue('unit',{code:'SEND_FAIL',route:'/api/send',error:'الرقم غير مسجل على WhatsApp.',status:422});
  assert.ok(issue.issue.id && issue.issue.steps.length >= 3,'issue must have detailed actionable steps');
  assert.equal(session.ownerAssistant.pendingNotifications.length,1,'offline issue must be queued for later WhatsApp notification');
  const dup = await owner.recordIssue('unit',{code:'SEND_FAIL',route:'/api/send',error:'الرقم غير مسجل على WhatsApp.',status:422});
  assert.equal(dup.deduplicated,true,'repeated identical problem should be deduplicated');
  assert.equal(session.ownerAssistant.issues.length,1);
  ready = true;
  await owner.onReady('unit');
  assert.ok(session.ownerAssistant.welcomeCreatedAt,'welcome thread must be created on first successful connection');
  assert.equal(session.ownerAssistant.welcomeSentAt,'','failed first welcome delivery must remain retryable');
  await owner.onReady('unit');
  assert.ok(session.ownerAssistant.welcomeSentAt,'undelivered welcome must retry after a subsequent successful connection');
  assert.ok(outgoing.some(x=>x.text.startsWith('🤖 chat BOT — تم ربط WhatsApp بنجاح')),'welcome should be delivered after retry');
  assert.equal(session.ownerAssistant.welcomeVersion,'8.8.0','welcome command list should be versioned');
  const oldWelcomeCount=outgoing.filter(x=>x.text.startsWith('🤖 chat BOT — تم ربط WhatsApp بنجاح')).length;
  session.ownerAssistant.welcomeVersion='8.4.4'; session.ownerAssistant.welcomeSentVersion='8.4.4'; session.ownerAssistant.welcomeSentAt='2026-10-01T00:00:00.000Z';
  await owner.onReady('unit');
  assert.equal(outgoing.filter(x=>x.text.startsWith('🤖 chat BOT — تم ربط WhatsApp بنجاح')).length,oldWelcomeCount+1,'after an app upgrade the newest command guide must be sent');
  assert.equal(session.ownerAssistant.welcomeSentVersion,'8.8.0');
  assert.equal(session.ownerAssistant.pendingNotifications.length,0,'pending issue should be sent after reconnection');
  const staleConnectionIssue={id:'old-connection-issue',code:'DIAGNOSTIC_WHATSAPP',title:'اتصال قديم',details:'old connect error',status:'open'};
  const staleSelfChatIssue={id:'old-self-chat-issue',code:'DIAGNOSTIC_SELF-CHAT',title:'معرف حساب قديم',details:'no WhatsApp id',status:'open'};
  session.ownerAssistant.issues.push(staleConnectionIssue,staleSelfChatIssue);
  session.ownerAssistant.pendingNotifications.push(staleConnectionIssue.id,staleSelfChatIssue.id);
  assert.equal(owner.resolveRecoveredConnectionIssues('unit'),2,'a ready account with a resolved self ID should clear stale connection/self-chat diagnostics');
  assert.equal(staleConnectionIssue.status,'resolved'); assert.equal(staleSelfChatIssue.status,'resolved');
  assert.ok(!session.ownerAssistant.pendingNotifications.includes(staleConnectionIssue.id));
  assert.ok(!session.ownerAssistant.pendingNotifications.includes(staleSelfChatIssue.id));
  assert.ok(outgoing.some(x=>x.text.startsWith('⚠️ chat BOT |')),'issue should be delivered after reconnection');
  const diag=owner.diagnostics('unit'); assert.equal(diag.sessionId,'unit'); assert.ok(Array.isArray(diag.checks));
  const activityCountBefore=session.ownerAssistant.activity.length; const activity=owner.recordActivity('unit',{message:'تم اختبار رسالة الروبوت',type:'success',page:'send'}); assert.equal(activity.type,'success'); assert.equal(session.ownerAssistant.activity.length,activityCountBefore+1,'activity feed must be persisted independently from the owner chat'); assert.equal(session.ownerAssistant.messages.length > 0,true,'chat conversation remains separate from activity feed');
  const duplicateActivity=owner.recordActivity('unit',{message:'تم اختبار رسالة الروبوت',type:'success',page:'send'}); assert.equal(duplicateActivity.id,activity.id,'activity feed deduplicates rapid duplicate notices'); assert.equal(session.ownerAssistant.activity.length,activityCountBefore+1);
  const otherPageActivity=owner.recordActivity('unit',{message:'تم اختبار رسالة الروبوت',type:'success',page:'groups'}); assert.notEqual(otherPageActivity.id,activity.id,'identical notices from different pages remain separately navigable');
  for (let i=0;i<305;i++) owner.recordActivity('unit',{message:`bulk event ${i}`,type:i%2?'info':'warning',page:'dashboard'});
  assert.equal(session.ownerAssistant.activity.length,300,'activity history is bounded to prevent unlimited session growth');
  assert.ok(session.ownerAssistant.activity.some(x=>x.message==='bulk event 304'),'activity log retains the latest event after trimming');
  const resolved=await owner.resolveIssue('unit',issue.issue.id); assert.equal(resolved.status,'resolved');
  assert.equal(issueGuide({route:'/api/groups/discover',error:'GID غير صالح'}).page,'groups');
  assert.equal(issueGuide({route:'/api/session/connect',error:'فشل التوثيق'}).page,'session');
  const rawEventShape={body:'مساعدة',_data:{id:{fromMe:true,remote:{_serialized:'96890000000@c.us'}}},id:{remote:{_serialized:'96890000000@c.us'}},to:'96890000000@c.us'};
  assert.equal(isFromMeMessage(rawEventShape),true,'self-chat detection must handle raw WhatsApp message ID fields if the wrapper property is absent');
  assert.deepEqual(messageChatIds(rawEventShape),['96890000000@c.us'],'self-chat detection must resolve the outgoing destination from raw event aliases');
  const selfMsg={fromMe:true,body:'مساعدة',id:{remote:{_serialized:'96890000000@c.us'}}};
  const handled=await owner.handleSelfChatMessage('unit',selfMsg); assert.equal(handled.handled,true); assert.ok(outgoing.some(x=>x.text.includes('chat BOT') && (x.text.includes('أوامر محادثة مرنة') || x.text.includes('مساعدة الأشخاص'))));
  const unrelatedOwnMessage={fromMe:true,body:'رسالة اختبار لا تخص محادثة النفس',id:{remote:{_serialized:'96891112222@c.us'}},getChat:()=>new Promise(()=>{})};
  const unrelatedSelfResult=await owner.handleSelfChatMessage('unit',unrelatedOwnMessage);
  assert.equal(unrelatedSelfResult.handled,false,'an outgoing message outside the self-chat must be safely ignored');
  assert.equal(unrelatedSelfResult.reason,'not-self-chat','the self-chat guard must return a controlled outcome when chat IDs differ');
  const phonePath=require.resolve('../src/phones');
  require.cache[phonePath]={id:phonePath,filename:phonePath,loaded:true,exports:{countries(){return ['OM','SA','EG','AE','KW','QA','BH','JO','IQ','YE','LB','SY','PS','MA','DZ','TN','LY','SD','IN','PK','TR','GB','US','CA','DE','FR','BD','PH'].map(code=>({code}));},parse(input,country='OM'){let raw=String(input).replace(/[^\d+]/g,'');if(raw.startsWith('00'))raw='+'+raw.slice(2);const digits=raw.replace(/\D/g,'');if(digits.length<8)throw new Error('رقم غير صالح');let detected=String(country||'OM').toUpperCase();if(raw.startsWith('+')){if(digits.startsWith('968'))detected='OM';else if(digits.startsWith('966'))detected='SA';}return {digits,e164:'+'+digits,international:'+'+digits,formatted:'+'+digits,country:detected,callingCode:detected==='SA'?'966':'968',national:digits.slice(-8)}}}};
  const addNumberMsg={fromMe:true,body:'أضف الرقم +96891234568 باسم اختبار الأمر',id:{remote:{_serialized:'96890000000@c.us'}}};
  const added=await owner.handleSelfChatMessage('unit',addNumberMsg); assert.equal(added.handled,true); assert.equal(session.recipients.length,1,'a self-chat add-number command must change the saved recipient list'); assert.equal(session.recipients[0].name,'اختبار الأمر'); assert.ok(outgoing.some(x=>x.text.includes('تمت إضافة الرقم فعليًا')),'self-chat response should report the verified mutation');
  // Drive the full multi-turn wizard through the same owner WhatsApp self-chat handler used by message_create.
  const selfChat = body => ({fromMe:true,body,id:{remote:{_serialized:'96890000000@c.us'}}});
  const wizardStart = await owner.handleSelfChatMessage('unit',selfChat('عايز اضيف رقم مستخدم جديد'));
  assert.equal(wizardStart.handled,true); assert.match(wizardStart.response,/الخطوة 1\/3/); assert.equal(session.ownerAssistant.conversation.step,'name');
  const wizardName = await owner.handleSelfChatMessage('unit',selfChat('سالم'));
  assert.match(wizardName.response,/الخطوة 2\/3/); assert.equal(session.ownerAssistant.conversation.data.name,'سالم');
  const wizardBadCountry = await owner.handleSelfChatMessage('unit',selfChat('دولة خيالية'));
  assert.match(wizardBadCountry.response,/لم أتعرف على الدولة/); assert.equal(session.ownerAssistant.conversation.step,'country'); assert.equal(session.recipients.length,1,'invalid country must not persist a recipient');
  const wizardCountry = await owner.handleSelfChatMessage('unit',selfChat('عمان'));
  assert.match(wizardCountry.response,/الخطوة 3\/3/); assert.equal(session.ownerAssistant.conversation.step,'phone');
  const wizardBadPhone = await owner.handleSelfChatMessage('unit',selfChat('123'));
  assert.match(wizardBadPhone.response,/رقم الهاتف غير صالح/); assert.equal(session.ownerAssistant.conversation.step,'phone'); assert.equal(session.recipients.length,1,'invalid phone must not persist a recipient');
  const wizardSuccess = await owner.handleSelfChatMessage('unit',selfChat('+96891234569'));
  assert.equal(wizardSuccess.handled,true); assert.match(wizardSuccess.response,/تم التحقق من حفظ جهة الاتصال/);
  assert.equal(session.recipients.length,2,'a valid reply sent as the next WhatsApp message should create exactly one recipient');
  assert.equal(session.recipients[1].name,'سالم'); assert.equal(session.ownerAssistant.conversation,null,'wizard state must clear only after a confirmed save');
  assert.ok(outgoing.some(x=>x.text.includes('اكتب اسمًا واضحًا')===false && x.text.includes('الخطوة 2/3')),'WhatsApp replies should explain each expected field');
  let interactionRuns=0; owner.interaction={onMessage:async()=>{interactionRuns++;}}; session.settings.interactionIgnoreOwn=false; session.settings.interactionEnabled=true; session.interaction={enabled:true,rules:[],recent:[]};
  const selfTestMsg={fromMe:true,body:'اختبار قاعدة تجريبية',id:{remote:{_serialized:'96890000000@c.us'}}}; await owner.handleSelfChatMessage('unit',selfTestMsg); assert.equal(interactionRuns,1,'opt-in self-chat interaction test should invoke the real interaction engine hook');
  // Link a second, distinct WhatsApp account only after explicit confirmation, then test both directions.
  const secondary = JSON.parse(JSON.stringify(session)); secondary.id='secondary'; secondary.name='الحساب الثاني';
  secondary.ownerAssistant = { ownerPhone:'',ownerPhoneConfirmed:false,notificationsEnabled:true,notificationMode:'self',welcomeCreatedAt:'',welcomeSentAt:'',welcomeAttemptedAt:'',conversation:null,replySessionId:'',replySessionEnabled:false,replySessionConfirmedAt:'',linkedProcessedMessageIds:[],messages:[],issues:[],activity:[],pendingNotifications:[] };
  sessions.set('secondary', secondary);
  let configured = await owner.executeCommand('unit','فعّل حساب الرد الثاني | الجلسة=secondary | تأكيد=نعم');
  assert.equal(configured.ok,true); assert.equal(session.ownerAssistant.replySessionEnabled,true); assert.equal(session.ownerAssistant.replySessionId,'secondary');
  const beforeSecondaryReply=outgoing.length;
  const viaSecond=await owner.handleSelfChatMessage('unit',{fromMe:true,body:'اعرض الأشخاص',id:{remote:{_serialized:'96890000000@c.us'}}});
  assert.equal(viaSecond.sent,true); assert.equal(viaSecond.deliveryMode,'second-account'); assert.ok(outgoing.length>beforeSecondaryReply);
  assert.equal(outgoing[outgoing.length-1].opts.sessionId,'secondary','responses must use the selected connected secondary session');
  assert.equal(outgoing[outgoing.length-1].opts.chatId,'96890000000@c.us','secondary account must reply only to the verified primary account');
  const linkedMessage={fromMe:false,from:'96890000000@c.us',body:'اعرض الأشخاص',id:{_serialized:'linked-inbound-1',remote:{_serialized:'96890000000@c.us'}}};
  const linked=await owner.handleLinkedReplyMessage('secondary',linkedMessage); assert.equal(linked.handled,true); assert.equal(linked.sent,true,'a reply typed into the secondary account conversation should execute and send an answer');
  const outBeforeDuplicate=outgoing.length; const duplicate=await owner.handleLinkedReplyMessage('secondary',linkedMessage); assert.equal(duplicate.handled,true); assert.equal(duplicate.duplicate,true); assert.equal(outgoing.length,outBeforeDuplicate,'duplicate WhatsApp event must not execute/send twice');
  const stranger=await owner.handleLinkedReplyMessage('secondary',{fromMe:false,from:'96899999999@c.us',body:'اعرض الأشخاص',id:{_serialized:'untrusted-inbound-1'}}); assert.equal(stranger.handled,false,'messages from numbers other than the primary account owner must not enter the command engine');
  configured=await owner.executeCommand('unit','أوقف حساب الرد الثاني'); assert.equal(configured.ok,true); assert.equal(session.ownerAssistant.replySessionEnabled,false,'disable command must restore self-chat reply mode');
  console.log('owner-assistant: ok (welcome delivery, WhatsApp self-chat command execution, conversational multi-step add, verified second-account sending, inbound owner allow-list and duplicate suppression)');
})().catch(error=>{console.error(error);process.exitCode=1;}).finally(()=>{try{fs.rmSync(temp,{recursive:true,force:true});}catch{}});
