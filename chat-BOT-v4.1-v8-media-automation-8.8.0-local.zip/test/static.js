"use strict";
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '..');
const js = ['server.js','scripts/ensure-browser.js','public/local-assistant.js','public/app.js','src/compat.js','src/whatsapp.js','src/delivery.js','src/interaction.js','src/scheduler.js','src/store.js','src/phones.js','src/groups.js','src/media.js','src/backgrounds.js','src/serverlib.js','src/owner-assistant.js','test/send-media.js','test/contact-management.js','test/whatsapp-identifiers.js','test/command-aliases.js','test/interaction-recipient-name.js','test/whatsapp-profile-lookup.js','test/scheduler-reliability.js','test/scheduled-delivery.js','test/scheduled-partial-progress.js'];
let failed = 0;
for (const f of js) {
  try { new vm.Script(fs.readFileSync(path.join(root,f),'utf8'), {filename:f}); console.log('OK JS', f); }
  catch (e) { failed++; console.error('BAD JS', f, e.message); }
}
const app = fs.readFileSync(path.join(root,'public/app.js'),'utf8');
for (const token of ['function pageSend(', 'function pagePeople(', 'function pageGroups(', 'function filterGroupMembers(', 'function renderGroupMembers(', 'function pageInteraction(', 'function pageSession(', 'function pageAppearance(', 'function pageOperation(', 'function pageAssistant(', 'function pageOwnerCenter(', 'function bindOwnerCenter(', 'function bindLocalAssistant(', 'function runAssistantAction(', 'function loadCountries(', 'function setupBackground(', 'function rangeControl(', 'function robotSvgMarkup(', 'function logAssistantActivity(', 'function activityMarkup(']) {
  if (!app.includes(token)) { failed++; console.error('MISSING', token); }
}
for (const banned of ['/api/session/select','/api/session/create','/api/session/update','/api/session/delete','/api/media/upload','/api/schedule/delete','/api/interaction/rules/delete']) {
  if (app.includes(banned)) { failed++; console.error('STALE_ENDPOINT', banned); }
}
if ((app.match(/function loadCountries\(/g)||[]).length !== 1) { failed++; console.error('DUPLICATE loadCountries'); }
const whatsapp = fs.readFileSync(path.join(root,'src/whatsapp.js'),'utf8');
if (!whatsapp.includes('function ackIsDelivered(ack) { return Number(ack) >= 2; }')) { failed++; console.error('ACK_SEMANTICS_NOT_SAFE'); }
if (!whatsapp.includes("require('./compat').patch()") || !whatsapp.includes('تعذر إصلاح مكتبة WhatsApp لإرسال المرفقات')) { failed++; console.error('MEDIA_PATCH_NOT_SHARED_OR_FAIL_CLOSED'); }
if (!whatsapp.includes("client.on('error'") || !whatsapp.includes('recoverRuntimeNavigation') || !whatsapp.includes('matchesOutgoingConfirmation')) { failed++; console.error('WHATSAPP_RUNTIME_RECOVERY_OR_SEND_CONFIRMATION_MISSING'); }
const compatSource = fs.readFileSync(path.join(root,'src/compat.js'),'utf8');
if (!compatSource.includes('delete message.__x_id;') || !compatSource.includes('MediaData.__x_id')) { failed++; console.error('MEDIA_ID_COLLISION_FIX_MISSING'); }
const server = fs.readFileSync(path.join(root,'server.js'),'utf8');
for (const token of ['/api/send','/api/recipient','/api/recipient/from-whatsapp','/api/recipients/sync-preview','/api/recipients/sync-apply','/api/whatsapp/contacts','/api/recipient/:id/profile-status','/api/recipient/:id/auto-reply','/api/recipients/bulk-delete','/api/groups/connect','/api/groups/discover','/api/groups/bulk','/api/automation/task','/api/interaction/rules','/api/interaction/test','/api/settings/background','/api/countries','/api/media/:filename/preview','const maxFileBytes = Number(maxFileSizeMB) * 1024 * 1024']) if (!server.includes(token)) { failed++; console.error('MISSING SERVER ROUTE', token); }
for (const token of ['id="mediaDropZone"','id="sendTextPlacement"','id="captionMode"','id="groupMemberSearch"','id="scanContactSync"','id="loadWhatsappContacts"','data-edit-person','data-save-person-auto','data-select-person','deleteSelectedPeople','contactSyncAutoScannedSession','id="interactionUseRecipientNames"','id="opCommandTriggerWords"','id="saveCommandTriggers"']) if (!app.includes(token)) { failed++; console.error('MISSING UI TOKEN', token); }
const html = fs.readFileSync(path.join(root,'public/index.html'),'utf8');
for (const token of ['id="app"','id="bgCanvas"','id="bgImageLayer"','src="local-assistant.js"','robot-icon.svg']) if (!html.includes(token)) { failed++; console.error('MISSING HTML', token); }
const pkg = JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8')); if (pkg.version !== '8.8.0') { failed++; console.error('BAD VERSION'); } if (pkg.dependencies?.puppeteer !== '24.38.0') { failed++; console.error('WHATSAPP-WEB.JS COMPATIBLE PUPPETEER PIN MISSING'); } if (pkg.overrides?.['whatsapp-web.js']?.puppeteer) { failed++; console.error('UNTESTED WHATSAPP-WEB.JS PUPPETEER OVERRIDE SHOULD NOT BE PRESENT'); } if (pkg.engines?.node !== '>=20.0.0') { failed++; console.error('NODE ENGINE REQUIREMENT MISSING'); }
const whatsappSource = fs.readFileSync(path.join(root,'src/whatsapp.js'),'utf8'); if (!/async replyToMessage\([\s\S]*?return this\.sendText\(id, chatId, content\);/.test(whatsappSource) || /message\?\.reply\(content\)/.test(whatsappSource) || !whatsappSource.includes("if (chatId.endsWith('@lid'))")) { failed++; console.error('AUTO-REPLY MUST USE DIRECT, CONFIRMABLE CHAT SEND'); } if (!whatsappSource.includes('msg?._data?.id?.fromMe === true')) { failed++; console.error('RAW WHATSAPP MESSAGE_CREATE ROUTING FALLBACK MISSING'); } if (!whatsappSource.includes('avatarStatus') || !whatsappSource.includes('getProfilePicUrl(candidate)')) { failed++; console.error('WHATSAPP PROFILE PICTURE ALIAS RETRY MISSING'); }


const schedulerSource = fs.readFileSync(path.join(root,'src/scheduler.js'),'utf8');
if (!schedulerSource.includes('DEFAULT_GRACE_MINUTES = 30') || !schedulerSource.includes('taskDue.key') || !schedulerSource.includes('partialCount') || !schedulerSource.includes('unsafePartialCount')) { failed++; console.error('SCHEDULE_CATCH_UP_OR_PARTIAL_GUARD_MISSING'); }
const deliverySource = fs.readFileSync(path.join(root,'src/delivery.js'),'utf8');
if (!deliverySource.includes('textMode,') || !deliverySource.includes('sendAsDocument: task.sendAsDocument === true') || !deliverySource.includes("task.mediaMode === 'cycle' ? []") || !deliverySource.includes('chatBotProgress') || !deliverySource.includes('partialDelivery')) { failed++; console.error('SCHEDULE_DELIVERY_OPTIONS_NOT_PERSISTED'); }
if (!app.includes('id=\"scheduleTextPlacement\"') || !app.includes('id=\"schedulePreText\"') || !app.includes('id=\"scheduleGraceMinutes\"')) { failed++; console.error('SCHEDULE_EDITOR_FIELDS_MISSING'); }
const commandEngineSource = fs.readFileSync(path.join(root,'src/local-command-engine.js'),'utf8');
for (const token of ['handleConversationInput', 'resolveCountry(input)', 'replySessionCommand', 'conversation-invalid-country', 'conversation-invalid-phone', 'commandTriggerMatch', 'prepareCommandInput', 'فعّل استخدام أسماء المشروع']) if (!commandEngineSource.includes(token)) { failed++; console.error('LOCAL CONVERSATION FEATURE MISSING', token); }
const ownerHandlerSource = fs.readFileSync(path.join(root,'src/owner-assistant.js'),'utf8');
if (!ownerHandlerSource.includes('handleLinkedReplyMessage') || !ownerHandlerSource.includes('handleSelfChatMessage') || !ownerHandlerSource.includes('linkedProcessedMessageIds') || ownerHandlerSource.includes('reason: selfId ?')) { failed++; console.error('WHATSAPP OWNER MESSAGE HANDLER OR DEDUPLICATION MISSING'); }
const ownerSource = fs.readFileSync(path.join(root,'src/owner-assistant.js'),'utf8');
if (!ownerSource.includes('pendingNotifications') || !ownerSource.includes('steps:') || !ownerSource.includes('recordActivity') || !ownerSource.includes('feed.activity')) { failed++; console.error('OWNER_ASSISTANT_ACTIONABLE_NOTIFICATIONS_MISSING'); }
if (!app.includes("['owner-center', '◉', 'مركز المساعد']")) { failed++; console.error('OWNER_CENTER_NAV_MISSING'); }
if (!app.includes("requestUrl.searchParams.set('sessionId', currentSessionId)")) { failed++; console.error('REQUEST_SESSION_CONTEXT_MISSING'); }
if (!server.includes('لن يعاد إنشاء الجلسة المحذوفة تلقائيًا')) { failed++; console.error('DELETED_SESSION_GUARD_MISSING'); }
if (!server.includes('scheduler: scheduler.status(id)')) { failed++; console.error('SCHEDULER_HEALTH_NOT_EXPOSED_PER_SESSION'); } if (!app.includes('function schedulerHealthMarkup(') || !app.includes('حالة الإرسال المجدول')) { failed++; console.error('SCHEDULER_HEALTH_UI_MISSING'); } if (!server.includes('لم تطابق قاعدة رد تلقائي فعّالة')) { failed++; console.error('INCOMING_INTERACTION_DIAGNOSTICS_MISSING'); }
const storeSource = fs.readFileSync(path.join(root,'src/store.js'),'utf8');
if (!storeSource.includes('الجلسة غير موجودة أو حُذفت') || !storeSource.includes('activeSessionId')) { failed++; console.error('SESSION_DELETE_GUARD_MISSING'); }
if (!fs.readFileSync(path.join(root,'src/whatsapp.js'),'utf8').includes('e.starting === startPromise')) { failed++; console.error('WHATSAPP_STALE_START_RACE_GUARD_MISSING'); }
for (const token of ["app.get('/api/assistant/center'", "app.post('/api/assistant/activity'", "app.post('/api/assistant/test-notification'", "app.post('/api/assistant/issues/:id/resolve'"]) if (!server.includes(token)) { failed++; console.error('OWNER_ASSISTANT_ROUTE_MISSING', token); }

const robotUi = fs.readFileSync(path.join(root,'public/app.js'),'utf8');
for (const token of ['id="assistantSpeech"','id="assistantSpeechClose"','id="assistantSpeechOpen"','id="assistantRobotButton"','id="ownerActivityList"','expiresAt: Date.now() + duration',"api('/api/assistant/activity'"]) if (!robotUi.includes(token)) { failed++; console.error('ROBOT ACTIVITY FEATURE MISSING', token); }
if (!fs.existsSync(path.join(root,'public/robot-icon.svg'))) { failed++; console.error('ROBOT ICON SVG MISSING'); }

process.exitCode = failed ? 1 : 0;
