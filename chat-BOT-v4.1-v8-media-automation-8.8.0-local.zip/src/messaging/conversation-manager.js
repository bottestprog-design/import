'use strict';
const { choiceFromReply } = require('./intent-resolver');

class ConversationManager {
  constructor({ store, ttlMs = 15 * 60 * 1000 } = {}) { this.store = store; this.ttlMs = ttlMs; }
  load(sessionId) { return this.store.loadSession(sessionId).messagingConversation || null; }
  save(sessionId, state) {
    const session = this.store.loadSession(sessionId);
    session.messagingConversation = state ? { ...state, updatedAt: new Date().toISOString(), expiresAt: new Date(Date.now() + this.ttlMs).toISOString() } : null;
    this.store.saveSession(session); return session.messagingConversation;
  }
  clear(sessionId) { this.save(sessionId, null); }
  isExpired(state) { return !state || !state.expiresAt || Date.parse(state.expiresAt) <= Date.now(); }
  consumeChoice(sessionId, text) {
    const state = this.load(sessionId);
    if (!state || state.type !== 'intent-disambiguation') return { handled: false };
    if (this.isExpired(state)) { this.clear(sessionId); return { handled: true, expired: true, response: 'انتهت صلاحية الاختيار السابق. اكتب طلبك من جديد وسأساعدك.' }; }
    const choice = choiceFromReply(text, state.candidates || []);
    if (!choice) return { handled: true, response: `اختر رقمًا من 1 إلى ${(state.candidates || []).length}، أو اكتب «إلغاء». لم أنفّذ أي إجراء بعد.` };
    this.clear(sessionId);
    return { handled: true, choice, response: choice.intent };
  }
}
module.exports = { ConversationManager };
