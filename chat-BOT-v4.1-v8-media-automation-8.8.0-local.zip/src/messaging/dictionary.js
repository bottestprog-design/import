'use strict';

function normalizeArabic(value) {
  return String(value ?? '').normalize('NFKC').replace(/[ـ]/gu, '').replace(/[\u064B-\u065F\u0670]/gu, '')
    .replace(/[أإآٱ]/gu, 'ا').replace(/ى/gu, 'ي').replace(/[ؤئ]/gu, 'ء')
    .replace(/[٠-٩]/gu, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/[۰-۹]/gu, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .toLocaleLowerCase('ar').replace(/[،؛؟!.,:()[\]{}"“”'`]/gu, ' ').replace(/\s+/gu, ' ').trim();
}

const BUILTIN_ENTRIES = Object.freeze([
  { intent: 'send_message', phrases: ['ابعت رسالة','ابعث رسالة','ارسل رسالة','أرسل رسالة','بعت رسالة','وصل رسالة','ارسال رسالة','راسل','ابعث ل','ابعت ل','ارسل ل'], weight: 1 },
  { intent: 'schedule_message', phrases: ['جدول رسالة','جدول الرسالة','حدد موعد ارسال','ارسل لاحقا','ابعت بكرة','ارسل بكرة','حدد وقت الارسال','موعد ارسال'], weight: 1 },
  { intent: 'forward_message', phrases: ['حول رسالة','حوّل رسالة','فوروارد','اعد توجيه الرسالة','مرر الرسالة','حولها لشخص'], weight: 1 },
  { intent: 'contact_list', phrases: ['اعرض الاشخاص','وريني الناس','قائمة المستلمين','جهات الاتصال','اعرض جهات الاتصال'], weight: .95 },
  { intent: 'help', phrases: ['مساعدة','ساعدني','ايه الاوامر','ماذا تستطيع'], weight: .95 },
  { intent: 'cancel', phrases: ['الغاء','الغ العملية','وقف العملية','cancel'], weight: 1 },
]);

function levenshtein(a, b, max = 5) {
  if (a === b) return 0;
  if (!a || !b || Math.abs(a.length - b.length) > max) return max + 1;
  let prev = Array.from({length: b.length + 1}, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const cur = [i]; let rowMin = i;
    for (let j = 1; j <= b.length; j++) {
      cur[j] = Math.min(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      rowMin = Math.min(rowMin, cur[j]);
    }
    if (rowMin > max) return max + 1;
    prev = cur;
  }
  return prev[b.length];
}

function flattenEntries(custom = []) {
  const rows = [];
  for (const entry of [...BUILTIN_ENTRIES, ...(Array.isArray(custom) ? custom : [])]) {
    if (!entry || entry.enabled === false || !entry.intent) continue;
    const phrases = Array.isArray(entry.phrases) ? entry.phrases : [entry.phrase || entry.value || ''];
    for (const phrase of phrases) {
      const normalized = normalizeArabic(phrase);
      if (normalized) rows.push({ intent: String(entry.intent), phrase: String(phrase), normalized, weight: Number(entry.weight) || 1, matchType: entry.matchType || 'synonym' });
    }
  }
  return rows;
}

function matchDictionary(input, custom = [], options = {}) {
  const text = normalizeArabic(input);
  if (!text) return [];
  const rows = flattenEntries(custom), scores = new Map();
  for (const row of rows) {
    let score = 0;
    if (text === row.normalized) score = 1;
    else if (text.startsWith(row.normalized + ' ') || text.endsWith(' ' + row.normalized) || text.includes(' ' + row.normalized + ' ')) score = .91;
    else if (row.normalized.length >= 4 && (text.startsWith(row.normalized) || text.includes(row.normalized))) score = .84;
    else if (options.fuzzy !== false && row.normalized.length >= 4 && text.length <= 40) {
      const d = levenshtein(text, row.normalized, 4);
      const ratio = 1 - d / Math.max(text.length, row.normalized.length, 1);
      if (d <= Math.max(1, Math.floor(row.normalized.length * .2))) score = ratio * .78;
    }
    score *= Math.min(1, Math.max(.1, row.weight));
    if (score > 0 && (!scores.has(row.intent) || scores.get(row.intent).score < score)) scores.set(row.intent, { intent: row.intent, score, matchedPhrase: row.phrase, matchType: row.matchType });
  }
  return [...scores.values()].sort((a,b) => b.score - a.score || a.intent.localeCompare(b.intent));
}

function validateEntry(entry) {
  const intent = String(entry?.intent || '').trim();
  const phrases = Array.isArray(entry?.phrases) ? entry.phrases : [entry?.phrase || ''];
  const cleanPhrases = [...new Set(phrases.map(x => String(x || '').trim()).filter(Boolean))].slice(0, 30);
  if (!/^[a-z][a-z0-9_]{1,63}$/.test(intent)) throw new Error('معرّف النية غير صالح. استخدم حروفًا إنجليزية صغيرة وشرطة سفلية.');
  if (!cleanPhrases.length || cleanPhrases.some(x => x.length > 120)) throw new Error('أضف عبارة واحدة على الأقل، بحد أقصى 120 حرفًا لكل عبارة.');
  return { id: String(entry.id || require('node:crypto').randomUUID()), intent, phrases: cleanPhrases, weight: Math.max(.1, Math.min(1, Number(entry.weight) || 1)), enabled: entry.enabled !== false, createdAt: entry.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString() };
}

module.exports = { normalizeArabic, matchDictionary, validateEntry, BUILTIN_ENTRIES, levenshtein };
