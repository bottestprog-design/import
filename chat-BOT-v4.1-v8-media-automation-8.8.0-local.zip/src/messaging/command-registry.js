'use strict';

class CommandRegistry {
  constructor() { this.commands = new Map(); }
  register(definition) {
    if (!definition || !/^[a-z][a-z0-9_]{1,63}$/.test(String(definition.key || ''))) throw new Error('Invalid command key');
    if (typeof definition.execute !== 'function') throw new Error(`Command ${definition.key} needs an execute handler`);
    if (this.commands.has(definition.key)) throw new Error(`Command already registered: ${definition.key}`);
    this.commands.set(definition.key, Object.freeze({ ...definition, aliases: [...new Set((definition.aliases || []).map(String))] }));
    return this;
  }
  get(key) { return this.commands.get(String(key)); }
  list() { return [...this.commands.values()].map(({ execute, ...publicDefinition }) => publicDefinition); }
  async execute(key, context, parameters = {}) {
    const command = this.get(key);
    if (!command) return { status: 'failed', errorCode: 'COMMAND_NOT_FOUND', message: 'الأمر غير مسجل.' };
    if (command.permission && !context?.permissions?.includes(command.permission)) return { status: 'failed', errorCode: 'PERMISSION_DENIED', message: 'ليست لديك صلاحية تنفيذ هذا الأمر.' };
    const validation = typeof command.validate === 'function' ? await command.validate(parameters, context) : { ok: true, value: parameters };
    if (validation === false || validation?.ok === false) return { status: 'failed', errorCode: 'VALIDATION_FAILED', message: validation?.message || 'البيانات غير مكتملة أو غير صالحة.' };
    try {
      const result = await command.execute(context, validation?.value ?? parameters);
      return { status: 'success', command: key, result };
    } catch (error) {
      return { status: 'failed', command: key, errorCode: error.code || 'EXECUTION_FAILED', message: String(error.message || error) };
    }
  }
}
module.exports = { CommandRegistry };
