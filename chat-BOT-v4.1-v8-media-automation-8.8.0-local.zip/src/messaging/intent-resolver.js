'use strict';
const { normalizeArabic, matchDictionary } = require('./dictionary');

const AMBIGUOUS_SHORT_FORMS = Object.freeze({
  'بعت': ['send_message', 'schedule_message', 'forward_message'],
  'وصل': ['send_message', 'schedule_message', 'forward_message'],
  'حولها': ['forward_message', 'send_message'],
  'ابعت': ['send_message', 'schedule_message'],
  'ارسل': ['send_message', 'schedule_message'],
});
const LABELS = Object.freeze({ send_message: 'إرسال رسالة جديدة', schedule_message: 'جدولة رسالة لوقت لاحق', forward_message: 'تحويل رسالة موجودة', contact_list: 'عرض جهات الاتصال', help: 'عرض المساعدة', cancel: 'إلغاء العملية' });

function resolveIntent(text, customDictionary = [], context = {}) {
  const normalized = normalizeArabic(text);
  if (!normalized) return { status: 'unknown', candidates: [], normalized };
  const explicit = AMBIGUOUS_SHORT_FORMS[normalized];
  if (explicit && !context.activeFlow) return { status: 'ambiguous', candidates: explicit.map((intent, i) => ({ intent, score: .7 - i * .01, label: LABELS[intent] || intent })), normalized, source: 'ambiguous-short-form' };
  const matches = matchDictionary(text, customDictionary);
  if (!matches.length || matches[0].score < .54) return { status: 'unknown', candidates: matches, normalized };
  const top = matches[0], second = matches[1];
  if (second && top.score - second.score < .075 && top.score < .96) {
    return { status: 'ambiguous', candidates: matches.slice(0, 3).map(x => ({ ...x, label: LABELS[x.intent] || x.intent })), normalized, source: 'dictionary-score-tie' };
  }
  return { status: 'resolved', intent: top.intent, confidence: top.score, matchedPhrase: top.matchedPhrase, candidates: matches.slice(0, 3), normalized };
}

function choiceFromReply(text, candidates) {
  const raw = String(text || '').trim();
  const m = raw.match(/^\s*(?:اختيار\s*)?([1-9])\s*[.)،]?\s*$/u);
  if (m) return candidates[Number(m[1]) - 1] || null;
  const normalized = normalizeArabic(raw);
  return candidates.find(c => normalizeArabic(c.label || c.intent) === normalized || normalizeArabic(c.intent.replace(/_/g, ' ')) === normalized) || null;
}
module.exports = { resolveIntent, choiceFromReply, LABELS, AMBIGUOUS_SHORT_FORMS };
