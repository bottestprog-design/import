'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const mediaFiles = require('./media');
const groups = require('./groups');
const { resolveIntent } = require('./messaging/intent-resolver');
const { ConversationManager } = require('./messaging/conversation-manager');

const HELP = `🤖 chat BOT 8.8.0 — مساعد الأوامر

اكتب الأمر بطريقتك: «وريني الناس»، «عايز أشوف الأشخاص»، «ممكن تعرض المستلمين». أرسل الأوامر من محادثة نفسك فقط لأنها تتحكم في حسابك وبياناتك.

ابدأ بسرعة:
• مساعدة الأشخاص — إضافة وتعديل وحذف ومزامنة الأسماء والصور.
• مساعدة الإرسال — إرسال نص أو ملفات وكيفية إكمال الطلب.
• مساعدة المواعيد — إنشاء موعد وتعديله وتشغيله وإيقافه.
• مساعدة التفاعل — الردود التلقائية والقواعد وكلمات التشغيل.
• مساعدة المجموعات — استكشاف المجموعات وربطها.
• مساعدة الجلسات — ربط WhatsApp وإدارة الجلسات.
• مساعدة الإعدادات — نطاق الردود، الهدوء، التوقيت، والاسم المستخدم في الرد.
• الحالة / التشخيص / اعرض سجل المساعد — معرفة مكان توقف العملية.

اختصارات الحوار:
• «أضف شخصًا» ← سأسأل عن الاسم ثم الدولة ثم الرقم، خطوة خطوة.
• «أرسل رسالة» ← سأسأل عن المستلم ثم نص الرسالة.
• «أنشئ موعدًا» ← سأسأل عن الاسم والتاريخ والوقت والمستلم والرسالة.
• «أنشئ ردًا تلقائيًا» ← سأسأل عن العبارة ثم الرد.
• «إلغاء» يوقف أي خطوات معلقة دون حفظ العملية.

أمثلة كاملة:
• أرسل الآن | إلى=أحمد | الرسالة=مساء الخير
• أضف موعد | الاسم=تذكير | التكرار=مرة | التاريخ=2026-10-20 | الوقت=18:30 | إلى=أحمد | الرسالة=موعدنا اليوم
• أضف قاعدة تفاعل | الاسم=ترحيب | عندما=السلام عليكم | المطابقة=يحتوي | الرد=وعليكم السلام {{sender}}
• زامن ملف WhatsApp | إلى=أحمد، سارة / زامن ملفات WhatsApp | إلى=الكل

مهم: لا أدعي نجاح إرسال أو مزامنة إلا بعد استلام نتيجة التنفيذ. الأوامر الإدارية لا ينفذها إلا مالك الحساب في محادثة نفسه، وليس كل شخص يراسله.`;

const HELP_TOPICS = {
  people: `👥 الأشخاص — المسار الكامل\n1) لإضافة تفاعلية اكتب «أضف شخصًا» ثم أجب عن الاسم والدولة والرقم. لن يُحفظ قبل التحقق.\n2) أو استخدم: أضف الرقم 7345 xxxx باسم أحمد.\n3) عرض: اعرض الأشخاص. تغيير الاسم: غيّر اسم المستلم أحمد إلى أحمد الجديد. تفعيل/إيقاف: فعّل المستلم أحمد / عطّل المستلم أحمد. حذف: احذف المستلم أحمد.\n4) جلب مصدر WhatsApp: اختيار من WhatsApp في الموقع، أو زامن ملف WhatsApp | إلى=أحمد. المزامنة تغيّر ملف WhatsApp فقط ولا تستبدل الاسم/الصورة المحليين.\nإذا لم تعرف جهة الاتصال، اعرض الأشخاص أولًا وتأكد من اسمها ورقمها قبل الإرسال.`,
  send: `✉️ الإرسال — المسار الكامل\n1) تأكد أن WhatsApp متصل وأن المستلم محفوظ ومفعّل.\n2) سريع: «ابعت رسالة لأحمد: صباح الخير».\n3) دقيق: أرسل الآن | إلى=أحمد | الرسالة=صباح الخير.\n4) مرفق: أرسل الآن | إلى=أحمد | ملف=اسم_الملف.pdf | الرسالة=هذا الملف. ارفع الملف للمشروع أولًا ثم استخدم اسمه من «اعرض الوسائط».\n5) الإرسال للجميع يحتاج تأكيد=نعم.\n6) بعد الإرسال راجع ملخص نجاح/فشل كل هدف؛ إن كانت النتيجة جزئية، راجعها قبل إعادة المحاولة حتى لا تكرر الرسائل.`,
  schedules: `⏰ المواعيد — المسار الكامل\n1) اكتب «أنشئ موعدًا» لأسئلة خطوة بخطوة، أو اكتب الأمر كاملًا.\n2) مرة واحدة: أضف موعد | الاسم=تذكير | التكرار=مرة | التاريخ=2026-10-20 | الوقت=18:30 | إلى=أحمد | الرسالة=النص.\n3) التكرار: التكرار=أسبوعي/شهري/سنوي، وأكمل اليوم أو يوم الشهر والشهر عند الحاجة.\n4) اعرض المواعيد، ثم عدّل الموعد تذكير | الوقت=19:30، أو أوقف الموعد تذكير / فعّل الموعد تذكير / شغّل الموعد الآن تذكير.\n5) تأكد أن الأتمتة مفعّلة، والهدف نشط، وWhatsApp متصل، والخادم يعمل وقت الموعد. عند التأخر، افحص الحالة وسجل المواعيد قبل إنشاء نسخة ثانية.`,
  interaction: `💬 الردود التلقائية — المسار الكامل\n1) فعّل التفاعل، وحدّد النطاق: كل المحادثات أو الخاص أو المجموعات أو أهداف محددة.\n2) اكتب «أنشئ ردًا تلقائيًا» لإنشاء قاعدة خطوة بخطوة. أو استخدم: أضف قاعدة تفاعل | الاسم=ترحيب | عندما=السلام عليكم | المطابقة=يحتوي | الرد=وعليكم السلام {{sender}}.\n3) يدعم الرد المتغيرات {{sender}} و{{message}} و{{time}}. يمكن استخدام الاسم المسجل داخل المشروع، وإيقاف هذا الخيار من الإعدادات.\n4) اعرض قواعد التفاعل، ثم عدّل قاعدة التفاعل ترحيب | الرد=نص، أو فعّل/أوقف/احذف قاعدة التفاعل ترحيب.\n5) إذا لم تطابق الرسالة قاعدة، يعمل الرد الافتراضي عند تفعيله. غيّر نصه من الموقع أو اكتب: عدّل الرد الافتراضي | الرد=نص.\n6) إن لم يصل رد، افحص: اتصال WhatsApp، تشغيل التفاعل في الإعدادات، نطاق القاعدة، وقتها، وفاصل التكرار؛ ثم راجع آخر التفاعلات والسبب المسجل.`,
  groups: `👥 المجموعات — المسار الكامل\n1) اكتشف المجموعات ثم اعرض المجموعات.\n2) أضف المجموعة باستخدام GID الذي يظهر في WhatsApp: أضف مجموعة | GID=...@g.us أو حلّل رابط دعوة.\n3) يمكنك تغيير الاسم المحلي أو تفعيل المجموعة/إيقافها أو حذفها من قائمة المشروع. هذا لا يغير الاسم الأصلي ولا يحذف المجموعة من WhatsApp.\n4) استخدم المجموعة هدفًا في الإرسال أو المواعيد بعد التأكد من أنها مفعّلة.`,
  sessions: `🔌 الجلسات — المسار الكامل\n1) الجلسات لعرضها، وأنشئ جلسة | الاسم=اسم الجلسة لإنشاء جلسة مستقلة.\n2) اتصل بواتساب ثم امسح QR من جهازك داخل الجلسة المختارة.\n3) لا تستخدم نفس مجلد المصادقة لجلسات مختلفة، ولا تشارك QR.\n4) حالة الاتصال / التشخيص يوضحان الاتصال والأخطاء. لإيقاف الجلسة استخدم «افصل واتساب». تغيير الجلسة أو حذفها إجراء إداري؛ تحقّق من الجلسة المختارة قبل التعديل.`,
  settings: `⚙️ الإعدادات — المسار الكامل\n• اعرض إعدادات التفاعل / اعرض إعدادات الإرسال والتفاعل.\n• اضبط المنطقة الزمنية | المنطقة=Asia/Muscat.\n• اضبط النطاق | النطاق=خاص/مجموعات/الكل.\n• اضبط فترة الهدوء | البداية=23:00 | النهاية=07:00 | السلوك=رد مخصص، أو أوقف فترة الهدوء.\n• استخدم الاسم المسجل في المشروع للتحكم في {{sender}}: فعّل استخدام أسماء المشروع / أوقف استخدام أسماء المشروع.\n• كلمة التشغيل: غيّر كلمة تشغيل الأوامر إلى يا نجم، مساعد؛ ثم اجعلها إلزامية/اختيارية. عند إلزامها اكتب الكلمة في أي جزء من الأمر.\n• الخلفية والمظهر ورفع الملفات خيارات بصرية في الموقع؛ لا يغيّر أمر نصي صورة محلية لم ترفعها إلى المشروع.`,
};
function topicHelp(text) {
  const value = norm(text);
  if (!/^(?:مساعدة|ساعدني|شرح|كيف|طريقة|دليل)\s+/u.test(value)) return '';
  if (/(?:اشخاص|اشخاص|الاشخاص|جهات الاتصال|المستلمين|الارقام)/u.test(value)) return HELP_TOPICS.people;
  if (/(?:ارسال|ارسل|رسائل|وسائط|ملفات)/u.test(value)) return HELP_TOPICS.send;
  if (/(?:موعد|مواعيد|جدول|تذكير|جدوله|جدولة|اتمته)/u.test(value)) return HELP_TOPICS.schedules;
  if (/(?:تفاعل|رد تلقائي|ردود تلقائيه|قواعد|محادثه|الردود)/u.test(value)) return HELP_TOPICS.interaction;
  if (/(?:مجموعات|جروبات|قروبات)/u.test(value)) return HELP_TOPICS.groups;
  if (/(?:جلسات|واتساب|اتصال|qr|حساب)/u.test(value)) return HELP_TOPICS.sessions;
  if (/(?:اعدادات|اعداد|كلمه تشغيل|هدوء|المنطقه الزمنيه|نطاق)/u.test(value)) return HELP_TOPICS.settings;
  return HELP;
}

function unknownCommandResponse(input) {
  const raw = String(input || '').trim().slice(0, 180);
  const value = norm(raw);
  let guidance = `اكتب «مساعدة» أو «مساعدة الإرسال» أو «مساعدة المواعيد» أو «مساعدة التفاعل» لعرض المسار الكامل.`;
  if (/(?:ابعت|ابعث|ارسل|أرسل|ارسال|رساله|رسالة|send)/u.test(value)) guidance = `جرّب: «ابعت رسالة لأحمد: صباح الخير» أو «أرسل الآن | إلى=أحمد | الرسالة=النص». ثم راجع نتيجة الإرسال. اكتب «مساعدة الإرسال» للمسار الكامل.`;
  else if (/(?:موعد|مواعيد|ذكرني|تذكير|جدول|وقت|تاريخ)/u.test(value)) guidance = `جرّب «أنشئ موعدًا» لأمشي معك خطوة خطوة، أو «أضف موعد | الاسم=تذكير | التكرار=مرة | التاريخ=YYYY-MM-DD | الوقت=18:30 | إلى=أحمد | الرسالة=النص». اكتب «مساعدة المواعيد» للمسار الكامل.`;
  else if (/(?:شخص|مستخدم|مستلم|رقم|اسم|جهات اتصال|whatsapp)/u.test(value)) guidance = `جرّب «أضف شخصًا» لإكمال البيانات خطوة خطوة، أو «اعرض الأشخاص». اكتب «مساعدة الأشخاص» لتعرف طريقة الإضافة والتعديل والمزامنة.`;
  else if (/(?:رد|تفاعل|قاعدة|تلقائي|ترحيب)/u.test(value)) guidance = `جرّب «أنشئ ردًا تلقائيًا» لإنشاء القاعدة بالتدريج، أو «أضف قاعدة تفاعل | الاسم=ترحيب | عندما=مرحبا | المطابقة=يحتوي | الرد=أهلًا {{sender}}». اكتب «مساعدة التفاعل» للتشخيص.`;
  else if (/(?:مجموعه|مجموعات|جروب|قروب)/u.test(value)) guidance = `جرّب «اكتشف المجموعات» أو «اعرض المجموعات». اكتب «مساعدة المجموعات» لمعرفة ربط المجموعة.`;
  return `فهمت رسالتك: «${raw}»\nلكن لم أتعرف على إجراء محدد، لذلك لم أغيّر أي بيانات ولم أرسل شيئًا.\n\n${guidance}\n\nيمكنك كتابة الأمر بطريقتك أو وصف الهدف، وسأعرض أقرب صيغة وخطوات إكماله. إذا كنت تقصد أمرًا موجودًا، أخبرني باسم القسم أو اكتب «مساعدة».`;
}


function norm(value) {
  return String(value ?? '').normalize('NFKC').replace(/[ـ]/g, '').replace(/[ًٌٍَُِّْ]/g, '')
    .replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/\s+/g, ' ').trim().toLocaleLowerCase('ar');
}
function clean(value, max = 1000) { return String(value ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, max); }
function normalizedPhoneDigits(value) {
  const raw = String(value ?? '').trim(), digits = raw.replace(/\D/g, '');
  if (digits.length < 6) return '';
  try { return require('./phones').parse(raw, 'OM').digits; } catch { return digits; }
}
function parseFields(text) {
  const out = {};
  for (const piece of String(text || '').split(/[|\n]/)) {
    const m = piece.trim().match(/^([^=:]{1,40})\s*[=:]\s*([\s\S]*)$/);
    if (!m) continue;
    const key = norm(m[1]).replace(/[؟?]$/, '');
    const val = clean(m[2], 3500);
    const map = {
      'اسم':'name','الاسم':'name','name':'name','عنوان':'name','عنوان الموعد':'name','اسم الموعد الجديد':'newName','الاسم الجديد':'newName','new name':'newName','الموعد':'taskName','اسم الموعد':'taskName','معرف الموعد':'taskId','معرّف الموعد':'taskId','task id':'taskId',
      'رقم':'phone','الرقم':'phone','رقم الهاتف':'phone','الهاتف':'phone','phone':'phone',
      'التاريخ':'date','تاريخ':'date','date':'date','الوقت':'time','وقت':'time','time':'time','الشهر':'month','شهر':'month','month':'month','يوم الشهر':'dayOfMonth','day of month':'dayOfMonth','السنة':'year','سنة':'year','year':'year','وضع النص':'textMode','طريقة النص':'textMode','موضع النص':'textMode','text mode':'textMode','وضع الملفات':'mediaMode','نمط الملفات':'mediaMode','مدة السماح':'graceMinutes','مهلة التنفيذ':'graceMinutes','إرسال كمستند':'sendAsDocument','ارسال كمستند':'sendAsDocument','كمستند':'sendAsDocument','نص قبل الإرسال':'preText','النص قبل الإرسال':'preText','نص بعد الإرسال':'postText','النص بعد الإرسال':'postText',
      'الرسالة':'text','رسالة':'text','نص':'text','النص':'text','message':'text','text':'text',
      'الي':'to','الى':'to','إلى':'to','المستلم':'to','المستلمين':'to','الهدف':'to','targets':'to','to':'to',
      'التكرار':'repeat','تكرار':'repeat','repeat':'repeat','اليوم':'day','يوم':'day','day':'day',
      'ملف':'file','الملف':'file','ملفات':'files','الملفات':'files','وسائط':'files','media':'files',
      'تاكيد':'confirm','تأكيد':'confirm','confirm':'confirm','مللي ثانية':'sendDelayMs','ملي ثانية':'sendDelayMs','تاخير الارسال':'sendDelayMs','تأخير الارسال':'sendDelayMs','المطابقة':'match','مطابقة':'match','match':'match',
      'عندما':'when','اذا':'when','إذا':'when','when':'when','الرد':'reply','رد':'reply','reply':'reply',
      'الدولة':'country','دولة':'country','country':'country','الوصف':'description','description':'description',
      'المنطقة الزمنية':'timezone','المنطقة':'timezone','timezone':'timezone','البداية':'quietStart','بداية الهدوء':'quietStart','وقت البداية':'quietStart','النهاية':'quietEnd','نهاية الهدوء':'quietEnd','وقت النهاية':'quietEnd','السلوك':'quietAction','نوع الهدوء':'quietAction','نص الرد':'quietReply','رد الهدوء':'quietReply','فاصل الرد':'quietCooldownSec','فاصل بين الردود':'quietCooldownSec','النطاق':'interactionScope','نطاق التفاعل':'interactionScope','فاصل القاعدة':'cooldownSec','فاصل التكرار':'cooldownSec','مهلة التكرار':'cooldownSec','العدد':'maxActionsPerMinute','الحد الأقصى للأفعال':'maxActionsPerMinute','مفعل':'enabled','تفعيل':'enabled',
    };
    const dest = map[key] || key;
    out[dest] = val;
  }
  return out;
}
function extractPhone(text) {
  const m = String(text || '').match(/(?:\+|00)?[\d٠-٩۰-۹][\d٠-٩۰-۹\s().-]{5,24}/u);
  return m ? m[0].trim().replace(/[،؛,]+$/g, '').trim() : '';
}
function weekdayNumber(value) {
  const v = norm(value);
  const names = {
    'الاحد':0,'احد':0,'sunday':0,'الاثنين':1,'الإثنين':1,'اثنين':1,'monday':1,
    'الثلاثاء':2,'ثلاثاء':2,'tuesday':2,'الاربعاء':3,'الأربعاء':3,'اربعاء':3,'wednesday':3,
    'الخميس':4,'خميس':4,'thursday':4,'الجمعة':5,'جمعه':5,'friday':5,'السبت':6,'سبت':6,'saturday':6,
  };
  return Object.prototype.hasOwnProperty.call(names, v) ? names[v] : null;
}

const COUNTRY_ALIASES = new Map(Object.entries({
  'عمان':'OM','سلطنة عمان':'OM','oman':'OM','om':'OM',
  'السعودية':'SA','السعوديه':'SA','المملكة العربية السعودية':'SA','المملكه العربيه السعوديه':'SA','saudi arabia':'SA','sa':'SA',
  'مصر':'EG','egypt':'EG','eg':'EG','الإمارات':'AE','الامارات':'AE','الامارات العربية المتحدة':'AE','الامارات العربيه المتحده':'AE','uae':'AE','ae':'AE',
  'الكويت':'KW','kuwait':'KW','kw':'KW','قطر':'QA','qatar':'QA','qa':'QA','البحرين':'BH','bahrain':'BH','bh':'BH',
  'الأردن':'JO','الاردن':'JO','jordan':'JO','jo':'JO','العراق':'IQ','iraq':'IQ','iq':'IQ','اليمن':'YE','yemen':'YE','ye':'YE',
  'لبنان':'LB','lebanon':'LB','lb':'LB','سوريا':'SY','syria':'SY','sy':'SY','فلسطين':'PS','palestine':'PS','ps':'PS',
  'المغرب':'MA','morocco':'MA','ma':'MA','الجزائر':'DZ','algeria':'DZ','dz':'DZ','تونس':'TN','tunisia':'TN','tn':'TN',
  'ليبيا':'LY','libya':'LY','ly':'LY','السودان':'SD','sudan':'SD','sd':'SD','الهند':'IN','india':'IN','in':'IN',
  'باكستان':'PK','pakistan':'PK','pk':'PK','تركيا':'TR','turkey':'TR','tr':'TR','بريطانيا':'GB','المملكة المتحدة':'GB','united kingdom':'GB','uk':'GB','gb':'GB',
  'أمريكا':'US','امريكا':'US','الولايات المتحدة':'US','united states':'US','usa':'US','us':'US','كندا':'CA','canada':'CA','ca':'CA',
  'ألمانيا':'DE','المانيا':'DE','germany':'DE','de':'DE','فرنسا':'FR','france':'FR','fr':'FR','بنغلاديش':'BD','bangladesh':'BD','bd':'BD',
  'الفلبين':'PH','philippines':'PH','ph':'PH'
}).map(([name, code]) => [norm(name), code]));
function resolveCountry(input) {
  const raw = clean(input, 100).replace(/^(?:دولة|البلد|بلد)\s*/u, '');
  const value = norm(raw), code = COUNTRY_ALIASES.get(value) || (/^[a-z]{2}$/i.test(raw) ? raw.toUpperCase() : '');
  if (!code) return null;
  try { if (!require('./phones').countries().some(x => x.code === code)) return null; } catch { return null; }
  const names = { OM:'عمان', SA:'السعودية', EG:'مصر', AE:'الإمارات', KW:'الكويت', QA:'قطر', BH:'البحرين', JO:'الأردن', IQ:'العراق', YE:'اليمن', LB:'لبنان', SY:'سوريا', PS:'فلسطين', MA:'المغرب', DZ:'الجزائر', TN:'تونس', LY:'ليبيا', SD:'السودان', IN:'الهند', PK:'باكستان', TR:'تركيا', GB:'بريطانيا', US:'أمريكا', CA:'كندا', DE:'ألمانيا', FR:'فرنسا', BD:'بنغلاديش', PH:'الفلبين' };
  return { code, name: names[code] || code };
}


function escapeRegex(value) { return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function commandTriggerList(settings = {}) {
  const raw = Array.isArray(settings.commandTriggerWords) ? settings.commandTriggerWords : String(settings.commandTriggerWords || '').split(/[،,;|\n]/);
  return [...new Set(raw.map(value => clean(value, 50)).filter(Boolean))].slice(0, 12);
}
function triggerPattern(value) {
  return norm(value).split('').map(ch => ch === 'ا' ? '[اأإآ]' : ch === 'ي' ? '[يى]' : /\s/.test(ch) ? '\\s+' : escapeRegex(ch)).join('');
}
function commandTriggerMatch(text, settings = {}) {
  if (settings.commandTriggerEnabled === false) return { matched:false, words:[] };
  const source = norm(text), words = commandTriggerList(settings);
  const matched = words.filter(word => {
    const normalized = norm(word);
    if (!normalized) return false;
    if (/^[a-z0-9 _-]+$/i.test(normalized)) return new RegExp(`(?:^|[^a-z0-9])${escapeRegex(normalized)}(?:$|[^a-z0-9])`, 'i').test(source);
    return source.includes(normalized);
  });
  return { matched:matched.length > 0, words:matched };
}
function removeCommandTriggers(text, settings = {}) {
  if (settings.commandTriggerEnabled === false) return String(text || '').trim();
  let value = String(text || '');
  for (const word of commandTriggerList(settings).sort((a,b) => b.length-a.length)) {
    try { value = value.replace(new RegExp(triggerPattern(word), 'giu'), ' '); } catch {}
  }
  return value.replace(/\s+/g, ' ').replace(/^[\s،,:;.!؟!?\-–—]+|[\s،,:;.!؟!?\-–—]+$/gu, '').trim();
}
function stripConversationalFiller(text) {
  let value = String(text || '').trim();
  value = value.replace(/^[\s،,:;.!؟!?\-–—]+/u, '');
  const prefixes = /^(?:(?:السلام\s+عليكم|لو\s+سمحت|من\s+فضلك|بعد\s+إذنك|بعد\s+اذنك|ممكن|هل\s+ممكن|هل\s+تقدر|هل\s+يمكنك|تقدر|عايز(?:ة)?|عاوز(?:ة)?|عاوزك|عايزك|محتاج(?:ة)?|أريد|اريد|أبغى|ابغى|بدي|please|kindly|can\s+you|could\s+you|would\s+you)\s+)+/iu;
  for (let i=0;i<4;i++) { const next=value.replace(prefixes,'').replace(/^[\s،,:;.!؟!?\-–—]+/u,'').trim(); if (next === value) break; value = next; }
  return value.replace(/[؟?!]+$/u, '').trim();
}
function canonicalizeCommandHead(head) {
  let h = stripConversationalFiller(head).normalize('NFKC').replace(/[ـ\u064b-\u065f\u0670]/g, '');
  const rules = [
    [/^(?:مساعده|help|الاوامر|دليل\s*(?:الاوامر|المستخدم)|قوللي\s*(?:كل\s*)?(?:الاوامر|تعمل\s*ايه)|ايه\s*الاوامر)(?=$|\s|[،,:;|])/iu, 'مساعدة'],
    [/^(?:اعرض|عرض|اظهر|أظهر|وريني|ورني|توريني|تورينيلي|هات|هاتلي|جيب|اعرضلي|ورينيلي|تعرضلي|show|list)\s*(?:لي\s*)?(?:كل\s*)?(?:قائمه\s*)?(?:ال)?(?:اشخاص|الأشخاص|المستلمين|جهات\s*الاتصال|الارقام|ارقام|المستخدمين)(?=$|\s|[،,:;|])/iu, 'اعرض الأشخاص'],
    [/^(?:اعرض|عرض|اظهر|أظهر|وريني|ورني|هات|جيب|اعرضلي|تعرضلي|show|list)\s*(?:لي\s*)?(?:كل\s*)?(?:قائمه\s*)?(?:ال)?(?:مجموعات|الجروبات|الجروبات|القروبات|قروباتي)(?=$|\s|[،,:;|])/iu, 'اعرض المجموعات'],
    [/^(?:اعرض|عرض|اظهر|أظهر|وريني|ورني|هات|جيب|اعرضلي|تعرضلي|show|list)\s*(?:لي\s*)?(?:كل\s*)?(?:ال)?(?:مواعيد|المواعيد|المواعيد\s*المجدوله|جدولي|مواعيدي|التذكيرات)(?=$|\s|[،,:;|])/iu, 'اعرض المواعيد'],
    [/^(?:اعرض|عرض|اظهر|أظهر|وريني|ورني|هات|جيب|show|list)\s*(?:لي\s*)?(?:ال)?(?:وسائط|الملفات|ملفاتي|الصور)(?=$|\s|[،,:;|])/iu, 'اعرض الوسائط'],
    [/^(?:اعرض|عرض|اظهر|أظهر|وريني|هات|جيب|show|list)\s*(?:لي\s*)?(?:قواعد\s*)?(?:التفاعل|الرد\s*التلقائي(?:ه|ة)?|الردود\s*التلقائي(?:ه|ة)?)(?=$|\s|[،,:;|])/iu, 'اعرض قواعد التفاعل'],
    [/^(?:اعرض|عرض|اظهر|أظهر|وريني|هات|show|list)\s*(?:لي\s*)?(?:كل\s*)?(?:ال)?(?:جلسات|الجلسات|الحسابات)(?=$|\s|[،,:;|])/iu, 'الجلسات'],
    [/^(?:اعرض|عرض|اظهر|أظهر|وريني|هات|show|list)\s*(?:لي\s*)?(?:حاله|حالة|وضع)\s*(?:الاتصال|الواتساب|البوت|الجلسه|الجلسة)(?=$|\s|[،,:;|])/iu, 'حالة الاتصال'],
    [/^(?:حاله|حالة|وضع)\s*(?:الاتصال|الواتساب|البوت|الجلسه|الجلسة)(?=$|\s|[،,:;|])/iu, 'حالة الاتصال'],
    [/^(?:اتصل|وصل|اربط|شغل|شغّل|فعّل|فعل)\s*(?:ب)?\s*(?:واتساب|الواتس|الجلسه|الجلسة|الحساب)(?=$|\s|[،,:;|])/iu, 'اتصل بواتساب'],
    [/^(?:افصل|اقطع|وقف|أوقف|اوقف|عطل|عطّل)\s*(?:اتصال\s*)?(?:واتساب|الواتس|الجلسه|الجلسة|الحساب)(?=$|\s|[،,:;|])/iu, 'افصل واتساب'],
    [/^(?:شغل|شغّل|فعّل|فعل|ابدأ|ابدألي)\s*(?:نظام\s*)?(?:التفاعل|الردود\s*التلقائي(?:ه|ة)?|الرد\s*التلقائي(?:ه|ة)?)(?=$|\s|[،,:;|])/iu, 'فعّل التفاعل'],
    [/^(?:وقف|أوقف|اوقف|عطل|عطّل|اقفل|اطفي)\s*(?:نظام\s*)?(?:التفاعل|الردود\s*التلقائي(?:ه|ة)?|الرد\s*التلقائي(?:ه|ة)?)(?=$|\s|[،,:;|])/iu, 'أوقف التفاعل'],
    [/^(?:شغل|شغّل|فعّل|فعل|ابدأ)\s*(?:نظام\s*)?(?:الجدوله|الجدولة|الأتمته|الاتمته|الأتمتة|الاتماتيك|المواعيد)(?=$|\s|[،,:;|])/iu, 'فعّل الأتمتة'],
    [/^(?:وقف|أوقف|اوقف|عطل|عطّل|اقفل)\s*(?:نظام\s*)?(?:الجدوله|الجدولة|الأتمته|الاتمته|الأتمتة|الاتماتيك|المواعيد)(?=$|\s|[،,:;|])/iu, 'أوقف الأتمتة'],
    [/^(?:ضيف|ضيفلي|اضف|أضف|أضيف|سجل|سجّل|احفظ|حط)\s*(?:لي\s*)?(?:رقم|شخص|مستلم|جهة\s*اتصال)(?=$|\s|[،,:;|])/iu, 'أضف الرقم'],
    [/^(?:امسح|احذف|حذف|شيل|ازل|أزل)\s*(?:لي\s*)?(?:الشخص|المستخدم|جهة\s*الاتصال|المستلم)(?=$|\s|[،,:;|])/iu, 'احذف المستلم'],
    [/^(?:عدل|عدّل|غير|غيّر|حدث|حدّث|تعديل)\s+(?:بيانات\s*)?(?:الموعد|التذكير)(?=$|\s|[،,:;|])/iu, 'تعديل الموعد'],
    [/^(?:عدل|عدّل|غير|غيّر|تعديل)\s+(?:قاعدة|قاعده)\s+(?:التفاعل|الرد\s*التلقائي(?:ه|ة)?)(?=$|\s|[،,:;|])/iu, 'تعديل قاعدة التفاعل'],
    [/^(?:اذكرني|ذكرني|اعمل|اعمللي|انشئ|أنشئ|اضف|أضف|ضيف|جدول|جدوللي)\s*(?:لي\s*)?(?:موعد|تذكير|رساله\s*مجدوله|رسالة\s*مجدولة)(?=$|\s|[،,:;|])/iu, 'أضف موعد'],
    [/^(?:أرسل\s+الآن|ارسل\s+الان|ابعت|ابعتلي|ابعث|ابعثلي|تبعت|ترسل|ارسل|أرسل|ارسلي|ابعتي|بعت|send)(?=$|\s|[،,:;|])/iu, 'أرسل الآن'],
    [/^(?:شخص|اسم|الاسم)\s+/iu, ''],
  ];
  for (const [pattern, canonical] of rules) {
    const match = h.match(pattern);
    if (match) { h = `${canonical}${h.slice(match[0].length)}`.trim(); break; }
  }
  return h.replace(/^[،,:;.!؟!?\-–—\s]+/u, '').replace(/[؟]+$/u, '').trim();
}
function naturalSendCommand(text) {
  const value = String(text || '').trim();
  if (!value || /[|\n]/.test(value) || !/^(?:ابعت|ابعتلي|ابعث|ابعثلي|تبعت|ترسل|ارسل|أرسل|ارسلي|ابعتي|بعت|أرسل الآن|ارسل الان|أرسل رسالة|ارسل رسالة)(?=\s|$)/iu.test(value)) return '';
  let match = value.match(/^(?:ابعت|ابعتلي|ابعث|ابعثلي|تبعت|ترسل|ارسل|أرسل|ارسلي|ابعتي|بعت|أرسل الآن|ارسل الان|أرسل رسالة|ارسل رسالة)\s+(?:(?:ال)?رساله\s+|(?:ال)?رسالة\s+)?(?:ل|الى|إلى|لـ)\s*(?<to>[^:،]+?)\s*(?:(?:محتواها|نصها|الرساله|الرسالة)\s*[:=]?|[:،])\s*(?<body>[\s\S]+)$/iu);
  if (match?.groups?.to && match?.groups?.body) return `أرسل الآن | إلى=${match.groups.to.trim()} | الرسالة=${match.groups.body.trim()}`;
  match = value.match(/^(?:ابعت|ابعتلي|ابعث|ابعثلي|تبعت|ترسل|ارسل|أرسل|ارسلي|ابعتي|بعت)\s+(?:(?:ال)?رساله\s+|(?:ال)?رسالة\s+)?(?<body>[\s\S]+?)\s+(?:ل|الى|إلى|لـ)\s*(?<to>[^،:]+)$/iu);
  if (match?.groups?.to && match?.groups?.body) return `أرسل الآن | إلى=${match.groups.to.trim()} | الرسالة=${match.groups.body.trim()}`;
  return '';
}
function prepareCommandInput(input, settings = {}) {
  const original = clean(input, 1000);
  const separatorAt = original.search(/[|\n]/);
  const rawHead = separatorAt < 0 ? original : original.slice(0, separatorAt);
  const tail = separatorAt < 0 ? '' : original.slice(separatorAt);
  const trigger = commandTriggerMatch(original, settings);
  if (settings.commandTriggerEnabled !== false && settings.commandTriggerRequired === true && !trigger.matched) {
    return { text:'', blocked:true, reason:'command-trigger-required' };
  }
  const head = removeCommandTriggers(rawHead, settings);
  // Preserve message text byte-for-byte for a natural send request instead of
  // normalizing/removing Arabic marks from the payload.
  if (separatorAt < 0) {
    const natural = naturalSendCommand(stripConversationalFiller(head));
    if (natural) return { text:natural, blocked:false, triggerMatched:trigger.matched, triggerWords:trigger.words };
  }
  const normalizedHead = canonicalizeCommandHead(head);
  let text = `${normalizedHead}${tail.startsWith('|') ? ' ' : ''}${tail}`.trim();
  if (separatorAt < 0) {
    const naturalSend = naturalSendCommand(text);
    if (naturalSend) text = naturalSend;
  }
  return { text, blocked:false, triggerMatched:trigger.matched, triggerWords:trigger.words };
}

class LocalCommandEngine {
  constructor({ store, whatsapp, delivery, log, saveGroup, normalizeAutomationPayload, interaction = null, refreshRecipientProfile = null }) {
    this.store = store; this.whatsapp = whatsapp; this.delivery = delivery; this.log = log || (() => {});
    this.saveGroup = saveGroup; this.normalizeAutomationPayload = normalizeAutomationPayload; this.interaction = interaction;
    this.refreshRecipientProfile = typeof refreshRecipientProfile === 'function' ? refreshRecipientProfile : null;
    this.messagingConversations = new ConversationManager({ store });
  }
  session(id) { return this.store.loadSession(id); }
  reply(message, action = 'read') { return { handled: true, ok: true, action, response: String(message).slice(0, 3500) }; }
  fail(message, action = 'command') { return { handled: true, ok: false, action, response: `⚠️ لم أنفّذ الأمر: ${message}\nلم أغيّر البيانات. اكتب «مساعدة» لعرض الصيغة الصحيحة.` }; }
  targetKeys(id, raw, { allowAll = false, requireConfirm = false, confirm = '' } = {}) {
    const s = this.session(id), wanted = norm(raw);
    if (!wanted) throw new Error('حدّد المستلم في حقل «إلى=».');
    const people = s.recipients.filter(x => x.enabled !== false), groupItems = s.groups.filter(x => x.enabled !== false);
    if (['الكل','كل المستلمين','الجميع','all'].includes(wanted)) {
      if (!allowAll) throw new Error('هذا الإجراء لا يقبل «الكل»؛ اختر مستلمًا محددًا.');
      if (requireConfirm && norm(confirm) !== 'نعم') throw new Error('الإرسال الجماعي يحتاج الحقل «تأكيد=نعم».');
      return [...people.map(x => `r:${x.id}`), ...groupItems.map(x => `g:${x.id}`)];
    }
    const chunks = String(raw).split(/[,،;؛]/).map(x => x.trim()).filter(Boolean);
    const keys = [];
    for (const chunk of chunks) {
      const q = norm(chunk), digits = normalizedPhoneDigits(chunk);
      const personMatches = people.filter(x => norm(x.name) === q || (digits.length >= 6 && [x.digits, x.phone, x.e164].some(v => String(v || '').replace(/\D/g, '') === digits)));
      const groupMatches = groupItems.filter(x => norm(x.name) === q || String(x.gid || '').toLowerCase() === chunk.toLowerCase());
      const matches = [...personMatches.map(x => ({ key:`r:${x.id}`, name:x.name })), ...groupMatches.map(x => ({ key:`g:${x.id}`, name:x.name }))];
      if (matches.length > 1) throw new Error(`الاسم «${chunk}» غير فريد. استخدم الرقم الكامل أو GID المجموعة.`);
      if (!matches.length) throw new Error(`لم أجد مستلمًا مفعّلًا مطابقًا لـ «${chunk}». أضفه أو فعّله أولًا.`);
      keys.push(matches[0].key);
    }
    const out = [...new Set(keys)];
    if (!out.length) throw new Error('لم يتم تحديد أي مستلم مفعّل.');
    return out;
  }
  async addRecipient(id, text) {
    const fields = parseFields(text);
    let phone = fields.phone || '';
    if (!phone) {
      const m = text.match(/(?:ضيف|اضف|أضف|أضيف|سجل|سجّل|احفظ|أحفظ)\s+(?:لي\s+)?(?:ال)?(?:رقم|شخص|مستلم)\s+(?:ده\s+|هذا\s+)?((?:\+|00)?[\d٠-٩۰-۹][\d٠-٩۰-۹\s().-]{5,24})/iu);
      if (m) phone = m[1].trim();
    }
    if (!phone) throw new Error('استخدم: أضف الرقم 7345 xxxx باسم أحمد، أو «رقم=… | الاسم=…».');
    phone = phone.replace(/\s+(?:باسم|اسم)\s+.*$/iu, '').trim();
    let name = fields.name || '';
    if (!name) {
      const nm = text.match(/(?:باسم|اسم)\s*[=:]?\s*(.+)$/iu);
      if (nm) name = clean(nm[1], 80);
    }
    const country = String(fields.country || 'OM').toUpperCase();
    const parsed = require('./phones').parse(phone, country);
    const s = this.session(id);
    const exists = s.recipients.find(x => String(x.e164 || '').replace(/\D/g, '') === parsed.digits || String(x.digits || x.phone || '').replace(/\D/g, '') === parsed.digits);
    if (exists) throw new Error(`الرقم موجود بالفعل باسم «${exists.name}»؛ لم أضف نسخة مكررة.`);
    name = clean(name || `رقم ${parsed.digits.slice(-4)}`, 80);
    const recipient = { id: crypto.randomUUID(), name, ...parsed, phone: parsed.digits, enabled: true, createdAt: new Date().toISOString(), source: 'owner-command' };
    s.recipients.push(recipient); s.setupComplete = true; this.store.saveSession(s);
    const verified = this.session(id).recipients.find(x => x.id === recipient.id);
    if (!verified) throw new Error('تعذّر التحقق من حفظ المستلم؛ أعد المحاولة من لوحة الأشخاص.');
    this.log(id, 'INFO', `أضاف المالك مستلمًا عبر الأمر المحلي: ${name}`);
    return this.reply(`✅ تمت إضافة الرقم فعليًا وحفظه في الجلسة «${s.name}».\nالاسم: ${name}\nالرقم: ${parsed.international}\nالمعرّف: ${recipient.id}`, 'add-recipient');
  }
  async groupCommand(id, text) {
    if (/^(?:اعرض|اظهر|أظهر|قائمة)?\s*(?:المجموعات|مجموعاتي|قروباتي)\s*$/iu.test(text)) {
      const s = this.session(id);
      return this.reply(`المجموعات المحفوظة (${s.groups.length}):\n${s.groups.length ? s.groups.map((g,i)=>`${i+1}. ${g.name} | ${g.gid} | ${g.enabled?'مفعّلة':'متوقفة'}`).join('\n') : 'لا توجد مجموعات محفوظة. اكتب «اكتشف المجموعات» أو أرسل رابط دعوة.'}`, 'list-groups');
    }
    if (!this.whatsapp.listRuntime(id).ready) throw new Error('اربط WhatsApp في هذه الجلسة أولًا؛ تحليل الروابط يحتاج اتصالًا حيًا.');
    const invite = text.match(/(?:https?:\/\/)?chat\.whatsapp\.com\/[A-Za-z0-9_-]+/i);
    const gid = text.match(/\d{5,25}(?:-\d+)*@g\.us/i);
    if (invite) {
      const inviteCode = groups.extractInviteCode(invite[0]);
      let info = await this.whatsapp.analyzeGroupInvite(id, inviteCode);
      if (info?.gid) { try { info = await this.whatsapp.getGroupInfo(id, groups.normalizeGid(info.gid)); } catch {} }
      if (info?.gid && groups.isGroupId(info.gid)) {
        const saved = this.saveGroup(id, { ...info, inviteCode });
        const confirmed = this.session(id).groups.find(x => x.gid === saved.gid);
        if (!confirmed) throw new Error('حلّل WhatsApp الدعوة لكن لم يتم التحقق من حفظ المجموعة.');
        return this.reply(`✅ تم تحليل المجموعة وحفظها فعليًا.\n${groups.formatGroupAnalysis(confirmed)}`, 'analyze-group');
      }
      return this.reply(`تم تحليل رابط الدعوة، لكن WhatsApp لم يعطِ GID يسمح بحفظ المجموعة بعد.\nالاسم: ${info?.name || 'غير متاح'}\nالوصف: ${info?.description || 'غير متاح'}\nالأعضاء: ${info?.participantsCount ?? 'غير متاح'}\nلم أحفظها كمجموعة قابلة للإرسال لأن معرفها غير مؤكد. افتح المجموعة في WhatsApp ثم أرسل «اكتشف المجموعات».`, 'analyze-invite');
    }
    if (gid) {
      let info = await this.whatsapp.getGroupInfo(id, groups.normalizeGid(gid[0]));
      const saved = this.saveGroup(id, info);
      const verified=this.session(id).groups.find(x=>x.gid===saved.gid);
      if(!verified)throw new Error('تم الاتصال بالمجموعة لكن لم يتم التحقق من حفظها داخل الجلسة.');
      return this.reply(`✅ تمت إضافة المجموعة وحفظ معلوماتها فعليًا.\n${groups.formatGroupAnalysis(verified)}`, 'add-group');
    }
    if (/اكتشف المجموعات|اكتشاف المجموعات|حدّث المجموعات|حدث المجموعات/i.test(text)) {
      const found = await this.whatsapp.listGroups(id), valid = found.filter(x => x?.gid && groups.isGroupId(x.gid));
      const saved = valid.map(x => this.saveGroup(id, x));
      if (saved.length !== valid.length) throw new Error('لم تُحفظ كل المجموعات المكتشفة؛ راجع سجل الجلسة.');
      return this.reply(`✅ اكتمل اكتشاف المجموعات وحُفظ ${saved.length} مجموعة في هذه الجلسة.\n${saved.slice(0, 15).map((g,i)=>`${i+1}. ${g.name} — ${g.gid}`).join('\n')}${saved.length>15?'\n… توجد مجموعات أخرى في صفحة المجموعات.':''}`, 'discover-groups');
    }
    throw new Error('أرسل رابط chat.whatsapp.com أو GID ينتهي بـ @g.us، أو اكتب «اكتشف المجموعات».');
  }
  async scheduleCommand(id, text) {
    const s = this.session(id), f = parseFields(text), low = norm(text);
    if (/اعرض المواعيد|المواعيد|جدولتي|مواعيدي/.test(low) && !/اضف|أضف|انشئ|إنشئ|موعد\s*\|/.test(low)) {
      const tasks = s.automation.tasks || [];
      return this.reply(`المواعيد المحفوظة (${tasks.length}):\n${tasks.length ? tasks.map((t,i)=>`${i+1}. ${t.name} | ${t.mode} | ${t.date || 'متكرر'} ${t.time} | ${t.enabled?'مفعّل':'متوقف'} | ID=${t.id}`).join('\n') : 'لا توجد مواعيد.'}`, 'list-schedules');
    }
    const modeText = norm(f.repeat || (low.includes('اسبوع') ? 'أسبوعي' : low.includes('شهري') ? 'شهري' : low.includes('سنوي') ? 'سنوي' : 'مرة'));
    const mode = /اسبوع|weekly/.test(modeText) ? 'weekly' : /شهري|monthly/.test(modeText) ? 'monthly' : /سنوي|yearly/.test(modeText) ? 'yearly' : 'once';
    const time = f.time || '';
    if (!time) throw new Error('حدد الوقت بصيغة 24 ساعة: الوقت=18:30.');
    if (mode === 'once' && !/^\d{4}-\d{2}-\d{2}$/.test(f.date || '')) throw new Error('الموعد مرة واحدة يحتاج التاريخ=YYYY-MM-DD.');
    const targetsRaw = f.to || '';
    const targetKeys = this.targetKeys(id, targetsRaw, { allowAll:true, requireConfirm:true, confirm:f.confirm || '' });
    const selectedFiles = [];
    const files = this.delivery.files(id);
    const fileRaw = f.file || f.files || '';
    let mediaMode = /دورة|الحالية|cycle/i.test(fileRaw) ? 'cycle' : 'selected';
    if (fileRaw && mediaMode !== 'cycle') {
      const names = fileRaw.split(/[,،;؛]/).map(x=>x.trim()).filter(Boolean);
      for (const name of names) {
        const matches = files.filter(file => norm(file.id) === norm(name) || norm(file.filename) === norm(name) || norm(file.filename).includes(norm(name)));
        if (matches.length !== 1) throw new Error(`اسم الملف «${name}» غير موجود أو غير فريد. استخدم الاسم الكامل من قائمة «الوسائط».`);
        selectedFiles.push(matches[0].id);
      }
    }
    const textValue = f.text || '';
    if (!textValue && !selectedFiles.length && mediaMode !== 'cycle') throw new Error('أضف الرسالة=... أو ملف=اسم_الملف، أو ملف=الدورة.');
    const body = {
      name: f.name || 'موعد من WhatsApp', mode, date: f.date || '', time, day: weekdayNumber(f.day ?? f.repeat) ?? 5,
      dayOfMonth: Number(f.dayOfMonth || f.day || 1), month: Number(f.month || 1), year: f.year || '', timezone:s.settings.timezone,
      targetKeys, mediaIds:selectedFiles, mediaMode, text:textValue, textMode: norm(f.textMode || '').includes('تعليق') ? 'caption' : 'auto',
      captionMode:true, sendAsDocument:/مرفق|مستند|document/i.test(text), preText:'', postText:'', sendDelayMs:s.settings.sendDelayMs,
      graceMinutes:30, scheduledGroupsEnabled:true, sendOrder:'target-first',
    };
    const task = this.normalizeAutomationPayload(id, body);
    s.automation.tasks.push(task); s.automation.enabled = true; this.store.saveSession(s);
    const saved = this.session(id).automation.tasks.find(t=>t.id===task.id);
    if (!saved) throw new Error('لم أستطع التحقق من حفظ الموعد.');
    const scope = mode === 'once' ? `بتاريخ ${task.date}` : mode === 'weekly' ? `كل أسبوع (اليوم ${task.day})` : mode === 'monthly' ? `كل شهر (اليوم ${task.dayOfMonth})` : `كل سنة (الشهر ${task.month}، اليوم ${task.dayOfMonth})`;
    return this.reply(`✅ حُفظ الموعد فعليًا وأصبح لدى المجدول.\nالاسم: ${task.name}\nالوقت: ${task.time} (${s.settings.timezone})\nالتكرار: ${scope}\nالأهداف: ${task.targetKeys.length}\nالملفات: ${task.mediaIds.length}${task.mediaMode==='cycle'?' (دورة الصور)':''}\nالمهمة: ${task.id}\nمهم: يبقى التطبيق والخادم يعملان وقت الموعد.`, 'create-schedule');
  }
  saveConversation(id, conversation) {
    const s = this.session(id);
    s.ownerAssistant.conversation = conversation || null;
    this.store.saveSession(s);
    return s.ownerAssistant.conversation;
  }
  isAddRecipientWizardIntent(text) {
    const value = norm(text);
    if (!value || /(?:رقم\s*[=:]|الاسم\s*[=:]|الدولة\s*[=:])/.test(value)) return false;
    if (/(?:\+|00)?\d[\d\s().-]{6,}/u.test(text) && /(?:اضف|اضيف|ضيف|سجل|احفظ)/u.test(value)) return false;
    const action = /^(?:(?:انا\s+)?(?:عايز|عاوزه|عاوز|عاوزة|اريد|محتاج|محتاجه|ابغى|ممكن)\s+(?:اني\s+)?(?:اضيف|اضف|ضيف|سجل|احفظ|اضافه|اضافة)|اضيف|اضف|ضيف|سجل|احفظ|اضافه|اضافة)(?=\s|$)/u.test(value);
    const target = /(?:رقم|مستخدم|مستلم|شخص|جهة اتصال|جهات الاتصال|contact|recipient)/u.test(value);
    return action && target;
  }
  isSendWizardIntent(text) {
    const raw = String(text || '').trim(), value = norm(raw);
    if (!value || /[|\n]/u.test(raw) || naturalSendCommand(raw)) return false;
    return /^(?:(?:انا\s+)?(?:عايز|عاوزه|عاوز|عاوزة|اريد|محتاج|محتاجه|ممكن|لو\s+سمحت)\s+)*(?:ابعت|ابعتلي|ابعث|ابعثلي|ارسل|ارسلي|ابعتي|بعت|send)(?:\s+(?:لي|لنا))?(?:\s+(?:رساله|رسالة))?$/u.test(value)
      || /^(?:(?:انا\s+)?(?:عايز|عاوزه|عاوز|عاوزة|اريد|محتاج|محتاجه|ممكن)\s+)+(?:رساله|رسالة)(?:\s+للبوت)?$/u.test(value);
  }
  isScheduleWizardIntent(text) {
    const raw = String(text || '').trim(), value = norm(raw);
    if (!value || /[|\n]/u.test(raw)) return false;
    return /^(?:(?:انا\s+)?(?:عايز|عاوزه|عاوز|عاوزة|اريد|محتاج|ممكن|لو\s+سمحت)\s+)*(?:(?:اعمل|انشئ|اضيف|ضيف|جدول|احجز|سوي)\s+)?(?:موعدا?|تذكيرا?|رساله\s+مجدوله|رسالة\s+مجدولة)(?:\s+(?:جديد|جديده|جديدة))?$/u.test(value);
  }
  isInteractionWizardIntent(text) {
    const raw = String(text || '').trim(), value = norm(raw);
    if (!value || /[|\n]/u.test(raw)) return false;
    return /^(?:(?:انا\s+)?(?:عايز|عاوزه|عاوز|عاوزة|اريد|محتاج|ممكن|لو\s+سمحت)\s+)*(?:(?:اعمل|انشئ|اضيف|ضيف|سجل|حط|سوي)\s+)?(?:ردا?\s+تلقائيا?(?:\s+جديد)?|قاعده\s+تفاعل|قاعدة\s+تفاعل|ردود\s+تلقائيه)$/u.test(value);
  }
  async handleAdvancedConversationInput(id, text, flow) {
    const value = clean(text, 3500), normalized = norm(value);
    if (normalized === 'مساعدة' || normalized === 'help' || normalized === 'ازاي اكمل' || normalized === 'كيف اكمل') {
      const steps = {
        'send-message': 'أرسل اسم المستلم أو عدة أسماء محفوظة. بعد التحقق سأطلب نص الرسالة ثم أرسلها مرة واحدة.',
        'add-schedule': 'خطوات الموعد: الاسم، التاريخ بصيغة YYYY-MM-DD، الوقت 24 ساعة، المستلم المحفوظ، ثم نص الرسالة. لن يُحفظ إلا بعد التحقق من التاريخ والوقت والمستلم.',
        'add-interaction-rule': 'خطوات قاعدة الرد: العبارة التي يجب أن تظهر في الرسالة، ثم نص الرد. سأحفظ القاعدة وأفعّل نظام التفاعل إذا كان متوقفًا.',
      };
      return this.reply(`ℹ️ ${steps[flow.type] || 'أكمل الحقل الظاهر أو اكتب إلغاء.'}\nيمكنك كتابة «إلغاء» في أي وقت. لم أغيّر شيئًا في هذه الخطوة.`, 'conversation-help');
    }
    const age = Date.now() - Date.parse(flow.updatedAt || flow.startedAt || 0);
    if (!Number.isFinite(age) || age > 30 * 60 * 1000) {
      this.saveConversation(id, null);
      return this.reply('انتهت صلاحية خطوات العملية بعد 30 دقيقة. لم أُكمل أي إرسال أو حفظ. ابدأ من جديد بكتابة «أرسل رسالة» أو «أنشئ موعدًا» أو «أنشئ ردًا تلقائيًا».', 'conversation-expired');
    }
    if (!value) return this.reply('الرد فارغ. اكتب قيمة للحقل المطلوب، أو «إلغاء» للتراجع دون تنفيذ.', 'conversation-invalid');
    flow.updatedAt = new Date().toISOString();

    if (flow.type === 'send-message') {
      if (flow.step === 'target') {
        let targetKeys;
        try { targetKeys = this.targetKeys(id, value, { allowAll:false }); }
        catch (error) { return this.reply(`لم أتعرف على المستلم «${value.slice(0,100)}».\n${clean(error.message || error, 300)}\nاكتب اسم الشخص أو المجموعة كما يظهر في «اعرض الأشخاص» أو «اعرض المجموعات». لن أرسل قبل تأكيد الهدف.`, 'conversation-invalid-target'); }
        if (!targetKeys.length) return this.reply('لم أجد هدفًا محفوظًا ومفعّلًا. اكتب «اعرض الأشخاص» أو «اعرض المجموعات» ثم أرسل الاسم كما هو.', 'conversation-invalid-target');
        flow.data.to = value; flow.data.targetKeys = targetKeys; flow.step = 'message';
        this.saveConversation(id, flow);
        return this.reply(`✅ تم التعرف على المستلم (${targetKeys.length}).\n\nالخطوة 2/2 — **نص الرسالة**\nاكتب النص الذي تريد إرساله. سأعرض نتيجة الإرسال وعدد الناجح والفاشل، ولن أعيد الإرسال تلقائيًا عند الشك.`, 'conversation-send-target');
      }
      if (flow.step === 'message') {
        const body = clean(value, 3500);
        try {
          const result = await this.delivery.sendNow(id, { targetKeys:flow.data.targetKeys || [], mediaIds:[], text:body, textMode:'auto', captionMode:true, repeatGuard:true, sendDelayMs:this.session(id).settings.sendDelayMs });
          const sent = Array.isArray(result.sent) ? result.sent.length : 0, failed = Array.isArray(result.failed) ? result.failed.length : 0;
          this.saveConversation(id, null);
          if (failed || result.ok === false) return this.reply(`${sent ? '⚠️ اكتمل الإرسال جزئيًا' : '❌ فشل الإرسال'}: نجح ${sent} وفشل ${failed}.\n${(result.failed || []).slice(0,5).map(item => `${item.target || 'هدف'}: ${item.error || 'خطأ'}`).join('\n') || result.error || 'لم يؤكد محرك الإرسال النتيجة.'}\nراجِع النتائج قبل إعادة المحاولة حتى لا تتكرر الرسالة.`, 'conversation-send-result');
          return this.reply(`✅ اكتمل الإرسال.\nالمستلمون المحددون: ${(flow.data.targetKeys || []).length}\nالعمليات الناجحة: ${sent}\nالنص: ${body.slice(0,220)}${body.length > 220 ? '…' : ''}`, 'conversation-send-result');
        } catch (error) {
          this.saveConversation(id, null);
          return this.reply(`تعذّر تأكيد الإرسال: ${clean(error.message || error, 450)}\nأوقفت المحاولة ولم أعِد إرسالها تلقائيًا منعًا للتكرار. راجع سجل الإرسال قبل اتخاذ خطوة أخرى.`, 'conversation-send-error');
        }
      }
    }

    if (flow.type === 'add-schedule') {
      if (flow.step === 'name') {
        flow.data.name = clean(value, 100);
        flow.step = 'date'; this.saveConversation(id, flow);
        return this.reply(`✅ اسم الموعد: «${flow.data.name}».\n\nالخطوة 2/5 — **التاريخ**\nاكتب تاريخًا بصيغة YYYY-MM-DD (مثال توضيحي: 2026-10-20). يُتحقق من أن التاريخ موجود فعلًا ولم ينتهِ.`, 'conversation-schedule-name');
      }
      if (flow.step === 'date') {
        const date = value.match(/\b(\d{4}-\d{2}-\d{2})\b/)?.[1] || '';
        const parsedDate = date ? new Date(`${date}T00:00:00.000Z`) : null;
        if (!date || !parsedDate || Number.isNaN(parsedDate.getTime()) || parsedDate.toISOString().slice(0,10) !== date) return this.reply('التاريخ غير صالح. استخدم YYYY-MM-DD مثل 2026-10-20؛ لا أحفظ الموعد قبل التحقق من التاريخ.', 'conversation-invalid-date');
        flow.data.date = date; flow.step = 'time'; this.saveConversation(id, flow);
        return this.reply(`✅ التاريخ ${date}.\n\nالخطوة 3/5 — **الوقت**\nاكتب الوقت بنظام 24 ساعة مثل 18:30. سيُستخدم توقيت الجلسة: ${this.session(id).settings.timezone || 'Asia/Muscat'}.`, 'conversation-schedule-date');
      }
      if (flow.step === 'time') {
        const time = value.match(/\b([01]\d|2[0-3]):([0-5]\d)\b/)?.[0] || '';
        if (!time) return this.reply('الوقت غير صالح. اكتب الساعة والدقيقة بصيغة 24 ساعة، مثل 18:30.', 'conversation-invalid-time');
        flow.data.time = time; flow.step = 'target'; this.saveConversation(id, flow);
        return this.reply(`✅ الوقت ${time}.\n\nالخطوة 4/5 — **المستلم**\nاكتب اسم شخص أو مجموعة محفوظة في المشروع. لا أرسل أو أجدول إلى «الكل» من خلال هذا المسار لمنع الإرسال العرضي.`, 'conversation-schedule-time');
      }
      if (flow.step === 'target') {
        let targetKeys;
        try { targetKeys = this.targetKeys(id, value, { allowAll:false }); }
        catch (error) { return this.reply(`لم أتعرف على الهدف. ${clean(error.message || error, 250)}\nاكتب اسمًا محفوظًا كما هو، أو أوقف العملية بكلمة «إلغاء».`, 'conversation-invalid-target'); }
        if (!targetKeys.length) return this.reply('لم يتم تحديد أي مستلم صالح. اكتب اسم شخص أو مجموعة محفوظة.', 'conversation-invalid-target');
        flow.data.to = value; flow.data.targetKeys = targetKeys; flow.step = 'message'; this.saveConversation(id, flow);
        return this.reply(`✅ تم تحديد ${targetKeys.length} مستلم.\n\nالخطوة 5/5 — **نص الموعد**\nاكتب الرسالة التي تريد إرسالها عند ${flow.data.date} الساعة ${flow.data.time}.`, 'conversation-schedule-target');
      }
      if (flow.step === 'message') {
        const s = this.session(id);
        try {
          const body = { name:flow.data.name, mode:'once', date:flow.data.date, time:flow.data.time, day:5, dayOfMonth:1, month:1, year:'', timezone:s.settings.timezone || 'Asia/Muscat', targetKeys:flow.data.targetKeys || [], mediaIds:[], mediaMode:'selected', text:value, textMode:'auto', captionMode:true, sendAsDocument:false, preText:'', postText:'', sendDelayMs:s.settings.sendDelayMs, graceMinutes:30 };
          const task = this.normalizeAutomationPayload(id, body);
          s.automation.tasks.push(task); s.automation.enabled = true; s.ownerAssistant.conversation = null; this.store.saveSession(s);
          const saved = this.session(id).automation.tasks.find(item => item.id === task.id);
          if (!saved) throw new Error('لم يتم التحقق من حفظ الموعد داخل الجلسة.');
          return this.reply(`✅ تم إنشاء الموعد وحفظه للمجدول.\nالاسم: ${saved.name}\nالموعد: ${saved.date} ${saved.time} (${s.settings.timezone || 'Asia/Muscat'})\nالمستلمون: ${saved.targetKeys.length}\nالمهمة: ${saved.id}\nمهم: يجب أن يبقى التطبيق والخادم متصلين وقت الإرسال.`, 'conversation-schedule-result');
        } catch (error) {
          this.saveConversation(id, null);
          return this.reply(`تعذر حفظ الموعد: ${clean(error.message || error, 450)}\nلم أؤكد الحفظ. راجع «اعرض المواعيد» قبل إنشاء موعد آخر.`, 'conversation-schedule-error');
        }
      }
    }

    if (flow.type === 'add-interaction-rule') {
      if (flow.step === 'when') {
        flow.data.when = clean(value, 500);
        flow.step = 'reply'; this.saveConversation(id, flow);
        return this.reply(`✅ شرط المطابقة: «${flow.data.when}».\n\nالخطوة 2/2 — **الرد**\nاكتب الرد الذي يرسله البوت عند ورود رسالة تحتوي هذه العبارة. يمكنك استخدام {{sender}} لاسم الشخص المسجل و{{message}} لنص رسالته.`, 'conversation-rule-trigger');
      }
      if (flow.step === 'reply') {
        const s = this.session(id);
        try {
          const rule = { id:crypto.randomUUID(), name:`قاعدة من الشات ${new Date().toLocaleDateString('en-CA')}`, enabled:true, priority:10, when:{ type:'message', match:'contains', value:flow.data.when, ignoreCase:true }, then:{ reply:clean(value,1000), reaction:'' }, scope:'all', chatIds:[], cooldownSec:30 };
          require('./interaction').valid(rule);
          s.interaction.rules.push(rule); s.interaction.enabled = true; s.settings.interactionEnabled = true; s.ownerAssistant.conversation = null; this.store.saveSession(s);
          const checked = this.session(id).interaction.rules.find(item => item.id === rule.id);
          if (!checked) throw new Error('لم يتم التحقق من حفظ القاعدة.');
          return this.reply(`✅ تم حفظ قاعدة الرد وتفعيل التفاعل.\nعندما تحتوي الرسالة: «${checked.when.value}»\nالرد: «${checked.then.reply}»\nالنطاق: كل المحادثات\nID=${checked.id}\nيمكنك تعديلها أو إيقافها من الموقع أو اكتب «اعرض قواعد التفاعل».`, 'conversation-rule-result');
        } catch (error) {
          this.saveConversation(id, null);
          return this.reply(`تعذر حفظ قاعدة الرد: ${clean(error.message || error, 450)}\nلم أتأكد من وجودها. اكتب «اعرض قواعد التفاعل» قبل إعادة المحاولة.`, 'conversation-rule-error');
        }
      }
    }
    this.saveConversation(id, null);
    return this.reply('انتهت خطوات العملية. لم أنفذ إجراءً غير محدد؛ اكتب «مساعدة» للبدء من جديد.', 'conversation-reset');
  }
  async handleConversationInput(id, text) {
    const s = this.session(id), existing = s.ownerAssistant.conversation;
    const cancel = /^(?:الغاء|إلغاء|الغي|ألغ|الغِ|cancel|الغاء العملية|إلغاء العملية|وقف المحادثة)$/iu.test(text.trim());
    if (cancel) {
      if (!existing) return this.reply('لا توجد خطوات معلّقة لإلغائها. اكتب «مساعدة» لرؤية ما أستطيع تنفيذه.', 'conversation-cancel');
      s.ownerAssistant.conversation = null; this.store.saveSession(s);
      return this.reply('✅ ألغيت العملية الحوارية. لم أكمل إرسالًا أو إنشاء موعد أو قاعدة من هذه الخطوات، ولم أغيّر بياناتها.', 'conversation-cancel');
    }
    let flow = existing;
    if (!flow && this.isSendWizardIntent(text)) {
      flow = { type:'send-message', step:'target', data:{}, startedAt:new Date().toISOString(), updatedAt:new Date().toISOString() };
      s.ownerAssistant.conversation = flow; this.store.saveSession(s);
      return this.reply('تمام، سنرسل رسالة بخطوتين واضحتين.\n\nالخطوة 1/2 — **المستلم**\nاكتب اسم شخص أو مجموعة محفوظة في المشروع. لن أرسل إلى كل القائمة من دون أمر وتأكيد منفصلين.\nللتراجع اكتب «إلغاء».', 'conversation-send-start');
    }
    if (!flow && this.isScheduleWizardIntent(text)) {
      flow = { type:'add-schedule', step:'name', data:{}, startedAt:new Date().toISOString(), updatedAt:new Date().toISOString() };
      s.ownerAssistant.conversation = flow; this.store.saveSession(s);
      return this.reply('تمام، سننشئ موعدًا لمرة واحدة على خمس خطوات.\n\nالخطوة 1/5 — **اسم الموعد**\nاكتب اسمًا يسهّل عليك العثور عليه لاحقًا، مثل «تذكير الدراسة».\nلن يتم حفظ الموعد حتى نتحقق من التاريخ والوقت والمستلم والرسالة.', 'conversation-schedule-start');
    }
    if (!flow && this.isInteractionWizardIntent(text)) {
      flow = { type:'add-interaction-rule', step:'when', data:{}, startedAt:new Date().toISOString(), updatedAt:new Date().toISOString() };
      s.ownerAssistant.conversation = flow; this.store.saveSession(s);
      return this.reply('تمام، سننشئ ردًا تلقائيًا بخطوتين.\n\nالخطوة 1/2 — **متى يرد البوت؟**\nاكتب كلمة أو عبارة يجب أن تظهر في رسالة المستخدم، مثل «السلام عليكم». ستكون المطابقة «تحتوي» حتى تعمل مع الجملة الأطول أيضًا.\nللتراجع اكتب «إلغاء».', 'conversation-rule-start');
    }
    if (!flow && this.isAddRecipientWizardIntent(text)) {
      flow = { type:'add-recipient', step:'name', data:{}, startedAt:new Date().toISOString(), updatedAt:new Date().toISOString() };
      s.ownerAssistant.conversation = flow; this.store.saveSession(s);
      return this.reply('تمام، سنضيف رقم مستخدم جديد على 3 خطوات.\n\nالخطوة 1/3 — **اسم المستخدم**\nاكتب الاسم الذي تريد ظهوره في قائمة الأشخاص، مثل: أحمد.\nسأستخدم هذا الرد كقيمة «الاسم». لن أضيف أي رقم قبل التحقق من الدولة ورقم الهاتف.\nللتراجع في أي وقت اكتب «إلغاء».', 'conversation-start');
    }
    if (!flow) return null;
    if (flow.type !== 'add-recipient') return this.handleAdvancedConversationInput(id, text, flow);
    const age = Date.now() - Date.parse(flow.updatedAt || flow.startedAt || 0);
    if (!Number.isFinite(age) || age > 30 * 60 * 1000) {
      s.ownerAssistant.conversation = null; this.store.saveSession(s);
      return this.reply('انتهت صلاحية خطوات الإضافة بعد 30 دقيقة لحماية البيانات من استخدام رد قديم. لم أضف شيئًا. ابدأ بكتابة «عايز أضيف رقم مستخدم جديد».', 'conversation-expired');
    }
    if (norm(text) === 'مساعدة' || norm(text) === 'help') return this.reply(`${HELP}\n\nالعملية الحالية ما زالت محفوظة؛ أكمل الحقل المطلوب أو اكتب «إلغاء».`, 'help');

    if (flow.step === 'name') {
      const name = clean(text, 80);
      if (!name || name.length < 2 || /(?:\+|00)?\d[\d\s().-]{6,}/u.test(name)) {
        return this.reply('لم أقبل الاسم لأنّه فارغ أو يبدو كأنه رقم هاتف.\nالخطوة 1/3 — اكتب اسمًا واضحًا من حرفين على الأقل، مثل: أحمد. لم يتم حفظ أي رقم.', 'conversation-invalid-name');
      }
      flow.data = { name };
      flow.step = 'country'; flow.updatedAt = new Date().toISOString();
      this.saveConversation(id, flow);
      return this.reply(`✅ فهمت الاسم: «${name}».\n\nالخطوة 2/3 — **الدولة**\nاكتب الدولة التي ينتمي إليها رقم ${name}، مثل: عمان، السعودية، مصر، الإمارات، أو رمز ISO مثل OM/SA/EG/AE.\nسأستخدم هذا الرد لتفسير الرقم المحلي والتحقق من صحته؛ لم تتم إضافة جهة الاتصال بعد.`, 'conversation-name');
    }

    if (flow.step === 'country') {
      if (/(?:الدولة|البلد).*(?:غلط|خطأ|خطا|تغيير)|^(?:رجوع|ارجع)$/iu.test(text)) {
        return this.reply('نحن في خطوة الدولة. اكتب اسم الدولة الصحيح أو رمزها مثل عمان/OM أو السعودية/SA. لم يتم حفظ الرقم.', 'conversation-country');
      }
      const country = resolveCountry(text);
      if (!country) {
        return this.reply(`لم أتعرف على الدولة «${clean(text,60)}»، لذلك لم أغيّر شيئًا.\nالخطوة 2/3 — أرسل اسم دولة واضحًا مثل عمان أو السعودية أو مصر، أو رمزًا من حرفين مثل OM أو SA أو EG. يمكنك كتابة «إلغاء» للتراجع.`, 'conversation-invalid-country');
      }
      flow.data.countryCode = country.code; flow.data.countryName = country.name;
      flow.step = 'phone'; flow.updatedAt = new Date().toISOString();
      this.saveConversation(id, flow);
      return this.reply(`✅ تم فهم الدولة: ${country.name} (${country.code}).\n\nالخطوة 3/3 — **رقم الهاتف**\nأرسل رقم ${flow.data.name} مع أو بدون رمز الدولة، مثل: ${country.code === 'OM' ? '7345 xxxx' : 'رقم الهاتف المحلي أو الرقم الدولي الذي يبدأ بعلامة +'} .\nسأتحقق من صلاحية الرقم واتساقه مع ${country.name} وأمنع التكرار. لن أحفظه إن كان غير صالح.`, 'conversation-country');
    }

    if (flow.step === 'phone') {
      if (/(?:الدولة|البلد).*(?:غلط|خطأ|خطا|مش صح|تغيير)/iu.test(text)) {
        flow.step = 'country'; flow.updatedAt = new Date().toISOString(); this.saveConversation(id, flow);
        return this.reply(`حسنًا، نرجع إلى خطوة الدولة مع الاحتفاظ بالاسم «${flow.data.name}». اكتب الدولة الصحيحة مثل عمان أو السعودية أو رمزها OM/SA. لم يُحفظ الرقم بعد.`, 'conversation-country-correction');
      }
      const rawPhone = extractPhone(text) || clean(text, 40);
      let parsed;
      try { parsed = require('./phones').parse(rawPhone, flow.data.countryCode); }
      catch (error) {
        return this.reply(`❌ رقم الهاتف غير صالح للدولة المحددة (${flow.data.countryName}). لم أحفظ أي جهة اتصال.\n\nأعد إرسال رقم صحيح في الخطوة 3/3، مثل ${flow.data.countryCode === 'OM' ? '7345 xxxx' : 'رقم دولي يبدأ بعلامة +'} . إذا كانت الدولة نفسها خطأ، اكتب «الدولة غلط» ثم أدخلها من جديد.`, 'conversation-invalid-phone');
      }
      const explicitInternational = /^\s*(?:\+|00)/u.test(rawPhone);
      if (explicitInternational && parsed.country && parsed.country !== flow.data.countryCode) {
        return this.reply(`❌ رمز الرقم الدولي يطابق دولة مختلفة: الرقم يعرّف دولة ${parsed.country} وليس ${flow.data.countryName} (${flow.data.countryCode}). لم أحفظ الرقم.\nأرسل رقمًا تابعًا لـ ${flow.data.countryName} أو اكتب «الدولة غلط» لاختيار دولة أخرى.`, 'conversation-country-mismatch');
      }
      const latest = this.session(id);
      const exists = latest.recipients.find(x => String(x.e164 || '').replace(/\D/g,'') === parsed.digits || String(x.digits || x.phone || '').replace(/\D/g,'') === parsed.digits);
      if (exists) {
        return this.reply(`هذا الرقم محفوظ بالفعل باسم «${exists.name}». لم أضف نسخة مكررة.\nأرسل رقمًا آخر لـ «${flow.data.name}»، أو اكتب «إلغاء».`, 'conversation-duplicate-phone');
      }
      try {
        const outcome = await this.addRecipient(id, `رقم=${rawPhone} | الاسم=${flow.data.name} | الدولة=${flow.data.countryCode}`);
        const verify = this.session(id).recipients.find(x => String(x.e164 || '').replace(/\D/g,'') === parsed.digits);
        if (!verify) throw new Error('لم يظهر الرقم في قائمة الأشخاص بعد الحفظ.');
        const fresh = this.session(id); fresh.ownerAssistant.conversation = null; this.store.saveSession(fresh);
        return this.reply(`${outcome.response}\n\n🎉 اكتملت الخطوات 3/3 وتم التحقق من حفظ جهة الاتصال.\nالقيم التي استُخدمت: الاسم=${verify.name} | الدولة=${verify.country || flow.data.countryCode} | الرقم=${verify.international || verify.e164}.\nيمكنك الآن كتابة «اعرض الأشخاص» لرؤية القائمة.`, 'conversation-add-recipient');
      } catch (error) {
        return this.reply(`تعذّر إكمال الإضافة: ${clean(error.message || error, 450)}\nلم تُحفظ جهة اتصال جديدة. أرسل رقمًا آخر صحيحًا أو اكتب «إلغاء».`, 'conversation-invalid-phone');
      }
    }
    s.ownerAssistant.conversation = null; this.store.saveSession(s);
    return this.reply('انتهت حالة المحادثة القديمة. اكتب «عايز أضيف رقم مستخدم جديد» للبدء من جديد.', 'conversation-reset');
  }
  faqResponse(text) {
    const value = norm(text);
    if (/^(?:السلام عليكم|السلام عليكم ورحمة الله وبركاته|مرحبا|مرحبا بك|اهلا|اهلين|صباح الخير|مساء الخير|hi|hello|hey)$/u.test(value))
      return this.reply('وعليكم السلام وأهلًا بك 👋\nأنا مساعد محلي داخل chat BOT. اكتب «مساعدة» للدليل، أو «عايز أضيف رقم مستخدم جديد» للبدء بحوار الاسم ثم الدولة ثم الرقم. كل خطوة تشرح لك ما يجب إرساله.', 'faq-greeting');
    if (/(?:ماذا|ايش|وش|ايه|ما هي|ماهي).{0,24}(?:تستطيع|تقدر|تعمل|وظيف|اوامر|مساعد)|(?:قدرات|وظائف) (?:البوت|المساعد)/u.test(value))
      return this.reply('أقدر محليًا إدارة الأرقام والمجموعات والمواعيد والوسائط، وتشغيل الإرسال بعد ربط WhatsApp، وإدارة قواعد تفاعل محفوظة. لا أستخدم API ذكاء اصطناعي لتلك الأوامر. اكتب «مساعدة» للدليل المنظم، أو ابدأ بعبارة «عايز أضيف رقم مستخدم جديد».', 'faq-capabilities');
    if (/(?:كيف|ازاي|ازاى|شلون|طريقة).{0,30}(?:اضيف|اضافه|رقم|مستخدم)/u.test(value))
      return this.reply('لإضافة رقم بالمحادثة، اكتب بالضبط: «عايز أضيف رقم مستخدم جديد». سأطلب الاسم، ثم الدولة، ثم رقم الهاتف. كل رد يكون قيمة الحقل الذي أطلبه، وسأرفض الدولة/الرقم غير الصحيح دون حفظ.', 'faq-add-recipient');
    if (/(?:كيف|ازاي|ازاى|شلون|طريقة).{0,30}(?:ربط|حساب|رقم).{0,20}(?:ثاني|تاني|اخر|آخر)/u.test(value) || /(?:رقم ثاني|رقم تاني|حساب ثاني|حساب تاني)/u.test(value))
      return this.reply('لربط رقم آخر تملكه: اكتب «أنشئ جلسة | الاسم=رقم الرد الثاني»، ثم افتح الجلسة الجديدة من اللوحة وامسح QR بحساب الرقم الثاني. بعد اتصال الحسابين، استخدم «فعّل حساب الرد الثاني | الجلسة=معرّف_الجلسة | تأكيد=نعم». مهم: الردود من الرقم الثاني تظهر في محادثة مستقلة معه، ولا يمكنها الظهور داخل محادثة «الرسائل إلى نفسك». اكتب «مساعدة» للتفاصيل.', 'faq-second-account');
    if (/(?:هل|لازم|يحتاج|يحتاجني).{0,20}(?:api|ذكاء اصطناعي|انترنت)/u.test(value) || /بدون api|من دون api/u.test(value))
      return this.reply('الأوامر المحلية وإضافة الأرقام وإدارة الجلسات لا تحتاج API توليديًا. يلزم اتصال إنترنت وحساب WhatsApp مرتبط لتنفيذ الفحص والإرسال الحقيقي والمواعيد، ويجب أن يبقى الخادم يعمل وقت الموعد.', 'faq-api');
    if (/^(?:شكرا|شكرًا|تسلم|تمام|اوكي|ok|thanks)$/u.test(value))
      return this.reply('العفو! اكتب «مساعدة» للدليل، أو اذكر المهمة التي تريد تنفيذها. سأوضح كل حقل قبل استخدامه.', 'faq-thanks');
    return null;
  }
  sessionPhone(id) {
    const self = String(this.whatsapp.selfChatId(id) || '').toLowerCase();
    const match = self.match(/^(\d{6,20})@c\.us$/);
    return match ? match[1] : '';
  }
  async replySessionCommand(id, text) {
    if (/^(?:حالة حساب الرد|حساب الرد|حالة رقم الرد الثاني)$/iu.test(text)) {
      const s = this.session(id), c = s.ownerAssistant, otherId = String(c.replySessionId || ''), rt = otherId ? this.whatsapp.listRuntime(otherId) : null;
      const primaryPhone = this.sessionPhone(id), otherPhone = otherId ? this.sessionPhone(otherId) : '';
      return this.reply(`قناة الرد لهذه الجلسة:\nالوضع: ${c.replySessionEnabled && otherId ? 'الرد من حساب ثانٍ' : 'الرد الافتراضي داخل الرسائل إلى نفسك'}\nالجلسة الثانية: ${otherId || 'غير محددة'}\nحالة الحساب الثاني: ${rt ? (rt.ready ? 'متصل' : rt.status) : 'غير مرتبط'}\nرقم الحساب الأساسي: ${primaryPhone ? `••••${primaryPhone.slice(-4)}` : 'لم أتعرف عليه بعد'}\nرقم الحساب الثاني: ${otherPhone ? `••••${otherPhone.slice(-4)}` : 'غير متاح'}\nلا يتفعّل الحساب الثاني إلا إذا كان الرقمان متصلين ومختلفين وبموافقة صريحة.`, 'reply-session-status');
    }
    if (/^(?:أوقف حساب الرد الثاني|اوقف حساب الرد الثاني|عطّل حساب الرد الثاني|عطل حساب الرد الثاني|الرد داخل نفسي|أوقف الرد من الرقم الثاني)$/iu.test(text)) {
      const s = this.session(id); s.ownerAssistant.replySessionEnabled = false; s.ownerAssistant.replySessionConfirmedAt = ''; this.store.saveSession(s);
      return this.reply('✅ أوقفت الرد من الحساب الثاني. ستعود الردود إلى محادثة «الرسائل إلى نفسك» باستخدام الحساب الأساسي. الجلسة الثانية لم تُحذف ولم أفصل حسابها.', 'reply-session-disable');
    }
    if (!/^(?:فعّل|فعل) حساب الرد الثاني(?:\s*\||\s*$)/iu.test(text)) return null;
    const fields = parseFields(text), targetId = clean(fields.session || fields['معرف الجلسة'] || fields['الجلسة'] || '', 80), confirm = norm(fields.confirm || '');
    if (confirm !== 'نعم') throw new Error('لأمان الحساب، أضف «تأكيد=نعم» بعد مراجعة رقم الجلسة التي تملكها.');
    if (!targetId || !this.store.listSessionIds().includes(targetId)) throw new Error('معرّف الجلسة الثانية غير موجود. اكتب «الجلسات» ثم انسخ المعرّف الصحيح.');
    if (targetId === id) throw new Error('اختر جلسة أخرى؛ لا يمكن استخدام الحساب نفسه كرقم ثانٍ.');
    const primaryRuntime = this.whatsapp.listRuntime(id), secondRuntime = this.whatsapp.listRuntime(targetId);
    if (!primaryRuntime.ready || !secondRuntime.ready) throw new Error('يجب أن يكون الحساب الأساسي والحساب الثاني متصلين أولًا. اربط الجلسة الثانية بمسح QR من الهاتف الذي تملكه.');
    const primaryPhone = this.sessionPhone(id), secondPhone = this.sessionPhone(targetId);
    if (!primaryPhone || !secondPhone) throw new Error('تعذر التحقق من رقمي الحسابين بأمان. أعد اتصال كل جلسة وتأكد أن رقم الهاتف ظاهر كمعرّف c.us.');
    if (primaryPhone === secondPhone) throw new Error('الحسابان مرتبطان بالرقم نفسه؛ اختر جلسة متصلة برقم WhatsApp حقيقي مختلف تملكه.');
    const s = this.session(id); s.ownerAssistant.replySessionId = targetId; s.ownerAssistant.replySessionEnabled = true; s.ownerAssistant.replySessionConfirmedAt = new Date().toISOString(); this.store.saveSession(s);
    const check = this.session(id).ownerAssistant;
    if (!check.replySessionEnabled || check.replySessionId !== targetId) throw new Error('لم أستطع التحقق من حفظ إعداد قناة الرد الثانية.');
    return this.reply(`✅ تم تفعيل الرد عبر الجلسة الثانية «${targetId}» بعد التحقق من أن الحسابين متصلان وبرقمين مختلفين.\n\nمهم لفهم واتساب: سيظهر رد الحساب الثاني داخل محادثة مستقلة مع ذلك الرقم، وليس داخل «الرسائل إلى نفسك». يمكنك إرسال أمر بدء من محادثة نفسك، ثم مواصلة الحوار إما من هناك (ستصل الردود إلى شات الرقم الثاني) أو بفتح شات الرقم الثاني والرد عليه مباشرة. لإرجاع جميع الردود لنفسك اكتب «أوقف حساب الرد الثاني».`, 'reply-session-enable');
  }
  async run(id, input) {
    const originalText = clean(input, 1000);
    let text = originalText, lower = norm(text);
    if (!text) return { handled:false };
    const activeFlow = this.session(id).ownerAssistant.conversation;
    if (/^(?:الغاء|إلغاء|الغي|ألغ|الغِ|cancel|الغاء العملية|إلغاء العملية|وقف المحادثة)$/iu.test(text.trim())) { this.messagingConversations.clear(id); return this.handleConversationInput(id, text); }
    const pendingIntent = this.messagingConversations.load(id);
    if (pendingIntent?.type === 'intent-disambiguation') {
      const selected = this.messagingConversations.consumeChoice(id, text);
      if (!selected.handled) return selected;
      if (selected.expired) return this.reply(selected.response, 'intent-choice-expired');
      if (!selected.choice) return this.reply(selected.response, 'intent-choice-needed');
      const intent = selected.choice.intent;
      if (intent === 'send_message') {
        const session = this.session(id); session.ownerAssistant.conversation = { type:'send-message', step:'target', data:{}, startedAt:new Date().toISOString(), updatedAt:new Date().toISOString() }; this.store.saveSession(session);
        return this.reply(`تمام، اخترت «إرسال رسالة جديدة».\n\nالخطوة 1/2 — اكتب اسم المستلم أو المجموعة المحفوظة. بعد ذلك سأطلب نص الرسالة ثم أعرض ملخصًا قبل الإرسال.`, 'intent-send-selected');
      }
      if (intent === 'schedule_message') {
        const session = this.session(id); session.ownerAssistant.conversation = { type:'add-schedule', step:'name', data:{}, startedAt:new Date().toISOString(), updatedAt:new Date().toISOString() }; this.store.saveSession(session);
        return this.reply(`تمام، اخترت «جدولة رسالة».\n\nالخطوة 1 — اكتب اسم الموعد، ثم سأجمع التاريخ والوقت والمستلم ونص الرسالة وأراجعها معك قبل الحفظ.`, 'intent-schedule-selected');
      }
      if (intent === 'forward_message') return this.reply('اخترت «تحويل رسالة موجودة». افتح الرسالة الأصلية وحدد نصها أو أرسلها إلى محادثة البوت، ثم اكتب «حوّل الرسالة إلى [اسم المستلم]». لم أنفّذ أي تحويل لأن مصدر الرسالة لم يُحدّد بعد.', 'intent-forward-selected');
      return this.reply(`اخترت: ${selected.choice.label || intent}. اكتب «مساعدة» لمعرفة المسار المتاح.`, 'intent-selected');
    }
    if (!activeFlow) {
      const detected = resolveIntent(text, this.session(id).commandDictionary || []);
      if (detected.status === 'ambiguous') {
        const session = this.session(id);
        this.messagingConversations.save(id, { type:'intent-disambiguation', rawText:text, candidates:detected.candidates.map(x => ({ intent:x.intent, label:x.label || x.intent, score:x.score })), startedAt:new Date().toISOString() });
        return this.reply(`أريد التأكد من قصدك قبل التنفيذ. هل تقصد:\n\n${detected.candidates.map((x,i)=>`${i+1}. ${x.label || x.intent}`).join('\n')}\n\nأرسل رقم الاختيار فقط. لن أنفذ شيئًا قبل اختيارك.`, 'intent-disambiguation');
      }
    }
    if (activeFlow && /^(?:مساعدة|help|الأوامر|اوامر|commands|الاوامر|دليل الأوامر|دليل المستخدم)\s*$/iu.test(text)) return this.handleConversationInput(id, text);
    if (activeFlow) { const flowResult = await this.handleConversationInput(id, originalText); if (flowResult) return flowResult; }
    const commandSettings = this.session(id).settings || {};
    const prepared = prepareCommandInput(originalText, commandSettings);
    if (prepared.blocked) return { handled:false, ok:null, action:'unknown', response:'لم يتم تنفيذ الأمر لأن كلمة التشغيل المطلوبة غير موجودة. أرسل إحدى كلمات التشغيل في بداية الأمر أو بين أجزائه قبل علامة |.' };
    // Conversation starters (e.g. the add-person wizard) keep their natural-language
    // intent; only the configured trigger phrase is removed before the dialogue parser.
    const conversationText = removeCommandTriggers(originalText, commandSettings);
    const rawConversation = await this.handleConversationInput(id, conversationText);
    if (rawConversation) return rawConversation;
    const rawFaq = this.faqResponse(conversationText);
    if (rawFaq) return rawFaq;
    text = prepared.text || conversationText;
    lower = norm(text);
    const helpForTopic = topicHelp(text);
    if (helpForTopic) return this.reply(helpForTopic, 'help-topic');
    if (/^(?:مساعدة|help|الأوامر|اوامر|commands|الاوامر|دليل الأوامر|دليل المستخدم|ماذا تستطيع|تعمل ايه|بتعمل ايه)\s*$/iu.test(text)) return this.reply(HELP, 'help');
    const accountCommand = await this.replySessionCommand(id, text);
    if (accountCommand) return accountCommand;
    const conversational = await this.handleConversationInput(id, text);
    if (conversational) return conversational;
    const faq = this.faqResponse(text);
    if (faq) return faq;
    if (/^(?:أنشئ جلسة|انشئ جلسة|أضف جلسة|اضف جلسة)(?:\s*\||\s*$)/iu.test(text)) {
      const f=parseFields(text), name=clean(f.name||'',80); if(!name) throw new Error('اكتب اسم الجلسة: أنشئ جلسة | الاسم=حساب ثانٍ.');
      if(typeof this.store.createSessionInactive!=='function') throw new Error('إصدار التخزين الحالي لا يدعم إنشاء جلسة مستقلة بأمان.');
      const created=this.store.createSessionInactive(name), ids=this.store.listSessionIds();
      if(!ids.includes(created.id)) throw new Error('لم أتمكن من التحقق من حفظ الجلسة الجديدة.');
      return this.reply(`✅ أنشأت الجلسة المستقلة «${created.name}» وحفظتها. لم أغيّر الجلسة النشطة ولم أنقل إليها مصادقة WhatsApp.
المعرّف: ${created.id}
افتح قائمة الجلسات، ثم اربط حساب WhatsApp داخل الجلسة الجديدة.`, 'create-session');
    }
    if (/^احذف الجلسة\s+.+$/iu.test(text)) {
      const f=parseFields(text), raw=text.replace(/^احذف الجلسة\s+/iu,'').replace(/\s*\|\s*تأكيد\s*[=:].*$/iu,'').trim();
      const target=this.store.safeSessionId?this.store.safeSessionId(raw):raw;
      if(norm(f.confirm||'')!=='نعم')throw new Error('حذف الجلسة يحتاج تأكيدًا صريحًا: احذف الجلسة ID | تأكيد=نعم.');
      if(target===String(id))throw new Error('لا يمكن حذف الجلسة التي تستخدمها هذه المحادثة؛ استخدم لوحة الجلسات بعد التأكد من النسخة الاحتياطية.');
      if(this.store.activeSessionId&&target===this.store.activeSessionId())throw new Error('لا يمكن حذف الجلسة النشطة من محادثة أخرى حتى لا تتغير الجلسة الحالية دون قصد. اخترها في اللوحة أولًا ثم احذفها من الواجهة.');
      if(!this.store.listSessionIds().includes(target))throw new Error('لم أجد معرّف جلسة محفوظًا بهذا الاسم. اكتب «الجلسات» لنسخ المعرّف الصحيح.');
      await this.whatsapp.stop(target,{clearAuth:true});
      const deleted=this.store.deleteSession(target);
      if(this.store.listSessionIds().includes(target)||deleted.deletedSessionId!==target)throw new Error('لم أستطع التحقق من حذف الجلسة.');
      return this.reply(`✅ حُذفت الجلسة «${target}» وملفات مصادقتها بعد التأكيد. الجلسة التي أرسلت منها الأمر لم تتغير.`, 'delete-session');
    }
    if (/^(?:غيّر اسم الجلسة|غير اسم الجلسة|أعد تسمية الجلسة|اعد تسمية الجلسة)\s+(?:إلى|الى|لـ|ل)\s+.+$/iu.test(text)) {
      const name=clean(text.replace(/^(?:غيّر اسم الجلسة|غير اسم الجلسة|أعد تسمية الجلسة|اعد تسمية الجلسة)\s+(?:إلى|الى|لـ|ل)\s+/iu,''),80);
      if(!name) throw new Error('اكتب الاسم الجديد.'); const renamed=this.store.renameSession(id,name); return this.reply(`✅ تغيّر اسم الجلسة الحالية إلى «${renamed.name}» وتم حفظه.`, 'rename-session');
    }
    if (/^(?:اتصل بواتساب|أعد الاتصال|اعد الاتصال|ربط واتساب|شغّل واتساب|شغل واتساب)$/iu.test(text)) {
      const rt=await this.whatsapp.start(id), live=this.whatsapp.listRuntime(id);
      return this.reply(`حالة محاولة الاتصال: ${live.ready?'متصل':live.status}. ${live.ready?'الجلسة جاهزة.':'لم أؤكد الاتصال بعد؛ افتح قسم الجلسة واتبع QR إذا ظهر.'}`, 'connect-session');
    }
    if (/^(?:افصل واتساب|أوقف اتصال واتساب|اوقف اتصال واتساب|أوقف الجلسة مؤقتًا|اوقف الجلسة مؤقتا)$/iu.test(text)) {
      await this.whatsapp.stop(id); const live=this.whatsapp.listRuntime(id);
      if(live.ready || !['stopped','disconnected','idle'].includes(String(live.status))) throw new Error(`طلب إيقاف الجلسة لكن الحالة الحالية «${live.status}».`);
      return this.reply(`✅ أُوقف اتصال WhatsApp لهذه الجلسة فقط. الحالة: ${live.status}. لم أحذف ملفات المصادقة.`, 'stop-session');
    }
    if (/^(?:افحص|تشخيص|diagnostic|check)\s*$/iu.test(text)) return { handled:true, ok:true, action:'diagnostics', response:'__RUN_DIAGNOSTICS__' };
    if (/^(?:حالة الاتصال|الحالة|status|متصل|اتصال)\s*$/iu.test(text)) {
      const s = this.session(id), rt = this.whatsapp.listRuntime(id);
      return this.reply(`الجلسة: ${s.name} (${s.id})\nWhatsApp: ${rt.ready?'متصل':rt.status}\nالأشخاص: ${s.recipients.length} (${s.recipients.filter(x=>x.enabled!==false).length} مفعّل)\nالمجموعات: ${s.groups.length} (${s.groups.filter(x=>x.enabled!==false).length} مفعّل)\nالمواعيد: ${(s.automation.tasks||[]).length}\nقواعد التفاعل: ${(s.interaction.rules||[]).length}\nالمشكلات المفتوحة: ${(s.ownerAssistant?.issues||[]).filter(x=>x.status==='open').length}`, 'status');
    }
    if (/^(?:الجلسات|اعرض الجلسات|قائمة الجلسات|sessions)\s*$/iu.test(text)) {
      const ids = this.store.listSessionIds();
      return this.reply(`الجلسات (${ids.length}):\n${ids.map((sid,i)=>{const s=this.session(sid),rt=this.whatsapp.listRuntime(sid);return `${i+1}. ${s.name} | ${sid} | ${rt.ready?'متصل':rt.status}`;}).join('\n')}\nهذا الأمر يعرض الجلسات فقط ولا يبدّل الجلسة النشطة.`, 'list-sessions');
    }

    if (/^(?:(?:فعّل|فعل|شغّل|شغل)\s+(?:استخدام\s+)?(?:اسماء|أسماء)\s*(?:المشروع|المستلمين|جهات المشروع)|(?:استخدم|استخدام)\s+(?:اسماء|أسماء)\s*(?:المشروع|المستلمين|جهات المشروع)|(?:استخدم|فعّل|فعل)\s+اسم\s+المستلم\s+في\s+الرد)/iu.test(text)) {
      const s=this.session(id); s.settings.interactionUseRecipientNames=true; this.store.saveSession(s);
      return this.reply('✅ فعّلت استخدام الاسم المسجل في مشروع chat BOT داخل {{sender}} للردود التلقائية.', 'recipient-names-toggle');
    }
    if (/^(?:(?:أوقف|اوقف|عطّل|عطل|الغ|الغِ)\s+(?:استخدام\s+)?(?:اسماء|أسماء)\s*(?:المشروع|المستلمين|جهات المشروع)|(?:لا تستخدم|منع استخدام)\s+(?:اسماء|أسماء)\s*(?:المشروع|المستلمين|جهات المشروع)|(?:أوقف|اوقف|عطّل|عطل|لا تستخدم)\s+اسم\s+المستلم\s+في\s+الرد)/iu.test(text)) {
      const s=this.session(id); s.settings.interactionUseRecipientNames=false; this.store.saveSession(s);
      return this.reply('✅ أوقفت استخدام الأسماء المسجلة محليًا. سيستخدم الرد الاسم الذي يوفره WhatsApp بدلًا منه.', 'recipient-names-toggle');
    }
    if (/^(?:غيّر|غير|بدّل|بدل|اجعل|خلي|خلّي)\s+(?:كلمة|عبارة)\s*(?:تشغيل|تفعيل)\s*(?:الأوامر|الاوامر)\s*(?:إلى|الى|لـ|ل|=|:)\s*.+$/iu.test(text)) {
      const value=clean(text.replace(/^(?:غيّر|غير|بدّل|بدل|اجعل|خلي|خلّي)\s+(?:كلمة|عبارة)\s*(?:تشغيل|تفعيل)\s*(?:الأوامر|الاوامر)\s*(?:إلى|الى|لـ|ل|=|:)\s*/iu,''),250);
      const words=value.split(/[،,;|]/).map(x=>clean(x,50)).filter(Boolean).slice(0,12);
      if(!words.length) throw new Error('اكتب كلمة أو عبارة واحدة على الأقل.');
      const s=this.session(id); s.settings.commandTriggerWords=words; s.settings.commandTriggerEnabled=true; this.store.saveSession(s);
      return this.reply(`✅ حُفظت كلمات تشغيل الأوامر: ${words.join('، ')}. يمكنك قول أي كلمة منها قبل الأمر أو داخله.`, 'command-trigger-settings');
    }
    if (/^(?:فعّل|فعل|شغّل|شغل)\s+(?:اشتراط|شرط)\s+(?:كلمة|عبارة)\s*(?:تشغيل|التشغيل)\s*(?:للأوامر|الأوامر)?$/iu.test(text)) {
      const s=this.session(id); s.settings.commandTriggerEnabled=true; s.settings.commandTriggerRequired=true; this.store.saveSession(s); return this.reply('✅ أصبح وجود كلمة التشغيل شرطًا لتنفيذ أوامر المحادثة.', 'command-trigger-settings');
    }
    if (/^(?:أوقف|اوقف|عطّل|عطل|الغ|الغِ)\s+(?:اشتراط|شرط)\s+(?:كلمة|عبارة)\s*(?:تشغيل|التشغيل)\s*(?:للأوامر|الأوامر)?$/iu.test(text)) {
      const s=this.session(id); s.settings.commandTriggerRequired=false; this.store.saveSession(s); return this.reply('✅ لم تعد كلمة التشغيل إلزامية؛ يمكنك تنفيذ الأوامر بصيغتها الطبيعية أو مع «يا بوت».', 'command-trigger-settings');
    }

    if (/^(?:زامن|حدّث|حدث|حدّثي|حدثي)\s+(?:ملف|ملفات|بيانات)\s+(?:WhatsApp|واتساب)(?=$|\s|\|)/iu.test(text)) {
      if (!this.whatsapp.listRuntime(id).ready) throw new Error('اربط WhatsApp في هذه الجلسة أولًا قبل مزامنة الأسماء والصور.');
      if (!this.refreshRecipientProfile) throw new Error('مزامنة الملف الشخصي من المحادثة غير متاحة في هذا السياق؛ استخدم «مزامنة الأسماء والصور» في صفحة الأشخاص.');
      const fields = parseFields(text);
      let rawTarget = String(fields.to || '').trim();
      if (!rawTarget) rawTarget = text.replace(/^(?:زامن|حدّث|حدث|حدّثي|حدثي)\s+(?:ملف|ملفات|بيانات)\s+(?:WhatsApp|واتساب)\s*/iu, '').trim().replace(/^\|\s*/, '').replace(/^(?:للمستلم|للشخص|للأشخاص|جهة الاتصال)\s*/iu, '').trim();
      if (!rawTarget) throw new Error('حدّد الأشخاص: زامن ملف واتساب | إلى=أحمد، سارة. لمزامنة القائمة كلها استخدم إلى=الكل.');
      const session = this.session(id), recipients = session.recipients || [];
      const allMode = /^(?:الكل|كل المستلمين|كل الأشخاص|جميع الأشخاص|الجميع|all)$/iu.test(rawTarget);
      let selected;
      if (allMode) selected = recipients.filter(r => r.enabled !== false).slice(0, 100);
      else {
        selected = [];
        for (const query of rawTarget.replace(/^إلى\s*[=:]\s*/iu, '').split(/[,،;؛]/).map(v => v.trim()).filter(Boolean)) {
          const q = norm(query), digits = query.replace(/\D/g, '');
          const hits = recipients.filter(r => [r.localName, r.name, r.whatsappName, r.phone, r.e164, r.international, r.digits].some(v => norm(v) === q || (digits.length >= 6 && String(v || '').replace(/\D/g, '') === digits)));
          if (hits.length !== 1) throw new Error(hits.length ? `الاسم «${query}» غير فريد؛ استخدم الرقم أو الاسم الكامل.` : `لم أجد مستلمًا محفوظًا باسم «${query}».`);
          if (!selected.some(r => r.id === hits[0].id)) selected.push(hits[0]);
        }
      }
      if (!selected.length) throw new Error('لا توجد جهات اتصال مفعّلة للمزامنة. أضف شخصًا أو اختر مستلمين محفوظين.');
      if (selected.length > 100) throw new Error('المزامنة عبر المحادثة محدودة بـ100 جهة في المرة الواحدة.');
      const results = [];
      for (const item of selected) {
        const before = { name:item.whatsappName || item.name || item.phone || 'بدون اسم', avatar: item.whatsappAvatarFile || item.whatsappAvatarUrl || '' };
        let outcome;
        try { outcome = await this.refreshRecipientProfile(id, item.id); }
        catch (error) { outcome = { ok:false, error:String(error?.message || error) }; }
        const afterItem = this.session(id).recipients.find(r => r.id === item.id) || item;
        if (outcome?.ok) {
          const after = { name:afterItem.whatsappName || afterItem.name || afterItem.phone || 'بدون اسم', avatar:afterItem.whatsappAvatarFile || afterItem.whatsappAvatarUrl || '' };
          const nameChanged = before.name !== after.name, avatarChanged = before.avatar !== after.avatar;
          results.push({ ok:true, name:afterItem.localName || afterItem.name || after.name, before, after, nameChanged, avatarChanged, avatarStatus:outcome.profile?.avatarStatus || (after.avatar ? 'available' : 'unknown') });
        } else results.push({ ok:false, name:item.localName || item.name || item.phone, error:String(outcome?.error || (outcome?.skipped ? 'تجاوز النظام هذه الجهة؛ قد تكون مزامنتها جارية بالفعل.' : 'لم يكتمل التحديث.')) });
      }
      const succeeded = results.filter(x => x.ok).length, failed = results.length - succeeded;
      const changed = results.filter(x => x.ok && (x.nameChanged || x.avatarChanged)).length;
      const lines = results.slice(0, 12).map(x => x.ok
        ? `• ${x.name}: الاسم ${x.nameChanged ? `قبل «${x.before.name}»، بعد «${x.after.name}»` : 'دون تغيير'}؛ الصورة ${x.avatarChanged ? 'تحدّثت' : x.avatarStatus === 'none' ? 'غير متاحة في WhatsApp' : 'دون تغيير'}`
        : `• ${x.name}: تعذر التحديث (${x.error.slice(0, 120)})`);
      return this.reply(`✅ انتهت مزامنة بيانات WhatsApp دون استبدال الاسم أو الصورة المحليين.\nتم فحص: ${results.length}${allMode && recipients.filter(r=>r.enabled!==false).length>100 ? ' من أول 100 جهة مفعّلة' : ''}\nنجح: ${succeeded} | تعذر: ${failed} | تغييرات ظاهرة: ${changed}\n${lines.join('\n')}${results.length>12 ? `\n… و${results.length-12} جهات أخرى.` : ''}`, 'recipient-profile-sync');
    }
    if (/^(?:اعرض الأشخاص|الأشخاص|قائمة الأرقام|ارقامى|أرقامي|جهات الاتصال|المستلمين)\s*$/iu.test(text)) {
      const s=this.session(id); return this.reply(`الأشخاص (${s.recipients.length}):\n${s.recipients.length?s.recipients.map((r,i)=>`${i+1}. ${r.name} | ${r.international||r.e164||r.digits} | ${r.enabled===false?'متوقف':'مفعّل'}`).join('\n'):'لا توجد أرقام محفوظة.'}`, 'list-recipients');
    }
    if (/^(?:الوسائط|اعرض الوسائط|الملفات|ملفاتي)\s*$/iu.test(text)) {
      const fs=this.delivery.files(id); return this.reply(`الملفات (${fs.length}):\n${fs.slice(0,50).map((f,i)=>`${i+1}. ${f.filename} | ${f.isImage?'صورة':'ملف'} | ${f.size} bytes`).join('\n')||'لا توجد ملفات.'}\nاستخدم الاسم الكامل في حقل «ملف=».`, 'list-media');
    }
    if (/^(?:معلومات المجموعة|تفاصيل المجموعة|معلومات القروب|تفاصيل القروب)\s+(.+)$/iu.test(text)) {
      const query=clean(text.replace(/^(?:معلومات المجموعة|تفاصيل المجموعة|معلومات القروب|تفاصيل القروب)\s+/iu,''),180), s=this.session(id), q=norm(query);
      const hits=s.groups.filter(g=>norm(g.name)===q||String(g.gid||'').toLowerCase()===query.toLowerCase());
      if(hits.length!==1) throw new Error(hits.length?'اسم المجموعة غير فريد؛ استخدم GID.':'لم أجد المجموعة المحفوظة بهذا الاسم. أرسل رابط الدعوة أو GID لتحليلها.');
      return this.reply(groups.formatGroupAnalysis(hits[0]), 'group-details');
    }
    if (/^(?:افحص الرقم|تحقق من الرقم|تحقق الرقم|هل الرقم مسجل)\s+.+$/iu.test(text)) {
      const raw=text.replace(/^(?:افحص الرقم|تحقق من الرقم|تحقق الرقم|هل الرقم مسجل)\s+/iu,''), parsed=require('./phones').parse(raw,'OM');
      if(!this.whatsapp.listRuntime(id).ready) throw new Error('فحص تسجيل الرقم يحتاج WhatsApp متصلًا في هذه الجلسة.');
      const chatId=await this.whatsapp.resolveChatId(id,{kind:'person',...parsed});
      if(!chatId) throw new Error('لم يرجع WhatsApp معرف محادثة لهذا الرقم.');
      return this.reply(`✅ أكد WhatsApp أن الرقم مسجّل ويمكن تحديد محادثته.\nالرقم: ${parsed.international||parsed.e164}\nالمعرّف: ${chatId}\nلم أضفه إلى القائمة؛ استخدم «أضف الرقم … باسم …» لحفظه.`, 'validate-phone');
    }
    if (/^(?:اعرض المشاكل|مشاكلي|الأخطاء المفتوحة|الاخطاء المفتوحة)\s*$/iu.test(text)) {
      const issues=(this.session(id).ownerAssistant?.issues||[]).filter(x=>x.status==='open').slice(-12);
      return this.reply(`المشكلات المفتوحة (${issues.length}):\n${issues.length?issues.map((x,i)=>`${i+1}. ${x.title} | ${x.code} | ID=${x.id}\n${x.details}`).join('\n'): 'لا توجد مشكلات مفتوحة مسجلة.'}`, 'list-issues');
    }
    if (/^(?:حل المشكلة|أغلق المشكلة|اغلق المشكلة)\s+(.+)$/iu.test(text)) {
      const q=norm(text.replace(/^(?:حل المشكلة|أغلق المشكلة|اغلق المشكلة)\s+/iu,'')), s=this.session(id), issues=s.ownerAssistant?.issues||[];
      const hits=issues.filter(x=>norm(x.id)===q||(x.status==='open'&&norm(x.title)===q));
      if(hits.length!==1) throw new Error(hits.length?'المشكلة غير محددة؛ استخدم ID.':'لم أجد المشكلة المفتوحة.');
      hits[0].status='resolved'; hits[0].resolvedAt=new Date().toISOString(); hits[0].resolvedBy='owner-command'; this.store.saveSession(s);
      const checked=(this.session(id).ownerAssistant?.issues||[]).find(x=>x.id===hits[0].id); if(!checked||checked.status!=='resolved')throw new Error('لم أستطع التحقق من حفظ حالة المشكلة.');
      return this.reply(`✅ تم إغلاق المشكلة في السجل وحفظها: ${checked.title} (${checked.id}). هذا يحدّث حالة السجل فقط ولا يدّعي أن سببها التقني اختفى ما لم يُختبر الإصلاح.`, 'resolve-issue');
    }
    if (/^(?:اعرض سجل المساعد|سجل المساعد|رسائل المساعد)\s*$/iu.test(text)) {
      const messages=this.session(id).ownerAssistant?.messages||[];
      return this.reply(`آخر رسائل المساعد (${Math.min(12,messages.length)} من ${messages.length}):\n${messages.slice(-12).map(m=>`${m.role==='user'?'أنت':'المساعد'}: ${String(m.text||'').slice(0,220)}`).join('\n')||'لا توجد رسائل محفوظة.'}`, 'list-assistant-messages');
    }
    if (/^(?:فعّل إشعارات المساعد|فعل إشعارات المساعد|أوقف إشعارات المساعد|اوقف إشعارات المساعد)$/iu.test(text)) {
      const s=this.session(id); if(!s.ownerAssistant)s.ownerAssistant={messages:[],issues:[],activity:[],pendingNotifications:[],notificationMode:'self'};
      const enabled=/^(?:فعّل|فعل)/iu.test(text); s.ownerAssistant.notificationsEnabled=enabled; this.store.saveSession(s);
      const verified=this.session(id).ownerAssistant.notificationsEnabled===enabled; if(!verified)throw new Error('لم يتم حفظ خيار الإشعارات.');
      return this.reply(`✅ ${enabled?'تم تفعيل':'تم إيقاف'} إشعارات المساعد وحُفظ الخيار لهذه الجلسة. ${enabled?'سيحاول إرسال التنبيهات الجديدة عبر القناة المضبوطة عند اتصال WhatsApp.':'ستبقى التنبيهات محفوظة محليًا دون إرسالها.'}`, 'assistant-notifications');
    }
    if (/^(?:فعّل|فعل|شغل|شغّل) الرد الافتراضي(?: عند عدم تطابق قاعدة)?$/iu.test(text)) { const s=this.session(id); s.settings.interactionFallbackEnabled=true; this.store.saveSession(s); return this.reply('✅ تم تشغيل الرد الافتراضي عند عدم تطابق قاعدة. إذا لم تطابق الرسالة أي قاعدة فسيُرسل رد متاح مرة واحدة خلال فترة التهدئة.', 'interaction-fallback-toggle'); }
    if (/^(?:أوقف|اوقف|عطّل|عطل|اقفل) الرد الافتراضي(?: عند عدم تطابق قاعدة)?$/iu.test(text)) { const s=this.session(id); s.settings.interactionFallbackEnabled=false; this.store.saveSession(s); return this.reply('✅ تم إيقاف الرد الافتراضي؛ لن يرد البوت على رسالة لا تطابق قاعدة مفعّلة.', 'interaction-fallback-toggle'); }
    if (/^(?:عدّل|عدل|غيّر|غير) الرد الافتراضي(?: عند عدم تطابق قاعدة)?\s*(?:\||$)/iu.test(text)) { const f=parseFields(text), reply=clean(f.reply||f.text||'',1000); if(!reply) throw new Error('استخدم: عدّل الرد الافتراضي | الرد=أهلًا {{sender}} وصلتني رسالتك: {{message}}.'); const s=this.session(id); s.settings.interactionFallbackReply=reply; this.store.saveSession(s); return this.reply(`✅ حُفظ نص الرد الافتراضي. المتغيرات المتاحة: {{sender}}، {{message}}، {{chat}}، {{time}}.\nالنص: ${reply}`, 'interaction-fallback-edit'); }
    if (/^(?:اعرض إعدادات التفاعل|اعرض اعدادات التفاعل|حالة التفاعل)\s*$/iu.test(text)) {
      const s = this.session(id), settings = s.settings, scope = ({all:'كل المحادثات', groups:'المجموعات فقط', private:'المحادثات الخاصة', selected:'أهداف محددة'})[settings.interactionScope || 'all'];
      return this.reply(`إعدادات التفاعل لهذه الجلسة:\nالتفاعل: ${settings.interactionEnabled !== false && s.interaction.enabled !== false ? 'مفعّل' : 'متوقف'}\nمساعد المجموعات: ${settings.groupAssistantEnabled !== false ? 'مفعّل' : 'متوقف'}\nالنطاق: ${scope}\nاستخدام أسماء المشروع: ${settings.interactionUseRecipientNames !== false ? 'مفعّل' : 'متوقف'}\nفترة الهدوء: ${settings.interactionQuietEnabled ? 'مفعّلة' : 'متوقفة'} (${settings.interactionQuietStart || '23:00'}–${settings.interactionQuietEnd || '07:00'})\nكلمة التشغيل: ${(settings.commandTriggerWords || []).join('، ')}${settings.commandTriggerRequired ? ' (إلزامية)' : ' (اختيارية)'}`, 'interaction-settings');
    }
    if (/^(?:فعّل|فعل|شغّل|شغل|أوقف|اوقف|عطّل|عطل)\s+(?:تجاهل رسائل الحساب|تجاهل رسائل نفسي)$/iu.test(text)) {
      const s = this.session(id), enable = /^(?:فعّل|فعل|شغّل|شغل)/iu.test(text);
      s.settings.interactionIgnoreOwn = enable; this.store.saveSession(s);
      return this.reply(`✅ ${enable ? 'سيتم تجاهل' : 'لن يتم تجاهل'} الرسائل الصادرة من الحساب في التفاعل العام. اختبار محادثة نفسك له إعداد مستقل.`, 'own-message-setting');
    }
    if (/^(?:اضبط|غيّر|غير|بدّل|بدل)\s+(?:النطاق|نطاق التفاعل)(?=$|\s|[|])/iu.test(text)) {
      const fields = parseFields(text), raw = norm(fields.interactionScope || text.split(/[|]/).slice(1).join('|'));
      const value = /مجموع|جروب|قروب|group/.test(raw) ? 'groups' : /خاص|private/.test(raw) ? 'private' : /محدد|مختار|selected/.test(raw) ? 'selected' : /كل|الكل|عام|all/.test(raw) ? 'all' : '';
      if (!value) throw new Error('استخدم: اضبط النطاق | النطاق=كل المحادثات أو خاص أو مجموعات أو محدد.');
      const s = this.session(id);
      if (value === 'selected' && !(s.settings.interactionChatIds || []).length) throw new Error('نطاق «محدد» يحتاج أهدافًا محددة. حدّدها من صفحة التفاعل أولًا، ثم أرسل الأمر.');
      s.settings.interactionScope = value; this.store.saveSession(s);
      if (this.session(id).settings.interactionScope !== value) throw new Error('لم يتم التحقق من حفظ نطاق التفاعل.');
      return this.reply(`✅ تم حفظ نطاق التفاعل: ${{all:'كل المحادثات',groups:'المجموعات فقط',private:'المحادثات الخاصة',selected:'أهداف محددة'}[value]}.`, 'interaction-scope');
    }
    if (/^(?:اضبط|غيّر|غير|عدّل|عدل)\s+(?:فترة الهدوء|وقت الهدوء)(?=$|\s|[|])/iu.test(text)) {
      const f = parseFields(text), s = this.session(id), settings = s.settings;
      const start = String(f.quietStart ?? settings.interactionQuietStart ?? '23:00'), end = String(f.quietEnd ?? settings.interactionQuietEnd ?? '07:00');
      if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(start) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(end) || start === end) throw new Error('حدد بداية ونهاية مختلفتين بصيغة HH:MM: البداية=23:00 | النهاية=07:00.');
      let action = String(settings.interactionQuietAction || 'silence');
      if (f.quietAction !== undefined) {
        const raw = norm(f.quietAction);
        action = /رد|reply/.test(raw) ? 'reply' : /قواعد|تطبيق|rules/.test(raw) ? 'rules' : /صمت|لا\s*يرد|بدون|silence|تجاهل/.test(raw) ? 'silence' : '';
        if (!action) throw new Error('السلوك المسموح: لا يرد، أو رد مخصص، أو تطبيق القواعد.');
      }
      const cooldown = Number(f.quietCooldownSec ?? settings.interactionQuietCooldownSec ?? 300);
      if (!Number.isInteger(cooldown) || cooldown < 30 || cooldown > 86400) throw new Error('الفاصل بين ردود الهدوء يجب أن يكون من 30 إلى 86400 ثانية.');
      settings.interactionQuietStart = start; settings.interactionQuietEnd = end; settings.interactionQuietAction = action; settings.interactionQuietCooldownSec = cooldown;
      if (f.quietReply !== undefined) settings.interactionQuietReply = clean(f.quietReply, 1000);
      if (f.enabled !== undefined) settings.interactionQuietEnabled = /^(?:نعم|فعّل|فعل|true|yes|1|on)$/iu.test(String(f.enabled).trim());
      this.store.saveSession(s); const check = this.session(id).settings;
      if (check.interactionQuietStart !== start || check.interactionQuietEnd !== end || check.interactionQuietAction !== action) throw new Error('لم يتم التحقق من حفظ إعدادات فترة الهدوء.');
      return this.reply(`✅ تم حفظ فترة الهدوء ${check.interactionQuietEnabled ? 'وتفعيلها' : '؛ وهي متوقفة حاليًا'}.\nالوقت: ${start}–${end}\nالسلوك: ${{silence:'لا يرد',reply:'رد مخصص',rules:'تطبيق القواعد'}[action]}\nالفاصل بين الردود: ${cooldown} ثانية.`, 'quiet-settings');
    }
    if (/^(?:فعّل|فعل|شغّل|شغل|أوقف|اوقف|عطّل|عطل)\s+(?:فترة الهدوء|الوضع الهادئ)$/iu.test(text)) {
      const s = this.session(id), enabled = /^(?:فعّل|فعل|شغّل|شغل)/iu.test(text);
      s.settings.interactionQuietEnabled = enabled; this.store.saveSession(s);
      return this.reply(`✅ ${enabled ? 'فترة الهدوء مفعّلة' : 'فترة الهدوء متوقفة'}. الوقت المضبوط: ${s.settings.interactionQuietStart}–${s.settings.interactionQuietEnd}.`, 'quiet-toggle');
    }
    if (/^(?:اضبط|غيّر|غير)\s+(?:الحد الأقصى للأفعال|حد التفاعل)(?=$|\s|[|])/iu.test(text)) {
      const f = parseFields(text), raw = f.maxActionsPerMinute, value = Number(raw);
      if (raw === undefined || !Number.isInteger(value) || value < 1 || value > 1000) throw new Error('استخدم: اضبط حد التفاعل | العدد=20. الحد من 1 إلى 1000 فعل في الدقيقة.');
      const s = this.session(id); s.settings.maxActionsPerMinute = value; this.store.saveSession(s);
      return this.reply(`✅ تم حفظ الحد الأقصى: ${value} فعلًا في الدقيقة.`, 'interaction-rate-limit');
    }
    if (/^(?:اضبط|غيّر|غير|بدّل|بدل|غيّرلي|غيرلي)\s+(?:المنطقة الزمنية|المنطقه الزمنيه|التوقيت)(?=$|\s|\|)/iu.test(text)) {
      const fields = parseFields(text);
      let timezone = String(fields.timezone || '').trim();
      if (!timezone) {
        const match = text.match(/(?:إلى|الى|=|:)\s*([A-Za-z0-9_+.-]+(?:\/[A-Za-z0-9_+.-]+)+)\s*$/u);
        timezone = match?.[1] || '';
      }
      if (!timezone) throw new Error('استخدم منطقة IANA مثل: اضبط المنطقة الزمنية | المنطقة=Asia/Muscat.');
      try { new Intl.DateTimeFormat('en-US', { timeZone:timezone }).format(new Date()); }
      catch { throw new Error(`المنطقة الزمنية «${timezone}» غير معروفة. استخدم اسمًا من قاعدة IANA مثل Asia/Muscat أو Europe/London.`); }
      const s = this.session(id); s.settings.timezone = timezone; this.store.saveSession(s);
      if (this.session(id).settings.timezone !== timezone) throw new Error('لم يتم التحقق من حفظ المنطقة الزمنية.');
      return this.reply(`✅ تم حفظ المنطقة الزمنية: ${timezone}. ستُستخدم في المواعيد وفترة الهدوء وفق إعدادات الجلسة.`, 'timezone-settings');
    }
    if (/^اعرض إعدادات الإرسال\s*$/iu.test(text)) {
      const s=this.session(id); return this.reply(`إعدادات الإرسال للجلسة «${s.name}»:\nتأخير بين العمليات: ${Number(s.settings.sendDelayMs||0)} ms\nالأتمتة: ${s.settings.automationEnabled===false?'متوقفة':'مفعّلة'}\nالمنطقة الزمنية: ${s.settings.timezone||'Asia/Muscat'}\nالمستلمون المفعّلون: ${s.recipients.filter(x=>x.enabled!==false).length}\nالمجموعات المفعّلة: ${s.groups.filter(x=>x.enabled!==false).length}`, 'send-settings');
    }
    if (/^احذف الملف\s+.+$/iu.test(text) || /^أزل الملف\s+.+$/iu.test(text)) {
      const raw=text.replace(/^(?:احذف الملف|أزل الملف)\s+/iu,'').trim(), files=this.delivery.files(id);
      const matches=files.filter(x=>norm(x.filename)===norm(raw)||norm(x.id)===norm(raw));
      if(matches.length!==1)throw new Error(matches.length?'اسم الملف غير فريد. استخدم الاسم الكامل من «الوسائط».':'لم أجد هذا الملف في مكتبة الجلسة. اكتب «الوسائط» لعرض الأسماء.');
      const target=matches[0], dir=this.store.getPaths(id).media, full=mediaFiles.safePath(dir,target.filename||target.id);
      if(!fs.existsSync(full)||!fs.statSync(full).isFile())throw new Error('الملف غير موجود على القرص؛ لم أغيّر المواعيد.');
      const s=this.session(id); fs.rmSync(full,{force:false});
      let affected=0;
      for(const task of s.automation.tasks||[]) if((task.mediaIds||[]).includes(target.id)) {
        task.mediaIds=task.mediaIds.filter(x=>x!==target.id); affected++;
        if(task.mediaMode!=='cycle'&&!task.mediaIds.length&&!String(task.text||task.preText||task.postText||'').trim()) { task.enabled=false; task.lastResult={ok:false,error:`توقف الموعد لأن الملف ${target.filename||target.id} حُذف.`,at:new Date().toISOString()}; }
      }
      if(s.settings.scheduleMediaId===target.id)s.settings.scheduleMediaId='';
      if(s.cycle?.imageOrder)s.cycle.imageOrder=s.cycle.imageOrder.filter(x=>x!==target.id);
      this.store.saveSession(s);
      if(this.delivery.files(id).some(x=>x.id===target.id))throw new Error('أُزيل الملف من القرص لكن بقي ظاهرًا في فهرس الوسائط؛ حدّث المكتبة وافحص سجل المساعد.');
      return this.reply(`✅ حُذف الملف «${target.filename||target.id}» من مكتبة هذه الجلسة.\nالمواعيد التي كانت تشير إليه: ${affected}${affected?' — تم تحديثها؛ عُطّل الموعد الذي لم يعد يحتوي نصًا أو ملفًا.':'.'}`, 'delete-media');
    }
    if (/^اختبر الإرسال لنفسي\s*\|/iu.test(text)) {
      const f=parseFields(text), message=clean(f.text||'',1000), runtime=this.whatsapp.listRuntime(id), self=this.whatsapp.selfChatId(id);
      if(!runtime.ready)throw new Error('اربط WhatsApp أولًا قبل اختبار الإرسال.');
      if(!self)throw new Error('تعذر تحديد محادثة نفسك من حساب WhatsApp الحالي.');
      if(!message)throw new Error('استخدم: اختبر الإرسال لنفسي | الرسالة=رسالة اختبار.');
      const testText=`🤖 chat BOT | اختبار إرسال ذاتي\n${message}`;
      const result=await this.whatsapp.sendText(id,self,testText);
      const ack=result?.__chatBotAck?.status||result?.result?.__chatBotAck?.status||'created';
      return this.reply(`✅ أنشأ WhatsApp رسالة اختبار في محادثة نفسك.\nحالة الإرسال: ${ack}.\nلم يتم إرسالها إلى أي مستلم آخر.`, 'self-send-test');
    }
    if (/^(?:اضبط تأخير الإرسال|اضبط تأخير الارسال|غيّر تأخير الإرسال|غير تأخير الارسال)(?:\s*\||\s+).+$/iu.test(text)) {
      const f=parseFields(text), raw=f.sendDelayMs, n=Number(raw); if(raw===undefined||!Number.isInteger(n)||n<0||n>60000)throw new Error('استخدم: اضبط تأخير الإرسال | مللي ثانية=500. الحد من 0 إلى 60000.');
      const s=this.session(id); s.settings.sendDelayMs=n; this.store.saveSession(s); if(Number(this.session(id).settings.sendDelayMs)!==n)throw new Error('لم يتم التحقق من حفظ التأخير.');
      return this.reply(`✅ تم حفظ تأخير الإرسال: ${n} مللي ثانية بين العمليات لهذه الجلسة.`, 'send-settings');
    }
    if (/^(?:الجروبات|مجموعاتي|اعرض المجموعات|المجموعات|قائمة المجموعات|قروباتي)\s*$/iu.test(text)) return this.groupCommand(id,text);
    if (!/^(?:احذف المجموعة|حذف المجموعة|أوقف المجموعة|اوقف المجموعة|عطّل المجموعة|عطل المجموعة|فعّل المجموعة|فعل المجموعة)\s+/iu.test(text) && (/اكتشف المجموعات|اكتشاف المجموعات|حدّث المجموعات|حدث المجموعات|تحليل المجموعة|حلل المجموعة|تحليل القروب|حلل القروب|تفاصيل المجموعة|معلومات المجموعة|تفاصيل القروب|معلومات القروب/i.test(text) || /chat\.whatsapp\.com\//i.test(text) || /(?:أضف|اضف|ضيف)\s+(?:ال)?مجموعة/i.test(text) || /\d{5,25}(?:-\d+)*@g\.us/i.test(text))) return this.groupCommand(id,text);
    if (/(?:أضف|اضف|ضيف|سجل|احفظ).{0,20}(?:رقم|مستلم|شخص)/iu.test(text) || /^رقم\s*[=:]/iu.test(text) && /الاسم\s*[=:]/iu.test(text)) return this.addRecipient(id,text);
    if (/^(?:فعّل|فعل|شغّل|شغل|أوقف|اوقف|عطّل|عطل)\s+(?:اختبار التفاعل مع نفسي|التفاعل|الأتمتة|الاتمتة|مساعد المجموعات|مساعد المجموعة)$/iu.test(text)) {
      const s=this.session(id), enable=/^(?:فعّل|فعل|شغّل|شغل)/iu.test(text);
      if (/الأتمتة|الاتمتة/.test(text)) { s.settings.automationEnabled=enable; s.automation.enabled=enable; }
      else if (/مساعد المجموعات|مساعد المجموعة/.test(text)) s.settings.groupAssistantEnabled=enable;
      else if (/اختبار التفاعل مع نفسي/.test(text)) {
        const self = this.whatsapp.selfChatId(id); if(enable && !self) throw new Error('لا أستطيع تحديد محادثة نفسك؛ اربط WhatsApp وانتظر حالة متصل.');
        s.settings.interactionIgnoreOwn = !enable;
        if (enable) { s.settings.interactionChatIds=[...new Set([...(s.settings.interactionChatIds||[]),self])]; s.settings.interactionScope='selected'; }
        else { s.settings.interactionChatIds=(s.settings.interactionChatIds||[]).filter(x=>String(x).toLowerCase()!==String(self).toLowerCase()); s.settings.interactionScope=(s.settings.interactionChatIds||[]).length?'selected':'all'; }
      } else { s.settings.interactionEnabled=enable; s.interaction.enabled=enable; }
      this.store.saveSession(s); const verify=this.session(id);
      const setting=/الأتمتة|الاتمتة/.test(text)?verify.settings.automationEnabled:/مساعد المجموعات|مساعد المجموعة/.test(text)?verify.settings.groupAssistantEnabled:/اختبار التفاعل مع نفسي/.test(text)?verify.settings.interactionIgnoreOwn===!enable:verify.settings.interactionEnabled===enable;
      if (!setting) throw new Error('لم تنجح مراجعة حفظ الإعداد.');
      return this.reply(`✅ تم ${enable?'التفعيل':'الإيقاف'} والحفظ الفعلي.`, 'settings');
    }
    if (/^(?:اعرض قواعد التفاعل|قواعد التفاعل|قواعدي)\s*$/iu.test(text)) {
      const s=this.session(id), rules=s.interaction.rules||[]; return this.reply(`قواعد التفاعل (${rules.length}):\n${rules.length?rules.map((r,i)=>`${i+1}. ${r.name||r.id} | ${r.enabled===false?'متوقفة':'مفعّلة'} | ${r.when?.match||'—'}: ${r.when?.value||'—'} | ID=${r.id}`).join('\n'):'لا توجد قواعد محفوظة.'}`, 'list-interaction-rules');
    }
    if (/^(?:تعديل قاعدة التفاعل|عدّل قاعدة التفاعل|عدل قاعدة التفاعل|غيّر قاعدة التفاعل|غير قاعدة التفاعل)\s+.+$/iu.test(text)) {
      const head = text.split('|')[0].trim();
      const selector = clean(head.replace(/^(?:تعديل قاعدة التفاعل|عدّل قاعدة التفاعل|عدل قاعدة التفاعل|غيّر قاعدة التفاعل|غير قاعدة التفاعل)\s*/iu, ''), 120);
      const f = parseFields(text), s = this.session(id), rules = s.interaction.rules || [], q = norm(selector || f.ruleId || f.taskId || '');
      const hits = rules.filter(rule => norm(rule.id) === q || norm(rule.name) === q || (q.length >= 3 && norm(rule.name).includes(q)));
      if (hits.length !== 1) throw new Error(hits.length ? 'اسم القاعدة غير فريد؛ استخدم ID من «اعرض قواعد التفاعل».' : 'لم أجد قاعدة التفاعل. استخدم «اعرض قواعد التفاعل» لنسخ اسمها أو ID.');
      const rule = hits[0];
      if (f.name !== undefined) rule.name = clean(f.name, 100);
      if (f.when !== undefined) rule.when.value = clean(f.when, 500);
      if (f.reply !== undefined) rule.then.reply = clean(f.reply, 1000);
      if (f.match !== undefined) {
        const raw = norm(f.match);
        const match = /دقيق|بالضبط|exact/.test(raw) ? 'exact' : /يبدأ|بدايه|starts/.test(raw) ? 'starts' : /ينتهي|ends/.test(raw) ? 'ends' : /regex|نمط/.test(raw) ? 'regex' : /أي|اي|any/.test(raw) ? 'any' : /يحتوي|contains/.test(raw) ? 'contains' : '';
        if (!match) throw new Error('نوع المطابقة: يحتوي أو دقيق أو يبدأ أو ينتهي أو نمط.');
        rule.when.match = match;
      }
      if (f.cooldownSec !== undefined) {
        const cooldown = Number(f.cooldownSec);
        if (!Number.isInteger(cooldown) || cooldown < 0 || cooldown > 86400) throw new Error('فاصل القاعدة يجب أن يكون عددًا صحيحًا من 0 إلى 86400 ثانية.');
        rule.cooldownSec = cooldown;
      }
      require('./interaction').valid(rule);
      this.store.saveSession(s);
      const verified = (this.session(id).interaction.rules || []).find(item => item.id === rule.id);
      if (!verified || verified.when.value !== rule.when.value || verified.then.reply !== rule.then.reply) throw new Error('لم أتمكن من التحقق من حفظ تعديل القاعدة.');
      return this.reply(`✅ تم تعديل قاعدة التفاعل وحفظها.\nالاسم: ${verified.name}\nعند: ${verified.when.value}\nالرد: ${verified.then.reply}\nالمطابقة: ${verified.when.match}\nID=${verified.id}`, 'edit-interaction-rule');
    }
    if (/^(?:احذف قاعدة التفاعل|حذف قاعدة التفاعل|أوقف قاعدة التفاعل|اوقف قاعدة التفاعل|فعّل قاعدة التفاعل|فعل قاعدة التفاعل)\s+.+$/iu.test(text)) {
      const m=text.match(/^(?:احذف قاعدة التفاعل|حذف قاعدة التفاعل|أوقف قاعدة التفاعل|اوقف قاعدة التفاعل|فعّل قاعدة التفاعل|فعل قاعدة التفاعل)\s+(.+)$/iu), q=norm(m?.[1]||''), s=this.session(id);
      const hits=(s.interaction.rules||[]).filter(r=>norm(r.id)===q||norm(r.name)===q||norm(r.name).includes(q));
      if(hits.length!==1) throw new Error(hits.length?'اسم القاعدة غير فريد؛ استخدم ID من «اعرض قواعد التفاعل».':'لم أجد قاعدة التفاعل.'); const rule=hits[0];
      if(/^(?:احذف|حذف)/.test(text)) s.interaction.rules=s.interaction.rules.filter(r=>r.id!==rule.id); else rule.enabled=/^(?:فعّل|فعل)/.test(text);
      this.store.saveSession(s); return this.reply(`✅ تم ${/^(?:احذف|حذف)/.test(text)?'حذف':rule.enabled?'تفعيل':'إيقاف'} قاعدة التفاعل «${rule.name}» وحُفظ التغيير.`, 'manage-interaction-rule');
    }
    if (/^أضف قاعدة تفاعل|^اضف قاعدة تفاعل|^أنشئ قاعدة تفاعل|^انشئ قاعدة تفاعل/iu.test(text)) {
      const f=parseFields(text), s=this.session(id), value=clean(f.when || '',500), reply=clean(f.reply || '',1000);
      if (!value || !reply) throw new Error('استخدم: أضف قاعدة تفاعل | الاسم=ترحيب | عندما=السلام عليكم | المطابقة=يحتوي | الرد=وعليكم السلام.');
      const mt=norm(f.match||'يحتوي'), match=/دقيق|exact/.test(mt)?'exact':/يبدأ|starts/.test(mt)?'starts':/ينتهي|ends/.test(mt)?'ends':/regex|نمط/.test(mt)?'regex':mt==='any'?'any':'contains';
      const rule={id:crypto.randomUUID(),name:clean(f.name||`قاعدة ${s.interaction.rules.length+1}`,100),enabled:true,priority:10,when:{type:'message',match,value,ignoreCase:true},then:{reply,reaction:''},scope:'all',chatIds:[],cooldownSec:30};
      require('./interaction').valid(rule); s.interaction.rules.push(rule); s.interaction.enabled=true; s.settings.interactionEnabled=true; this.store.saveSession(s);
      const ok=this.session(id).interaction.rules.some(x=>x.id===rule.id); if(!ok) throw new Error('لم يتم حفظ قاعدة التفاعل.');
      return this.reply(`✅ أُضيفت قاعدة التفاعل وحُفظت فعليًا.\nالاسم: ${rule.name}\nعند: ${value}\nالرد: ${reply}\nالمطابقة: ${match}\nID=${rule.id}`, 'add-interaction-rule');
    }
    if (/^(?:أوقف الأتمتة|اوقف الأتمتة|فعّل الأتمتة|فعل الأتمتة|تشغيل الأتمتة|تعطيل الأتمتة)$/iu.test(text)) { const s=this.session(id), on=/فعّل|فعل|تشغيل/.test(text); s.settings.automationEnabled=on; s.automation.enabled=on; this.store.saveSession(s); return this.reply(`✅ ${on?'الأتمتة مفعّلة':'الأتمتة متوقفة'} لهذه الجلسة.`, 'automation-toggle'); }
    if (/^(?:اعرض المواعيد|المواعيد|جدولتي|مواعيدي)\s*$/iu.test(text)) return this.scheduleCommand(id,text);
    if (/^(?:أضف موعد|اضف موعد|أنشئ موعد|انشئ موعد|جدولة)(?=\s|\||$)|^موعد\s*\|/iu.test(text)) return this.scheduleCommand(id,text);
    if (/^(?:تعديل الموعد|عدّل الموعد|عدل الموعد|غيّر الموعد|غير الموعد|حدّث الموعد|حدث الموعد)(?=$|\s|[،,:;|])/iu.test(text)) {
      const fields = parseFields(text), session = this.session(id), header = String(text).split(/[|\n]/, 1)[0].trim();
      const headerSelector = header.replace(/^(?:تعديل الموعد|عدّل الموعد|عدل الموعد|غيّر الموعد|غير الموعد|حدّث الموعد|حدث الموعد)\s*/iu, '').trim();
      const selector = clean(fields.taskId || fields.taskName || headerSelector, 120);
      if (!selector) throw new Error('حدّد الموعد بالاسم أو المعرّف: عدّل الموعد تذكير | الوقت=19:30. ويمكن استخدام الموعد=... داخل الحقول.');
      const query = norm(selector), hits = (session.automation.tasks || []).filter(task => norm(task.id) === query || norm(task.name) === query || (query.length >= 3 && norm(task.name).includes(query)));
      if (hits.length !== 1) throw new Error(hits.length ? 'اسم الموعد غير فريد؛ استخدم المعرّف من «اعرض المواعيد» أو اكتب الاسم كاملًا.' : 'لم أجد الموعد. اكتب «اعرض المواعيد» ثم استخدم اسمه أو معرّفه.');
      const task = hits[0], body = { ...task };
      if (fields.newName !== undefined) body.name = clean(fields.newName, 100);
      else if (fields.name !== undefined && (fields.taskName !== undefined || fields.taskId !== undefined || headerSelector)) body.name = clean(fields.name, 100);
      if (fields.repeat !== undefined) {
        const repeat = norm(fields.repeat);
        if (/مرة|واحد|one|once/.test(repeat)) body.mode = 'once';
        else if (/اسبوع|أسبوع|weekly/.test(repeat)) body.mode = 'weekly';
        else if (/شهر|monthly/.test(repeat)) body.mode = 'monthly';
        else if (/سن|yearly|annual/.test(repeat)) body.mode = 'yearly';
        else throw new Error('التكرار غير معروف. استخدم مرة أو أسبوعي أو شهري أو سنوي.');
      }
      for (const key of ['date','time','month','year','dayOfMonth','preText','postText','text']) if (fields[key] !== undefined) body[key] = fields[key];
      if (fields.day !== undefined) {
        const dayText = norm(fields.day), dayByName = weekdayNumber(fields.day);
        const numericDay = /^\d$/.test(dayText) ? Number(dayText) : null;
        if (dayByName === null && numericDay === null) throw new Error('اليوم غير معروف. اكتب اسم اليوم أو رقمه من 0 إلى 6.');
        body.day = dayByName ?? numericDay;
      }
      if (fields.to !== undefined) body.targetKeys = this.targetKeys(id, fields.to, { allowAll:true, requireConfirm:true, confirm:fields.confirm || '' });
      if (fields.file !== undefined || fields.files !== undefined || fields.mediaMode !== undefined) {
        const filesRaw = String(fields.files ?? fields.file ?? '').trim(), mediaModeRaw = norm(fields.mediaMode || '');
        if (/دورة|صور\s*الدوره|cycle/.test(mediaModeRaw) || /دورة|صور\s*الدوره|cycle/.test(norm(filesRaw))) { body.mediaMode = 'cycle'; body.mediaIds = []; }
        else if (/selected|مختاره|محدده/.test(mediaModeRaw)) body.mediaMode = 'selected';
        else if (fields.file !== undefined || fields.files !== undefined) {
          body.mediaMode = 'selected';
          if (!filesRaw || /^(?:لا|بدون|حذف|none|clear)$/iu.test(filesRaw)) body.mediaIds = [];
          else {
            const available = this.delivery.files(id), resolvedFiles = [];
            for (const name of filesRaw.split(/[,،;؛]/).map(value => value.trim()).filter(Boolean)) {
              const matches = available.filter(file => norm(file.id) === norm(name) || norm(file.filename) === norm(name) || norm(file.filename).includes(norm(name)));
              if (matches.length !== 1) throw new Error(`الملف «${name}» غير موجود أو غير فريد. استخدم الاسم الكامل من «اعرض الوسائط».`);
              resolvedFiles.push(matches[0].id);
            }
            body.mediaIds = resolvedFiles;
          }
        }
      }
      if (fields.mediaMode !== undefined && !/دورة|صور\s*الدوره|cycle/.test(norm(fields.mediaMode))) body.mediaMode = 'selected';
      if (fields.textMode !== undefined) {
        const textMode = norm(fields.textMode);
        if (/تعليق|caption/.test(textMode)) body.textMode = 'caption';
        else if (/قبل|before/.test(textMode)) body.textMode = 'before';
        else if (/بعد|after/.test(textMode)) body.textMode = 'after';
        else if (/لا\s*ترسل|بدون|none/.test(textMode)) body.textMode = 'none';
        else if (/تلقائي|auto/.test(textMode)) body.textMode = 'auto';
        else throw new Error('طريقة النص غير واضحة. استخدم تلقائي أو تعليق أو قبل أو بعد أو بدون.');
      }
      if (fields.sendAsDocument !== undefined) body.sendAsDocument = /^(?:نعم|صح|true|yes|1|on)$/iu.test(String(fields.sendAsDocument).trim());
      for (const key of ['sendDelayMs','graceMinutes']) if (fields[key] !== undefined) {
        const value = Number(fields[key]);
        const min = key === 'graceMinutes' ? 1 : 0, max = key === 'graceMinutes' ? 180 : 60000;
        if (!Number.isInteger(value) || value < min || value > max) throw new Error(key === 'graceMinutes' ? 'مهلة التنفيذ بين 1 و180 دقيقة.' : 'تأخير الإرسال يجب أن يكون بين 0 و60000 مللي ثانية.');
        body[key] = value;
      }
      const normalized = this.normalizeAutomationPayload(id, body, task);
      const taskId = task.id;
      Object.assign(task, normalized, { id:taskId, enabled:true, lastRunKey:'', lastFailureKey:'', lastResult:null, lastAttemptAt:'', updatedAt:new Date().toISOString() });
      this.store.saveSession(session);
      const verified = this.session(id).automation.tasks.find(item => item.id === taskId);
      if (!verified || verified.enabled === false || verified.time !== body.time || verified.text !== body.text) throw new Error('لم أستطع التحقق من حفظ تعديلات الموعد؛ راجع الموعد من لوحة الجدولة.');
      return this.reply(`✅ تم تعديل الموعد «${verified.name}» وحفظه وإعادة تفعيله.\nالوقت: ${verified.time}\nالتكرار: ${verified.mode}\nالأهداف: ${verified.targetKeys.length}\nالرسالة: ${String(verified.text || '').slice(0, 160) || 'بدون نص رئيسي'}`, 'edit-schedule');
    }
    if (/^(?:نفّذ الموعد|نفذ الموعد|شغّل الموعد الآن|شغل الموعد الآن)\s+/iu.test(text)) {
      const query=norm(text.replace(/^(?:نفّذ الموعد|نفذ الموعد|شغّل الموعد الآن|شغل الموعد الآن)\s+/iu,'')), s=this.session(id);
      const hits=(s.automation.tasks||[]).filter(t=>norm(t.id)===query||norm(t.name)===query||norm(t.name).includes(query));
      if(hits.length!==1) throw new Error(hits.length?'اسم الموعد غير فريد؛ استخدم المعرّف من «اعرض المواعيد».':'لم أجد الموعد.');
      const task=hits[0]; if(!this.whatsapp.listRuntime(id).ready) throw new Error('اربط WhatsApp أولًا قبل التنفيذ.');
      const result=await this.delivery.scheduledTaskRun(id,task); const sent=Array.isArray(result.sent)?result.sent.length:0, failed=Array.isArray(result.failed)?result.failed.length:0;
      if(failed || result.ok===false) return this.reply(`⚠️ لم يكتمل الموعد: نجح ${sent} وفشل ${failed}. ${result.error||'راجع أخطاء الأهداف قبل إعادة التشغيل؛ لم أعد إرسال النجاحات تلقائيًا.'}`, 'run-schedule');
      return this.reply(`✅ أعاد محرك الإرسال نتيجة مكتملة للموعد «${task.name}»: ${sent} عملية.`, 'run-schedule');
    }
    if (/^(?:أوقف الموعد|اوقف الموعد|عطّل الموعد|عطل الموعد|فعّل الموعد|فعل الموعد|احذف الموعد|حذف الموعد)\s+/iu.test(text)) {
      const m=text.match(/^(?:أوقف الموعد|اوقف الموعد|عطّل الموعد|عطل الموعد|فعّل الموعد|فعل الموعد|احذف الموعد|حذف الموعد)\s+(.+)$/iu), query=norm(m?.[1]||''), s=this.session(id);
      const hits=(s.automation.tasks||[]).filter(t=>norm(t.id)===query||norm(t.name)===query||norm(t.name).includes(query));
      if(hits.length!==1) throw new Error(hits.length?'اسم الموعد غير فريد؛ استخدم ID من «اعرض المواعيد».':'لم أجد الموعد. اكتب «اعرض المواعيد».');
      const t=hits[0];
      if (/^احذف|^حذف/.test(text)) s.automation.tasks=s.automation.tasks.filter(x=>x.id!==t.id);
      else { const enable=/^فعّل|^فعل/.test(text); if(enable&&t.mode==='once'){const planned=require('./scheduler').zonedDateToUtc(t.date,t.time,s.settings.timezone);if(!planned||planned.getTime()<Date.now()-Number(t.graceMinutes||30)*60000)throw new Error('هذا الموعد انتهى؛ أنشئ موعدًا جديدًا أو حدّثه من اللوحة.');} t.enabled=enable;t.updatedAt=new Date().toISOString(); }
      const deleting=/^احذف|^حذف/.test(text), desired=!deleting&&/^فعّل|^فعل/.test(text), taskId=t.id;
      this.store.saveSession(s); const check=this.session(id).automation.tasks.find(x=>x.id===taskId);
      if(deleting ? Boolean(check) : (!check||check.enabled!==desired))throw new Error('لم يتم التحقق من حفظ تعديل الموعد.');
      return this.reply(`✅ تم ${deleting?'حذف':desired?'تفعيل':'إيقاف'} الموعد «${t.name}» فعليًا.`, 'manage-schedule');
    }
    if (/^أرسل الآن|^ارسل الان|^أرسل رسالة|^ارسل رسالة/iu.test(text)) {
      const f=parseFields(text), message=f.text || '', targetKeys=this.targetKeys(id,f.to,{allowAll:true,requireConfirm:true,confirm:f.confirm||''}), files=this.delivery.files(id), fileIds=[];
      for(const rawName of String(f.file||f.files||'').split(/[,،;؛]/).map(x=>x.trim()).filter(Boolean)) { const found=files.filter(x=>norm(x.id)===norm(rawName)||norm(x.filename)===norm(rawName)||norm(x.filename).includes(norm(rawName))); if(found.length!==1)throw new Error(`الملف «${rawName}» غير موجود أو غير فريد؛ اكتب الاسم الكامل.`); fileIds.push(found[0].id); }
      if(!message&&!fileIds.length) throw new Error('حدد الرسالة=... أو ملف=اسم_الملف.');
      if(targetKeys.length>1 && norm(f.to)!=='الكل' && norm(f.to)!=='all') { /* explicit multi-target names are allowed */ }
      if(targetKeys.length>1 && ['الكل','all','الجميع','كل المستلمين'].includes(norm(f.to)) && norm(f.confirm)!=='نعم') throw new Error('لمنع الإرسال العرضي، أضف «تأكيد=نعم» عند الإرسال للجميع.');
      const result=await this.delivery.sendNow(id,{targetKeys,mediaIds:fileIds,text:message,textMode:'auto',captionMode:true,repeatGuard:true,sendDelayMs:this.session(id).settings.sendDelayMs});
      const verified=Array.isArray(result.sent)?result.sent.length:0, failed=Array.isArray(result.failed)?result.failed.length:0;
      if(failed || result.ok===false) { const names=(result.failed||[]).slice(0,5).map(x=>`${x.target||'هدف'}: ${x.error||'خطأ'}`).join('\n'); return this.reply(`${verified?`⚠️ اكتمل الإرسال جزئيًا: نجح ${verified} وفشل ${failed}.`:'❌ فشل الإرسال.'}\n${names||result.error||'لم يؤكد محرك الإرسال نجاح كل العمليات.'}\nراجع سجل النتائج قبل إعادة المحاولة.`, 'send-result'); }
      return this.reply(`✅ أكد محرك الإرسال نجاح ${verified} عملية.\nالمستلمون: ${targetKeys.length}\nالملفات: ${fileIds.length}\n${message?'تم تضمين الرسالة.':''}`, 'send-result');
    }
    if (/^(?:غيّر اسم المستلم|غير اسم المستلم|عدّل اسم المستلم|عدل اسم المستلم)\s+/iu.test(text)) {
      const m = text.match(/^(?:غيّر اسم المستلم|غير اسم المستلم|عدّل اسم المستلم|عدل اسم المستلم)\s+(.+?)\s+(?:إلى|الى|لـ|ل)\s+(.+)$/iu);
      if (!m) throw new Error('الصيغة: غيّر اسم المستلم أحمد إلى أحمد الجديد.');
      const s=this.session(id), from=norm(m[1]), to=clean(m[2],80); if(!to) throw new Error('الاسم الجديد فارغ.');
      const hits=s.recipients.filter(r=>norm(r.name)===from || String(r.digits||r.phone||r.e164||'').replace(/\D/g,'')===m[1].replace(/\D/g,''));
      if(hits.length!==1) throw new Error(hits.length?'الاسم غير فريد؛ استخدم رقم الهاتف.':'لم أجد المستلم القديم.');
      hits[0].name=to; this.store.saveSession(s); const checked=this.session(id).recipients.find(r=>r.id===hits[0].id);
      if(!checked||checked.name!==to) throw new Error('لم يتم التحقق من حفظ الاسم الجديد.');
      return this.reply(`✅ تم تغيير اسم المستلم وحفظه: ${to} (${checked.international||checked.e164||checked.digits}).`, 'rename-recipient');
    }
    if (/^(?:احذف المستلم|حذف المستلم|احذف الرقم|حذف الرقم|أزل المستلم|ازل المستلم)\s+/iu.test(text)) {
      const rawQuery=text.replace(/^(?:احذف المستلم|حذف المستلم|احذف الرقم|حذف الرقم|أزل المستلم|ازل المستلم)\s+/iu,''), query=norm(rawQuery),s=this.session(id),digits=normalizedPhoneDigits(rawQuery);
      const hits=s.recipients.filter(r=>norm(r.name)===query||(digits.length>=6&&[r.digits,r.phone,r.e164].some(v=>String(v||'').replace(/\D/g,'')===digits))); if(hits.length!==1)throw new Error(hits.length?'الاسم غير فريد؛ استخدم رقم الهاتف.':'لم أجد المستلم.');
      const target=hits[0];s.recipients=s.recipients.filter(r=>r.id!==target.id);const key=`r:${target.id}`;s.settings.scheduleTargetKeys=(s.settings.scheduleTargetKeys||[]).filter(x=>x!==key);s.automation.tasks=(s.automation.tasks||[]).map(t=>({...t,targetKeys:(t.targetKeys||[]).filter(x=>x!==key)})).filter(t=>(t.targetKeys||[]).length||t.text||t.preText||t.postText||(t.mediaIds||[]).length);this.store.saveSession(s);
      if(this.session(id).recipients.some(r=>r.id===target.id))throw new Error('تعذر التحقق من حذف الرقم.');return this.reply(`✅ حُذف المستلم «${target.name}» من هذه الجلسة وأزيل من قوائم المواعيد.`, 'delete-recipient');
    }
    if (/^(?:فعّل المستلم|فعل المستلم|شغّل المستلم|شغل المستلم|عطّل المستلم|عطل المستلم|أوقف المستلم|اوقف المستلم)\s+/iu.test(text)) {
      const m=text.match(/^(?:فعّل المستلم|فعل المستلم|شغّل المستلم|شغل المستلم|عطّل المستلم|عطل المستلم|أوقف المستلم|اوقف المستلم)\s+(.+)$/iu),rawQ=m?.[1]||'',q=norm(rawQ),digits=normalizedPhoneDigits(rawQ),s=this.session(id),hits=s.recipients.filter(r=>norm(r.name)===q||(digits&&[r.digits,r.phone,r.e164].some(v=>String(v||'').replace(/\D/g,'')===digits)));if(hits.length!==1)throw new Error(hits.length?'الاسم غير فريد؛ استخدم رقم الهاتف.':'لم أجد المستلم.');const on=/^(?:فعّل|فعل|شغّل|شغل)/iu.test(text);hits[0].enabled=on;this.store.saveSession(s);return this.reply(`✅ ${on?'تم تفعيل':'تم إيقاف'} المستلم «${hits[0].name}» وحُفظ التغيير.`, 'toggle-recipient');
    }
    if (/^(?:غيّر اسم المجموعة|غير اسم المجموعة|عدّل اسم المجموعة|عدل اسم المجموعة)\s+.+\s+(?:إلى|الى)\s+.+$/iu.test(text)) {
      const m=text.match(/^(?:غيّر اسم المجموعة|غير اسم المجموعة|عدّل اسم المجموعة|عدل اسم المجموعة)\s+(.+?)\s+(?:إلى|الى)\s+(.+)$/iu);
      const from=norm(m?.[1]||''), to=clean(m?.[2]||'',120), s=this.session(id);
      if(!to)throw new Error('اكتب الاسم المحلي الجديد للمجموعة.');
      const hits=s.groups.filter(g=>norm(g.name)===from||String(g.gid||'').toLowerCase()===String(m?.[1]||'').toLowerCase());
      if(hits.length!==1)throw new Error(hits.length?'اسم المجموعة غير فريد؛ استخدم GID.':'لم أجد المجموعة القديمة.');
      if (s.groups.some(g => g.id !== hits[0].id && norm(g.name) === norm(to))) throw new Error(`الاسم «${to}» مستخدم بالفعل لمجموعة أخرى؛ اختر اسمًا فريدًا لتجنب الالتباس.`);
      const old=hits[0].name; hits[0].name=to; hits[0].updatedAt=new Date().toISOString(); this.store.saveSession(s);
      const verified=this.session(id).groups.find(g=>g.id===hits[0].id);
      if(!verified||verified.name!==to)throw new Error('لم يتم التحقق من حفظ الاسم المحلي الجديد.');
      return this.reply(`✅ تم تحديث الاسم داخل chat BOT فقط: «${old}» ← «${to}». لم أغيّر اسم مجموعة WhatsApp نفسها.\nGID: ${verified.gid}`, 'rename-group-local');
    }
    if (/^(?:احذف المجموعة|حذف المجموعة|أوقف المجموعة|اوقف المجموعة|عطّل المجموعة|عطل المجموعة|فعّل المجموعة|فعل المجموعة)\s+/iu.test(text)) {
      const m=text.match(/^(?:احذف المجموعة|حذف المجموعة|أوقف المجموعة|اوقف المجموعة|عطّل المجموعة|عطل المجموعة|فعّل المجموعة|فعل المجموعة)\s+(.+)$/iu),q=norm(m?.[1]||''),s=this.session(id),hits=s.groups.filter(g=>norm(g.name)===q||String(g.gid||'').toLowerCase()===String(m?.[1]||'').toLowerCase());if(hits.length!==1)throw new Error(hits.length?'اسم المجموعة غير فريد؛ استخدم GID.':'لم أجد المجموعة.');const g=hits[0];
      const deleting=/^(?:احذف|حذف)/.test(text), oldId=g.id, oldName=g.name;
      if (deleting){s.groups=s.groups.filter(x=>x.id!==g.id);const key=`g:${g.id}`;s.settings.scheduleTargetKeys=(s.settings.scheduleTargetKeys||[]).filter(x=>x!==key);s.automation.tasks=(s.automation.tasks||[]).map(t=>({...t,targetKeys:(t.targetKeys||[]).filter(x=>x!==key)})).filter(t=>(t.targetKeys||[]).length||t.text||t.preText||t.postText||(t.mediaIds||[]).length);}else g.enabled=/^(?:فعّل|فعل)/iu.test(text);
      const desired=!deleting&&g.enabled;
      this.store.saveSession(s);const check=this.session(id).groups.find(x=>x.id===oldId);
      if(deleting?Boolean(check):(!check||check.enabled!==desired))throw new Error('لم يتم التحقق من حفظ تعديل المجموعة.');
      return this.reply(`✅ تم ${deleting?'حذف':desired?'تفعيل':'إيقاف'} المجموعة «${oldName}» من قائمة الجلسة. لم يُحذف الأصل من WhatsApp.`, 'manage-group');
    }
    if (/^(?:فعّل اختبار التفاعل مع نفسي|فعل اختبار التفاعل مع نفسي|أوقف اختبار التفاعل مع نفسي|اوقف اختبار التفاعل مع نفسي)$/iu.test(text)) { /* handled above but keep explicit alias compatibility */ }
    return { handled:false, response:unknownCommandResponse(originalText) };
  }
}

module.exports = { LocalCommandEngine, HELP, HELP_TOPICS, topicHelp, unknownCommandResponse, parseFields, norm, weekdayNumber, commandTriggerMatch, prepareCommandInput, canonicalizeCommandHead, naturalSendCommand };
