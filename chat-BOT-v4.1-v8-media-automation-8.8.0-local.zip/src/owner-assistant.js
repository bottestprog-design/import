'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs');
const media = require('./media');
const { LocalCommandEngine, HELP: COMMAND_HELP } = require('./local-command-engine');
function serializedId(value) {
  if (!value) return '';
  if (typeof value === 'string') return value;
  if (value._serialized) return String(value._serialized);
  if (value.$1) return String(value.$1);
  if (value.remote) return serializedId(value.remote);
  return '';
}
function isFromMeMessage(msg) {
  return msg?.fromMe === true || msg?._data?.id?.fromMe === true || msg?.id?.fromMe === true;
}
function validChatId(value) {
  const id = serializedId(value).trim().toLowerCase();
  return id.endsWith('@c.us') || id.endsWith('@g.us') || id.endsWith('@lid') ? id : '';
}
function messageChatIds(msg) {
  const outgoing = isFromMeMessage(msg);
  const values = outgoing
    ? [msg?.id?.remote, msg?._data?.id?.remote, msg?.msgId?.remote, msg?.to, msg?._data?.to, msg?.chatId]
    : [msg?.from, msg?.id?.remote, msg?._data?.id?.remote, msg?.chatId, msg?.to];
  return [...new Set(values.map(validChatId).filter(Boolean))];
}
function messageChatId(msg) { return messageChatIds(msg)[0] || ''; }

function nowIso() { return new Date().toISOString(); }
function short(value, max = 2400) { return String(value ?? '').trim().slice(0, max); }
function safeText(value) { return String(value ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').slice(0, 4000); }
function issueGuide({ route = '', error = '', code = '', status = 400 } = {}) {
  const e = `${code} ${error}`.toLowerCase();
  if (/execution context was destroyed|cannot find context with specified id|most likely because of a navigation/.test(e)) return {
    page: 'session', title: 'تعطّل سياق Chromium أثناء اتصال WhatsApp', severity: 'error',
    steps: ['يعيد النظام محاولة إصلاح سياق Chromium المتعطل حتى 3 مرات بمهل متدرجة؛ لا تضغط «ربط / تشغيل» مرارًا أثناء ظهور «جارٍ إصلاح الاتصال».', 'انتظر حتى يظهر QR أو «متصل». إذا فشل الاسترداد، أوقف الجلسة ثم جرّب اتصالًا واحدًا جديدًا.', 'اترك Puppeteer على النسخة المطابقة لتثبيت whatsapp-web.js وهي 24.38.0، واستخدم Node.js 20 أو أحدث، وتأكد أن Chrome/Chromium قابل للتشغيل من المسار المعروض.', 'لا تحذف مجلد auth ولا تفصل الحساب قبل حفظ نسخة احتياطية. إذا استمر الخطأ، صدّر سجل الجلسة وآخر تفاصيل الخطأ من هذه الصفحة.']
  };
  if (/auth_failure|qr|تسجيل|ربط|واتساب|whatsapp|disconnected|not ready|ليست جاهزة|غير متصل|disconnect/.test(e) || /\/api\/session/.test(route)) return {
    page: 'session', title: 'مشكلة اتصال WhatsApp', severity: 'error',
    steps: ['افتح «الجلسة» وتأكد أنك تعمل على الجلسة المقصودة.', 'اضغط «الاتصال» وانتظر ظهور رمز QR.', 'من WhatsApp في الهاتف: الأجهزة المرتبطة ← ربط جهاز، ثم امسح الرمز.', 'انتظر حتى تظهر الحالة «متصل». إذا بقيت الحالة معلّقة، اضغط «تشخيص الجلسة» واقرأ النتيجة.', 'إذا ظل الخطأ قائمًا، أوقف هذه الجلسة فقط ثم أعد ربطها؛ لا تحذف مجلد auth يدويًا قبل أخذ نسخة احتياطية.'],
  };
  if (/group|مجموعة|gid|invite|دعوة/.test(e) || /\/api\/groups/.test(route)) return {
    page: 'groups', title: 'مشكلة في المجموعة أو تحديدها', severity: 'error',
    steps: ['افتح «المجموعات» داخل الجلسة التي تحتوي حساب WhatsApp الصحيح.', 'نفّذ «اكتشاف المجموعات» بعد التأكد من اتصال الحساب.', 'اختر المجموعة من القائمة المكتشفة، وتحقق من GID الذي ينتهي بـ @g.us.', 'لا تستخدم اسم المجموعة وحده كمعرّف؛ إذا أضفتها يدويًا، استخدم GID صحيحًا ثم حدّث بياناتها.', 'ارجع إلى الإرسال وحدد المجموعة مرة أخرى.'],
  };
  if (/recipient|phone|number|رقم|مستلم|غير مسجل|غير صالح/.test(e) || /\/api\/recipient|\/api\/send/.test(route)) return {
    page: /recipient|phone|number|رقم|مستلم/.test(e) ? 'people' : 'send', title: 'مشكلة في المستلم أو الإرسال', severity: 'error',
    steps: ['تأكد من أن قائمة الجلسة الحالية هي الجلسة المرتبطة بالرقم الصحيح.', 'في «الأشخاص»، راجع رمز الدولة والرقم الدولي؛ لا تضف صفرًا محليًا بعد رمز الدولة.', 'إذا كان الهدف مجموعة، اخترها من قسم «المجموعات» بدل إضافتها كرقم شخص.', 'في «الإرسال»، امسح الاختيار القديم ثم حدد مستلمًا واحدًا للاختبار.', 'أرسل نصًا قصيرًا أولًا. بعد نجاحه، أضف صورة/ملفًا ثم راجع نتيجة كل هدف قبل إعادة المحاولة لتجنب التكرار.'],
  };
  if (/media|file|upload|ملف|صورة|حجم/.test(e) || /\/api\/media/.test(route)) return {
    page: 'send', title: 'مشكلة في الملف أو المرفق', severity: 'warning',
    steps: ['افتح «الإرسال» وتأكد أن الملف ظاهر في مكتبة الوسائط.', 'تحقق من الامتداد المدعوم وحجم الملف ضمن الحد الموجود في الإعدادات.', 'أزل الملف من اختيار الإرسال ثم حدده مرة أخرى؛ لا تحذف الملف من المكتبة إلا إذا كنت تريد حذفه فعلًا.', 'أرسل الملف إلى مستلم واحد مع رسالة بسيطة، وتحقق من نتيجة الإرسال.'],
  };
  if (/session|جلسة/.test(e) || /\/api\/sessions/.test(route)) return {
    page: 'session', title: 'مشكلة في الجلسة أو حفظها', severity: 'error',
    steps: ['افتح «الجلسة» وتحقق من اسم الجلسة الحالية.', 'تأكد أن الجلسة المطلوبة محددة قبل تنفيذ الإجراء.', 'بدّل إلى جلسة أخرى ثم ارجع إلى الجلسة المطلوبة؛ كل الجلسات يجب أن تحتفظ بقوائمها ووسائطها منفصلة.', 'لا تحذف ملفات الجلسة يدويًا. إذا ظهرت جلسة محذوفة من جديد، حدّث الصفحة وتحقق من سجل مركز المساعد.'],
  };
  if (Number(status) >= 500) return {
    page: 'settings', title: 'خطأ داخلي في التطبيق', severity: 'error',
    steps: ['افتح «الإعدادات» ثم «التشغيل والتشخيص».', 'حدّث الصفحة مرة واحدة وتحقق من أن الخطأ يتكرر.', 'احفظ رسالة الخطأ من مركز المساعد دون نشر أرقام الهاتف أو بيانات المصادقة.', 'أعد تشغيل التطبيق فقط إذا توقف الخادم عن الاستجابة؛ لا تمسح مجلد data.'],
  };
  return {
    page: 'dashboard', title: 'حدثت مشكلة أثناء تنفيذ العملية', severity: Number(status) >= 500 ? 'error' : 'warning',
    steps: ['اقرأ تفاصيل الخطأ المسجلة أدناه.', 'تحقق من الجلسة الحالية والاتصال قبل إعادة المحاولة.', 'افتح القسم المرتبط بالمشكلة من زر «فتح القسم».', 'إذا تكرر الخطأ، نفّذ التشخيص واحفظ النتيجة.'],
  };
}

class OwnerAssistant {
  constructor({ store, whatsapp, log, delivery, groups, phones, saveGroup, normalizeAutomationPayload, interaction, refreshRecipientProfile }) { this.store = store; this.whatsapp = whatsapp; this.log = log || (() => {}); this.interaction = interaction || null; this.readyLocks = new Set(); this.commands = new LocalCommandEngine({ store, whatsapp, delivery, log:this.log, saveGroup, normalizeAutomationPayload, interaction:this.interaction, refreshRecipientProfile }); }
  state(id) {
    const s = this.store.loadSession(id);
    if (!s.ownerAssistant) s.ownerAssistant = { ownerPhone:'', ownerPhoneConfirmed:false, notificationsEnabled:true, notificationMode:'self', welcomeCreatedAt:'', welcomeSentAt:'', welcomeAttemptedAt:'', conversation:null, replySessionId:'', replySessionEnabled:false, replySessionConfirmedAt:'', linkedProcessedMessageIds:[], messages:[], issues:[], activity:[], pendingNotifications:[] };
    if (!Array.isArray(s.ownerAssistant.messages)) s.ownerAssistant.messages = [];
    if (!Array.isArray(s.ownerAssistant.issues)) s.ownerAssistant.issues = [];
    if (!Array.isArray(s.ownerAssistant.pendingNotifications)) s.ownerAssistant.pendingNotifications = [];
    if (!Array.isArray(s.ownerAssistant.linkedProcessedMessageIds)) s.ownerAssistant.linkedProcessedMessageIds = [];
    if (s.ownerAssistant.replySessionEnabled !== true) s.ownerAssistant.replySessionEnabled = false;
    if (!Array.isArray(s.ownerAssistant.activity)) s.ownerAssistant.activity = [];
    return s;
  }
  addMessage(session, role, text, meta = {}) {
    const feed = session.ownerAssistant;
    const entry = { id: crypto.randomUUID(), role, text: safeText(text), at: nowIso(), page: meta.page || 'owner-center', issueId: meta.issueId || null, kind: meta.kind || 'message', delivery: meta.delivery || null };
    feed.messages = [...(feed.messages || []), entry].slice(-250);
    return entry;
  }
  addActivity(session, input = {}) {
    const feed = session.ownerAssistant;
    if (!Array.isArray(feed.activity)) feed.activity = [];
    const message = safeText(input.message || input.text || 'تم تنفيذ إجراء.').trim().slice(0, 1200);
    const type = ['success', 'error', 'warning', 'info'].includes(input.type) ? input.type : 'info';
    const page = short(input.page || 'dashboard', 80);
    const stamp = Date.now();
    const same = [...feed.activity].reverse().find(item => item.message === message && item.type === type && item.page === page && stamp - Date.parse(item.at || 0) < 5000);
    if (same) {
      same.count = Math.min(9999, Number(same.count || 1) + 1);
      same.lastSeenAt = nowIso();
      same.issueId = same.issueId || input.issueId || null;
      return same;
    }
    const item = { id: crypto.randomUUID(), message, type, page, at: nowIso(), lastSeenAt: nowIso(), count: 1, issueId: input.issueId || null, source: short(input.source || 'ui', 40) };
    feed.activity = [...feed.activity, item].slice(-300);
    return item;
  }
  recordActivity(id, input = {}) {
    const session = this.state(id);
    const item = this.addActivity(session, input);
    this.store.saveSession(session);
    return item;
  }
  async sendConfigured(id, text) {
    const s = this.state(id), c = s.ownerAssistant;
    if (c.notificationMode === 'phone' && (!c.ownerPhone || !c.ownerPhoneConfirmed)) throw new Error('إشعارات رقم المالك غير مفعّلة لأن الرقم لم يُؤكَّد.');
    if (c.replySessionEnabled && c.replySessionId) return this.sendViaReplySession(id, text);
    return this.whatsapp.sendOwnerNotification(id, text, { mode: c.notificationMode, phone: c.ownerPhone });
  }
  async recordIssue(id, input = {}, { notify = true } = {}) {
    const s = this.state(id), center = s.ownerAssistant, guide = issueGuide(input), current = nowIso(), stamp = Date.now();
    const route = short(input.route || '', 180), code = short(input.code || 'APP_ERROR', 80), details = short(input.error || input.details || 'لا توجد تفاصيل إضافية.', 1200);
    const same = [...center.issues].reverse().find(x => x.code === code && x.route === route && x.status === 'open' && stamp - Date.parse(x.lastSeenAt || x.createdAt) < 90000);
    if (same) {
      same.count = Math.min(9999, Number(same.count || 1) + 1); same.lastSeenAt = current; same.details = details;
      this.store.saveSession(s); return { issue: same, deduplicated: true };
    }
    const issue = { id: crypto.randomUUID(), code, title: short(input.title || guide.title, 160), severity: input.severity || guide.severity, details, route, page: input.page || guide.page, steps: Array.isArray(input.steps) && input.steps.length ? input.steps.map(x => short(x, 300)).slice(0, 8) : guide.steps, status: 'open', count: 1, createdAt: current, lastSeenAt: current, notifiedAt: null, notificationError: '' };
    center.issues = [...center.issues, issue].slice(-200);
    this.addActivity(s, { message: `${issue.title}: ${details}`, type: issue.severity === 'error' ? 'error' : 'warning', page: issue.page, issueId: issue.id, source: 'diagnostics' });
    const text = `⚠️ chat BOT | ${issue.title}\nالمشكلة: ${issue.details}\nالمكان: ${issue.page}\nالحل المقترح:\n${issue.steps.map((x, i) => `${i + 1}. ${x}`).join('\n')}`;
    this.addMessage(s, 'assistant', text, { page: issue.page, issueId: issue.id, kind: 'issue' });
    if (notify && center.notificationsEnabled && !center.pendingNotifications.includes(issue.id)) center.pendingNotifications.push(issue.id);
    this.store.saveSession(s);
    if (notify && center.notificationsEnabled && this.whatsapp.listRuntime(id).ready) await this.deliverIssueNotification(id, issue.id);
    return { issue, deduplicated: false };
  }
  async deliverIssueNotification(id, issueId) {
    const s = this.state(id), center = s.ownerAssistant, issue = center.issues.find(x => x.id === issueId);
    if (!issue || issue.notifiedAt || !center.notificationsEnabled || !this.whatsapp.listRuntime(id).ready) return { sent: false, queued: true };
    const text = `⚠️ chat BOT | ${issue.title}\n${issue.details}\nالقسم: ${issue.page}\nالخطوات:\n${issue.steps.map((x, i) => `${i + 1}) ${x}`).join('\n')}\nافتح لوحة chat BOT ← ${issue.page}`.slice(0, 3500);
    try {
      const result = await this.sendConfigured(id, text);
      const fresh = this.state(id), c = fresh.ownerAssistant, current = c.issues.find(x => x.id === issueId);
      if (current) { current.notifiedAt = nowIso(); current.notificationError = ''; }
      c.pendingNotifications = c.pendingNotifications.filter(x => x !== issueId);
      this.addMessage(fresh, 'assistant', 'تم إرسال تنبيه المشكلة إلى محادثة المالك في WhatsApp.', { page: issue.page, issueId, kind: 'notification', delivery: result.ack });
      this.store.saveSession(fresh); return { sent: true, result };
    } catch (error) {
      const fresh = this.state(id), current = fresh.ownerAssistant.issues.find(x => x.id === issueId);
      if (current) current.notificationError = short(error.message || error, 600);
      this.store.saveSession(fresh); return { sent: false, queued: true, error: error.message || String(error) };
    }
  }
  resolveRecoveredConnectionIssues(id) {
    const s = this.state(id), c = s.ownerAssistant, rt = this.whatsapp.listRuntime(id);
    if (!rt.ready) return 0;
    const selfId = this.whatsapp.selfChatId(id);
    const resolvedIds = new Set(); let changed = false, count = 0;
    for (const issue of c.issues || []) {
      if (issue.status !== 'open') continue;
      const connectionIssue = ['WHATSAPP_DISCONNECTED','WHATSAPP_AUTH_FAILURE','DIAGNOSTIC_WHATSAPP'].includes(issue.code);
      const selfIssue = Boolean(selfId) && ['DIAGNOSTIC_SELF-CHAT','OWNER_SELF_CHAT_ID_MISSING'].includes(issue.code);
      if (!connectionIssue && !selfIssue) continue;
      issue.status = 'resolved'; issue.resolvedAt = nowIso(); issue.resolvedBy = 'auto-recovery';
      issue.resolutionNote = connectionIssue ? 'تم رصد حالة اتصال جاهزة؛ أُغلقت المشكلة القديمة تلقائيًا.' : 'تم التعرف على معرف محادثة المالك بعد نجاح الاتصال.';
      resolvedIds.add(issue.id); changed = true; count++;
    }
    if (resolvedIds.size) c.pendingNotifications = (c.pendingNotifications || []).filter(id => !resolvedIds.has(id));
    if (changed) this.store.saveSession(s);
    return count;
  }
  async onReady(id) {
    if (this.readyLocks.has(id)) return;
    this.readyLocks.add(id);
    try {
      this.resolveRecoveredConnectionIssues(id);
      let s = this.state(id), center = s.ownerAssistant;
      const welcomeVersion = '8.8.0';
      const welcome = `🤖 chat BOT — تم ربط WhatsApp بنجاح.\nمرحبًا! هذه محادثتك الخاصة بالمساعد لهذه الجلسة. يمكنك التحدث بعبارات طبيعية محفوظة في المشروع، وسأطلب الحقول واحدًا واحدًا مع توضيح ما سيُحفظ. الأوامر المحلية لا تحتاج API ذكاء اصطناعي، ولن أؤكد النجاح إلا بعد التحقق.\n\n${COMMAND_HELP}`;
      const hadLocalWelcome = Boolean(center.welcomeCreatedAt);
      const welcomeNeedsUpdate = center.welcomeVersion !== welcomeVersion;
      if (!center.welcomeCreatedAt || welcomeNeedsUpdate) {
        center.welcomeCreatedAt = center.welcomeCreatedAt || nowIso();
        center.welcomeVersion = welcomeVersion;
        if (welcomeNeedsUpdate) { center.welcomeSentVersion = ''; center.welcomeSentAt = ''; }
        this.addMessage(s, 'assistant', welcome, { page: 'owner-center', kind: hadLocalWelcome && welcomeNeedsUpdate ? 'welcome-update' : 'welcome' });
        this.store.saveSession(s);
      }
      // Send/re-send welcome on first connection and on an app upgrade so existing users get the current command list.
      // Delivery is version-tracked separately from local creation and remains retryable after network failures.
      s = this.state(id); center = s.ownerAssistant;
      if (center.notificationsEnabled && center.welcomeSentVersion !== welcomeVersion) {
        center.welcomeAttemptedAt = nowIso(); this.store.saveSession(s);
        try {
          const result = await this.sendConfigured(id, welcome);
          const fresh = this.state(id); fresh.ownerAssistant.welcomeSentAt = nowIso(); fresh.ownerAssistant.welcomeSentVersion = welcomeVersion;
          this.addMessage(fresh, 'assistant', 'تم إرسال رسالة الترحيب وقائمة أوامر الإصدار الحالي إلى WhatsApp.', { page: 'owner-center', kind: 'notification', delivery: result.ack });
          this.store.saveSession(fresh);
        } catch (error) {
          await this.recordIssue(id, { code:'OWNER_WELCOME_FAILED', title:'تعذّر إرسال الترحيب إلى WhatsApp', error:error.message || String(error), route:'/api/assistant/center', page:'owner-center', steps:['رسالة الترحيب محفوظة داخل مركز المساعد ولن تضيع.', 'تأكد أن الجلسة تظهر «متصل».', 'إذا كان حساب WhatsApp لا يسمح بمحادثة الرسائل إلى نفسك، سجّل رقمك في مركز المساعد وفعّل تأكيد ملكيته.', 'سيحاول النظام إرسال الترحيب عند نجاح اتصال لاحق، ويمكنك استخدام زر «اختبار الإشعار» للتحقق يدويًا.'] }, { notify:false });
        }
      }
      s = this.state(id); const pending = [...s.ownerAssistant.pendingNotifications];
      for (const issueId of pending) await this.deliverIssueNotification(id, issueId);
    } finally { this.readyLocks.delete(id); }
  }
  diagnostics(id) {
    const s = this.state(id), p = this.store.getPaths(id), rt = this.whatsapp.listRuntime(id), c = s.ownerAssistant;
    const scan = media.scan(p.media, s.settings.maxImageSizeMB);
    const enabledPeople = s.recipients.filter(x => x.enabled !== false).length, enabledGroups = s.groups.filter(x => x.enabled !== false).length;
    const checks = [
      { id:'session', title:'عزل الجلسة', ok:this.store.listSessionIds().includes(s.id) && p.dir.endsWith(s.id), detail:`الجلسة: ${s.name} (${s.id})`, page:'session', steps:['لا تستخدم زر الحذف إلا للجلسة المقصودة.', 'اختبر كل جلسة بإضافة شخص تجريبي مختلف وتأكد أن القوائم لا تتداخل.'] },
      { id:'whatsapp', title:'اتصال WhatsApp', ok:!!rt.ready, severity:['auth_failure','error'].includes(rt.status) ? 'error' : 'warning', detail:`الحالة: ${rt.status}${rt.info?.wid?.user ? ` · الرقم: ${rt.info.wid.user}` : ''}${rt.lastError ? ` · التفاصيل: ${short(rt.lastError, 300)}` : ''}`, page:'session', steps:rt.lastError && /execution context was destroyed|navigation/i.test(rt.lastError) ? ['أزل المشروع خيارات Chromium الإضافية غير الضرورية؛ الإصدار الحالي يشغّل المتصفح بخيارات أقل لتفادي سباق التنقل.', 'اترك النظام يكمل محاولات الاستعادة التلقائية ولا تضغط «ربط / تشغيل» مرارًا.', 'إذا بقيت الحالة «خطأ»، أوقف الجلسة ثم شغّلها مرة واحدة، وانتظر QR أو «متصل».', 'راجع Node.js 20 أو أحدث وPuppeteer 24.38.0 المطابق للمكتبة، وتأكد أن Chrome/Chromium قابل للتشغيل. لا تحذف مجلد auth قبل النسخ الاحتياطي.'] : ['افتح الجلسة الصحيحة.', 'اضغط الاتصال وامسح QR من الأجهزة المرتبطة.', 'انتظر الحالة «متصل».', ...(rt.lastError ? [`آخر خطأ: ${short(rt.lastError, 250)}`] : [])] },
      { id:'people', title:'الأشخاص', ok:enabledPeople > 0, severity:'warning', detail:`${enabledPeople} شخص مفعّل`, page:'people', steps:['افتح الأشخاص.', 'تحقق من رمز الدولة والرقم.', 'فعّل المستلم إذا كان متوقفًا.'] },
      { id:'groups', title:'المجموعات', ok:enabledGroups > 0, severity:'warning', detail:`${enabledGroups} مجموعة مفعّلة`, page:'groups', steps:['افتح المجموعات.', 'اكتشف مجموعات WhatsApp للحساب المرتبط.', 'تحقق من GID ثم اختر المجموعة من الإرسال.'] },
      { id:'media', title:'مكتبة الوسائط', ok:scan.files.length > 0, severity:'info', detail:`${scan.files.length} ملف · ${scan.images.length} صورة`, page:'send', steps:['افتح الإرسال وارفع ملفًا مدعومًا.', 'تأكد أن حجم الملف ضمن الحد المحدد.'] },
      { id:'self-chat', title:'محادثة المالك', ok:!rt.ready || !c.notificationsEnabled || (c.notificationMode === 'self' ? !!rt.info?.wid : !!(c.ownerPhone && c.ownerPhoneConfirmed)), severity:'warning', detail:!rt.ready ? 'سيتم التحقق من معرف محادثة النفس بعد اتصال WhatsApp؛ لا يتم إرسال إشعار قبل الجاهزية.' : (c.notificationMode === 'self' ? (rt.info?.wid ? 'تم التعرف على حساب WhatsApp لهذا الشات.' : 'اتصل الحساب لكن معرف الحساب غير متاح؛ راجع سجل الجلسة.') : (c.ownerPhoneConfirmed ? `رقم مؤكّد: ${c.ownerPhone}` : 'رقم المالك غير مؤكّد.')), page:'owner-center', steps:['تعمل محادثة الدعم محليًا حتى دون WhatsApp.', 'بعد ظهور الحالة «متصل»، تأكد من ظهور رقم الحساب في صفحة الجلسة.', 'إذا ظل معرف الحساب غير متاح بعد الاتصال، أعد تحديث الحالة ثم راجع سجل الجلسة.', 'لإشعارات رقم آخر، سجّل الرقم وفعّل تأكيد الملكية ثم اختبر الإشعار.'] },
    ];
    return { at:nowIso(), sessionId:s.id, sessionName:s.name, ready:!!rt.ready, status:rt.status, checks, openIssues:c.issues.filter(x=>x.status==='open').length, pendingNotifications:c.pendingNotifications.length };
  }
  async runDiagnostics(id, { persist = true } = {}) {
    const result = this.diagnostics(id);
    if (persist) {
      for (const check of result.checks.filter(x => !x.ok && ['whatsapp','self-chat'].includes(x.id))) {
        await this.recordIssue(id, { code:`DIAGNOSTIC_${check.id.toUpperCase()}`, title:check.title, error:check.detail, page:check.page, steps:check.steps, severity:check.severity || 'warning', route:'/api/assistant/diagnostics' });
      }
      const s = this.state(id); s.ownerAssistant.lastDiagnosticsAt = result.at; this.store.saveSession(s);
    }
    return result;
  }
  saveConfig(id, input = {}) {
    const s = this.state(id), c = s.ownerAssistant, mode = input.notificationMode === 'phone' ? 'phone' : 'self';
    const enabled = input.notificationsEnabled !== false;
    let ownerPhone = c.ownerPhone, confirmed = c.ownerPhoneConfirmed;
    if (input.ownerPhone !== undefined) {
      const raw = String(input.ownerPhone || '').trim();
      if (raw) { const parsed = require('./phones').parse(raw, String(input.country || 'OM')); ownerPhone = parsed.e164; }
      else { ownerPhone = ''; confirmed = false; }
    }
    if (input.ownerPhoneConfirmed !== undefined) confirmed = input.ownerPhoneConfirmed === true;
    if (mode === 'phone' && enabled && (!ownerPhone || !confirmed)) throw new Error('أدخل رقمك الدولي، ثم فعّل مربع تأكيد أن الرقم ملكك أو لديك إذن باستقبال الإشعارات عليه.');
    c.ownerPhone = ownerPhone; c.ownerPhoneConfirmed = confirmed; c.notificationMode = mode; c.notificationsEnabled = enabled;
    this.store.saveSession(s); return { ownerAssistant:c };
  }
  sessionPhoneDigits(id) {
    const self = String(this.whatsapp.selfChatId(id) || '').trim().toLowerCase();
    const m = self.match(/^(\d{6,20})@c\.us$/);
    return m ? m[1] : '';
  }
  async sendViaReplySession(id, text) {
    const primary = this.state(id), config = primary.ownerAssistant, senderId = String(config.replySessionId || '');
    if (!config.replySessionEnabled || !senderId || !config.replySessionConfirmedAt) throw new Error('قناة الرد الثانية غير مفعّلة بتأكيد صريح.');
    if (senderId === id || !this.store.listSessionIds().includes(senderId)) throw new Error('جلسة الرد الثانية غير صالحة؛ أوقفها وأعد ربط الجلسة الصحيحة.');
    const primaryRuntime = this.whatsapp.listRuntime(id), senderRuntime = this.whatsapp.listRuntime(senderId);
    if (!primaryRuntime.ready || !senderRuntime.ready) throw new Error('لا أستطيع إرسال الرد من الرقم الثاني لأن أحد الحسابين غير متصل.');
    const primaryPhone = this.sessionPhoneDigits(id), senderPhone = this.sessionPhoneDigits(senderId);
    if (!primaryPhone || !senderPhone) throw new Error('تعذر التحقق من رقم الحساب الأساسي أو الثاني؛ لم أرسل الرسالة.');
    if (primaryPhone === senderPhone) throw new Error('تعطلت قناة الرد للحماية لأن الحسابين يظهران الرقم نفسه.');
    const parsed = require('./phones').parse(`+${primaryPhone}`);
    const chatId = await this.whatsapp.resolveChatId(senderId, { kind:'person', ...parsed });
    if (!chatId || String(chatId).toLowerCase().endsWith('@g.us')) throw new Error('تعذر التحقق من محادثة صاحب الحساب الأساسي من الرقم الثاني.');
    const result = await this.whatsapp.sendText(senderId, chatId, String(text || '').slice(0, 3500));
    return { ok:true, mode:'second-account', sessionId:senderId, chatId, ack:result?.__chatBotAck?.status || result?.result?.__chatBotAck?.status || 'created' };
  }
  async handleLinkedReplyMessage(senderSessionId, msg) {
    if (!msg || msg.fromMe || !String(msg.body || '').trim()) return { handled:false };
    const rawFrom = String(msg.from || msg.author || msg.id?.remote?._serialized || msg._data?.id?.remote || '').trim().toLowerCase();
    if (!rawFrom || rawFrom.endsWith('@g.us') || rawFrom.endsWith('@lid')) return { handled:false };
    const body = String(msg.body || '').trim();
    if (/^(?:🤖 chat BOT|⚠️ chat BOT|\[chat BOT\])/i.test(body)) return { handled:false };
    const candidates = this.store.listSessionIds();
    for (const primaryId of candidates) {
      if (primaryId === senderSessionId) continue;
      const primary = this.state(primaryId), c = primary.ownerAssistant;
      if (!c.replySessionEnabled || c.replySessionId !== senderSessionId || !c.replySessionConfirmedAt) continue;
      const expected = String(this.whatsapp.selfChatId(primaryId) || '').toLowerCase();
      const senderDigits = rawFrom.match(/^(\d{6,20})@c\.us$/)?.[1] || '';
      const expectedDigits = expected.match(/^(\d{6,20})@c\.us$/)?.[1] || '';
      if (!senderDigits || !expectedDigits || senderDigits !== expectedDigits) continue;
      const messageId = String(msg.id?._serialized || msg._data?.id?._serialized || msg.id?.id || '').slice(0, 200);
      if (messageId && (c.linkedProcessedMessageIds || []).includes(messageId)) return { handled:true, duplicate:true };
      if (messageId) c.linkedProcessedMessageIds = [...(c.linkedProcessedMessageIds || []), messageId].slice(-150);
      this.addMessage(primary, 'user', body, { page:'owner-center', kind:'whatsapp-linked-account' });
      this.store.saveSession(primary);
      const outcome = await this.executeCommand(primaryId, body, { source:'whatsapp-linked-account' });
      const response = outcome.response;
      const latest = this.state(primaryId);
      this.addMessage(latest, 'assistant', response, { page:'owner-center', kind:'whatsapp-linked-account-reply' });
      this.store.saveSession(latest);
      try {
        const sent = await this.sendViaReplySession(primaryId, response);
        return { handled:true, sent:true, response, ack:sent.ack, sourceSessionId:senderSessionId };
      } catch (error) {
        const fresh = this.state(primaryId);
        this.addMessage(fresh, 'assistant', `تعذر إرسال الرد من الرقم الثاني: ${error.message || error}. الرد محفوظ في مركز المساعد، ولم أحاول إرسال نسخة مكررة تلقائيًا.`, { page:'owner-center', kind:'notification-error' });
        this.store.saveSession(fresh);
        return { handled:true, sent:false, response, error:error.message || String(error) };
      }
    }
    return { handled:false };
  }
  async testNotification(id) {
    const s = this.state(id), c = s.ownerAssistant;
    if (!this.whatsapp.listRuntime(id).ready) throw new Error('اربط WhatsApp أولًا حتى تستطيع اختبار الإشعار الخارجي.');
    const text = `🤖 chat BOT: اختبار إشعارات المالك\nالجلسة: ${s.name}\nالوقت: ${new Date().toLocaleString('ar-OM')}\nإذا وصلتك هذه الرسالة، فقناة التنبيه تعمل.`;
    const result = await this.sendConfigured(id, text);
    const fresh = this.state(id); this.addMessage(fresh, 'assistant', 'نجح اختبار قناة إشعارات WhatsApp.', { page:'owner-center', kind:'notification', delivery:result.ack }); this.store.saveSession(fresh);
    return { ok:true, result, message:'تم إرسال رسالة الاختبار.' };
  }
  async resolveIssue(id, issueId) {
    const s = this.state(id), issue = s.ownerAssistant.issues.find(x => x.id === issueId);
    if (!issue) throw new Error('المشكلة غير موجودة.');
    issue.status = 'resolved'; issue.resolvedAt = nowIso(); issue.resolvedBy = 'user';
    this.addMessage(s, 'assistant', `تم تعليم المشكلة «${issue.title}» كمحلولة. إذا تكررت، سيُنشأ سجل جديد بعد فترة منع التكرار.`, { page:issue.page, issueId, kind:'resolved' });
    this.store.saveSession(s); return issue;
  }
  async executeCommand(id, text, { source = 'local-chat' } = {}) {
    let outcome;
    try {
      outcome = await this.commands.run(id, text);
      if (outcome?.response === '__RUN_DIAGNOSTICS__') {
        const d = await this.runDiagnostics(id, { persist: true });
        outcome = { handled: true, ok: true, action: 'diagnostics', response: `نتيجة الفحص لجلسة «${d.sessionName}»:\n${d.checks.map(c => `${c.ok ? '✓' : '⚠'} ${c.title}: ${c.detail}`).join('\n')}\n\nافتح مركز المساعد لعرض خطوات الإصلاح التفصيلية.` };
      }
      if (!outcome?.handled) outcome = { handled: false, ok: null, action: 'unknown', response: outcome?.response || '' };
      if (outcome.ok === false && outcome.action !== 'unknown') {
        await this.recordIssue(id, { code: 'LOCAL_COMMAND_FAILED', title: 'تعذّر تنفيذ أمر المساعد', error: outcome.response || 'تعذّر تنفيذ الأمر.', route: '/api/assistant/chat', page: 'owner-center', severity: 'warning', steps: ['لم يتم تأكيد تنفيذ الأمر؛ راجع صيغة الأمر كما تظهر في «مساعدة».', 'تأكد من اختيار الجلسة الصحيحة قبل تعديل الأرقام أو المجموعات أو المواعيد.', 'للعمليات التي تحتاج WhatsApp حيًا، تأكد من أن الحالة «متصل».'] }, { notify: false });
      } else if (outcome.ok !== false && outcome.action && !['help', 'status', 'list-sessions', 'list-recipients', 'list-groups', 'list-media', 'list-schedules'].includes(outcome.action)) {
        try { this.recordActivity(id, { message: `نفّذ المساعد أمرًا: ${outcome.action}`, type: 'success', page: outcome.action.includes('group') ? 'groups' : outcome.action.includes('schedule') ? 'automation' : outcome.action.includes('send') ? 'send' : outcome.action.includes('recipient') ? 'people' : 'owner-center', source }); } catch {}
      }
    } catch (error) {
      const detail = short(error?.message || error, 900);
      try { await this.recordIssue(id, { code: 'LOCAL_COMMAND_EXCEPTION', title: 'توقف تنفيذ الأمر', error: detail, route: '/api/assistant/chat', page: /مجموعة|GID|دعوة/.test(detail) ? 'groups' : /موعد|جدول|وقت|تاريخ/.test(detail) ? 'automation' : /رقم|مستلم/.test(detail) ? 'people' : 'owner-center', severity: 'warning', steps: ['راجع نص الخطأ في سجل المساعد.', 'اكتب «مساعدة» وانسخ صيغة الأمر مع الحقول مفصولة بعلامة |.', 'لا تعِد إرسال الجميع إذا لم تتضح نتيجة الإرسال السابق.'] }, { notify: false }); } catch {}
      outcome = { handled: true, ok: false, action: 'error', response: `⚠️ لم يكتمل تنفيذ الأمر: ${detail}\nلم يتم تأكيد نجاح العملية. افتح سجل المساعد لمراجعة التشخيص.` };
    }
    const latest = this.state(id);
    const rawResponse = String(outcome?.response || 'لم أحصل على نتيجة تنفيذ.');
    const response = /^(?:🤖 chat BOT|⚠️ chat BOT|\[chat BOT\])/i.test(rawResponse) ? rawResponse : `🤖 chat BOT — ${rawResponse}`;
    outcome.response = response;
    // Return explicit execution metadata so the local UI never mistakes an unknown command for success.
    outcome.executed = outcome.ok === true && outcome.action !== 'help' && outcome.action !== 'status' && !String(outcome.action || '').startsWith('list-');
    outcome.sessionId = latest.id;
    return outcome;
  }
  async handleSelfChatMessage(id, msg) {
    const body = String(msg?.body || '').trim();
    if (!msg || !isFromMeMessage(msg) || msg?.__chatBotProgrammatic || !body || /^(?:🤖 chat BOT|⚠️ chat BOT|\[chat BOT\])/i.test(body)) return { handled:false };
    const selfIds = typeof this.whatsapp.selfChatIds === 'function'
      ? this.whatsapp.selfChatIds(id).map(x => String(x || '').trim().toLowerCase()).filter(Boolean)
      : [String(this.whatsapp.selfChatId(id) || '').trim().toLowerCase()].filter(Boolean);
    let chatIds = messageChatIds(msg);
    // WhatsApp Web may expose self-chat as either the phone JID (@c.us) or the
    // account LID (@lid). Keep every ID present on the message and resolve aliases
    // through the live client before deciding that the message is not a self-chat.
    if (!selfIds.some(value => chatIds.includes(value))) {
      let chatTimer;
      try {
        const chat = typeof msg.getChat === 'function' ? await Promise.race([
          Promise.resolve().then(() => msg.getChat()),
          new Promise(resolve => { chatTimer = setTimeout(() => resolve(null), 1800); }),
        ]) : null;
        const chatId = validChatId(chat?.id);
        if (chatId) chatIds = [...new Set([...chatIds, chatId])];
      } catch (error) {
        this.log(id, 'WARN', `تعذر قراءة وجهة رسالة الحساب الذاتية: ${error.message || error}`);
      } finally { if (chatTimer) clearTimeout(chatTimer); }
      if (typeof this.whatsapp.chatIdAliases === 'function') {
        for (const chatId of [...chatIds]) {
          try { chatIds = [...new Set([...chatIds, ...(await this.whatsapp.chatIdAliases(id, chatId))])]; } catch {}
        }
      }
    }
    const matchedSelfId = chatIds.find(chatId => selfIds.includes(chatId)) ||
      (typeof this.whatsapp.isSelfChatId === 'function' ? this.whatsapp.isSelfChatId(id, chatIds) : '') || '';
    if (!matchedSelfId) return { handled:false, reason: selfIds.length ? 'not-self-chat' : 'self-id-unavailable' };
    const s = this.state(id); this.addMessage(s, 'user', body, { page:'owner-center', kind:'whatsapp-self-chat' }); this.store.saveSession(s);
    const result = await this.executeCommand(id, body, { source: 'whatsapp-self-chat' });
    const rulesFirst = result.action === 'unknown' || String(result.action || '').startsWith('faq-');
    if (rulesFirst && this.interaction && s.settings?.interactionEnabled !== false && s.interaction?.enabled !== false) {
      try {
        const outcome = typeof this.interaction.onSelfChatMessage === 'function'
          ? await this.interaction.onSelfChatMessage(id, msg, matchedSelfId)
          : await this.interaction.onMessage(id, { ...msg, fromMe:false, __chatBotSelfInput:true, chatId:matchedSelfId });
        if (outcome?.handled) return { handled:false, fallback:true, interaction:outcome, reason:'message-handled-by-autoreply-rule' };
      } catch (error) { this.log(id, 'WARN', `تعذر تطبيق قواعد التفاعل في محادثة نفسك: ${error.message || error}`); }
    }
    const response = String(result.response || '').trim() || (result.action === 'unknown' ? 'لم أتعرف على المطلوب بعد. اكتب «مساعدة» أو «مساعدة المواعيد» أو «مساعدة التفاعل»، وسأعرض لك الصيغة المناسبة والخطوات.' : 'تم استلام طلبك، لكن لم أتلقّ نتيجة واضحة من محرك الأوامر. أرسل «حالة الاتصال» للتشخيص.');
    const latest = this.state(id); this.addMessage(latest, 'assistant', response, { page:'owner-center', kind:result.action === 'unknown' || result.handled === false ? 'command-help' : 'whatsapp-self-chat-reply' }); this.store.saveSession(latest);
    try { const sent = await this.sendConfigured(id, response); return { handled:true, sent:true, response, reason:result.action === 'unknown' || result.handled === false ? 'unknown-command-help-sent' : undefined, ack:sent.ack || sent.__chatBotAck?.status || 'created', deliveryMode:sent.mode || 'self' }; }
    catch (error) { const fresh=this.state(id); this.addMessage(fresh, 'assistant', `تعذر إرسال الرد عبر قناة الرد الحالية: ${error.message || error}. الرد محفوظ داخل مركز المساعد.`, { page:'owner-center', kind:'notification-error' }); this.store.saveSession(fresh); return { handled:true, sent:false, response, error:error.message || String(error) }; }
  }
}
module.exports = { OwnerAssistant, issueGuide, isFromMeMessage, messageChatId, messageChatIds };
