'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const mediaTools = require('./media');
const { matchDictionary } = require('./messaging/dictionary');
function chatIdFromMessage(msg) { const value = msg?.id?.remote || msg?._data?.id?.remote || msg?.from || msg?.to || msg?.chatId || ''; return typeof value === 'string' ? value : String(value?._serialized || value?.id || ''); }

const norm = value => String(value || '').normalize('NFKC').replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').toLowerCase().replace(/[^\p{L}\p{N}@.+_-]+/gu, ' ').trim();
const isVoiceMessage = msg => Boolean(msg?.hasMedia && (String(msg?.type || '').toLowerCase() === 'ptt' || String(msg?.type || '').toLowerCase() === 'audio' || /audio\//i.test(String(msg?._data?.mimetype || ''))));
const isStickerMessage = msg => Boolean(msg?.hasMedia && (String(msg?.type || '').toLowerCase() === 'sticker' || /image\/webp/i.test(String(msg?._data?.mimetype || ''))));
function run(command, args, timeoutMs = 180000) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '', stderr = '', settled = false;
    const timer = setTimeout(() => { if (!settled) { settled = true; child.kill('SIGKILL'); reject(new Error('انتهت مهلة التحويل المحلي للصوت.')); } }, timeoutMs);
    child.stdout.on('data', d => { stdout += d.toString(); if (stdout.length > 200000) stdout = stdout.slice(-200000); });
    child.stderr.on('data', d => { stderr += d.toString(); if (stderr.length > 200000) stderr = stderr.slice(-200000); });
    child.on('error', e => { if (settled) return; settled = true; clearTimeout(timer); reject(e); });
    child.on('close', code => { if (settled) return; settled = true; clearTimeout(timer); code === 0 ? resolve({ stdout, stderr }) : reject(new Error((stderr.trim() || `أداة الصوت المحلية انتهت بالرمز ${code}`).slice(-1200))); });
  });
}
class MediaAutomationService {
  constructor({ store, whatsapp, ownerAssistant, log }) { this.store = store; this.whatsapp = whatsapp; this.ownerAssistant = ownerAssistant; this.log = log || (() => {}); this.processing = new Set(); }
  session(id) { return this.store.loadSession(id); }
  isSelfChat(id, msg) {
    if (!(msg?.fromMe === true || msg?._data?.id?.fromMe === true || msg?.id?.fromMe === true)) return false;
    const chatId = String(chatIdFromMessage(msg) || '').toLowerCase();
    if (typeof this.whatsapp.isSelfChatId === 'function' && this.whatsapp.isSelfChatId(id, [chatId])) return true;
    const own = (typeof this.whatsapp.selfChatIds === 'function' ? this.whatsapp.selfChatIds(id) : [this.whatsapp.selfChatId(id)]).map(x => String(x || '').toLowerCase());
    return Boolean(chatId && own.includes(chatId));
  }
  async reply(id, text) { return this.whatsapp.sendOwnerNotification(id, text, { mode: 'self' }); }
  async handleSelfChatText(id, msg) {
    if (!this.isSelfChat(id, msg)) return { handled: false };
    const text = String(msg?.body || msg?.caption || '').trim(); if (!text) return { handled: false };
    const s = this.session(id), flow = s.mediaAutomation?.pendingSticker;
    if (/^(?:الغاء|إلغاء|cancel)$/iu.test(norm(text))) { if (flow) { s.mediaAutomation.pendingSticker = null; this.store.saveSession(s); await this.reply(id, 'تم إلغاء عملية الملصق.'); return { handled: true }; } return { handled: false }; }
    if (/^\s*\((?:voice|صوتية|صوت)\)\s*$/iu.test(text)) { await this.reply(id, 'وصلني نص علامة صوتية فقط، وليس ملفًا صوتيًا. أرسل تسجيلًا صوتيًا حقيقيًا في WhatsApp حتى أفرّغه محليًا إلى نص؛ لا أستخدم API خارجيًا.'); return { handled: true, markerOnly: true }; }
    if (/(?:ابعت|ارسل|أرسل|ابعث|send).{0,25}(?:استيكر|ستيكر|ملصق|sticker)|(?:استيكر|ستيكر|ملصق|sticker).{0,20}(?:ابعت|ارسل|أرسل|ابعث|send)/iu.test(text)) {
      const recipient = this.extractRecipientPhrase(text);
      s.mediaAutomation.pendingSticker = { stage: 'awaiting-sticker', targetText: recipient, createdAt: new Date().toISOString(), expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString() };
      this.store.saveSession(s);
      await this.reply(id, recipient ? `أرسل الملصق الآن كرسالة Sticker في هذه المحادثة، وسأرسله إلى «${recipient}». اكتب «إلغاء» لإيقاف العملية.` : 'Please send the sticker. أرسل الملصق الآن، ثم سأطلب منك اسم المستلم. اكتب «إلغاء» للإلغاء.');
      return { handled: true };
    }
    if (flow?.stage === 'awaiting-target' && Date.parse(flow.expiresAt || '') > Date.now()) {
      const result = await this.sendPendingSticker(id, text); return { handled: true, result };
    }
    return { handled: false };
  }
  extractRecipientPhrase(text) {
    const source = String(text || '');
    const m = source.match(/(?:الى|إلى|لـ?|to)\s+(.+?)(?:\s+(?:الان|الآن|دلوقتي|now))?\s*$/iu) || source.match(/\sل[أإآ]?([^\s،,]+)\s*$/u);
    if (!m) return '';
    const candidate = m[1].replace(/(?:من فضلك|لو سمحت)$/u, '').trim();
    return /^(?:الان|الآن|دلوقتي|now)$/iu.test(candidate) ? '' : candidate.slice(0, 120);
  }
  async downloadMessageMedia(id, msg, preferredExt = '') {
    if (typeof msg?.downloadMedia !== 'function') throw new Error('إصدار WhatsApp الحالي لا يتيح تنزيل هذا المرفق.');
    const downloaded = await msg.downloadMedia();
    if (!downloaded?.data || !downloaded?.mimetype) throw new Error('لم أستطع تنزيل الوسائط من WhatsApp.');
    const extByMime = { 'image/webp':'.webp','image/jpeg':'.jpg','image/png':'.png','video/mp4':'.mp4','audio/ogg':'.ogg','audio/opus':'.opus','audio/mpeg':'.mp3','audio/mp4':'.m4a','audio/wav':'.wav','application/pdf':'.pdf' };
    if (preferredExt === '.webp' && !/image\/webp/i.test(String(downloaded.mimetype))) throw new Error('الرسالة المستلمة ليست ملصق WebP صالحًا.');
    let ext = preferredExt || extByMime[String(downloaded.mimetype).split(';')[0].toLowerCase()] || '';
    if (!ext) ext = ({'image/':' .jpg','video/':'.mp4','audio/':'.ogg'}[String(downloaded.mimetype).split('/')[0] + '/'] || path.extname(String(downloaded.filename || '')) || '.bin').trim();
    if (ext === '.bin' && !mediaTools.MEDIA_EXT.has(ext)) throw new Error(`نوع الوسائط ${downloaded.mimetype} غير مدعوم للحفظ المحلي.`);
    const dir = this.store.getPaths(id).media; fs.mkdirSync(dir, { recursive: true });
    const name = `received_${Date.now()}_${crypto.randomBytes(3).toString('hex')}${ext}`;
    const full = mediaTools.safePath(dir, name); fs.writeFileSync(full, Buffer.from(downloaded.data, 'base64'), { flag: 'wx' });
    return { full, name, mimetype: downloaded.mimetype, size: fs.statSync(full).size };
  }
  async handleSelfChatSticker(id, msg) {
    if (!this.isSelfChat(id, msg) || !isStickerMessage(msg) || msg?.__chatBotProgrammatic) return { handled: false };
    const s = this.session(id), flow = s.mediaAutomation?.pendingSticker;
    if (!flow || flow.stage !== 'awaiting-sticker' || Date.parse(flow.expiresAt || '') <= Date.now()) return { handled: false };
    try {
      const saved = await this.downloadMessageMedia(id, msg, '.webp');
      if (saved.size > 20 * 1024 * 1024) { fs.rmSync(saved.full, { force: true }); throw new Error('الملصق أكبر من الحد الآمن (20MB).'); }
      flow.stickerFile = saved.name; flow.stage = flow.targetText ? 'ready-to-send' : 'awaiting-target'; flow.updatedAt = new Date().toISOString(); s.mediaAutomation.pendingSticker = flow; this.store.saveSession(s);
      if (flow.targetText) { await this.sendPendingSticker(id, flow.targetText); }
      else await this.reply(id, `وصلني الملصق وحُفظ محليًا باسم ${saved.name}. إلى مَن تريد إرساله؟ اكتب اسم جهة الاتصال أو المجموعة كما هو محفوظ.`);
      return { handled: true };
    } catch (e) { this.log(id, 'ERROR', `فشل استقبال الملصق: ${e.message || e}`); await this.reply(id, `لم أستطع تجهيز الملصق: ${e.message || e}`); return { handled: true, error: e.message || String(e) }; }
  }
  async sendPendingSticker(id, targetText) {
    const s = this.session(id), flow = s.mediaAutomation?.pendingSticker;
    if (!flow?.stickerFile) throw new Error('لم يصل الملصق بعد. أرسله أولًا ثم حدّد المستلم.');
    const q = norm(targetText), people = s.recipients.filter(x => x.enabled !== false), groups = s.groups.filter(x => x.enabled !== false);
    const candidates = [...people.map(x => ({ ...x, kind: 'recipient', targetId: x.id })), ...groups.map(x => ({ ...x, kind: 'group', targetId: x.id }))];
    const matches = candidates.filter(x => norm(x.name) === q || (x.kind === 'group' && String(x.gid || '').toLowerCase() === String(targetText).toLowerCase()));
    if (matches.length !== 1) { await this.reply(id, matches.length ? 'الاسم غير فريد؛ أرسل الاسم الكامل أو GID للمجموعة.' : `لم أجد مستلمًا مفعّلًا باسم «${targetText}». راجع صفحة الأشخاص والمجموعات ثم أعد كتابة الاسم.`); return { ok: false, needsTarget: true }; }
    const target = matches[0], chatId = await this.whatsapp.resolveChatId(id, target), full = mediaTools.safePath(this.store.getPaths(id).media, flow.stickerFile);
    if (!fs.existsSync(full)) throw new Error('ملف الملصق المؤقت غير موجود؛ أرسل الملصق من جديد.');
    const result = await this.whatsapp.sendMedia(id, chatId, full, { mediaKind: 'sticker', timeoutMs: s.settings.sendTimeoutMs });
    s.mediaAutomation.pendingSticker = null; s.mediaAutomation.lastStickerSend = { at: new Date().toISOString(), file: flow.stickerFile, target: target.name, ack: result?.__chatBotAck?.status || 'created' }; this.store.saveSession(s);
    await this.reply(id, `تم إرسال الملصق إلى «${target.name}». حالة الإرسال: ${result?.__chatBotAck?.status || 'تم إنشاء الرسالة'}.`);
    return { ok: true, target: target.name, ack: result?.__chatBotAck?.status || 'created' };
  }
  async transcribeLocal(audioFile) {
    const whisper = process.env.WHISPER_CPP_PATH || process.env.WHISPER_CLI_PATH || '';
    const model = process.env.WHISPER_MODEL_PATH || '';
    if (!whisper || !model || !fs.existsSync(whisper) || !fs.existsSync(model)) throw new Error('التفريغ الصوتي المحلي غير مُعدّ بعد. لا يلزم API: ضع مسار whisper-cli ومسار نموذج Whisper المحلي في WHISPER_CPP_PATH وWHISPER_MODEL_PATH.');
    let input = audioFile, tempWav = '';
    if (path.extname(audioFile).toLowerCase() !== '.wav') {
      const ffmpeg = process.env.FFMPEG_PATH || 'ffmpeg'; tempWav = path.join(os.tmpdir(), `chatbot_voice_${crypto.randomBytes(5).toString('hex')}.wav`);
      await run(ffmpeg, ['-y','-i',audioFile,'-ar','16000','-ac','1','-c:a','pcm_s16le',tempWav], 120000); input = tempWav;
    }
    try {
      const out = await run(whisper, ['-m',model,'-f',input,'-nt','-np','-l','auto'], 240000);
      const transcript = out.stdout.trim().split(/\r?\n/).map(x=>x.trim()).filter(Boolean).join(' ').replace(/^\[[^\]]+\]\s*/,'').trim();
      if (!transcript) throw new Error('اكتمل التفريغ المحلي لكن لم أتعرف على كلمات واضحة.');
      return transcript.slice(0, 60000);
    } finally { if (tempWav) fs.rmSync(tempWav, { force: true }); }
  }
  async handleSelfChatVoice(id, msg) {
    if (!this.isSelfChat(id, msg) || !isVoiceMessage(msg) || msg?.__chatBotProgrammatic) return { handled: false };
    const sid = this.store.safeSessionId(id), mid = String(msg?.id?._serialized || msg?._data?.id?._serialized || msg?.id?.id || '');
    const key = `${sid}:${mid || `${msg?.timestamp || ''}:${msg?.duration || ''}`}`;
    if (this.processing.has(key)) return { handled: true, duplicate: true };
    const s = this.session(sid); s.mediaAutomation = s.mediaAutomation || { processedVoiceIds: [] };
    if ((s.mediaAutomation.processedVoiceIds || []).includes(key)) return { handled: true, duplicate: true };
    this.processing.add(key);
    let saved;
    try {
      saved = await this.downloadMessageMedia(sid, msg);
      const transcript = await this.transcribeLocal(saved.full);
      const dictionaryMatches = matchDictionary(transcript, s.commandDictionary || []);
      const dictionaryMatch = dictionaryMatches[0] && dictionaryMatches[0].score >= .54 ? dictionaryMatches[0] : null;
      s.mediaAutomation.lastTranscription = { at: new Date().toISOString(), file: saved.name, text: transcript, messageId: mid, matchedIntent: dictionaryMatch?.intent || null, confidence: dictionaryMatch?.score || 0 };
      s.mediaAutomation.processedVoiceIds = [...(s.mediaAutomation.processedVoiceIds || []), key].slice(-500); this.store.saveSession(s);
      this.log(sid, 'INFO', `تم تفريغ رسالة صوتية محليًا (${transcript.length} حرفًا)${dictionaryMatch ? `؛ النية المطابقة: ${dictionaryMatch.intent} (${dictionaryMatch.score.toFixed(2)})` : '؛ لا توجد نية قاموسية قوية'}.`);
      await this.ownerAssistant.handleSelfChatMessage(sid, { ...msg, body: transcript, caption: '', __chatBotVoiceTranscript: true });
      return { handled: true, transcript };
    } catch (e) {
      this.log(sid, 'WARN', `تعذر تفريغ الصوت محليًا: ${e.message || e}`);
      await this.reply(sid, `لم أنفّذ أي أمر صوتي لأن التفريغ لم يكتمل. ${e.message || e}\nيمكنك استخدام النص يدويًا الآن؛ لم يتم استدعاء أي API خارجي.`);
      return { handled: true, error: e.message || String(e) };
    } finally { this.processing.delete(key); }
  }
  status(id) {
    const s = this.session(id), whisper = process.env.WHISPER_CPP_PATH || process.env.WHISPER_CLI_PATH || '', model = process.env.WHISPER_MODEL_PATH || '';
    return { localOnly: true, apiRequired: false, voiceTranscriptionReady: Boolean(whisper && model && fs.existsSync(whisper) && fs.existsSync(model)), whisperExecutableConfigured: Boolean(whisper && fs.existsSync(whisper)), modelConfigured: Boolean(model && fs.existsSync(model)), pendingSticker: s.mediaAutomation?.pendingSticker ? { stage: s.mediaAutomation.pendingSticker.stage, expiresAt: s.mediaAutomation.pendingSticker.expiresAt } : null, scheduledMedia: (s.automation.tasks || []).filter(t => t.mediaKind && t.mediaKind !== 'auto').length, lastTranscription: s.mediaAutomation?.lastTranscription || null };
  }
}
module.exports = { MediaAutomationService, isVoiceMessage, isStickerMessage };
