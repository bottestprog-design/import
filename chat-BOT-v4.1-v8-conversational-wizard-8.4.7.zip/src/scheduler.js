"use strict";

const DEFAULT_GRACE_MINUTES = 30;
function parts(date, tz) {
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone: tz || 'Asia/Muscat', weekday: 'short', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
  });
  const p = formatter.formatToParts(date), get = key => p.find(x => x.type === key)?.value;
  const weekday = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[get('weekday')];
  return { year: Number(get('year')), month: Number(get('month')), day: Number(get('day')), hour: Number(get('hour')) % 24, minute: Number(get('minute')), weekday };
}
function validTime(value) {
  const match = String(value || '17:30').match(/^(\d{2}):(\d{2})$/);
  return match && Number(match[1]) < 24 && Number(match[2]) < 60 ? { h: Number(match[1]), m: Number(match[2]) } : null;
}
function zonedDateToUtc(dateText, timeText, timezone = 'Asia/Muscat') {
  const [year, month, day] = String(dateText || '').split('-').map(Number), tm = validTime(timeText);
  if (!year || !month || !day || !tm) return null;
  const validity = new Date(Date.UTC(year, month - 1, day));
  if (validity.getUTCFullYear() !== year || validity.getUTCMonth() + 1 !== month || validity.getUTCDate() !== day) return null;
  let guess = new Date(Date.UTC(year, month - 1, day, tm.h, tm.m, 0));
  try {
    for (let i = 0; i < 8; i++) {
      const local = parts(guess, timezone), asUtc = Date.UTC(local.year, local.month - 1, local.day, local.hour, local.minute);
      const wanted = Date.UTC(year, month - 1, day, tm.h, tm.m), diff = wanted - asUtc;
      if (Math.abs(diff) < 1000) return guess;
      guess = new Date(guess.getTime() + diff);
    }
  } catch { return null; }
  const finalParts = parts(guess, timezone);
  return finalParts.year === year && finalParts.month === month && finalParts.day === day && finalParts.hour === tm.h && finalParts.minute === tm.m ? guess : null;
}
function localDate(value) { return `${value.year}-${String(value.month).padStart(2, '0')}-${String(value.day).padStart(2, '0')}`; }
function dateAdd(year, month, day, offset) {
  const value = new Date(Date.UTC(year, month - 1, day) + offset * 86400000);
  return { year: value.getUTCFullYear(), month: value.getUTCMonth() + 1, day: value.getUTCDate() };
}
function matchesCalendar(p, item) {
  const mode = item.mode || 'weekly';
  if (mode === 'weekly') return p.weekday === Number(item.day ?? 5);
  if (mode === 'monthly') return p.day === Number(item.dayOfMonth || 1) && (!item.month || Number(item.month) === p.month) && (!item.year || Number(item.year) === p.year);
  if (mode === 'yearly') return p.day === Number(item.dayOfMonth || 1) && Number(item.month) === p.month && (!item.year || Number(item.year) === p.year);
  return mode === 'once';
}
function graceMinutes(item) {
  const value = Number(item?.graceMinutes);
  return Number.isFinite(value) ? Math.max(1, Math.min(180, Math.floor(value))) : DEFAULT_GRACE_MINUTES;
}
function dueForItem(now, item) {
  const timezone = item.timezone || 'Asia/Muscat', mode = item.mode || 'weekly', tm = validTime(item.time || '17:30');
  if (!tm || item.enabled === false) return { due: false, key: '' };
  let p;
  try { p = parts(now, timezone); } catch { return { due: false, key: '', error: 'منطقة زمنية غير صالحة' }; }
  const date = localDate(p), minute = p.hour * 60 + p.minute, target = tm.h * 60 + tm.m, late = minute - target;
  if (late < 0 || late > graceMinutes(item)) return { due: false, key: '' };
  if (mode === 'once') {
    if (String(item.date || '') !== date) return { due: false, key: '' };
  } else if (!matchesCalendar(p, item)) return { due: false, key: '' };
  const key = `${item.id || 'legacy'}|${mode}|${date}|${item.time || '17:30'}`;
  return { due: item.lastRunKey !== key, key, date, lateMinutes: late };
}
function nextRunForItem(item, now = new Date()) {
  if (item.enabled === false) return null;
  const timezone = item.timezone || 'Asia/Muscat', mode = item.mode || 'weekly', time = String(item.time || '17:30');
  let start;
  try { start = parts(now, timezone); } catch { return null; }
  if (mode === 'once') {
    const target = zonedDateToUtc(item.date, time, timezone);
    if (!target) return null;
    if (target.getTime() >= now.getTime()) return target.toISOString();
    const sameLocalDay = String(item.date || '') === localDate(start);
    return sameLocalDay && now.getTime() - target.getTime() <= graceMinutes(item) * 60000 ? target.toISOString() : null;
  }
  for (let offset = 0; offset < 800; offset++) {
    const day = dateAdd(start.year, start.month, start.day, offset);
    const calendar = { ...day, weekday: new Date(Date.UTC(day.year, day.month - 1, day.day)).getUTCDay(), hour: 0, minute: 0 };
    if (!matchesCalendar(calendar, item)) continue;
    const target = zonedDateToUtc(localDate(day), time, timezone);
    if (!target) continue;
    if (target.getTime() >= now.getTime()) return target.toISOString();
    if (offset === 0 && now.getTime() - target.getTime() <= graceMinutes(item) * 60000) return target.toISOString();
  }
  return null;
}
function legacy(session) {
  const settings = session.settings || {};
  return { id: 'legacy', enabled: settings.scheduleEnabled, mode: settings.scheduleMode, time: settings.scheduleTime, date: settings.scheduleDate, day: settings.scheduleDay, dayOfMonth: settings.scheduleMonthDay, month: settings.scheduleMonth, year: settings.scheduleYear, timezone: settings.timezone, lastRunKey: session.scheduleState?.lastRunKey || '', graceMinutes: settings.scheduleGraceMinutes };
}
function due(now, session) { return dueForItem(now, legacy(session)); }
function nextRun(session, now = new Date()) { return nextRunForItem(legacy(session), now); }

class ReliableScheduler {
  constructor({ store, run, runTask, log }) {
    this.store = store; this.run = run; this.runTask = runTask; this.log = log;
    this.busy = new Set(); this.taskBusy = new Set(); this.lastFail = new Map();
    this.timer = setInterval(() => this.tick().catch(error => this.log(null, 'ERROR', `Scheduler: ${error.message}`)), 1000);
    this.timer.unref?.();
  }
  stop() { clearInterval(this.timer); }
  async tick() {
    for (const id of this.store.listSessionIds()) {
      try { await this.tickSession(id); } catch (error) { this.log(id, 'ERROR', `Scheduler: ${error.message}`); }
    }
  }
  async tickSession(id) {
    if (this.busy.has(id)) return;
    this.busy.add(id);
    try {
      let session = this.store.loadSession(id);
      const legacyDue = due(new Date(), session), legacyKey = `legacy:${id}`;
      if (legacyDue.due && Date.now() - (this.lastFail.get(legacyKey) || 0) > 10000) {
        try {
          const result = await this.run(id), fresh = this.store.loadSession(id);
          const sentCount = Array.isArray(result?.sent) ? result.sent.length : Number(result?.sentCount || 0);
          const failedItems = Array.isArray(result?.failed) ? result.failed : [];
          const uncertainCount = failedItems.filter(item => item?.code === 'SEND_UNCERTAIN' || /لم يتم تأكيد النتيجة|نتيجة غير مؤكدة/i.test(String(item?.error || ''))).length;
          const partialItems = failedItems.filter(item => item?.partialDelivery === true);
          const unsafePartialCount = partialItems.filter(item => item.progressPersisted !== true).length;
          const occurrenceConsumed = result?.ok === true || result?.complete === true || sentCount > 0 || uncertainCount > 0 || unsafePartialCount > 0;
          if (occurrenceConsumed) {
            fresh.scheduleState.lastRunKey = legacyDue.key;
            this.lastFail.delete(legacyKey);
            if ((sentCount > 0 || uncertainCount > 0 || unsafePartialCount > 0) && result?.ok !== true) this.log(id, 'WARN', `الجدولة العامة لديها نجاح جزئي أو نتيجة غير مؤكدة (نجح ${sentCount}، مراحل جزئية ${partialItems.length}، غير مؤكد ${uncertainCount})؛ تم استهلاك الموعد لمنع تكرار الإرسال. راجع سجل النتيجة قبل أي إعادة يدوية.`);
          } else this.lastFail.set(legacyKey, Date.now());
          this.store.saveSession(fresh);
        } catch (error) { this.lastFail.set(legacyKey, Date.now()); this.log(id, 'ERROR', `فشل الموعد العام: ${error.message}`); }
      }
      session = this.store.loadSession(id);
      if (session.settings.automationEnabled === false || session.automation.enabled === false) return;
      for (const taskSnapshot of session.automation.tasks || []) {
        const now = new Date(), taskDue = dueForItem(now, { ...taskSnapshot, timezone: session.settings.timezone });
        if (taskSnapshot.mode === 'once' && taskSnapshot.enabled !== false && !taskSnapshot.lastRunKey) {
          const plannedAt = zonedDateToUtc(taskSnapshot.date, taskSnapshot.time, session.settings.timezone);
          const graceMs = graceMinutes(taskSnapshot) * 60000;
          if (plannedAt && now.getTime() - plannedAt.getTime() > graceMs) {
            const fresh = this.store.loadSession(id), missed = fresh.automation.tasks.find(item => item.id === taskSnapshot.id);
            if (missed && missed.enabled !== false && !missed.lastRunKey) {
              const message = `فات الموعد «${missed.name || missed.id}» ولم يُنفّذ خلال مهلة ${graceMinutes(missed)} دقيقة. عدّل التاريخ والوقت ثم فعّله من جديد.`;
              missed.enabled = false;
              missed.lastFailureKey = `missed:${taskSnapshot.id}:${plannedAt.toISOString()}`;
              missed.lastResult = { ok: false, missed: true, error: message, attemptedAt: new Date().toISOString() };
              missed.lastAttemptAt = new Date().toISOString(); missed.updatedAt = new Date().toISOString();
              fresh.automation.recent = [...(fresh.automation.recent || []), { at: new Date().toISOString(), taskId: missed.id, name: missed.name, ok: false, missed: true, error: message }].slice(-100);
              this.store.saveSession(fresh); this.log(id, 'WARN', message);
            }
            continue;
          }
        }
        if (!taskDue.due) continue;
        const busyKey = `task:${id}:${taskSnapshot.id}`, coolDownAt = this.lastFail.get(busyKey) || 0;
        if (this.taskBusy.has(busyKey) || Date.now() - coolDownAt < 10000) continue;
        this.taskBusy.add(busyKey);
        try {
          const result = await this.runTask(id, { ...taskSnapshot, _scheduledOccurrenceKey: taskDue.key });
          const fresh = this.store.loadSession(id), saved = fresh.automation.tasks.find(item => item.id === taskSnapshot.id);
          const sentCount = Array.isArray(result?.sent) ? result.sent.length : Number(result?.sentCount || 0);
          const failedItems = Array.isArray(result?.failed) ? result.failed : [];
          const uncertainCount = failedItems.filter(item => item?.code === 'SEND_UNCERTAIN' || /لم يتم تأكيد النتيجة|نتيجة غير مؤكدة/i.test(String(item?.error || ''))).length;
          const partialCount = failedItems.filter(item => item?.partialDelivery === true).length;
          const finished = result?.ok === true || result?.complete === true || sentCount > 0 || uncertainCount > 0 || partialCount > 0;
          if (saved && finished) {
            // If any destination accepted the send, consume this occurrence. Retrying the whole
            // target/file matrix would duplicate already-sent messages on the next scheduler tick.
            saved.lastRunKey = taskDue.key;
            saved.lastResult = { ...result, ok: result.ok === true, attemptedAt: new Date().toISOString(), partial: result?.ok !== true && (sentCount > 0 || uncertainCount > 0 || partialCount > 0), partialCount, uncertain: uncertainCount > 0 };
            saved.lastAttemptAt = new Date().toISOString(); saved.lastFailureKey = '';
            saved.updatedAt = new Date().toISOString();
            if (saved.mode === 'once') saved.enabled = false;
            fresh.automation.recent = [...(fresh.automation.recent || []), {
              at: new Date().toISOString(), taskId: saved.id, name: saved.name,
              ok: result?.ok === true || result?.complete === true,
              partial: result?.ok !== true && (sentCount > 0 || uncertainCount > 0 || partialCount > 0), partialCount, uncertain: uncertainCount > 0,
              result: { sent: sentCount, failed: Array.isArray(result?.failed) ? result.failed.length : 0 }
            }].slice(-100);
            this.store.saveSession(fresh); this.lastFail.delete(busyKey);
            if ((sentCount > 0 || uncertainCount > 0 || partialCount > 0) && result?.ok !== true) this.log(id, 'WARN', `الموعد «${saved.name}» لديه نجاح جزئي أو نتيجة غير مؤكدة (نجح ${sentCount}، مراحل مكتملة قبل الفشل ${partialCount}، غير مؤكد ${uncertainCount})؛ تم استهلاك هذا الموعد لمنع تكرار رسالة ربما وصلت. راجع آخر نتيجة قبل أي إعادة يدوية.`);
          } else {
            this.lastFail.set(busyKey, Date.now());
            if (saved) {
              const message = result?.message || `لم ينجح أي إرسال في الموعد «${saved.name}».`;
              saved.lastResult = { ...result, ok: false, error: message, attemptedAt: new Date().toISOString() };
              saved.lastAttemptAt = new Date().toISOString(); saved.updatedAt = new Date().toISOString();
              if (saved.lastFailureKey !== taskDue.key) {
                saved.lastFailureKey = taskDue.key;
                fresh.automation.recent = [...(fresh.automation.recent || []), { at: new Date().toISOString(), taskId: saved.id, name: saved.name, ok: false, error: message }].slice(-100);
                this.log(id, 'ERROR', message);
              }
              this.store.saveSession(fresh);
            }
          }
        } catch (error) {
          this.lastFail.set(busyKey, Date.now());
          const fresh = this.store.loadSession(id), saved = fresh.automation.tasks.find(item => item.id === taskSnapshot.id);
          if (saved) {
            const message = String(error?.message || error || 'خطأ غير معروف');
            saved.lastResult = { ok: false, error: message, attemptedAt: new Date().toISOString() };
            saved.lastAttemptAt = new Date().toISOString(); saved.updatedAt = new Date().toISOString();
            if (saved.lastFailureKey !== taskDue.key) {
              saved.lastFailureKey = taskDue.key;
              fresh.automation.recent = [...(fresh.automation.recent || []), { at: new Date().toISOString(), taskId: saved.id, name: saved.name, ok: false, error: message }].slice(-100);
              this.log(id, 'ERROR', `فشل الموعد ${saved.name || saved.id}: ${message}`);
            }
            this.store.saveSession(fresh);
          } else this.log(id, 'ERROR', `فشل الموعد ${taskSnapshot.name || taskSnapshot.id}: ${error.message}`);
        } finally { this.taskBusy.delete(busyKey); }
        session = this.store.loadSession(id);
        if (session.settings.automationEnabled === false || session.automation.enabled === false) break;
      }
    } finally { this.busy.delete(id); }
  }
}
module.exports = { ReliableScheduler, parts, due, nextRun, zonedDateToUtc, dueForItem, nextRunForItem, validTime, DEFAULT_GRACE_MINUTES };
