'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const mediaFiles = require('./media');
const groups = require('./groups');

const HELP = `🤖 دليل استخدام chat BOT 8.4.7 — أوامر محلية دون API ذكاء اصطناعي
اكتب الأوامر في «الرسائل إلى نفسك». أشرح النتيجة ولا أؤكد النجاح إلا بعد التحقق.

0) محادثة مرنة لإضافة مستخدم
• اكتب: عايز أضيف رقم مستخدم جديد
• سأطلب الاسم ثم الدولة ثم الرقم. ردك قيمة الحقل المطلوب فقط.
• أمثلة الدولة: عمان، السعودية، مصر، الإمارات، الكويت؛ أو رمز الدولة OM/SA/EG/AE.
• إذا كان الإدخال خطأ، أشرح المطلوب وأنتظر التصحيح بلا حفظ. اكتب «إلغاء» للتراجع.

1) الأشخاص والأرقام
• ضيف الرقم ده +96891234567 باسم أحمد / أضف الرقم +96891234567 باسم أحمد
• افحص الرقم +96891234567 — يحتاج WhatsApp متصلًا
• اعرض الأشخاص / غيّر اسم المستلم أحمد إلى أحمد الجديد
• فعّل المستلم أحمد / عطّل المستلم أحمد / احذف المستلم أحمد

2) حساب رد ثانٍ حقيقي (اختياري)
• أنشئ جلسة | الاسم=رقم الرد الثاني، ثم اربط رقمًا تملكه بمسح QR من الهاتف نفسه.
• فعّل حساب الرد الثاني | الجلسة=معرّف_الجلسة | تأكيد=نعم
• حالة حساب الرد / أوقف حساب الرد الثاني
• لا تشارك QR أو مجلد auth؛ يجب أن يكون الرقمان متصلين ومختلفين.
• قيود واتساب: رسائل الرقم الثاني لا تظهر داخل «الرسائل إلى نفسك»، بل في محادثة مستقلة معه. الرد داخل نفس المحادثة هو الوضع الافتراضي.

3) المجموعات
• اكتشف المجموعات / اعرض المجموعات
• حلل المجموعة https://chat.whatsapp.com/رابط_الدعوة
• أضف مجموعة 120363012345678901@g.us
• معلومات المجموعة اسم_المجموعة / غيّر اسم المجموعة القديم إلى الجديد (اسم محلي فقط)
• احذف المجموعة الاسم / عطّل المجموعة الاسم / فعّل المجموعة الاسم

4) المواعيد — افصل الحقول بعلامة |
• أضف موعد | الاسم=تذكير | التكرار=مرة | التاريخ=2026-10-20 | الوقت=18:30 | إلى=أحمد | الرسالة=النص
• للتكرار استخدم أسبوعي/شهري/سنوي، مع اليوم أو يوم الشهر والشهر حسب الحاجة.
• اعرض المواعيد / أوقف الموعد الاسم / فعّل الموعد الاسم / احذف الموعد الاسم / نفّذ الموعد الآن الاسم
• فعّل الأتمتة / أوقف الأتمتة. يجب أن يبقى الخادم واتصال WhatsApp يعملان وقت التسليم.

5) الإرسال والوسائط
• أرسل الآن | إلى=أحمد | الرسالة=النص
• أرسل الآن | إلى=أحمد | ملف=اسم_الملف.pdf | الرسالة=تعليق
• إلى=الكل يتطلب تأكيد=نعم؛ لا يعيد النظام النجاحات تلقائيًا بعد فشل جزئي.
• اعرض الوسائط / احذف الملف الاسم_الكامل.ext
• اختبر الإرسال لنفسي | الرسالة=رسالة اختبار
• اضبط تأخير الإرسال | مللي ثانية=500

6) التفاعل والمساعد
• فعّل التفاعل / أوقف التفاعل
• فعّل اختبار التفاعل مع نفسي / أوقف اختبار التفاعل مع نفسي
• أضف قاعدة تفاعل | الاسم=ترحيب | عندما=السلام عليكم | المطابقة=يحتوي | الرد=وعليكم السلام {{sender}}
• اعرض قواعد التفاعل / فعّل قاعدة التفاعل الاسم / أوقف قاعدة التفاعل الاسم / احذف قاعدة التفاعل الاسم
• حالة الاتصال / افحص / الجلسات / اعرض المشاكل / اعرض سجل المساعد
• اعرض إعدادات الإرسال / فعّل إشعارات المساعد / أوقف إشعارات المساعد

ملاحظات: كل الأرقام والمجموعات والمواعيد تخص الجلسة التي استقبلت الأمر. المجموعات وفحص الرقم والإرسال الحقيقي يحتاج اتصالًا حيًا. الأسئلة الشائعة لها إجابات محلية محفوظة ولا تحتاج API توليدي. الأوامر غير المعروفة لا تُنفذ.`;

function norm(value) {
  return String(value ?? '').normalize('NFKC').replace(/[ـ]/g, '').replace(/[ًٌٍَُِّْ]/g, '')
    .replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/\s+/g, ' ').trim().toLocaleLowerCase('ar');
}
function clean(value, max = 1000) { return String(value ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, max); }
function normalizedPhoneDigits(value) {
  const raw = String(value ?? '').trim(), digits = raw.replace(/\D/g, '');
  if (digits.length < 6) return '';
  try { return require('./phones').parse(raw, 'OM').digits; } catch { return digits; }
}
function parseFields(text) {
  const out = {};
  for (const piece of String(text || '').split(/[|\n]/)) {
    const m = piece.trim().match(/^([^=:]{1,40})\s*[=:]\s*([\s\S]*)$/);
    if (!m) continue;
    const key = norm(m[1]).replace(/[؟?]$/, '');
    const val = clean(m[2], 3500);
    const map = {
      'اسم':'name','الاسم':'name','name':'name','عنوان':'name','عنوان الموعد':'name',
      'رقم':'phone','الرقم':'phone','رقم الهاتف':'phone','الهاتف':'phone','phone':'phone',
      'التاريخ':'date','تاريخ':'date','date':'date','الوقت':'time','وقت':'time','time':'time','الشهر':'month','شهر':'month','month':'month','يوم الشهر':'dayOfMonth','day of month':'dayOfMonth','السنة':'year','سنة':'year','year':'year','وضع النص':'textMode','text mode':'textMode',
      'الرسالة':'text','رسالة':'text','نص':'text','النص':'text','message':'text','text':'text',
      'الي':'to','الى':'to','إلى':'to','المستلم':'to','المستلمين':'to','الهدف':'to','targets':'to','to':'to',
      'التكرار':'repeat','تكرار':'repeat','repeat':'repeat','اليوم':'day','يوم':'day','day':'day',
      'ملف':'file','الملف':'file','ملفات':'files','الملفات':'files','وسائط':'files','media':'files',
      'تاكيد':'confirm','تأكيد':'confirm','confirm':'confirm','مللي ثانية':'sendDelayMs','ملي ثانية':'sendDelayMs','تاخير الارسال':'sendDelayMs','تأخير الارسال':'sendDelayMs','المطابقة':'match','مطابقة':'match','match':'match',
      'عندما':'when','اذا':'when','إذا':'when','when':'when','الرد':'reply','رد':'reply','reply':'reply',
      'الدولة':'country','دولة':'country','country':'country','الوصف':'description','description':'description',
    };
    const dest = map[key] || key;
    out[dest] = val;
  }
  return out;
}
function extractPhone(text) {
  const m = String(text || '').match(/(?:\+|00)?[\d٠-٩۰-۹][\d٠-٩۰-۹\s().-]{5,24}/u);
  return m ? m[0].trim().replace(/[،؛,]+$/g, '').trim() : '';
}
function weekdayNumber(value) {
  const v = norm(value);
  const names = {
    'الاحد':0,'احد':0,'sunday':0,'الاثنين':1,'الإثنين':1,'اثنين':1,'monday':1,
    'الثلاثاء':2,'ثلاثاء':2,'tuesday':2,'الاربعاء':3,'الأربعاء':3,'اربعاء':3,'wednesday':3,
    'الخميس':4,'خميس':4,'thursday':4,'الجمعة':5,'جمعه':5,'friday':5,'السبت':6,'سبت':6,'saturday':6,
  };
  return Object.prototype.hasOwnProperty.call(names, v) ? names[v] : null;
}

const COUNTRY_ALIASES = new Map(Object.entries({
  'عمان':'OM','سلطنة عمان':'OM','oman':'OM','om':'OM',
  'السعودية':'SA','السعوديه':'SA','المملكة العربية السعودية':'SA','المملكه العربيه السعوديه':'SA','saudi arabia':'SA','sa':'SA',
  'مصر':'EG','egypt':'EG','eg':'EG','الإمارات':'AE','الامارات':'AE','الامارات العربية المتحدة':'AE','الامارات العربيه المتحده':'AE','uae':'AE','ae':'AE',
  'الكويت':'KW','kuwait':'KW','kw':'KW','قطر':'QA','qatar':'QA','qa':'QA','البحرين':'BH','bahrain':'BH','bh':'BH',
  'الأردن':'JO','الاردن':'JO','jordan':'JO','jo':'JO','العراق':'IQ','iraq':'IQ','iq':'IQ','اليمن':'YE','yemen':'YE','ye':'YE',
  'لبنان':'LB','lebanon':'LB','lb':'LB','سوريا':'SY','syria':'SY','sy':'SY','فلسطين':'PS','palestine':'PS','ps':'PS',
  'المغرب':'MA','morocco':'MA','ma':'MA','الجزائر':'DZ','algeria':'DZ','dz':'DZ','تونس':'TN','tunisia':'TN','tn':'TN',
  'ليبيا':'LY','libya':'LY','ly':'LY','السودان':'SD','sudan':'SD','sd':'SD','الهند':'IN','india':'IN','in':'IN',
  'باكستان':'PK','pakistan':'PK','pk':'PK','تركيا':'TR','turkey':'TR','tr':'TR','بريطانيا':'GB','المملكة المتحدة':'GB','united kingdom':'GB','uk':'GB','gb':'GB',
  'أمريكا':'US','امريكا':'US','الولايات المتحدة':'US','united states':'US','usa':'US','us':'US','كندا':'CA','canada':'CA','ca':'CA',
  'ألمانيا':'DE','المانيا':'DE','germany':'DE','de':'DE','فرنسا':'FR','france':'FR','fr':'FR','بنغلاديش':'BD','bangladesh':'BD','bd':'BD',
  'الفلبين':'PH','philippines':'PH','ph':'PH'
}).map(([name, code]) => [norm(name), code]));
function resolveCountry(input) {
  const raw = clean(input, 100).replace(/^(?:دولة|البلد|بلد)\s*/u, '');
  const value = norm(raw), code = COUNTRY_ALIASES.get(value) || (/^[a-z]{2}$/i.test(raw) ? raw.toUpperCase() : '');
  if (!code) return null;
  try { if (!require('./phones').countries().some(x => x.code === code)) return null; } catch { return null; }
  const names = { OM:'عمان', SA:'السعودية', EG:'مصر', AE:'الإمارات', KW:'الكويت', QA:'قطر', BH:'البحرين', JO:'الأردن', IQ:'العراق', YE:'اليمن', LB:'لبنان', SY:'سوريا', PS:'فلسطين', MA:'المغرب', DZ:'الجزائر', TN:'تونس', LY:'ليبيا', SD:'السودان', IN:'الهند', PK:'باكستان', TR:'تركيا', GB:'بريطانيا', US:'أمريكا', CA:'كندا', DE:'ألمانيا', FR:'فرنسا', BD:'بنغلاديش', PH:'الفلبين' };
  return { code, name: names[code] || code };
}

class LocalCommandEngine {
  constructor({ store, whatsapp, delivery, log, saveGroup, normalizeAutomationPayload, interaction = null }) {
    this.store = store; this.whatsapp = whatsapp; this.delivery = delivery; this.log = log || (() => {});
    this.saveGroup = saveGroup; this.normalizeAutomationPayload = normalizeAutomationPayload; this.interaction = interaction;
  }
  session(id) { return this.store.loadSession(id); }
  reply(message, action = 'read') { return { handled: true, ok: true, action, response: String(message).slice(0, 3500) }; }
  fail(message, action = 'command') { return { handled: true, ok: false, action, response: `⚠️ لم أنفّذ الأمر: ${message}\nلم أغيّر البيانات. اكتب «مساعدة» لعرض الصيغة الصحيحة.` }; }
  targetKeys(id, raw, { allowAll = false, requireConfirm = false, confirm = '' } = {}) {
    const s = this.session(id), wanted = norm(raw);
    if (!wanted) throw new Error('حدّد المستلم في حقل «إلى=».');
    const people = s.recipients.filter(x => x.enabled !== false), groupItems = s.groups.filter(x => x.enabled !== false);
    if (['الكل','كل المستلمين','الجميع','all'].includes(wanted)) {
      if (!allowAll) throw new Error('هذا الإجراء لا يقبل «الكل»؛ اختر مستلمًا محددًا.');
      if (requireConfirm && norm(confirm) !== 'نعم') throw new Error('الإرسال الجماعي يحتاج الحقل «تأكيد=نعم».');
      return [...people.map(x => `r:${x.id}`), ...groupItems.map(x => `g:${x.id}`)];
    }
    const chunks = String(raw).split(/[,،;؛]/).map(x => x.trim()).filter(Boolean);
    const keys = [];
    for (const chunk of chunks) {
      const q = norm(chunk), digits = normalizedPhoneDigits(chunk);
      const personMatches = people.filter(x => norm(x.name) === q || (digits.length >= 6 && [x.digits, x.phone, x.e164].some(v => String(v || '').replace(/\D/g, '') === digits)));
      const groupMatches = groupItems.filter(x => norm(x.name) === q || String(x.gid || '').toLowerCase() === chunk.toLowerCase());
      const matches = [...personMatches.map(x => ({ key:`r:${x.id}`, name:x.name })), ...groupMatches.map(x => ({ key:`g:${x.id}`, name:x.name }))];
      if (matches.length > 1) throw new Error(`الاسم «${chunk}» غير فريد. استخدم الرقم الكامل أو GID المجموعة.`);
      if (!matches.length) throw new Error(`لم أجد مستلمًا مفعّلًا مطابقًا لـ «${chunk}». أضفه أو فعّله أولًا.`);
      keys.push(matches[0].key);
    }
    const out = [...new Set(keys)];
    if (!out.length) throw new Error('لم يتم تحديد أي مستلم مفعّل.');
    return out;
  }
  async addRecipient(id, text) {
    const fields = parseFields(text);
    let phone = fields.phone || '';
    if (!phone) {
      const m = text.match(/(?:ضيف|اضف|أضف|أضيف|سجل|سجّل|احفظ|أحفظ)\s+(?:لي\s+)?(?:ال)?(?:رقم|شخص|مستلم)\s+(?:ده\s+|هذا\s+)?((?:\+|00)?[\d٠-٩۰-۹][\d٠-٩۰-۹\s().-]{5,24})/iu);
      if (m) phone = m[1].trim();
    }
    if (!phone) throw new Error('استخدم: أضف الرقم +96891234567 باسم أحمد، أو «رقم=… | الاسم=…».');
    phone = phone.replace(/\s+(?:باسم|اسم)\s+.*$/iu, '').trim();
    let name = fields.name || '';
    if (!name) {
      const nm = text.match(/(?:باسم|اسم)\s*[=:]?\s*(.+)$/iu);
      if (nm) name = clean(nm[1], 80);
    }
    const country = String(fields.country || 'OM').toUpperCase();
    const parsed = require('./phones').parse(phone, country);
    const s = this.session(id);
    const exists = s.recipients.find(x => String(x.e164 || '').replace(/\D/g, '') === parsed.digits || String(x.digits || x.phone || '').replace(/\D/g, '') === parsed.digits);
    if (exists) throw new Error(`الرقم موجود بالفعل باسم «${exists.name}»؛ لم أضف نسخة مكررة.`);
    name = clean(name || `رقم ${parsed.digits.slice(-4)}`, 80);
    const recipient = { id: crypto.randomUUID(), name, ...parsed, phone: parsed.digits, enabled: true, createdAt: new Date().toISOString(), source: 'owner-command' };
    s.recipients.push(recipient); s.setupComplete = true; this.store.saveSession(s);
    const verified = this.session(id).recipients.find(x => x.id === recipient.id);
    if (!verified) throw new Error('تعذّر التحقق من حفظ المستلم؛ أعد المحاولة من لوحة الأشخاص.');
    this.log(id, 'INFO', `أضاف المالك مستلمًا عبر الأمر المحلي: ${name}`);
    return this.reply(`✅ تمت إضافة الرقم فعليًا وحفظه في الجلسة «${s.name}».\nالاسم: ${name}\nالرقم: ${parsed.international}\nالمعرّف: ${recipient.id}`, 'add-recipient');
  }
  async groupCommand(id, text) {
    if (/^(?:اعرض|اظهر|أظهر|قائمة)?\s*(?:المجموعات|مجموعاتي|قروباتي)\s*$/iu.test(text)) {
      const s = this.session(id);
      return this.reply(`المجموعات المحفوظة (${s.groups.length}):\n${s.groups.length ? s.groups.map((g,i)=>`${i+1}. ${g.name} | ${g.gid} | ${g.enabled?'مفعّلة':'متوقفة'}`).join('\n') : 'لا توجد مجموعات محفوظة. اكتب «اكتشف المجموعات» أو أرسل رابط دعوة.'}`, 'list-groups');
    }
    if (!this.whatsapp.listRuntime(id).ready) throw new Error('اربط WhatsApp في هذه الجلسة أولًا؛ تحليل الروابط يحتاج اتصالًا حيًا.');
    const invite = text.match(/(?:https?:\/\/)?chat\.whatsapp\.com\/[A-Za-z0-9_-]+/i);
    const gid = text.match(/\d{5,25}(?:-\d+)*@g\.us/i);
    if (invite) {
      const inviteCode = groups.extractInviteCode(invite[0]);
      let info = await this.whatsapp.analyzeGroupInvite(id, inviteCode);
      if (info?.gid) { try { info = await this.whatsapp.getGroupInfo(id, groups.normalizeGid(info.gid)); } catch {} }
      if (info?.gid && groups.isGroupId(info.gid)) {
        const saved = this.saveGroup(id, { ...info, inviteCode });
        const confirmed = this.session(id).groups.find(x => x.gid === saved.gid);
        if (!confirmed) throw new Error('حلّل WhatsApp الدعوة لكن لم يتم التحقق من حفظ المجموعة.');
        return this.reply(`✅ تم تحليل المجموعة وحفظها فعليًا.\n${groups.formatGroupAnalysis(confirmed)}`, 'analyze-group');
      }
      return this.reply(`تم تحليل رابط الدعوة، لكن WhatsApp لم يعطِ GID يسمح بحفظ المجموعة بعد.\nالاسم: ${info?.name || 'غير متاح'}\nالوصف: ${info?.description || 'غير متاح'}\nالأعضاء: ${info?.participantsCount ?? 'غير متاح'}\nلم أحفظها كمجموعة قابلة للإرسال لأن معرفها غير مؤكد. افتح المجموعة في WhatsApp ثم أرسل «اكتشف المجموعات».`, 'analyze-invite');
    }
    if (gid) {
      let info = await this.whatsapp.getGroupInfo(id, groups.normalizeGid(gid[0]));
      const saved = this.saveGroup(id, info);
      const verified=this.session(id).groups.find(x=>x.gid===saved.gid);
      if(!verified)throw new Error('تم الاتصال بالمجموعة لكن لم يتم التحقق من حفظها داخل الجلسة.');
      return this.reply(`✅ تمت إضافة المجموعة وحفظ معلوماتها فعليًا.\n${groups.formatGroupAnalysis(verified)}`, 'add-group');
    }
    if (/اكتشف المجموعات|اكتشاف المجموعات|حدّث المجموعات|حدث المجموعات/i.test(text)) {
      const found = await this.whatsapp.listGroups(id), valid = found.filter(x => x?.gid && groups.isGroupId(x.gid));
      const saved = valid.map(x => this.saveGroup(id, x));
      if (saved.length !== valid.length) throw new Error('لم تُحفظ كل المجموعات المكتشفة؛ راجع سجل الجلسة.');
      return this.reply(`✅ اكتمل اكتشاف المجموعات وحُفظ ${saved.length} مجموعة في هذه الجلسة.\n${saved.slice(0, 15).map((g,i)=>`${i+1}. ${g.name} — ${g.gid}`).join('\n')}${saved.length>15?'\n… توجد مجموعات أخرى في صفحة المجموعات.':''}`, 'discover-groups');
    }
    throw new Error('أرسل رابط chat.whatsapp.com أو GID ينتهي بـ @g.us، أو اكتب «اكتشف المجموعات».');
  }
  async scheduleCommand(id, text) {
    const s = this.session(id), f = parseFields(text), low = norm(text);
    if (/اعرض المواعيد|المواعيد|جدولتي|مواعيدي/.test(low) && !/اضف|أضف|انشئ|إنشئ|موعد\s*\|/.test(low)) {
      const tasks = s.automation.tasks || [];
      return this.reply(`المواعيد المحفوظة (${tasks.length}):\n${tasks.length ? tasks.map((t,i)=>`${i+1}. ${t.name} | ${t.mode} | ${t.date || 'متكرر'} ${t.time} | ${t.enabled?'مفعّل':'متوقف'} | ID=${t.id}`).join('\n') : 'لا توجد مواعيد.'}`, 'list-schedules');
    }
    const modeText = norm(f.repeat || (low.includes('اسبوع') ? 'أسبوعي' : low.includes('شهري') ? 'شهري' : low.includes('سنوي') ? 'سنوي' : 'مرة'));
    const mode = /اسبوع|weekly/.test(modeText) ? 'weekly' : /شهري|monthly/.test(modeText) ? 'monthly' : /سنوي|yearly/.test(modeText) ? 'yearly' : 'once';
    const time = f.time || '';
    if (!time) throw new Error('حدد الوقت بصيغة 24 ساعة: الوقت=18:30.');
    if (mode === 'once' && !/^\d{4}-\d{2}-\d{2}$/.test(f.date || '')) throw new Error('الموعد مرة واحدة يحتاج التاريخ=YYYY-MM-DD.');
    const targetsRaw = f.to || '';
    const targetKeys = this.targetKeys(id, targetsRaw, { allowAll:true, requireConfirm:true, confirm:f.confirm || '' });
    const selectedFiles = [];
    const files = this.delivery.files(id);
    const fileRaw = f.file || f.files || '';
    let mediaMode = /دورة|الحالية|cycle/i.test(fileRaw) ? 'cycle' : 'selected';
    if (fileRaw && mediaMode !== 'cycle') {
      const names = fileRaw.split(/[,،;؛]/).map(x=>x.trim()).filter(Boolean);
      for (const name of names) {
        const matches = files.filter(file => norm(file.id) === norm(name) || norm(file.filename) === norm(name) || norm(file.filename).includes(norm(name)));
        if (matches.length !== 1) throw new Error(`اسم الملف «${name}» غير موجود أو غير فريد. استخدم الاسم الكامل من قائمة «الوسائط».`);
        selectedFiles.push(matches[0].id);
      }
    }
    const textValue = f.text || '';
    if (!textValue && !selectedFiles.length && mediaMode !== 'cycle') throw new Error('أضف الرسالة=... أو ملف=اسم_الملف، أو ملف=الدورة.');
    const body = {
      name: f.name || 'موعد من WhatsApp', mode, date: f.date || '', time, day: weekdayNumber(f.day ?? f.repeat) ?? 5,
      dayOfMonth: Number(f.dayOfMonth || f.day || 1), month: Number(f.month || 1), year: f.year || '', timezone:s.settings.timezone,
      targetKeys, mediaIds:selectedFiles, mediaMode, text:textValue, textMode: norm(f.textMode || '').includes('تعليق') ? 'caption' : 'auto',
      captionMode:true, sendAsDocument:/مرفق|مستند|document/i.test(text), preText:'', postText:'', sendDelayMs:s.settings.sendDelayMs,
      graceMinutes:30, scheduledGroupsEnabled:true, sendOrder:'target-first',
    };
    const task = this.normalizeAutomationPayload(id, body);
    s.automation.tasks.push(task); s.automation.enabled = true; this.store.saveSession(s);
    const saved = this.session(id).automation.tasks.find(t=>t.id===task.id);
    if (!saved) throw new Error('لم أستطع التحقق من حفظ الموعد.');
    const scope = mode === 'once' ? `بتاريخ ${task.date}` : mode === 'weekly' ? `كل أسبوع (اليوم ${task.day})` : mode === 'monthly' ? `كل شهر (اليوم ${task.dayOfMonth})` : `كل سنة (الشهر ${task.month}، اليوم ${task.dayOfMonth})`;
    return this.reply(`✅ حُفظ الموعد فعليًا وأصبح لدى المجدول.\nالاسم: ${task.name}\nالوقت: ${task.time} (${s.settings.timezone})\nالتكرار: ${scope}\nالأهداف: ${task.targetKeys.length}\nالملفات: ${task.mediaIds.length}${task.mediaMode==='cycle'?' (دورة الصور)':''}\nالمهمة: ${task.id}\nمهم: يبقى التطبيق والخادم يعملان وقت الموعد.`, 'create-schedule');
  }
  saveConversation(id, conversation) {
    const s = this.session(id);
    s.ownerAssistant.conversation = conversation || null;
    this.store.saveSession(s);
    return s.ownerAssistant.conversation;
  }
  isAddRecipientWizardIntent(text) {
    const value = norm(text);
    if (!value || /(?:رقم\s*[=:]|الاسم\s*[=:]|الدولة\s*[=:])/.test(value)) return false;
    if (/(?:\+|00)?\d[\d\s().-]{6,}/u.test(text) && /(?:اضف|اضيف|ضيف|سجل|احفظ)/u.test(value)) return false;
    const action = /^(?:(?:انا\s+)?(?:عايز|عاوزه|عاوز|عاوزة|اريد|محتاج|محتاجه|ابغى|ممكن)\s+(?:اني\s+)?(?:اضيف|اضف|ضيف|سجل|احفظ|اضافه|اضافة)|اضيف|اضف|ضيف|سجل|احفظ|اضافه|اضافة)(?=\s|$)/u.test(value);
    const target = /(?:رقم|مستخدم|مستلم|شخص|جهة اتصال|جهات الاتصال|contact|recipient)/u.test(value);
    return action && target;
  }
  async handleConversationInput(id, text) {
    const s = this.session(id), existing = s.ownerAssistant.conversation;
    const cancel = /^(?:الغاء|إلغاء|الغي|ألغ|الغِ|cancel|الغاء العملية|إلغاء العملية|وقف المحادثة)$/iu.test(text.trim());
    if (cancel) {
      if (!existing) return this.reply('لا توجد خطوات معلّقة لإلغائها. اكتب «مساعدة» لرؤية ما أستطيع تنفيذه.', 'conversation-cancel');
      s.ownerAssistant.conversation = null; this.store.saveSession(s);
      return this.reply('✅ ألغيت العملية الحوارية. لم تتم إضافة أي رقم ولم أغيّر قائمة الأشخاص.', 'conversation-cancel');
    }
    let flow = existing;
    if (!flow && this.isAddRecipientWizardIntent(text)) {
      flow = { type:'add-recipient', step:'name', data:{}, startedAt:new Date().toISOString(), updatedAt:new Date().toISOString() };
      s.ownerAssistant.conversation = flow; this.store.saveSession(s);
      return this.reply('تمام، سنضيف رقم مستخدم جديد على 3 خطوات.\n\nالخطوة 1/3 — **اسم المستخدم**\nاكتب الاسم الذي تريد ظهوره في قائمة الأشخاص، مثل: أحمد.\nسأستخدم هذا الرد كقيمة «الاسم». لن أضيف أي رقم قبل التحقق من الدولة ورقم الهاتف.\nللتراجع في أي وقت اكتب «إلغاء».', 'conversation-start');
    }
    if (!flow || flow.type !== 'add-recipient') return null;
    const age = Date.now() - Date.parse(flow.updatedAt || flow.startedAt || 0);
    if (!Number.isFinite(age) || age > 30 * 60 * 1000) {
      s.ownerAssistant.conversation = null; this.store.saveSession(s);
      return this.reply('انتهت صلاحية خطوات الإضافة بعد 30 دقيقة لحماية البيانات من استخدام رد قديم. لم أضف شيئًا. ابدأ بكتابة «عايز أضيف رقم مستخدم جديد».', 'conversation-expired');
    }
    if (norm(text) === 'مساعدة' || norm(text) === 'help') return this.reply(`${HELP}\n\nالعملية الحالية ما زالت محفوظة؛ أكمل الحقل المطلوب أو اكتب «إلغاء».`, 'help');

    if (flow.step === 'name') {
      const name = clean(text, 80);
      if (!name || name.length < 2 || /(?:\+|00)?\d[\d\s().-]{6,}/u.test(name)) {
        return this.reply('لم أقبل الاسم لأنّه فارغ أو يبدو كأنه رقم هاتف.\nالخطوة 1/3 — اكتب اسمًا واضحًا من حرفين على الأقل، مثل: أحمد. لم يتم حفظ أي رقم.', 'conversation-invalid-name');
      }
      flow.data = { name };
      flow.step = 'country'; flow.updatedAt = new Date().toISOString();
      this.saveConversation(id, flow);
      return this.reply(`✅ فهمت الاسم: «${name}».\n\nالخطوة 2/3 — **الدولة**\nاكتب الدولة التي ينتمي إليها رقم ${name}، مثل: عمان، السعودية، مصر، الإمارات، أو رمز ISO مثل OM/SA/EG/AE.\nسأستخدم هذا الرد لتفسير الرقم المحلي والتحقق من صحته؛ لم تتم إضافة جهة الاتصال بعد.`, 'conversation-name');
    }

    if (flow.step === 'country') {
      if (/(?:الدولة|البلد).*(?:غلط|خطأ|خطا|تغيير)|^(?:رجوع|ارجع)$/iu.test(text)) {
        return this.reply('نحن في خطوة الدولة. اكتب اسم الدولة الصحيح أو رمزها مثل عمان/OM أو السعودية/SA. لم يتم حفظ الرقم.', 'conversation-country');
      }
      const country = resolveCountry(text);
      if (!country) {
        return this.reply(`لم أتعرف على الدولة «${clean(text,60)}»، لذلك لم أغيّر شيئًا.\nالخطوة 2/3 — أرسل اسم دولة واضحًا مثل عمان أو السعودية أو مصر، أو رمزًا من حرفين مثل OM أو SA أو EG. يمكنك كتابة «إلغاء» للتراجع.`, 'conversation-invalid-country');
      }
      flow.data.countryCode = country.code; flow.data.countryName = country.name;
      flow.step = 'phone'; flow.updatedAt = new Date().toISOString();
      this.saveConversation(id, flow);
      return this.reply(`✅ تم فهم الدولة: ${country.name} (${country.code}).\n\nالخطوة 3/3 — **رقم الهاتف**\nأرسل رقم ${flow.data.name} مع أو بدون رمز الدولة، مثل: ${country.code === 'OM' ? '91234567 أو +96891234567' : 'رقم الهاتف المحلي أو الرقم الدولي الذي يبدأ بعلامة +'} .\nسأتحقق من صلاحية الرقم واتساقه مع ${country.name} وأمنع التكرار. لن أحفظه إن كان غير صالح.`, 'conversation-country');
    }

    if (flow.step === 'phone') {
      if (/(?:الدولة|البلد).*(?:غلط|خطأ|خطا|مش صح|تغيير)/iu.test(text)) {
        flow.step = 'country'; flow.updatedAt = new Date().toISOString(); this.saveConversation(id, flow);
        return this.reply(`حسنًا، نرجع إلى خطوة الدولة مع الاحتفاظ بالاسم «${flow.data.name}». اكتب الدولة الصحيحة مثل عمان أو السعودية أو رمزها OM/SA. لم يُحفظ الرقم بعد.`, 'conversation-country-correction');
      }
      const rawPhone = extractPhone(text) || clean(text, 40);
      let parsed;
      try { parsed = require('./phones').parse(rawPhone, flow.data.countryCode); }
      catch (error) {
        return this.reply(`❌ رقم الهاتف غير صالح للدولة المحددة (${flow.data.countryName}). لم أحفظ أي جهة اتصال.\n\nأعد إرسال رقم صحيح في الخطوة 3/3، مثل ${flow.data.countryCode === 'OM' ? '+96891234567' : 'رقم دولي يبدأ بعلامة +'} . إذا كانت الدولة نفسها خطأ، اكتب «الدولة غلط» ثم أدخلها من جديد.`, 'conversation-invalid-phone');
      }
      const explicitInternational = /^\s*(?:\+|00)/u.test(rawPhone);
      if (explicitInternational && parsed.country && parsed.country !== flow.data.countryCode) {
        return this.reply(`❌ رمز الرقم الدولي يطابق دولة مختلفة: الرقم يعرّف دولة ${parsed.country} وليس ${flow.data.countryName} (${flow.data.countryCode}). لم أحفظ الرقم.\nأرسل رقمًا تابعًا لـ ${flow.data.countryName} أو اكتب «الدولة غلط» لاختيار دولة أخرى.`, 'conversation-country-mismatch');
      }
      const latest = this.session(id);
      const exists = latest.recipients.find(x => String(x.e164 || '').replace(/\D/g,'') === parsed.digits || String(x.digits || x.phone || '').replace(/\D/g,'') === parsed.digits);
      if (exists) {
        return this.reply(`هذا الرقم محفوظ بالفعل باسم «${exists.name}». لم أضف نسخة مكررة.\nأرسل رقمًا آخر لـ «${flow.data.name}»، أو اكتب «إلغاء».`, 'conversation-duplicate-phone');
      }
      try {
        const outcome = await this.addRecipient(id, `رقم=${rawPhone} | الاسم=${flow.data.name} | الدولة=${flow.data.countryCode}`);
        const verify = this.session(id).recipients.find(x => String(x.e164 || '').replace(/\D/g,'') === parsed.digits);
        if (!verify) throw new Error('لم يظهر الرقم في قائمة الأشخاص بعد الحفظ.');
        const fresh = this.session(id); fresh.ownerAssistant.conversation = null; this.store.saveSession(fresh);
        return this.reply(`${outcome.response}\n\n🎉 اكتملت الخطوات 3/3 وتم التحقق من حفظ جهة الاتصال.\nالقيم التي استُخدمت: الاسم=${verify.name} | الدولة=${verify.country || flow.data.countryCode} | الرقم=${verify.international || verify.e164}.\nيمكنك الآن كتابة «اعرض الأشخاص» لرؤية القائمة.`, 'conversation-add-recipient');
      } catch (error) {
        return this.reply(`تعذّر إكمال الإضافة: ${clean(error.message || error, 450)}\nلم تُحفظ جهة اتصال جديدة. أرسل رقمًا آخر صحيحًا أو اكتب «إلغاء».`, 'conversation-invalid-phone');
      }
    }
    s.ownerAssistant.conversation = null; this.store.saveSession(s);
    return this.reply('انتهت حالة المحادثة القديمة. اكتب «عايز أضيف رقم مستخدم جديد» للبدء من جديد.', 'conversation-reset');
  }
  faqResponse(text) {
    const value = norm(text);
    if (/^(?:السلام عليكم|السلام عليكم ورحمة الله وبركاته|مرحبا|مرحبا بك|اهلا|اهلين|صباح الخير|مساء الخير|hi|hello|hey)$/u.test(value))
      return this.reply('وعليكم السلام وأهلًا بك 👋\nأنا مساعد محلي داخل chat BOT. اكتب «مساعدة» للدليل، أو «عايز أضيف رقم مستخدم جديد» للبدء بحوار الاسم ثم الدولة ثم الرقم. كل خطوة تشرح لك ما يجب إرساله.', 'faq-greeting');
    if (/(?:ماذا|ايش|وش|ايه|ما هي|ماهي).{0,24}(?:تستطيع|تقدر|تعمل|وظيف|اوامر|مساعد)|(?:قدرات|وظائف) (?:البوت|المساعد)/u.test(value))
      return this.reply('أقدر محليًا إدارة الأرقام والمجموعات والمواعيد والوسائط، وتشغيل الإرسال بعد ربط WhatsApp، وإدارة قواعد تفاعل محفوظة. لا أستخدم API ذكاء اصطناعي لتلك الأوامر. اكتب «مساعدة» للدليل المنظم، أو ابدأ بعبارة «عايز أضيف رقم مستخدم جديد».', 'faq-capabilities');
    if (/(?:كيف|ازاي|ازاى|شلون|طريقة).{0,30}(?:اضيف|اضافه|رقم|مستخدم)/u.test(value))
      return this.reply('لإضافة رقم بالمحادثة، اكتب بالضبط: «عايز أضيف رقم مستخدم جديد». سأطلب الاسم، ثم الدولة، ثم رقم الهاتف. كل رد يكون قيمة الحقل الذي أطلبه، وسأرفض الدولة/الرقم غير الصحيح دون حفظ.', 'faq-add-recipient');
    if (/(?:كيف|ازاي|ازاى|شلون|طريقة).{0,30}(?:ربط|حساب|رقم).{0,20}(?:ثاني|تاني|اخر|آخر)/u.test(value) || /(?:رقم ثاني|رقم تاني|حساب ثاني|حساب تاني)/u.test(value))
      return this.reply('لربط رقم آخر تملكه: اكتب «أنشئ جلسة | الاسم=رقم الرد الثاني»، ثم افتح الجلسة الجديدة من اللوحة وامسح QR بحساب الرقم الثاني. بعد اتصال الحسابين، استخدم «فعّل حساب الرد الثاني | الجلسة=معرّف_الجلسة | تأكيد=نعم». مهم: الردود من الرقم الثاني تظهر في محادثة مستقلة معه، ولا يمكنها الظهور داخل محادثة «الرسائل إلى نفسك». اكتب «مساعدة» للتفاصيل.', 'faq-second-account');
    if (/(?:هل|لازم|يحتاج|يحتاجني).{0,20}(?:api|ذكاء اصطناعي|انترنت)/u.test(value) || /بدون api|من دون api/u.test(value))
      return this.reply('الأوامر المحلية وإضافة الأرقام وإدارة الجلسات لا تحتاج API توليديًا. يلزم اتصال إنترنت وحساب WhatsApp مرتبط لتنفيذ الفحص والإرسال الحقيقي والمواعيد، ويجب أن يبقى الخادم يعمل وقت الموعد.', 'faq-api');
    if (/^(?:شكرا|شكرًا|تسلم|تمام|اوكي|ok|thanks)$/u.test(value))
      return this.reply('العفو! اكتب «مساعدة» للدليل، أو اذكر المهمة التي تريد تنفيذها. سأوضح كل حقل قبل استخدامه.', 'faq-thanks');
    return null;
  }
  sessionPhone(id) {
    const self = String(this.whatsapp.selfChatId(id) || '').toLowerCase();
    const match = self.match(/^(\d{6,20})@c\.us$/);
    return match ? match[1] : '';
  }
  async replySessionCommand(id, text) {
    if (/^(?:حالة حساب الرد|حساب الرد|حالة رقم الرد الثاني)$/iu.test(text)) {
      const s = this.session(id), c = s.ownerAssistant, otherId = String(c.replySessionId || ''), rt = otherId ? this.whatsapp.listRuntime(otherId) : null;
      const primaryPhone = this.sessionPhone(id), otherPhone = otherId ? this.sessionPhone(otherId) : '';
      return this.reply(`قناة الرد لهذه الجلسة:\nالوضع: ${c.replySessionEnabled && otherId ? 'الرد من حساب ثانٍ' : 'الرد الافتراضي داخل الرسائل إلى نفسك'}\nالجلسة الثانية: ${otherId || 'غير محددة'}\nحالة الحساب الثاني: ${rt ? (rt.ready ? 'متصل' : rt.status) : 'غير مرتبط'}\nرقم الحساب الأساسي: ${primaryPhone ? `••••${primaryPhone.slice(-4)}` : 'لم أتعرف عليه بعد'}\nرقم الحساب الثاني: ${otherPhone ? `••••${otherPhone.slice(-4)}` : 'غير متاح'}\nلا يتفعّل الحساب الثاني إلا إذا كان الرقمان متصلين ومختلفين وبموافقة صريحة.`, 'reply-session-status');
    }
    if (/^(?:أوقف حساب الرد الثاني|اوقف حساب الرد الثاني|عطّل حساب الرد الثاني|عطل حساب الرد الثاني|الرد داخل نفسي|أوقف الرد من الرقم الثاني)$/iu.test(text)) {
      const s = this.session(id); s.ownerAssistant.replySessionEnabled = false; s.ownerAssistant.replySessionConfirmedAt = ''; this.store.saveSession(s);
      return this.reply('✅ أوقفت الرد من الحساب الثاني. ستعود الردود إلى محادثة «الرسائل إلى نفسك» باستخدام الحساب الأساسي. الجلسة الثانية لم تُحذف ولم أفصل حسابها.', 'reply-session-disable');
    }
    if (!/^(?:فعّل|فعل) حساب الرد الثاني(?:\s*\||\s*$)/iu.test(text)) return null;
    const fields = parseFields(text), targetId = clean(fields.session || fields['معرف الجلسة'] || fields['الجلسة'] || '', 80), confirm = norm(fields.confirm || '');
    if (confirm !== 'نعم') throw new Error('لأمان الحساب، أضف «تأكيد=نعم» بعد مراجعة رقم الجلسة التي تملكها.');
    if (!targetId || !this.store.listSessionIds().includes(targetId)) throw new Error('معرّف الجلسة الثانية غير موجود. اكتب «الجلسات» ثم انسخ المعرّف الصحيح.');
    if (targetId === id) throw new Error('اختر جلسة أخرى؛ لا يمكن استخدام الحساب نفسه كرقم ثانٍ.');
    const primaryRuntime = this.whatsapp.listRuntime(id), secondRuntime = this.whatsapp.listRuntime(targetId);
    if (!primaryRuntime.ready || !secondRuntime.ready) throw new Error('يجب أن يكون الحساب الأساسي والحساب الثاني متصلين أولًا. اربط الجلسة الثانية بمسح QR من الهاتف الذي تملكه.');
    const primaryPhone = this.sessionPhone(id), secondPhone = this.sessionPhone(targetId);
    if (!primaryPhone || !secondPhone) throw new Error('تعذر التحقق من رقمي الحسابين بأمان. أعد اتصال كل جلسة وتأكد أن رقم الهاتف ظاهر كمعرّف c.us.');
    if (primaryPhone === secondPhone) throw new Error('الحسابان مرتبطان بالرقم نفسه؛ اختر جلسة متصلة برقم WhatsApp حقيقي مختلف تملكه.');
    const s = this.session(id); s.ownerAssistant.replySessionId = targetId; s.ownerAssistant.replySessionEnabled = true; s.ownerAssistant.replySessionConfirmedAt = new Date().toISOString(); this.store.saveSession(s);
    const check = this.session(id).ownerAssistant;
    if (!check.replySessionEnabled || check.replySessionId !== targetId) throw new Error('لم أستطع التحقق من حفظ إعداد قناة الرد الثانية.');
    return this.reply(`✅ تم تفعيل الرد عبر الجلسة الثانية «${targetId}» بعد التحقق من أن الحسابين متصلان وبرقمين مختلفين.\n\nمهم لفهم واتساب: سيظهر رد الحساب الثاني داخل محادثة مستقلة مع ذلك الرقم، وليس داخل «الرسائل إلى نفسك». يمكنك إرسال أمر بدء من محادثة نفسك، ثم مواصلة الحوار إما من هناك (ستصل الردود إلى شات الرقم الثاني) أو بفتح شات الرقم الثاني والرد عليه مباشرة. لإرجاع جميع الردود لنفسك اكتب «أوقف حساب الرد الثاني».`, 'reply-session-enable');
  }
  async run(id, input) {
    const text = clean(input, 1000), lower = norm(text);
    if (!text) return { handled:false };
    const activeFlow = this.session(id).ownerAssistant.conversation;
    if (/^(?:الغاء|إلغاء|الغي|ألغ|الغِ|cancel|الغاء العملية|إلغاء العملية|وقف المحادثة)$/iu.test(text.trim())) return this.handleConversationInput(id, text);
    if (activeFlow && /^(?:مساعدة|help|الأوامر|اوامر|commands|الاوامر|دليل الأوامر|دليل المستخدم)\s*$/iu.test(text)) return this.handleConversationInput(id, text);
    if (/^(?:مساعدة|help|الأوامر|اوامر|commands|الاوامر|دليل الأوامر|دليل المستخدم)\s*$/iu.test(text)) return this.reply(HELP, 'help');
    const accountCommand = await this.replySessionCommand(id, text);
    if (accountCommand) return accountCommand;
    const conversational = await this.handleConversationInput(id, text);
    if (conversational) return conversational;
    const faq = this.faqResponse(text);
    if (faq) return faq;
    if (/^(?:أنشئ جلسة|انشئ جلسة|أضف جلسة|اضف جلسة)(?:\s*\||\s*$)/iu.test(text)) {
      const f=parseFields(text), name=clean(f.name||'',80); if(!name) throw new Error('اكتب اسم الجلسة: أنشئ جلسة | الاسم=حساب ثانٍ.');
      if(typeof this.store.createSessionInactive!=='function') throw new Error('إصدار التخزين الحالي لا يدعم إنشاء جلسة مستقلة بأمان.');
      const created=this.store.createSessionInactive(name), ids=this.store.listSessionIds();
      if(!ids.includes(created.id)) throw new Error('لم أتمكن من التحقق من حفظ الجلسة الجديدة.');
      return this.reply(`✅ أنشأت الجلسة المستقلة «${created.name}» وحفظتها. لم أغيّر الجلسة النشطة ولم أنقل إليها مصادقة WhatsApp.
المعرّف: ${created.id}
افتح قائمة الجلسات، ثم اربط حساب WhatsApp داخل الجلسة الجديدة.`, 'create-session');
    }
    if (/^احذف الجلسة\s+.+$/iu.test(text)) {
      const f=parseFields(text), raw=text.replace(/^احذف الجلسة\s+/iu,'').replace(/\s*\|\s*تأكيد\s*[=:].*$/iu,'').trim();
      const target=this.store.safeSessionId?this.store.safeSessionId(raw):raw;
      if(norm(f.confirm||'')!=='نعم')throw new Error('حذف الجلسة يحتاج تأكيدًا صريحًا: احذف الجلسة ID | تأكيد=نعم.');
      if(target===String(id))throw new Error('لا يمكن حذف الجلسة التي تستخدمها هذه المحادثة؛ استخدم لوحة الجلسات بعد التأكد من النسخة الاحتياطية.');
      if(this.store.activeSessionId&&target===this.store.activeSessionId())throw new Error('لا يمكن حذف الجلسة النشطة من محادثة أخرى حتى لا تتغير الجلسة الحالية دون قصد. اخترها في اللوحة أولًا ثم احذفها من الواجهة.');
      if(!this.store.listSessionIds().includes(target))throw new Error('لم أجد معرّف جلسة محفوظًا بهذا الاسم. اكتب «الجلسات» لنسخ المعرّف الصحيح.');
      await this.whatsapp.stop(target,{clearAuth:true});
      const deleted=this.store.deleteSession(target);
      if(this.store.listSessionIds().includes(target)||deleted.deletedSessionId!==target)throw new Error('لم أستطع التحقق من حذف الجلسة.');
      return this.reply(`✅ حُذفت الجلسة «${target}» وملفات مصادقتها بعد التأكيد. الجلسة التي أرسلت منها الأمر لم تتغير.`, 'delete-session');
    }
    if (/^(?:غيّر اسم الجلسة|غير اسم الجلسة|أعد تسمية الجلسة|اعد تسمية الجلسة)\s+(?:إلى|الى|لـ|ل)\s+.+$/iu.test(text)) {
      const name=clean(text.replace(/^(?:غيّر اسم الجلسة|غير اسم الجلسة|أعد تسمية الجلسة|اعد تسمية الجلسة)\s+(?:إلى|الى|لـ|ل)\s+/iu,''),80);
      if(!name) throw new Error('اكتب الاسم الجديد.'); const renamed=this.store.renameSession(id,name); return this.reply(`✅ تغيّر اسم الجلسة الحالية إلى «${renamed.name}» وتم حفظه.`, 'rename-session');
    }
    if (/^(?:اتصل بواتساب|أعد الاتصال|اعد الاتصال|ربط واتساب|شغّل واتساب|شغل واتساب)$/iu.test(text)) {
      const rt=await this.whatsapp.start(id), live=this.whatsapp.listRuntime(id);
      return this.reply(`حالة محاولة الاتصال: ${live.ready?'متصل':live.status}. ${live.ready?'الجلسة جاهزة.':'لم أؤكد الاتصال بعد؛ افتح قسم الجلسة واتبع QR إذا ظهر.'}`, 'connect-session');
    }
    if (/^(?:افصل واتساب|أوقف اتصال واتساب|اوقف اتصال واتساب|أوقف الجلسة مؤقتًا|اوقف الجلسة مؤقتا)$/iu.test(text)) {
      await this.whatsapp.stop(id); const live=this.whatsapp.listRuntime(id);
      if(live.ready || !['stopped','disconnected','idle'].includes(String(live.status))) throw new Error(`طلب إيقاف الجلسة لكن الحالة الحالية «${live.status}».`);
      return this.reply(`✅ أُوقف اتصال WhatsApp لهذه الجلسة فقط. الحالة: ${live.status}. لم أحذف ملفات المصادقة.`, 'stop-session');
    }
    if (/^(?:افحص|تشخيص|diagnostic|check)\s*$/iu.test(text)) return { handled:true, ok:true, action:'diagnostics', response:'__RUN_DIAGNOSTICS__' };
    if (/^(?:حالة الاتصال|الحالة|status|متصل|اتصال)\s*$/iu.test(text)) {
      const s = this.session(id), rt = this.whatsapp.listRuntime(id);
      return this.reply(`الجلسة: ${s.name} (${s.id})\nWhatsApp: ${rt.ready?'متصل':rt.status}\nالأشخاص: ${s.recipients.length} (${s.recipients.filter(x=>x.enabled!==false).length} مفعّل)\nالمجموعات: ${s.groups.length} (${s.groups.filter(x=>x.enabled!==false).length} مفعّل)\nالمواعيد: ${(s.automation.tasks||[]).length}\nقواعد التفاعل: ${(s.interaction.rules||[]).length}\nالمشكلات المفتوحة: ${(s.ownerAssistant?.issues||[]).filter(x=>x.status==='open').length}`, 'status');
    }
    if (/^(?:الجلسات|اعرض الجلسات|قائمة الجلسات|sessions)\s*$/iu.test(text)) {
      const ids = this.store.listSessionIds();
      return this.reply(`الجلسات (${ids.length}):\n${ids.map((sid,i)=>{const s=this.session(sid),rt=this.whatsapp.listRuntime(sid);return `${i+1}. ${s.name} | ${sid} | ${rt.ready?'متصل':rt.status}`;}).join('\n')}\nهذا الأمر يعرض الجلسات فقط ولا يبدّل الجلسة النشطة.`, 'list-sessions');
    }
    if (/^(?:اعرض الأشخاص|الأشخاص|قائمة الأرقام|ارقامى|أرقامي|جهات الاتصال|المستلمين)\s*$/iu.test(text)) {
      const s=this.session(id); return this.reply(`الأشخاص (${s.recipients.length}):\n${s.recipients.length?s.recipients.map((r,i)=>`${i+1}. ${r.name} | ${r.international||r.e164||r.digits} | ${r.enabled===false?'متوقف':'مفعّل'}`).join('\n'):'لا توجد أرقام محفوظة.'}`, 'list-recipients');
    }
    if (/^(?:الوسائط|اعرض الوسائط|الملفات|ملفاتي)\s*$/iu.test(text)) {
      const fs=this.delivery.files(id); return this.reply(`الملفات (${fs.length}):\n${fs.slice(0,50).map((f,i)=>`${i+1}. ${f.filename} | ${f.isImage?'صورة':'ملف'} | ${f.size} bytes`).join('\n')||'لا توجد ملفات.'}\nاستخدم الاسم الكامل في حقل «ملف=».`, 'list-media');
    }
    if (/^(?:معلومات المجموعة|تفاصيل المجموعة|معلومات القروب|تفاصيل القروب)\s+(.+)$/iu.test(text)) {
      const query=clean(text.replace(/^(?:معلومات المجموعة|تفاصيل المجموعة|معلومات القروب|تفاصيل القروب)\s+/iu,''),180), s=this.session(id), q=norm(query);
      const hits=s.groups.filter(g=>norm(g.name)===q||String(g.gid||'').toLowerCase()===query.toLowerCase());
      if(hits.length!==1) throw new Error(hits.length?'اسم المجموعة غير فريد؛ استخدم GID.':'لم أجد المجموعة المحفوظة بهذا الاسم. أرسل رابط الدعوة أو GID لتحليلها.');
      return this.reply(groups.formatGroupAnalysis(hits[0]), 'group-details');
    }
    if (/^(?:افحص الرقم|تحقق من الرقم|تحقق الرقم|هل الرقم مسجل)\s+.+$/iu.test(text)) {
      const raw=text.replace(/^(?:افحص الرقم|تحقق من الرقم|تحقق الرقم|هل الرقم مسجل)\s+/iu,''), parsed=require('./phones').parse(raw,'OM');
      if(!this.whatsapp.listRuntime(id).ready) throw new Error('فحص تسجيل الرقم يحتاج WhatsApp متصلًا في هذه الجلسة.');
      const chatId=await this.whatsapp.resolveChatId(id,{kind:'person',...parsed});
      if(!chatId) throw new Error('لم يرجع WhatsApp معرف محادثة لهذا الرقم.');
      return this.reply(`✅ أكد WhatsApp أن الرقم مسجّل ويمكن تحديد محادثته.\nالرقم: ${parsed.international||parsed.e164}\nالمعرّف: ${chatId}\nلم أضفه إلى القائمة؛ استخدم «أضف الرقم … باسم …» لحفظه.`, 'validate-phone');
    }
    if (/^(?:اعرض المشاكل|مشاكلي|الأخطاء المفتوحة|الاخطاء المفتوحة)\s*$/iu.test(text)) {
      const issues=(this.session(id).ownerAssistant?.issues||[]).filter(x=>x.status==='open').slice(-12);
      return this.reply(`المشكلات المفتوحة (${issues.length}):\n${issues.length?issues.map((x,i)=>`${i+1}. ${x.title} | ${x.code} | ID=${x.id}\n${x.details}`).join('\n'): 'لا توجد مشكلات مفتوحة مسجلة.'}`, 'list-issues');
    }
    if (/^(?:حل المشكلة|أغلق المشكلة|اغلق المشكلة)\s+(.+)$/iu.test(text)) {
      const q=norm(text.replace(/^(?:حل المشكلة|أغلق المشكلة|اغلق المشكلة)\s+/iu,'')), s=this.session(id), issues=s.ownerAssistant?.issues||[];
      const hits=issues.filter(x=>norm(x.id)===q||(x.status==='open'&&norm(x.title)===q));
      if(hits.length!==1) throw new Error(hits.length?'المشكلة غير محددة؛ استخدم ID.':'لم أجد المشكلة المفتوحة.');
      hits[0].status='resolved'; hits[0].resolvedAt=new Date().toISOString(); hits[0].resolvedBy='owner-command'; this.store.saveSession(s);
      const checked=(this.session(id).ownerAssistant?.issues||[]).find(x=>x.id===hits[0].id); if(!checked||checked.status!=='resolved')throw new Error('لم أستطع التحقق من حفظ حالة المشكلة.');
      return this.reply(`✅ تم إغلاق المشكلة في السجل وحفظها: ${checked.title} (${checked.id}). هذا يحدّث حالة السجل فقط ولا يدّعي أن سببها التقني اختفى ما لم يُختبر الإصلاح.`, 'resolve-issue');
    }
    if (/^(?:اعرض سجل المساعد|سجل المساعد|رسائل المساعد)\s*$/iu.test(text)) {
      const messages=this.session(id).ownerAssistant?.messages||[];
      return this.reply(`آخر رسائل المساعد (${Math.min(12,messages.length)} من ${messages.length}):\n${messages.slice(-12).map(m=>`${m.role==='user'?'أنت':'المساعد'}: ${String(m.text||'').slice(0,220)}`).join('\n')||'لا توجد رسائل محفوظة.'}`, 'list-assistant-messages');
    }
    if (/^(?:فعّل إشعارات المساعد|فعل إشعارات المساعد|أوقف إشعارات المساعد|اوقف إشعارات المساعد)$/iu.test(text)) {
      const s=this.session(id); if(!s.ownerAssistant)s.ownerAssistant={messages:[],issues:[],activity:[],pendingNotifications:[],notificationMode:'self'};
      const enabled=/^(?:فعّل|فعل)/iu.test(text); s.ownerAssistant.notificationsEnabled=enabled; this.store.saveSession(s);
      const verified=this.session(id).ownerAssistant.notificationsEnabled===enabled; if(!verified)throw new Error('لم يتم حفظ خيار الإشعارات.');
      return this.reply(`✅ ${enabled?'تم تفعيل':'تم إيقاف'} إشعارات المساعد وحُفظ الخيار لهذه الجلسة. ${enabled?'سيحاول إرسال التنبيهات الجديدة عبر القناة المضبوطة عند اتصال WhatsApp.':'ستبقى التنبيهات محفوظة محليًا دون إرسالها.'}`, 'assistant-notifications');
    }
    if (/^اعرض إعدادات الإرسال\s*$/iu.test(text)) {
      const s=this.session(id); return this.reply(`إعدادات الإرسال للجلسة «${s.name}»:\nتأخير بين العمليات: ${Number(s.settings.sendDelayMs||0)} ms\nالأتمتة: ${s.settings.automationEnabled===false?'متوقفة':'مفعّلة'}\nالمنطقة الزمنية: ${s.settings.timezone||'Asia/Muscat'}\nالمستلمون المفعّلون: ${s.recipients.filter(x=>x.enabled!==false).length}\nالمجموعات المفعّلة: ${s.groups.filter(x=>x.enabled!==false).length}`, 'send-settings');
    }
    if (/^احذف الملف\s+.+$/iu.test(text) || /^أزل الملف\s+.+$/iu.test(text)) {
      const raw=text.replace(/^(?:احذف الملف|أزل الملف)\s+/iu,'').trim(), files=this.delivery.files(id);
      const matches=files.filter(x=>norm(x.filename)===norm(raw)||norm(x.id)===norm(raw));
      if(matches.length!==1)throw new Error(matches.length?'اسم الملف غير فريد. استخدم الاسم الكامل من «الوسائط».':'لم أجد هذا الملف في مكتبة الجلسة. اكتب «الوسائط» لعرض الأسماء.');
      const target=matches[0], dir=this.store.getPaths(id).media, full=mediaFiles.safePath(dir,target.filename||target.id);
      if(!fs.existsSync(full)||!fs.statSync(full).isFile())throw new Error('الملف غير موجود على القرص؛ لم أغيّر المواعيد.');
      const s=this.session(id); fs.rmSync(full,{force:false});
      let affected=0;
      for(const task of s.automation.tasks||[]) if((task.mediaIds||[]).includes(target.id)) {
        task.mediaIds=task.mediaIds.filter(x=>x!==target.id); affected++;
        if(task.mediaMode!=='cycle'&&!task.mediaIds.length&&!String(task.text||task.preText||task.postText||'').trim()) { task.enabled=false; task.lastResult={ok:false,error:`توقف الموعد لأن الملف ${target.filename||target.id} حُذف.`,at:new Date().toISOString()}; }
      }
      if(s.settings.scheduleMediaId===target.id)s.settings.scheduleMediaId='';
      if(s.cycle?.imageOrder)s.cycle.imageOrder=s.cycle.imageOrder.filter(x=>x!==target.id);
      this.store.saveSession(s);
      if(this.delivery.files(id).some(x=>x.id===target.id))throw new Error('أُزيل الملف من القرص لكن بقي ظاهرًا في فهرس الوسائط؛ حدّث المكتبة وافحص سجل المساعد.');
      return this.reply(`✅ حُذف الملف «${target.filename||target.id}» من مكتبة هذه الجلسة.\nالمواعيد التي كانت تشير إليه: ${affected}${affected?' — تم تحديثها؛ عُطّل الموعد الذي لم يعد يحتوي نصًا أو ملفًا.':'.'}`, 'delete-media');
    }
    if (/^اختبر الإرسال لنفسي\s*\|/iu.test(text)) {
      const f=parseFields(text), message=clean(f.text||'',1000), runtime=this.whatsapp.listRuntime(id), self=this.whatsapp.selfChatId(id);
      if(!runtime.ready)throw new Error('اربط WhatsApp أولًا قبل اختبار الإرسال.');
      if(!self)throw new Error('تعذر تحديد محادثة نفسك من حساب WhatsApp الحالي.');
      if(!message)throw new Error('استخدم: اختبر الإرسال لنفسي | الرسالة=رسالة اختبار.');
      const testText=`🤖 chat BOT | اختبار إرسال ذاتي\n${message}`;
      const result=await this.whatsapp.sendText(id,self,testText);
      const ack=result?.__chatBotAck?.status||result?.result?.__chatBotAck?.status||'created';
      return this.reply(`✅ أنشأ WhatsApp رسالة اختبار في محادثة نفسك.\nحالة الإرسال: ${ack}.\nلم يتم إرسالها إلى أي مستلم آخر.`, 'self-send-test');
    }
    if (/^(?:اضبط تأخير الإرسال|اضبط تأخير الارسال|غيّر تأخير الإرسال|غير تأخير الارسال)(?:\s*\||\s+).+$/iu.test(text)) {
      const f=parseFields(text), raw=f.sendDelayMs, n=Number(raw); if(raw===undefined||!Number.isInteger(n)||n<0||n>60000)throw new Error('استخدم: اضبط تأخير الإرسال | مللي ثانية=500. الحد من 0 إلى 60000.');
      const s=this.session(id); s.settings.sendDelayMs=n; this.store.saveSession(s); if(Number(this.session(id).settings.sendDelayMs)!==n)throw new Error('لم يتم التحقق من حفظ التأخير.');
      return this.reply(`✅ تم حفظ تأخير الإرسال: ${n} مللي ثانية بين العمليات لهذه الجلسة.`, 'send-settings');
    }
    if (/^(?:الجروبات|مجموعاتي|اعرض المجموعات|المجموعات|قائمة المجموعات|قروباتي)\s*$/iu.test(text)) return this.groupCommand(id,text);
    if (!/^(?:احذف المجموعة|حذف المجموعة|أوقف المجموعة|اوقف المجموعة|عطّل المجموعة|عطل المجموعة|فعّل المجموعة|فعل المجموعة)\s+/iu.test(text) && (/اكتشف المجموعات|اكتشاف المجموعات|حدّث المجموعات|حدث المجموعات|تحليل المجموعة|حلل المجموعة|تحليل القروب|حلل القروب|تفاصيل المجموعة|معلومات المجموعة|تفاصيل القروب|معلومات القروب/i.test(text) || /chat\.whatsapp\.com\//i.test(text) || /(?:أضف|اضف|ضيف)\s+(?:ال)?مجموعة/i.test(text) || /\d{5,25}(?:-\d+)*@g\.us/i.test(text))) return this.groupCommand(id,text);
    if (/(?:أضف|اضف|ضيف|سجل|احفظ).{0,20}(?:رقم|مستلم|شخص)/iu.test(text) || /^رقم\s*[=:]/iu.test(text) && /الاسم\s*[=:]/iu.test(text)) return this.addRecipient(id,text);
    if (/^(?:فعّل|فعل|شغّل|شغل|أوقف|اوقف|عطّل|عطل)\s+(?:اختبار التفاعل مع نفسي|التفاعل|الأتمتة|الاتمتة)$/iu.test(text)) {
      const s=this.session(id), enable=/^(?:فعّل|فعل|شغّل|شغل)/iu.test(text);
      if (/الأتمتة|الاتمتة/.test(text)) { s.settings.automationEnabled=enable; s.automation.enabled=enable; }
      else if (/اختبار التفاعل مع نفسي/.test(text)) {
        const self = this.whatsapp.selfChatId(id); if(enable && !self) throw new Error('لا أستطيع تحديد محادثة نفسك؛ اربط WhatsApp وانتظر حالة متصل.');
        s.settings.interactionIgnoreOwn = !enable;
        if (enable) { s.settings.interactionChatIds=[...new Set([...(s.settings.interactionChatIds||[]),self])]; s.settings.interactionScope='selected'; }
        else { s.settings.interactionChatIds=(s.settings.interactionChatIds||[]).filter(x=>String(x).toLowerCase()!==String(self).toLowerCase()); s.settings.interactionScope=(s.settings.interactionChatIds||[]).length?'selected':'all'; }
      } else { s.settings.interactionEnabled=enable; s.interaction.enabled=enable; }
      this.store.saveSession(s); const verify=this.session(id);
      const setting=/الأتمتة|الاتمتة/.test(text)?verify.settings.automationEnabled:/اختبار التفاعل مع نفسي/.test(text)?verify.settings.interactionIgnoreOwn===!enable:verify.settings.interactionEnabled===enable;
      if (!setting) throw new Error('لم تنجح مراجعة حفظ الإعداد.');
      return this.reply(`✅ تم ${enable?'التفعيل':'الإيقاف'} والحفظ الفعلي.`, 'settings');
    }
    if (/^(?:اعرض قواعد التفاعل|قواعد التفاعل|قواعدي)\s*$/iu.test(text)) {
      const s=this.session(id), rules=s.interaction.rules||[]; return this.reply(`قواعد التفاعل (${rules.length}):\n${rules.length?rules.map((r,i)=>`${i+1}. ${r.name||r.id} | ${r.enabled===false?'متوقفة':'مفعّلة'} | ${r.when?.match||'—'}: ${r.when?.value||'—'} | ID=${r.id}`).join('\n'):'لا توجد قواعد محفوظة.'}`, 'list-interaction-rules');
    }
    if (/^(?:احذف قاعدة التفاعل|حذف قاعدة التفاعل|أوقف قاعدة التفاعل|اوقف قاعدة التفاعل|فعّل قاعدة التفاعل|فعل قاعدة التفاعل)\s+.+$/iu.test(text)) {
      const m=text.match(/^(?:احذف قاعدة التفاعل|حذف قاعدة التفاعل|أوقف قاعدة التفاعل|اوقف قاعدة التفاعل|فعّل قاعدة التفاعل|فعل قاعدة التفاعل)\s+(.+)$/iu), q=norm(m?.[1]||''), s=this.session(id);
      const hits=(s.interaction.rules||[]).filter(r=>norm(r.id)===q||norm(r.name)===q||norm(r.name).includes(q));
      if(hits.length!==1) throw new Error(hits.length?'اسم القاعدة غير فريد؛ استخدم ID من «اعرض قواعد التفاعل».':'لم أجد قاعدة التفاعل.'); const rule=hits[0];
      if(/^(?:احذف|حذف)/.test(text)) s.interaction.rules=s.interaction.rules.filter(r=>r.id!==rule.id); else rule.enabled=/^(?:فعّل|فعل)/.test(text);
      this.store.saveSession(s); return this.reply(`✅ تم ${/^(?:احذف|حذف)/.test(text)?'حذف':rule.enabled?'تفعيل':'إيقاف'} قاعدة التفاعل «${rule.name}» وحُفظ التغيير.`, 'manage-interaction-rule');
    }
    if (/^أضف قاعدة تفاعل|^اضف قاعدة تفاعل|^أنشئ قاعدة تفاعل|^انشئ قاعدة تفاعل/iu.test(text)) {
      const f=parseFields(text), s=this.session(id), value=clean(f.when || '',500), reply=clean(f.reply || '',1000);
      if (!value || !reply) throw new Error('استخدم: أضف قاعدة تفاعل | الاسم=ترحيب | عندما=السلام عليكم | المطابقة=يحتوي | الرد=وعليكم السلام.');
      const mt=norm(f.match||'يحتوي'), match=/دقيق|exact/.test(mt)?'exact':/يبدأ|starts/.test(mt)?'starts':/ينتهي|ends/.test(mt)?'ends':/regex|نمط/.test(mt)?'regex':mt==='any'?'any':'contains';
      const rule={id:crypto.randomUUID(),name:clean(f.name||`قاعدة ${s.interaction.rules.length+1}`,100),enabled:true,priority:10,when:{type:'message',match,value,ignoreCase:true},then:{reply,reaction:''},scope:'all',chatIds:[],cooldownSec:30};
      require('./interaction').valid(rule); s.interaction.rules.push(rule); s.interaction.enabled=true; s.settings.interactionEnabled=true; this.store.saveSession(s);
      const ok=this.session(id).interaction.rules.some(x=>x.id===rule.id); if(!ok) throw new Error('لم يتم حفظ قاعدة التفاعل.');
      return this.reply(`✅ أُضيفت قاعدة التفاعل وحُفظت فعليًا.\nالاسم: ${rule.name}\nعند: ${value}\nالرد: ${reply}\nالمطابقة: ${match}\nID=${rule.id}`, 'add-interaction-rule');
    }
    if (/^(?:أوقف الأتمتة|اوقف الأتمتة|فعّل الأتمتة|فعل الأتمتة|تشغيل الأتمتة|تعطيل الأتمتة)$/iu.test(text)) { const s=this.session(id), on=/فعّل|فعل|تشغيل/.test(text); s.settings.automationEnabled=on; s.automation.enabled=on; this.store.saveSession(s); return this.reply(`✅ ${on?'الأتمتة مفعّلة':'الأتمتة متوقفة'} لهذه الجلسة.`, 'automation-toggle'); }
    if (/^(?:اعرض المواعيد|المواعيد|جدولتي|مواعيدي)\s*$/iu.test(text)) return this.scheduleCommand(id,text);
    if (/أضف موعد|اضف موعد|أنشئ موعد|انشئ موعد|جدولة|موعد\s*\|/iu.test(text)) return this.scheduleCommand(id,text);
    if (/^(?:نفّذ الموعد|نفذ الموعد|شغّل الموعد الآن|شغل الموعد الآن)\s+/iu.test(text)) {
      const query=norm(text.replace(/^(?:نفّذ الموعد|نفذ الموعد|شغّل الموعد الآن|شغل الموعد الآن)\s+/iu,'')), s=this.session(id);
      const hits=(s.automation.tasks||[]).filter(t=>norm(t.id)===query||norm(t.name)===query||norm(t.name).includes(query));
      if(hits.length!==1) throw new Error(hits.length?'اسم الموعد غير فريد؛ استخدم المعرّف من «اعرض المواعيد».':'لم أجد الموعد.');
      const task=hits[0]; if(!this.whatsapp.listRuntime(id).ready) throw new Error('اربط WhatsApp أولًا قبل التنفيذ.');
      const result=await this.delivery.scheduledTaskRun(id,task); const sent=Array.isArray(result.sent)?result.sent.length:0, failed=Array.isArray(result.failed)?result.failed.length:0;
      if(failed || result.ok===false) return this.reply(`⚠️ لم يكتمل الموعد: نجح ${sent} وفشل ${failed}. ${result.error||'راجع أخطاء الأهداف قبل إعادة التشغيل؛ لم أعد إرسال النجاحات تلقائيًا.'}`, 'run-schedule');
      return this.reply(`✅ أعاد محرك الإرسال نتيجة مكتملة للموعد «${task.name}»: ${sent} عملية.`, 'run-schedule');
    }
    if (/^(?:أوقف الموعد|اوقف الموعد|عطّل الموعد|عطل الموعد|فعّل الموعد|فعل الموعد|احذف الموعد|حذف الموعد)\s+/iu.test(text)) {
      const m=text.match(/^(?:أوقف الموعد|اوقف الموعد|عطّل الموعد|عطل الموعد|فعّل الموعد|فعل الموعد|احذف الموعد|حذف الموعد)\s+(.+)$/iu), query=norm(m?.[1]||''), s=this.session(id);
      const hits=(s.automation.tasks||[]).filter(t=>norm(t.id)===query||norm(t.name)===query||norm(t.name).includes(query));
      if(hits.length!==1) throw new Error(hits.length?'اسم الموعد غير فريد؛ استخدم ID من «اعرض المواعيد».':'لم أجد الموعد. اكتب «اعرض المواعيد».');
      const t=hits[0];
      if (/^احذف|^حذف/.test(text)) s.automation.tasks=s.automation.tasks.filter(x=>x.id!==t.id);
      else { const enable=/^فعّل|^فعل/.test(text); if(enable&&t.mode==='once'){const planned=require('./scheduler').zonedDateToUtc(t.date,t.time,s.settings.timezone);if(!planned||planned.getTime()<Date.now()-Number(t.graceMinutes||30)*60000)throw new Error('هذا الموعد انتهى؛ أنشئ موعدًا جديدًا أو حدّثه من اللوحة.');} t.enabled=enable;t.updatedAt=new Date().toISOString(); }
      const deleting=/^احذف|^حذف/.test(text), desired=!deleting&&/^فعّل|^فعل/.test(text), taskId=t.id;
      this.store.saveSession(s); const check=this.session(id).automation.tasks.find(x=>x.id===taskId);
      if(deleting ? Boolean(check) : (!check||check.enabled!==desired))throw new Error('لم يتم التحقق من حفظ تعديل الموعد.');
      return this.reply(`✅ تم ${deleting?'حذف':desired?'تفعيل':'إيقاف'} الموعد «${t.name}» فعليًا.`, 'manage-schedule');
    }
    if (/^أرسل الآن|^ارسل الان|^أرسل رسالة|^ارسل رسالة/iu.test(text)) {
      const f=parseFields(text), message=f.text || '', targetKeys=this.targetKeys(id,f.to,{allowAll:true,requireConfirm:true,confirm:f.confirm||''}), files=this.delivery.files(id), fileIds=[];
      for(const rawName of String(f.file||f.files||'').split(/[,،;؛]/).map(x=>x.trim()).filter(Boolean)) { const found=files.filter(x=>norm(x.id)===norm(rawName)||norm(x.filename)===norm(rawName)||norm(x.filename).includes(norm(rawName))); if(found.length!==1)throw new Error(`الملف «${rawName}» غير موجود أو غير فريد؛ اكتب الاسم الكامل.`); fileIds.push(found[0].id); }
      if(!message&&!fileIds.length) throw new Error('حدد الرسالة=... أو ملف=اسم_الملف.');
      if(targetKeys.length>1 && norm(f.to)!=='الكل' && norm(f.to)!=='all') { /* explicit multi-target names are allowed */ }
      if(targetKeys.length>1 && ['الكل','all','الجميع','كل المستلمين'].includes(norm(f.to)) && norm(f.confirm)!=='نعم') throw new Error('لمنع الإرسال العرضي، أضف «تأكيد=نعم» عند الإرسال للجميع.');
      const result=await this.delivery.sendNow(id,{targetKeys,mediaIds:fileIds,text:message,textMode:'auto',captionMode:true,repeatGuard:true,sendDelayMs:this.session(id).settings.sendDelayMs});
      const verified=Array.isArray(result.sent)?result.sent.length:0, failed=Array.isArray(result.failed)?result.failed.length:0;
      if(failed || result.ok===false) { const names=(result.failed||[]).slice(0,5).map(x=>`${x.target||'هدف'}: ${x.error||'خطأ'}`).join('\n'); return this.reply(`${verified?`⚠️ اكتمل الإرسال جزئيًا: نجح ${verified} وفشل ${failed}.`:'❌ فشل الإرسال.'}\n${names||result.error||'لم يؤكد محرك الإرسال نجاح كل العمليات.'}\nراجع سجل النتائج قبل إعادة المحاولة.`, 'send-result'); }
      return this.reply(`✅ أكد محرك الإرسال نجاح ${verified} عملية.\nالمستلمون: ${targetKeys.length}\nالملفات: ${fileIds.length}\n${message?'تم تضمين الرسالة.':''}`, 'send-result');
    }
    if (/^(?:غيّر اسم المستلم|غير اسم المستلم|عدّل اسم المستلم|عدل اسم المستلم)\s+/iu.test(text)) {
      const m = text.match(/^(?:غيّر اسم المستلم|غير اسم المستلم|عدّل اسم المستلم|عدل اسم المستلم)\s+(.+?)\s+(?:إلى|الى|لـ|ل)\s+(.+)$/iu);
      if (!m) throw new Error('الصيغة: غيّر اسم المستلم أحمد إلى أحمد الجديد.');
      const s=this.session(id), from=norm(m[1]), to=clean(m[2],80); if(!to) throw new Error('الاسم الجديد فارغ.');
      const hits=s.recipients.filter(r=>norm(r.name)===from || String(r.digits||r.phone||r.e164||'').replace(/\D/g,'')===m[1].replace(/\D/g,''));
      if(hits.length!==1) throw new Error(hits.length?'الاسم غير فريد؛ استخدم رقم الهاتف.':'لم أجد المستلم القديم.');
      hits[0].name=to; this.store.saveSession(s); const checked=this.session(id).recipients.find(r=>r.id===hits[0].id);
      if(!checked||checked.name!==to) throw new Error('لم يتم التحقق من حفظ الاسم الجديد.');
      return this.reply(`✅ تم تغيير اسم المستلم وحفظه: ${to} (${checked.international||checked.e164||checked.digits}).`, 'rename-recipient');
    }
    if (/^(?:احذف المستلم|حذف المستلم|احذف الرقم|حذف الرقم|أزل المستلم|ازل المستلم)\s+/iu.test(text)) {
      const rawQuery=text.replace(/^(?:احذف المستلم|حذف المستلم|احذف الرقم|حذف الرقم|أزل المستلم|ازل المستلم)\s+/iu,''), query=norm(rawQuery),s=this.session(id),digits=normalizedPhoneDigits(rawQuery);
      const hits=s.recipients.filter(r=>norm(r.name)===query||(digits.length>=6&&[r.digits,r.phone,r.e164].some(v=>String(v||'').replace(/\D/g,'')===digits))); if(hits.length!==1)throw new Error(hits.length?'الاسم غير فريد؛ استخدم رقم الهاتف.':'لم أجد المستلم.');
      const target=hits[0];s.recipients=s.recipients.filter(r=>r.id!==target.id);const key=`r:${target.id}`;s.settings.scheduleTargetKeys=(s.settings.scheduleTargetKeys||[]).filter(x=>x!==key);s.automation.tasks=(s.automation.tasks||[]).map(t=>({...t,targetKeys:(t.targetKeys||[]).filter(x=>x!==key)})).filter(t=>(t.targetKeys||[]).length||t.text||t.preText||t.postText||(t.mediaIds||[]).length);this.store.saveSession(s);
      if(this.session(id).recipients.some(r=>r.id===target.id))throw new Error('تعذر التحقق من حذف الرقم.');return this.reply(`✅ حُذف المستلم «${target.name}» من هذه الجلسة وأزيل من قوائم المواعيد.`, 'delete-recipient');
    }
    if (/^(?:فعّل المستلم|فعل المستلم|شغّل المستلم|شغل المستلم|عطّل المستلم|عطل المستلم|أوقف المستلم|اوقف المستلم)\s+/iu.test(text)) {
      const m=text.match(/^(?:فعّل المستلم|فعل المستلم|شغّل المستلم|شغل المستلم|عطّل المستلم|عطل المستلم|أوقف المستلم|اوقف المستلم)\s+(.+)$/iu),rawQ=m?.[1]||'',q=norm(rawQ),digits=normalizedPhoneDigits(rawQ),s=this.session(id),hits=s.recipients.filter(r=>norm(r.name)===q||(digits&&[r.digits,r.phone,r.e164].some(v=>String(v||'').replace(/\D/g,'')===digits)));if(hits.length!==1)throw new Error(hits.length?'الاسم غير فريد؛ استخدم رقم الهاتف.':'لم أجد المستلم.');const on=/^(?:فعّل|فعل|شغّل|شغل)/iu.test(text);hits[0].enabled=on;this.store.saveSession(s);return this.reply(`✅ ${on?'تم تفعيل':'تم إيقاف'} المستلم «${hits[0].name}» وحُفظ التغيير.`, 'toggle-recipient');
    }
    if (/^(?:غيّر اسم المجموعة|غير اسم المجموعة|عدّل اسم المجموعة|عدل اسم المجموعة)\s+.+\s+(?:إلى|الى)\s+.+$/iu.test(text)) {
      const m=text.match(/^(?:غيّر اسم المجموعة|غير اسم المجموعة|عدّل اسم المجموعة|عدل اسم المجموعة)\s+(.+?)\s+(?:إلى|الى)\s+(.+)$/iu);
      const from=norm(m?.[1]||''), to=clean(m?.[2]||'',120), s=this.session(id);
      if(!to)throw new Error('اكتب الاسم المحلي الجديد للمجموعة.');
      const hits=s.groups.filter(g=>norm(g.name)===from||String(g.gid||'').toLowerCase()===String(m?.[1]||'').toLowerCase());
      if(hits.length!==1)throw new Error(hits.length?'اسم المجموعة غير فريد؛ استخدم GID.':'لم أجد المجموعة القديمة.');
      if (s.groups.some(g => g.id !== hits[0].id && norm(g.name) === norm(to))) throw new Error(`الاسم «${to}» مستخدم بالفعل لمجموعة أخرى؛ اختر اسمًا فريدًا لتجنب الالتباس.`);
      const old=hits[0].name; hits[0].name=to; hits[0].updatedAt=new Date().toISOString(); this.store.saveSession(s);
      const verified=this.session(id).groups.find(g=>g.id===hits[0].id);
      if(!verified||verified.name!==to)throw new Error('لم يتم التحقق من حفظ الاسم المحلي الجديد.');
      return this.reply(`✅ تم تحديث الاسم داخل chat BOT فقط: «${old}» ← «${to}». لم أغيّر اسم مجموعة WhatsApp نفسها.\nGID: ${verified.gid}`, 'rename-group-local');
    }
    if (/^(?:احذف المجموعة|حذف المجموعة|أوقف المجموعة|اوقف المجموعة|عطّل المجموعة|عطل المجموعة|فعّل المجموعة|فعل المجموعة)\s+/iu.test(text)) {
      const m=text.match(/^(?:احذف المجموعة|حذف المجموعة|أوقف المجموعة|اوقف المجموعة|عطّل المجموعة|عطل المجموعة|فعّل المجموعة|فعل المجموعة)\s+(.+)$/iu),q=norm(m?.[1]||''),s=this.session(id),hits=s.groups.filter(g=>norm(g.name)===q||String(g.gid||'').toLowerCase()===String(m?.[1]||'').toLowerCase());if(hits.length!==1)throw new Error(hits.length?'اسم المجموعة غير فريد؛ استخدم GID.':'لم أجد المجموعة.');const g=hits[0];
      const deleting=/^(?:احذف|حذف)/.test(text), oldId=g.id, oldName=g.name;
      if (deleting){s.groups=s.groups.filter(x=>x.id!==g.id);const key=`g:${g.id}`;s.settings.scheduleTargetKeys=(s.settings.scheduleTargetKeys||[]).filter(x=>x!==key);s.automation.tasks=(s.automation.tasks||[]).map(t=>({...t,targetKeys:(t.targetKeys||[]).filter(x=>x!==key)})).filter(t=>(t.targetKeys||[]).length||t.text||t.preText||t.postText||(t.mediaIds||[]).length);}else g.enabled=/^(?:فعّل|فعل)/iu.test(text);
      const desired=!deleting&&g.enabled;
      this.store.saveSession(s);const check=this.session(id).groups.find(x=>x.id===oldId);
      if(deleting?Boolean(check):(!check||check.enabled!==desired))throw new Error('لم يتم التحقق من حفظ تعديل المجموعة.');
      return this.reply(`✅ تم ${deleting?'حذف':desired?'تفعيل':'إيقاف'} المجموعة «${oldName}» من قائمة الجلسة. لم يُحذف الأصل من WhatsApp.`, 'manage-group');
    }
    if (/^(?:فعّل اختبار التفاعل مع نفسي|فعل اختبار التفاعل مع نفسي|أوقف اختبار التفاعل مع نفسي|اوقف اختبار التفاعل مع نفسي)$/iu.test(text)) { /* handled above but keep explicit alias compatibility */ }
    return { handled:false, response:'لم أنفّذ هذه الرسالة لأنني لم أتعرف عليها كأمر مدعوم. اكتب «مساعدة» لعرض الأوامر وصيغتها.' };
  }
}

module.exports = { LocalCommandEngine, HELP, parseFields, norm, weekdayNumber };
