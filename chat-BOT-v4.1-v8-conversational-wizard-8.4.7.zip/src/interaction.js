"use strict";

function norm(v) { return String(v ?? '').normalize('NFKC').replace(/[ـ]/g,'').replace(/[ًٌٍَُِّْ]/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').trim().toLocaleLowerCase('ar'); }
function minutes(v) {
  const m = String(v ?? '').match(/^(\d{2}):(\d{2})$/); if (!m) return null;
  const h = Number(m[1]), n = Number(m[2]); return h > 23 || n > 59 ? null : h * 60 + n;
}
function quiet(s, now = new Date()) {
  if (!s.interactionQuietEnabled) return false;
  const a = minutes(s.interactionQuietStart), b = minutes(s.interactionQuietEnd); if (a == null || b == null || a === b) return false;
  const p = new Intl.DateTimeFormat('en-GB', { timeZone: s.timezone || 'Asia/Muscat', hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(now);
  const current = Number(p.find(x => x.type === 'hour')?.value || 0) * 60 + Number(p.find(x => x.type === 'minute')?.value || 0);
  return a < b ? current >= a && current < b : current >= a || current < b;
}
function scopeOk(scope, chatId, selected = []) {
  const id = String(chatId || '').toLowerCase(), isGroup = id.endsWith('@g.us');
  if (scope === 'groups') return isGroup;
  if (scope === 'private') return !isGroup;
  if (scope === 'selected') return selected.map(norm).includes(norm(chatId));
  return true;
}
function match(rule, event, text, emoji) {
  const input = norm(event === 'reaction' ? emoji : text), value = norm(rule.when?.value);
  switch (rule.when?.match) {
    case 'any': return Boolean(input);
    case 'exact': return Boolean(value) && input === value;
    case 'contains': return Boolean(value) && input.includes(value);
    case 'starts': return Boolean(value) && input.startsWith(value);
    case 'ends': return Boolean(value) && input.endsWith(value);
    case 'regex': try { return new RegExp(rule.when.value, rule.when.ignoreCase === false ? 'u' : 'iu').test(event === 'reaction' ? emoji : text); } catch { return false; }
    default: return false;
  }
}
function render(text, ctx, tz = 'Asia/Muscat') {
  const time = new Intl.DateTimeFormat('ar-OM', { timeZone: tz, hour: '2-digit', minute: '2-digit' }).format(new Date());
  return String(text || '').replace(/\{\{message\}\}/gi, ctx.message || '').replace(/\{\{sender\}\}/gi, ctx.sender || 'صديق').replace(/\{\{chat\}\}/gi, ctx.chat || '').replace(/\{\{time\}\}/gi, time).replace(/\{\{type\}\}/gi, ctx.type || '').replace(/\{\{emoji\}\}/gi, ctx.emoji || '').trim();
}
function valid(rule) {
  if (!['message', 'reaction'].includes(rule.when?.type)) throw new Error('نوع الحدث غير مدعوم.');
  if (!['any', 'contains', 'exact', 'starts', 'ends', 'regex'].includes(rule.when?.match)) throw new Error('نوع المطابقة غير مدعوم.');
  if (rule.when.match !== 'any' && !String(rule.when.value || '').trim()) throw new Error('اكتب قيمة المطابقة.');
  if (rule.when.match === 'regex') new RegExp(rule.when.value);
  if (!['all', 'groups', 'private', 'selected'].includes(rule.scope || 'all')) throw new Error('نطاق غير مدعوم.');
  if (!rule.then?.reply && !rule.then?.reaction) throw new Error('اختر ردًا أو Reaction.');
}

class InteractionEngine {
  constructor({ store, whatsapp, log }) { this.store = store; this.whatsapp = whatsapp; this.log = log; this.seen = new Map(); this.cool = new Map(); this.rate = new Map(); this.inFlight = new Set(); }
  rateOk(key, limit) {
    const now = Date.now(); let bucket = this.rate.get(key);
    if (!bucket || now - bucket.start >= 60000) { bucket = { start: now, count: 0 }; this.rate.set(key, bucket); }
    if (bucket.count >= limit) return false; bucket.count++; return true;
  }
  async onMessage(id, msg) { return this.handle(id, 'message', msg); }
  async onReaction(id, reaction) { if (reaction?.fromMe) return; return this.handle(id, 'reaction', reaction); }

  async chatContext(raw, event) {
    let chat = null;
    try { if (typeof raw?.getChat === 'function') chat = await raw.getChat(); } catch {}
    const serialized = value => {
      if (!value) return '';
      if (typeof value === 'string') return value;
      return String(value._serialized || value.$1 || value.remote?._serialized || value.remote?.$1 || '');
    };
    const candidates = event === 'message'
      ? [chat?.id, raw?.from, raw?.chatId, raw?.to, raw?.id?.remote, raw?._data?.id?.remote]
      : [chat?.id, raw?.chatId, raw?.msgId?.remote, raw?.messageId?.remote, raw?.id?.remote];
    const chatId = candidates.map(serialized).find(x => x) || '';
    return { chat, chatId: chatId.toLowerCase() };
  }

  async handle(id, event, raw) {
    const s = this.store.loadSession(id);
    if (!s.settings.interactionEnabled || !s.interaction.enabled || quiet(s.settings)) return;
    if (event === 'message' && raw?.fromMe && s.settings.interactionIgnoreOwn !== false) return;
    const { chat, chatId } = await this.chatContext(raw, event);
    if (!chatId || !scopeOk(s.settings.interactionScope || 'all', chatId, s.settings.interactionChatIds || [])) return;

    const text = event === 'message' ? String(raw?.body || '') : '';
    if (event === 'message' && raw?.fromMe && !s.settings.interactionIgnoreOwn) {
      const bodyKey = text.slice(0, 120);
      if (bodyKey && /^(وعليكم السلام|أهلًا|الأوامر:)/u.test(bodyKey)) return;
    }
    const emoji = event === 'reaction' ? String(raw?.reaction || raw?.emoji || raw?.value || '') : '';
    const stable = String(raw?.id?._serialized || raw?.id?.$1 || raw?.msgId?._serialized || raw?.msgId?.$1 || raw?.messageId?._serialized || raw?.messageId?.$1 || raw?.id || raw?.timestamp || `${chatId}|${text}|${emoji}`);
    const seenKey = `${event}|${chatId}|${stable}|${text}|${emoji}`;
    if (this.seen.has(seenKey)) return;
    this.seen.set(seenKey, Date.now());
    if (this.seen.size > 5000) for (const [k, t] of this.seen) if (Date.now() - t > 600000) this.seen.delete(k);

    const rules = [...s.interaction.rules].filter(r => r.enabled !== false).sort((a, b) => (b.priority || 0) - (a.priority || 0));
    for (const rule of rules) {
      if (!scopeOk(rule.scope || 'all', chatId, rule.chatIds || [])) continue;
      if (!match(rule, event, text, emoji)) continue;
      try { valid(rule); } catch (e) { this.record(id, event, rule, 'error', chatId, text, emoji, e); continue; }
      const actionKey = `${id}|${rule.id}|${chatId}`;
      if (this.inFlight.has(actionKey)) continue;
      const cooldown = Math.min(Number(rule.cooldownSec) || 0, Number(s.settings.interactionCooldownCapSec) || 86400);
      if (Date.now() - (this.cool.get(actionKey) || 0) < cooldown * 1000) continue;
      if (!this.rateOk(`${id}|${chatId}`, Number(s.settings.maxActionsPerMinute) || 20)) return;
      this.inFlight.add(actionKey);
      try {
        const ctx = {
          message: text,
          sender: String(raw?.notifyName || raw?._data?.notifyName || raw?.author || chat?.name || 'صديق'),
          chat: chatId,
          type: event,
          emoji,
        };
        const reply = render(rule.then.reply, ctx, s.settings.timezone);
        if (reply) {
          if (event === 'message') await this.whatsapp.replyToMessage(id, raw, reply);
          else await this.whatsapp.sendText(id, chatId, reply);
        }
        if (rule.then.reaction) {
          const messageId = raw?.id || raw?.msgId || raw?.messageId;
          if (messageId) await this.whatsapp.reactToMessage(id, messageId, rule.then.reaction);
        }
        this.cool.set(actionKey, Date.now());
        this.record(id, event, rule, 'success', chatId, text, emoji);
      } catch (e) {
        this.record(id, event, rule, e.code === 'SEND_UNCERTAIN' ? 'uncertain' : 'error', chatId, text, emoji, e);
        this.log(id, 'ERROR', `فشل التفاعل ${rule.name}: ${e.message}`);
      } finally { this.inFlight.delete(actionKey); }
      if (rule.then.stopAfter !== false) break;
    }
  }
  record(id, event, rule, status, chatId, text, emoji, error) {
    const s = this.store.loadSession(id);
    s.interaction.recent = [...s.interaction.recent, { at: new Date().toISOString(), ruleName: rule.name || rule.id, event, ruleId: rule.id, status, chatId, text: String(text || '').slice(0, 250), emoji, detail: error ? String(error.message || error) : undefined }].slice(-200);
    status === 'success' ? s.stats.interactionActions++ : s.stats.interactionErrors++;
    this.store.saveSession(s);
    if (status === 'success') this.log(id, 'INFO', `تفاعل: ${rule.name || rule.id} → ${chatId}`);
  }
}
module.exports = { InteractionEngine, match, valid, quiet, scopeOk, render };
