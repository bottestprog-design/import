"use strict";
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const BAD_LINE = /(^|\r?\n)\s*(?:if\s*\(message\s*&&\s*message\.__x_id\)\s*delete\s+message\.__x_id\s*;?|message\.__x_id\s*=.*?;)(?=\r?\n|$)/g;
const MARKERS = /(^|\r?\n)\s*\/\*\s*CHAT_BOT_[^*]*COMPAT[^*]*\*\/\s*/g;

function syntaxOk(source, filename) {
  try { new vm.Script(String(source), { filename }); return true; }
  catch { return false; }
}

function patchUtilsText(source) {
  let out = String(source);
  const before = out;
  let mediaFixInserted = false;
  // Remove malformed legacy injections, but preserve the valid explicit deletion below.
  out = out.replace(BAD_LINE, '\n').replace(MARKERS, '\n');

  // Safe compatibility fallbacks for message IDs used by newer WhatsApp Web builds.
  const replacements = [
    ['window.Store.Msg.get(newMsgKey._serialized)', 'window.Store.Msg.get(newMsgKey._serialized || newMsgKey.$1)'],
    ['window.Store.Msg.get(msg.id._serialized)', 'window.Store.Msg.get(msg.id._serialized || msg.id.$1)'],
    ['window.Store.Msg.get(chat.lastReceivedKey._serialized)', 'window.Store.Msg.get(chat.lastReceivedKey._serialized || chat.lastReceivedKey.$1)'],
    ['window.Store.Msg.getMessagesById([chat.lastReceivedKey._serialized])', 'window.Store.Msg.getMessagesById([chat.lastReceivedKey._serialized || chat.lastReceivedKey.$1])'],
    ['window.Store.WidFactory.createWid(chat.id._serialized)', 'window.Store.WidFactory.createWid(chat.id._serialized || chat.id.$1)'],
    ["window.require('WAWebCollections').Msg.get(newMsgKey._serialized)", "window.require('WAWebCollections').Msg.get(newMsgKey._serialized || newMsgKey.$1)"],
  ];
  for (const [from, to] of replacements) out = out.replaceAll(from, to);

  // whatsapp-web.js 1.34.7 can spread MediaData.__x_id into the outgoing Msg
  // model. That shadows the real MsgKey id and causes WhatsApp Web to throw
  // “Data passed to getter must include an id property” for every media type.
  // Patch only inside WWebJS.sendMessage, immediately after its outgoing
  // message object is assembled. Be strict: if this known package layout has
  // changed and the fix cannot be proven, do not report a successful patch.
  const sendStart = out.indexOf('window.WWebJS.sendMessage = async');
  if (sendStart >= 0) {
    const fnEndCandidates = [
      out.indexOf('window.WWebJS.editMessage = async', sendStart),
      out.indexOf('window.WWebJS.sendSeen = async', sendStart),
    ].filter(i => i >= 0);
    const fnEnd = fnEndCandidates.length ? Math.min(...fnEndCandidates) : out.length;
    const sendFn = out.slice(sendStart, fnEnd);
    const messageStartRel = sendFn.indexOf('const message = {');
    if (messageStartRel >= 0) {
      const msgStart = sendStart + messageStartRel;
      const knownComment = "// Bot's won't reply if canonicalUrl is set (linking)";
      const commentAt = out.indexOf(knownComment, msgStart);
      let alreadyFixed = false;
      if (commentAt >= 0 && commentAt < fnEnd) {
        const messageToComment = out.slice(msgStart, commentAt);
        const closeAtRel = messageToComment.lastIndexOf('};');
        if (closeAtRel >= 0) {
          const closeAt = msgStart + closeAtRel;
          const afterClose = out.slice(closeAt + 2, commentAt);
          if (/\bdelete\s+message\.__x_id\s*;/.test(afterClose)) {
            alreadyFixed = true;
          } else if (!afterClose.trim()) {
            const lineStart = out.lastIndexOf('\n', commentAt) + 1;
            const indent = (out.slice(lineStart, commentAt).match(/^[ \t]*/) || ['        '])[0];
            const newline = out.includes('\r\n') ? '\r\n' : '\n';
            out = out.slice(0, lineStart) + indent + 'delete message.__x_id;' + newline + out.slice(lineStart);
            mediaFixInserted = true;
            alreadyFixed = true;
          }
        }
      }
      // Accept library releases that fix the collision before constructing the
      // Msg object (instead of relying on the insertion point above).
      const fixedPrefix = out.slice(sendStart, msgStart);
      const fixedMessage = out.slice(msgStart, Math.min(fnEnd, msgStart + 7000));
      if (!alreadyFixed && (/delete\s+mediaOptions\.__x_id\s*;/.test(fixedPrefix) || /delete\s+message\.__x_id\s*;/.test(fixedMessage) || /__x_id\s*,\s*\.\.\.\w+/.test(fixedMessage))) {
        alreadyFixed = true;
      }
      if (!alreadyFixed) {
        return { text: before, changed: [], ok: false, note: 'تعذر تطبيق إصلاح تعارض MediaData.__x_id داخل WWebJS.sendMessage؛ لم يتم اعتبار المكتبة سليمة أو الكتابة فوقها.' };
      }
    } else if (!/delete\s+mediaOptions\.__x_id\s*;/.test(sendFn)) {
      return { text: before, changed: [], ok: false, note: 'لم يُعثر على كائن الرسالة داخل WWebJS.sendMessage؛ نسخة whatsapp-web.js غير متوقعة ولم يتم تعديلها.' };
    }
  }

  if (!syntaxOk(out, 'whatsapp-web.js/src/util/Injected/Utils.js')) {
    return { text: before, changed: [], ok: false, note: 'النص الناتج من إصلاح Utils.js غير صالح نحويًا؛ لم يتم الكتابة على المكتبة.' };
  }
  const changed = out !== before ? ['Utils.js-sanitized'] : [];
  if (mediaFixInserted) changed.push('MediaData.__x_id-send-fix');
  return { text: out, changed, ok: true, note: mediaFixInserted ? 'تم تطبيق إصلاح تعارض MediaData.__x_id والتحقق منه.' : 'Utils.js يحتوي على إصلاح إرسال الوسائط المطلوب.' };
}

function packageRoot() {
  try { return path.dirname(require.resolve('whatsapp-web.js/package.json')); }
  catch { return null; }
}

function patch() {
  const result = { ok: true, changed: [], notes: [], packageVersion: null };
  try {
    const root = packageRoot();
    if (!root) {
      result.notes.push('whatsapp-web.js غير مثبت بعد. سيتم تنفيذ الإصلاح بعد تثبيت الاعتماديات.');
      return result;
    }
    try {
      const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
      result.packageVersion = pkg.version || null;
    } catch {}

    const utils = path.join(root, 'src', 'util', 'Injected', 'Utils.js');
    if (!fs.existsSync(utils)) {
      result.notes.push('Utils.js غير موجود.');
      return result;
    }
    const before = fs.readFileSync(utils, 'utf8');
    const fixed = patchUtilsText(before);
    if (!fixed.ok) {
      result.ok = false;
      result.notes.push(fixed.note || 'تعذر إصلاح Utils.js بأمان.');
      return result;
    }
    if (fixed.text !== before) {
      const tmp = `${utils}.chatbot.tmp`;
      fs.writeFileSync(tmp, fixed.text, 'utf8');
      // Validate the exact bytes before replacing the real library file.
      if (!syntaxOk(fixed.text, utils)) {
        fs.rmSync(tmp, { force: true });
        result.ok = false;
        result.notes.push('فشل فحص الصياغة بعد الإصلاح؛ تم إلغاء الكتابة.');
        return result;
      }
      fs.renameSync(tmp, utils);
      result.changed.push(...fixed.changed);
    }
    const finalText = fs.readFileSync(utils, 'utf8');
    const sendStart = finalText.indexOf('window.WWebJS.sendMessage = async');
    const editStart = finalText.indexOf('window.WWebJS.editMessage = async', sendStart);
    if (sendStart < 0) {
      result.ok = false;
      result.notes.push('لم يُعثر على WWebJS.sendMessage في Utils.js؛ إصدار المكتبة غير متوقع ولم يتم تأكيد إصلاح المرفقات.');
      return result;
    }
    const mediaRegion = finalText.slice(sendStart, editStart >= 0 ? editStart : undefined);
    if (!/delete\s+message\.__x_id\s*;/.test(mediaRegion) && !/delete\s+mediaOptions\.__x_id\s*;/.test(mediaRegion)) {
      result.ok = false;
      result.notes.push('فشل التحقق بعد الكتابة: لا يزال إصلاح MediaData.__x_id غير موجود في مسار الإرسال.');
      return result;
    }
    result.notes.push(fixed.note || (fixed.changed.length ? 'تم تطبيق الإصلاح.' : 'الإصلاح موجود مسبقًا.'));
    return result;
  } catch (e) {
    result.ok = false;
    result.notes.push(e?.message || String(e));
    return result;
  }
}

if (require.main === module) {
  const r = patch();
  console.log(JSON.stringify(r, null, 2));
  if (!r.ok) process.exitCode = 1;
}

module.exports = { patch, patchUtilsText, syntaxOk };
