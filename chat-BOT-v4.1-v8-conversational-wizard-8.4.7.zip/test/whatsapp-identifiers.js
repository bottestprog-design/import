'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require.resolve('../src/whatsapp'), 'utf8');
function extract(name) {
  const re = new RegExp(`function ${name}\\([\\s\\S]*?\\n}`);
  const match = source.match(re);
  assert.ok(match, `Cannot find ${name} in WhatsApp service`);
  return match[0];
}
const context = {};
vm.runInNewContext(`${extract('idSerialized')}\n${extract('chatIdFromMessage')}\nthis.chatIdFromMessage=chatIdFromMessage;`, context);
const chatIdFromMessage = context.chatIdFromMessage;
assert.equal(chatIdFromMessage({ fromMe:true, from:{_serialized:'11111111111@c.us'}, to:{_serialized:'96890000000@c.us'}, id:{remote:{_serialized:'96890000000@c.us'}} }), '96890000000@c.us', 'Outgoing messages must map to the recipient, not the account owner');
assert.equal(chatIdFromMessage({ from:{_serialized:'96890000000@c.us'}, to:{_serialized:'11111111111@c.us'}, id:{remote:{_serialized:'96890000000@c.us'}} }), '96890000000@c.us', 'Incoming messages must map to the sender');
assert.equal(chatIdFromMessage({ fromMe:true, from:'11111111111@c.us', to:'120363123@g.us', id:{remote:'120363123@g.us'} }), '120363123@g.us', 'Outgoing group messages must map to the group');
console.log('whatsapp-identifiers: ok (outgoing recipient, incoming sender, group ACK association)');
