"use strict";

const fs = require('node:fs');
const path = require('node:path');
const express = require('express');
const multer = require('multer');

const store = require('./src/store');
const media = require('./src/media');
const phones = require('./src/phones');
const groups = require('./src/groups');
const backgrounds = require('./src/backgrounds');
const { WhatsAppManager, safeError, groupFromMessage } = require('./src/whatsapp');
const { DeliveryService } = require('./src/delivery');
const { InteractionEngine } = require('./src/interaction');
const { ReliableScheduler, nextRun, due, nextRunForItem, zonedDateToUtc } = require('./src/scheduler');
const { OwnerAssistant } = require('./src/owner-assistant');
const { logFactory, replyError, randomId } = require('./src/serverlib');

const HOST = process.env.HOST || '127.0.0.1';
const PORT = store.toInt(process.env.PORT, 7005, 1, 65535);
const TEMP = path.join(store.DATA_DIR, '_temp');
fs.mkdirSync(TEMP, { recursive: true });

const log = logFactory(store);
const whatsapp = new WhatsAppManager({ store, log });
const delivery = new DeliveryService({ store, whatsapp, log });
const interaction = new InteractionEngine({ store, whatsapp, log });
const scheduler = new ReliableScheduler({ store, run: id => delivery.scheduledRun(id), runTask: (id, task) => delivery.scheduledTaskRun(id, task), log });
const ownerAssistant = new OwnerAssistant({ store, whatsapp, delivery, interaction, groups, phones, saveGroup, normalizeAutomationPayload, log });

function sid(req) {
  return store.safeSessionId(req.body?.sessionId || req.query?.sessionId || store.activeSessionId());
}
function boolValue(value, fallback = false) {
  if (value === undefined || value === null) return fallback;
  if (typeof value === 'boolean') return value;
  const x = String(value).trim().toLowerCase();
  if (['true', '1', 'yes', 'on', 'نعم', 'تشغيل', 'مفعّل'].includes(x)) return true;
  if (['false', '0', 'no', 'off', 'لا', 'إيقاف', 'متوقف'].includes(x)) return false;
  return fallback;
}
function uniqueStrings(values) {
  return [...new Set((Array.isArray(values) ? values : []).map(v => String(v || '').trim()).filter(Boolean))];
}
function validTargetKeys(session, keys) {
  const allowed = new Set([
    ...session.recipients.map(x => `r:${x.id}`),
    ...session.groups.map(x => `g:${x.id}`),
  ]);
  return uniqueStrings(keys).filter(k => allowed.has(k));
}
function normalizeRuleChatIds(chatIds) {
  return uniqueStrings(chatIds).map(v => v.toLowerCase());
}
function validIsoDate(value) {
  const x = String(value || '').trim(), m = x.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return false;
  const y = Number(m[1]), mo = Number(m[2]), d = Number(m[3]);
  if (mo < 1 || mo > 12 || d < 1 || d > 31) return false;
  const dt = new Date(Date.UTC(y, mo - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === mo - 1 && dt.getUTCDate() === d;
}
function saveGroup(id, info) {
  const s = store.loadSession(id);
  const n = store.normalizeGroup(info);
  n.gid = groups.normalizeGid(n.gid);
  if (!groups.isGroupId(n.gid)) throw new Error('GID المجموعة غير صالح.');
  const old = s.groups.find(x => x.gid === n.gid);
  if (old) {
    const enabled = old.enabled;
    const discoveredAt = old.discoveredAt;
    const before = JSON.stringify({ name: old.name, gid: old.gid, inviteCode: old.inviteCode, description: old.description, owner: old.owner, participantsCount: old.participantsCount, participants: old.participants, admins: old.admins, enabled });
    Object.assign(old, n, { enabled, discoveredAt, updatedAt: old.updatedAt || new Date().toISOString() });
    const after = JSON.stringify({ name: old.name, gid: old.gid, inviteCode: old.inviteCode, description: old.description, owner: old.owner, participantsCount: old.participantsCount, participants: old.participants, admins: old.admins, enabled });
    if (before !== after) { old.updatedAt = new Date().toISOString(); store.saveSession(s); log(id, 'INFO', `تم تحديث بيانات المجموعة: ${old.name || old.gid}`); }
    return old;
  }
  s.groups.push(n);
  s.setupComplete = true;
  store.saveSession(s);
  log(id, 'INFO', `تم ربط مجموعة جديدة: ${n.name || n.gid}`);
  return n;
}
function removeTargetFromSchedule(s, key) {
  s.settings.scheduleTargetKeys = (s.settings.scheduleTargetKeys || []).filter(x => x !== key);
}
function snapshot(id) {
  const s = store.loadSession(id);
  const scan = media.scan(store.getPaths(id).media, s.settings.maxImageSizeMB);
  return {
    version: store.APP_VERSION,
    session: { id: s.id, name: s.name, setupComplete: s.setupComplete },
    ownerAssistant: { ...s.ownerAssistant, messages: (s.ownerAssistant?.messages || []).slice(-100), issues: (s.ownerAssistant?.issues || []).slice(-80), activity: (s.ownerAssistant?.activity || []).slice(-150) },
    media: scan.files.map(x => ({ ...x, url: `/media/${encodeURIComponent(x.filename)}?sessionId=${encodeURIComponent(id)}` })),
    activeSessionId: store.activeSessionId(),
    sessions: store.listSessionIds().map(x => {
      const ss = store.loadSession(x);
      const runtime = whatsapp.listRuntime(x);
      const summary = media.quickSummary(store.getPaths(x).media);
      return { id: ss.id, name: ss.name, status: runtime.status, ready: runtime.ready, recipients: ss.recipients.filter(y => y.enabled !== false).length, groups: ss.groups.filter(y => y.enabled !== false).length, images: summary.images, files: summary.files };
    }),
    recipients: s.recipients,
    groups: s.groups,
    images: scan.images.map(x => ({ ...x, url: `/media/${encodeURIComponent(x.filename)}?sessionId=${encodeURIComponent(id)}` })),
    invalidImages: scan.invalid,
    duplicates: scan.duplicates,
    currentImage: delivery.currentImage(id),
    cycle: s.cycle,
    settings: s.settings,
    interaction: s.interaction,
    whatsapp: whatsapp.listRuntime(id),
    schedule: { ...due(new Date(), s), nextRun: nextRun(s) },
    automation: { enabled: s.automation.enabled !== false, tasks: (s.automation.tasks || []).map(t => ({ ...t, nextRun: nextRunForItem({ ...t, timezone: s.settings.timezone }) })), recent: s.automation.recent || [] },
    background: {
      mode: s.settings.backgroundMode,
      imageName: s.settings.backgroundImage,
      imageUrl: s.settings.backgroundImage ? `/background/${encodeURIComponent(s.settings.backgroundImage)}?sessionId=${encodeURIComponent(id)}&v=${encodeURIComponent(s.updatedAt)}` : null,
      opacity: s.settings.backgroundOpacity,
      settings: s.settings.backgroundSettings,
    },
    stats: s.stats,
    lastRun: s.lastRun,
    logs: s.logs.slice(-60).reverse(),
  };
}

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '6mb' }));
app.use(express.urlencoded({ extended: true, limit: '6mb' }));
app.use(express.static(path.join(store.ROOT, 'public')));

// Asset URLs can be stale after deleting a session; return 404 instead of recreating its data folder.
app.use(['/media', '/background'], (req, res, next) => {
  const requested = req.query?.sessionId;
  const id = store.safeSessionId(requested || store.activeSessionId());
  if (!store.listSessionIds().includes(id)) return res.status(404).end();
  next();
});

// Do not silently recreate a deleted session when a stale tab sends its old sessionId.
app.use('/api', (req, res, next) => {
  const pathname = req.path || '';
  if ((req.method === 'GET' && ['/health', '/countries'].includes(pathname)) || (req.method === 'POST' && pathname === '/sessions')) return next();
  const explicit = req.body?.sessionId || req.query?.sessionId;
  const contextId = explicit ? store.safeSessionId(explicit) : store.activeSessionId();
  const match = pathname === '/sessions/switch' ? null : pathname.match(/^\/sessions\/([^/]+)$/);
  const routeId = match ? decodeURIComponent(match[1]) : '';
  const ids = store.listSessionIds();
  if (!ids.includes(contextId) || (routeId && !ids.includes(store.safeSessionId(routeId)))) {
    return res.status(404).json({ ok: false, error: 'الجلسة المحددة غير موجودة أو حُذفت. حدّث القائمة واختر جلسة صالحة؛ لن يعاد إنشاء الجلسة المحذوفة تلقائيًا.' });
  }
  next();
});

// Convert API failures into a persistent, actionable issue in the current session's private assistant center.
app.use('/api', (req, res, next) => {
  const apiRoute = `/api${req.path}`;
  const sendJson = res.json.bind(res);
  res.json = body => {
    const failed = res.statusCode >= 400 || body?.ok === false;
    if (failed && !req.path.startsWith('/assistant/')) {
      const explicit = req.body?.sessionId || req.query?.sessionId;
      const id = store.safeSessionId(explicit || store.activeSessionId());
      if (store.listSessionIds().includes(id)) {
        const detail = body?.error || body?.message || `HTTP ${res.statusCode}`;
        queueMicrotask(() => ownerAssistant.recordIssue(id, { code: body?.code || `${req.method}_${res.statusCode}`, route: apiRoute, error: detail, status: res.statusCode }).catch(() => {}));
      }
    }
    return sendJson(body);
  };
  next();
});

app.get('/api/health', (_req, res) => res.json({ ok: true, version: store.APP_VERSION, time: new Date().toISOString(), node: process.version }));
app.get('/api/state', (req, res) => { try { res.json({ ok: true, ...snapshot(sid(req)) }); } catch (e) { replyError(res, e, 500); } });
app.get('/api/countries', (_req, res) => { try { res.json({ ok: true, countries: phones.countries() }); } catch (e) { replyError(res, e, 500); } });
app.post('/api/phone/validate', (req, res) => { try { const country = String(req.body?.country || 'OM').toUpperCase(); const phone = phones.parse(req.body?.phone || '', country); res.json({ ok: true, valid: true, phone }); } catch (e) { res.status(422).json({ ok: false, valid: false, error: safeError(e) }); } });
app.get('/api/assistant/center', (req, res) => { try { const id=sid(req), s=store.loadSession(id); res.json({ ok:true, session:{id:s.id,name:s.name}, ownerAssistant:s.ownerAssistant, diagnostics:ownerAssistant.diagnostics(id), whatsapp:whatsapp.listRuntime(id) }); } catch(e) { replyError(res,e,500); } });
app.post('/api/assistant/activity', (req, res) => { try { const id=sid(req), body=req.body || {}; const message=String(body.message || '').trim(); if (!message) throw new Error('رسالة سجل المساعد فارغة.'); if (message.length > 1200) throw new Error('رسالة سجل المساعد أطول من الحد المسموح.'); const item=ownerAssistant.recordActivity(id,{message,type:body.type,page:body.page,issueId:body.issueId,source:body.source || 'ui'}); res.json({ok:true,activity:item,message:'حُفظت الرسالة في سجل المساعد.'}); } catch(e) { replyError(res,e,422); } });
app.post('/api/assistant/config', (req, res) => { try { const result=ownerAssistant.saveConfig(sid(req), req.body || {}); res.json({ok:true, ownerAssistant:result.ownerAssistant, message:'تم حفظ إعدادات مركز المساعد لهذه الجلسة.'}); } catch(e) { replyError(res,e,422); } });
app.post('/api/assistant/diagnostics', async (req, res) => { try { const id=sid(req), diagnostics=await ownerAssistant.runDiagnostics(id,{persist:true}); res.json({ok:true, diagnostics, ownerAssistant:store.loadSession(id).ownerAssistant, message:'اكتمل فحص الجلسة وحفظت المشكلات التي تحتاج متابعة.'}); } catch(e) { replyError(res,e,500); } });
app.post('/api/assistant/test-notification', async (req, res) => { try { const result=await ownerAssistant.testNotification(sid(req)); res.json(result); } catch(e) { replyError(res,e,422); } });
app.post('/api/assistant/issues/:id/resolve', async (req, res) => { try { const issue=await ownerAssistant.resolveIssue(sid(req), req.params.id); res.json({ok:true,issue,message:'تم تعليم المشكلة كمحلولة.'}); } catch(e) { replyError(res,e,404); } });
app.post('/api/assistant/chat', async (req, res) => { try {
  const id = sid(req), text = String(req.body?.text || '').trim();
  if (!text) throw new Error('اكتب سؤالك أو الأمر أولًا.');
  if (text.length > 1000) throw new Error('الرسالة أطول من الحد المسموح (1000 حرف).');
  const s = store.loadSession(id);
  ownerAssistant.addMessage(s, 'user', text, { page:'owner-center', kind:'local-chat' }); store.saveSession(s);
  const result = await ownerAssistant.executeCommand(id, text, { source:'local-chat' });
  const fresh = store.loadSession(id);
  ownerAssistant.addMessage(fresh, 'assistant', result.response, { page:'owner-center', kind:result.ok === false ? 'local-command-error' : 'local-chat-reply' }); store.saveSession(fresh);
  res.json({ ok:true, response:result.response, action:result.action || 'unknown', commandOk:result.ok === true, executed:result.executed === true, ownerAssistant:fresh.ownerAssistant });
} catch(e) { replyError(res,e,422); } });

app.get('/api/diagnostics', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), p = store.getPaths(id), scan = media.scan(p.media, s.settings.maxImageSizeMB), runtime = whatsapp.listRuntime(id);
    res.json({ ok: true, version: store.APP_VERSION, checks: {
      session: true, mediaFolder: fs.existsSync(p.media), authFolder: fs.existsSync(p.auth), mediaCount: scan.files.length,
      groups: s.groups.length, recipients: s.recipients.length, interactionRules: s.interaction.rules.length, whatsapp: !!runtime.ready,
      scheduleTargets: validTargetKeys(s, s.settings.scheduleTargetKeys).length, compatPatched: true,
    }, runtime, dependency: 'whatsapp-web.js 1.34.7' });
  } catch (e) { replyError(res, e, 500); }
});

const upload = multer({ dest: TEMP, limits: { files: 100, fileSize: 50 * 1024 * 1024 } });
const bgUpload = multer({ dest: TEMP, limits: { fileSize: 15 * 1024 * 1024, files: 1 } });

app.post('/api/sessions', (req, res) => { try { const s = store.createSession(req.body?.name); res.json({ ok: true, session: { id: s.id, name: s.name }, activeSessionId: store.activeSessionId(), sessions: store.listSessionIds() }); } catch (e) { replyError(res, e); } });
app.post('/api/sessions/switch', async (req, res) => {
  try {
    const target = store.safeSessionId(req.body?.sessionId);
    if (!store.listSessionIds().includes(target)) throw new Error('الجلسة غير موجودة.');
    const s = store.setActiveSession(target);
    if (s.settings.autoStartSession && whatsapp.hasSavedAuth(target) && !whatsapp.listRuntime(target).ready) whatsapp.start(target).catch(err => log(target, 'WARN', `تعذر تشغيل الجلسة عند التبديل: ${safeError(err)}`));
    res.json({ ok: true, session: s.id });
  } catch (e) { replyError(res, e); }
});
app.put('/api/sessions/:id', (req, res) => { try { res.json({ ok: true, session: store.renameSession(req.params.id, req.body?.name) }); } catch (e) { replyError(res, e); } });
app.delete('/api/sessions/:id', async (req, res) => { try { const deleting = store.safeSessionId(req.params.id); if (!store.listSessionIds().includes(deleting)) throw new Error('الجلسة غير موجودة أو حُذفت بالفعل.'); await whatsapp.stop(deleting, { clearAuth: true }); res.json({ ok: true, ...store.deleteSession(deleting) }); } catch (e) { replyError(res, e); } });

app.post('/api/session/connect', async (req, res) => { try { const runtime = await whatsapp.start(sid(req)); res.json({ ok: true, runtime, message: runtime.ready ? 'الجلسة جاهزة.' : 'تم بدء الاتصال؛ امسح QR إذا ظهر.' }); } catch (e) { replyError(res, e); } });
app.post('/api/session/stop', async (req, res) => { try { await whatsapp.stop(sid(req)); res.json({ ok: true }); } catch (e) { replyError(res, e); } });
app.post('/api/session/unlink', async (req, res) => { try { await whatsapp.stop(sid(req), { clearAuth: true }); res.json({ ok: true }); } catch (e) { replyError(res, e); } });

app.post('/api/recipient', (req, res) => {
  try {
    const s = store.loadSession(sid(req));
    const parsed = phones.parse(req.body?.phone, String(req.body?.country || 'OM'));
    const name = String(req.body?.name || '').trim();
    if (!name) throw new Error('اكتب اسم المستلم.');
    if (s.recipients.some(x => x.phone === parsed.digits || x.e164 === parsed.e164)) throw new Error('الرقم مكرر في الجلسة.');
    const recipient = { id: randomId(), name: name.slice(0, 80), ...parsed, enabled: true };
    s.recipients.push(recipient); s.setupComplete = true;
    store.saveSession(s); res.json({ ok: true, recipient });
  } catch (e) { replyError(res, e); }
});
app.post('/api/recipients/bulk', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), parsed = phones.parseMany(req.body?.lines, String(req.body?.country || 'OM'));
    const added = [];
    for (const item of parsed.out) {
      if (s.recipients.some(x => x.phone === item.digits || x.e164 === item.e164)) continue;
      const { name, ...number } = item;
      added.push({ id: randomId(), name, ...number, enabled: true });
    }
    s.recipients.push(...added); if (added.length) s.setupComplete = true; store.saveSession(s);
    res.json({ ok: true, added, failed: parsed.failed, skippedDuplicates: parsed.out.length - added.length });
  } catch (e) { replyError(res, e); }
});
app.post('/api/recipient/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), r = s.recipients.find(x => x.id === req.params.id); if (!r) throw new Error('المستلم غير موجود.'); r.enabled = !r.enabled; store.saveSession(s); res.json({ ok: true, enabled: r.enabled }); } catch (e) { replyError(res, e); } });
app.delete('/api/recipient/:id', (req, res) => {
  try { const s = store.loadSession(sid(req)), key = `r:${req.params.id}`, before = s.recipients.length; s.recipients = s.recipients.filter(x => x.id !== req.params.id); if (before === s.recipients.length) throw new Error('المستلم غير موجود.'); removeTargetFromSchedule(s, key); s.automation.tasks = (s.automation.tasks || []).map(t => ({ ...t, targetKeys: (t.targetKeys || []).filter(k => k !== key) })); store.saveSession(s); res.json({ ok: true }); }
  catch (e) { replyError(res, e); }
});

app.post('/api/groups/discover', async (req, res) => { try { const id = sid(req), found = await whatsapp.listGroups(id), saved = found.filter(x => x.gid).map(x => saveGroup(id, x)); res.json({ ok: true, found: found.length, saved, message: `تم اكتشاف ${saved.length} مجموعة في هذه الجلسة.` }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/refresh-all', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), saved = [], failed = [];
    for (const g of s.groups) { try { saved.push(saveGroup(id, await whatsapp.getGroupInfo(id, g.gid))); } catch (e) { failed.push({ id: g.id, name: g.name, error: safeError(e) }); } }
    res.json({ ok: true, saved, failed, message: failed.length ? `تم تحديث ${saved.length} مجموعة، وتعذر تحديث ${failed.length}.` : 'تم تحديث المجموعات.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/groups/add-gid', async (req, res) => { try { const id = sid(req), gid = groups.normalizeGid(req.body?.gid); if (!groups.isGroupId(gid)) throw new Error('GID المجموعة غير صالح.'); const info = await whatsapp.getGroupInfo(id, gid); res.json({ ok: true, group: saveGroup(id, info), message: 'تمت إضافة المجموعة إلى هذه الجلسة.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/connect', async (req, res) => {
  try {
    const id = sid(req), value = String(req.body?.value || '').trim();
    if (!value) throw new Error('أدخل GID أو رابط دعوة.');
    let info;
    if (/chat\.whatsapp\.com\//i.test(value)) {
      info = await whatsapp.analyzeGroupInvite(id, groups.extractInviteCode(value));
      if (info?.gid) { try { info = await whatsapp.getGroupInfo(id, groups.normalizeGid(info.gid)); } catch {} }
    } else {
      info = await whatsapp.getGroupInfo(id, groups.normalizeGid(value));
    }
    if (!info?.gid) throw new Error('لم أستطع الحصول على GID للمجموعة من WhatsApp.');
    const group = saveGroup(id, info);
    res.json({ ok: true, group, message: 'تم الربط والتحليل داخل الجلسة الحالية.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/groups/save', (req, res) => { try { const id = sid(req), g = req.body?.group || {}; if (!groups.isGroupId(g.gid)) throw new Error('GID المجموعة غير صالح.'); res.json({ ok: true, group: saveGroup(id, g), message: 'تم حفظ المجموعة داخل الجلسة الحالية.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/add-invite', async (req, res) => {
  try {
    const id = sid(req), code = groups.extractInviteCode(req.body?.url || req.body?.code), info = await whatsapp.analyzeGroupInvite(id, code);
    if (!info.gid) throw new Error('تم تحليل الدعوة لكن WhatsApp لم يعطِ GID لهذه المجموعة؛ افتح المجموعة أو استخدم الاكتشاف من الجلسة ثم أضفها.');
    res.json({ ok: true, group: saveGroup(id, info), message: 'تمت إضافة المجموعة إلى هذه الجلسة.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/groups/analyze-gid', async (req, res) => { try { const id=sid(req), info=await whatsapp.getGroupInfo(id, groups.normalizeGid(req.body?.gid)); res.json({ ok:true, group:saveGroup(id, info), message:'تم تحديث بيانات المجموعة داخل الجلسة.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/analyze-invite', async (req, res) => { try { const id=sid(req), info=await whatsapp.analyzeGroupInvite(id, groups.extractInviteCode(req.body?.url || req.body?.code)); res.json({ ok:true, group: info?.gid ? saveGroup(id, info) : info, message: info?.gid ? 'تم تحديث بيانات المجموعة.' : 'تم تحليل الدعوة؛ لم يوفر WhatsApp GID.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), g = s.groups.find(x => x.id === req.params.id); if (!g) throw new Error('المجموعة غير موجودة.'); g.enabled = !g.enabled; store.saveSession(s); res.json({ ok: true, enabled: g.enabled }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/:id/refresh', async (req, res) => { try { const id = sid(req), s = store.loadSession(id), g = s.groups.find(x => x.id === req.params.id); if (!g) throw new Error('المجموعة غير موجودة.'); res.json({ ok: true, group: saveGroup(id, await whatsapp.getGroupInfo(id, g.gid)) }); } catch (e) { replyError(res, e); } });
app.delete('/api/groups/:id', (req, res) => {
  try { const s = store.loadSession(sid(req)), key = `g:${req.params.id}`, removed = s.groups.find(x => x.id === req.params.id); if (!removed) throw new Error('المجموعة غير موجودة.'); s.groups = s.groups.filter(x => x.id !== req.params.id); removeTargetFromSchedule(s, key); const removedGid = String(removed.gid || '').toLowerCase(); s.settings.interactionChatIds = (s.settings.interactionChatIds || []).filter(x => String(x).toLowerCase() !== removedGid); s.automation.tasks = (s.automation.tasks || []).map(t => ({ ...t, targetKeys: (t.targetKeys || []).filter(k => k !== key) })).filter(t => (t.targetKeys || []).length || (t.preText || t.postText || (t.mediaIds || []).length)); store.saveSession(s); res.json({ ok: true }); }
  catch (e) { replyError(res, e); }
});

app.post('/api/groups/bulk', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), action = String(req.body?.action || ''), ids = [...new Set((Array.isArray(req.body?.ids) ? req.body.ids : []).map(String))].slice(0, 500);
    if (!ids.length) throw new Error('حدد مجموعة واحدة على الأقل.');
    if (!['enable','disable','delete'].includes(action)) throw new Error('الإجراء الجماعي غير صالح.');
    const selected = s.groups.filter(group => ids.includes(group.id));
    if (!selected.length) throw new Error('لم يتم العثور على المجموعات المحددة.');
    if (action === 'enable' || action === 'disable') {
      const enabled = action === 'enable'; selected.forEach(group => { group.enabled = enabled; group.updatedAt = new Date().toISOString(); });
    } else {
      const removedIds = new Set(selected.map(group => group.id)), removedGids = new Set(selected.map(group => String(group.gid || '').toLowerCase()));
      s.groups = s.groups.filter(group => !removedIds.has(group.id));
      s.settings.scheduleTargetKeys = (s.settings.scheduleTargetKeys || []).filter(key => ![...removedIds].some(id => key === `g:${id}`));
      s.settings.interactionChatIds = (s.settings.interactionChatIds || []).filter(value => !removedGids.has(String(value).toLowerCase()));
      s.automation.tasks = (s.automation.tasks || []).map(task => ({ ...task, targetKeys: (task.targetKeys || []).filter(key => ![...removedIds].some(id => key === `g:${id}`)) })).filter(task => (task.targetKeys || []).length || task.preText || task.postText || (task.mediaIds || []).length);
    }
    store.saveSession(s);
    res.json({ ok: true, affected: selected.length, action, message: action === 'enable' ? `تم تفعيل ${selected.length} مجموعة.` : action === 'disable' ? `تم إيقاف ${selected.length} مجموعة.` : `تم حذف ${selected.length} مجموعة من المكتبة المحلية.` });
  } catch (e) { replyError(res, e); }
});

app.post('/api/media', upload.array('files', 100), (req, res) => {
  try {
    const id = sid(req), dir = store.getPaths(id).media, saved = [], duplicates = [], rejected = [];
    const maxFileSizeMB = store.loadSession(id).settings.maxImageSizeMB;
    const maxFileBytes = Number(maxFileSizeMB) * 1024 * 1024;
    const replaceDuplicates = boolValue(req.body?.replaceDuplicates, false);
    const existing = new Map();
    for (const entry of media.scan(dir, store.loadSession(id).settings.maxImageSizeMB).files) {
      try { existing.set(`${entry.size}:${media.hashFile(media.safePath(dir, entry.filename))}`, entry.filename); } catch {}
    }
    for (const file of req.files || []) {
      const ext = path.extname(file.originalname || '').toLowerCase();
      if (Number(file.size) > maxFileBytes) { rejected.push({ filename: file.originalname, error: `حجم الملف يتجاوز الحد الحالي (${maxFileSizeMB} MB).` }); fs.rmSync(file.path, { force: true }); continue; }
      if (!media.MEDIA_EXT.has(ext)) { rejected.push({ filename: file.originalname, error: 'نوع غير مدعوم' }); fs.rmSync(file.path, { force: true }); continue; }
      const hash = media.hashFile(file.path);
      const duplicateName = existing.get(`${fs.statSync(file.path).size}:${hash}`);
      if (duplicateName && !replaceDuplicates) {
        duplicates.push({ incoming: file.originalname, existing: duplicateName }); fs.rmSync(file.path, { force: true }); continue;
      }
      if (duplicateName && replaceDuplicates) {
        fs.renameSync(file.path, media.safePath(dir, duplicateName)); saved.push(duplicateName); continue;
      }
      const name = media.IMAGE_EXT.has(ext) ? media.nextImageName(dir, ext) : media.uniqueFileName(dir, path.basename(file.originalname, path.extname(file.originalname)), ext);
      fs.renameSync(file.path, media.safePath(dir, name));
      existing.set(`${fs.statSync(media.safePath(dir, name)).size}:${media.hashFile(media.safePath(dir, name))}`, name);
      saved.push(name);
    }
    res.json({ ok: true, saved, duplicates, rejected, message: duplicates.length ? `تم رفع ${saved.length} ملف، ووجدت ${duplicates.length} ملفًا مكررًا لم يتم استبداله.` : `تم رفع ${saved.length} ملف.` });
  } catch (e) {
    for (const f of req.files || []) { try { fs.rmSync(f.path, { force: true }); } catch {} }
    replyError(res, e);
  }
});
app.get('/api/media/:filename/preview', (req, res) => {
  try {
    const filename = decodeURIComponent(req.params.filename), ext = path.extname(filename).toLowerCase();
    if (ext !== '.txt') return res.status(415).json({ ok: false, error: 'المعاينة النصية متاحة لملفات TXT فقط.' });
    const full = media.safePath(store.getPaths(sid(req)).media, filename), stat = fs.statSync(full);
    if (!stat.isFile()) throw new Error('الملف غير موجود.');
    const buffer = fs.readFileSync(full).subarray(0, 6000);
    const preview = buffer.toString('utf8').replace(/\u0000/g, '').replace(/[\x01-\x08\x0B\x0C\x0E-\x1F]/g, '').slice(0, 1200);
    res.setHeader('Cache-Control', 'no-store'); res.json({ ok: true, filename, preview, truncated: stat.size > buffer.length });
  } catch (e) { replyError(res, e, 404); }
});

app.delete('/api/media/:filename', (req, res) => { try { const id = sid(req), name = decodeURIComponent(req.params.filename); fs.rmSync(media.safePath(store.getPaths(id).media, name), { force: true }); const s = store.loadSession(id); s.automation.tasks = (s.automation.tasks || []).map(t => ({ ...t, mediaIds: (t.mediaIds || []).filter(x => String(x) !== name) })); if (s.settings.scheduleMediaId === name) s.settings.scheduleMediaId = ''; store.saveSession(s); res.json({ ok: true, message: 'تم حذف الملف.' }); } catch (e) { replyError(res, e); } });
app.get('/media/:filename', (req, res) => { try { res.sendFile(media.safePath(store.getPaths(sid(req)).media, decodeURIComponent(req.params.filename))); } catch { res.status(404).end(); } });

app.post('/api/send', async (req, res) => { try {
  const id = sid(req), result = await delivery.sendNow(id, req.body || {});
  const sent = Array.isArray(result.sent) ? result.sent.length : Number(result.sent || result.success || 0), failed = Array.isArray(result.failed) ? result.failed.length : Number(result.failed || 0);
  if (failed) ownerAssistant.recordIssue(id, { code:'SEND_PARTIAL_FAILURE', route:'/api/send', title:'تعذّر إرسال بعض الرسائل أو المرفقات', error:result.failed.slice(0, 8).map(x => `${x.target || 'هدف غير معروف'}: ${x.error || 'فشل غير محدد'}`).join(' | '), page:'send', steps:['افتح سجل النتيجة واقرأ خطأ كل مستلم.', 'تحقق من اتصال الجلسة الحالية.', 'تحقق من صحة الرقم أو GID وتفعيل الهدف.', 'جرّب إرسال نص إلى مستلم واحد فقط ثم جرّب الملف.', 'لا تضغط إعادة إرسال للجميع قبل مراجعة حالة الرسائل الناجحة لمنع التكرار.'] }).catch(() => {});
  res.json({ ...result, ok: true, complete: failed === 0, message: failed ? `نجح ${sent} إرسال، وتعذر ${failed}.` : `تم إرسال ${sent} عملية بنجاح.` });
} catch (e) { replyError(res, e); } });
app.post('/api/schedule', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), b = req.body || {}, time = String(b.scheduleTime || '17:30'), tm = time.match(/^(\d{2}):(\d{2})$/);
    const mode = ['weekly', 'monthly', 'once'].includes(b.scheduleMode) ? b.scheduleMode : 'weekly';
    if (!tm || Number(tm[1]) > 23 || Number(tm[2]) > 59) throw new Error('وقت الجدولة غير صالح.');
    if (mode === 'once' && !validIsoDate(b.scheduleDate)) throw new Error('أدخل تاريخًا تقويميًا صالحًا للجدولة مرة واحدة.');
    if (mode === 'monthly' && !(Number(b.scheduleMonthDay) >= 1 && Number(b.scheduleMonthDay) <= 31)) throw new Error('اختر يومًا صحيحًا من 1 إلى 31 للجدولة الشهرية.');
    const requestedTargets = Array.isArray(b.scheduleTargetKeys) ? b.scheduleTargetKeys : []; const targetKeys = validTargetKeys(s, requestedTargets.length ? requestedTargets : [...s.recipients.filter(x => x.enabled !== false).map(x => `r:${x.id}`), ...s.groups.filter(x => x.enabled !== false).map(x => `g:${x.id}`)]);
    Object.assign(s.settings, {
      scheduleMode: mode, scheduleTime: time,
      scheduleDay: store.toInt(b.scheduleDay, 5, 0, 6),
      scheduleMonthDay: store.toInt(b.scheduleMonthDay, 1, 1, 31),
      scheduleDate: String(b.scheduleDate || ''), scheduleEnabled: boolValue(b.scheduleEnabled, true),
      scheduledGroupsEnabled: true, scheduleTargetKeys: targetKeys,
      scheduleMediaId: String(b.scheduleMediaId || ''), schedulePreText: String(b.schedulePreText ?? ''), schedulePostText: String(b.schedulePostText ?? ''),
    });
    if (!targetKeys.length) throw new Error('أضف رقمًا أو مجموعة للجدولة.');
    if (s.settings.scheduleMediaId && !media.scan(store.getPaths(s.id).media, s.settings.maxImageSizeMB).files.some(x => x.id === s.settings.scheduleMediaId)) throw new Error('ملف الجدولة المحدد غير موجود.');
    s.scheduleState.lastRunKey = '';
    store.saveSession(s);
    res.json({ ok: true, nextRun: nextRun(s), targets: targetKeys.length, message: 'تم حفظ الجدولة.' });
  } catch (e) { replyError(res, e); }
});

app.post('/api/interaction/rules', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), b = req.body || {};
    const r = {
      id: randomId(), name: String(b.name || 'قاعدة').slice(0, 100), enabled: true, priority: store.toInt(b.priority, 0, -1000, 1000),
      when: { type: b.when?.type === 'reaction' ? 'reaction' : 'message', match: ['any', 'contains', 'exact', 'starts', 'ends', 'regex'].includes(b.when?.match) ? b.when.match : 'contains', value: String(b.when?.value || ''), ignoreCase: b.when?.ignoreCase !== false },
      then: { reply: String(b.then?.reply || '').trim(), reaction: String(b.then?.reaction || '').trim(), stopAfter: b.then?.stopAfter !== false },
      scope: ['all', 'groups', 'private', 'selected'].includes(b.scope) ? b.scope : 'all', chatIds: normalizeRuleChatIds(b.chatIds), cooldownSec: store.toInt(b.cooldownSec, 30, 0, 86400),
    };
    if (!r.then.reply && !r.then.reaction) throw new Error('أضف ردًا واحدًا على الأقل.');
    s.interaction.rules.push(r); store.saveSession(s); res.json({ ok: true, rule: r });
  } catch (e) { replyError(res, e); }
});
app.post('/api/interaction/rules/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), r = s.interaction.rules.find(x => x.id === req.params.id); if (!r) throw new Error('القاعدة غير موجودة.'); r.enabled = !r.enabled; store.saveSession(s); res.json({ ok: true, enabled: r.enabled }); } catch (e) { replyError(res, e); } });
app.delete('/api/interaction/rules/:id', (req, res) => { try { const s = store.loadSession(sid(req)), before = s.interaction.rules.length; s.interaction.rules = s.interaction.rules.filter(x => x.id !== req.params.id); if (before === s.interaction.rules.length) throw new Error('القاعدة غير موجودة.'); store.saveSession(s); res.json({ ok: true }); } catch (e) { replyError(res, e); } });


function normalizeAutomationPayload(id, b, existing = null) {
  const base = existing || {};
  const raw = { ...base, ...(b || {}) };
  const mode = ['weekly', 'monthly', 'yearly', 'once'].includes(String(raw.mode || '')) ? String(raw.mode) : 'weekly';
  const time = String(raw.time || '17:30');
  if (!/^\d{2}:\d{2}$/.test(time) || Number(time.slice(0, 2)) > 23 || Number(time.slice(3)) > 59) throw new Error('وقت الموعد غير صالح.');
  if (mode === 'once' && !validIsoDate(raw.date)) throw new Error('أدخل تاريخًا تقويميًا صالحًا.');
  if (mode !== 'once' && mode !== 'weekly' && !(Number(raw.dayOfMonth) >= 1 && Number(raw.dayOfMonth) <= 31)) throw new Error('يوم الشهر يجب أن يكون بين 1 و31.');
  if (mode === 'yearly' && !(Number(raw.month) >= 1 && Number(raw.month) <= 12)) throw new Error('اختر الشهر السنوي.');
  const s = store.loadSession(id), targets = validTargetKeys(s, Array.isArray(raw.targetKeys) ? raw.targetKeys : []), mediaIds = uniqueStrings(raw.mediaIds);
  const graceMinutes = store.toInt(raw.graceMinutes, 30, 1, 180);
  if (mode === 'once') {
    const plannedAt = zonedDateToUtc(raw.date, time, s.settings.timezone);
    if (!plannedAt) throw new Error('تعذر حساب وقت الموعد حسب المنطقة الزمنية لهذه الجلسة.');
    if (plannedAt.getTime() < Date.now() - graceMinutes * 60000) throw new Error('وقت الموعد في الماضي خارج مهلة التنفيذ. اختر تاريخًا ووقتًا في المستقبل أو ضمن المهلة المحددة.');
  }
  const available = new Set(media.scan(store.getPaths(id).media, s.settings.maxImageSizeMB).files.map(x => x.id));
  const mediaOk = mediaIds.filter(x => available.has(x));
  if (mediaIds.length !== mediaOk.length) throw new Error('بعض ملفات الموعد غير موجودة.');
  if (!targets.length) throw new Error('اختر مستلمًا أو مجموعة للموعد.');
  const mediaMode = raw.mediaMode === 'cycle' ? 'cycle' : 'selected';
  const text = String(raw.text ?? '');
  const textMode = ['auto', 'caption', 'before', 'after', 'none'].includes(String(raw.textMode || '')) ? String(raw.textMode) : (text.trim() ? 'auto' : 'before');
  const preText = String(raw.preText || ''), postText = String(raw.postText || '');
  const hasCycleImages = mediaMode === 'cycle' && media.scan(store.getPaths(id).media, s.settings.maxImageSizeMB).images.length > 0;
  const mainTextWillSend = text.trim() && textMode !== 'none';
  if (!mediaOk.length && !mainTextWillSend && !preText.trim() && !postText.trim() && !hasCycleImages) throw new Error('أضف نصًا فعّالًا أو ملفًا للموعد، أو فعّل دورة الصور مع وجود صور.');
  return store.normalizeAutomationTask({ ...raw, id: base.id || undefined, name: raw.name, mode, time, date: raw.date, day: store.toInt(raw.day, 5, 0, 6), dayOfMonth: store.toInt(raw.dayOfMonth, 1, 1, 31), month: raw.month === '' ? '' : store.toInt(raw.month, 1, 1, 12), year: raw.year === '' ? '' : store.toInt(raw.year, new Date().getFullYear(), 2020, 2100), targetKeys: targets, mediaIds: mediaMode === 'cycle' ? [] : mediaOk, mediaMode, text, textMode, captionMode: boolValue(raw.captionMode, true), sendAsDocument: boolValue(raw.sendAsDocument, false), sendDelayMs: store.toInt(raw.sendDelayMs, s.settings.sendDelayMs, 0, 60000), preText, postText, graceMinutes });
}
app.get('/api/automation/tasks', (req, res) => { try { const s = store.loadSession(sid(req)); res.json({ ok: true, tasks: (s.automation.tasks || []).map(t => ({ ...t, nextRun: nextRunForItem({ ...t, timezone: s.settings.timezone }) })) }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/task', (req, res) => { try { const id = sid(req), s = store.loadSession(id), task = normalizeAutomationPayload(id, req.body || {}); s.automation.tasks.push(task); s.automation.enabled = true; store.saveSession(s); res.json({ ok: true, task: { ...task, nextRun: nextRunForItem({ ...task, timezone: s.settings.timezone }) }, message: 'تم حفظ الموعد داخل الجلسة الحالية.' }); } catch (e) { replyError(res, e); } });
app.put('/api/automation/task/:id', (req, res) => { try { const id = sid(req), s = store.loadSession(id), task = s.automation.tasks.find(x => x.id === req.params.id); if (!task) throw new Error('الموعد غير موجود.'); const updated = normalizeAutomationPayload(id, req.body || {}, task); Object.assign(task, updated, { id: task.id, enabled: true, lastRunKey: '', lastFailureKey: '', lastResult: null, lastAttemptAt: '', updatedAt: new Date().toISOString() }); store.saveSession(s); res.json({ ok: true, task: { ...task, nextRun: nextRunForItem({ ...task, timezone: s.settings.timezone }) }, message: 'تم تحديث الموعد وإعادة تفعيله.' }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/task/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), t = s.automation.tasks.find(x => x.id === req.params.id); if (!t) throw new Error('الموعد غير موجود.'); const enabling = t.enabled === false; if (enabling && t.mode === 'once') { const plannedAt = zonedDateToUtc(t.date, t.time, s.settings.timezone); if (!plannedAt || plannedAt.getTime() < Date.now() - Number(t.graceMinutes || 30) * 60000) throw new Error('انتهى وقت هذا الموعد. افتحه للتعديل واختر وقتًا جديدًا قبل تفعيله.'); } t.enabled = enabling; t.updatedAt = new Date().toISOString(); store.saveSession(s); res.json({ ok: true, enabled: t.enabled, message: t.enabled ? 'تم تشغيل الموعد.' : 'تم إيقاف الموعد.' }); } catch (e) { replyError(res, e); } });
app.delete('/api/automation/task/:id', (req, res) => { try { const s = store.loadSession(sid(req)), before = s.automation.tasks.length; s.automation.tasks = s.automation.tasks.filter(x => x.id !== req.params.id); if (before === s.automation.tasks.length) throw new Error('الموعد غير موجود.'); store.saveSession(s); res.json({ ok: true, message: 'تم حذف الموعد.' }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/task/:id/run', async (req, res) => { try { const s = store.loadSession(sid(req)), t = s.automation.tasks.find(x => x.id === req.params.id); if (!t) throw new Error('الموعد غير موجود.'); res.json({ ok: true, ...(await delivery.scheduledTaskRun(s.id, t)), message: 'تم تنفيذ الموعد.' }); } catch (e) { replyError(res, e); } });

app.post('/api/interaction/test', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), body = String(req.body?.message || ''), chatId = String(req.body?.chatId || 'test@c.us').toLowerCase();
    const rule = req.body?.rule || {};
    if (!body && rule.when?.type === 'message' && rule.when?.match !== 'any') throw new Error('اكتب رسالة اختبار.');
    const ok = require('./src/interaction').match(rule, rule.when?.type === 'reaction' ? 'reaction' : 'message', body, String(req.body?.emoji || ''));
    res.json({ ok: true, matched: ok, rendered: require('./src/interaction').render(rule.then?.reply || '', { message: body, sender: String(req.body?.sender || 'مستخدم'), chat: chatId, type: rule.when?.type || 'message', emoji: String(req.body?.emoji || '') }, s.settings.timezone) });
  } catch (e) { replyError(res, e); }
});
app.post('/api/settings', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), b = req.body || {};
    for (const key of ['timezone', 'sendOrder', 'interactionScope', 'interactionQuietStart', 'interactionQuietEnd']) {
      if (b[key] === undefined) continue;
      const value = String(b[key]).trim();
      if (key === 'timezone') { try { new Intl.DateTimeFormat('en-US', { timeZone: value }).format(); } catch { throw new Error('المنطقة الزمنية غير صالحة. استخدم اسمًا مثل Asia/Muscat.'); } }
      s.settings[key] = value;
    }
    if (Array.isArray(b.interactionChatIds)) s.settings.interactionChatIds = normalizeRuleChatIds(b.interactionChatIds);
    if (b.appearance && typeof b.appearance === 'object') {
      const a = b.appearance, isHex = v => /^#[0-9a-f]{6}$/i.test(String(v || ''));
      const current = s.settings.appearance || {};
      s.settings.appearance = {
        ...current,
        accent: isHex(a.accent) ? String(a.accent) : current.accent,
        accent2: isHex(a.accent2) ? String(a.accent2) : current.accent2,
        panelOpacity: Number.isFinite(Number(a.panelOpacity)) ? Math.max(.72, Math.min(.97, Number(a.panelOpacity))) : current.panelOpacity,
        panelBlur: Number.isFinite(Number(a.panelBlur)) ? Math.max(4, Math.min(28, Number(a.panelBlur))) : current.panelBlur,
        radius: Number.isFinite(Number(a.radius)) ? Math.max(12, Math.min(28, Number(a.radius))) : current.radius,
        glow: Number.isFinite(Number(a.glow)) ? Math.max(0, Math.min(1, Number(a.glow))) : current.glow,
      };
    }
    for (const key of ['sendTimeoutMs', 'sendDelayMs', 'retryAttempts', 'retryDelayMs', 'maxImageSizeMB', 'maxActionsPerMinute']) if (b[key] !== undefined) s.settings[key] = store.toInt(b[key], s.settings[key], 1, key === 'retryAttempts' ? 4 : 1000000);
    for (const key of ['interactionEnabled', 'groupAssistantEnabled', 'interactionIgnoreOwn', 'interactionQuietEnabled', 'autoStartSession', 'automationEnabled']) if (b[key] !== undefined) s.settings[key] = boolValue(b[key], s.settings[key]);
    if (b.interactionEnabled !== undefined) s.interaction.enabled = boolValue(b.interactionEnabled, s.interaction.enabled);
    if (b.automationEnabled !== undefined) s.automation.enabled = boolValue(b.automationEnabled, s.automation.enabled);
    store.saveSession(s); res.json({ ok: true, message: 'تم حفظ الإعدادات.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/settings/background', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), b = req.body || {}, n = backgrounds.normalize(b.mode, b.settings, b.opacity);
    s.settings.backgroundMode = n.mode; s.settings.backgroundSettings = n.settings; s.settings.backgroundOpacity = n.opacity;
    if (b.removeImage && s.settings.backgroundImage) { try { fs.rmSync(media.safePath(store.getPaths(id).backgrounds, s.settings.backgroundImage), { force: true }); } catch {} s.settings.backgroundImage = ''; }
    store.saveSession(s); res.json({ ok: true, message: 'تم تطبيق المظهر فعليًا.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/background', bgUpload.single('file'), (req, res) => {
  try {
    const id = sid(req), file = req.file; if (!file) throw new Error('اختر صورة خلفية.');
    const ext = path.extname(file.originalname || '').toLowerCase(); if (!['.jpg', '.jpeg', '.png', '.webp'].includes(ext)) throw new Error('صيغة الخلفية غير مدعومة.');
    const s = store.loadSession(id), dir = store.getPaths(id).backgrounds, name = `background${ext}`;
    for (const oldExt of ['.jpg','.jpeg','.png','.webp']) { const oldName = `background${oldExt}`; if (oldName !== name) { try { fs.rmSync(media.safePath(dir, oldName), { force: true }); } catch {} } }
    fs.renameSync(file.path, media.safePath(dir, name)); s.settings.backgroundImage = name; store.saveSession(s); res.json({ ok: true, message: 'تم رفع الخلفية وتطبيقها.' });
  } catch (e) { try { if (req.file) fs.rmSync(req.file.path, { force: true }); } catch {} replyError(res, e); }
});
app.get('/background/:filename', (req, res) => { try { const s = store.loadSession(sid(req)), name = decodeURIComponent(req.params.filename); if (s.settings.backgroundImage !== name) return res.status(404).end(); res.sendFile(media.safePath(store.getPaths(s.id).backgrounds, name)); } catch { res.status(404).end(); } });

whatsapp.on('status', (id, runtime) => {
  if (runtime?.ready) ownerAssistant.onReady(id).catch(e => log(id,'WARN',`لم يكتمل تهيئة مركز المساعد: ${safeError(e)}`));
  else if (runtime?.status === 'auth_failure') ownerAssistant.recordIssue(id,{code:'WHATSAPP_AUTH_FAILURE',route:'/api/session/connect',error:'فشل توثيق WhatsApp. افحص الجلسة وأعد الربط بعد التأكد من الحساب.',status:401}).catch(()=>{});
  else if (runtime?.status === 'disconnected') ownerAssistant.recordIssue(id,{code:'WHATSAPP_DISCONNECTED',route:'/api/session/status',error:'انقطع اتصال WhatsApp. ستبقى المشكلة محفوظة محليًا، وسيعاد إرسال التنبيه عند عودة الاتصال إذا كانت الإشعارات مفعّلة.',status:503,steps:['افتح الجلسة وتحقق من حالة الاتصال.', 'أعد الاتصال وامسح QR عند الطلب.', 'انتظر حالة «متصل» وتحقق من سجل الأحداث.']}).catch(()=>{});
});
whatsapp.on('message_create', (id,msg) => ownerAssistant.handleSelfChatMessage(id,msg).catch(e => log(id,'WARN',`تعذر التعامل مع رسالة مركز المساعد: ${safeError(e)}`)));
whatsapp.on('message', async (id, msg) => {
  try {
    // Incoming messages from the explicitly linked secondary account are accepted only
    // when they come from the primary account owner; otherwise keep normal automations.
    const linked = await ownerAssistant.handleLinkedReplyMessage(id, msg);
    if (linked?.handled) return;
    const results = await Promise.allSettled([interaction.onMessage(id, msg), groupCommand(id, msg)]);
    results.filter(x => x.status === 'rejected').forEach(x => log(id, 'ERROR', safeError(x.reason)));
  } catch (error) { log(id, 'ERROR', `تعذر توجيه رسالة WhatsApp: ${safeError(error)}`); }
});
whatsapp.on('reaction', (id, reaction) => interaction.onReaction(id, reaction).catch(e => log(id, 'ERROR', safeError(e))));

async function groupCommand(id, msg) {
  try {
    if (msg?.fromMe) return;
    const gid = groupFromMessage(msg); if (!gid) return;
    const s = store.loadSession(id);
    let info = null;
    try { info = await whatsapp.getGroupInfoFromMessage(id, msg); if (info?.gid) saveGroup(id, info); } catch {}
    if (!s.settings.groupAssistantEnabled) return;
    const body = String(msg?.body || '').trim();
    const command = /^(?:!|\/)?(?:gid|group\s*id|groupid|group\s*info|group\s*analysis|معرف\s*(?:المجموعة|القروب)|تحليل\s*(?:المجموعة|القروب)|معلومات\s*(?:المجموعة|القروب)|معلومات\s*الجروب)(?=\s|$)/iu;
    const invite = body.match(/(?:https?:\/\/)?chat\.whatsapp\.com\/[A-Za-z0-9_-]+/i);
    const gidMention = body.match(/(?:^|[\s(])\d{5,25}(?:-\d+)*@g\.us(?=$|[\s)])/i);
    if (!command.test(body) && !invite && !gidMention) return;
    let target = invite ? invite[0] : gidMention ? gidMention[0] : body.replace(command, '').trim();
    if (!target) target = gid;
    if (groups.isGroupId(target)) info = await whatsapp.getGroupInfo(id, groups.normalizeGid(target));
    else if (invite) info = await whatsapp.analyzeGroupInvite(id, groups.extractInviteCode(target));
    else info = info || await whatsapp.getGroupInfo(id, gid);
    if (info?.gid) saveGroup(id, info);
    await whatsapp.replyToMessage(id, msg, `تحليل المجموعة\n${groups.formatGroupAnalysis(info)}`);
  } catch (e) {
    try { if (msg && !msg.fromMe) await whatsapp.replyToMessage(id, msg, `تعذر تحليل المجموعة: ${safeError(e)}`); } catch {}
  }
}

app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  const message = err?.code === 'LIMIT_FILE_SIZE' ? 'حجم الملف أكبر من الحد المسموح.' : err?.code === 'LIMIT_FILE_COUNT' ? 'عدد الملفات أكبر من الحد المسموح.' : safeError(err);
  res.status(Number(err?.status) || 400).json({ ok: false, error: message });
});
process.on('unhandledRejection', reason => log(null, 'ERROR', `Unhandled Promise Rejection: ${safeError(reason)}`));

async function shutdown(signal) {
  log(null, 'INFO', `إيقاف الخادم (${signal})…`);
  scheduler.stop();
  await whatsapp.stopAll().catch(() => {});
  process.exit(0);
}
process.once('SIGINT', () => shutdown('SIGINT'));
process.once('SIGTERM', () => shutdown('SIGTERM'));

app.listen(PORT, HOST, () => { log(null, 'INFO', `لوحة التحكم تعمل على http://${HOST}:${PORT}`); setTimeout(() => { for (const id of store.listSessionIds()) { const s = store.loadSession(id); if (s.settings.autoStartSession && whatsapp.hasSavedAuth(id) && !whatsapp.listRuntime(id).ready) whatsapp.start(id).catch(err => log(id, 'WARN', `التشغيل التلقائي للجلسة لم يكتمل: ${safeError(err)}`)); } }, 500); });
