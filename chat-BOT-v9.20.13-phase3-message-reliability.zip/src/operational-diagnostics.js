'use strict';

// Safe operational report for the local dashboard. The report intentionally
// exposes only fixed labels, counts and coarse states; never forwards paths,
// contact identifiers, QR/pairing material, tokens, message bodies or raw errors.

function majorVersion(value) {
  const match = String(value || '').match(/^v?(\d+)/i);
  return match ? Number(match[1]) : 0;
}
function count(value) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.trunc(n)) : 0;
}
function stateText(value) {
  const state = String(value || '').toLowerCase();
  const labels = {
    ready: 'جاهز', connected: 'متصل', qr: 'بانتظار مسح رمز QR',
    pairing_code: 'بانتظار رمز الربط', initializing: 'جارٍ التهيئة',
    connecting: 'جارٍ الاتصال', disconnected: 'غير متصل',
    auth_failure: 'تعذر التحقق من الجلسة', failed: 'فشل التشغيل',
    stopped: 'متوقف', idle: 'لم يبدأ بعد', preparing: 'جارٍ التجهيز',
  };
  return labels[state] || 'الحالة غير معروفة';
}
function buildReport(input = {}) {
  const checks = [];
  const add = (id, label, status, detail, recommendation = '') => checks.push({ id, label, status, detail, recommendation });
  const nodeMajor = majorVersion(input.nodeVersion);
  add('node-runtime', 'إصدار Node.js', nodeMajor >= 20 ? 'pass' : 'error',
    nodeMajor >= 20 ? `الإصدار ${String(input.nodeVersion || '').slice(0, 30)} مناسب للمشروع.` : 'يتطلب المشروع Node.js 20 أو أحدث.',
    nodeMajor >= 20 ? '' : 'ثبّت إصدار LTS حديثًا من Node.js ثم أعد التشغيل.');

  const storage = input.storage || {};
  const storageOK = storage.dataReadable === true && storage.dataWritable === true && storage.sessionsReadable === true && storage.sessionsWritable === true;
  add('local-storage', 'تخزين المشروع المحلي', storageOK ? 'pass' : 'error',
    storageOK ? 'مجلدات البيانات والجلسات قابلة للقراءة والكتابة.' : 'تعذرت قراءة أو كتابة أحد مجلدات البيانات المحلية.',
    storageOK ? '' : 'تحقق من صلاحيات مجلد المشروع ومجلد data، ولا تشغّل نسختين من المشروع على المجلد نفسه.');
  add('session-data', 'بيانات الجلسة', input.sessionLoaded === true ? 'pass' : 'error',
    input.sessionLoaded === true ? 'تم تحميل بيانات الجلسة الحالية.' : 'تعذر تحميل بيانات الجلسة الحالية.',
    input.sessionLoaded === true ? '' : 'استخدم نسخة احتياطية سليمة وافحص سجل التشغيل المحلي قبل استبدال البيانات.');
  add('media-storage', 'مكتبة الوسائط', input.mediaWritable === true ? 'pass' : 'warning',
    input.mediaWritable === true ? `مجلد الوسائط متاح؛ عدد الملفات المحفوظة: ${count(input.mediaCount)}.` : 'مجلد الوسائط غير موجود أو غير قابل للكتابة.',
    input.mediaWritable === true ? '' : 'افحص صلاحيات التخزين المحلي؛ إرسال الوسائط قد لا يعمل حتى تُحل المشكلة.');

  const wa = input.whatsapp || {};
  if (wa.ready === true) add('whatsapp-session', 'اتصال WhatsApp', 'pass', 'الجلسة متصلة وفق حالة التشغيل الحالية.');
  else if (['failed', 'auth_failure', 'error'].includes(String(wa.status || '').toLowerCase())) add('whatsapp-session', 'اتصال WhatsApp', 'error', `حالة الاتصال: ${stateText(wa.status)}.`, 'راجع صفحة الجلسة وسجل التشغيل، ثم أعد الربط عند الحاجة.');
  else add('whatsapp-session', 'اتصال WhatsApp', 'warning', `حالة الاتصال: ${stateText(wa.status)}.`, 'امسح QR أو أكمل رمز الربط من صفحة الجلسة. لا يمكن اختبار التسليم قبل الاتصال.');
  add('whatsapp-auth', 'بيانات جلسة WhatsApp المحفوظة', wa.hasSavedAuth === true ? 'pass' : 'warning',
    wa.hasSavedAuth === true ? 'عُثر على بيانات جلسة محفوظة؛ هذا لا يضمن قبول WhatsApp لها.' : 'لا توجد بيانات جلسة محفوظة مؤكدة.',
    wa.hasSavedAuth === true ? 'إذا لم يتصل الحساب، أعد الربط من صفحة الجلسة.' : 'اربط الحساب من صفحة الجلسة إذا أردت تشغيله.');

  const voice = input.voice || {};
  if (voice.ready === true) add('voice-runtime', 'محركات الصوت المحلية', 'pass', 'تهيئة محركات الصوت أبلغت عن الجاهزية.');
  else if (String(voice.state || '').toLowerCase() === 'failed') add('voice-runtime', 'محركات الصوت المحلية', 'warning', 'تهيئة الصوت لم تكتمل؛ بقية لوحة التحكم تبقى مستقلة عن هذا المحرك.', 'افتح صفحة المحركات الذكية لمراجعة حالة الصوت وإعادة التهيئة التلقائية.');
  else if (['preparing', 'installing', 'downloading'].includes(String(voice.state || '').toLowerCase())) add('voice-runtime', 'محركات الصوت المحلية', 'info', `تهيئة الصوت قيد التنفيذ (${count(voice.progress)}%).`, 'انتظر انتهاء التهيئة ثم نفّذ اختبار صوت حقيقي من صفحة المحركات الذكية.');
  else add('voice-runtime', 'محركات الصوت المحلية', 'warning', `حالة محرك الصوت: ${stateText(voice.state)}.`, 'نفّذ اختبار اللغات الأربع؛ حالة الخدمة وحدها لا تثبت نجاح التفريغ أو الإرسال الصوتي.');

  const session = input.session || {};
  const recipientCount = count(session.recipients);
  const groupCount = count(session.groups);
  const enabledRuleCount = count(session.enabledInteractionRules);
  const enabledTaskCount = count(session.enabledAutomationTasks);
  add('targets', 'جهات الإرسال', recipientCount + groupCount > 0 ? 'pass' : 'info',
    `الأشخاص المحفوظون: ${recipientCount}؛ المجموعات المحفوظة: ${groupCount}.`,
    recipientCount + groupCount > 0 ? '' : 'أضف شخصًا أو مجموعة قبل اختبار الإرسال.');
  add('automation', 'القواعد والأتمتة', enabledRuleCount + enabledTaskCount > 0 ? 'pass' : 'info',
    `قواعد التفاعل المفعّلة: ${enabledRuleCount}؛ مهام الأتمتة المفعّلة: ${enabledTaskCount}.`,
    enabledRuleCount + enabledTaskCount > 0 ? '' : 'فعّل قاعدة بعد مراجعتها إذا كنت تحتاج إلى ردود أو مهام تلقائية.');
  if (input.maintenance === true) add('maintenance', 'صيانة النسخ الاحتياطي', 'warning', 'هناك عملية نسخ أو استعادة أو إعادة تهيئة جلسات جارية.', 'انتظر انتهاء العملية قبل اختبار واجهات أخرى.');
  else add('maintenance', 'صيانة النسخ الاحتياطي', 'pass', 'لا توجد عملية صيانة معروفة قيد التنفيذ.');

  const counts = checks.reduce((result, check) => { result[check.status] = (result[check.status] || 0) + 1; return result; }, { pass: 0, warning: 0, error: 0, info: 0 });
  const overall = counts.error ? 'needs_attention' : counts.warning ? 'degraded' : 'healthy';
  return {
    ok: true,
    schemaVersion: 1,
    version: String(input.version || '').slice(0, 30),
    checkedAt: new Date().toISOString(),
    overall,
    summary: { total: checks.length, ...counts },
    checks,
    privacy: 'يعرض التقرير حالات عامة وأعدادًا فقط؛ لا يتضمن محتوى الرسائل أو أرقام الهواتف أو معرفات المحادثات أو رموز الربط أو كلمات المرور أو المسارات المحلية.',
  };
}

module.exports = { buildReport, majorVersion, stateText };
