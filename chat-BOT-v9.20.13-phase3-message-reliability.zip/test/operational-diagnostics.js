'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { buildReport, majorVersion, stateText } = require('../src/operational-diagnostics');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

const good = buildReport({
  version: '9.20.12', nodeVersion: 'v22.11.0', sessionLoaded: true,
  storage: { dataReadable: true, dataWritable: true, sessionsReadable: true, sessionsWritable: true },
  mediaWritable: true, mediaCount: 5,
  whatsapp: { ready: true, status: 'ready', hasSavedAuth: true },
  voice: { ready: true, state: 'ready', progress: 100 },
  session: { recipients: 2, groups: 1, enabledInteractionRules: 3, enabledAutomationTasks: 2 }, maintenance: false,
});
assert.equal(good.overall, 'healthy');
assert.equal(good.summary.error, 0);
assert.ok(good.checks.every(check => ['pass', 'warning', 'error', 'info'].includes(check.status)));
assert.equal(good.version, '9.20.12');

const degraded = buildReport({
  version: '9.20.12', nodeVersion: 'v20.10.0', sessionLoaded: true,
  storage: { dataReadable: true, dataWritable: true, sessionsReadable: true, sessionsWritable: true }, mediaWritable: true,
  whatsapp: { ready: false, status: 'qr', hasSavedAuth: false },
  voice: { ready: false, state: 'preparing', progress: 23 },
  session: { recipients: 0, groups: 0, enabledInteractionRules: 0, enabledAutomationTasks: 0 }, maintenance: true,
});
assert.equal(degraded.overall, 'degraded');
assert.ok(degraded.checks.some(check => check.id === 'whatsapp-session' && check.status === 'warning'));
assert.ok(degraded.checks.some(check => check.id === 'voice-runtime' && check.status === 'info'));
assert.ok(degraded.checks.some(check => check.id === 'maintenance' && check.status === 'warning'));

const critical = buildReport({
  version: '9.20.12', nodeVersion: 'v18.0.0', sessionLoaded: false,
  storage: { dataReadable: false, dataWritable: false, sessionsReadable: false, sessionsWritable: false },
  mediaWritable: false, whatsapp: { ready: false, status: 'auth_failure', hasSavedAuth: false },
  voice: { ready: false, state: 'failed', progress: 0 }, session: {}, maintenance: false,
});
assert.equal(critical.overall, 'needs_attention');
assert.ok(critical.summary.error >= 2);
assert.equal(majorVersion('v22.3.4'), 22);
assert.equal(majorVersion('not-a-version'), 0);
assert.equal(stateText('qr'), 'بانتظار مسح رمز QR');

const contaminatedInput = {
  version: '9.20.12', nodeVersion: 'v22.0.0', sessionLoaded: true,
  storage: { dataReadable: true, dataWritable: true, sessionsReadable: true, sessionsWritable: true }, mediaWritable: true,
  whatsapp: { ready: true, status: 'ready', hasSavedAuth: true, qr: 'QR_SUPER_SECRET', token: 'TOKEN_SECRET', whatsappJid: 'PHONE_SECRET' },
  voice: { ready: true, state: 'ready', message: 'C:\\Users\\private\\secret' },
  session: { recipients: 1, groups: 1, enabledInteractionRules: 1, enabledAutomationTasks: 1, message: 'PRIVATE_MESSAGE_BODY', recipientPhone: '+96800000000' },
};
const serialized = JSON.stringify(buildReport(contaminatedInput));
for (const secret of ['QR_SUPER_SECRET', 'TOKEN_SECRET', 'PHONE_SECRET', 'PRIVATE_MESSAGE_BODY', 'C:\\\\Users', '+96800000000']) assert.ok(!serialized.includes(secret), `diagnostic report leaked sensitive input: ${secret}`);

const server = read('server.js');
const app = read('public/app.js');
assert.match(server, /app\.get\('\/api\/diagnostics\/report'/);
assert.match(server, /Cache-Control', 'no-store, no-cache, must-revalidate, private'/);
assert.match(server, /const report = buildOperationalDiagnosticsReport/);
assert.match(server, /تعذر إنشاء التقرير التشغيلي\. راجع سجل الخادم المحلي/);
assert.match(app, /id="refreshOperationalDiagnostics"/);
assert.match(app, /id="copyOperationalDiagnostics"/);
assert.match(app, /api\/diagnostics\/report/);
assert.match(app, /التقرير التشغيلي الآمن/);
console.log('operational-diagnostics: ok (healthy/degraded/critical classification, actionable checks, secret-safe report shape, dashboard integration)');
