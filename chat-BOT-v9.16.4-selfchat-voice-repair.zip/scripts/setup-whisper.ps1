$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Tools = Join-Path $Root 'tools\whisper'
$Models = Join-Path $Root 'models'
$Temp = Join-Path ([System.IO.Path]::GetTempPath()) ('chatbot-whisper-setup-' + [guid]::NewGuid().ToString('N'))
$EnvFile = Join-Path $Root '.env'
$ExpectedSmallModelSha256 = '1be3a9b2063867b937e64e2ec7483364a79917e157fa98c5d94b5c1fffea987b'
New-Item -ItemType Directory -Path $Tools -Force | Out-Null
New-Item -ItemType Directory -Path $Models -Force | Out-Null
New-Item -ItemType Directory -Path $Temp -Force | Out-Null

function Find-WhisperBinary {
  $preferred = @(
    (Join-Path $Tools 'whisper-cli.exe'),
    (Join-Path $Tools 'bin\whisper-cli.exe'),
    (Join-Path $Tools 'main.exe')
  )
  foreach ($candidate in $preferred) { if (Test-Path -LiteralPath $candidate -PathType Leaf) { return (Resolve-Path $candidate).Path } }
  $found = Get-ChildItem -LiteralPath $Tools -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -in @('whisper-cli.exe','main.exe') } | Select-Object -First 1
  if ($found) { return $found.FullName }
  return ''
}
function Set-EnvValue([string]$Key, [string]$Value) {
  $lines = @()
  if (Test-Path -LiteralPath $EnvFile) { $lines = @(Get-Content -LiteralPath $EnvFile -ErrorAction Stop) }
  $pattern = '^\s*' + [regex]::Escape($Key) + '\s*='
  $quoted = '"' + $Value.Replace('\','/').Replace('"','\"') + '"'
  $replacement = "$Key=$quoted"
  $newLines = New-Object 'System.Collections.Generic.List[string]'
  foreach ($existing in $lines) { if ($existing -notmatch $pattern) { $newLines.Add([string]$existing) } }
  $newLines.Add($replacement)
  Set-Content -LiteralPath $EnvFile -Value $newLines -Encoding UTF8
}
try {
  $binary = Find-WhisperBinary
  if (-not $binary) {
    Write-Host 'جارٍ البحث عن إصدار Windows الرسمي من whisper.cpp...' -ForegroundColor Cyan
    $headers = @{ 'User-Agent' = 'chat-BOT-local-voice-setup'; 'Accept' = 'application/vnd.github+json' }
    $release = Invoke-RestMethod -Uri 'https://api.github.com/repos/ggml-org/whisper.cpp/releases/latest' -Headers $headers -TimeoutSec 30
    $assets = @($release.assets)
    $asset = $assets | Where-Object { $_.name -match '(?i)^whisper-bin-win-cpu-x64\.zip$' } | Select-Object -First 1
    if (-not $asset) {
      $asset = $assets | Where-Object { $_.name -match '(?i)^whisper-cpp-win32-x64-cpu\.zip$' } | Select-Object -First 1
    }
    if (-not $asset) {
      $asset = $assets | Where-Object { $_.name -match '(?i)whisper.*(win|x64|amd64).*cpu.*\.zip$' -and $_.name -notmatch '(?i)(cuda|cublas|vulkan|arm64|openvino|sycl)' } | Select-Object -First 1
    }
    if (-not $asset -or -not $asset.browser_download_url) {
      throw "لم أجد حزمة CPU متوافقة في الإصدار الرسمي $($release.tag_name). لم يتم تنزيل ملف تنفيذي غير معروف. راجع docs/VOICE_SETUP_AR.md لتجهيز whisper.cpp يدويًا."
    }
    $archive = Join-Path $Temp $asset.name
    Write-Host "تنزيل المحرك الرسمي $($release.tag_name): $($asset.name)" -ForegroundColor Cyan
    Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $archive -Headers @{ 'User-Agent' = 'chat-BOT-local-voice-setup' } -TimeoutSec 900
    if ((Get-Item -LiteralPath $archive).Length -lt 1MB) { throw 'ملف محرك Whisper الذي تم تنزيله أصغر من المتوقع؛ أوقف الإعداد.' }
    $extract = Join-Path $Temp 'extract'
    Expand-Archive -LiteralPath $archive -DestinationPath $extract -Force
    Get-ChildItem -LiteralPath $extract -Force | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $Tools -Recurse -Force }
    $binary = Find-WhisperBinary
    if (-not $binary) { throw 'تم تنزيل الحزمة لكن لم يُعثر على whisper-cli.exe بداخلها. لم يتم تفعيل إعداد الصوت.' }
  }

  # Prefer the multilingual small model for noticeably better Arabic accuracy than base.
  # Keep an existing base model as a fallback only when a small model is already unavailable.
  $model = Join-Path $Models 'ggml-small.bin'
  $validModel = $false
  if (Test-Path -LiteralPath $model -PathType Leaf) {
    $existing = Get-Item -LiteralPath $model
    if ($existing.Length -ge 400MB) {
      $existingHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $model).Hash.ToLowerInvariant()
      $validModel = ($existingHash -eq $ExpectedSmallModelSha256)
      if (-not $validModel) { Write-Warning 'نموذج ggml-small.bin الموجود لا يطابق البصمة الرسمية؛ سيعاد تنزيله.' }
    }
  }
  if (-not $validModel) {
    $partial = Join-Path $Temp 'ggml-small.bin.download'
    Write-Host 'جارٍ تنزيل نموذج Whisper متعدد اللغات بحجم أكبر ودقة أفضل للعربية (نحو 488 MB).' -ForegroundColor Cyan
    Invoke-WebRequest -Uri 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin?download=true' -OutFile $partial -Headers @{ 'User-Agent' = 'chat-BOT-local-voice-setup' } -TimeoutSec 2400
    if (-not (Test-Path -LiteralPath $partial -PathType Leaf) -or (Get-Item -LiteralPath $partial).Length -lt 400MB) { throw 'تنزيل نموذج Whisper small غير مكتمل (أقل من 400 MB). لم يتم تفعيل النموذج.' }
    $downloadHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $partial).Hash.ToLowerInvariant()
    if ($downloadHash -ne $ExpectedSmallModelSha256) { throw "فشل تحقق بصمة نموذج Whisper small. المتوقع $ExpectedSmallModelSha256 والموجود $downloadHash؛ أوقف الإعداد بدل تشغيل نموذج تالف." }
    Move-Item -LiteralPath $partial -Destination $model -Force
  }

  $ffmpeg = (Get-Command 'ffmpeg.exe' -ErrorAction SilentlyContinue | Select-Object -First 1).Source
  if (-not $ffmpeg) { $ffmpeg = (Get-Command 'ffmpeg' -ErrorAction SilentlyContinue | Select-Object -First 1).Source }
  $localFfmpegCandidates = @((Join-Path $Root 'tools\ffmpeg\bin\ffmpeg.exe'), (Join-Path $Root 'tools\ffmpeg\ffmpeg.exe'))
  foreach ($candidate in $localFfmpegCandidates) { if (-not $ffmpeg -and (Test-Path -LiteralPath $candidate -PathType Leaf)) { $ffmpeg = (Resolve-Path $candidate).Path } }
  if (-not $ffmpeg -and (Get-Command 'winget.exe' -ErrorAction SilentlyContinue)) {
    $answer = Read-Host 'يحتاج تحويل صوتيات WhatsApp (OGG/OPUS) إلى WAV إلى FFmpeg. هل تريد محاولة تثبيته عبر winget؟ (Y/N)'
    if ($answer -match '(?i)^(y|yes)$') {
      Write-Host 'جارٍ تثبيت FFmpeg عبر winget...' -ForegroundColor Cyan
      & winget install --id Gyan.FFmpeg --exact --scope user --silent --accept-package-agreements --accept-source-agreements
      $ffmpeg = (Get-Command 'ffmpeg.exe' -ErrorAction SilentlyContinue | Select-Object -First 1).Source
      if (-not $ffmpeg) { $ffmpeg = (Get-Command 'ffmpeg' -ErrorAction SilentlyContinue | Select-Object -First 1).Source }
    }
  }

  $binary = (Resolve-Path -LiteralPath $binary).Path
  $model = (Resolve-Path -LiteralPath $model).Path
  Set-EnvValue 'WHISPER_BACKEND' 'whisper.cpp'
  Set-EnvValue 'WHISPER_CPP_BIN' $binary
  Set-EnvValue 'WHISPER_MODEL_PATH' $model
  if ($ffmpeg) { Set-EnvValue 'FFMPEG_BIN' $ffmpeg } else { Set-EnvValue 'FFMPEG_BIN' 'ffmpeg' }

  Write-Host ''
  Write-Host 'تم تجهيز محرك Whisper والنموذج وحفظ مساراتهما في .env.' -ForegroundColor Green
  Write-Host 'أعد تشغيل Chat BOT ثم افتح «المحركات الذكية» واضغط «تحديث حالة الصوت».' -ForegroundColor Green
  if (-not $ffmpeg) {
    Write-Warning 'لم يُعثر على FFmpeg. ستفشل أغلب فويسات WhatsApp بصيغة OGG/OPUS دون تحويل محلي. ثبّته بالأمر: winget install --id Gyan.FFmpeg -e --scope user ثم أعد تشغيل البوت.'
  }
  & $binary --help *> $null
  if ($LASTEXITCODE -ne 0) { throw "تم العثور على ملف whisper-cli لكن فشل تشغيله (exit=$LASTEXITCODE). تحقق من ملفات DLL داخل tools\whisper." }
  Write-Host 'الصوت يُعالج محليًا بعد التنزيل الأول للمحرك والنموذج؛ لا يُرسل إلى API صوتي سحابي.'
} catch {
  Write-Host "فشل إعداد الصوت: $($_.Exception.Message)" -ForegroundColor Red
  Write-Host 'لم يتم تأكيد جاهزية Whisper. افتح docs/VOICE_SETUP_AR.md لمراجعة المتطلبات.' -ForegroundColor Yellow
  exit 1
} finally {
  Remove-Item -LiteralPath $Temp -Recurse -Force -ErrorAction SilentlyContinue
}
