$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$VoiceDir = Join-Path $Root '.voice-venv'
$ModelsDir = Join-Path $Root 'models'
$ModelName = 'ar_JO-kareem-medium.onnx'
$ModelPath = Join-Path $ModelsDir $ModelName
$ConfigPath = "$ModelPath.json"
$ModelUrl = 'https://huggingface.co/rhasspy/piper-voices/resolve/main/ar/ar_JO/kareem/medium/ar_JO-kareem-medium.onnx'
$ConfigUrl = "$ModelUrl.json"
$ExpectedSha256 = '9e95cab07b679da603bba17c4dec7ab3111320571964ee95c0379603c086491e'

Write-Host '=== إعداد الصوت العربي المحلي لـ chat BOT ===' -ForegroundColor Cyan
Write-Host 'سيتم تنزيل محرك نطق محلي ونموذج عربي إلى هذا الجهاز فقط.'
Write-Host 'لا يُرفع نص الرسالة إلى خدمة توليد صوت سحابية أثناء النطق.'

if (-not (Test-Path $VoiceDir)) {
  $created = $false
  foreach ($version in @('3.12','3.11','3.13','3.10')) {
    try {
      & py "-$version" -m venv $VoiceDir 2>$null
      if ($LASTEXITCODE -eq 0 -and (Test-Path (Join-Path $VoiceDir 'Scripts\python.exe'))) { $created = $true; break }
    } catch {}
    if (Test-Path $VoiceDir) { Remove-Item -Recurse -Force $VoiceDir -ErrorAction SilentlyContinue }
  }
  if (-not $created) {
    $winget = Get-Command 'winget.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($winget) {
      $answer = Read-Host 'لم أجد Python متوافقًا (قد يكون الموجود 3.14 فقط). هل تريد تثبيت Python 3.12 للمستخدم الحالي عبر winget؟ (Y/N)'
      if ($answer -match '(?i)^(y|yes)$') {
        Write-Host 'جارٍ تثبيت Python 3.12 المتوافق مع بيئة Piper…' -ForegroundColor Yellow
        & $winget.Source install --id Python.Python.3.12 --exact --scope user --silent --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -eq 0) {
          $launcher = Get-Command 'py.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
          $pythonCandidates = @(
            (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'),
            (Join-Path $env:ProgramFiles 'Python312\python.exe')
          )
          if ($launcher) {
            try { & $launcher.Source '-3.12' -m venv $VoiceDir 2>$null; if ($LASTEXITCODE -eq 0 -and (Test-Path (Join-Path $VoiceDir 'Scripts\python.exe'))) { $created = $true } } catch {}
          }
          if (-not $created) {
            foreach ($candidate in $pythonCandidates) {
              if (Test-Path -LiteralPath $candidate -PathType Leaf) {
                try { & $candidate -m venv $VoiceDir 2>$null; if ($LASTEXITCODE -eq 0 -and (Test-Path (Join-Path $VoiceDir 'Scripts\python.exe'))) { $created = $true; break } } catch {}
              }
            }
          }
        }
      }
    }
  }
  if (-not $created) {
    throw 'لم أجد Python 3.10–3.13 متوافقًا لإنشاء بيئة الصوت. ثبّت Python 3.12 أو 3.13 ثم أعد تشغيل الأداة؛ Python 3.14 وحده قد لا يدعم جميع تبعيات Piper.'
  }
}
$Python = Join-Path $VoiceDir 'Scripts\python.exe'
$Piper = Join-Path $VoiceDir 'Scripts\piper.exe'
Write-Host 'تثبيت Piper داخل بيئة منفصلة…' -ForegroundColor Yellow
& $Python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'تعذر تحديث pip داخل بيئة الصوت.' }
& $Python -m pip install --upgrade piper-tts
if ($LASTEXITCODE -ne 0) { throw 'تعذر تثبيت piper-tts. تحقق من اتصال التنزيل والمساحة المتاحة.' }
if (-not (Test-Path $Piper)) { throw 'تم تثبيت الحزمة لكن piper.exe غير موجود في بيئة الصوت؛ لم أضبط النظام على مسار غير صالح.' }

New-Item -ItemType Directory -Force -Path $ModelsDir | Out-Null
if (-not (Test-Path $ModelPath) -or (Get-Item $ModelPath).Length -lt 10000000) {
  Write-Host 'تنزيل نموذج العربية (نحو 63 ميجابايت)…' -ForegroundColor Yellow
  Invoke-WebRequest -Uri $ModelUrl -OutFile $ModelPath -UseBasicParsing
}
$ActualSha256 = (Get-FileHash -Algorithm SHA256 -Path $ModelPath).Hash.ToLowerInvariant()
if ($ActualSha256 -ne $ExpectedSha256) {
  Remove-Item -Force $ModelPath -ErrorAction SilentlyContinue
  throw "فشل تحقق بصمة نموذج النطق. المتوقع $ExpectedSha256 والموجود $ActualSha256. حذفت الملف غير المطابق؛ أعد المحاولة من مصدر النموذج الرسمي."
}
if (-not (Test-Path $ConfigPath) -or (Get-Item $ConfigPath).Length -lt 100) {
  Write-Host 'تنزيل إعدادات النموذج…' -ForegroundColor Yellow
  Invoke-WebRequest -Uri $ConfigUrl -OutFile $ConfigPath -UseBasicParsing
}
try { $null = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json } catch { throw 'ملف إعدادات نموذج الصوت ليس JSON صالحًا.' }

$EnvPath = Join-Path $Root '.env'
if (-not (Test-Path $EnvPath)) { New-Item -ItemType File -Path $EnvPath | Out-Null }
$lines = [System.Collections.Generic.List[string]]::new()
$lines.AddRange([string[]](Get-Content -Path $EnvPath -ErrorAction SilentlyContinue))
function Set-EnvValue([string]$Key, [string]$Value) {
  $found = $false
  for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match "^\s*$([regex]::Escape($Key))=") { $lines[$i] = "$Key=$Value"; $found = $true }
  }
  if (-not $found) { $lines.Add("$Key=$Value") }
}
Set-EnvValue 'PIPER_BIN' $Piper
Set-EnvValue 'PIPER_MODEL_PATH' $ModelPath
Set-EnvValue 'TTS_REQUIRE_PROOFREAD' 'true'
$Ffmpeg = Get-Command ffmpeg -ErrorAction SilentlyContinue
if ($Ffmpeg) {
  Set-EnvValue 'FFMPEG_BIN' $Ffmpeg.Source
  Write-Host "وجدت FFmpeg: $($Ffmpeg.Source)" -ForegroundColor Green
} else {
  Set-EnvValue 'FFMPEG_BIN' 'ffmpeg'
  Write-Host 'FFmpeg غير موجود؛ لن يمكن إرسال OGG/Opus حتى تثبيته.' -ForegroundColor Yellow
  Write-Host 'يمكنك تثبيته من Terminal (مسؤول): winget install --id Gyan.FFmpeg.Shared -e'
}
Set-Content -Path $EnvPath -Value $lines -Encoding utf8

Write-Host ''
Write-Host 'اكتمل إعداد Piper ونموذج العربية والتحقق من بصمته.' -ForegroundColor Green
Write-Host 'أعد تشغيل chat BOT. لإرسال الصوت، يحتاج التدقيق اللغوي إلى Ollama ونموذج عربي محلي مثبت؛ سيمنع البوت الإرسال الصوتي إذا لم ينجح التدقيق ما دام TTS_REQUIRE_PROOFREAD=true.'
Write-Host 'تحقق من Ollama باستخدام: ollama list'
if (-not $Ffmpeg) { Write-Host 'بعد تثبيت FFmpeg، أعد تشغيل البرنامج ثم تحقق من حالة النطق في «المحركات الذكية».' }
Read-Host 'اضغط Enter للإغلاق'
