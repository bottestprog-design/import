@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title chat BOT - إعداد الصوت المحلي الكامل

echo ============================================================
echo  chat BOT - Whisper + Piper + مدقق عربي محلي
echo ============================================================
echo يحتاج اتصال إنترنت لتنزيل المحركات والنماذج أول مرة.
echo بعد التنزيل تتم معالجة الصوت محليًا؛ لا تُرفع التسجيلات إلى خدمة صوت سحابية.
echo.

echo [1/3] إعداد Whisper لتفريغ الصوت إلى نص...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup-whisper.ps1"
if errorlevel 1 goto :failed

echo.
echo [2/3] إعداد Piper لإنتاج الردود الصوتية العربية...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup-tts.ps1"
if errorlevel 1 goto :failed

echo.
echo [3/3] فحص وتجهيز Ollama والنموذج المحلي للتدقيق قبل النطق...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup-local-ai.ps1"
if errorlevel 1 goto :failed

echo.
echo انتهت خطوات الإعداد. راجع التحذيرات: رفض تنزيل Ollama أو النموذج يعني أن التدقيق الإلزامي لن يرسل صوتًا حتى يكتمل هذا المكون.
echo افتح واجهة chat BOT ثم افحص حالة التفريغ وحالة النطق.
echo إذا حذر البرنامج من FFmpeg أو Ollama/نموذج التدقيق المحلي، اتبع الرسالة الظاهرة؛ لا يعني نجاح تنزيل المحركات أن هذه الاعتماديات الإضافية مثبتة.
echo.
pause
exit /b 0

:failed
echo.
echo لم يكتمل إعداد كل مكونات الصوت. راجع الخطأ الظاهر أعلاه.
echo إذا نجح Whisper وفشل Piper، يمكنك استخدام التفريغ النصي بينما تكمل إعداد النطق بشكل مستقل.
pause
exit /b 1
