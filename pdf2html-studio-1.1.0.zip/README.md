# PDF2HTML Studio

**Local-first high-fidelity PDF → standalone HTML studio.**

The product treats the PDF as the visual source of truth and layers searchable/selectable text, links, semantic structure, inspection, OCR fallback, and automated visual QA around that visual foundation.

## Current version

`1.1.0`

## Highlights

- Local-only FastAPI application.
- Async conversion queue with real progress and job state.
- Multi-page PDF analysis with page classification.
- Ultra pixel-locked raster visual layer by default, with SVG as an advanced alternative and a transparent selectable-text overlay.
- Balanced and Semantic modes.
- Selectable text overlay + search index.
- Arabic + English OCR fallback through Tesseract/PyMuPDF.
- Table discovery and semantic table reconstruction.
- Links with unsafe-scheme filtering.
- Extracted-font discovery/embedding when possible.
- Standalone, offline-capable single-file HTML.
- Project ZIP + manifest + thumbnails.
- Chromium browser rendering for true preview validation.
- Pixel-level visual diff with error metrics, regions, and alignment probe.
- Conversion-time quality gate with configurable threshold and downloadable quality report.
- PDF form/annotation interaction overlays that do not disturb the visual source of truth.
- Optional standalone Content-Security-Policy for self-contained artifacts.
- Parallel all-page validation.
- Preview / Compare / Overlay / Diff workspace.
- Inspector bridge for text/vector/link elements.
- Responsive RTL UI, keyboard navigation, quality dashboard.
- Local conversion cache keyed by source hash + options + engine version.
- Batch analyze/convert (up to 12 local files).
- User-cancellable conversion jobs and resource quotas.
- Workspace/job inventory endpoints.
- Standalone viewer toolbar with search, navigation, print, semantic editing, and edited-HTML export.
- Local form-value persistence keyed to the source hash.
- Stronger PDF signature/page-count validation and safer filenames.

## Run locally

### Recommended (Windows / Linux / macOS)

```bash
python run_local.py --open
```

On the first run the launcher creates a project-local `.venv`, installs the pinned Python dependencies, and uses an existing local Chrome/Edge/Chromium when available. If no compatible local browser is found, it installs the local Playwright Chromium browser used for visual QA. **This setup step may use the internet once; the application itself does not use a cloud/API service at runtime.**

To run diagnostics without starting the server:

```bash
python run_local.py --doctor
```

Local engine self-check:

```bash
python run_local.py --self-test
```

To intentionally use the current Python environment without automatic setup:

```bash
python run_local.py --no-bootstrap
```

On Windows you can also double-click `install_local.bat` once, then use `run_local.bat --open`.

Release audits:

```bash
python tools/audit_frontend.py
python tools/audit_release.py
```

Open `http://127.0.0.1:8000`.

## Test

```bash
pytest -q
```

Chromium should be installed for visual validation. Tesseract plus the requested language packs are required for OCR.

## Fidelity philosophy

The converter does not assume OCR or semantic HTML can reproduce arbitrary PDF geometry. The default Ultra mode embeds a PDF-native raster render at the QA DPI to minimize browser rasterization drift; SVG remains available as an advanced vector backend, while selectable text and semantic layers are overlays. Visual QA is performed by rendering the generated HTML in Chromium and comparing it against a PDF reference render.

A high score on a fixture is not a guarantee for every PDF. Unembedded fonts, unusual PDF operators, scanned documents, annotations, transparency, and malformed files can require additional fallbacks.

## License note

Review the license terms of every bundled component before distributing a packaged product, particularly PDF engines and OCR/model assets.


### Batch export and retry

The local API supports `/api/batch-export` for bundling completed project ZIPs and `/api/retry/{job_id}` for re-running a completed/failed job with its saved options. No remote service is used.

### Local storage controls

All workspace data stays under the local `workspace/` directory. Old jobs can be cleaned from the UI, and `DELETE /api/cache` clears only the local conversion cache.
