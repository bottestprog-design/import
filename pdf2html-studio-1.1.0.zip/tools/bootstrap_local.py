from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import venv
import shutil

ROOT = Path(__file__).resolve().parents[1]
VENV_DIR = ROOT / ".venv"
LOCK_FILE = ROOT / "requirements-lock.txt"
RUNTIME_REQUIREMENTS = (
    ("fastapi", "fastapi"),
    ("uvicorn", "uvicorn"),
    ("pymupdf", "PyMuPDF"),
    ("PIL", "Pillow"),
    ("multipart", "python-multipart"),
    ("pydantic", "pydantic"),
    ("playwright", "playwright"),
)


def venv_python(root: Path = VENV_DIR) -> Path:
    if os.name == "nt":
        return root / "Scripts" / "python.exe"
    return root / "bin" / "python"


def _run(python: Path, args: list[str], *, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run([str(python), *args], cwd=ROOT, text=True, check=check)


def _missing_modules(python: Path) -> list[str]:
    code = (
        "import importlib.util, json; "
        "mods=" + repr([m for m, _ in RUNTIME_REQUIREMENTS]) + "; "
        "print(json.dumps([m for m in mods if importlib.util.find_spec(m) is None]))"
    )
    result = subprocess.run([str(python), "-c", code], cwd=ROOT, capture_output=True, text=True, check=True)
    import json
    return list(json.loads(result.stdout or "[]"))


def locked_versions() -> dict[str, str]:
    versions: dict[str, str] = {}
    if not LOCK_FILE.is_file():
        return versions
    for raw in LOCK_FILE.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "==" not in line:
            continue
        name, version = line.split("==", 1)
        dist = name.split("[", 1)[0].strip().lower().replace("_", "-")
        versions[dist] = version.strip()
    return versions


def _environment_python_version(python: Path) -> tuple[int, int] | None:
    try:
        result = subprocess.run(
            [str(python), "-c", "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"],
            cwd=ROOT, capture_output=True, text=True, check=False, timeout=8,
        )
        if result.returncode != 0:
            return None
        major, minor = (int(x) for x in result.stdout.strip().split(".", 1))
        return major, minor
    except (OSError, ValueError, subprocess.TimeoutExpired):
        return None


def _installed_mismatches(python: Path) -> dict[str, dict[str, str | None]]:
    locked = locked_versions()
    if not locked:
        return {}
    code = """import importlib.metadata,json
names = %r
out = {}
for n in names:
    try:
        out[n] = importlib.metadata.version(n)
    except importlib.metadata.PackageNotFoundError:
        out[n] = None
print(json.dumps(out))
""" % sorted(locked)
    result = subprocess.run([str(python), "-c", code], cwd=ROOT, capture_output=True, text=True, check=False, timeout=12)
    if result.returncode != 0:
        return {name: {"expected": version, "installed": None} for name, version in locked.items()}
    try:
        installed = json.loads(result.stdout or "{}")
    except json.JSONDecodeError:
        installed = {}
    return {
        name: {"expected": expected, "installed": installed.get(name)}
        for name, expected in locked.items()
        if installed.get(name) != expected
    }


def ensure_venv() -> Path:
    py = venv_python()
    current_version = (sys.version_info.major, sys.version_info.minor)
    if py.exists() and not _environment_python_version(py) == current_version:
        print("[setup] البيئة المحلية موجودة لكن مبنية على Python مختلف؛ إعادة إنشائها…")
        import shutil
        shutil.rmtree(VENV_DIR, ignore_errors=True)
    if not py.exists():
        print(f"[setup] إنشاء البيئة المحلية: {VENV_DIR}")
        venv.EnvBuilder(with_pip=True, clear=False, symlinks=False).create(VENV_DIR)
    if not py.exists():
        raise RuntimeError("تعذر إنشاء بيئة Python المحلية .venv.")
    return py


def install_runtime(py: Path) -> None:
    if not LOCK_FILE.is_file():
        raise RuntimeError(f"ملف المتطلبات غير موجود: {LOCK_FILE}")
    print("[setup] تثبيت الاعتماديات المحلية المثبتة versions…")
    try:
        _run(py, ["-m", "pip", "--disable-pip-version-check", "install", "--only-binary=PyMuPDF", "-r", str(LOCK_FILE)])
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            "تعذر تثبيت الاعتماديات. تحقق من اتصال الإنترنت أثناء التثبيت الأول أو ثبّت الحزم محليًا ثم أعد التشغيل بـ --no-bootstrap."
        ) from exc



def system_browser_available() -> bool:
    program_files = os.environ.get("PROGRAMFILES", r"C:\Program Files")
    program_files_x86 = os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")
    local_app_data = os.environ.get("LOCALAPPDATA", "")
    candidates = (
        os.environ.get("P2H_BROWSER_EXE"),
        os.environ.get("CHROMIUM_PATH"),
        shutil.which("chromium"), shutil.which("chromium-browser"),
        shutil.which("google-chrome"), shutil.which("chrome"), shutil.which("msedge"),
        Path(program_files) / "Google/Chrome/Application/chrome.exe",
        Path(program_files_x86) / "Google/Chrome/Application/chrome.exe",
        Path(local_app_data) / "Google/Chrome/Application/chrome.exe",
        Path(program_files) / "Microsoft/Edge/Application/msedge.exe",
        Path(program_files_x86) / "Microsoft/Edge/Application/msedge.exe",
        Path(local_app_data) / "Microsoft/Edge/Application/msedge.exe",
        Path("/usr/bin/chromium"), Path("/usr/bin/chromium-browser"),
    )
    return any(bool(c) and Path(c).exists() for c in candidates)

def verify_imports(py: Path) -> None:
    code = "import pymupdf, fastapi, uvicorn, PIL, multipart, pydantic, playwright; print('ok')"
    result = subprocess.run([str(py), "-c", code], cwd=ROOT, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "unknown import error").strip()
        raise RuntimeError(f"فشل تحميل إحدى الاعتماديات بعد التثبيت: {detail}")


def playwright_browser_installed(py: Path) -> bool:
    try:
        result = subprocess.run(
            [str(py), "-m", "playwright", "install", "--list"],
            cwd=ROOT,
            capture_output=True,
            text=True,
            check=False,
            timeout=12,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    text = (result.stdout or "") + "\n" + (result.stderr or "")
    return result.returncode == 0 and any(name in text.lower() for name in ("chromium", "chrome for testing"))


def ensure_playwright_chromium(py: Path) -> None:
    if os.environ.get("P2H_SKIP_BROWSER", "0") == "1":
        print("[setup] تم تخطي تثبيت Chromium بسبب P2H_SKIP_BROWSER=1")
        return
    if system_browser_available():
        print("[setup] تم اكتشاف Chrome/Edge/Chromium محلي؛ لن يتم تنزيل Browser إضافي.")
        return
    if playwright_browser_installed(py):
        return
    print("[setup] تثبيت Chromium المحلي لـPlaywright…")
    try:
        _run(py, ["-m", "playwright", "install", "chromium"])
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            "تم تثبيت Python dependencies، لكن تعذر تنزيل Chromium المحلي. "
            "يمكنك تثبيته لاحقًا بالأمر: python -m playwright install chromium"
        ) from exc


def environment_report(py: Path) -> dict[str, object]:
    import json
    result = subprocess.run([str(py), "-c", "import sys,json; print(json.dumps({'python':sys.version,'executable':sys.executable}))"], cwd=ROOT, capture_output=True, text=True, check=True)
    report = json.loads(result.stdout)
    report.update({"platform": platform.platform(), "venv": str(VENV_DIR)})
    report["missing_modules"] = _missing_modules(py)
    report["locked_version_mismatches"] = _installed_mismatches(py)
    report["playwright_chromium"] = playwright_browser_installed(py)
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="PDF2HTML Studio local runtime bootstrap")
    parser.add_argument("--check", action="store_true", help="فحص البيئة فقط")
    parser.add_argument("--no-browser", action="store_true", help="لا تثبت Chromium")
    args = parser.parse_args(argv)

    current = Path(sys.executable).resolve()
    in_project_venv = current.parent in {VENV_DIR / "Scripts", VENV_DIR / "bin"}
    if args.check:
        py = current if in_project_venv else (venv_python() if venv_python().exists() else current)
        report = environment_report(py)
        report["check_only"] = True
        report["would_create_venv"] = not venv_python().exists() and not in_project_venv
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    py = current if in_project_venv else ensure_venv()

    missing = _missing_modules(py)
    mismatches = _installed_mismatches(py)
    if missing or mismatches:
        if mismatches:
            print("[setup] توجد حزم محلية بإصدارات غير مطابقة؛ مزامنة النسخ المثبتة…")
        install_runtime(py)
    verify_imports(py)
    if not args.no_browser and not (system_browser_available() or playwright_browser_installed(py)):
        ensure_playwright_chromium(py)
    print("[setup] البيئة المحلية جاهزة.")
    print(py)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
