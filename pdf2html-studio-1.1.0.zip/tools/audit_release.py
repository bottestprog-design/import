#!/usr/bin/env python3
"""Audit the release tree for accidental cloud/runtime coupling."""
from __future__ import annotations

import re
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
# XML/SVG namespaces are identifiers, not network resources. Reject actual remote
# runtime references while allowing standard SVG namespace declarations.
FORBIDDEN_REMOTE = re.compile(r"https?://(?!(?:www\.)?w3\.org/(?:2000/svg|1999/xlink)(?:[\"\'\s>]|$))|wss?://", re.I)
FORBIDDEN_RUNTIME = {"source.pdf", "source-info.json", "state.json", "result.json"}
SKIP_DIRS = {".git", "__pycache__", "workspace", ".venv", ".pytest_cache"}


def text_files():
    for p in ROOT.rglob("*"):
        if not p.is_file() or any(part in SKIP_DIRS for part in p.parts):
            continue
        if p.suffix.lower() in {".py", ".js", ".css", ".html", ".md", ".json", ".toml", ".bat", ".cmd", ".ps1", ".sh", ".txt"}:
            yield p


def is_runtime_source(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    return bool(rel.parts and rel.parts[0] in {"frontend", "backend", "tools"})


def audit_text(text: str) -> bool:
    return bool(FORBIDDEN_REMOTE.search(text))


def main() -> int:
    failures = []
    for p in text_files():
        try:
            text = p.read_text(encoding="utf-8")
        except Exception:
            continue
        if is_runtime_source(p) and audit_text(text):
            failures.append(f"remote runtime reference: {p.relative_to(ROOT)}")

    for z in ROOT.glob("*.zip"):
        try:
            with zipfile.ZipFile(z) as archive:
                names = archive.namelist()
                for n in names:
                    if Path(n).name in FORBIDDEN_RUNTIME:
                        failures.append(f"runtime file leaked into ZIP: {z.name}:{n}")
                if "index.html" in names:
                    html = archive.read("index.html").decode("utf-8", errors="ignore")
                    if audit_text(html):
                        failures.append(f"remote runtime reference in standalone HTML: {z.name}")
        except (OSError, zipfile.BadZipFile) as exc:
            failures.append(f"cannot audit archive {z.name}: {exc}")

    if failures:
        print("FAIL")
        print("\n".join(failures))
        return 1
    print("PASS — release tree is local-first and no forbidden runtime refs were found")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
