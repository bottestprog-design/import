#!/usr/bin/env python3
"""Static audit for DOM selectors used by the local frontend."""
from __future__ import annotations
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
js = (ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
ids = set(re.findall(r'\bid=["\']([^"\']+)["\']', html))
refs = set(re.findall(r"\$\(\s*['\"]#([^'\"]+)['\"]\s*\)", js))
missing = sorted(refs - ids)
if missing:
    print("FAIL — missing DOM ids:")
    print("\n".join(missing))
    raise SystemExit(1)
if "##" in js:
    print("FAIL — suspicious double-hash selector")
    raise SystemExit(1)
print(f"PASS — {len(refs)} direct DOM id selectors resolve")
