from __future__ import annotations

import hashlib
import subprocess
import sys
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSION = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
OUT = ROOT.parent / f"pdf2html-studio-{VERSION}.zip"
SHA = ROOT.parent / f"pdf2html-studio-{VERSION}.zip.sha256"

EXCLUDED_DIRS = {".git", ".pytest_cache", "__pycache__", "workspace", ".venv", "node_modules"}
EXCLUDED_NAMES = {"source.pdf", "state.json", "result.json", "source-info.json"}

def main() -> int:
    subprocess.run([sys.executable, "tools/audit_frontend.py"], cwd=ROOT, check=True)
    subprocess.run([sys.executable, "tools/audit_release.py"], cwd=ROOT, check=True)
    subprocess.run([sys.executable, "-m", "compileall", "-q", "backend", "tests", "tools", "run_local.py"], cwd=ROOT, check=True)
    if OUT.exists(): OUT.unlink()
    with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(ROOT.rglob("*")):
            if not path.is_file() or path.name in EXCLUDED_NAMES:
                continue
            rel = path.relative_to(ROOT)
            if any(part in EXCLUDED_DIRS or part.endswith(".pyc") for part in rel.parts):
                continue
            z.write(path, rel.as_posix())
    digest = hashlib.sha256(OUT.read_bytes()).hexdigest()
    SHA.write_text(digest + "  " + OUT.name + "\n", encoding="utf-8")
    print(OUT)
    print(digest)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
