from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import webbrowser

ROOT = Path(__file__).resolve().parent
VENV_DIR = ROOT / ".venv"


def _venv_python() -> Path:
    return (VENV_DIR / "Scripts" / "python.exe") if os.name == "nt" else (VENV_DIR / "bin" / "python")


def _inside_local_venv() -> bool:
    try:
        return Path(sys.executable).resolve().parent == _venv_python().resolve().parent
    except OSError:
        return False


def _bootstrap(no_bootstrap: bool, no_browser: bool) -> Path:
    target = _venv_python()
    if _inside_local_venv():
        return Path(sys.executable).resolve()
    if no_bootstrap:
        return Path(sys.executable).resolve()
    command = [sys.executable, str(ROOT / "tools" / "bootstrap_local.py")]
    if no_browser:
        command.append("--no-browser")
    env = os.environ.copy()
    env["P2H_BOOTSTRAP_PARENT"] = "1"
    subprocess.run(command, cwd=ROOT, check=True, env=env)
    if not target.exists():
        raise RuntimeError(f"لم يتم إنشاء Python المحلي المتوقع: {target}")
    return target


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="PDF2HTML Studio — Local launcher")
    parser.add_argument("--open", action="store_true", help="فتح المتصفح تلقائيًا")
    parser.add_argument("--no-bootstrap", action="store_true", help="استخدم Python الحالي دون تثبيت الاعتماديات")
    parser.add_argument("--no-browser", action="store_true", help="لا تثبت Chromium أثناء الإعداد")
    parser.add_argument("--self-test", action="store_true", help="تشغيل self-test ثم الخروج")
    parser.add_argument("--doctor", action="store_true", help="تشخيص البيئة ثم الخروج")
    args, passthrough = parser.parse_known_args(argv)

    # Doctor is intentionally read-only: it must never download/install anything.
    if args.doctor and not args.no_bootstrap:
        command = [sys.executable, str(ROOT / "tools" / "bootstrap_local.py"), "--check"]
        try:
            result = subprocess.run(command, cwd=ROOT, check=False)
        except OSError as exc:
            print(f"\n[DOCTOR ERROR] تعذر تشغيل أداة التشخيص: {exc}\n", file=sys.stderr)
            return 1
        return int(result.returncode)

    try:
        python = _bootstrap(args.no_bootstrap, args.no_browser)
    except (RuntimeError, subprocess.CalledProcessError, OSError) as exc:
        print(f"\n[SETUP ERROR] {exc}\n", file=sys.stderr)
        print("حل يدوي: python -m pip install -r requirements-lock.txt", file=sys.stderr)
        print("أو شغّل install_local.bat / install_local.ps1 على Windows.", file=sys.stderr)
        return 1

    if python.resolve() != Path(sys.executable).resolve():
        if args.self_test:
            cmd = [str(python), str(ROOT / "run_local.py"), "--self-test", "--no-bootstrap"]
        elif args.doctor:
            cmd = [str(python), str(ROOT / "run_local.py"), "--doctor", "--no-bootstrap"]
        else:
            cmd = [str(python), str(ROOT / "run_local.py"), "--no-bootstrap"] + passthrough
            if args.open:
                cmd.append("--open")
        env = os.environ.copy()
        env["P2H_BOOTSTRAPPED"] = "1"
        return subprocess.run(cmd, cwd=ROOT, env=env).returncode

    if args.doctor:
        from backend.app.runtime import diagnostic_report
        import json
        print(json.dumps(diagnostic_report(ROOT), ensure_ascii=False, indent=2))
        return 0

    if args.self_test:
        import json
        from backend.app.main import self_test
        result = self_test()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("ok") else 1

    host = os.environ.get("PDF2HTML_HOST", "127.0.0.1")
    port = os.environ.get("PDF2HTML_PORT", "8000")
    url = f"http://{host}:{port}"
    open_browser = args.open or os.environ.get("PDF2HTML_OPEN_BROWSER", "0") == "1"

    print(f"PDF2HTML Studio → {url}")
    print("Local-only runtime: conversion, OCR, rendering, QA, cache and history stay on this device.")
    print("First-run setup may download Python packages and the local Playwright Chromium browser.")

    if open_browser:
        def _open_later() -> None:
            time.sleep(0.8)
            try:
                webbrowser.open(url)
            except Exception:
                pass
        threading.Thread(target=_open_later, daemon=True).start()

    cmd = [str(python), "-m", "uvicorn", "backend.app.main:app", "--host", host, "--port", port]
    completed = subprocess.run(cmd, cwd=ROOT, check=False)
    return int(completed.returncode)


if __name__ == "__main__":
    raise SystemExit(main())
