from __future__ import annotations

import base64
import io
import json
from pathlib import Path
from typing import Any

import pymupdf as fitz
from PIL import Image

from .validator import validate_page


def _data_uri(payload: bytes, mime: str = "image/png") -> str:
    return f"data:{mime};base64,{base64.b64encode(payload).decode('ascii')}"


def _merge_regions(regions: list[dict[str, Any]], max_regions: int = 20, gap: int = 6) -> list[dict[str, Any]]:
    boxes: list[list[int]] = []
    for r in sorted(regions, key=lambda x: x.get("changed_percent", 0), reverse=True):
        x0, y0 = int(r["x"]), int(r["y"])
        x1, y1 = x0 + int(r["width"]), y0 + int(r["height"])
        merged = False
        for b in boxes:
            bx0, by0, bx1, by1 = b
            if not (x1 + gap < bx0 or bx1 + gap < x0 or y1 + gap < by0 or by1 + gap < y0):
                b[0], b[1], b[2], b[3] = min(bx0, x0), min(by0, y0), max(bx1, x1), max(by1, y1)
                merged = True
                break
        if not merged:
            boxes.append([x0, y0, x1, y1])
        if len(boxes) >= max_regions * 2:
            break
    changed = True
    while changed:
        changed = False
        merged_boxes: list[list[int]] = []
        for b in boxes:
            found = False
            for o in merged_boxes:
                if not (b[2] + gap < o[0] or o[2] + gap < b[0] or b[3] + gap < o[1] or o[3] + gap < b[1]):
                    o[0], o[1], o[2], o[3] = min(o[0], b[0]), min(o[1], b[1]), max(o[2], b[2]), max(o[3], b[3])
                    changed = True
                    found = True
                    break
            if not found:
                merged_boxes.append(b)
        boxes = merged_boxes
    return [{"x": b[0], "y": b[1], "width": b[2]-b[0], "height": b[3]-b[1]} for b in boxes[:max_regions]]


def _render_reference(pdf_path: Path, page_number: int, dpi: int) -> Image.Image:
    with fitz.open(pdf_path) as doc:
        pix = doc[page_number - 1].get_pixmap(dpi=dpi, alpha=False)
        return Image.open(io.BytesIO(pix.tobytes("png"))).convert("RGB")


def _load_page_elements(out_dir: Path, page_number: int) -> list[dict[str, Any]]:
    path = out_dir / "reference" / "elements.json"
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return []
    if not isinstance(data, list) or page_number < 1 or page_number > len(data):
        return []
    return list((data[page_number - 1] or {}).get("elements", []) or [])


def _intersection_area(a: dict[str, Any], bbox: list[float]) -> float:
    x0, y0 = max(float(a.get("x", 0)), float(bbox[0])), max(float(a.get("y", 0)), float(bbox[1]))
    x1, y1 = min(float(a.get("x", 0)) + float(a.get("width", 0)), float(bbox[2])), min(float(a.get("y", 0)) + float(a.get("height", 0)), float(bbox[3]))
    return max(0.0, x1 - x0) * max(0.0, y1 - y0)


def _attribute_regions(regions: list[dict[str, Any]], elements: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not elements:
        return [dict(r, element_ids=[], best_element=None) for r in regions]
    attributed = []
    for region in regions:
        bbox = [float(region["x"]), float(region["y"]), float(region["x"] + region["width"]), float(region["y"] + region["height"])]
        matches = []
        for element in elements:
            eb = element.get("bbox")
            if not isinstance(eb, list) or len(eb) != 4:
                continue
            area = _intersection_area(region, [float(v) for v in eb])
            if area > 0:
                matches.append((area, str(element.get("id") or ""), str(element.get("kind") or "unknown")))
        matches.sort(reverse=True)
        attributed.append(dict(region, element_ids=[m[1] for m in matches[:6] if m[1]], best_element=(matches[0][1] if matches and matches[0][1] else None), best_element_kind=(matches[0][2] if matches else None)))
    return attributed


def _make_candidate(html_source: str, page_number: int, out_dir: Path, label: str, css: str, extra: str = "") -> Path:
    repair_dir = out_dir / "repair" / f"page-{page_number}"
    repair_dir.mkdir(parents=True, exist_ok=True)
    candidate = repair_dir / f"{label}.html"
    marker = f'<style id="pdf2html-repair-{page_number}-{label}">{css}</style>'
    source = html_source.replace("</head>", marker + "</head>", 1)
    # Inject repair overlays into the requested page only. Replacing the first
    # closing section globally is incorrect for multi-page documents because
    # it silently places page-N repairs on page 1.
    if extra:
        import re
        page_pattern = re.compile(
            rf'(<section\s+class="page-shell"[^>]*\bid="page-{page_number}"[^>]*>)(.*?)(</section>)',
            re.IGNORECASE | re.DOTALL,
        )
        match = page_pattern.search(source)
        if match:
            body = match.group(2) + extra
            source = source[:match.start(2)] + body + source[match.end(2):]
    candidate.write_text(source, encoding="utf-8")
    return candidate


def build_patch_candidate(pdf_path: Path, html_path: Path, page_number: int, out_dir: Path, dpi: int = 144, max_regions: int = 20) -> dict[str, Any]:
    baseline = validate_page(pdf_path, html_path, page_number, dpi, out_dir, alignment_probe=True)
    source_html = html_path.read_text(encoding="utf-8")
    best = baseline
    best_candidate: Path | None = None
    best_strategy: dict[str, Any] | None = None
    repair_dir = out_dir / "repair" / f"page-{page_number}"
    repair_dir.mkdir(parents=True, exist_ok=True)

    alignment = baseline.get("alignment") or {"dx": 0, "dy": 0}
    dx, dy = int(alignment.get("dx", 0)), int(alignment.get("dy", 0))
    strategies: list[tuple[str, str, str, int, int]] = []
    if dx or dy:
        for selector in (f"#page-{page_number} > .page-visual", f"#page-{page_number} > .repair-layer"):
            strategies.append(("alignment", selector, f"transform:translate({dx}px,{dy}px);", dx, dy))
            strategies.append(("alignment-inverse", selector, f"transform:translate({-dx}px,{-dy}px);", -dx, -dy))
    # For SVG pages, tiny layer shifts can correct browser/subpixel drift without changing text semantics.
    for selector in (f"#page-{page_number} > .page-visual", f"#page-{page_number} > .text-layer", f"#page-{page_number} > .semantic-layer"):
        strategies.extend([(f"micro-{i}", selector, f"transform:translate({sx}px,{sy}px);", sx, sy) for i,(sx,sy) in enumerate(((1,0),(-1,0),(0,1),(0,-1)),1)])
    for idx, (kind, selector, rule, sx, sy) in enumerate(strategies[:24], 1):
        candidate = _make_candidate(source_html, page_number, out_dir, f"transform-{idx}", f"{selector}{{{rule}}}")
        result = validate_page(pdf_path, candidate, page_number, dpi, out_dir, alignment_probe=False)
        if result["score"] > best["score"] + 0.005:
            if best_candidate and best_candidate != candidate:
                best_candidate.unlink(missing_ok=True)
            best, best_candidate, best_strategy = result, candidate, {"kind": kind, "selector": selector, "dx": sx, "dy": sy}
        else:
            candidate.unlink(missing_ok=True)

    # Selective rasterization: copy only the highest-error reference regions into an overlay.
    regions = _merge_regions(best.get("regions") or [], max_regions=max_regions)
    elements = _load_page_elements(out_dir, page_number)
    regions = _attribute_regions(regions, elements)
    patch_count = 0
    if regions:
        ref = _render_reference(pdf_path, page_number, dpi)
        scale = dpi / 72.0
        padding = 2
        patch_imgs: list[str] = []
        patch_meta: list[dict[str, Any]] = []
        for idx, region in enumerate(regions, 1):
            x0 = max(0, int(region["x"]) - padding); y0 = max(0, int(region["y"]) - padding)
            x1 = min(ref.width, int(region["x"] + region["width"]) + padding); y1 = min(ref.height, int(region["y"] + region["height"]) + padding)
            if x1 <= x0 or y1 <= y0: continue
            crop = ref.crop((x0,y0,x1,y1)); buf=io.BytesIO(); crop.save(buf,format="PNG",optimize=True)
            patch_imgs.append(f'<img class="repair-patch" data-repair-index="{idx}" src="{_data_uri(buf.getvalue())}" alt="" draggable="false" style="left:{x0/scale:.4f}px;top:{y0/scale:.4f}px;width:{(x1-x0)/scale:.4f}px;height:{(y1-y0)/scale:.4f}px">')
            patch_meta.append({"index":idx,"x_px":x0,"y_px":y0,"width_px":x1-x0,"height_px":y1-y0,"element_ids":list(region.get("element_ids") or []),"best_element":region.get("best_element"),"best_element_kind":region.get("best_element_kind")})
        if patch_imgs:
            layer = '<div class="repair-layer" aria-hidden="true"><div class="repair-patches">' + ''.join(patch_imgs) + '</div></div>'
            css = '.repair-layer{position:absolute;inset:0;z-index:5;pointer-events:none;overflow:hidden}.repair-patches{position:absolute;inset:0}.repair-patch{position:absolute;display:block;object-fit:fill;pointer-events:none;user-select:none}'
            candidate = _make_candidate(source_html if best_candidate is None else best_candidate.read_text(encoding="utf-8"), page_number, out_dir, "patch-candidate", css, layer)
            result = validate_page(pdf_path, candidate, page_number, dpi, out_dir, alignment_probe=True)
            if result["score"] > best["score"] + 0.005:
                if best_candidate and best_candidate != candidate:
                    best_candidate.unlink(missing_ok=True)
                best, best_candidate, patch_count, best_strategy = result, candidate, len(patch_imgs), {"kind":"selective-raster-patches", "patch_count":len(patch_imgs)}
            else:
                candidate.unlink(missing_ok=True)

    if not best_candidate:
        summary = {"ok": True, "improved": False, "before": baseline["score"], "after": baseline["score"], "patch_count": 0, "strategy": None, "attributed_regions": regions, "message": "لم يُعثر على إصلاح آمن يحسن النتيجة."}
    else:
        canonical_candidate = repair_dir / "candidate.html"
        best_candidate.replace(canonical_candidate)
        summary = {"ok": True, "improved": True, "before": baseline["score"], "after": best["score"], "patch_count": patch_count, "strategy": best_strategy, "candidate": str(canonical_candidate), "attributed_regions": regions, "message": "تم إنشاء مرشح إصلاح محلي بعد مقارنة عدة تعديلات."}
    (repair_dir / "repair.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
    return summary
