from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
VERSION_FILE = ROOT / "VERSION"
try:
    VERSION = VERSION_FILE.read_text(encoding="utf-8").strip() or "1.1.0"
except OSError:
    VERSION = "1.1.0"
