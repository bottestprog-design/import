from __future__ import annotations

import os

# Keep the local CLI/UI noise-free unless the optional layout analyzer is explicitly enabled.
os.environ.setdefault("PYMUPDF_SUGGEST_LAYOUT_ANALYZER", "0")
