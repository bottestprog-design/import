from __future__ import annotations

import base64
import hashlib
import html
import json
import math
import mimetypes
import re
import unicodedata
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import pymupdf as fitz

from .version import VERSION


ProgressCallback = Callable[[int, str], None]


@dataclass
class ConvertedDocument:
    html: str
    metadata: dict[str, Any]
    page_count: int
    page_sizes: list[tuple[float, float]]
    page_reports: list[dict[str, Any]]
    reference_dir: Path
    search_index: list[dict[str, Any]]


def _data_uri(mime: str, payload: bytes) -> str:
    return f"data:{mime};base64,{base64.b64encode(payload).decode('ascii')}"


def _css_num(value: float) -> str:
    return f"{float(value):.4f}".rstrip("0").rstrip(".")


def _safe_json(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _normalize_extracted_text(text: str, reverse_rtl: bool = False) -> str:
    """Repair a common PDF extraction artifact where Arabic presentation forms are reversed."""
    raw = str(text or "")
    has_presentation_forms = bool(re.search(r"[\uFB50-\uFDFF\uFE70-\uFEFF]", raw))
    normalized = unicodedata.normalize("NFKC", raw)
    arabic_run = re.compile(r"[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]+")
    if has_presentation_forms:
        return arabic_run.sub(lambda m: m.group(0)[::-1], normalized)
    return normalized


def _language_guess(text: str) -> str:
    if not text.strip():
        return "unknown"
    arabic = len(re.findall(r"[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]", text))
    latin = len(re.findall(r"[A-Za-z]", text))
    cjk = len(re.findall(r"[\u3040-\u30FF\u3400-\u9FFF]", text))
    if arabic and latin:
        return "ar+en"
    if arabic:
        return "ar"
    if cjk:
        return "cjk"
    if latin:
        return "en"
    return "other"


def _complexity(page: fitz.Page, text_chars: int, drawings: int, images: int, tables: int = 0) -> str:
    score = 0
    if drawings > 800:
        score += 3
    elif drawings > 250:
        score += 2
    elif drawings > 80:
        score += 1
    if images > 20:
        score += 2
    elif images > 5:
        score += 1
    if text_chars > 15000:
        score += 2
    elif text_chars > 5000:
        score += 1
    if tables > 4:
        score += 2
    elif tables:
        score += 1
    if score >= 6:
        return "very-high"
    if score >= 3:
        return "high"
    if score >= 1:
        return "medium"
    return "low"


def _find_tables(page: fitz.Page) -> list[dict[str, Any]]:
    """Detect tables and enrich cells with recoverable grid geometry."""
    try:
        finder = page.find_tables()
        tables = []
        for idx, table in enumerate(finder.tables, start=1):
            rows = []
            try:
                extracted = table.extract()
                rows = [["" if cell is None else str(cell) for cell in row] for row in extracted]
            except Exception:
                pass
            raw_cells = list(getattr(table, "cells", []) or [])
            cells = [None if cell is None else [float(v) for v in cell] for cell in raw_cells]
            x_edges, y_edges = [], []
            for cell in cells:
                if cell:
                    x_edges += [cell[0], cell[2]]
                    y_edges += [cell[1], cell[3]]
            def unique_edges(values):
                result = []
                for value in sorted(values):
                    if not result or abs(result[-1] - value) > 0.75:
                        result.append(value)
                return result
            x_edges, y_edges = unique_edges(x_edges), unique_edges(y_edges)
            details = []
            for cell_index, bbox in enumerate(cells):
                if not bbox: continue
                x0, y0, x1, y1 = bbox
                col = min(range(max(1, len(x_edges)-1)), key=lambda j: abs(x_edges[j]-x0)) if len(x_edges)>1 else 0
                row = min(range(max(1, len(y_edges)-1)), key=lambda j: abs(y_edges[j]-y0)) if len(y_edges)>1 else 0
                col_end = min(range(len(x_edges)), key=lambda j: abs(x_edges[j]-x1)) if x_edges else 1
                row_end = min(range(len(y_edges)), key=lambda j: abs(y_edges[j]-y1)) if y_edges else 1
                text_value = rows[row][col] if row < len(rows) and col < len(rows[row]) else ""
                details.append({"index": cell_index, "row": row, "col": col, "rowspan": max(1,row_end-row), "colspan": max(1,col_end-col), "bbox": bbox, "text": text_value})
            header = getattr(table, "header", None)
            markdown = ""
            try: markdown = str(table.to_markdown())
            except Exception: pass
            tables.append({
                "id": idx, "bbox": [float(v) for v in table.bbox],
                "row_count": int(getattr(table, "row_count", len(rows))),
                "col_count": int(getattr(table, "col_count", max((len(r) for r in rows), default=0))),
                "rows": rows, "cells": cells, "cells_detail": details, "markdown": markdown,
                "header_names": list(getattr(header, "names", []) or []) if header is not None else [],
            })
        return tables
    except Exception:
        return []


def _page_textpage(page: fitz.Page, options: dict[str, Any] | None = None):
    options = options or {}
    native = page.get_text("text", sort=True).strip()
    mode = options.get("ocr_mode", "auto")
    # Avoid expensive OCR on short but genuinely digital pages. In auto mode OCR
    # is reserved for image-heavy/hybrid pages with little native text or pages
    # that contain no native text at all. Force mode remains explicit.
    image_heavy = len(page.get_images(full=True)) > 0
    should_ocr = mode == "force" or (mode == "auto" and (not native or (image_heavy and len(native) < 10)))
    if not should_ocr:
        return None, False
    try:
        tp = page.get_textpage_ocr(
            language=options.get("ocr_languages", "ara+eng"),
            dpi=int(options.get("ocr_dpi", 220)),
            full=True,
        )
        return tp, True
    except Exception:
        return None, False


def _text_dict(page: fitz.Page, textpage=None, reverse_rtl: bool = False) -> dict[str, Any]:
    raw = page.get_text("dict", sort=True, textpage=textpage) if textpage is not None else page.get_text("dict", sort=True)
    for block in raw.get("blocks", []):
        if block.get("type") != 0:
            continue
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                if "text" in span:
                    span["text"] = _normalize_extracted_text(span.get("text", ""), reverse_rtl=reverse_rtl)
    return raw


def analyze_pdf(path: Path) -> dict[str, Any]:
    with fitz.open(path) as doc:
        pages: list[dict[str, Any]] = []
        try:
            raw_labels = doc.get_page_labels() if hasattr(doc, "get_page_labels") else []
            page_labels = [str(item.get("label") or item.get("prefix") or idx + 1) if isinstance(item, dict) else str(item) for idx, item in enumerate(raw_labels or [])]
        except Exception:
            page_labels = []
        toc = doc.get_toc(simple=True) or []
        for i, page in enumerate(doc):
            raw = _text_dict(page)
            blocks = raw.get("blocks", [])
            text_blocks = 0
            text_spans = 0
            characters = 0
            words = 0
            text = _normalize_extracted_text(page.get_text("text", sort=True))
            for block in blocks:
                if block.get("type") != 0:
                    continue
                text_blocks += 1
                for line in block.get("lines", []):
                    for span in line.get("spans", []):
                        text_spans += 1
                        t = span.get("text", "")
                        characters += len(t)
                        words += len(t.split())
            images = len(page.get_images(full=True))
            drawings = len(page.get_drawings())
            links = len(page.get_links())
            fonts = len(page.get_fonts(full=True))
            annotations = 0
            try:
                annotations = sum(1 for _ in page.annots() or [])
            except Exception:
                pass
            widgets = 0
            try:
                widgets = sum(1 for _ in page.widgets() or [])
            except Exception:
                pass
            tables = _find_tables(page)
            rect = page.rect
            likely_scanned = (not text.strip() and images > 0) or (len(text.strip()) < 10 and images > 0)
            pages.append({
                "number": i + 1,
                "page_label": str(page_labels[i] if i < len(page_labels) else i + 1),
                "width_pt": float(rect.width),
                "height_pt": float(rect.height),
                "width_mm": round(rect.width * 25.4 / 72.0, 2),
                "height_mm": round(rect.height * 25.4 / 72.0, 2),
                "rotation": int(page.rotation),
                "text_blocks": text_blocks,
                "text_spans": text_spans,
                "characters": characters,
                "words": words,
                "images": images,
                "drawings": drawings,
                "links": links,
                "annotations": annotations,
                "widgets": widgets,
                "tables": len(tables),
                "fonts": fonts,
                "has_text": bool(text.strip()),
                "likely_scanned": likely_scanned,
                "language": _language_guess(text),
                "complexity": _complexity(page, characters, drawings, images, len(tables)),
            })
        metadata = dict(doc.metadata or {})
        format_value = str(metadata.get("format") or "")
        version_match = re.search(r"PDF\s+([0-9.]+)", format_value, flags=re.I)
        return {
            "page_count": len(doc),
            "pages": pages,
            "metadata": metadata,
            "toc_entries": len(toc),
            "toc": toc,
            "encrypted": bool(doc.is_encrypted),
            "pdf_version": version_match.group(1) if version_match else "unknown",
            "sha256": _sha256(path),
        }


def render_thumbnails(path: Path, out_dir: Path, dpi: int = 54) -> list[str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    urls: list[str] = []
    with fitz.open(path) as doc:
        for i, page in enumerate(doc, start=1):
            pix = page.get_pixmap(dpi=dpi, alpha=False)
            target = out_dir / f"page-{i}.png"
            pix.save(target)
            urls.append(target.name)
    return urls


def _extract_font_faces(page: fitz.Page) -> list[dict[str, str]]:
    fonts: dict[str, dict[str, str]] = {}
    try:
        for item in page.get_fonts(full=True):
            xref, _, font_type, basefont, name, *_ = item
            if not name or name in fonts:
                continue
            record = {"name": name, "basefont": basefont or name, "type": str(font_type), "data": "", "ext": ""}
            try:
                font_info = page.parent.extract_font(xref)
                ext = str(font_info[1] or "")
                data = font_info[3]
                if data:
                    mime = mimetypes.types_map.get(f".{ext.lower()}", "application/octet-stream")
                    if ext.lower() == "ttf": mime = "font/ttf"
                    elif ext.lower() == "otf": mime = "font/otf"
                    record["data"] = _data_uri(mime, data)
                    record["ext"] = ext
            except Exception:
                pass
            fonts[name] = record
    except Exception:
        pass
    return list(fonts.values())


def _span_style(span: dict[str, Any], bbox: tuple[float, float, float, float], angle: float) -> str:
    color = span.get("color", 0)
    try:
        rgb = ((color >> 16) & 255, (color >> 8) & 255, color & 255)
        css_color = f"rgb({rgb[0]},{rgb[1]},{rgb[2]})"
    except Exception:
        css_color = "transparent"
    font_name = html.escape(str(span.get("font", "")), quote=True)
    flags = int(span.get("flags", 0) or 0)
    weight = "700" if flags & 16 else "400"
    style = "italic" if flags & 2 else "normal"
    x0, y0, x1, y1 = bbox
    fs = float(span.get("size", 10))
    return (
        f"left:{_css_num(x0)}px;top:{_css_num(y0)}px;width:{_css_num(max(0, x1-x0))}px;"
        f"height:{_css_num(max(1, y1-y0))}px;font-size:{_css_num(fs)}px;"
        f"font-family:'{font_name}';font-weight:{weight};font-style:{style};"
        f"color:{css_color};transform:rotate({_css_num(angle)}deg)"
    )


def _search_variants(text: str) -> list[str]:
    base = _normalize_extracted_text(text)
    if not re.search(r"[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]", base):
        return [base]
    variants = [base]
    arabic_run = re.compile(r"[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]+")
    char_reversed = arabic_run.sub(lambda m: m.group(0)[::-1], base)
    if char_reversed != base:
        variants.append(char_reversed)
    words = base.split()
    if len(words) > 1:
        word_reversed = " ".join(reversed(words))
        if word_reversed != base:
            variants.append(word_reversed)
        both = " ".join(reversed(char_reversed.split()))
        if both not in variants and both != base:
            variants.append(both)
    return list(dict.fromkeys(variants))


def _text_layer(page: fitz.Page, textpage=None, reverse_rtl: bool = False) -> tuple[str, list[dict[str, Any]]]:
    raw = _text_dict(page, textpage=textpage)
    spans_out: list[str] = []
    search_entries: list[dict[str, Any]] = []
    counter = 0
    for block in raw.get("blocks", []):
        if block.get("type") != 0:
            continue
        for line in block.get("lines", []):
            direction = line.get("dir", (1, 0))
            angle = math.degrees(math.atan2(direction[1], direction[0])) if direction else 0.0
            for span in line.get("spans", []):
                text = str(span.get("text", ""))
                if not text or not text.strip():
                    continue
                counter += 1
                x0, y0, x1, y1 = span.get("bbox", (0, 0, 0, 0))
                sid = f"text-{counter}"
                direction_attr = "rtl" if re.search(r"[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]", text) else "ltr"
                spans_out.append(
                    f'<span id="{sid}" class="text-span" dir="{direction_attr}" data-kind="text" data-search="1" data-bbox="{",".join(_css_num(v) for v in (x0,y0,x1,y1))}" style="{_span_style(span, (x0,y0,x1,y1), angle)}">{html.escape(text)}</span>'
                )
                search_entries.append({
                    "id": sid,
                    "text": text,
                    "search_variants": _search_variants(text),
                    "bbox": [float(x0), float(y0), float(x1), float(y1)],
                })
    return "\n".join(spans_out), search_entries


def _links_layer(page: fitz.Page, safe_external_links: bool = True) -> str:
    out = []
    for idx, link in enumerate(page.get_links(), start=1):
        rect = link.get("from")
        if not rect:
            continue
        href = link.get("uri")
        internal = False
        if not href:
            dest = link.get("page")
            if isinstance(dest, int) and dest >= 0:
                href = f"#page-{dest + 1}"
                internal = True
        if not href:
            continue
        href_text = str(href).strip()
        if href_text.lower().startswith(("javascript:", "data:", "file:")):
            continue
        target_attrs = ''
        if not internal and safe_external_links:
            target_attrs = ' target="_blank" rel="noopener noreferrer nofollow"'
        out.append(
            f'<a id="link-{idx}" class="link-hotspot" data-kind="link" aria-label="PDF link" href="{html.escape(href_text, quote=True)}" style="left:{_css_num(rect.x0)}px;top:{_css_num(rect.y0)}px;width:{_css_num(rect.width)}px;height:{_css_num(rect.height)}px"{target_attrs}></a>'
        )
    return "\n".join(out)


def _semantic_layer(page: fitz.Page, textpage=None, tables: list[dict[str, Any]] | None = None, semantic_headers: bool = True, reverse_rtl: bool = False) -> str:
    raw = _text_dict(page, textpage=textpage)
    blocks: list[str] = []
    all_spans = []
    for block in raw.get("blocks", []):
        if block.get("type") != 0:
            continue
        text_parts = []
        max_size = 0.0
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                t = span.get("text", "")
                if t:
                    text_parts.append(t)
                    max_size = max(max_size, float(span.get("size", 0)))
        text = " ".join(" ".join(text_parts).split())
        if text:
            all_spans.append((max_size, text, tuple(float(v) for v in block.get("bbox", (0,0,0,0)))))
    median = sorted([s for s, _, _ in all_spans])[len(all_spans)//2] if all_spans else 12.0
    for idx, (size, text, bbox) in enumerate(all_spans, start=1):
        x0, y0, x1, y1 = bbox
        tag = "h2" if semantic_headers and size >= max(median * 1.55, 18) else "p"
        direction_attr = "rtl" if re.search(r"[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]", text) else "ltr"
        blocks.append(
            f'<{tag} class="semantic-node" dir="{direction_attr}" data-kind="semantic" data-bbox="{",".join(_css_num(v) for v in bbox)}" id="semantic-{idx}" style="left:{_css_num(x0)}px;top:{_css_num(y0)}px;width:{_css_num(x1-x0)}px;height:{_css_num(y1-y0)}px">{html.escape(text)}</{tag}>'
        )
    for table in tables or []:
        rows = []
        details = table.get("cells_detail") or []
        by_row = {}
        for cell in details:
            by_row.setdefault(int(cell.get("row", 0)), []).append(cell)
        for row_idx, row in enumerate(table.get("rows", [])):
            tag = "th" if row_idx == 0 else "td"
            row_cells = sorted(by_row.get(row_idx, []), key=lambda c: int(c.get("col", 0)))
            rendered = []
            if row_cells:
                for cell in row_cells:
                    attrs = [f'data-cell-row="{row_idx}"', f'data-cell-col="{int(cell.get("col", 0))}"']
                    if int(cell.get("rowspan",1)) > 1: attrs.append(f'rowspan="{int(cell["rowspan"])}"')
                    if int(cell.get("colspan",1)) > 1: attrs.append(f'colspan="{int(cell["colspan"])}"')
                    if tag == "th":
                        attrs.append('scope="col"')
                    rendered.append(f'<{tag} {" ".join(attrs)}>{html.escape(str(cell.get("text", "")))}</{tag}>')
            else:
                rendered = [f"<{tag}>{html.escape(cell)}</{tag}>" for cell in row]
            rows.append(f'<tr>{"".join(rendered)}</tr>')
        if rows:
            bbox = table["bbox"]
            header_names = list(table.get("header_names") or [])
            caption = html.escape(" • ".join(str(x) for x in header_names if str(x).strip())[:180])
            caption_html = f'<caption class="table-a11y-caption">{caption}</caption>' if caption else ''
            blocks.append(f'<table class="semantic-table" role="table" aria-label="جدول PDF {table.get("id","")}" data-table-id="table-{table.get("id")}" data-kind="table" data-row-count="{table.get("row_count",0)}" data-col-count="{table.get("col_count",0)}" data-bbox="{",".join(_css_num(v) for v in bbox)}" style="left:{_css_num(bbox[0])}px;top:{_css_num(bbox[1])}px;width:{_css_num(bbox[2]-bbox[0])}px;height:{_css_num(bbox[3]-bbox[1])}px">{caption_html}{"".join(rows)}</table>')
    return "\n".join(blocks)


def _annotation_layer(page: fitz.Page) -> str:
    out: list[str] = []
    try:
        annots = page.annots() or []
        for idx, annot in enumerate(annots, start=1):
            rect = annot.rect
            atype = getattr(annot, "type", [0, "Unknown"])
            subtype = str(atype[1] if isinstance(atype, (list, tuple)) and len(atype) > 1 else atype)
            info = getattr(annot, "info", {}) or {}
            content = str(info.get("content") or info.get("subject") or "").strip()
            uri = ""
            try:
                uri = str((annot.get_link() or {}).get("uri") or "")
            except Exception:
                pass
            if uri.lower().startswith(("javascript:", "data:", "file:")):
                uri = ""
            label = content or subtype or "PDF annotation"
            href = f' href="{html.escape(uri, quote=True)}" target="_blank" rel="noopener noreferrer nofollow"' if uri else ""
            out.append(
                f'<a id="annotation-{idx}" class="annotation-hotspot" data-kind="annotation" data-subtype="{html.escape(subtype, quote=True)}" data-content="{html.escape(content, quote=True)}" aria-label="{html.escape(label, quote=True)}"{href} style="left:{_css_num(rect.x0)}px;top:{_css_num(rect.y0)}px;width:{_css_num(rect.width)}px;height:{_css_num(rect.height)}px"></a>'
            )
    except Exception:
        return ""
    return "\n".join(out)


def _widget_layer(page: fitz.Page) -> str:
    out: list[str] = []
    try:
        widgets = page.widgets() or []
        for idx, widget in enumerate(widgets, start=1):
            rect = widget.rect
            ftype = int(getattr(widget, "field_type", 0) or 0)
            value = getattr(widget, "field_value", "")
            value = "" if value is None else str(value)
            name = str(getattr(widget, "field_name", "") or f"field-{idx}")
            label = str(getattr(widget, "field_label", "") or name)
            common = (
                f'id="widget-{idx}" class="pdf-widget" data-kind="form" data-field-name="{html.escape(name, quote=True)}" '
                f'aria-label="{html.escape(label, quote=True)}" style="left:{_css_num(rect.x0)}px;top:{_css_num(rect.y0)}px;width:{_css_num(rect.width)}px;height:{_css_num(rect.height)}px"'
            )
            if ftype == getattr(fitz, "PDF_WIDGET_TYPE_CHECKBOX", 2):
                checked = " checked" if value.lower() in {"yes", "on", "true", "1"} else ""
                out.append(f'<input type="checkbox" {common}{checked}>')
            elif ftype == getattr(fitz, "PDF_WIDGET_TYPE_RADIOBUTTON", 5):
                checked = " checked" if value.lower() not in {"", "off", "no", "false", "0"} else ""
                out.append(f'<input type="radio" name="{html.escape(name, quote=True)}" {common}{checked}>')
            elif ftype == getattr(fitz, "PDF_WIDGET_TYPE_COMBOBOX", 3):
                choices = list(getattr(widget, "choice_values", []) or [])
                opts = "".join(f'<option{(" selected" if str(c)==value else "")}>{html.escape(str(c))}</option>' for c in choices)
                out.append(f'<select {common}>{opts}</select>')
            elif ftype == getattr(fitz, "PDF_WIDGET_TYPE_LISTBOX", 4):
                choices = list(getattr(widget, "choice_values", []) or [])
                opts = "".join(f'<option{(" selected" if str(c)==value else "")}>{html.escape(str(c))}</option>' for c in choices)
                out.append(f'<select multiple {common}>{opts}</select>')
            elif ftype == getattr(fitz, "PDF_WIDGET_TYPE_TEXT", 7):
                out.append(f'<textarea {common}>{html.escape(value)}</textarea>')
            else:
                out.append(f'<span {common}></span>')
    except Exception:
        return ""
    return "\n".join(out)

def _strip_svg_headers(svg: str) -> str:
    svg = re.sub(r"<\?xml[^>]*>\s*", "", svg)
    svg = re.sub(r"<!DOCTYPE[^>]*>\s*", "", svg, flags=re.I)
    return svg.strip()


def _raster_visual(page: fitz.Page, dpi: int) -> str:
    pix = page.get_pixmap(dpi=int(dpi), alpha=False)
    png = pix.tobytes("png")
    data = _data_uri("image/png", png)
    return f'<img class="page-raster" draggable="false" alt="" aria-hidden="true" src="{data}" width="{pix.width}" height="{pix.height}">'


def convert_pdf(path: Path, job_dir: Path, options: dict[str, Any], progress: ProgressCallback | None = None) -> ConvertedDocument:
    job_dir.mkdir(parents=True, exist_ok=True)
    ref_dir = job_dir / "reference"
    ref_dir.mkdir(exist_ok=True)
    with fitz.open(path) as doc:
        metadata = dict(doc.metadata or {})
        try:
            labels = doc.get_page_labels() if hasattr(doc, "get_page_labels") else []
            metadata["page_labels"] = [str(item.get("label") or item.get("prefix") or idx + 1) if isinstance(item, dict) else str(item) for idx, item in enumerate(labels or [])]
        except Exception:
            metadata["page_labels"] = []
        page_sections: list[str] = []
        sizes: list[tuple[float, float]] = []
        reports: list[dict[str, Any]] = []
        all_fonts: dict[str, dict[str, str]] = {}
        search_index: list[dict[str, Any]] = []
        element_index: list[dict[str, Any]] = []
        ocr_used = 0
        total = max(1, len(doc))
        for i, page in enumerate(doc):
            rect = page.rect
            sizes.append((float(rect.width), float(rect.height)))
            textpage, used_ocr = _page_textpage(page, options)
            if used_ocr:
                ocr_used += 1
            tables = _find_tables(page) if options.get("extract_tables", True) else []
            mode = options.get("visual_mode", "ultra")
            backend = options.get("ultra_visual_backend", "raster") if mode == "ultra" else "svg"
            if backend == "raster":
                raster_dpi = int(options.get("raster_dpi") or options.get("validation_dpi") or options.get("dpi", 144))
                svg = _raster_visual(page, raster_dpi)
                (ref_dir / f"page-{i + 1}.svg").write_text(page.get_svg_image(matrix=fitz.Matrix(1, 1), text_as_path=False), encoding="utf-8")
            else:
                svg = _strip_svg_headers(page.get_svg_image(matrix=fitz.Matrix(1, 1), text_as_path=(mode == "ultra")))
                (ref_dir / f"page-{i + 1}.svg").write_text(svg, encoding="utf-8")
            if options.get("create_reference_renders", True):
                pix = page.get_pixmap(dpi=int(options.get("validation_dpi", 144)), alpha=False)
                pix.save(ref_dir / f"page-{i + 1}.png")
            for face in _extract_font_faces(page):
                all_fonts[face["name"]] = face
            text_layer, page_search = _text_layer(page, textpage=textpage, reverse_rtl=used_ocr) if options.get("selectable_text", True) else ("", [])
            for item in page_search:
                item["page"] = i + 1
                search_index.append(item)
            links = _links_layer(page, bool(options.get("safe_external_links", True))) if options.get("include_links", True) else ""
            semantics = _semantic_layer(page, textpage=textpage, tables=tables, semantic_headers=bool(options.get("semantic_headers", True)), reverse_rtl=used_ocr) if options.get("include_semantics", True) else ""
            annotations_layer = _annotation_layer(page) if options.get("include_annotations", True) else ""
            widgets_layer = _widget_layer(page) if options.get("include_forms", True) else ""
            page_elements: list[dict[str, Any]] = []
            for item in page_search:
                page_elements.append({"kind": "text", "id": item.get("id"), "bbox": item.get("bbox"), "text": item.get("text", "")[:500]})
            for table in tables:
                page_elements.append({"kind": "table", "id": f"table-{table.get('id')}", "bbox": table.get("bbox"), "row_count": table.get("row_count", 0), "col_count": table.get("col_count", 0)})
                for cell in table.get("cells_detail", [])[:500]:
                    page_elements.append({"kind": "table-cell", "id": f"table-{table.get('id')}-cell-{cell.get('index')}", "bbox": cell.get("bbox"), "row": cell.get("row"), "col": cell.get("col"), "text": str(cell.get("text", ""))[:250]})
            for li, link in enumerate(page.get_links(), 1):
                r = link.get("from")
                if r:
                    page_elements.append({"kind": "link", "id": f"link-{li}", "bbox": [float(r.x0), float(r.y0), float(r.x1), float(r.y1)], "uri": str(link.get("uri") or "")})
            try:
                for ai, annot in enumerate(page.annots() or [], 1):
                    r = annot.rect
                    atype = getattr(annot, "type", [0, "Unknown"])
                    page_elements.append({"kind": "annotation", "id": f"annotation-{ai}", "bbox": [float(r.x0), float(r.y0), float(r.x1), float(r.y1)], "subtype": str(atype[1] if isinstance(atype, (list, tuple)) and len(atype)>1 else atype)})
            except Exception:
                pass
            try:
                for wi, widget in enumerate(page.widgets() or [], 1):
                    r = widget.rect
                    page_elements.append({"kind": "form", "id": f"widget-{wi}", "bbox": [float(r.x0), float(r.y0), float(r.x1), float(r.y1)], "field_name": str(getattr(widget, "field_name", "") or "")})
            except Exception:
                pass
            element_index.append({"page": i + 1, "elements": page_elements})
            reports.append({
                "page": i + 1,
                "width_pt": float(rect.width), "height_pt": float(rect.height), "rotation": int(page.rotation),
                "ocr_used": used_ocr, "table_count": len(tables), "visual_backend": backend, "raster_dpi": raster_dpi if backend == "raster" else None,
                "text_characters": len(page.get_text("text", sort=True, textpage=textpage) if textpage else page.get_text("text", sort=True)),
                "image_count": len(page.get_images(full=True)), "drawing_count": len(page.get_drawings()),
                "link_count": len(page.get_links()), "annotation_count": sum(1 for _ in page.annots() or []),
                "widget_count": sum(1 for _ in page.widgets() or []), "font_count": len(page.get_fonts(full=True)),
                "annotation_layer_items": sum(1 for _ in page.annots() or []),
                "form_layer_items": sum(1 for _ in page.widgets() or []),
                "table_cell_count": sum(1 for c in sum((t.get("cells", []) for t in tables), []) if c is not None),
                "table_models": tables,
                "semantic_nodes": len(page_search),
                "search_tokens": len(page_search),
                "element_count": len(page_elements),
                "complexity": _complexity(page, len(page.get_text("text", sort=True, textpage=textpage) if textpage else page.get_text("text", sort=True)), len(page.get_drawings()), len(page.get_images(full=True)), len(tables)),
            })
            label_list = metadata.get("page_labels") if isinstance(metadata.get("page_labels"), list) else []
            page_label = str(label_list[i] if i < len(label_list) else i + 1)
            page_sections.append(
                f'<section class="page-shell" id="page-{i+1}" role="region" tabindex="0" aria-roledescription="PDF page" aria-label="صفحة {html.escape(page_label, quote=True)}" lang="{html.escape(_language_guess((page.get_text("text", sort=True, textpage=textpage) if textpage else page.get_text("text", sort=True)) or "unknown"), quote=True)}" data-page-label="{html.escape(page_label, quote=True)}" data-page="{i+1}" data-width="{_css_num(rect.width)}" data-height="{_css_num(rect.height)}" data-render-mode="{html.escape(mode, quote=True)}" data-page-language="{html.escape(_language_guess((page.get_text("text", sort=True, textpage=textpage) if textpage else page.get_text("text", sort=True)) or "unknown"), quote=True)}" data-complexity="{html.escape(reports[-1]["complexity"], quote=True)}" data-table-count="{reports[-1]["table_count"]}" style="width:{_css_num(rect.width)}px;height:{_css_num(rect.height)}px">'
                f'<div class="page-visual" aria-hidden="true">{svg}</div>'
                f'<div class="text-layer" aria-label="Selectable PDF text">{text_layer}</div>'
                f'<div class="link-layer-root">{links}</div>'
                f'<div class="semantic-layer" aria-label="Semantic document structure">{semantics}</div>'
                f'<div class="annotation-layer" aria-label="PDF annotations">{annotations_layer}</div>'
                f'<div class="form-layer" aria-label="PDF form controls">{widgets_layer}</div>'
                f'<div class="inspect-layer" aria-hidden="true"></div>'
                '</section>'
            )
            (ref_dir / f"page-{i + 1}.json").write_text(_safe_json(reports[-1]), encoding="utf-8")
            if progress:
                progress(int(8 + (i + 1) / total * 70), f"بناء الصفحة {i + 1} من {total}…")

        metadata["page_count"] = len(doc)
        metadata["source_sha256"] = _sha256(path)
        metadata["fonts"] = [{k: v for k, v in f.items() if k != "data"} for f in all_fonts.values()]
        metadata["font_count"] = len(all_fonts)
        metadata["embedded_font_count"] = sum(1 for f in all_fonts.values() if f.get("data"))
        metadata["font_embedding_rate"] = round((metadata["embedded_font_count"] / max(1, metadata["font_count"])) * 100, 2)
        metadata["toc"] = doc.get_toc(simple=True) or []
        metadata["ocr_pages"] = ocr_used
        metadata["tables"] = sum(r["table_count"] for r in reports)
        # Keep page labels normalized to strings so the standalone viewer has a stable contract.
        metadata["page_labels"] = [str(x) for x in (metadata.get("page_labels") or [])]

    font_css = []
    for face in all_fonts.values():
        data_uri = face.get("data")
        if not data_uri:
            continue
        family = (face.get("basefont") or face["name"]).replace("'", "")
        ext = face.get("ext", "").lower()
        fmt = "truetype" if ext == "ttf" else "opentype" if ext == "otf" else "woff2" if ext == "woff2" else "truetype"
        font_css.append(f"@font-face{{font-family:'{html.escape(family, quote=True)}';src:url('{data_uri}') format('{fmt}');font-display:block;}}")

    html_payload = "\n".join(page_sections)
    external_resource_patterns = [
        r"<(?:script|iframe|embed|object|video|audio|source)\b[^>]*(?:src|data|href)=\s*[\"']https?://",
        r"<link\b[^>]*href=\s*[\"']https?://",
        r"@import\s+(?:url\()?\s*[\"']https?://",
        r"url\(\s*[\"']https?://",
    ]
    external_resource_count = sum(len(re.findall(pattern, html_payload, flags=re.I)) for pattern in external_resource_patterns)
    external_link_count = len(re.findall(r'href=["\']https?://', html_payload, flags=re.I))
    local_only_audit = {
        "local_only": external_resource_count == 0,
        "external_resource_count": external_resource_count,
        "external_link_count": external_link_count,
        "network_connectivity": "not required; external links activate network only when the user clicks them",
        "embedded_images": html_payload.count("data:image/"),
        "embedded_fonts": len(font_css),
    }

    metadata["local_only_audit"] = local_only_audit
    metadata["element_count"] = sum(len(x.get("elements", [])) for x in element_index)
    (ref_dir / "elements.json").write_text(_safe_json(element_index), encoding="utf-8")
    data = {
        "metadata": metadata,
        "pageSizes": sizes,
        "pageCount": len(sizes),
        "reports": reports,
        "elements": element_index,
        "searchIndex": search_index if options.get("build_search_index", True) else [],
        "toc": metadata.get("toc", []),
        "pageLabels": metadata.get("page_labels", []),
        "sourceSha256": metadata.get("source_sha256", ""),
        "localOnlyAudit": local_only_audit,
        "options": {
            "localFormPersistence": bool(options.get("local_form_persistence", True)),
            "allowSemanticEditing": bool(options.get("allow_semantic_editing", True)),
            "rasterDpi": int(options.get("raster_dpi") or options.get("validation_dpi") or options.get("dpi", 144)),
        },
    }
    script_data = _safe_json(data).replace("</script>", "<\\/script>")
    page_gap = int(options.get("html_page_gaps", 28))
    csp_meta = "<meta http-equiv=\"Content-Security-Policy\" content=\"default-src \'none\'; img-src data: blob:; font-src data:; style-src \'unsafe-inline\'; script-src \'unsafe-inline\'; connect-src \'none\'; frame-src \'none\'; base-uri \'none\'\">" if options.get("standalone_csp", True) else ""
    toolbar_html = ""
    if options.get("standalone_toolbar", True):
        toc_button = '<button id="viewerToc" type="button">الفهرس</button>' if metadata.get("toc") else ''
        toolbar_html = f'''<nav id="viewerToolbar" class="standalone-toolbar" aria-label="أدوات المستند"><strong class="viewer-title">{html.escape(str(metadata.get("title") or path.stem))}</strong><div class="viewer-tools"><button id="viewerPrev" type="button">‹</button><span id="viewerPage">1 / {len(sizes)}</span><button id="viewerNext" type="button">›</button><label class="viewer-search"><span>⌕</span><input id="viewerSearch" type="search" placeholder="بحث…"></label><button id="viewerPrevHit" type="button">↑</button><button id="viewerNextHit" type="button">↓</button>{toc_button}<button id="viewerPrint" type="button">طباعة</button><button id="viewerEdit" type="button">تحرير البنية</button><button id="viewerExport" type="button">تصدير التعديل</button></div></nav>'''
    html_doc = f'''<!doctype html>
<html lang="ar" dir="auto">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="generator" content="PDF2HTML Studio {VERSION}">
<meta name="color-scheme" content="light dark">
<meta name="referrer" content="no-referrer">
<meta name="robots" content="noindex,nofollow,noarchive">
<meta name="description" content="Standalone HTML reconstructed from a PDF by PDF2HTML Studio">
<title>{html.escape(metadata.get('title') or path.stem)}</title>
<meta name="author" content="{html.escape(str(metadata.get('author') or ''), quote=True)}">
<meta name="subject" content="{html.escape(str(metadata.get('subject') or ''), quote=True)}">
<meta name="keywords" content="{html.escape(str(metadata.get('keywords') or ''), quote=True)}">
<meta name="pdf-source-sha256" content="{html.escape(str(metadata.get('source_sha256') or ''), quote=True)}">
{csp_meta}
<style>
{chr(10).join(font_css)}
:root{{--page-bg:#171a1f;--canvas-bg:#d9dce2;--selection:rgba(45,118,255,.30)}}
*{{box-sizing:border-box}}
html,body{{margin:0;padding:0;background:var(--page-bg)}}
body{{font-family:system-ui,-apple-system,"Segoe UI",Arial,sans-serif;color:#111}}
#document{{padding:28px;display:flex;flex-direction:column;align-items:center;gap:{page_gap}px;background:var(--canvas-bg);min-height:100vh}}
.page-shell{{position:relative;content-visibility:auto;contain-intrinsic-size:auto 842px;background:#fff;box-shadow:0 16px 45px rgba(0,0,0,.22);overflow:hidden;flex:none;isolation:isolate;contain:layout paint;print-color-adjust:exact;-webkit-print-color-adjust:exact}}
.standalone-toolbar{{position:sticky;top:0;z-index:1000;display:flex;align-items:center;justify-content:space-between;gap:14px;padding:10px 14px;background:rgba(16,21,29,.94);backdrop-filter:blur(12px);color:#e7eef7;font:13px/1.2 system-ui,-apple-system,"Segoe UI",Arial,sans-serif}}
.viewer-title{{max-width:30vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
.viewer-tools{{display:flex;align-items:center;gap:6px;flex-wrap:wrap}}
.viewer-tools button,.viewer-search{{border:1px solid rgba(255,255,255,.11);background:#111923;color:#d9e5f1;border-radius:8px;padding:7px 9px;font:12px system-ui,-apple-system,"Segoe UI",Arial,sans-serif;cursor:pointer}}
.viewer-search{{display:flex;align-items:center;gap:6px;padding:5px 8px}}
.viewer-search input{{border:0;outline:0;background:transparent;color:inherit;width:160px;font:12px system-ui,-apple-system,"Segoe UI",Arial,sans-serif}}
.editor-mode .semantic-layer{{opacity:1!important;pointer-events:auto!important;background:rgba(255,255,255,.94)!important;overflow:auto!important}}
.editor-mode .page-visual{{opacity:.10!important}}
.editor-mode .semantic-node,.editor-mode .semantic-table{{outline:1px dashed rgba(50,118,255,.45);background:rgba(50,118,255,.035)}}
@media print{{.standalone-toolbar{{display:none!important}}}}

.page-visual,.page-visual svg,.page-raster{{position:absolute;inset:0;width:100%;height:100%;display:block;pointer-events:none;user-select:none;object-fit:fill}}
.text-layer{{position:absolute;inset:0;pointer-events:none;overflow:hidden;z-index:10}}
.text-span{{position:absolute;display:block;overflow:hidden;white-space:pre;line-height:1;pointer-events:auto;color:transparent!important;background:transparent;user-select:text;-webkit-user-select:text}}
.text-span::selection{{background:var(--selection)}}
.link-layer-root{{position:absolute;inset:0;z-index:20;pointer-events:none;overflow:hidden}}
.link-hotspot{{position:absolute;display:block;pointer-events:auto;background:transparent}}
.semantic-layer{{position:absolute;inset:0;z-index:30;pointer-events:none;opacity:0}}
.semantic-node,.semantic-table{{position:absolute;margin:0;padding:0;overflow:hidden}}.semantic-table{{border-collapse:collapse;background:rgba(255,255,255,.98)}}.semantic-table td,.semantic-table th{{border:1px solid #8a93a1;padding:3px 6px;vertical-align:middle}}.table-a11y-caption{{position:absolute!important;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);clip-path:inset(50%);white-space:nowrap}}
.page-shell[data-render-mode="semantic"] .semantic-layer{{opacity:.97;pointer-events:auto;background:rgba(255,255,255,.98);overflow:hidden}}
.page-shell[data-render-mode="semantic"] .page-visual{{opacity:.10}}
.annotation-layer{{position:absolute;inset:0;z-index:25;pointer-events:none;overflow:hidden}}
.annotation-hotspot{{position:absolute;display:block;pointer-events:auto;background:transparent;color:inherit;text-decoration:none}}
.form-layer{{position:absolute;inset:0;z-index:26;pointer-events:none;overflow:hidden}}
.pdf-widget{{position:absolute;pointer-events:auto;margin:0;padding:0;border:1px solid transparent;background:transparent;color:transparent;opacity:.01;font:inherit;resize:none}}
.pdf-widget:focus{{opacity:1;color:#111;background:rgba(255,255,255,.96);border:2px solid #3276ff;outline:none;box-shadow:0 0 0 3px rgba(50,118,255,.15)}}
.inspect-layer{{position:absolute;inset:0;z-index:50;pointer-events:none;outline:0}}
.inspect-highlight{{position:absolute;border:2px solid #3878ff;background:rgba(56,120,255,.08);box-shadow:0 0 0 99999px rgba(17,25,38,.02);pointer-events:none}}
.search-hit{{outline:2px solid #f2c14e!important;background:rgba(242,193,78,.12)!important;border-radius:2px}}
.search-current{{outline:3px solid #20d0aa!important}}
@media print{{html,body{{background:#fff}}#document{{padding:0;gap:0;background:#fff}}.page-shell{{box-shadow:none;page-break-after:always;break-after:page}}}}
</style>
</head>
<body>
{toolbar_html}
<div id="viewerTocPanel" class="viewer-toc-panel" aria-label="فهرس المستند"></div>
<div id="document" data-local-only="true" data-external-resources="0">{''.join(page_sections)}</div>
<script>
window.__PDF2HTML__ = {script_data};
(function(){{
 const DATA=window.__PDF2HTML__, params=new URLSearchParams(location.search), pages=[...document.querySelectorAll('.page-shell')], pageCount=pages.length;
 let printPage=Number(params.get('page')||1);
 const state={{hits:[],index:-1,term:'',edit:false}};
 function norm(s){{return String(s||'').normalize('NFKC').toLocaleLowerCase().replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ؤ/g,'و').replace(/ئ/g,'ي').replace(/ة/g,'ه').replace(/ـ/g,'');}}
 const visible=()=>pages.find(el=>!el.hidden)||pages[0];
 function revealPage(n){{const target=Math.max(1,Math.min(pageCount,Number(n)||1));pages.forEach(el=>el.hidden=Number(el.dataset.page)!==target);const badge=document.getElementById('viewerPage');if(badge)badge.textContent=`${{pages[target-1]?.dataset.pageLabel||target}} / ${{pageCount}}`;document.getElementById('page-'+target)?.scrollIntoView({{block:'start'}});if(location.hash!==`#page-${{target}}`)history.replaceState(null,'',`#page-${{target}}`);return target;}}
 function clearHits(){{document.querySelectorAll('.search-hit,.search-current').forEach(el=>el.classList.remove('search-hit','search-current'));}}
 function search(term,index){{clearHits();const q=norm(String(term||'').trim());state.term=q;if(!q){{state.hits=[];state.index=-1;return {{count:0,index:-1,page:Number(visible()?.dataset.page||1)}};}}state.hits=(DATA.searchIndex||[]).filter(x=>norm(x.text).includes(q)||(x.search_variants||[]).some(v=>norm(v).includes(q)));state.index=state.hits.length?Math.max(0,Math.min(state.hits.length-1,Number.isInteger(index)?index:0)):-1;state.hits.forEach(h=>document.getElementById(h.id)?.classList.add('search-hit'));if(state.index>=0){{const h=state.hits[state.index];revealPage(h.page);document.getElementById(h.id)?.classList.add('search-current');}}return {{count:state.hits.length,index:state.index,page:state.hits[state.index]?.page||1}};}}
 function persistForms(){{if(!DATA.options?.localFormPersistence||!DATA.sourceSha256)return;const values={{}};document.querySelectorAll('.pdf-widget').forEach((el,i)=>values[i]=(el.type==='checkbox'||el.type==='radio')?{{checked:el.checked}}:{{value:el.value}});try{{localStorage.setItem(`p2h-forms-${{DATA.sourceSha256}}`,JSON.stringify(values));}}catch{{}}}}
 function restoreForms(){{if(!DATA.options?.localFormPersistence||!DATA.sourceSha256)return;try{{const v=JSON.parse(localStorage.getItem(`p2h-forms-${{DATA.sourceSha256}}`)||'null');if(!v)return;document.querySelectorAll('.pdf-widget').forEach((el,i)=>{{const x=v[i];if(!x)return;if('checked' in x)el.checked=!!x.checked;if('value' in x)el.value=x.value;}});}}catch{{}}}}
 function toggleEdit(){{if(!DATA.options?.allowSemanticEditing)return;state.edit=!state.edit;document.body.classList.toggle('editor-mode',state.edit);document.querySelectorAll('.semantic-node,.semantic-table').forEach(el=>el.contentEditable=state.edit?'true':'false');const b=document.getElementById('viewerEdit');if(b)b.textContent=state.edit?'إغلاق التحرير':'تحرير البنية';}}
 function exportEdited(){{const clone=document.documentElement.cloneNode(true);clone.querySelector('#viewerToolbar')?.remove();const blob=new Blob(['<!doctype html>\\n'+clone.outerHTML],{{type:'text/html;charset=utf-8'}});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='edited-pdf2html.html';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}}
 function escapeText(s){{const d=document.createElement('div');d.textContent=String(s||'');return d.innerHTML}}
 function buildToc(){{const panel=document.getElementById('viewerTocPanel'),button=document.getElementById('viewerToc');if(!panel||!button||!Array.isArray(DATA.toc))return;panel.innerHTML=DATA.toc.map((e)=>{{const level=Number(e[0]||1),title=String(e[1]||''),page=typeof e[2]==='number'?e[2]:typeof e[3]==='number'?e[3]+1:1;return `<button type="button" data-toc-page="${{page}}" style="padding-inline-start:${{8+Math.min(6,Math.max(0,level-1))*12}}px">${{escapeText(title)}}</button>`}}).join('');panel.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{{revealPage(Number(b.dataset.tocPage||1));panel.classList.remove('open')}}));button.addEventListener('click',()=>panel.classList.toggle('open'));}}
 buildToc();
 if(params.get('page'))revealPage(params.get('page'));else revealPage(1);if(location.hash.startsWith('#page-'))revealPage(location.hash.slice(6));
 document.getElementById('viewerPrev')?.addEventListener('click',()=>revealPage(Number(visible()?.dataset.page||1)-1));document.getElementById('viewerNext')?.addEventListener('click',()=>revealPage(Number(visible()?.dataset.page||1)+1));document.getElementById('viewerPrint')?.addEventListener('click',()=>window.print());document.getElementById('viewerEdit')?.addEventListener('click',toggleEdit);document.getElementById('viewerExport')?.addEventListener('click',exportEdited);document.getElementById('viewerSearch')?.addEventListener('input',e=>search(e.target.value));document.getElementById('viewerPrevHit')?.addEventListener('click',()=>state.hits.length&&search(state.term,(state.index-1+state.hits.length)%state.hits.length));document.getElementById('viewerNextHit')?.addEventListener('click',()=>state.hits.length&&search(state.term,(state.index+1)%state.hits.length));
 restoreForms();document.addEventListener('input',e=>e.target.matches?.('.pdf-widget')&&persistForms());document.addEventListener('change',e=>e.target.matches?.('.pdf-widget')&&persistForms());
 window.addEventListener('hashchange',()=>{{const m=location.hash.match(/^#page-(\\d+)$/);if(m)revealPage(Number(m[1]));}});
 window.addEventListener('beforeprint',()=>{{printPage=Number(visible()?.dataset.page||params.get('page')||1);pages.forEach(el=>el.hidden=false);}});window.addEventListener('afterprint',()=>revealPage(printPage));
 window.addEventListener('keydown',e=>{{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){{e.preventDefault();document.getElementById('viewerSearch')?.focus();}}if(e.key==='ArrowRight'&&!e.ctrlKey&&!e.metaKey)revealPage(Number(visible()?.dataset.page||1)+1);if(e.key==='ArrowLeft'&&!e.ctrlKey&&!e.metaKey)revealPage(Number(visible()?.dataset.page||1)-1);}});
 window.addEventListener('message',e=>{{const m=e.data||{{}};if(m.source!=='pdf2html-studio')return;if(m.type==='inspect-mode')document.querySelectorAll('.page-visual').forEach(el=>el.style.pointerEvents=m.active?'auto':'none');if(m.type==='search'){{const payload=search(m.term,m.index);window.parent?.postMessage({{source:'pdf2html-studio',type:'search-result',payload}},'*');}}if(m.type==='clear-search')clearHits();if(m.type==='goto-page')revealPage(m.page);if(m.type==='show-all-pages-for-print')pages.forEach(el=>el.hidden=false);}});
 let inspect=false;function inspectTarget(t){{const page=t?.closest?.('.page-shell')||visible();if(!t||!page)return;const r=t.getBoundingClientRect(),pr=page.getBoundingClientRect(),st=getComputedStyle(t),raw=(t.getAttribute?.('data-bbox')||'').split(',').map(Number);const payload={{page:Number(page.dataset.page),tag:t.tagName.toLowerCase(),id:t.id||'',className:t.className?.baseVal||t.className||'',text:(t.innerText||t.textContent||'').trim().slice(0,500),bbox:[r.left-pr.left,r.top-pr.top,r.right-pr.left,r.bottom-pr.top].map(n=>Number(n.toFixed(3))),bboxPdf:raw.length===4?raw:null,color:st.color,background:st.backgroundColor,font:st.fontFamily,fontSize:st.fontSize,fontWeight:st.fontWeight,opacity:st.opacity,transform:st.transform,href:t.closest?.('a')?.href||'',pageComplexity:page.dataset.complexity||'',tableCount:Number(page.dataset.tableCount||0)}};window.parent?.postMessage({{source:'pdf2html-studio',type:'inspect',payload}},'*');}}
 document.addEventListener('click',e=>{{if(inspect){{e.preventDefault();e.stopPropagation();inspectTarget(e.target);}}}},true);window.addEventListener('message',e=>{{if(e.data?.source==='pdf2html-studio'&&e.data.type==='inspect-mode')inspect=!!e.data.active;}});
 if(window.parent!==window)window.parent.postMessage({{source:'pdf2html-studio',type:'ready',pageCount}},'*');
}})();
</script>
</body>
</html>'''
    (ref_dir / "manifest.json").write_text(_safe_json(data), encoding="utf-8")
    return ConvertedDocument(html_doc, metadata, len(sizes), sizes, reports, ref_dir, search_index)


def make_zip(html_text: str, job_dir: Path, output_zip: Path) -> None:
    """Build a clean deliverable archive, excluding runtime/process internals.

    The HTML is always written as the canonical root entry. Runtime source PDFs,
    state/result files, browser render scratch space and repair candidates stay
    on the local workspace and are never copied into the user deliverable.
    """
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    excluded_files = {"index.html", "state.json", "result.json", "source.pdf", "source-info.json"}
    excluded_dirs = {"html-renders", "repair", "repair-candidates", "thumbs", "__pycache__"}
    with zipfile.ZipFile(output_zip, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("index.html", html_text)
        for p in job_dir.rglob("*"):
            if not p.is_file() or p == output_zip or p.name in excluded_files:
                continue
            rel = p.relative_to(job_dir)
            if any(part in excluded_dirs or part.startswith("repair-") for part in rel.parts):
                continue
            z.write(p, rel.as_posix())
