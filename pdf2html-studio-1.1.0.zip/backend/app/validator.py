from __future__ import annotations

import asyncio
import io
import math
import os
import shutil
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

import pymupdf as fitz
from PIL import Image, ImageChops, ImageEnhance, ImageFilter, ImageStat


def _render_pdf_page(pdf_path: Path, page_num: int, dpi: int) -> Image.Image:
    with fitz.open(pdf_path) as doc:
        pix = doc[page_num].get_pixmap(dpi=dpi, alpha=False)
        return Image.open(io.BytesIO(pix.tobytes("png"))).convert("RGB")


def _chromium_executable() -> str | None:
    program_files = os.environ.get("PROGRAMFILES", r"C:\Program Files")
    program_files_x86 = os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")
    local_app_data = os.environ.get("LOCALAPPDATA", "")
    candidates = [
        os.environ.get("P2H_BROWSER_EXE"),
        os.environ.get("CHROMIUM_PATH"),
        shutil.which("chromium"),
        shutil.which("chromium-browser"),
        shutil.which("google-chrome"),
        shutil.which("chrome"),
        shutil.which("msedge"),
        Path(program_files) / "Google/Chrome/Application/chrome.exe",
        Path(program_files_x86) / "Google/Chrome/Application/chrome.exe",
        Path(local_app_data) / "Google/Chrome/Application/chrome.exe",
        Path(program_files) / "Microsoft/Edge/Application/msedge.exe",
        Path(program_files_x86) / "Microsoft/Edge/Application/msedge.exe",
        Path(local_app_data) / "Microsoft/Edge/Application/msedge.exe",
        "/usr/bin/chromium", "/usr/bin/chromium-browser"
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(candidate)
    return None


def _render_html_pages(html_text: str, out_dir: Path, page_width_pt: float, page_height_pt: float, dpi: int, page_number: int) -> Path:
    from playwright.async_api import async_playwright
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"page-{page_number}.png"
    scale = dpi / 72.0

    async def run() -> None:
        async with async_playwright() as p:
            args = ["--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage"]
            executable = _chromium_executable()
            kwargs = {"headless": True, "args": args}
            if executable:
                kwargs["executable_path"] = executable
            try:
                browser = await p.chromium.launch(**kwargs)
            except Exception as exc:
                raise RuntimeError("تعذر تشغيل Chromium/Chrome/Edge المحلي. ثبّت Playwright Chromium أو اضبط P2H_BROWSER_EXE لمسار Chrome/Edge صالح.") from exc
            context = await browser.new_context(
                viewport={"width": max(1280, int(page_width_pt * scale) + 40), "height": min(max(1200, int(page_height_pt * scale) + 40), 4000)},
                device_scale_factor=scale,
                color_scheme="light",
            )
            page = await context.new_page()
            await page.set_content(html_text, wait_until="load")
            await page.wait_for_function("document.fonts ? document.fonts.status === 'loaded' : true")
            await page.add_style_tag(content="""
                html,body { background:#fff !important; margin:0 !important; }
                #viewerToolbar { display:none !important; }
                #document { padding:0 !important; gap:0 !important; background:#fff !important; }
                .page-shell { box-shadow:none !important; }
            """)
            target = page.locator(f"#page-{page_number}")
            await target.scroll_into_view_if_needed()
            png = await target.screenshot(animations="disabled", scale="device")
            out.write_bytes(png)
            await context.close(); await browser.close()

    asyncio.run(run())
    return out


async def _render_html_document_pages(html_text: str, out_dir: Path, page_width_pts: list[float], page_height_pts: list[float], dpi: int, page_numbers: list[int]) -> dict[int, Path]:
    from playwright.async_api import async_playwright
    out_dir.mkdir(parents=True, exist_ok=True)
    scale = dpi / 72.0
    max_w = max([int(w * scale) for w in page_width_pts] or [1280]) + 80
    max_h = min(max([int(h * scale) for h in page_height_pts] or [1200]) + 80, 5000)
    results: dict[int, Path] = {}
    async with async_playwright() as p:
        args = ["--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage"]
        executable = _chromium_executable()
        kwargs = {"headless": True, "args": args}
        if executable:
            kwargs["executable_path"] = executable
        try:
            browser = await p.chromium.launch(**kwargs)
        except Exception as exc:
            raise RuntimeError("تعذر تشغيل Chromium/Chrome/Edge المحلي. ثبّت Playwright Chromium أو اضبط P2H_BROWSER_EXE لمسار Chrome/Edge صالح.") from exc
        context = await browser.new_context(viewport={"width": max_w, "height": max_h}, device_scale_factor=scale, color_scheme="light")
        page = await context.new_page()
        await page.set_content(html_text, wait_until="load")
        await page.wait_for_function("document.fonts ? document.fonts.status === 'loaded' : true")
        await page.add_style_tag(content="""
            html,body { background:#fff !important; margin:0 !important; }
            #viewerToolbar { display:none !important; }
            #document { padding:0 !important; gap:0 !important; background:#fff !important; }
            .page-shell { box-shadow:none !important; }
        """)
        await page.evaluate("""() => { document.querySelectorAll('.page-shell').forEach((el) => { el.hidden = false; }); }""")
        for number in page_numbers:
            await page.evaluate("""(n) => { document.querySelectorAll('.page-shell').forEach((el) => { el.hidden = Number(el.dataset.page) !== n; }); }""", number)
            target = page.locator(f"#page-{number}")
            await target.scroll_into_view_if_needed()
            out = out_dir / f"page-{number}.png"
            png = await target.screenshot(animations="disabled", scale="device")
            out.write_bytes(png)
            results[number] = out
        await context.close()
        await browser.close()
    return results


def _validate_rendered_page(pdf_path: Path, html_img_path: Path, page_number: int, dpi: int, out_dir: Path, alignment_probe: bool = False) -> dict[str, Any]:
    pdf_img = _render_pdf_page(pdf_path, page_number - 1, dpi)
    html_img = Image.open(html_img_path).convert("RGB")
    if html_img.size != pdf_img.size:
        html_img = html_img.resize(pdf_img.size, Image.Resampling.LANCZOS)
    score, diff, metrics = compare_images(pdf_img, html_img)
    alignment = _probe_alignment(pdf_img, html_img) if alignment_probe else None
    diff_path = out_dir / "diff" / f"page-{page_number}.png"
    _save_diff(diff, diff_path)
    return {"page":page_number,"score":round(score,4),"width":pdf_img.width,"height":pdf_img.height,"metrics":metrics,"regions":_diff_regions(diff),"alignment":alignment,"diff_file":diff_path,"html_render":html_img_path}

def compare_images(a: Image.Image, b: Image.Image, threshold: int = 8) -> tuple[float, Image.Image, dict[str, Any]]:
    if b.size != a.size:
        b = b.resize(a.size, Image.Resampling.LANCZOS)
    diff = ImageChops.difference(a, b).convert("RGB")
    gray = diff.convert("L")
    stats = ImageStat.Stat(gray)
    histogram = gray.histogram()
    total = a.width * a.height
    changed = total - histogram[0]
    values = []
    cumulative = 0
    p95 = 0
    for value, count in enumerate(histogram):
        cumulative += count
        if cumulative >= total * 0.95:
            p95 = value
            break
    max_error = max((i for i, count in enumerate(histogram) if count), default=0)
    changed_threshold = sum(histogram[threshold + 1:])
    mean_error = stats.mean[0] / 255.0
    exact_ratio = 1 - changed_threshold / max(1, total)
    edge_a = a.convert("L").filter(ImageFilter.FIND_EDGES)
    edge_b = b.convert("L").filter(ImageFilter.FIND_EDGES)
    edge_diff = ImageStat.Stat(ImageChops.difference(edge_a, edge_b)).mean[0] / 255.0
    score = (0.56 * (1 - mean_error) + 0.24 * exact_ratio + 0.20 * (1 - edge_diff)) * 100
    return max(0.0, min(100.0, score)), diff, {
        "changed_ratio": round(changed_threshold / max(1, total) * 100, 4),
        "mean_error": round(mean_error * 100, 4),
        "p95_error": p95,
        "edge_error": round(edge_diff * 100, 4),
        "max_error": int(max_error),
        "exact_ratio": round(exact_ratio * 100, 4),
    }


def _diff_regions(diff: Image.Image, min_ratio: float = 0.02, tile: int = 48) -> list[dict[str, Any]]:
    gray = diff.convert("L")
    width, height = gray.size
    regions: list[dict[str, Any]] = []
    for y in range(0, height, tile):
        for x in range(0, width, tile):
            crop = gray.crop((x, y, min(width, x + tile), min(height, y + tile)))
            hist = crop.histogram(); total = crop.width * crop.height
            changed = total - hist[0]
            ratio = changed / max(1, total)
            if ratio >= min_ratio:
                regions.append({"x": x, "y": y, "width": crop.width, "height": crop.height, "changed_percent": round(ratio * 100, 2)})
    regions.sort(key=lambda r: r["changed_percent"], reverse=True)
    return regions[:120]


def _save_diff(diff: Image.Image, out_path: Path) -> None:
    emphasized = ImageEnhance.Contrast(diff).enhance(4.0).filter(ImageFilter.SHARPEN)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    emphasized.save(out_path)


def _probe_alignment(pdf_img: Image.Image, html_img: Image.Image) -> dict[str, Any]:
    best = {"dx": 0, "dy": 0, "score": -1.0}
    for dx in (-2, -1, 0, 1, 2):
        for dy in (-2, -1, 0, 1, 2):
            canvas = Image.new("RGB", html_img.size, "white")
            canvas.paste(html_img, (dx, dy))
            score, _, _ = compare_images(pdf_img, canvas)
            if score > best["score"]:
                best = {"dx": dx, "dy": dy, "score": round(score, 4)}
    return best


def validate_html_text(pdf_path: Path, html_path: Path, page_number: int, dpi: int, out_dir: Path, alignment_probe: bool = True, stem: str | None = None) -> dict[str, Any]:
    html_text = html_path.read_text(encoding="utf-8")
    pdf_img = _render_pdf_page(pdf_path, page_number - 1, dpi)
    html_out = _render_html_pages(html_text, out_dir / "html-renders", pdf_img.width * 72 / dpi, pdf_img.height * 72 / dpi, dpi, page_number)
    if stem:
        renamed = out_dir / "html-renders" / f"{stem}.png"
        if html_out != renamed:
            html_out.replace(renamed)
            html_out = renamed
    html_img = Image.open(html_out).convert("RGB")
    if html_img.size != pdf_img.size:
        html_img = html_img.resize(pdf_img.size, Image.Resampling.LANCZOS)
    score, diff, metrics = compare_images(pdf_img, html_img)
    alignment = _probe_alignment(pdf_img, html_img) if alignment_probe else None
    diff_path = out_dir / "diff" / f"{stem or 'page-'+str(page_number)}.png"
    _save_diff(diff, diff_path)
    return {
        "page": page_number, "score": round(score, 4), "width": pdf_img.width, "height": pdf_img.height,
        "metrics": metrics, "regions": _diff_regions(diff), "alignment": alignment,
        "diff_file": diff_path, "html_render": html_out,
    }


def validate_page(pdf_path: Path, html_path: Path, page_number: int, dpi: int, out_dir: Path, alignment_probe: bool = True) -> dict[str, Any]:
    return validate_html_text(pdf_path, html_path, page_number, dpi, out_dir, alignment_probe=alignment_probe)


def validate_all(pdf_path: Path, html_path: Path, dpi: int, out_dir: Path, page_count: int, alignment_probe: bool = False, threshold: float = 99.0) -> dict[str, Any]:
    html_text = html_path.read_text(encoding="utf-8")
    with fitz.open(pdf_path) as doc:
        widths = [float(page.rect.width) for page in doc]
        heights = [float(page.rect.height) for page in doc]
    render_dir = out_dir / "html-renders"
    import concurrent.futures
    render_paths = asyncio.run(_render_html_document_pages(html_text, render_dir, widths, heights, dpi, list(range(1, page_count + 1))))
    workers = max(1, min(8, (os.cpu_count() or 2)))
    def run(n: int):
        return _validate_rendered_page(pdf_path, render_paths[n], n, dpi, out_dir, alignment_probe=alignment_probe)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        results = list(executor.map(run, range(1, page_count + 1)))
    results.sort(key=lambda x: x["page"])
    scores = [r["score"] for r in results]
    overall = sum(scores) / len(scores) if scores else 0.0
    worst = min(scores) if scores else 0.0
    worst_page = results[scores.index(worst)]["page"] if results else None
    passed = [s >= threshold for s in scores]
    return {
        "overall_score": round(overall, 4),
        "worst_page_score": round(worst, 4),
        "worst_page": worst_page,
        "pass_rate": round(sum(passed) / max(1, len(passed)) * 100, 2),
        "threshold": round(float(threshold), 2),
        "page_count": len(results),
        "pages": [{k: v for k, v in r.items() if k not in {"diff_file", "html_render"}} for r in results],
    }


def write_quality_report(out_dir: Path, quality: dict[str, Any], title: str = 'PDF2HTML Studio — Quality Report') -> Path:
    'Write a completely offline HTML QA report with relative image links.'
    import html as _html
    out_dir.mkdir(parents=True, exist_ok=True)
    pages = quality.get('pages') or []
    threshold = float(quality.get('threshold', 99.0))
    overall = float(quality.get('overall_score', 0.0))
    worst = float(quality.get('worst_page_score', 0.0))
    pass_rate = float(quality.get('pass_rate', 0.0))
    rows: list[str] = []
    cards: list[str] = []
    safe_title = _html.escape(str(title))
    for page in pages:
        number = int(page.get('page', 1))
        score = float(page.get('score', 0.0))
        state = 'PASS' if score >= threshold else 'WARN'
        css = 'ok' if state == 'PASS' else 'warn'
        metrics = page.get('metrics') or {}
        ref = f'reference/page-{number}.png'
        diff = f'diff/page-{number}.png'
        rows.append(
            f'<tr><td>{number}</td><td class="{css}">{score:.2f}%</td>'
            f'<td>{float(metrics.get("changed_ratio",0)):.3f}%</td>'
            f'<td>{float(metrics.get("mean_error",0)):.3f}%</td>'
            f'<td>{float(metrics.get("edge_error",0)):.3f}%</td>'
            f'<td>{len(page.get("regions") or [])}</td><td>{state}</td></tr>'
        )
        cards.append(
            f'''<article class="card"><header><div><b>الصفحة {number}</b><span class="badge {css}">{score:.2f}%</span></div><small>Reference / Diff</small></header><div class="images"><figure><figcaption>مرجع PDF</figcaption><img src="{ref}" alt="PDF reference page {number}" loading="lazy"></figure><figure><figcaption>Visual Diff</figcaption><img src="{diff}" alt="Visual diff page {number}" loading="lazy"></figure></div></article>'''
        )
    report = f'''<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="referrer" content="no-referrer"><title>{safe_title}</title><style>
:root{{--bg:#081019;--panel:#0e1720;--line:rgba(180,205,235,.12);--text:#edf4fb;--muted:#8b9aae;--good:#79dfbd;--warn:#f1c773}}*{{box-sizing:border-box}}html,body{{margin:0;background:var(--bg);color:var(--text);font-family:system-ui,-apple-system,"Segoe UI",Arial,sans-serif}}main{{width:min(1200px,calc(100% - 30px));margin:0 auto;padding:28px 0 50px}}header.hero{{padding:24px;border:1px solid var(--line);border-radius:18px;background:linear-gradient(145deg,#0e1a25,#091118);box-shadow:0 25px 70px rgba(0,0,0,.28)}}header.hero h1{{margin:0 0 6px;font-size:24px}}header.hero p{{margin:0;color:var(--muted);font-size:12px;line-height:1.7}}.metrics{{display:grid;grid-template-columns:repeat(4,1fr);gap:9px;margin:14px 0}}.metric{{padding:14px;border:1px solid var(--line);border-radius:13px;background:var(--panel)}}.metric span{{display:block;color:var(--muted);font-size:9px}}.metric b{{display:block;font-size:22px;margin-top:6px}}.metric b.good,.badge.ok,td.ok{{color:var(--good)}}.metric b.warn,.badge.warn,td.warn{{color:var(--warn)}}.table-wrap{{overflow:auto;border:1px solid var(--line);border-radius:13px;background:var(--panel)}}table{{width:100%;border-collapse:collapse;font-size:10px}}th,td{{padding:9px 10px;border-bottom:1px solid var(--line);text-align:right;white-space:nowrap}}th{{color:var(--muted);font-weight:600;background:rgba(255,255,255,.025)}}.cards{{display:grid;gap:12px;margin-top:14px}}article.card{{border:1px solid var(--line);border-radius:15px;background:var(--panel);padding:12px}}article.card header{{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}}article.card header div{{display:flex;align-items:center;gap:8px}}article.card header b{{font-size:11px}}article.card header small{{color:var(--muted);font-size:8px}}.badge{{padding:4px 7px;border-radius:999px;background:rgba(121,223,189,.08);font-size:8px}}.images{{display:grid;grid-template-columns:1fr 1fr;gap:10px}}figure{{margin:0;padding:8px;border:1px solid var(--line);border-radius:11px;background:#fff}}figcaption{{font-size:8px;color:#5f6b78;margin:0 0 6px}}figure img{{display:block;width:100%;height:auto;object-fit:contain}}.foot{{margin-top:14px;color:var(--muted);font-size:9px;line-height:1.7}}@media(max-width:800px){{.metrics{{grid-template-columns:1fr 1fr}}.images{{grid-template-columns:1fr}}}}
</style></head><body><main><header class="hero"><h1>{safe_title}</h1><p>تقرير مراجعة محلي. لا توجد خدمة خارجية مطلوبة لعرض هذا التقرير.</p></header><section class="metrics"><div class="metric"><span>متوسط التطابق</span><b class="good">{overall:.2f}%</b></div><div class="metric"><span>أسوأ صفحة</span><b class="warn">{worst:.2f}%</b></div><div class="metric"><span>نسبة الاجتياز</span><b>{pass_rate:.0f}%</b></div><div class="metric"><span>حد النجاح</span><b>{threshold:.2f}%</b></div></section><div class="table-wrap"><table><thead><tr><th>الصفحة</th><th>Score</th><th>Changed</th><th>Mean Error</th><th>Edge Error</th><th>Regions</th><th>State</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div><section class="cards">{''.join(cards)}</section><div class="foot">المقارنة مبنية على Render محلي للـPDF مقابل Render محلي للـHTML داخل Chromium. الدرجة مقياس هندسي للملف الذي تم فحصه وليست ضمانًا عالميًا لـ100% لكل ملف PDF.</div></main></body></html>'''
    path = out_dir / 'quality-report.html'
    path.write_text(report, encoding='utf-8')
    return path
