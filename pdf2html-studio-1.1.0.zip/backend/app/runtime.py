from __future__ import annotations

import importlib.metadata
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
from typing import Any

from .version import VERSION

PACKAGE_MAP = {
    "FastAPI": "fastapi",
    "Uvicorn": "uvicorn",
    "PyMuPDF": "PyMuPDF",
    "Pillow": "Pillow",
    "python-multipart": "python-multipart",
    "Pydantic": "pydantic",
    "Playwright": "playwright",
}


def package_versions() -> dict[str, str | None]:
    versions: dict[str, str | None] = {}
    for label, dist in PACKAGE_MAP.items():
        try:
            versions[label] = importlib.metadata.version(dist)
        except importlib.metadata.PackageNotFoundError:
            versions[label] = None
    return versions


def _system_chromium() -> str | None:
    program_files = os.environ.get("PROGRAMFILES", r"C:\Program Files")
    program_files_x86 = os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")
    local_app_data = os.environ.get("LOCALAPPDATA", "")
    candidates = (
        os.environ.get("P2H_BROWSER_EXE"),
        os.environ.get("CHROMIUM_PATH"),
        shutil.which("chromium"),
        shutil.which("chromium-browser"),
        shutil.which("google-chrome"),
        shutil.which("chrome"),
        shutil.which("msedge"),
        Path(program_files) / "Google/Chrome/Application/chrome.exe",
        Path(program_files_x86) / "Google/Chrome/Application/chrome.exe",
        Path(local_app_data) / "Google/Chrome/Application/chrome.exe",
        Path(program_files) / "Microsoft/Edge/Application/msedge.exe",
        Path(program_files_x86) / "Microsoft/Edge/Application/msedge.exe",
        Path(local_app_data) / "Microsoft/Edge/Application/msedge.exe",
        "/usr/bin/chromium",
        "/usr/bin/chromium-browser",
    )
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(Path(candidate).resolve())
    return None


def playwright_browser_status(python: str | None = None) -> dict[str, Any]:
    """Check the local Playwright browser installation without downloading anything."""
    python_exe = python or sys.executable
    try:
        result = subprocess.run(
            [python_exe, "-m", "playwright", "install", "--list"],
            capture_output=True,
            text=True,
            timeout=12,
            check=False,
        )
        output = (result.stdout or "") + "\n" + (result.stderr or "")
    except FileNotFoundError:
        return {"installed": False, "method": "playwright", "reason": "python executable not found"}
    except subprocess.TimeoutExpired:
        return {"installed": False, "method": "playwright", "reason": "playwright --list timed out"}
    except OSError as exc:
        return {"installed": False, "method": "playwright", "reason": str(exc)}

    low = output.lower()
    chromium = "chromium" in low or "chrome for testing" in low
    return {
        "installed": bool(result.returncode == 0 and chromium),
        "method": "playwright",
        "exit_code": result.returncode,
        "details": output.strip()[-4000:],
    }


def tesseract_status() -> dict[str, Any]:
    executable = shutil.which("tesseract")
    if not executable:
        return {"installed": False, "executable": None, "languages": []}
    try:
        result = subprocess.run([executable, "--list-langs"], capture_output=True, text=True, timeout=8, check=False)
        languages = [line.strip() for line in result.stdout.splitlines()[1:] if line.strip()]
        return {"installed": result.returncode == 0, "executable": executable, "languages": languages, "arabic": "ara" in languages}
    except (OSError, subprocess.TimeoutExpired):
        return {"installed": True, "executable": executable, "languages": [], "arabic": False}


def diagnostic_report(root: Path) -> dict[str, Any]:
    workspace = root / "workspace"
    workspace.mkdir(parents=True, exist_ok=True)
    write_probe = workspace / ".write-probe"
    writable = False
    try:
        write_probe.write_text("ok", encoding="utf-8")
        writable = write_probe.read_text(encoding="utf-8") == "ok"
    except OSError:
        writable = False
    finally:
        write_probe.unlink(missing_ok=True)
    chrome = _system_chromium()
    pw = playwright_browser_status()
    tesseract = tesseract_status()
    packages = package_versions()
    packages_ready = all(value is not None for value in packages.values())
    return {
        "ok": writable and packages_ready,
        "version": VERSION,
        "local_only": True,
        "internet_required_at_runtime": False,
        "internet_required_for_first_run_setup": True,
        "python": {"version": platform.python_version(), "executable": sys.executable, "implementation": platform.python_implementation()},
        "platform": platform.platform(),
        "packages": packages,
        "chromium": {"system_executable": chrome, "playwright": pw, "ready_for_visual_qa": bool(chrome or pw.get("installed"))},
        "tesseract": tesseract,
        "workspace": {"path": str(workspace), "writable": writable},
    }
