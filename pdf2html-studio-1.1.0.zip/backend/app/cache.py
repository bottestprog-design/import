from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path
from typing import Any

from .version import VERSION

ENGINE_VERSION = VERSION


def canonical_options(options: dict[str, Any]) -> str:
    return json.dumps(options, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def cache_key(source_sha256: str, options: dict[str, Any]) -> str:
    payload = f"{ENGINE_VERSION}\n{source_sha256}\n{canonical_options(options)}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def cache_dir(root: Path, key: str) -> Path:
    return root / key[:2] / key


def has_cache(root: Path, key: str) -> bool:
    folder = cache_dir(root, key)
    return (folder / "index.html").is_file() and (folder / "manifest.json").is_file()


def restore_cache(root: Path, key: str, outdir: Path) -> None:
    source = cache_dir(root, key)
    if outdir.exists():
        shutil.rmtree(outdir, ignore_errors=True)
    shutil.copytree(source, outdir)
    for transient in ("state.json", "result.json"):
        (outdir / transient).unlink(missing_ok=True)


def save_cache(root: Path, key: str, outdir: Path) -> None:
    destination = cache_dir(root, key)
    temporary = destination.with_name(destination.name + ".tmp")
    if temporary.exists():
        shutil.rmtree(temporary, ignore_errors=True)
    temporary.parent.mkdir(parents=True, exist_ok=True)
    temporary.mkdir(parents=True, exist_ok=True)
    for item in outdir.iterdir():
        if item.name in {"state.json", "result.json"}:
            continue
        target = temporary / item.name
        if item.is_dir():
            shutil.copytree(item, target)
        else:
            shutil.copy2(item, target)
    if destination.exists():
        shutil.rmtree(destination, ignore_errors=True)
    temporary.replace(destination)


def prune_cache(root: Path, max_bytes: int = 2 * 1024 * 1024 * 1024, max_entries: int = 100) -> dict[str, int]:
    root.mkdir(parents=True, exist_ok=True)
    entries: list[tuple[Path, float, int]] = []
    total = 0
    for path in root.glob("*/*"):
        if not path.is_dir() or path.name.endswith(".tmp"):
            continue
        size = sum(p.stat().st_size for p in path.rglob("*") if p.is_file())
        total += size
        newest = path.stat().st_mtime
        entries.append((path, newest, size))
    entries.sort(key=lambda x: x[1], reverse=True)
    removed = 0
    while len(entries) > max_entries or total > max_bytes:
        path, _, size = entries.pop()
        shutil.rmtree(path, ignore_errors=True)
        total -= size
        removed += 1
    return {"entries": len(entries), "bytes": max(0, total), "removed": removed}
