from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field


class ConversionOptions(BaseModel):
    visual_mode: Literal["ultra", "balanced", "semantic"] = "ultra"
    ultra_visual_backend: Literal["raster", "svg"] = "raster"
    dpi: int = Field(default=180, ge=72, le=300)
    validation_dpi: int = Field(default=144, ge=72, le=240)
    raster_dpi: int = Field(default=0, ge=0, le=360, description="0 = match validation DPI for pixel-locked Ultra raster output")
    selectable_text: bool = True
    include_links: bool = True
    include_metadata: bool = True
    extract_tables: bool = True
    ocr_mode: Literal["auto", "off", "force"] = "auto"
    ocr_languages: str = Field(default="ara+eng", min_length=2, max_length=80)
    ocr_dpi: int = Field(default=220, ge=100, le=400)
    embed_assets: bool = True
    create_reference_renders: bool = True
    safe_external_links: bool = True
    build_search_index: bool = True
    semantic_headers: bool = True
    include_semantics: bool = True
    include_annotations: bool = True
    include_forms: bool = True
    preserve_pdf_metadata: bool = True
    standalone_csp: bool = True
    html_page_gaps: int = Field(default=28, ge=0, le=100)
    auto_validate: bool = True
    validation_threshold: float = Field(default=99.0, ge=90.0, le=100.0)
    use_cache: bool = True
    max_output_mb: int = Field(default=512, ge=64, le=4096)
    page_gap: int = Field(default=28, ge=0, le=100)
    preserve_page_labels: bool = True
    standalone_toolbar: bool = True
    local_form_persistence: bool = True
    allow_semantic_editing: bool = True


class ValidationRequest(BaseModel):
    page: int = Field(default=1, ge=1)
    dpi: int = Field(default=144, ge=72, le=240)
    alignment_probe: bool = True
    threshold: float = Field(default=99.0, ge=90.0, le=100.0)


class PageInfo(BaseModel):
    number: int
    page_label: str = ""
    width_pt: float
    height_pt: float
    width_mm: float
    height_mm: float
    rotation: int
    text_blocks: int
    text_spans: int
    characters: int
    words: int
    images: int
    drawings: int
    links: int
    annotations: int
    widgets: int
    tables: int
    fonts: int
    has_text: bool
    likely_scanned: bool
    language: str
    complexity: str


class AnalyzeResponse(BaseModel):
    toc: list[Any] = Field(default_factory=list)
    job_id: str
    filename: str
    page_count: int
    file_size: int
    sha256: str
    pages: list[PageInfo]
    metadata: dict[str, Any]
    toc_entries: int
    encrypted: bool
    pdf_version: str
