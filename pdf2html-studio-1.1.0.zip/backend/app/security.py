from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import pymupdf as fitz

PDF_MAGIC = b"%PDF-"
MAX_PAGE_MEGAPIXELS = 50
MAX_PDF_FILE_BYTES = 100 * 1024 * 1024
JOB_ID_RE = re.compile(r"^[a-f0-9]{16,64}$")


def validate_pdf(path: Path, max_pages: int = 2000, max_page_megapixels: int = MAX_PAGE_MEGAPIXELS) -> dict[str, Any]:
    with path.open("rb") as stream:
        if stream.read(5) != PDF_MAGIC:
            raise ValueError("الملف لا يبدأ بتوقيع PDF صالح.")
    with fitz.open(path) as doc:
        page_count = len(doc)
        if page_count <= 0:
            raise ValueError("الملف لا يحتوي على صفحات.")
        if page_count > max_pages:
            raise ValueError(f"الملف يحتوي على {page_count} صفحة، والحد المحلي هو {max_pages} صفحة.")
        encrypted = bool(doc.is_encrypted)
        max_page_megapixels = max(1, int(max_page_megapixels))
        for index, page in enumerate(doc, start=1):
            rect = page.rect
            # Worst-case guard: validation/preview can render at higher DPI than
            # the page's CSS dimensions. Refuse pathological page sizes before
            # allocating a giant bitmap in a local worker. 50 MP is generous for
            # normal office/design PDFs while protecting the process from OOM.
            pixels = (max(float(rect.width), 1.0) / 72.0 * 400.0) * (max(float(rect.height), 1.0) / 72.0 * 400.0)
            if pixels > max_page_megapixels * 1_000_000:
                raise ValueError(f"الصفحة {index} كبيرة جدًا للرندر المحلي الآمن (تتجاوز {max_page_megapixels} MP).")
        # An encrypted document that cannot expose pages is rejected cleanly rather than crashing later.
        if encrypted:
            try:
                if not doc.authenticate(""):
                    return {"page_count": page_count, "encrypted": True, "requires_password": True}
            except Exception:
                return {"page_count": page_count, "encrypted": True, "requires_password": True}
        return {"page_count": page_count, "encrypted": encrypted, "requires_password": False}


def safe_filename(name: str, fallback: str = "document.pdf") -> str:
    cleaned = Path(name or fallback).name
    cleaned = re.sub(r"[^\w.()\-\u0600-\u06FF ]+", "_", cleaned).strip(" .")
    if not cleaned:
        cleaned = fallback
    if not cleaned.lower().endswith(".pdf"):
        cleaned += ".pdf"
    return cleaned[:180]


def valid_job_id(job_id: str) -> bool:
    return bool(JOB_ID_RE.fullmatch(job_id))
