from __future__ import annotations

import hashlib
import json
import os
import shutil
import threading
import time
import uuid
import zipfile
from contextlib import asynccontextmanager
from concurrent.futures import Future, ThreadPoolExecutor
from pathlib import Path
from typing import Any

import pymupdf as fitz
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .cache import cache_dir, cache_key, has_cache, prune_cache, restore_cache, save_cache
from .models import AnalyzeResponse, ConversionOptions, ValidationRequest
from .pdf_engine import analyze_pdf, convert_pdf, make_zip, render_thumbnails
from .repair import build_patch_candidate
from .security import safe_filename, validate_pdf
from .validator import validate_all, validate_page, validate_html_text, write_quality_report
from .runtime import diagnostic_report, playwright_browser_status, tesseract_status
from .version import VERSION

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / "workspace"
UPLOADS = WORK / "uploads"
OUTPUTS = WORK / "outputs"
CACHE = WORK / "cache"

def _env_int(name: str, default: int, minimum: int, maximum: int) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(maximum, value))

MAX_FILE_SIZE = _env_int("P2H_MAX_FILE_SIZE", 100 * 1024 * 1024, 1 * 1024 * 1024, 2 * 1024 * 1024 * 1024)
MAX_PAGES = _env_int("P2H_MAX_PAGES", 2000, 1, 10000)
MAX_WORKERS = _env_int("P2H_MAX_WORKERS", min(6, os.cpu_count() or 2), 1, 12)
UPLOADS.mkdir(parents=True, exist_ok=True)
OUTPUTS.mkdir(parents=True, exist_ok=True)
CACHE.mkdir(parents=True, exist_ok=True)

@asynccontextmanager
async def lifespan(_: FastAPI):
    prune_cache(CACHE)
    # Recover jobs that were interrupted by a local app restart. Never pretend a
    # process that died halfway through succeeded; mark it resumable instead.
    for folder in list(OUTPUTS.iterdir()) if OUTPUTS.exists() else []:
        if not folder.is_dir():
            continue
        state_path = folder / "state.json"
        if not state_path.exists():
            continue
        try:
            state = json.loads(state_path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if state.get("state") in {"running", "queued", "cancelling"}:
            state.update({"state": "interrupted", "progress": min(float(state.get("progress", 0)), 99), "message": "تم إيقاف المعالجة بسبب إعادة تشغيل التطبيق. يمكنك استخدام إعادة المحاولة محليًا."})
            state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
            with STATE_LOCK:
                JOB_STATE[folder.name] = state
    try:
        yield
    finally:
        executor.shutdown(wait=False, cancel_futures=True)


app = FastAPI(title="PDF2HTML Studio", version=VERSION, lifespan=lifespan)
app.mount("/static", StaticFiles(directory=ROOT / "frontend"), name="static")
executor = ThreadPoolExecutor(max_workers=MAX_WORKERS, thread_name_prefix="pdf2html")
STATE_LOCK = threading.Lock()
JOB_STATE: dict[str, dict[str, Any]] = {}
JOB_CANCEL: dict[str, threading.Event] = {}
JOB_FUTURES: dict[str, Future] = {}
JOB_DELETE: set[str] = set()
ENGINE_INFO = {"version": VERSION, "local_only": True, "internet_required": False, "default_visual_backend": "raster", "default_raster_dpi": 180, "default_auto_validate": True, "max_file_size": MAX_FILE_SIZE, "max_pages": MAX_PAGES, "workers": MAX_WORKERS}


def _job_paths(job_id: str) -> tuple[Path, Path]:
    safe = Path(job_id).name
    if safe != job_id or not job_id or len(job_id) > 80 or not all(c in "0123456789abcdef" for c in job_id.lower()):
        raise HTTPException(400, "معرّف المهمة غير صالح.")
    return UPLOADS / safe, OUTPUTS / safe


def _state_path(outdir: Path) -> Path:
    outdir.mkdir(parents=True, exist_ok=True)
    return outdir / "state.json"


def _write_state(outdir: Path, **updates: Any) -> None:
    current: dict[str, Any] = {}
    path = _state_path(outdir)
    if path.exists():
        try:
            current = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            current = {}
    current.update({"updated_at": time.time(), **updates})
    path.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")
    with STATE_LOCK:
        JOB_STATE[outdir.name] = dict(current)


def _read_state(outdir: Path) -> dict[str, Any] | None:
    path = outdir / "state.json"
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass
    with STATE_LOCK:
        return JOB_STATE.get(outdir.name)


def _job_cancelled(job_id: str) -> bool:
    with STATE_LOCK:
        event = JOB_CANCEL.get(job_id)
    return bool(event and event.is_set())


def _enforce_output_quota(outdir: Path, max_mb: int) -> None:
    limit = max_mb * 1024 * 1024
    size = sum(p.stat().st_size for p in outdir.rglob("*") if p.is_file())
    if size > limit:
        raise RuntimeError(f"تجاوزت مخرجات المهمة الحد المسموح ({max_mb} MB).")


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _result_from_output(job_id: str, options: dict[str, Any], source: Path, outdir: Path, converted_meta: dict[str, Any] | None = None, cache_hit: bool = False) -> dict[str, Any]:
    manifest_path = outdir / "manifest.json"
    manifest = {}
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    quality = None
    if (outdir / "quality.json").exists():
        try:
            quality = json.loads((outdir / "quality.json").read_text(encoding="utf-8"))
        except Exception:
            pass
    page_count = manifest.get("page_count") or len(manifest.get("reports", []))
    metadata = manifest.get("metadata") or (converted_meta or {})
    reports = manifest.get("reports") or []
    quality_gate = None
    if quality:
        threshold = float(options.get("validation_threshold", 99.0))
        available = quality.get("status") != "unavailable" and quality.get("worst_page_score") is not None
        quality_gate = {"threshold": threshold, "status": "passed" if available and float(quality.get("worst_page_score", 0)) >= threshold else ("failed" if available else "unavailable"), "passed": bool(available and float(quality.get("worst_page_score", 0)) >= threshold), "overall_score": quality.get("overall_score"), "worst_page_score": quality.get("worst_page_score")}
    return {
        "job_id": job_id,
        "page_count": page_count,
        "html_url": f"/api/output/{job_id}/index.html",
        "zip_url": f"/api/output/{job_id}/pdf2html-project.zip",
        "manifest_url": f"/api/output/{job_id}/manifest.json",
        "quality_url": f"/api/output/{job_id}/quality.json" if (outdir / "quality.json").exists() else None,
        "quality_report_url": f"/api/output/{job_id}/quality-report.html" if (outdir / "quality-report.html").exists() else None,
        "security_audit_url": f"/api/output/{job_id}/security-audit.json" if (outdir / "security-audit.json").exists() else None,
        "elements_url": f"/api/output/{job_id}/reference/elements.json" if (outdir / "reference" / "elements.json").exists() else None,
        "preview_url": f"/api/output/{job_id}/index.html?page=1",
        "reference_url": f"/api/output/{job_id}/reference/page-1.svg",
        "reference_png_url": f"/api/output/{job_id}/reference/page-1.png",
        "metadata": metadata,
        "reports": reports,
        "options": options,
        "quality": quality,
        "quality_gate": quality_gate,
        "cache_hit": cache_hit,
        "source_sha256": _file_sha256(source),
        "html_sha256": hashlib.sha256((outdir / "index.html").read_bytes()).hexdigest() if (outdir / "index.html").exists() else None,
        "zip_sha256": hashlib.sha256((outdir / "pdf2html-project.zip").read_bytes()).hexdigest() if (outdir / "pdf2html-project.zip").exists() else None,
    }


def _run_conversion(job_id: str, options: dict[str, Any]) -> None:
    upload, outdir = _job_paths(job_id)
    source = upload / "source.pdf"
    cancel = JOB_CANCEL.get(job_id)
    started = time.time()
    try:
        outdir.mkdir(parents=True, exist_ok=True)
        if _job_cancelled(job_id):
            raise RuntimeError("تم إلغاء المهمة قبل بدء التحويل.")
        source_sha = _file_sha256(source)
        key = cache_key(source_sha, options)
        _write_state(outdir, state="running", progress=2, message="تهيئة محرك التحويل المحلي…", cache_key=key)
        cache_hit = False
        if options.get("use_cache", True) and has_cache(CACHE, key):
            _write_state(outdir, state="running", progress=14, message="استرجاع نتيجة مطابقة من الذاكرة المحلية…", cache_hit=True)
            restore_cache(CACHE, key, outdir)
            manifest_path = outdir / "manifest.json"
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            except Exception:
                manifest = {}
            original_name = json.loads((upload / "source-info.json").read_text(encoding="utf-8")).get("filename", "document.pdf") if (upload / "source-info.json").exists() else "document.pdf"
            manifest.update({"job_id": job_id, "cache_key": key, "cache_hit": True, "source": {"name": original_name, "sha256": source_sha}, "options": options})
            manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
            if not (outdir / "security-audit.json").exists():
                (outdir / "security-audit.json").write_text(json.dumps(manifest.get("local_only_audit", {}), ensure_ascii=False, indent=2), encoding="utf-8")
            cache_hit = True
        else:
            def progress(p: int, message: str):
                if cancel and cancel.is_set():
                    raise RuntimeError("تم إلغاء المهمة بواسطة المستخدم.")
                _write_state(outdir, state="running", progress=p, message=message)

            converted = convert_pdf(source, outdir, options, progress=progress)
            html_path = outdir / "index.html"
            html_path.write_text(converted.html, encoding="utf-8")
            _write_state(outdir, state="running", progress=84, message="تجهيز تقرير المصدر والحزمة…")
            source_info = {}
            try: source_info = json.loads((upload / "source-info.json").read_text(encoding="utf-8"))
            except Exception: pass
            manifest = {
                "schema_version": "1.0",
                "engine_version": ENGINE_INFO["version"],
                "job_id": job_id,
                "cache_key": key,
                "cache_hit": False,
                "source": {"name": safe_filename(source_info.get("filename", "document.pdf")), "sha256": source_sha},
                "options": options,
                "page_count": converted.page_count,
                "reports": converted.page_reports,
                "metadata": converted.metadata,
                "search_index_count": len(converted.search_index),
                "element_count": int(converted.metadata.get("element_count", 0)),
                "html_sha256": hashlib.sha256(html_path.read_bytes()).hexdigest(),
                "local_only_audit": converted.metadata.get("local_only_audit", {}),
            }
            (outdir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
            (outdir / "security-audit.json").write_text(json.dumps(converted.metadata.get("local_only_audit", {}), ensure_ascii=False, indent=2), encoding="utf-8")
        html_path = outdir / "index.html"
        page_count = 0
        with fitz.open(source) as doc:
            page_count = len(doc)
        quality = None
        if options.get("auto_validate") and not cache_hit:
            _write_state(outdir, state="running", progress=88, message="تشغيل بوابة الجودة البصرية…")
            threshold = float(options.get("validation_threshold", 99.0))
            try:
                quality = validate_all(source, html_path, int(options.get("validation_dpi", 144)), outdir, page_count, alignment_probe=False, threshold=threshold)
            except Exception as exc:
                # Conversion remains usable when Chromium/Playwright is unavailable; QA becomes explicitly unavailable instead of failing the whole conversion.
                quality = {
                    "status": "unavailable",
                    "overall_score": None,
                    "worst_page_score": None,
                    "worst_page": None,
                    "pass_rate": None,
                    "threshold": threshold,
                    "page_count": page_count,
                    "pages": [],
                    "error": str(exc),
                    "local_only": True,
                }
            (outdir / "quality.json").write_text(json.dumps(quality, ensure_ascii=False, indent=2), encoding="utf-8")
            if quality.get("status") != "unavailable":
                write_quality_report(outdir, quality)
                _write_state(outdir, state="running", progress=95, message=f"بوابة الجودة: {quality['overall_score']:.2f}% • اجتياز {quality['pass_rate']:.0f}%")
            else:
                _write_state(outdir, state="running", progress=95, message="اكتمل التحويل، لكن الفحص البصري غير متاح في هذه البيئة.")
        elif (outdir / "quality.json").exists():
            try: quality = json.loads((outdir / "quality.json").read_text(encoding="utf-8"))
            except Exception: quality = None
        # Persist the latest QA summary into the manifest before packaging.
        manifest_path = outdir / "manifest.json"
        if quality is not None and manifest_path.exists():
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            except Exception:
                manifest = {}
            manifest["quality_summary"] = {
                "overall_score": quality.get("overall_score"),
                "worst_page_score": quality.get("worst_page_score"),
                "pass_rate": quality.get("pass_rate"),
                "threshold": float(options.get("validation_threshold", 99.0)),
            }
            manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        _enforce_output_quota(outdir, int(options.get("max_output_mb", 512)))
        result = _result_from_output(job_id, options, source, outdir, cache_hit=cache_hit)
        (outdir / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        _write_state(outdir, state="running", progress=97, message="إنشاء ZIP مستقل…")
        zip_path = outdir / "pdf2html-project.zip"
        make_zip(html_path.read_text(encoding="utf-8"), outdir, zip_path)
        _enforce_output_quota(outdir, int(options.get("max_output_mb", 512)))
        if options.get("use_cache", True) and not cache_hit:
            try:
                save_cache(CACHE, key, outdir)
            except Exception:
                pass
        result = _result_from_output(job_id, options, source, outdir, cache_hit=cache_hit)
        (outdir / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        _write_state(outdir, state="completed", progress=100, message=f"اكتمل التحويل خلال {time.time()-started:.1f}s.", result=result)
        prune_cache(CACHE)
    except Exception as exc:
        status = "cancelled" if "إلغاء" in str(exc) else "failed"
        _write_state(outdir, state=status, progress=100, message=str(exc), error=str(exc))
    finally:
        delete_requested = False
        with STATE_LOCK:
            delete_requested = job_id in JOB_DELETE
            JOB_CANCEL.pop(job_id, None)
            JOB_FUTURES.pop(job_id, None)
            JOB_DELETE.discard(job_id)
        if delete_requested:
            shutil.rmtree(upload, ignore_errors=True)
            shutil.rmtree(outdir, ignore_errors=True)


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")


@app.get("/api/health")
def health():
    return {**ENGINE_INFO, "ok": True, "service": "pdf2html-studio"}


@app.get("/api/capabilities")
def capabilities():
    report = diagnostic_report(ROOT)
    packages = report.get("packages", {})
    pw = report.get("chromium", {}).get("playwright", {})
    tesseract = report.get("tesseract", {})
    system_chromium = report.get("chromium", {}).get("system_executable")
    visual_qa = bool(system_chromium or pw.get("installed"))
    return {
        "local_only": True, "internet_required": False, "runtime_network": False,
        "version": VERSION,
        "python": report.get("python", {}),
        "packages": packages,
        "chromium": visual_qa, "playwright_browser": pw.get("installed", False),
        "tesseract": tesseract.get("installed", False), "arabic_ocr": bool(tesseract.get("arabic", False)),
        "ocr_languages": tesseract.get("languages", []), "workers": MAX_WORKERS,
        "features": {"raster_ultra": True, "svg_ultra": True, "standalone_html": True, "ocr": tesseract.get("installed", False), "arabic_search": True, "tables": True, "forms": True, "annotations": True, "toc": True, "visual_diff": visual_qa, "auto_repair": visual_qa, "cache": True, "batch": True, "self_test": True, "cleanup": True}
    }


@app.get("/api/self-test")
def self_test():
    import tempfile
    from .validator import validate_all
    started = time.time()
    with tempfile.TemporaryDirectory(prefix="p2h-selftest-") as tmp:
        root = Path(tmp); pdf = root / "self-test.pdf"; out = root / "out"
        doc = fitz.open(); page = doc.new_page(width=300, height=420)
        page.insert_text((30, 50), "PDF2HTML Studio local self-test", fontsize=14)
        page.insert_text((30, 80), "اختبار عربي Local", fontsize=11)
        for x in (30, 120, 210, 270): page.draw_line((x, 110), (x, 190), color=(0, 0, 0), width=0.7)
        for y in (110, 150, 190): page.draw_line((30, y), (270, y), color=(0, 0, 0), width=0.7)
        doc.save(pdf); doc.close()
        checks = {"pdf_parse": False, "standalone_html": False, "csp": False, "local_only": False, "chromium_validation": False}
        try:
            info = analyze_pdf(pdf); checks["pdf_parse"] = info["page_count"] == 1
            options = ConversionOptions(visual_mode="ultra", ultra_visual_backend="raster", dpi=96, validation_dpi=96, raster_dpi=0, auto_validate=False, use_cache=False).model_dump()
            converted = convert_pdf(pdf, out, options)
            (out / "index.html").write_text(converted.html, encoding="utf-8")
            checks["standalone_html"] = "<!doctype html>" in converted.html.lower() and "window.__PDF2HTML__" in converted.html
            checks["csp"] = "Content-Security-Policy" in converted.html
            audit = converted.metadata.get("local_only_audit", {})
            checks["local_only"] = bool(audit.get("local_only")) and int(audit.get("external_resource_count", 1)) == 0
            quality = None
            if capabilities().get("chromium"):
                quality = validate_all(pdf, out / "index.html", 96, out, 1, alignment_probe=False, threshold=95.0)
                checks["chromium_validation"] = quality["pass_rate"] == 100.0
            return {"ok": all(checks.values()), "checks": checks, "quality": quality, "elapsed_seconds": round(time.time()-started, 3), "local_only": True, "version": ENGINE_INFO["version"]}
        except Exception as exc:
            return {"ok": False, "checks": checks, "error": str(exc), "elapsed_seconds": round(time.time()-started, 3), "local_only": True, "version": ENGINE_INFO["version"]}


@app.get("/api/diagnostics")
def diagnostics():
    return diagnostic_report(ROOT)


@app.get("/api/doctor")
def doctor():
    return diagnostic_report(ROOT)


async def _save_upload(file: UploadFile, target: Path) -> tuple[int, str]:
    target.parent.mkdir(parents=True, exist_ok=True)
    size = 0
    with target.open("wb") as f:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > MAX_FILE_SIZE:
                raise HTTPException(413, f"حجم الملف يتجاوز الحد المحلي المسموح به ({MAX_FILE_SIZE / (1024*1024):.0f}MB).")
            f.write(chunk)
    info = validate_pdf(target, MAX_PAGES)
    if info.get("requires_password"):
        raise ValueError("الملف مشفر ويتطلب كلمة مرور؛ لا يمكن قراءته محليًا دون مفتاح.")
    digest = _file_sha256(target)
    return size, digest


@app.post("/api/analyze", response_model=AnalyzeResponse)
async def analyze(file: UploadFile = File(...)):
    name = safe_filename(file.filename or "document.pdf")
    if not name.lower().endswith(".pdf"):
        raise HTTPException(400, "يرجى اختيار ملف PDF.")
    job_id = uuid.uuid4().hex
    job = UPLOADS / job_id
    job.mkdir(parents=True, exist_ok=False)
    pdf_path = job / "source.pdf"
    try:
        size, digest = await _save_upload(file, pdf_path)
        (job / "source-info.json").write_text(json.dumps({"filename": name, "sha256": digest}, ensure_ascii=False, indent=2), encoding="utf-8")
        result = analyze_pdf(pdf_path)
        render_thumbnails(pdf_path, job / "thumbs", dpi=48)
        (job / "analysis.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    except HTTPException:
        shutil.rmtree(job, ignore_errors=True); raise
    except Exception as exc:
        shutil.rmtree(job, ignore_errors=True); raise HTTPException(422, f"تعذر قراءة ملف PDF محليًا: {exc}") from exc
    result.update({"job_id": job_id, "filename": name, "file_size": size, "sha256": digest})
    with STATE_LOCK:
        JOB_STATE[job_id] = {"job_id": job_id, "state": "analyzed", "progress": 0, "message": "تم تحليل الملف."}
    return result


@app.post("/api/analyze-batch")
async def analyze_batch(files: list[UploadFile] = File(...)):
    if not files or len(files) > 12:
        raise HTTPException(400, "يمكن تحليل من 1 إلى 12 ملفًا في الدفعة المحلية.")
    results = []
    for file in files:
        try:
            item = await analyze(file)
            results.append(item.model_dump() if hasattr(item, "model_dump") else item)
        except HTTPException as exc:
            results.append({"filename": file.filename or "document.pdf", "ok": False, "error": exc.detail})
    return {"count": len(results), "successful": sum(1 for r in results if isinstance(r, dict) and r.get("job_id")), "results": results, "local_only": True}


@app.get("/api/upload/{job_id}/thumbs/page-{page}.png")
def thumbnail(job_id: str, page: int):
    if page < 1: raise HTTPException(400, "رقم الصفحة غير صالح.")
    upload, _ = _job_paths(job_id); path = upload / "thumbs" / f"page-{page}.png"
    if not path.is_file(): raise HTTPException(404, "الصورة المصغرة غير موجودة.")
    return FileResponse(path, media_type="image/png")


@app.get("/api/jobs")
def list_jobs(limit: int = 50):
    items = []
    for folder in sorted(UPLOADS.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True) if UPLOADS.exists() else []:
        if not folder.is_dir():
            continue
        state = _read_state(OUTPUTS / folder.name) or {"state": "analyzed", "progress": 0}
        item = {"job_id": folder.name, **state}
        info_path = folder / "source-info.json"
        analysis_path = folder / "analysis.json"
        if info_path.exists():
            try:
                info = json.loads(info_path.read_text(encoding="utf-8"))
                item.update({"filename": info.get("filename"), "sha256": info.get("sha256")})
            except Exception:
                pass
        if analysis_path.exists():
            try:
                summary = json.loads(analysis_path.read_text(encoding="utf-8"))
                item["page_count"] = summary.get("page_count") or len(summary.get("pages", []))
            except Exception:
                pass
        result_path = OUTPUTS / folder.name / "result.json"
        if result_path.exists():
            try:
                result = json.loads(result_path.read_text(encoding="utf-8"))
                item["quality"] = result.get("quality")
                item["cache_hit"] = result.get("cache_hit", False)
            except Exception:
                pass
        items.append(item)
        if len(items) >= max(1, min(limit, 200)):
            break
    return {"count": len(items), "jobs": items, "local_only": True}


@app.get("/api/job/{job_id}/analysis")
def job_analysis(job_id: str):
    upload, _ = _job_paths(job_id)
    path = upload / "analysis.json"
    if not path.is_file():
        raise HTTPException(404, "لا يوجد تحليل محفوظ لهذه المهمة.")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise HTTPException(500, "تعذر قراءة التحليل المحلي المحفوظ.") from exc
    info = upload / "source-info.json"
    if info.exists():
        try:
            data.update(json.loads(info.read_text(encoding="utf-8")))
        except Exception:
            pass
    return data


@app.get("/api/workspace")
def workspace_stats():
    def folder_bytes(root: Path) -> int:
        return sum(p.stat().st_size for p in root.rglob("*") if p.is_file()) if root.exists() else 0
    return {"uploads": {"bytes": folder_bytes(UPLOADS)}, "outputs": {"bytes": folder_bytes(OUTPUTS)}, "cache": {"bytes": folder_bytes(CACHE)}, "jobs": sum(1 for p in UPLOADS.iterdir() if p.is_dir()) if UPLOADS.exists() else 0, "workers": MAX_WORKERS, "version": ENGINE_INFO["version"], "local_only": True}


@app.get("/api/job/{job_id}")
def job_status(job_id: str):
    upload, output = _job_paths(job_id)
    if not upload.exists(): raise HTTPException(404, "المهمة غير موجودة.")
    state = _read_state(output) or {"state": "analyzed", "progress": 0, "message": "بانتظار التحويل…"}
    if (output / "quality.json").exists():
        try: state["quality"] = json.loads((output / "quality.json").read_text(encoding="utf-8"))
        except Exception: pass
    if (output / "result.json").exists() and "result" not in state:
        try: state["result"] = json.loads((output / "result.json").read_text(encoding="utf-8"))
        except Exception: pass
    return {"job_id": job_id, **state}


@app.post("/api/convert/{job_id}")
async def convert(job_id: str, options: ConversionOptions | None = None):
    options = options or ConversionOptions()
    upload, outdir = _job_paths(job_id); source = upload / "source.pdf"
    if not source.exists(): raise HTTPException(404, "المهمة غير موجودة.")
    old = _read_state(outdir) or {}
    if old.get("state") in {"running", "queued"}:
        return JSONResponse({"job_id": job_id, "state": old.get("state"), "progress": old.get("progress", 0), "message": old.get("message", "جاري التحويل…")}, status_code=202)
    if outdir.exists(): shutil.rmtree(outdir, ignore_errors=True)
    outdir.mkdir(parents=True, exist_ok=True)
    cancel = threading.Event()
    with STATE_LOCK: JOB_CANCEL[job_id] = cancel
    _write_state(outdir, state="queued", progress=0, message="تم وضع المهمة في قائمة التحويل…")
    future = executor.submit(_run_conversion, job_id, options.model_dump())
    with STATE_LOCK: JOB_FUTURES[job_id] = future
    return JSONResponse({"job_id": job_id, "state": "queued", "progress": 0, "message": "تم وضع المهمة في قائمة التحويل…"}, status_code=202)


@app.post("/api/convert-batch")
async def convert_batch(payload: dict[str, Any]):
    job_ids = payload.get("job_ids") or []
    if not isinstance(job_ids, list) or not job_ids or len(job_ids) > 12:
        raise HTTPException(400, "يجب تقديم من 1 إلى 12 مهمة.")
    raw_options = payload.get("options") or ConversionOptions().model_dump()
    options = ConversionOptions(**raw_options)
    results: list[dict[str, Any]] = []
    for jid in job_ids:
        try:
            result = await convert(str(jid), options)
            payload = json.loads(result.body.decode("utf-8")) if isinstance(result, JSONResponse) else result
            results.append(dict(payload))
        except Exception as exc:
            results.append({"job_id": str(jid), "ok": False, "error": str(exc)})
    return {"count": len(results), "queued": sum(1 for item in results if item.get("state") == "queued"), "failed": sum(1 for item in results if item.get("ok") is False), "results": results, "local_only": True}


@app.post("/api/retry/{job_id}")
async def retry_job(job_id: str):
    upload, outdir = _job_paths(job_id)
    source = upload / "source.pdf"
    if not source.exists():
        raise HTTPException(404, "المهمة غير موجودة.")
    state = _read_state(outdir) or {}
    if state.get("state") in {"running", "queued", "cancelling"}:
        raise HTTPException(409, "المهمة ما زالت قيد المعالجة.")
    options_data: dict[str, Any] = {}
    manifest_path = outdir / "manifest.json"
    if manifest_path.exists():
        try:
            options_data = json.loads(manifest_path.read_text(encoding="utf-8")).get("options") or {}
        except Exception:
            options_data = {}
    if not options_data and (outdir / "result.json").exists():
        try:
            options_data = json.loads((outdir / "result.json").read_text(encoding="utf-8")).get("options") or {}
        except Exception:
            options_data = {}
    options = ConversionOptions(**options_data) if options_data else ConversionOptions()
    return await convert(job_id, options)


@app.post("/api/batch-export")
def batch_export(payload: dict[str, Any]):
    job_ids = payload.get("job_ids") or []
    if not isinstance(job_ids, list) or not 1 <= len(job_ids) <= 12:
        raise HTTPException(400, "يجب تقديم من 1 إلى 12 مهمة.")
    unique = []
    seen = set()
    for jid in job_ids:
        jid = str(jid)
        if jid in seen:
            continue
        _job_paths(jid)  # validates the identifier
        seen.add(jid); unique.append(jid)
    if not unique:
        raise HTTPException(400, "لا توجد مهام صالحة للتصدير.")
    anchor = OUTPUTS / unique[0]
    anchor.mkdir(parents=True, exist_ok=True)
    bundle = anchor / "pdf2html-batch.zip"
    manifest_rows = []
    with zipfile.ZipFile(bundle, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for jid in unique:
            upload, outdir = _job_paths(jid)
            state = _read_state(outdir) or {}
            project = outdir / "pdf2html-project.zip"
            if state.get("state") != "completed" or not project.is_file():
                continue
            name = "document"
            info = upload / "source-info.json"
            try:
                name = Path(json.loads(info.read_text(encoding="utf-8")).get("filename", "document.pdf")).stem or "document"
            except Exception:
                pass
            name = Path(safe_filename(name)).stem or "document"
            entry = f"{name}-{jid[:8]}/pdf2html-project.zip"
            z.write(project, entry)
            manifest_rows.append({"job_id": jid, "name": name, "project_zip": entry, "pages": (state.get("result") or {}).get("page_count")})
        z.writestr("batch-manifest.json", json.dumps({"schema_version":"1.0","local_only":True,"count":len(manifest_rows),"projects":manifest_rows}, ensure_ascii=False, indent=2))
    if not manifest_rows:
        bundle.unlink(missing_ok=True)
        raise HTTPException(409, "لا توجد نتائج مكتملة قابلة للتصدير.")
    return {"ok": True, "job_id": unique[0], "count": len(manifest_rows), "url": f"/api/output/{unique[0]}/pdf2html-batch.zip", "manifest": manifest_rows, "local_only": True}


@app.post("/api/cancel/{job_id}")
def cancel(job_id: str):
    upload, outdir = _job_paths(job_id)
    if not upload.exists(): raise HTTPException(404, "المهمة غير موجودة.")
    with STATE_LOCK:
        event = JOB_CANCEL.get(job_id)
        future = JOB_FUTURES.get(job_id)
    state = _read_state(outdir) or {}
    if state.get("state") in {"completed", "failed", "cancelled"}:
        return {"ok": True, "job_id": job_id, "state": state.get("state"), "message": "المهمة في حالة نهائية بالفعل."}
    if event:
        event.set()
    if future and future.cancel():
        _write_state(outdir, state="cancelled", progress=100, message="تم إلغاء المهمة.")
        result_state = "cancelled"
    else:
        _write_state(outdir, state="cancelling", progress=99, message="جارٍ إلغاء المهمة…")
        result_state = "cancelling"
    return {"ok": True, "job_id": job_id, "state": result_state}


@app.get("/api/output/{job_id}/{filename:path}")
def output(job_id: str, filename: str):
    _, base = _job_paths(job_id)
    path = (base / filename).resolve(); root = base.resolve()
    if root not in path.parents or not path.is_file(): raise HTTPException(404, "الملف غير موجود.")
    media = None
    if path.suffix == ".html": media = "text/html; charset=utf-8"
    elif path.suffix == ".json": media = "application/json; charset=utf-8"
    elif path.suffix == ".svg": media = "image/svg+xml"
    elif path.suffix == ".png": media = "image/png"
    elif path.suffix == ".zip": media = "application/zip"
    return FileResponse(path, media_type=media, filename=path.name if path.suffix not in {".html", ".svg", ".json", ".png"} else None)


@app.post("/api/validate/{job_id}")
def validate(job_id: str, request: ValidationRequest | None = None):
    request = request or ValidationRequest(); upload, outdir = _job_paths(job_id)
    source = upload / "source.pdf"; html_path = outdir / "index.html"
    if not source.exists() or not html_path.exists(): raise HTTPException(404, "نفّذ التحويل أولًا.")
    try:
        with fitz.open(source) as doc:
            page_count = len(doc)
        if request.page > page_count: raise HTTPException(400, "رقم الصفحة خارج النطاق.")
        result = validate_page(source, html_path, request.page, request.dpi, outdir, alignment_probe=request.alignment_probe)
        result["threshold"] = request.threshold
        result["passed"] = bool(result.get("score", 0) >= request.threshold)
    except HTTPException: raise
    except Exception as exc: raise HTTPException(422, f"تعذر تنفيذ فحص التطابق: {exc}") from exc
    response = {k: v for k, v in result.items() if k not in {"diff_file", "html_render"}}
    response["diff_url"] = f"/api/output/{job_id}/diff/page-{request.page}.png"
    response["html_render_url"] = f"/api/output/{job_id}/html-renders/page-{request.page}.png"
    return response


@app.post("/api/repair/{job_id}/{page}")
def repair_page(job_id: str, page: int):
    upload, outdir = _job_paths(job_id)
    source = upload / "source.pdf"
    html_path = outdir / "index.html"
    if not source.exists() or not html_path.exists():
        raise HTTPException(404, "نفّذ التحويل أولًا.")
    with fitz.open(source) as doc:
        if page < 1 or page > len(doc):
            raise HTTPException(400, "رقم الصفحة خارج النطاق.")
    try:
        manifest = {}
        manifest_path = outdir / "manifest.json"
        if manifest_path.exists():
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            except Exception:
                manifest = {}
        options = manifest.get("options") or {}
        repair_dpi = int(options.get("validation_dpi") or 144)
        result = build_patch_candidate(source, html_path, page, outdir, dpi=repair_dpi, max_regions=24)
        if result.get("improved"):
            result["candidate_url"] = f"/api/output/{job_id}/repair/page-{page}/candidate.html"
            result["apply_url"] = f"/api/repair/{job_id}/{page}/apply"
        return result
    except Exception as exc:
        raise HTTPException(422, f"تعذر إنشاء إصلاح تلقائي: {exc}") from exc


@app.post("/api/repair/{job_id}/{page}/apply")
def apply_repair(job_id: str, page: int):
    upload, outdir = _job_paths(job_id)
    source = upload / "source.pdf"
    html_path = outdir / "index.html"
    candidate = outdir / "repair" / f"page-{page}" / "candidate.html"
    if not source.exists() or not html_path.exists():
        raise HTTPException(404, "نفّذ التحويل أولًا.")
    if not candidate.is_file():
        raise HTTPException(404, "لا يوجد إصلاح مرشح لهذه الصفحة. شغّل الإصلاح أولًا.")
    # Candidate was already measured before being exposed to the user. Applying
    # it atomically keeps the canonical output consistent even if validation is
    # interrupted afterwards.
    temp = html_path.with_suffix(".repair.tmp")
    shutil.copy2(candidate, temp)
    temp.replace(html_path)
    manifest_path = outdir / "manifest.json"
    manifest: dict[str, Any] = {}
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception:
            manifest = {}
    quality = None
    try:
        with fitz.open(source) as doc:
            page_count = len(doc)
        manifest_options = manifest.get("options") or {}
        repair_dpi = int(manifest_options.get("validation_dpi") or 144)
        repair_threshold = float(manifest_options.get("validation_threshold") or 99.0)
        quality = validate_all(source, html_path, repair_dpi, outdir, page_count, alignment_probe=False, threshold=repair_threshold)
        (outdir / "quality.json").write_text(json.dumps(quality, ensure_ascii=False, indent=2), encoding="utf-8")
        write_quality_report(outdir, quality)
    except Exception as exc:
        manifest.setdefault("warnings", []).append({"kind":"repair-qa", "message":str(exc)})
    manifest["active_repairs"] = sorted(set((manifest.get("active_repairs") or []) + [page]))
    manifest.setdefault("options", {})["use_cache"] = False
    manifest["cache_invalidated_by_repair"] = True
    manifest["html_sha256"] = hashlib.sha256(html_path.read_bytes()).hexdigest()
    if quality:
        manifest["quality_summary"] = {k: quality.get(k) for k in ("overall_score", "worst_page_score", "pass_rate", "threshold")}
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    zip_path = outdir / "pdf2html-project.zip"
    make_zip(html_path.read_text(encoding="utf-8"), outdir, zip_path)
    (outdir / "result.json").unlink(missing_ok=True)
    result = _result_from_output(job_id, manifest.get("options") or {}, source, outdir, cache_hit=False)
    (outdir / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    _write_state(outdir, state="completed", progress=100, message=f"تم اعتماد إصلاح الصفحة {page}.", result=result, quality=quality)
    return {"ok": True, "job_id": job_id, "page": page, "quality": quality, "result": result, "html_url": result["html_url"], "zip_url": result["zip_url"]}


@app.post("/api/validate-all/{job_id}")
def validate_every_page(job_id: str, request: ValidationRequest | None = None):
    request = request or ValidationRequest(); upload, outdir = _job_paths(job_id)
    source = upload / "source.pdf"; html_path = outdir / "index.html"
    if not source.exists() or not html_path.exists(): raise HTTPException(404, "نفّذ التحويل أولًا.")
    with fitz.open(source) as doc: page_count = len(doc)
    try: result = validate_all(source, html_path, request.dpi, outdir, page_count, alignment_probe=request.alignment_probe, threshold=request.threshold)
    except Exception as exc: raise HTTPException(422, f"تعذر فحص جميع الصفحات: {exc}") from exc
    persisted = json.loads(json.dumps(result, ensure_ascii=False))
    (outdir / "quality.json").write_text(json.dumps(persisted, ensure_ascii=False, indent=2), encoding="utf-8")
    write_quality_report(outdir, persisted)
    response = {**result, "pages": [{**p, "diff_url": f"/api/output/{job_id}/diff/page-{p['page']}.png", "html_render_url": f"/api/output/{job_id}/html-renders/page-{p['page']}.png", "reference_url": f"/api/output/{job_id}/reference/page-{p['page']}.png"} for p in result["pages"]]}
    _write_state(outdir, quality=persisted)
    return response


@app.get("/api/quality/{job_id}")
def quality(job_id: str):
    _, outdir = _job_paths(job_id); path = outdir / "quality.json"
    if not path.is_file(): raise HTTPException(404, "لم يتم تنفيذ فحص الجودة بعد.")
    return json.loads(path.read_text(encoding="utf-8"))


@app.delete("/api/job/{job_id}")
def delete_job(job_id: str):
    upload, output = _job_paths(job_id)
    if not upload.exists() and not output.exists():
        raise HTTPException(404, "المهمة غير موجودة.")
    with STATE_LOCK:
        event = JOB_CANCEL.get(job_id)
        future = JOB_FUTURES.get(job_id)
        active = bool(future and not future.done())
        if active:
            JOB_DELETE.add(job_id)
    if event:
        event.set()
    if active:
        if future and future.cancel():
            with STATE_LOCK:
                JOB_DELETE.discard(job_id)
            shutil.rmtree(upload, ignore_errors=True)
            shutil.rmtree(output, ignore_errors=True)
            with STATE_LOCK:
                JOB_STATE.pop(job_id, None); JOB_CANCEL.pop(job_id, None); JOB_FUTURES.pop(job_id, None)
            return {"ok": True, "job_id": job_id, "state": "deleted"}
        _write_state(output, state="deleting", progress=99, message="جارٍ إيقاف المهمة ثم حذفها محليًا…")
        return JSONResponse({"ok": True, "job_id": job_id, "state": "deleting", "message": "سيُحذف العمل بعد توقف الـworker بأمان."}, status_code=202)
    shutil.rmtree(upload, ignore_errors=True); shutil.rmtree(output, ignore_errors=True)
    with STATE_LOCK:
        JOB_STATE.pop(job_id, None); JOB_CANCEL.pop(job_id, None); JOB_FUTURES.pop(job_id, None); JOB_DELETE.discard(job_id)
    return {"ok": True, "job_id": job_id, "state": "deleted"}


@app.post("/api/cleanup")
def cleanup_workspace(max_age_hours: int = 24, include_cache: bool = False):
    max_age_hours = max(1, min(int(max_age_hours), 24 * 30))
    cutoff = time.time() - max_age_hours * 3600
    removed_jobs = 0; bytes_removed = 0
    for folder in list(UPLOADS.iterdir()) if UPLOADS.exists() else []:
        if not folder.is_dir() or folder.stat().st_mtime >= cutoff:
            continue
        job_id = folder.name
        state = _read_state(OUTPUTS / job_id) or {}
        if state.get("state") in {"running", "queued", "cancelling"}:
            continue
        pair = [folder, OUTPUTS / job_id]
        size = sum(p.stat().st_size for root in pair if root.exists() for p in root.rglob("*") if p.is_file())
        for root in pair:
            shutil.rmtree(root, ignore_errors=True)
        with STATE_LOCK:
            JOB_STATE.pop(job_id, None); JOB_CANCEL.pop(job_id, None); JOB_FUTURES.pop(job_id, None)
        bytes_removed += size; removed_jobs += 1
    cache_removed = 0
    if include_cache:
        cache_removed = prune_cache(CACHE).get("removed", 0)
    return {"ok": True, "jobs_removed": removed_jobs, "bytes_removed": bytes_removed, "cache_entries_removed": cache_removed, "max_age_hours": max_age_hours, "local_only": True}


@app.post("/api/cache/prune")
def cache_prune():
    return prune_cache(CACHE)


@app.delete("/api/cache")
def cache_clear():
    removed = 0
    bytes_removed = 0
    for folder in list(CACHE.glob("*/*")) if CACHE.exists() else []:
        if not folder.is_dir():
            continue
        size = sum(p.stat().st_size for p in folder.rglob("*") if p.is_file())
        shutil.rmtree(folder, ignore_errors=True)
        removed += 1
        bytes_removed += size
    return {"ok": True, "entries_removed": removed, "bytes_removed": bytes_removed, "local_only": True}
