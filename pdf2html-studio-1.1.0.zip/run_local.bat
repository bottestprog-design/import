@echo off
setlocal
cd /d %~dp0
where python >nul 2>&1
if not errorlevel 1 (
  python --version >nul 2>&1
  if not errorlevel 1 (
    python run_local.py %*
    set "RC=%ERRORLEVEL%"
    if "%RC%"=="0" goto done
    echo.
    echo Python command returned %RC%. Trying the py launcher if available...
  )
)
where py >nul 2>&1
if not errorlevel 1 (
  py -3 --version >nul 2>&1
  if not errorlevel 1 (
    py -3 run_local.py %*
    set "RC=%ERRORLEVEL%"
    goto done
  )
)
echo Python 3 was not found or could not be started.
echo Install Python 3.11+ and reopen the terminal.
set "RC=1"
:done
if not "%RC%"=="0" (
  echo.
  echo PDF2HTML Studio failed to start. Run "python run_local.py --doctor" or "py -3 run_local.py --doctor" for diagnostics.
)
endlocal & exit /b %RC%
