# Roadmap — 1.0 baseline and hardening

## 1.0 — Core local studio — implemented

- Local-only FastAPI + frontend
- Ultra visual fidelity foundation
- SVG/raster backends
- OCR fallback
- Search/selectable text
- Tables
- Forms/annotations overlays
- Visual QA/diff
- Auto-repair candidates
- Batch/cache/retry/cancellation
- Local history
- Standalone HTML + ZIP + manifest
- Local release audit

## 1.1 — Fidelity hardening

- Font/glyph metric calibration for pathological PDFs
- Smarter region → DOM/SVG attribution
- More repair strategies with bounded optimization
- Better transparent/overprint/shading handling
- Larger Arabic/RTL regression corpus

## 1.2 — Distribution

- Windows/macOS/Linux launchers and packaging
- Dependency health checker
- Reproducible environment/lock file
- Accessibility audit and keyboard-first completion

## 1.3 — Scale

- Larger batch queue controls
- Resumable conversion checkpoints
- More aggressive cache GC policies
- Performance budgets for very large documents
