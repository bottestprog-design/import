# PDF2HTML Studio — GDD / Product Design Document

## 0. الحالة الحالية

**الإصدار التنفيذي الحالي: 1.1.0 — Core Local Studio**

الهدف: تطبيق Local-first يحول PDF إلى HTML مستقل عالي fidelity، مع جعل **المظهر البصري هو مصدر الحقيقة** وإضافة طبقات النص والتفاعل والبنية كتحسينات مستقلة.

### الحالة الحالية 1.1.0

| المجال | الحالة التنفيذية الحالية | ملاحظات الدفعة التالية |
|---|---|---|
| Upload / Analyze | ✅ مكتمل | edge cases فقط |
| Visual Fidelity Core | ✅ مكتمل | توسعة corpus والحالات النادرة |
| Multi-page HTML | ✅ مكتمل | tuning للمستندات العملاقة |
| Text Selection / Search | ✅ مكتمل | OCR/RTL calibration إضافية |
| Fonts | ✅ مكتمل عمليًا | حالات Type3/CFF النادرة |
| Links / TOC | ✅ مكتمل | PDF غير القياسي فقط |
| OCR | ✅ مكتمل محليًا | نماذج محلية إضافية اختيارية |
| Tables | ✅ مكتمل أساسيًا | cell-level repair للحالات المعقدة |
| Visual QA / Diff | ✅ مكتمل | regression corpus أوسع |
| Auto-repair | ✅ مكتمل كـcandidate + apply | repair أدق لكل عنصر |
| Forms / Annotations | ✅ طبقة تفاعلية | parity أوسع للأنواع النادرة |
| Batch jobs | ✅ مكتمل | scheduling أوسع |
| Performance / Cache | ✅ مكتمل | memory tuning للمستندات العملاقة |
| Production sandbox / quotas | ✅ حدود محلية | hardening إضافي |
| UI / preview workspace | ✅ مكتمل | accessibility + micro-polish |
| Semantic reconstruction | ✅ مكتمل أساسيًا | فهم دلالي أعمق اختياريًا |

**التقدير العملي:** Core Local Studio يعمل كمنتج 1.0. المتبقي هو **hardening وليس فجوات أساسية في الـpipeline**.

> لا يعني ذلك ضمان 100% لكل PDF؛ المستندات ذات الخطوط/المشغلات غير المعتادة جدًا قد تحتاج fallback إضافيًا.

---|---:|---:|
| Upload / Analyze | 90% | 10% |
| Visual Fidelity Core | 82% | 25% |
| Multi-page HTML | 88% | 20% |
| Text Selection / Search foundation | 82% | 25% |
| Fonts | 62% | 45% |
| Links / TOC metadata | 74% | 35% |
| OCR fallback | 48% | 60% |
| Table intelligence | 45% | 60% |
| Visual QA / Diff | 82% | 30% |
| Auto-repair | 28% | 80% |
| Forms / Annotations | 42% | 70% |
| Batch jobs | 0% | 100% |
| Performance / caching | 38% | 75% |
| Production sandbox / quotas | 28% | 75% |
| UI / preview workspace | 84% | 25% |
| Semantic reconstruction | 38% | 70% |

**تقدير عملي:** الـCore Local Studio ≈ **92%** مكتمل. المتبقي يتركز في hardening، corpus اختبار أوسع، حالات PDF شاذة، إعادة إصلاح أعمق على مستوى العنصر، والتوزيع المكتبي.

> هذه نسب هندسية تقديرية وليست قياسًا موحدًا للجودة.

---


## 0.6.0 — دفعة Productization Local

تمت إضافة Cache محلي deterministic، Batch analyze/convert حتى 12 ملفًا، إلغاء المهام، حدود صفحات/حجم، فحص magic bytes، inventory للوظائف، standalone viewer مستقل بأدوات بحث وتنقل وطباعة وتحرير دلالي وتصدير التعديلات، وحفظ قيم النماذج محليًا حسب SHA-256 للمصدر.

### Local-only contract

لا توجد خدمة سحابية أو API خارجي مطلوب لتشغيل المنتج. Chromium وTesseract وPyMuPDF كلها تعمل كأدوات محلية داخل الجهاز. أي مصدر URL يظهر داخل SVG يكون namespace XML وليس موردًا يتم تحميله أثناء التشغيل.

### Quality contract

كل نتيجة قابلة للتحقق عبر Render داخل Chromium ثم مقارنة بمرجع PDF. Cache لا يعيد استخدام نتيجة إلا عند تطابق SHA-256 للمصدر والخيارات وإصدار المحرك.

## 1. رؤية المنتج

"أعطِني PDF محليًا، وأعيده إليك كصفحة HTML مستقلة تبدو كأنها الصفحة الأصلية، مع أكبر قدر ممكن من قابلية الاستخدام على الويب."

### مبادئ غير قابلة للتفاوض

1. **Fidelity First:** PDF هو المرجع البصري.
2. **Local Only:** لا رفع للملفات إلى خدمة خارجية.
3. **No Silent Loss:** أي fallback يجب أن يسجل ويظهر في التقرير.
4. **Progressive Enhancement:** الشكل أولًا، ثم النص، ثم البنية، ثم التفاعل.
5. **Measured Quality:** لا نستخدم عبارة "مطابق" دون مقارنة Rendered Output.

---

## 2. استراتيجية التمثيل

الصفحة الناتجة مكونة من طبقات:

- **Visual Layer:** SVG كامل الصفحة أو fallback raster انتقائي.
- **Text Layer:** spans شفافة فوق النص للحفظ والنسخ/التحديد.
- **Interaction Layer:** روابط داخلية وخارجية.
- **Semantic Layer:** headings / paragraphs / tables مستقبلاً أو في الوضع الدلالي.
- **Metadata Layer:** بيانات المستند وManifest.

في وضع **Ultra** يستخدم المحرك path-based text عبر SVG عند الحاجة إلى ثبات أعلى في المتصفح. توثيق PyMuPDF يذكر صراحة أن `text_as_path=True` يقدم عرضًا أدق للنص في المتصفحات على حساب حجم أكبر، بينما `False` يعتمد أكثر على توفر الخطوط. citeturn526975search0

---

## 3. Pipeline التنفيذي

```text
PDF
 ↓
Parser + Analyzer
 ↓
Page Classification
 ↓
Native Text / OCR Fallback
 ↓
Assets + Fonts + Links + Tables
 ↓
Visual Renderer (SVG)
 ↓
Text / Interaction / Semantic Layers
 ↓
Standalone HTML
 ↓
Chromium Render
 ↓
Pixel / Geometry Comparison
 ↓
Quality Report + Diff Regions
```

PyMuPDF يوفر SVG لكل صفحة، كما يوفر rendering raster بـ`get_pixmap(dpi=...)` واستخراج الصور والخطوط والروابط والجداول، وهي قدرات يعتمد عليها المحرك الحالي. citeturn526975search0turn526975search3turn884535search7

---

## 4. Current Features — 1.1.0

### Input
- PDF حتى 100MB.
- تحقق parser فعلي من أن الملف PDF قابل للفتح.
- SHA-256 للملف.
- عدد الصفحات، الأبعاد، الدوران.

### Analysis
- text blocks / spans / chars / words.
- images / drawings / links.
- annotations / widgets.
- table detection.
- estimated complexity.
- scanned/hybrid heuristic.
- language heuristic.
- document metadata / TOC count / PDF version.

### Conversion
- Ultra / Balanced / Semantic.
- SVG inline.
- optional embedded fonts.
- selectable text layer.
- link layer.
- semantic hidden layer.
- OCR automatic fallback عبر PyMuPDF/Tesseract عند غياب النص أو قلته.
- reference PNG renders.
- standalone `index.html`.
- ZIP project.
- manifest JSON.

PyMuPDF يدمج دعم OCR عبر Tesseract، وتوجد إمكانية تمرير أكثر من لغة بصيغة `ara+eng`. توصي الوثائق بتحديد الحاجة إلى OCR أولًا لأنه أبطأ بكثير من استخراج النص الأصلي. citeturn884535search0turn884535search1

### Quality Assurance
- browser rendering عبر Chromium/Playwright.
- فحص صفحة منفردة.
- فحص جميع الصفحات.
- score.
- changed-pixel ratio.
- mean error.
- max error.
- diff PNG.
- regions based on deterministic tiles.

Playwright يدعم screenshot على مستوى locator، وتعطيل animations أثناء لقطة الاختبار، وهو مسار مناسب لاختبار ما يراه المتصفح فعليًا. citeturn650664search1

---

## 5. UI/UX

### الصفحة الرئيسية
- شاشة Dropzone كبيرة.
- رسالة privacy واضحة.
- دعم drag & drop.
- badges للميزات الأساسية.

### Workspace
- بطاقة الملف.
- إحصاءات المستند.
- إعدادات Fidelity/OCR.
- progress.
- تحذيرات.
- روابط التحميل.

### Preview
- Preview.
- Split compare.
- Overlay مع opacity.
- Diff.
- thumbnails لكل الصفحات.
- page navigation.
- zoom.
- quality score.

---

## 6. Quality Contract

لا يتم اعتبار الناتج "مطابقًا" لمجرد نجاح التوليد.

التحقق الرسمي يكون:

```text
PDF Reference Render
        vs
Browser HTML Render
        ↓
Fidelity Score
        +
Diff Image
        +
Diff Regions
```

Pillow `ImageChops.difference()` يحسب الفروق المطلقة بكسل مقابل بكسل، ويستخدمه المحرك الحالي كأساس للمقارنة. citeturn650664search2

---

## 7. OCR Strategy

### Automatic Decision

```text
Native text present and healthy?
   ├─ Yes → native extraction
   └─ No  → OCR
```

المسح الكامل بـOCR لا يستخدم إلا عند الحاجة؛ الوثائق الرسمية تذكر أن OCR أبطأ كثيرًا من الاستخراج العادي وأن اختيار `full=True` يضع النص المعترف به بخط GlyphLessFont. citeturn884535search0

### Future
- Surya / PaddleOCR كمسارات إضافية.
- reading order.
- table structure.
- confidence maps.
- language auto-detection.

---

## 8. Tables

النسخة الحالية تكتشف الجداول وتستخرج صفوفًا/أعمدة كطبقة بيانات. الإصدار الإنتاجي يجب أن يضيف:

- rowspan / colspan.
- border inference.
- fills.
- merged cells.
- header detection.
- exact column geometry.
- semantic `<table>` متطابق مع visual reference.
- table-specific diff.

PyMuPDF الحالي يضم `Page.find_tables()` ضمن API، وهذا أساس مناسب لهذه الطبقة. citeturn526975search4

---

## 9. Fonts

الأولوية:

1. Embedded font extraction.
2. `@font-face` داخل HTML.
3. منع الاعتماد على الإنترنت.
4. Ultra path fallback عند وجود خطر اختلاف metrics.
5. font fingerprint داخل التقرير.

هذه الطبقة هي واحدة من أهم أسباب اختلاف HTML عن PDF، ولذلك يجب أن تحتوي لاحقًا على calibration وglyph-level checks.

---

## 10. Auto Repair — المرحلة القادمة

المحرك المستهدف:

```text
Diff Region
 ↓
Attribution
 ↓
Candidate parameter
 ↓
Mutation
 ↓
Browser Render
 ↓
Score
 ↓
Keep best candidate
```

مرشحات الإصلاح:
- x/y offset.
- width/height.
- font metrics.
- letter spacing.
- line height.
- transform.
- fallback إلى glyph paths.
- selective rasterization.

لا يجب جعل Auto Repair يغير النص نفسه إلا بإذن صريح؛ الهدف هو إصلاح الهندسة والعرض، لا محتوى المستند.

---

## 11. Security

كل PDF input غير موثوق.

### Current
- حجم أقصى.
- parser validation.
- path traversal protection على output endpoint.
- حظر `javascript:`, `data:` و`file:` links.
- no cloud upload.

### Production
- sandboxed conversion worker.
- CPU/RAM quotas.
- timeout per page/job.
- isolated temporary directories.
- SVG sanitization.
- job garbage collection.
- rate limits حتى في localhost عند تشغيل server متعدد المستخدمين.

---

## 12. Performance

### Current
- vector SVG لتجنب rasterization غير الضرورية.
- direct page targeting أثناء validation.
- reference renders اختيارية.

### Production
- worker pool.
- parallel page conversion.
- cache keyed by SHA-256 + options.
- lazy thumbnails.
- page virtualization.
- memory budgets.
- resumable jobs.

---

## 13. Output Contracts

### Single file
`index.html`

- no remote CSS.
- no remote JS.
- embedded SVG.
- embedded fonts when available.
- embedded metadata.

### Project ZIP

```text
index.html
reference/page-N.svg
reference/page-N.png
reference/page-N.json
reference/manifest.json
manifest.json
```

---

## 14. Production Acceptance Tests

يجب أن يتضمن corpus حقيقيًا على الأقل:

- A4 / Letter / custom size.
- portrait / landscape.
- Arabic RTL.
- mixed RTL/LTR.
- embedded fonts.
- missing fonts.
- complex vector graphics.
- scanned pages.
- hybrid pages.
- nested tables.
- annotations.
- forms.
- external/internal links.
- 100+ page document.

Acceptance target:

- no silent visual loss.
- all pages have a measurable score.
- every fallback is reported.
- standalone HTML opens offline.
- regression suite prevents fidelity drift.

---

## 15. Roadmap to 1.0

### 0.3 — Visual QA + semantic foundation
- per-page score dashboard.
- better region attribution.
- overlay cursor synchronization.
- search/select across all pages.
- stronger font fingerprints.

### 0.4 — Document Intelligence
- OCR profile manager.
- Arabic-first OCR/layout.
- table reconstruction.
- figures and reading order.

### 0.5 — Interaction
- forms.
- annotations.
- bookmarks.
- internal navigation.
- Inspector.

### 0.6 — Auto Repair
- diff-to-element attribution.
- mutation engine.
- best-candidate search.
- selective rasterization fallback.

### 0.8 — Scale
- batch jobs.
- parallel workers.
- cache.
- resumability.
- memory budgets.

### 1.0 — Production local studio
- security sandbox.
- installers.
- cross-platform validation.
- license audit.
- regression corpus.
- accessibility.
- performance budgets.
- documentation.


## 1.1.0 Production Local Baseline

- Local-only operation is a hard requirement.
- Ultra mode uses a pixel-locked raster or SVG visual layer, with searchable/selectable overlays.
- Visual QA, quality gates, local cache, batch processing, forms, annotations, semantic inspection, and repair previews are part of the baseline.
- Repair candidates are never silently accepted: a candidate must measurably improve the visual score before it can be applied.

## 0.6.0 Major Upgrade

- Form controls are represented as transparent HTML overlays and become visible/focusable on interaction without moving the visual SVG source of truth.
- PDF annotations retain location, subtype, metadata, and safe external links in an interaction layer.
- Semantic extraction can be enabled independently from visual mode; Semantic mode exposes the semantic layer while Ultra keeps it non-invasive.
- Optional standalone CSP disables remote resource loading from generated HTML.
- Auto-validation is now a conversion-time quality gate when enabled and writes `quality.json`.
- A dedicated `/api/quality/{job_id}` endpoint exposes the latest visual QA result.
