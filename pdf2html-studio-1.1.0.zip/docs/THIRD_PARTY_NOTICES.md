# Third-party notices

This project relies on locally installed/open-source components. Before distributing a packaged product, review the exact license terms of the versions you bundle.

- FastAPI / Starlette / Pydantic — Python web/API stack.
- Uvicorn — local ASGI server.
- PyMuPDF / MuPDF — PDF parsing and rendering. Review the applicable AGPL/commercial licensing terms for your distribution model.
- Pillow — image processing.
- Playwright + Chromium — browser-based QA/rendering. Review Playwright/Chromium notices for your distribution model.
- Tesseract OCR and language data — optional local OCR dependency; verify the engine and language-pack licenses separately.

No external service is used as a runtime dependency by the application itself.
