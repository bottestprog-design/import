# Release Notes

## 1.1.0 — Windows Runtime Reliability & Local Diagnostics

- Automatic local `.venv` bootstrap from `run_local.py`.
- Pinned runtime installation from `requirements-lock.txt`.
- Windows `python` / `py -3` launcher fallbacks.
- Existing Chrome/Edge/Chromium detection before Playwright browser installation.
- Read-only `--doctor` / bootstrap `--check` path.
- Clear dependency/setup errors instead of raw import tracebacks.
- Active-job deletion safety and browser executable normalization.
- Local-only runtime remains unchanged: no cloud/API service is required after setup.

# Release Notes — 1.1.0

## 1.1.0 — Core Local Studio

هذه النسخة تمثل خط الأساس الإنتاجي المحلي للمشروع. كل التحويل والتحليل وOCR والـQA والـcache والإصلاحات المرشحة تعمل داخل الجهاز.

### Conversion
- Ultra visual mode with local raster backend by default.
- SVG visual backend remains available.
- Selectable/searchable text layer.
- Arabic + English OCR fallback.
- Table discovery with cell geometry, rowspan/colspan metadata and semantic table output.
- Links, annotations, and form overlays.
- Embedded fonts when recoverable.
- Standalone HTML with optional strict CSP.

### QA / Fidelity
- Chromium render validation.
- Pixel diff metrics and mismatch regions.
- Alignment probing.
- Region attribution to extracted elements.
- Auto-repair candidate generation with improvement gate.
- Explicit user approval before applying a repair.
- All-page validation with one Chromium session and parallel comparisons.

### Product / UX
- Cinematic RTL studio UI.
- Upload + drag/drop + multi-file batch flow.
- Local job history and reopen flow.
- Page thumbnails and page navigation.
- Preview / Split / Overlay / Diff / Inspector tabs.
- Search across the document.
- Theme toggle.
- Standalone viewer with print, TOC, editing, export, and local form persistence.

### Local-only / Security
- No remote service is required for conversion.
- Cache is keyed by source SHA-256 + options + engine version.
- Job cancellation, retry, crash recovery and cleanup.
- File/page/output limits.
- Path and filename validation.
- Dangerous PDF link schemes are blocked.
- Release archive excludes source PDF, runtime state, result state and repair candidates.
- `tools/audit_release.py` verifies local runtime coupling before release.
- `DELETE /api/cache` and local workspace statistics for explicit storage control.
- Portable `quality-report.html` stays free of `/api/...` runtime URLs.
- Applying a repair disables cache reuse for that edited job so retry cannot silently revert the approved edit.

### Verification
- Python/JS static checks: PASS.
- Release tests: 34 passed.
- Local release audit: PASS.
- Final regression uses real PDF → Chromium → pixel comparison; the score is a quality measurement for the fixture, not a guarantee for arbitrary PDFs.
