# Architecture — 1.1.0

```text
PDF
 │
 ├── PDF Signature / Safety Validation
 │
 └── Analyzer
      │
      ├── Native Text ───────────────┐
      ├── OCR Fallback ──────────────┤
      ├── Tables / Cell Geometry ────┤
      ├── Fonts / Images / Links ────┤
      └── Forms / Annotations ────────┤
                                     ▼
                             Fidelity Engine
                                     │
                ┌────────────────────┼───────────────────┐
                │                    │                   │
             Raster               SVG              Semantic
                │                    │                   │
                └────────────────────┼───────────────────┘
                                     │
                            Standalone HTML
                                     │
                                 Chromium
                                     │
                              Visual QA / Diff
                                     │
                         Attribution + Repair
                                     │
                               Final Deliverable
```

## Runtime

`backend/app/main.py` owns the local HTTP/API lifecycle, jobs, cache, cancellation, cleanup, history, retry and output delivery.

`backend/app/pdf_engine.py` owns PDF analysis, OCR decisions, assets, fonts, tables, links, semantic structure, standalone HTML assembly and manifests.

`backend/app/validator.py` renders the PDF and generated HTML in Chromium, then compares the resulting images.

`backend/app/repair.py` generates local repair candidates, attributes high-error regions to elements when possible, and only exposes a candidate when it demonstrably improves the selected page.

`backend/app/security.py` validates PDF signatures, page count, pathological page dimensions and safe filenames/job IDs.

`backend/app/cache.py` stores deterministic local output by source hash + canonical options + engine version.

## Visual fidelity contract

The PDF is the visual source of truth. Ultra defaults to a local raster layer because the final browser output is then compared against a PDF render at the same QA DPI. A transparent text layer, links, tables, forms and semantic content sit above that visual foundation.

## Local-only contract

The UI, API, OCR, PDF engine, Chromium QA, cache, history, repair candidates and deliverables do not require a remote API. External URLs can remain clickable inside the resulting document when present in the source PDF, but they are not runtime dependencies.

## Data boundaries

Source PDFs remain inside `workspace/uploads/<job-id>/`. Runtime state and rendered QA material stay in `workspace/outputs/<job-id>/`. The user ZIP intentionally excludes source PDFs, job state, result state, browser scratch output and repair candidates.
