# Test Report — 1.1.0

## Static checks

| Check | Result |
|---|---|
| Python unit tests | 34 passed |
| Python compilation | Passed |
| Frontend JavaScript syntax | Passed |
| Generated standalone runtime syntax | Passed |

## API integration

Verified end-to-end with a multi-page generated PDF:

`analyze → low-DPI thumbnails → queued conversion → persisted progress → completed result → standalone HTML → ZIP → all-page visual validation`

All API steps returned successful responses. The ZIP was checked for duplicate `index.html` entries and contains exactly one.

## Visual validation fixture

Latest richer 3-page raster fixture aligned to validation DPI:

- Average fidelity: **99.6003%**
- Worst page: **99.0990%**
- Pass rate at 99% threshold: **100%**
- Pages validated: **3 / 3**

The fidelity score is an engineering metric for regression tracking, not a guarantee for arbitrary PDF files.

## Auto-repair fixture

A one-page fixture was validated with the alignment probe and then passed through Auto-Repair.

- Before repair: **99.3949%**
- After repair: **99.5497%**
- Detected translation: **Δx = -1px, Δy = 0px**
- The original artifact was preserved.

## Environment notes

The current runtime contains Chromium, Tesseract and Arabic OCR language data. OCR-dependent behavior was exercised by the earlier hybrid-PDF fixture. Full browser UI navigation against `localhost` can be restricted by the execution sandbox, so UI endpoint rendering is tested through the actual Chromium renderer and API integration instead of relying on host navigation from the sandbox.
