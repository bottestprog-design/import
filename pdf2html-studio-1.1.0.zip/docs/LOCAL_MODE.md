# Local Mode Contract

PDF2HTML Studio is intentionally built as a **local application**.

## Required local components

- Python + FastAPI/uvicorn
- PyMuPDF
- Pillow
- Chromium/Playwright for visual QA
- Tesseract + requested language packs for OCR

No cloud account or external conversion API is required.

## Network behavior

- The main UI talks only to the local FastAPI process.
- Conversion, OCR, rendering, diffing, cache, history and repair happen locally.
- Standalone HTML is self-contained when exported with the default embedded-assets settings.
- External links inherited from a PDF are navigation targets, not conversion dependencies.
- The release audit scans runtime sources and generated ZIPs for accidental remote runtime coupling.

## Local data layout

```text
workspace/
├── uploads/<job-id>/   # source PDF, source metadata, thumbnails, analysis
├── outputs/<job-id>/   # HTML, QA, manifest, project ZIP
└── cache/              # deterministic reusable conversion results
```

Delete `workspace/` to remove local project state. Use the in-app cleanup action or `/api/cleanup` for age-based cleanup.
