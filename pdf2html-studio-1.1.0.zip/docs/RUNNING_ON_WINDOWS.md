# تشغيل PDF2HTML Studio على Windows

## المشكلة التي عالجها هذا الإصدار

تشغيل `run_local.py` مباشرة من Python النظام كان قد يصل إلى Uvicorn قبل التأكد من تثبيت PyMuPDF وبقية الاعتماديات. النتيجة كانت `ModuleNotFoundError: No module named 'pymupdf'`.

الإصدار 1.1.0 يجعل `run_local.py` launcher فعليًا:

1. ينشئ `.venv` داخل مجلد المشروع عند الحاجة.
2. يثبت نسخ Python المثبتة في `requirements-lock.txt`.
3. يكتشف Chrome/Edge/Chromium الموجود على الجهاز ويستخدمه للـQA إن كان متاحًا؛ ويثبت Chromium المحلي لـPlaywright فقط عند الحاجة.
4. يشغل التطبيق من `.venv` وليس من حزم Python النظام.

## التشغيل

```powershell
python run_local.py --open
```

أو:

```powershell
.\run_local.bat --open
```

## تشخيص البيئة

```powershell
python run_local.py --doctor
```

## بدون إعداد تلقائي

```powershell
python run_local.py --no-bootstrap
```

هذا الخيار مخصص لبيئة تم تجهيزها مسبقًا؛ وهو لا يحاول تثبيت أي حزمة.

## Playwright / Chromium

يمكن تخطي تنزيل Chromium في البداية باستخدام:

```powershell
$env:P2H_SKIP_BROWSER="1"
python run_local.py
```

سيظل التحويل الأساسي يعمل، لكن Visual QA سيكون غير متاح حتى تثبيت Chromium.

## ملاحظة Local-only

التحويل بعد اكتمال الإعداد لا يحتاج خدمة سحابية أو API خارجي. تنزيل Python wheels وChromium هو جزء من **الإعداد المحلي الأول فقط**.
