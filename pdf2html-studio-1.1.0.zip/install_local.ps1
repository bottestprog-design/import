$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    $launcher = Get-Command py -ErrorAction SilentlyContinue
    if ($launcher) { & py -3 .\tools\bootstrap_local.py; exit $LASTEXITCODE }
    throw "Python 3 is not available in PATH. Install Python 3.10+ and reopen PowerShell."
}
& python .\tools\bootstrap_local.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "PDF2HTML Studio local environment is ready." -ForegroundColor Green
