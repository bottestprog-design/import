from pathlib import Path
import json
import fitz

from backend.app.pdf_engine import analyze_pdf, convert_pdf, make_zip
from backend.app.cache import cache_key


def build_pdf(path: Path):
    doc = fitz.open()
    p1 = doc.new_page(width=595, height=842)
    p1.insert_text((50, 60), "Release Test / اختبار الإصدار", fontsize=18)
    p1.draw_rect(fitz.Rect(40, 90, 555, 210), color=(0.1, 0.3, 0.8), fill=(0.95, 0.97, 1))
    x0,x1=60,510; y0,y1=225,330; cols=3; rows=3
    for c in range(cols+1):
        x=x0+(x1-x0)*c/cols; p1.draw_line((x,y0),(x,y1),color=(0,0,0),width=0.8)
    for r in range(rows+1):
        y=y0+(y1-y0)*r/rows; p1.draw_line((x0,y),(x1,y),color=(0,0,0),width=0.8)
    for r in range(rows):
        for c in range(cols):
            x=x0+(x1-x0)*c/cols+10; y=y0+(y1-y0)*(r+1)/rows-10
            p1.insert_text((x,y), f"R{r+1} C{c+1}", fontsize=10)
    p2 = doc.new_page(width=595, height=842)
    p2.insert_textbox(fitz.Rect(60, 90, 520, 160), "Standalone search target", fontsize=16)
    doc.save(path)
    doc.close()


def test_release_capabilities(tmp_path):
    pdf = tmp_path / "fixture.pdf"
    build_pdf(pdf)
    info = analyze_pdf(pdf)
    assert info["page_count"] == 2
    assert info["pages"][0]["page_label"] == "1"
    assert isinstance(info["toc"], list)
    out = tmp_path / "out"
    converted = convert_pdf(pdf, out, {
        "visual_mode":"ultra", "selectable_text":True, "extract_tables":True,
        "standalone_toolbar":True, "local_form_persistence":True, "allow_semantic_editing":True,
        "build_search_index":True,
    })
    html = converted.html
    assert 'viewerToolbar' in html
    assert 'viewerSearch' in html
    assert 'sourceSha256' in html
    assert 'localFormPersistence' in html
    assert 'cells_detail' in json.dumps(converted.page_reports)
    assert (out / "reference" / "page-1.svg").exists()


def test_cache_key_is_deterministic():
    a = cache_key("abc", {"dpi": 180, "visual_mode": "ultra"})
    b = cache_key("abc", {"visual_mode": "ultra", "dpi": 180})
    c = cache_key("abd", {"dpi": 180, "visual_mode": "ultra"})
    assert a == b and a != c


def test_ultra_raster_and_local_audit(tmp_path):
    pdf = tmp_path / "pixel.pdf"
    build_pdf(pdf)
    out = tmp_path / "pixel-out"
    converted = convert_pdf(pdf, out, {
        "visual_mode": "ultra", "ultra_visual_backend": "raster",
        "dpi": 180, "validation_dpi": 144, "raster_dpi": 0,
        "create_reference_renders": True,
    })
    assert 'class="page-raster"' in converted.html
    assert converted.metadata["local_only_audit"]["local_only"] is True
    assert converted.metadata["local_only_audit"]["external_resource_count"] == 0
    assert converted.page_reports[0]["visual_backend"] == "raster"
    assert converted.page_reports[0]["raster_dpi"] == 144


def test_zip_has_single_html_entry(tmp_path):
    pdf = tmp_path / "zip.pdf"
    build_pdf(pdf)
    out = tmp_path / "zip-out"
    converted = convert_pdf(pdf, out, {"visual_mode": "ultra", "raster_dpi": 96, "validation_dpi": 96})
    html = out / "index.html"
    html.write_text(converted.html, encoding="utf-8")
    archive = out / "project.zip"
    make_zip(converted.html, out, archive)
    import zipfile
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        assert names.count("index.html") == 1


def test_local_self_test_endpoint():
    from backend.app.main import self_test
    result = self_test()
    assert result["local_only"] is True
    assert result["checks"]["pdf_parse"] is True
    assert result["checks"]["standalone_html"] is True
    assert result["checks"]["csp"] is True
    assert result["checks"]["local_only"] is True


def test_ocr_auto_default_is_enabled(tmp_path):
    # An image-only PDF should invoke OCR when no explicit ocr_mode is supplied.
    from PIL import Image, ImageDraw
    image = Image.new("RGB", (800, 400), "white")
    ImageDraw.Draw(image).text((40, 40), "OCR local test 123", fill="black")
    png = tmp_path / "scan.png"; image.save(png)
    pdf = tmp_path / "scan.pdf"; doc = fitz.open(); page = doc.new_page(width=595, height=842); page.insert_image(fitz.Rect(40, 60, 555, 320), filename=str(png)); doc.save(pdf); doc.close()
    out = tmp_path / "scan-out"
    converted = convert_pdf(pdf, out, {"visual_mode":"ultra", "raster_dpi":96, "validation_dpi":96})
    assert converted.metadata["ocr_pages"] >= 1
    assert any(r["ocr_used"] for r in converted.page_reports)


def test_toc_data_is_embedded(tmp_path):
    pdf = tmp_path / "toc.pdf"; doc = fitz.open(); doc.new_page(width=595, height=842); doc.new_page(width=595, height=842); doc.set_toc([[1,"First",1],[1,"Second",2]]); doc.save(pdf); doc.close()
    converted = convert_pdf(pdf, tmp_path / "toc-out", {"visual_mode":"ultra", "raster_dpi":96, "validation_dpi":96})
    assert 'viewerTocPanel' in converted.html and 'viewerToc' in converted.html


def test_arabic_presentation_form_repair():
    from backend.app.pdf_engine import _normalize_extracted_text
    assert _normalize_extracted_text("ﺩﻡﺡﻡ ﺩﻡﺡﺃ") == "محمد أحمد"


def test_ocr_arabic_direction_recovery(tmp_path):
    from backend.app.pdf_engine import convert_pdf
    from PIL import Image, ImageDraw, ImageFont
    font_path = "/usr/share/fonts/truetype/noto/NotoNaskhArabic-Regular.ttf"
    image = Image.new("RGB", (900, 260), "white")
    draw = ImageDraw.Draw(image)
    draw.text((600, 70), "أحمد محمد", fill="black", font=ImageFont.truetype(font_path, 46), direction="rtl")
    png = tmp_path / "arabic.png"; image.save(png)
    pdf = tmp_path / "arabic.pdf"; doc = fitz.open(); page = doc.new_page(width=595, height=842); page.insert_image(fitz.Rect(40, 60, 555, 240), filename=str(png)); doc.save(pdf); doc.close()
    converted = convert_pdf(pdf, tmp_path / "out", {"visual_mode":"ultra", "raster_dpi":96, "validation_dpi":96, "ocr_mode":"force", "ocr_languages":"ara"})
    texts = " ".join(x["text"] for x in converted.search_index)
    assert "أحمد" in texts or "محمد" in texts or any("أحمد" in v or "محمد" in v for x in converted.search_index for v in x.get("search_variants", []))


def test_auto_ocr_does_not_trigger_on_short_digital_page(tmp_path):
    pdf = tmp_path / "short-digital.pdf"
    doc = fitz.open(); page = doc.new_page(width=300, height=300); page.insert_text((30, 50), "A", fontsize=12); doc.save(pdf); doc.close()
    out = tmp_path / "out"
    converted = convert_pdf(pdf, out, {"visual_mode":"ultra", "raster_dpi":96, "validation_dpi":96})
    assert converted.metadata["ocr_pages"] == 0


def test_batch_export_and_retry_api(tmp_path):
    from fastapi.testclient import TestClient
    from backend.app.main import app
    import time, zipfile
    client = TestClient(app)
    def make_pdf(text):
        doc = fitz.open(); p = doc.new_page(width=300, height=300); p.insert_text((30, 50), text, fontsize=12); data = doc.tobytes(); doc.close(); return data
    response = client.post('/api/analyze-batch', files=[('files', ('one.pdf', make_pdf('one'), 'application/pdf')), ('files', ('two.pdf', make_pdf('two'), 'application/pdf'))])
    assert response.status_code == 200
    job_ids = [x['job_id'] for x in response.json()['results'] if x.get('job_id')]
    assert len(job_ids) == 2
    response = client.post('/api/convert-batch', json={'job_ids': job_ids, 'options': {'visual_mode':'ultra','ultra_visual_backend':'raster','dpi':96,'validation_dpi':96,'raster_dpi':0,'auto_validate':False,'use_cache':False}})
    assert response.status_code == 200
    for _ in range(100):
        states = [client.get(f'/api/job/{j}').json() for j in job_ids]
        if all(x.get('state') == 'completed' for x in states):
            break
        time.sleep(0.05)
    assert all(x.get('state') == 'completed' for x in states)
    response = client.post('/api/batch-export', json={'job_ids': job_ids})
    assert response.status_code == 200
    bundle = Path('workspace/outputs') / job_ids[0] / 'pdf2html-batch.zip'
    with zipfile.ZipFile(bundle) as z:
        names = z.namelist()
        assert 'batch-manifest.json' in names
        assert len([n for n in names if n.endswith('/pdf2html-project.zip')]) == 2
    for j in job_ids:
        response = client.post(f'/api/retry/{j}')
        assert response.status_code == 202
        client.delete(f'/api/job/{j}')


def test_elements_manifest_and_standalone_print_support(tmp_path):
    pdf = tmp_path / "elements.pdf"
    build_pdf(pdf)
    out = tmp_path / "out"
    converted = convert_pdf(pdf, out, {"visual_mode": "ultra", "raster_dpi": 96, "validation_dpi": 96, "include_semantics": True})
    assert (out / "reference" / "elements.json").is_file()
    html = converted.html
    assert 'window.addEventListener(\'beforeprint\'' in html
    assert "window.addEventListener('hashchange'" in html
    assert "show-all-pages-for-print" in html
    data = json.loads((out / "reference" / "elements.json").read_text(encoding="utf-8"))
    assert len(data) == 2
    assert data[0]["elements"]


def test_region_repair_preview_is_only_accepted_when_better(tmp_path):
    from backend.app.repair import build_patch_candidate
    pdf = tmp_path / "repair.pdf"
    build_pdf(pdf)
    out = tmp_path / "out"
    converted = convert_pdf(pdf, out, {"visual_mode": "ultra", "ultra_visual_backend": "raster", "raster_dpi": 96, "validation_dpi": 96})
    html = out / "index.html"
    html.write_text(converted.html, encoding="utf-8")
    html.write_text(html.read_text(encoding="utf-8").replace("#document{", "#document{transform:translateX(1px);"), encoding="utf-8")
    result = build_patch_candidate(pdf, html, 1, out, dpi=96, max_regions=8)
    assert result["ok"] is True
    # The repair pipeline may legitimately reject the candidate on an already-good page.
    assert "improved" in result and "before" in result and "after" in result


def test_local_history_persists_analysis_and_lists_filename(tmp_path):
    from fastapi.testclient import TestClient
    from backend.app.main import app
    client = TestClient(app)
    pdf = tmp_path / "history.pdf"
    build_pdf(pdf)
    r = client.post('/api/analyze', files={'file': ('history.pdf', pdf.read_bytes(), 'application/pdf')})
    assert r.status_code == 200
    job_id = r.json()['job_id']
    a = client.get(f'/api/job/{job_id}/analysis')
    assert a.status_code == 200 and a.json()['filename'] == 'history.pdf'
    jobs = client.get('/api/jobs?limit=10')
    assert jobs.status_code == 200 and jobs.json()['local_only'] is True
    assert any(x['job_id'] == job_id and x.get('filename') == 'history.pdf' for x in jobs.json()['jobs'])
    client.delete(f'/api/job/{job_id}')



def test_repair_overlay_targets_requested_page(tmp_path):
    from backend.app.repair import _make_candidate
    pdf = tmp_path / "multi.pdf"
    build_pdf(pdf)
    html = '<!doctype html><html><head></head><body><section class="page-shell" id="page-1"></section><section class="page-shell" id="page-2"></section></body></html>'
    out = tmp_path / "out"
    candidate = _make_candidate(html, 2, out, "target-page", ".x{}", '<div class="repair-layer" data-repair-index="2"></div>')
    rendered = candidate.read_text(encoding='utf-8')
    assert rendered.count('data-repair-index="2"') == 1
    assert rendered.index('id="page-1"') < rendered.index('id="page-2"')
    page2_start = rendered.index('id="page-2"')
    assert rendered.index('data-repair-index="2"') > page2_start


def test_pathological_page_guard(tmp_path):
    from backend.app.security import validate_pdf
    pdf = tmp_path / "huge.pdf"
    doc = fitz.open(); doc.new_page(width=20000, height=20000); doc.save(pdf); doc.close()
    try:
        validate_pdf(pdf, max_pages=10, max_page_megapixels=1)
    except ValueError as exc:
        assert 'كبيرة جدًا' in str(exc)
    else:
        raise AssertionError('expected oversized page guard')


def test_single_page_validation_reports_threshold(tmp_path):
    from fastapi.testclient import TestClient
    from backend.app.main import app
    client = TestClient(app)
    pdf = tmp_path / "validate.pdf"
    build_pdf(pdf)
    r = client.post('/api/analyze', files={'file': ('validate.pdf', pdf.read_bytes(), 'application/pdf')})
    assert r.status_code == 200
    job_id = r.json()['job_id']
    r = client.post(f'/api/convert/{job_id}', json={'visual_mode':'ultra','ultra_visual_backend':'raster','dpi':96,'validation_dpi':96,'raster_dpi':0,'auto_validate':False,'use_cache':False})
    assert r.status_code == 202
    import time
    for _ in range(80):
        state = client.get(f'/api/job/{job_id}').json()
        if state.get('state') == 'completed': break
        time.sleep(0.03)
    r = client.post(f'/api/validate/{job_id}', json={'page':1,'dpi':96,'alignment_probe':False,'threshold':98.0})
    assert r.status_code == 200
    data = r.json()
    assert data['threshold'] == 98.0
    assert data['passed'] is True
    client.delete(f'/api/job/{job_id}')


def test_offline_quality_report_is_generated(tmp_path):
    from backend.app.validator import write_quality_report
    out = tmp_path / 'out'; out.mkdir()
    q = {'overall_score':99.5,'worst_page_score':98.9,'pass_rate':50.0,'threshold':99.0,'pages':[{'page':1,'score':100.0,'metrics':{'changed_ratio':0,'mean_error':0,'edge_error':0},'regions':[]},{'page':2,'score':98.9,'metrics':{'changed_ratio':1,'mean_error':0.2,'edge_error':0.4},'regions':[{'x':0,'y':0,'width':10,'height':10}]}]}
    report = write_quality_report(out, q)
    text = report.read_text(encoding='utf-8')
    assert report.is_file() and 'Reference / Diff' in text and 'reference/page-1.png' in text


def test_convert_batch_returns_structured_results(tmp_path):
    from fastapi.testclient import TestClient
    from backend.app.main import app
    import time
    client = TestClient(app)
    def make_pdf(text):
        doc = fitz.open(); p = doc.new_page(width=300, height=300); p.insert_text((30,50), text, fontsize=12); data=doc.tobytes(); doc.close(); return data
    r = client.post('/api/analyze-batch', files=[('files',('a.pdf',make_pdf('a'),'application/pdf')),('files',('b.pdf',make_pdf('b'),'application/pdf'))])
    assert r.status_code == 200
    ids=[x['job_id'] for x in r.json()['results'] if x.get('job_id')]
    r=client.post('/api/convert-batch', json={'job_ids':ids,'options':{'visual_mode':'ultra','ultra_visual_backend':'raster','dpi':96,'validation_dpi':96,'raster_dpi':0,'auto_validate':False,'use_cache':False}})
    assert r.status_code == 200 and all(isinstance(x,dict) for x in r.json()['results'])
    for jid in ids:
        for _ in range(100):
            state=client.get(f'/api/job/{jid}').json()
            if state.get('state')=='completed': break
            time.sleep(.03)
        assert state.get('state')=='completed'
        client.delete(f'/api/job/{jid}')


def test_apply_repair_endpoint_reads_manifest_before_quality(tmp_path):
    from fastapi.testclient import TestClient
    from backend.app.main import app
    import time
    client=TestClient(app); pdf=tmp_path/'repair-api.pdf'; build_pdf(pdf)
    r=client.post('/api/analyze', files={'file':('repair-api.pdf',pdf.read_bytes(),'application/pdf')}); assert r.status_code==200
    jid=r.json()['job_id']; r=client.post(f'/api/convert/{jid}',json={'visual_mode':'ultra','ultra_visual_backend':'raster','dpi':96,'validation_dpi':96,'raster_dpi':0,'auto_validate':False,'use_cache':False}); assert r.status_code==202
    for _ in range(100):
        state=client.get(f'/api/job/{jid}').json()
        if state.get('state')=='completed': break
        time.sleep(.03)
    assert state.get('state')=='completed'
    # Seed a candidate manually to exercise the apply endpoint without running the
    # intentionally expensive multi-candidate repair search in a unit test.
    from backend.app.main import OUTPUTS
    outdir=OUTPUTS / jid
    candidate_dir=outdir/'repair'/'page-1'; candidate_dir.mkdir(parents=True, exist_ok=True)
    (candidate_dir/'candidate.html').write_text((outdir/'index.html').read_text(encoding='utf-8'), encoding='utf-8')
    applied=client.post(f'/api/repair/{jid}/1/apply')
    assert applied.status_code==200 and applied.json()['ok'] is True
    client.delete(f'/api/job/{jid}')


def test_table_semantic_accessibility_metadata(tmp_path):
    pdf=tmp_path/'table-a11y.pdf'; build_pdf(pdf)
    converted=convert_pdf(pdf,tmp_path/'out',{'visual_mode':'semantic','raster_dpi':96,'validation_dpi':96,'extract_tables':True,'include_semantics':True})
    assert 'role="table"' in converted.html


def test_final_html_has_no_external_runtime_resources(tmp_path):
    pdf=tmp_path/'offline.pdf'; build_pdf(pdf)
    converted=convert_pdf(pdf,tmp_path/'out',{'visual_mode':'ultra','raster_dpi':96,'validation_dpi':96})
    audit=converted.metadata['local_only_audit']
    assert audit['local_only'] is True and audit['external_resource_count']==0


def test_delete_active_job_is_deferred_safely(tmp_path):
    from fastapi.testclient import TestClient
    from backend.app.main import app, JOB_FUTURES, JOB_CANCEL, JOB_STATE, JOB_DELETE, UPLOADS, OUTPUTS, STATE_LOCK
    import threading

    class ActiveFuture:
        def done(self):
            return False
        def cancel(self):
            return False

    client = TestClient(app)
    pdf = tmp_path / "delete-active.pdf"; build_pdf(pdf)
    r = client.post('/api/analyze', files={'file': ('delete-active.pdf', pdf.read_bytes(), 'application/pdf')})
    assert r.status_code == 200
    jid = r.json()['job_id']
    (OUTPUTS / jid).mkdir(parents=True, exist_ok=True)
    (OUTPUTS / jid / 'state.json').write_text(json.dumps({'state':'running','progress':20}), encoding='utf-8')
    event = threading.Event()
    with STATE_LOCK:
        JOB_CANCEL[jid] = event
        JOB_FUTURES[jid] = ActiveFuture()
    r = client.delete(f'/api/job/{jid}')
    assert r.status_code == 202
    assert (UPLOADS / jid).exists() and (OUTPUTS / jid).exists()
    assert jid in JOB_DELETE
    # Test cleanup after the worker exits: the worker's finally block owns the final delete.
    shutil_paths = [UPLOADS / jid, OUTPUTS / jid]
    for pth in shutil_paths:
        import shutil
        shutil.rmtree(pth, ignore_errors=True)
    with STATE_LOCK:
        JOB_CANCEL.pop(jid, None); JOB_FUTURES.pop(jid, None); JOB_STATE.pop(jid, None); JOB_DELETE.discard(jid)
