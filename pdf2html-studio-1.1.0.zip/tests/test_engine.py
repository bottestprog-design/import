from pathlib import Path
import fitz

from backend.app.pdf_engine import analyze_pdf, convert_pdf


def make_sample(path: Path):
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((60, 80), "PDF2HTML Studio", fontsize=24, color=(0.1, 0.3, 0.8))
    page.draw_rect(fitz.Rect(50, 110, 545, 260), color=(0.1, 0.3, 0.8), fill=(0.95, 0.97, 1.0), width=2)
    page.insert_textbox(fitz.Rect(70, 135, 520, 225), "هذا اختبار عربي + English\n12345", fontsize=14, color=(0.1, 0.1, 0.1))
    page.insert_text((70, 300), "Searchable text block", fontsize=12)
    doc.save(path)
    doc.close()


def test_analyze_and_convert(tmp_path):
    pdf = tmp_path / "sample.pdf"
    make_sample(pdf)
    result = analyze_pdf(pdf)
    assert result["page_count"] == 1
    assert result["pages"][0]["fonts"] >= 1
    out = tmp_path / "job"
    converted = convert_pdf(pdf, out, {"visual_mode":"ultra","selectable_text":True,"include_links":True,"build_search_index":True})
    assert "page-1" in converted.html
    assert "PDF2HTML Studio" in converted.html
    assert "searchIndex" in converted.html
    assert (out / "reference" / "page-1.svg").exists()


def test_standalone_features(tmp_path):
    pdf = tmp_path / "sample.pdf"
    make_sample(pdf)
    out = tmp_path / "job"
    converted = convert_pdf(pdf, out, {"visual_mode":"semantic","selectable_text":True,"include_links":True,"extract_tables":True})
    assert "inspect-mode" in converted.html
    assert "data-bbox" in converted.html
    assert "semantic-node" in converted.html
