from pathlib import Path

from tools.bootstrap_local import ROOT, VENV_DIR, RUNTIME_REQUIREMENTS, venv_python, locked_versions
from backend.app.runtime import diagnostic_report
from backend.app.version import VERSION


def test_project_runtime_contract():
    assert VERSION == (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    assert "PyMuPDF" in dict(RUNTIME_REQUIREMENTS).values()
    assert venv_python().name == ("python.exe" if __import__("os").name == "nt" else "python")
    assert VENV_DIR == ROOT / ".venv"


def test_diagnostic_report_shape(tmp_path):
    report = diagnostic_report(tmp_path)
    assert report["local_only"] is True
    assert report["internet_required_at_runtime"] is False
    assert "python" in report and "packages" in report and "chromium" in report
    assert "workspace" in report and report["workspace"]["writable"] is True


def test_self_test_cli_does_not_start_server():
    import subprocess, sys
    result = subprocess.run([sys.executable, str(ROOT / "run_local.py"), "--self-test", "--no-bootstrap"], cwd=ROOT, capture_output=True, text=True, timeout=40)
    assert result.returncode == 0, result.stdout + "\n" + result.stderr
    assert '"ok": true' in result.stdout.lower()
    assert 'Uvicorn running' not in result.stderr


def test_bootstrap_check_does_not_create_venv(tmp_path):
    # The check path must be observational and never mutate the project environment.
    import subprocess, sys, os
    env = os.environ.copy()
    result = subprocess.run(
        [sys.executable, str(ROOT / "tools" / "bootstrap_local.py"), "--check"],
        cwd=tmp_path, capture_output=True, text=True, timeout=40, env=env,
    )
    assert result.returncode == 0, result.stdout + "\n" + result.stderr
    assert '"check_only": true' in result.stdout.lower()


def test_backend_app_init_suppresses_layout_suggestion():
    text = (ROOT / "backend" / "app" / "__init__.py").read_text(encoding="utf-8")
    assert "PYMUPDF_SUGGEST_LAYOUT_ANALYZER" in text


def test_launcher_files_have_python_fallbacks():
    bat = (ROOT / "run_local.bat").read_text(encoding="utf-8")
    ps1 = (ROOT / "run_local.ps1").read_text(encoding="utf-8")
    assert "py -3" in bat
    assert "-3" in ps1 and "$py.Source" in ps1
    assert "run_local.py" in bat and "run_local.py" in ps1


def test_windows_first_run_guide_exists():
    guide = (ROOT / "START_HERE_WINDOWS.txt").read_text(encoding="utf-8")
    assert "ModuleNotFoundError" in guide
    assert "run_local.bat" in guide


def test_lock_file_parses_pinned_versions():
    locked = locked_versions()
    assert locked.get("pymupdf") == "1.26.7"
    assert locked.get("fastapi") == "0.128.2"
    assert locked.get("playwright") == "1.57.0"


def test_bootstrap_reports_version_mismatches():
    from tools.bootstrap_local import _installed_mismatches
    current = _installed_mismatches(venv_python() if venv_python().exists() else Path(__import__("sys").executable))
    assert isinstance(current, dict)
