@echo off
setlocal
cd /d %~dp0
where python >nul 2>&1
if not errorlevel 1 (
  python --version >nul 2>&1
  if not errorlevel 1 (
    python tools\bootstrap_local.py
    set "RC=%ERRORLEVEL%"
    if "%RC%"=="0" goto done
  )
)
where py >nul 2>&1
if not errorlevel 1 (
  py -3 --version >nul 2>&1
  if not errorlevel 1 (
    py -3 tools\bootstrap_local.py
    set "RC=%ERRORLEVEL%"
    goto done
  )
)
echo Python 3 was not found or could not be started.
set "RC=1"
:done
if not "%RC%"=="0" pause
endlocal & exit /b %RC%
