$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$python = Get-Command python -ErrorAction SilentlyContinue
$used = $false
if ($python) {
  & $python.Source .\run_local.py @args
  $rc = $LASTEXITCODE
  $used = $true
  if ($rc -eq 0) { exit 0 }
}
$py = Get-Command py -ErrorAction SilentlyContinue
if ($py) {
  & $py.Source -3 .\run_local.py @args
  $rc = $LASTEXITCODE
  if ($rc -eq 0) { exit 0 }
  Write-Host "PDF2HTML Studio stopped with exit code $rc" -ForegroundColor Red
  exit $rc
}
if ($used) { exit $rc }
throw "Python was not found on PATH. Install Python 3.11+ or add it to PATH."
