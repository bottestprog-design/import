'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { WhatsAppWebAdapter } = require('../src/whatsapp-web-adapter');
const { WhatsAppCloudApiAdapter } = require('../src/whatsapp-cloud-api-adapter');

const sent = [];
const fakeEntry = { lastSent: null };
const fakeManager = {
  store: { safeSessionId: id => String(id || 'main') },
  assertChatAuthorized: (_id, chatId) => ({ allowed: true, target: { label: chatId } }),
  ensureReady: async () => ({ sendMessage: async (chatId, payload) => { sent.push({ chatId, payload }); return { id: { _serialized: 'outgoing-1' } }; } }),
  sendConfirmed: async (_sid, chatId, operation) => ({ result: await operation(), __chatBotAck: { status: 'created' }, chatId }),
  entry: () => fakeEntry,
  listRuntime: () => ({ status: 'ready', ready: true }),
  start: async () => ({ status: 'ready' }),
  stop: async () => ({ ok: true }),
  _sendTextViaWeb: async (_id, chatId, text) => ({ providerId: 'whatsapp-web', chatId, text }),
  _sendMediaViaWeb: async (_id, chatId, file) => ({ providerId: 'whatsapp-web', chatId, file }),
  _sendVoiceViaWeb: async (_id, chatId, file) => ({ providerId: 'whatsapp-web', chatId, file, kind: 'voice' }),
  _reactToMessageViaWeb: async (_id, messageId, emoji) => ({ messageId, emoji }),
};
class FakePoll { constructor(question, options, config) { this.question = question; this.options = options; this.config = config; } }
class FakeScheduledEvent { constructor(name, startTime, options) { this.name = name; this.startTime = startTime; this.options = options; } }

(async () => {
  const web = new WhatsAppWebAdapter({ manager: fakeManager, Poll: FakePoll, ScheduledEvent: FakeScheduledEvent, version: '1.34.7', env: {} });
  assert.equal(web.assertContract(), true);
  assert.equal((await web.sendText('main', '12345678901@c.us', 'hello')).text, 'hello');
  assert.equal((await web.sendMedia('main', '12345678901@c.us', '/tmp/photo.png')).file, '/tmp/photo.png');
  assert.equal((await web.sendVoice('main', '12345678901@c.us', '/tmp/v.ogg')).kind, 'voice');
  assert.equal((await web.sendReaction('main', 'message-id', '👍')).emoji, '👍');
  await assert.rejects(() => web.validateTarget('main', 'invalid'), error => error.code === 'CHANNEL_TARGET_INVALID');
  const normalized = web.normalizeInbound('main', { id: { _serialized: 'true_12345678901@c.us_ABC', remote: '12345678901@c.us' }, from: '12345678901@c.us', body: 'hello', type: 'chat', timestamp: 1700000000 });
  assert.equal(normalized.provider, 'whatsapp-web');
  assert.equal(normalized.kind, 'text');
  assert.equal(normalized.conversationId, '12345678901@c.us');
  assert.ok(normalized.eventId.includes('outgoing') === false);
  const caps = await web.getCapabilities('main', { chatType: 'group' });
  assert.equal(caps.capabilities.buttons.status, 'deprecated');
  assert.equal(caps.capabilities.lists.status, 'deprecated');
  assert.equal(caps.capabilities.sendPoll.status, 'experimental');
  assert.equal(caps.capabilities.sendPoll.testedAt, null);
  const directCaps = await web.getCapabilities('main', { chatType: 'individual' });
  assert.equal(directCaps.capabilities.sendPoll.status, 'unavailable');
  await assert.rejects(() => web.sendPoll('main', '12345678901-2@g.us', { question: 'Pick?', options: ['A', 'B'] }), error => error.code === 'CHANNEL_CAPABILITY_EXPERIMENTAL');
  const enabledWeb = new WhatsAppWebAdapter({ manager: fakeManager, Poll: FakePoll, ScheduledEvent: FakeScheduledEvent, env: { WHATSAPP_WEB_ENABLE_EXPERIMENTAL_POLLS: 'true', WHATSAPP_WEB_ENABLE_EXPERIMENTAL_EVENTS: 'true' } });
  const pollResult = await enabledWeb.sendPoll('main', '12345678901-2@g.us', { question: 'Pick?', options: ['A', 'B'], allowMultipleAnswers: true });
  assert.equal(pollResult.__chatBotAck.status, 'created');
  assert.equal(sent.at(-1).payload instanceof FakePoll, true);
  const eventResult = await enabledWeb.sendEvent('main', '12345678901@c.us', { name: 'Demo', startTime: new Date(Date.now() + 3600000).toISOString() });
  assert.equal(eventResult.__chatBotAck.status, 'created');
  assert.equal(sent.at(-1).payload instanceof FakeScheduledEvent, true);
  await assert.rejects(() => enabledWeb.sendEvent('main', '12345678901@c.us', { name: 'Past', startTime: '2000-01-01T00:00:00Z' }), error => error.code === 'CHANNEL_INPUT_INVALID');

  const disabledCloud = new WhatsAppCloudApiAdapter({ env: {}, fetchImpl: async () => { throw new Error('network must not be called'); } });
  assert.equal((await disabledCloud.getStatus()).configured, false);
  assert.equal((await disabledCloud.getCapabilities('x')).capabilities.sendText.status, 'unavailable');
  await assert.rejects(() => disabledCloud.sendText('x', '+96891234567', 'hello'), error => error.code === 'CHANNEL_NOT_CONFIGURED');

  const calls = [];
  const cloud = new WhatsAppCloudApiAdapter({ env: { WHATSAPP_CLOUD_API_VERSION: 'v99.0', WHATSAPP_CLOUD_PHONE_NUMBER_ID: '1234567890123', WHATSAPP_CLOUD_ACCESS_TOKEN: 'test-token' }, fetchImpl: async (url, options) => {
    calls.push({ url, options });
    return { ok: true, status: 200, json: async () => ({ messages: [{ id: 'wamid.test' }] }) };
  } });
  const cloudSend = await cloud.sendText('account', '+968 9123 4567', 'Hello Cloud');
  assert.equal(cloudSend.accepted, true);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, 'https://graph.facebook.com/v99.0/1234567890123/messages');
  assert.equal(calls[0].options.redirect, 'error', 'Cloud API must not forward a bearer token through an HTTP redirect');
  assert.equal(JSON.parse(calls[0].options.body).to, '96891234567');
  assert.equal((await cloud.getCapabilities('account')).capabilities.sendText.status, 'experimental', 'configuration alone is not a live certification');
  await assert.rejects(() => cloud.sendVoice('account', '+96891234567', '/tmp/not-used.ogg'), error => error.code === 'CHANNEL_CAPABILITY_UNAVAILABLE');
  await assert.rejects(() => cloud.sendText('account', '12345678901@g.us', 'no group'), error => error.code === 'CHANNEL_TARGET_INVALID');
  await assert.rejects(() => cloud.sendPoll(), error => error.code === 'CHANNEL_CAPABILITY_UNAVAILABLE');

  const mediaDir = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-cloud-media-'));
  try {
    const mediaPath = path.join(mediaDir, 'sample.png'); const pngHeader = Buffer.alloc(24); Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]).copy(pngHeader, 0); pngHeader.write('IHDR', 12, 'ascii'); pngHeader.writeUInt32BE(1, 16); pngHeader.writeUInt32BE(1, 20); fs.writeFileSync(mediaPath, pngHeader);
    const uploadCalls = [];
    const cloudMedia = new WhatsAppCloudApiAdapter({ env: { WHATSAPP_CLOUD_API_VERSION: 'v99.0', WHATSAPP_CLOUD_PHONE_NUMBER_ID: '1234567890123', WHATSAPP_CLOUD_ACCESS_TOKEN: 'test-token' }, fetchImpl: async (url, options) => {
      uploadCalls.push({ url, options });
      return { ok: true, status: 200, json: async () => url.endsWith('/media') ? { id: 'media-id' } : { messages: [{ id: 'wamid.media' }] } };
    } });
    const mediaResult = await cloudMedia.sendMedia('account', '+96891234567', mediaPath, { caption: 'image' });
    assert.equal(mediaResult.accepted, true);
    assert.equal(uploadCalls.length, 2);
    assert.equal(uploadCalls[0].options.body instanceof FormData, true);
    assert.equal(uploadCalls[0].options.redirect, 'error');
    const spoofPath = path.join(mediaDir, 'spoof.png'); fs.writeFileSync(spoofPath, Buffer.from('not-a-png'));
    await assert.rejects(() => cloudMedia.sendMedia('account', '+96891234567', spoofPath), error => error.code === 'CHANNEL_MEDIA_SIGNATURE_MISMATCH');
    assert.equal(uploadCalls.length, 2, 'a mismatched MIME signature must be rejected before network upload');
    const oversizedImage = path.join(mediaDir, 'large.png'); const largeHandle = fs.openSync(oversizedImage, 'w'); fs.ftruncateSync(largeHandle, 5 * 1024 * 1024 + 1); fs.closeSync(largeHandle);
    await assert.rejects(() => cloudMedia.sendMedia('account', '+96891234567', oversizedImage), error => error.code === 'CHANNEL_MEDIA_LIMIT');
    assert.equal(uploadCalls.length, 2, 'a file above the conservative per-type limit must be rejected before upload');
  } finally { fs.rmSync(mediaDir, { recursive: true, force: true }); }

  const noMessageIdCloud = new WhatsAppCloudApiAdapter({ env: { WHATSAPP_CLOUD_API_VERSION: 'v99.0', WHATSAPP_CLOUD_PHONE_NUMBER_ID: '1234567890123', WHATSAPP_CLOUD_ACCESS_TOKEN: 'test-token' }, fetchImpl: async () => ({ ok: true, status: 200, json: async () => ({ messages: [] }) }) });
  await assert.rejects(() => noMessageIdCloud.sendText('account', '+96891234567', 'uncertain'), error => error.code === 'SEND_UNCERTAIN' && error.retryable === false);

  console.log('whatsapp-provider-adapters: ok (Web adapter, capability gates, normalization, Cloud API mock, MIME signature guard, redirect protection and uncertain-send handling)');
})().catch(error => { console.error(error); process.exitCode = 1; });
