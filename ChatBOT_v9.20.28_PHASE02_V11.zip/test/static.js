"use strict";
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '..');
const js = ['server.js','scripts/ensure-browser.js','public/app.js','src/compat.js','src/whatsapp.js','src/delivery.js','src/interaction.js','src/trigger-engine.js','src/reply-engine.js','src/command-priority.js','src/anti-conflict.js','src/scheduler.js','src/automation-engine.js','src/store.js','src/phones.js','src/groups.js','src/media.js','src/backgrounds.js','src/serverlib.js','src/channel-provider.js','src/whatsapp-web-adapter.js','src/whatsapp-cloud-api-adapter.js','src/local-llm.js','src/smart-reply.js','src/audio-transcriber.js','src/env-loader.js','src/recipient-avatars.js','src/conversation-archive.js','src/conversation-targets.js','src/conversation-recall.js','src/rule-diagnostics.js','src/reply-quality.js','src/text-to-speech.js','src/voice-bootstrap.js','src/integration-hub.js','src/message-identifiers.js'];
let failed = 0;
for (const f of js) {
  try { new vm.Script(fs.readFileSync(path.join(root,f),'utf8'), {filename:f}); console.log('OK JS', f); }
  catch (e) { failed++; console.error('BAD JS', f, e.message); }
}
const app = fs.readFileSync(path.join(root,'public/app.js'),'utf8');
for (const token of ['function pageSend(', 'function pagePeople(', 'function pageGroups(', 'function pageInteraction(', 'function pageAutomation(', 'function bindAutomation(', 'function pageSession(', 'function pageAppearance(', 'function pageOperation(', 'function loadCountries(', 'function setupBackground(', 'function rangeControl(']) {
  if (!app.includes(token)) { failed++; console.error('MISSING', token); }
}
for (const banned of ['/api/session/select','/api/session/create','/api/session/update','/api/session/delete','/api/media/upload','/api/schedule/delete','/api/interaction/rules/delete']) {
  if (app.includes(banned)) { failed++; console.error('STALE_ENDPOINT', banned); }
}
if ((app.match(/function loadCountries\(/g)||[]).length !== 1) { failed++; console.error('DUPLICATE loadCountries'); }
const whatsapp = fs.readFileSync(path.join(root,'src/whatsapp.js'),'utf8');
if (!whatsapp.includes('function ackIsDelivered(ack) { return Number(ack) >= 2; }')) { failed++; console.error('ACK_SEMANTICS_NOT_SAFE'); }
const server = fs.readFileSync(path.join(root,'server.js'),'utf8');
for (const token of ['/api/conversations/targets','/api/conversations/messages','/api/conversations/search','/api/conversations/import','/api/architecture/health','/api/channels/providers','/api/channels/capabilities','/api/integrations/health','/api/voice/parse','/api/dictionary/lookup','/api/dictionary','/api/send','/api/recipient','/api/groups/connect','/api/groups/discover','/api/automation/task','/api/automation/rules','/api/automation/mutes','/api/automation/group-permissions','/api/interaction/rules','/api/interaction/counters','/api/interaction/counters/reset','/api/interaction/test','/api/settings/background','/api/countries','/api/transcription/upload','/api/transcription/transcribe-latest','/api/assistant/llm-status','/api/voice/runtime-status','/api/voice/test-four-languages']) if (!server.includes(token)) { failed++; console.error('MISSING SERVER ROUTE', token); }
const html = fs.readFileSync(path.join(root,'public/index.html'),'utf8');
for (const token of ['id="app"','id="bgCanvas"','id="bgImageLayer"']) if (!html.includes(token)) { failed++; console.error('MISSING HTML', token); }
const counters = fs.readFileSync(path.join(root,'server.js'),'utf8');
for (const token of ['interactionConflictMode','interactionSimilarityThreshold','commandPriority','counterTriggers','automationEngine.handleMessage','runDueRules']) if (!counters.includes(token)) { failed++; console.error('MISSING ADVANCED ENGINE FEATURE', token); }
for (const token of ['id="transcriptionFile"','id="captionWithMedia"','id="smartReplyEnabled"','id="ruleCommandPriority"','id="counterReplies"','id="cancelRuleEditBtn"','id="cancelCounterEditBtn"']) if (!app.includes(token)) { failed++; console.error('MISSING INTERACTION CONTROL', token); }
const triggerEngine = fs.readFileSync(path.join(root,'src/trigger-engine.js'),'utf8');
if (!triggerEngine.includes("case 'contains'")) { failed++; console.error('TRIGGER_ENGINE_CONTAINS_MISSING'); }
const pkg = JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8')); if (pkg.version !== '9.20.28') { failed++; console.error('BAD VERSION'); } if (pkg.dependencies?.puppeteer !== '24.38.0') { failed++; console.error('PUPPETEER PIN MISSING'); }
const launcher = fs.readFileSync(path.join(root,'run.py'),'utf8'); if (!launcher.includes("run([npm, 'run', 'test:strict']") || launcher.includes("run([npm, 'run', 'verify']")) { failed++; console.error('LAUNCHER_MUST_REQUIRE_STRICT_VERIFICATION'); }
const allVoiceSetup = path.join(root, 'SETUP-ALL-VOICE-WINDOWS.bat'); if (!fs.existsSync(allVoiceSetup) || !fs.readFileSync(allVoiceSetup, 'utf8').includes('SETUP-PYTHON-VOICE-WINDOWS.bat')) { failed++; console.error('ALL_VOICE_SETUP_MUST_RUN_UNIFIED_PYTHON_VOICE_INSTALLER'); }
const voiceInstaller = fs.readFileSync(path.join(root,'scripts','setup-python-voice.ps1'),'utf8'); const voiceRequirements = fs.readFileSync(path.join(root,'scripts','voice-requirements.txt'),'utf8'); for (const token of ['faster-whisper','edge-tts','imageio-ffmpeg','av>=11,<19','piper-tts>=1.8,<2']) if (!voiceRequirements.includes(token)) { failed++; console.error('VOICE_REQUIREMENTS_MISSING', token); } for (const token of ['TTS_REQUIRE_PROOFREAD','WHISPER_BACKEND','voice-smoke-test','TTS_BACKEND','-r $Requirements','PYTHONIOENCODING']) if (!voiceInstaller.includes(token)) { failed++; console.error('PYTHON_VOICE_INSTALLER_MISSING', token); }
const localAiSetupPath = path.join(root, 'scripts', 'setup-local-ai.ps1'); if (!fs.existsSync(localAiSetupPath)) { failed++; console.error('LOCAL_AI_SETUP_SCRIPT_MISSING'); } else { const localAiSetup = fs.readFileSync(localAiSetupPath, 'utf8'); for (const token of ['127.0.0.1:11434', 'Ollama.Ollama', 'qwen3.5:4b', 'ollama pull']) if (!localAiSetup.includes(token)) { failed++; console.error('LOCAL_AI_SETUP_MISSING', token); } }
const whisperSetup = fs.readFileSync(path.join(root,'scripts','setup-whisper.ps1'),'utf8'); if (!whisperSetup.includes('setup-python-voice.ps1')) { failed++; console.error('WHISPER_SETUP_MUST_USE_UNIFIED_PYTHON_VOICE_INSTALLER'); }
const ttsSetup = fs.readFileSync(path.join(root,'scripts','setup-tts.ps1'),'utf8'); if (!ttsSetup.includes('setup-python-voice.ps1') || ttsSetup.includes("TTS_REQUIRE_PROOFREAD' 'true")) { failed++; console.error('PIPER_SETUP_MUST_USE_UNIFIED_INSTALLER_WITHOUT_MANDATORY_PROOFREAD'); }
const voices = JSON.parse(fs.readFileSync(path.join(root,'scripts','voice-voices.json'),'utf8')); const worker = fs.readFileSync(path.join(root,'scripts','voice_worker.py'),'utf8'); for (const voice of voices) if (!worker.includes(voice)) { failed++; console.error('EDGE_VOICE_MISSING_IN_WORKER', voice); } if (voices.length < 30) { failed++; console.error('ARABIC_NEURAL_VOICE_LIST_TOO_SMALL'); }
const transcriber = fs.readFileSync(path.join(root,'src','audio-transcriber.js'),'utf8'); if (!transcriber.includes("path.join(root, 'models', 'ggml-small.bin')") || !transcriber.includes('configuredModelCandidate && fs.existsSync(configuredModelCandidate)') || !transcriber.includes('knownBareExecutables') || !transcriber.includes('!fs.existsSync(binary)')) { failed++; console.error('WHISPER_MODEL_OR_BINARY_STALE_PATH_FALLBACK_MISSING'); }
process.exitCode = failed ? 1 : 0;
