'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const server = read('server.js');
const wa = read('src/whatsapp.js');
const contacts = read('src/whatsapp-contacts.js');
const bridge = read('src/local-command-bridge.js');
const app = read('public/app.js');
const css = read('public/styles.css');
const pkg = JSON.parse(read('package.json'));

const checks = [
  ['v9.20.21 contact and history release preserves the prior voice/PyAV foundation, archive recovery, rules and media/send behavior', pkg.version === '9.20.28'],
  ['legacy one-line command bridge is injected', server.includes("require('./src/local-command-bridge')") && server.includes('new LocalCommandBridge')],
  ['self-chat pending confirmations go to bridge first', /bridgePending \|\| !ownerFlow/.test(server) && server.indexOf('localCommandBridge.handle') < server.indexOf('ownerAssistant.handleSelfChatMessage')],
  ['text/media direct sends go through WhatsApp adapter', /async sendText\(id, chatId, text/.test(wa) && /async sendMedia\(id, chatId, file/.test(wa)],
  ['saved recipient aliases and old JID formats resolve safely', /target\.whatsappJid/.test(wa) && /client\.getNumberId\(digits\)/.test(wa)],
  ['contact loader uses real live WhatsApp contact API', /client\.getContacts\(\)/.test(wa)],
  ['contact rows preserve current WhatsApp profile name separately', /pushname, notifyName/.test(wa) && /whatsappPushname/.test(contacts)],
  ['profile picture URL allowlist and manual redirect validation exist', /isAllowedProfileUrl/.test(contacts) && /redirect: 'manual'/.test(contacts) && /new URL\(location, current\)/.test(contacts)],
  ['profile picture downloads are bounded, cached and de-duplicated', /5 \* 1024 \* 1024/.test(contacts) && /profilePictureInFlight/.test(contacts)],
  ['profile picture route only returns local cached files', /app\.get\('\/api\/whatsapp\/contact-picture'/.test(server) && /ensureContactPicture/.test(server)],
  ['contact sync route exposes explicit options', /app\.post\('\/api\/whatsapp\/contacts\/sync'/.test(server) && /updatePictures/.test(server) && /updateNames/.test(server)],
  ['contact list shows profile photo, address-book name and profile name', /wa-contact-photo/.test(app) && /اسم ملف الحساب/.test(app) && /اسم دفتر العناوين/.test(app)],
  ['person cards show saved WhatsApp avatar and both name fields', /person-profile-photo/.test(app) && /اسم ملف WhatsApp/.test(app) && /اسم دفتر العناوين/.test(app)],
  ['send API reports real numeric sent/failure counts', /const sentCount = Array\.isArray\(result\.sent\) \? result\.sent\.length/.test(server) && /failedDetails/.test(server)],
  ['bridge restores send, schedule, interaction and contact sync commands', /stageAddRecipient/.test(bridge) && /stageSend/.test(bridge) && /stageSchedule/.test(bridge) && /stageInteractionRule/.test(bridge) && /stageSyncWhatsappContacts/.test(bridge)],
  ['contact sync from chat requires confirmation', /type: 'sync-contacts'/.test(bridge) && /تأكيد المزامنه/.test(bridge)],
  ['normal group messages are not stored as new groups', (() => { const start = server.indexOf('async function groupCommand'); const gate = server.indexOf('if (!command.test(body) && !invite && !gidMention) return;', start); const fetchInfo = server.indexOf('getGroupInfoFromMessage', start); return start >= 0 && gate > start && fetchInfo > gate; })()],
  ['compact editors and WhatsApp photo rows remain connected', css.includes('.section-editor>summary') && css.includes('.wa-contact-photo') && app.includes('loadWhatsAppContacts()')],
  ['local audio transcription and configurable smart fallback exist', app.includes('id="transcribeUploadBtn"') && app.includes('id="interactionFallbackEnabled"') && server.includes('/api/transcription/transcribe-latest') && server.includes('/api/assistant/llm-status')],
];
let failed = false;
for (const [label, ok] of checks) { console.log(`${ok ? 'OK' : 'FAIL'} ${label}`); if (!ok) failed = true; }
if (failed) process.exit(1);
console.log(`reference-restoration: ok (${checks.length} static checks)`);
