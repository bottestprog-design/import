'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const app = fs.readFileSync(path.join(root, 'public', 'app.js'), 'utf8');
const styles = fs.readFileSync(path.join(root, 'public', 'styles.css'), 'utf8');
const contacts = fs.readFileSync(path.join(root, 'src', 'whatsapp-contacts.js'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const lock = JSON.parse(fs.readFileSync(path.join(root, 'package-lock.json'), 'utf8'));
assert.equal(pkg.version, '9.20.28', 'phase-six follow-up must publish a versioned integrated package');
assert.equal(lock.version, pkg.version);
assert.equal(lock.packages[''].version, pkg.version);

const routeStart = server.indexOf("app.post('/api/whatsapp/contacts/refresh-pictures'");
assert.ok(routeStart >= 0, 'a dedicated profile-photo refresh route must exist');
const routeEnd = server.indexOf("app.get('/api/diagnostics'", routeStart);
assert.ok(routeEnd > routeStart, 'the photo refresh route must be bounded before diagnostics');
const route = server.slice(routeStart, routeEnd);
assert.match(route, /jids\.length > 100/, 'refresh must cap a batch at 100 contacts');
assert.match(route, /\^\\d\{5,25\}@c\\\.us\$/, 'only confirmed phone JIDs are accepted');
assert.match(route, /store\.loadSession\(id\)/, 'refresh must load the active local session');
assert.match(route, /notSaved\.length/, 'unregistered contacts must not be refreshed as saved recipients');
assert.match(route, /whatsapp\.listContacts\(id, \{ limit: 2000, includeProfilePictures: true, onlyJids: jids \}\)/, 'refresh must resolve the selected IDs against the live WhatsApp contact list');
assert.match(route, /whatsappContacts\.refreshContactPictures/, 'refresh must use the shared safe avatar pipeline');
assert.match(route, /Cache-Control', 'no-store'/, 'refresh results must not be cached');

assert.match(app, /id=\\?"syncWhatsAppProfilesBtn\\?"[^>]*>تحديث صور المحدد/, 'the UI must describe the actual selected-photo operation');
assert.match(app, /\/api\/whatsapp\/contacts\/refresh-pictures/, 'the UI must call the dedicated refresh endpoint');
assert.match(app, /حدد جهات محفوظة لتحديث صورها/, 'the UI must explain that only saved contacts can be refreshed');
assert.match(app, /photoButton\.disabled = state\.whatsappContactsSelected\.size === 0/, 'the refresh action must be disabled without a selection');
assert.match(styles, /\.whatsapp-contact-row \.wa-contact-avatar-wrap\{width:44px;height:44px;min-width:44px;flex:0 0 44px/, 'contact-list avatars must have a consistent desktop size');
assert.match(styles, /@media\(max-width:600px\)\{\.whatsapp-contact-row \.wa-contact-avatar-wrap\{width:38px;height:38px/, 'contact-list avatars must scale consistently on mobile');
assert.match(styles, /\.whatsapp-contact-row \.wa-contact-photo\{width:100%;height:100%;inset:0;object-fit:cover/, 'photos must fill the fixed circular avatar without distortion');
assert.match(contacts, /profilePictureInFlight/, 'photo lookups must continue to deduplicate concurrent requests');
assert.match(contacts, /ensureContactPicture\(\{ store, whatsapp, sessionId: id, jid, refresh: true \}\)/, 'an explicit selected-photo refresh must bypass a valid cached avatar and ask WhatsApp for a current URL');
assert.match(contacts, /isAllowedProfileUrl/, 'the existing trusted-host validation must remain in place');
assert.ok(fs.existsSync(path.join(root, 'CHANGELOG_V9_20_17_PHASE6_AR.md')), 'the follow-up changelog must ship with the project');
assert.ok(fs.readFileSync(path.join(root, 'RELEASES_AR.md'), 'utf8').startsWith('## v9.20.28'), 'the release history must match the package version');

console.log('phase6-contact-refresh-ui: ok (saved-recipient guard, live JID verification, 100-item cap, safe shared photo pipeline, selected-only UI action, and consistent responsive avatar sizing)');
