'use strict';
const assert = require('node:assert/strict');
const {
  ChannelProvider, ProviderRegistry, CapabilityRegistry, REQUIRED_PROVIDER_METHODS,
  normalizeCapability, channelError,
} = require('../src/channel-provider');

class FakeProvider extends ChannelProvider {
  constructor(id) { super({ id, name: id, version: 'test-1' }); }
  async connect() { return { ok: true }; }
  async disconnect() { return { ok: true }; }
  async getStatus() { return { state: 'ready' }; }
  async sendText() { return { ok: true }; }
  async sendMedia() { return { ok: true }; }
  async sendVoice() { return { ok: true }; }
  async sendPoll() { return { ok: true }; }
  async sendEvent() { return { ok: true }; }
  async sendReaction() { return { ok: true }; }
  async getCapabilities() { return {}; }
  normalizeInbound(value) { return value; }
  validateTarget(value) { return { ok: true, value }; }
}

const provider = new FakeProvider('fake-channel');
assert.equal(provider.assertContract(), true);
assert.equal(REQUIRED_PROVIDER_METHODS.length, 12);
const registry = new ProviderRegistry();
assert.equal(registry.register(provider), provider);
assert.equal(registry.get('fake-channel'), provider);
assert.equal(registry.list().length, 1);
assert.throws(() => registry.register(provider), error => error.code === 'CHANNEL_PROVIDER_DUPLICATE');
const baseProvider = new ChannelProvider({ id: 'base' });
assert.equal(typeof baseProvider.sendText, 'function', 'base contract exposes required operation');

const capabilities = new CapabilityRegistry();
const normalized = normalizeCapability('sendText', { status: 'available', reason: 'unit' }, { providerId: 'fake', accountId: 'a', chatType: 'individual' });
assert.equal(normalized.status, 'available');
assert.equal(normalized.testedAt, null);
assert.equal(normalized.accountId, 'a');
assert.equal(normalizeCapability('bad', { status: 'made-up' }).status, 'unavailable');
capabilities.replace('fake', 'a', 'individual', { sendText: { status: 'available' }, buttons: { status: 'deprecated' } });
assert.equal(capabilities.get('fake', 'a', 'individual').length, 2);
assert.equal(capabilities.get('fake', 'a', 'group').length, 0);
capabilities.clear('fake', 'a', 'individual');
assert.equal(capabilities.get('fake', 'a', 'individual').length, 0);

const error = channelError('CHANNEL_TEST', 'test', { providerId: 'fake', capability: 'sendText' });
assert.equal(error.code, 'CHANNEL_TEST');
assert.equal(error.providerId, 'fake');
assert.equal(error.capability, 'sendText');
console.log('channel-provider-contract: ok');
