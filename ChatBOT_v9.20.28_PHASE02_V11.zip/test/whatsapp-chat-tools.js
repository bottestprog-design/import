'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const media = require('../src/media');
for (const ext of ['.csv','.json','.xml','.html','.md','.rar','.7z','.yaml','.py','.sql','.epub','.apk','.bin','.mov','.mkv','.heic','.heif']) {
  assert.ok(media.MEDIA_EXT.has(ext), `media library should accept ${ext} extracted from WhatsApp chats`);
}
const whatsapp = read('src/whatsapp.js');
const server = read('server.js');
const owner = read('src/owner-assistant.js');
const app = read('public/app.js');
const css = read('public/styles.css');
assert.match(whatsapp, /async searchChats\(/, 'chat search must be available to the owner assistant');
assert.match(whatsapp, /async downloadMediaFromChat\(/, 'bounded media download must be implemented');
assert.match(whatsapp, /const fromMe = isFromMeMessage\(msg\)/, 'self-message detection uses the shared helper for old, nested and serialized WhatsApp message fields');
assert.match(server, /withVoiceTranscript\(/, 'incoming and self-chat audio should enter the local transcript pipeline');
assert.match(server, /interaction\.onMessage\(id, processed\)/, 'reply engine must receive the transcript proxy instead of an empty voice note');
assert.match(owner, /download-chat-media/, 'owner assistant should require confirmation before chat media export');
assert.match(owner, /تاكيد التنزيل/, 'media download confirmation is recognized');
assert.match(app, /id="syncWhatsAppProfilesBtn"/, 'contact-photo resync is available from the contacts list');
assert.match(app, /id="voiceAutoTranscribeEnabled"/, 'auto-transcription can be configured in the UI');
assert.match(css, /wa-contact-avatar-wrap\.person-avatar\{width:36px;height:36px/, 'WhatsApp avatar dimensions match the round 36px reference presentation');
const { OwnerAssistant } = require('../src/owner-assistant');
const os = require('node:os');
const Module = require('node:module');
// Use the real WhatsAppManager class without needing a live browser/dependency install.
// Third-party runtime modules are stubbed only during require; the downloader itself is real.
const originalModuleLoad = Module._load;
const priorNodeEnv = process.env.NODE_ENV;
process.env.NODE_ENV = 'test';
Module._load = function (request, parent, isMain) {
  if (request === 'whatsapp-web.js') return { Client: class Client {}, LocalAuth: class LocalAuth {}, MessageMedia: { fromFilePath: filePath => ({ filePath }) } };
  if (request === 'qrcode') return { toDataURL: async value => `data:image/png;base64,${Buffer.from(String(value)).toString('base64')}` };
  if (request === 'puppeteer') return { executablePath: () => '' };
  return originalModuleLoad.call(this, request, parent, isMain);
};
let WhatsAppManager;
try { ({ WhatsAppManager } = require('../src/whatsapp')); } finally { Module._load = originalModuleLoad; if (priorNodeEnv === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = priorNodeEnv; }
const { ProviderRegistry, CapabilityRegistry } = require('../src/channel-provider');
const capabilityManager = Object.create(WhatsAppManager.prototype);
capabilityManager.store = { safeSessionId: value => String(value || 'main') };
capabilityManager.sessionProviders = new Map();
capabilityManager.providerRegistry = new ProviderRegistry();
capabilityManager.capabilityRegistry = new CapabilityRegistry();
capabilityManager.providerRegistry.register({
  id: 'test-provider', name: 'Test Provider', version: 'test-1', assertContract: () => true,
  getCapabilities: async (_sid, context) => ({ providerId: 'test-provider', accountId: 'acct-1', chatType: context.chatType, capabilities: { sendText: { status: 'experimental', reason: 'unit-test', testedAt: null } } }),
});
const clone = x => JSON.parse(JSON.stringify(x));
let persisted = { id: 'main', name: 'اختبار', recipients: [{ id: 'ahmed', name: 'أحمد', digits: '96891111111', e164: '+96891111111', international: '+968 9111 1111', enabled: true }], groups: [], settings: {}, interaction: { rules: [] }, automation: { tasks: [], rules: [] }, ownerAssistant: { flow: null, recent: [] } };
const replies = [];
let downloadCalls = 0;
const chatList = [{ id: '96891111111@c.us', name: 'أحمد', isGroup: false }];
const store = { safeSessionId: x => String(x || 'main'), loadSession: () => clone(persisted), saveSession: x => { persisted = clone(x); return clone(persisted); } };
const fakeWhatsApp = {
  selfChatId: () => '96890000000@c.us',
  sendText: async (_id, _chat, body) => { replies.push(String(body)); return { __chatBotAck: { status: 'confirmed' } }; },
  searchChats: async (_id, options = {}) => !options.query || 'أحمد'.includes(String(options.query)) ? chatList : [],
  downloadMediaFromChat: async (_id, chatId) => { downloadCalls++; assert.equal(chatId, chatList[0].id); return { chatId, chatName: 'أحمد', scanned: 4, mediaFound: 1, downloaded: [{ filename: 'photo.jpg', bytes: 1024 }], skipped: [], failed: [], totalBytes: 1024, mediaDirectory: 'data/sessions/main/media' }; },
  listRuntime: () => ({ ready: true }),
};
(async () => {
  const capabilityResult = await capabilityManager.getCapabilities('main', { providerId: 'test-provider', chatType: 'group' });
  assert.equal(capabilityResult.capabilities.sendText.providerId, 'test-provider');
  assert.equal(capabilityResult.capabilities.sendText.accountId, 'acct-1');
  assert.equal(capabilityManager.capabilityRegistry.get('test-provider', 'acct-1', 'group')[0].testedAt, null, 'capability registry must preserve the untested state');

  const owner = new OwnerAssistant({ store, whatsapp: fakeWhatsApp, phones: { parse: () => ({}) }, log: () => {} });
  await owner.handleSelfChatMessage('main', { body: 'استخرج الملفات من محادثة أحمد' });
  assert.equal(downloadCalls, 0, 'downloading from a chat must never start before the owner confirms');
  assert.match(replies.at(-1), /تأكيد التنزيل/);
  await owner.handleSelfChatMessage('main', { body: 'تأكيد التنزيل' });
  assert.equal(downloadCalls, 1, 'a confirmed download command should reach the media downloader exactly once');
  assert.match(replies.at(-1), /photo\.jpg/);
  assert.match(replies.at(-1), /data\/sessions\/main\/media/);

  // Exercise the real bounded downloader implementation with mocked WhatsApp messages.
  // Messages are supplied oldest-to-newest; the downloader should prefer the latest files,
  // enforce hard limits, and ignore corrupted base64 instead of writing junk to disk.
  const tempMedia = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-chat-media-download-'));
  try {
    const makeMessage = (timestamp, filename, data = Buffer.from(`file-${timestamp}`), type = 'document', mimetype = 'text/plain') => ({
      hasMedia: true, type, timestamp, id: { _serialized: `message-${timestamp}` },
      _data: { mimetype, filename },
      downloadMedia: async () => ({ data: Buffer.isBuffer(data) ? data.toString('base64') : data, mimetype, filename }),
    });
    let messages = [makeMessage(1, 'old.txt'), makeMessage(2, 'middle.txt'), makeMessage(3, 'new.txt'), makeMessage(4, 'broken.txt', '###invalid###')];
    let observedFetchLimit = null;
    const adapter = Object.create(WhatsAppManager.prototype);
    adapter.store = { safeSessionId: value => String(value || 'main'), loadSession: () => clone(persisted), getPaths: () => ({ media: tempMedia }) };
    adapter.clients = new Map();
    adapter.getChatSafe = async () => ({ id: { _serialized: chatList[0].id }, name: 'أحمد', fetchMessages: async options => { observedFetchLimit = options.limit; return messages; } });
    const downloaded = await adapter.downloadMediaFromChat('main', chatList[0].id, { messageLimit: 900, maxFiles: 3, perFileBytes: 64, totalBytes: 128 });
    assert.equal(observedFetchLimit, 500, 'the requested message scan limit must be clamped to the hard maximum');
    assert.equal(downloaded.limits.messageLimit, 500);
    assert.equal(downloaded.limits.maxFiles, 3);
    assert.deepEqual(downloaded.downloaded.map(item => item.timestamp), [3, 2], 'newest valid attachments should be handled first');
    assert.equal(downloaded.skipped.length, 1, 'malformed base64 should be reported instead of written');
    assert.equal(downloaded.downloaded.length, 2);
    assert.ok(downloaded.downloaded.every(item => fs.existsSync(path.join(tempMedia, item.filename))));
    assert.equal(downloaded.totalBytes, Buffer.byteLength('file-3') + Buffer.byteLength('file-2'));
    const fileCountBeforePausedCheck = fs.readdirSync(tempMedia).length;
    persisted.recipients[0].paused = true;
    await assert.rejects(() => adapter.downloadMediaFromChat('main', chatList[0].id), error => error.code === 'RECIPIENT_DISABLED');
    persisted.recipients[0].paused = false;
    assert.equal(fs.readdirSync(tempMedia).length, fileCountBeforePausedCheck, 'paused contact media must not be written to disk');
    messages = [makeMessage(5, 'voice.ogg', Buffer.from('voice-data'), 'ptt', 'audio/ogg'), makeMessage(6, 'document.txt')];
    const audioOnly = await adapter.downloadMediaFromChat('main', chatList[0].id, { messageLimit: 50, maxFiles: 10, mediaType: 'audio' });
    assert.equal(audioOnly.mediaType, 'audio');
    assert.equal(audioOnly.mediaFoundTotal, 2, 'response reports all available media separately from the selected type');
    assert.equal(audioOnly.mediaFound, 1, 'audio filter should select only audio/voice notes');
    assert.equal(audioOnly.downloaded.length, 1);
    assert.match(audioOnly.downloaded[0].filename, /voice.*\.ogg$/);
    assert.equal(audioOnly.downloaded[0].type, 'ptt');
    await assert.rejects(() => adapter.downloadMediaFromChat('main', chatList[0].id, { mediaType: 'secrets' }), /نوع المرفق المطلوب/);
  } finally { fs.rmSync(tempMedia, { recursive: true, force: true }); }

  // Regression: WhatsApp voice notes and stickers have no ordinary body text.
  // They must still match outgoing programmatic media intents in self-chat.
  const outboundAdapter = Object.create(WhatsAppManager.prototype);
  outboundAdapter.store = { safeSessionId: value => String(value || 'main') };
  outboundAdapter.outgoingIntents = new Map();
  outboundAdapter.programmaticMessages = new Map();
  const selfChat = '96890000000@c.us';
  const stickerIntent = outboundAdapter.trackOutgoingIntent('main', selfChat, '', 'إرسال الملصق');
  assert.equal(outboundAdapter.outgoingIntents.get(stickerIntent.key)[0].expectsMedia, true, 'sticker sends must be tracked as media intents');
  assert.equal(outboundAdapter.consumeProgrammaticOutgoing('main', { fromMe: true, to: selfChat, type: 'sticker', hasMedia: true, body: '', id: { remote: selfChat, _serialized: 'true_96890000000@c.us_STICKER' } }), true, 'self-chat sticker output must not be mistaken for a user command');
  const voiceIntent = outboundAdapter.trackOutgoingIntent('main', selfChat, '', 'إرسال رسالة صوتية');
  assert.equal(outboundAdapter.consumeProgrammaticOutgoing('main', { fromMe: true, to: selfChat, type: 'ptt', hasMedia: true, body: '', id: { remote: selfChat, _serialized: 'true_96890000000@c.us_VOICE' } }), true, 'self-chat voice output must not be mistaken for a user command');
  assert.equal(outboundAdapter.outgoingIntents.has(voiceIntent.key), false, 'matched media intent should be consumed exactly once');
  assert.match(whatsapp, /timeoutMs, 'إرسال رسالة صوتية', ''\)/, 'voice-send tracking must not use a fake text body');

  // Exercise sticker conversion settings using the pinned whatsapp-web.js API without a live account.
  const tempStickerDir = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-sticker-send-'));
  try {
    const stickerFile = path.join(tempStickerDir, 'hello.webp'); fs.writeFileSync(stickerFile, Buffer.alloc(2048, 7));
    let stickerOptions = null; const stickerState = {};
    const stickerAdapter = Object.create(WhatsAppManager.prototype);
    stickerAdapter.store = { safeSessionId: value => String(value || 'main') };
    stickerAdapter.ensureReady = async () => ({ sendMessage: async (_target, _mediaObject, options) => { stickerOptions = options; return { id: { _serialized: 'sticker-message-1' } }; } });
    stickerAdapter.sendConfirmed = async (_sid, _chatId, operation) => operation();
    stickerAdapter.entry = () => stickerState;
    await stickerAdapter.sendMedia('main', chatList[0].id, stickerFile, { asSticker: true, caption: 'ignored for stickers' });
    assert.equal(stickerOptions.sendMediaAsSticker, true);
    assert.equal(stickerOptions.sendMediaAsDocument, false);
    assert.equal(stickerOptions.stickerName, 'hello');
    assert.equal(stickerOptions.caption, undefined, 'sticker mode never attaches a caption');
    assert.equal(stickerState.lastSent.kind, 'sticker');
    await assert.rejects(() => stickerAdapter.sendMedia('main', chatList[0].id, path.join(tempStickerDir, 'missing.pdf'), { asSticker: true }), /غير موجود/);
  } finally { fs.rmSync(tempStickerDir, { recursive: true, force: true }); }

  // Exercise the real sendVoice adapter path without a live WhatsApp account.
  const tempVoiceDir = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-voice-send-'));
  try {
    const voiceFile = path.join(tempVoiceDir, 'reply.ogg');
    const invalidVoiceFile = path.join(tempVoiceDir, 'reply.wav');
    const { createOggOpusFixture } = require('./ogg-opus-fixture'); const validOgg = createOggOpusFixture(1024); fs.writeFileSync(voiceFile, validOgg);
    fs.writeFileSync(invalidVoiceFile, Buffer.alloc(1024, 7));
    let voiceSend = null;
    const state = {};
    const voiceAdapter = Object.create(WhatsAppManager.prototype);
    voiceAdapter.store = { safeSessionId: value => String(value || 'main') };
    voiceAdapter.ensureReady = async () => ({ sendMessage: async (target, mediaObject, options) => { voiceSend = { target, mediaObject, options }; return { id: { _serialized: 'voice-message-1' } }; } });
    voiceAdapter.sendConfirmed = async (_sid, _chatId, operation) => operation();
    voiceAdapter.entry = () => state;
    const voiceResult = await voiceAdapter.sendVoice('main', chatList[0].id, voiceFile);
    assert.equal(voiceSend.target, chatList[0].id);
    assert.equal(voiceSend.mediaObject.filePath, voiceFile);
    assert.deepEqual(voiceSend.options, { sendAudioAsVoice: true, sendMediaAsDocument: false });
    assert.equal(voiceResult.id._serialized, 'voice-message-1');
    assert.equal(state.lastSent.kind, 'voice');
    await assert.rejects(() => voiceAdapter.sendVoice('main', chatList[0].id, invalidVoiceFile), /OGG\/Opus/);
  } finally { fs.rmSync(tempVoiceDir, { recursive: true, force: true }); }

  console.log('whatsapp-chat-tools: ok (media safety caps/types, confirmed self-chat media download, actual voice-send adapter path, robust own-message routing, voice transcript routing, contact sync and reference avatar dimensions)');
})().catch(error => { console.error(error); process.exitCode = 1; });
