'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');
const { ChannelProvider, channelError, normalizeCapability } = require('./channel-provider');

const CLOUD_MEDIA_MAX_BYTES = 32 * 1024 * 1024;
const CLOUD_MEDIA_MAX_BYTES_BY_TYPE = Object.freeze({
  image: 5 * 1024 * 1024, video: 16 * 1024 * 1024, audio: 16 * 1024 * 1024,
  // Deliberately conservative local cap; Cloud API supports larger document limits by type.
  document: 32 * 1024 * 1024,
});
const MEDIA_TYPES = Object.freeze({
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
  '.mp4': 'video/mp4', '.3gp': 'video/3gpp',
  '.aac': 'audio/aac', '.amr': 'audio/amr', '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.ogg': 'audio/ogg',
  '.pdf': 'application/pdf', '.txt': 'text/plain', '.doc': 'application/msword',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.xls': 'application/vnd.ms-excel', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
});

function cleanError(value) {
  return String(value || 'Cloud API request failed.')
    .replace(/Bearer\s+[^\s,;]+/gi, 'Bearer [hidden]')
    .replace(/(access_token|token|authorization|password|secret)\s*[:=]\s*[^\s,;]+/gi, '$1=[hidden]')
    .replace(/https?:\/\/[^\s]+/gi, '[service URL]')
    .slice(0, 360);
}
function matchesMimeSignature(buffer, mimeType) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 4) return false;
  const starts = (...bytes) => bytes.every((value, index) => buffer[index] === value);
  switch (mimeType) {
    case 'image/png': return buffer.length >= 24 && starts(0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a) && buffer.toString('ascii', 12, 16) === 'IHDR' && buffer.readUInt32BE(16) > 0 && buffer.readUInt32BE(20) > 0;
    case 'image/jpeg': return buffer.length >= 4 && starts(0xff, 0xd8, 0xff) && buffer[buffer.length - 2] === 0xff && buffer[buffer.length - 1] === 0xd9;
    case 'video/mp4': case 'video/3gpp': case 'audio/mp4': return buffer.length >= 12 && buffer.toString('ascii', 4, 8) === 'ftyp';
    case 'audio/ogg': return buffer.length >= 27 && buffer.toString('ascii', 0, 4) === 'OggS';
    case 'audio/amr': return buffer.toString('ascii', 0, 6) === '#!AMR\n' || buffer.toString('ascii', 0, 9) === '#!AMR-WB\n';
    case 'audio/mpeg': return buffer.toString('ascii', 0, 3) === 'ID3' || (buffer[0] === 0xff && (buffer[1] & 0xe0) === 0xe0);
    case 'audio/aac': return buffer[0] === 0xff && (buffer[1] & 0xf6) === 0xf0;
    case 'application/pdf': return buffer.toString('ascii', 0, 5) === '%PDF-';
    case 'application/msword': return starts(0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1);
    case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
    case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': return starts(0x50, 0x4b, 0x03, 0x04);
    case 'text/plain':
      if (buffer.includes(0)) return false;
      try { new TextDecoder('utf-8', { fatal: true }).decode(buffer); return true; } catch { return false; }
    default: return false;
  }
}

function getContent(message, type) {
  const block = message?.[type] || {};
  return {
    text: type === 'text' ? String(block.body || '') : '',
    caption: String(block.caption || ''),
    mimeType: String(block.mime_type || ''),
    mediaId: String(block.id || ''),
    filename: String(block.filename || ''),
  };
}

class WhatsAppCloudApiAdapter extends ChannelProvider {
  constructor({ env = process.env, fetchImpl = globalThis.fetch, timeoutMs = 30000 } = {}) {
    super({ id: 'whatsapp-cloud-api', name: 'WhatsApp Business Platform Cloud API', version: 'Graph API version from configuration' });
    this.env = env;
    this.fetchImpl = fetchImpl;
    this.timeoutMs = Math.min(120000, Math.max(3000, Number(timeoutMs) || 30000));
  }
  config() {
    const apiVersion = String(this.env.WHATSAPP_CLOUD_API_VERSION || '').trim();
    const phoneNumberId = String(this.env.WHATSAPP_CLOUD_PHONE_NUMBER_ID || '').trim();
    const accessToken = String(this.env.WHATSAPP_CLOUD_ACCESS_TOKEN || '').trim();
    const accountId = String(this.env.WHATSAPP_CLOUD_ACCOUNT_ID || phoneNumberId || '').trim();
    const validVersion = /^v\d+\.\d+$/.test(apiVersion);
    const validPhoneId = /^\d{5,30}$/.test(phoneNumberId);
    return {
      configured: Boolean(validVersion && validPhoneId && accessToken),
      validVersion, validPhoneId, apiVersion, phoneNumberId, accountId,
      accessToken,
    };
  }
  async connect() {
    const c = this.config();
    if (!c.configured) throw channelError('CHANNEL_NOT_CONFIGURED', 'Cloud API غير مفعّلة. يلزم تحديد إصدار Graph API ورقم Phone Number ID ورمز الوصول صراحةً.', { providerId: this.id });
    return { ok: true, state: 'stateless', providerId: this.id, accountId: c.accountId, apiVersion: c.apiVersion };
  }
  async disconnect() { return { ok: true, state: 'stateless' }; }
  async getStatus() {
    const c = this.config();
    return { providerId: this.id, configured: c.configured, state: c.configured ? 'configured-not-probed' : 'not-configured', accountId: c.accountId || null, apiVersion: c.apiVersion || null };
  }
  async validateTarget(_accountId, target) {
    const raw = String(typeof target === 'string' ? target : (target?.phone || target?.e164 || target?.to || '')).trim();
    const digits = raw.replace(/^\+/, '').replace(/[\s().-]/g, '');
    if (!/^\d{8,15}$/.test(digits) || digits.startsWith('0')) throw channelError('CHANNEL_TARGET_INVALID', 'Cloud API يحتاج رقم مستلم بصيغة دولية من 8 إلى 15 رقمًا دون علامة +.', { providerId: this.id });
    return { ok: true, providerId: this.id, to: digits, chatType: 'individual' };
  }
  async request(pathPart, { method = 'GET', body, headers = {}, formData = null } = {}) {
    const c = this.config();
    if (!c.configured) throw channelError('CHANNEL_NOT_CONFIGURED', 'Cloud API غير مهيّأة.', { providerId: this.id });
    if (typeof this.fetchImpl !== 'function') throw channelError('CHANNEL_FETCH_UNAVAILABLE', 'بيئة Node الحالية لا توفر fetch.', { providerId: this.id });
    const url = `https://graph.facebook.com/${c.apiVersion}/${pathPart.replace(/^\/+/, '')}`;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs); timer.unref?.();
    let response;
    try {
      const requestHeaders = { Authorization: `Bearer ${c.accessToken}`, ...headers };
      if (!formData) requestHeaders['Content-Type'] = 'application/json';
      response = await this.fetchImpl(url, { method, headers: requestHeaders, body: formData || (body === undefined ? undefined : JSON.stringify(body)), signal: controller.signal, redirect: 'error' });
    } catch (error) {
      const message = cleanError(error?.name === 'AbortError' ? 'Request timed out.' : error?.message || error);
      throw channelError('SEND_UNCERTAIN', `Cloud API: ${message} نتيجة الإرسال غير مؤكدة؛ لا تعِد المحاولة تلقائيًا.`, { providerId: this.id, retryable: false });
    } finally { clearTimeout(timer); }
    let data = {};
    try { data = await response.json(); } catch { data = {}; }
    if (!response.ok) {
      const apiError = data?.error || {};
      const detail = cleanError(apiError.message || response.statusText || 'Cloud API rejected the request.');
      throw channelError('CLOUD_API_REJECTED', `Cloud API رفض العملية (HTTP ${response.status}${apiError.code ? ` / ${apiError.code}` : ''}): ${detail}`, { providerId: this.id, statusCode: response.status, retryable: response.status >= 500 || response.status === 429 });
    }
    return data;
  }
  async sendText(accountId, target, text) {
    const c = this.config();
    if (!c.configured) throw channelError('CHANNEL_NOT_CONFIGURED', 'Cloud API غير مهيّأة.', { providerId: this.id });
    const verified = await this.validateTarget(accountId, target);
    const body = String(text || '').trim();
    if (!body || body.length > 4096) throw channelError('CHANNEL_INPUT_INVALID', 'النص مطلوب ويجب ألا يتجاوز 4096 حرفًا.', { providerId: this.id, capability: 'sendText' });
    const result = await this.request(`${c.phoneNumberId}/messages`, { method: 'POST', body: {
      messaging_product: 'whatsapp', recipient_type: 'individual', to: verified.to,
      type: 'text', text: { preview_url: false, body },
    } });
    const messageId = String(result?.messages?.[0]?.id || '');
    if (!messageId) throw channelError('SEND_UNCERTAIN', 'أعاد Cloud API استجابة ناجحة دون معرف رسالة؛ لا يمكن الجزم بحالة التسليم ولا ينبغي تكرار الإرسال تلقائيًا.', { providerId: this.id, retryable: false });
    return { providerId: this.id, accepted: true, messageId, rawStatus: result?.messages?.[0]?.message_status || null, __chatBotAck: { status: 'accepted', mode: 'cloud_api', id: messageId } };
  }
  async sendMedia(accountId, target, file, options = {}) {
    const c = this.config();
    const verified = await this.validateTarget(accountId, target);
    const filePath = path.resolve(String(file || ''));
    let stat;
    try { stat = await fs.stat(filePath); } catch { throw channelError('MEDIA_FILE_MISSING', 'الملف المحدد غير موجود.', { providerId: this.id }); }
    if (!stat.isFile() || stat.size <= 0 || stat.size > CLOUD_MEDIA_MAX_BYTES) throw channelError('CHANNEL_MEDIA_LIMIT', 'ملف Cloud API يجب أن يكون ملفًا عاديًا وألا يتجاوز الحد المحلي الأقصى 32 ميجابايت.', { providerId: this.id, capability: 'sendMedia' });
    const extension = path.extname(filePath).toLowerCase();
    const mimeType = MEDIA_TYPES[extension];
    if (!mimeType) throw channelError('CHANNEL_MEDIA_TYPE_UNSUPPORTED', 'نوع الملف غير مدرج في أنواع الوسائط المفعّلة لهذا الموصل.', { providerId: this.id, capability: 'sendMedia' });
    const mediaType = mimeType.startsWith('image/') ? 'image' : mimeType.startsWith('video/') ? 'video' : mimeType.startsWith('audio/') ? 'audio' : 'document';
    const mediaLimit = CLOUD_MEDIA_MAX_BYTES_BY_TYPE[mediaType] || CLOUD_MEDIA_MAX_BYTES;
    if (stat.size > mediaLimit) throw channelError('CHANNEL_MEDIA_LIMIT', `حجم ${mediaType} يتجاوز الحد المحلي المحافظ لهذا الموصل (${Math.floor(mediaLimit / 1024 / 1024)} MB).`, { providerId: this.id, capability: 'sendMedia' });
    let buffer;
    const handle = await fs.open(filePath, 'r');
    try {
      const snapshot = await handle.stat();
      if (!snapshot.isFile() || snapshot.size !== stat.size || snapshot.size <= 0 || snapshot.size > CLOUD_MEDIA_MAX_BYTES) throw channelError('CHANNEL_MEDIA_CHANGED', 'تغير الملف أثناء فحصه؛ أوقف الرفع وأعد اختيار الملف.', { providerId: this.id, capability: 'sendMedia' });
      buffer = Buffer.alloc(snapshot.size);
      const read = await handle.read(buffer, 0, snapshot.size, 0);
      const after = await handle.stat();
      if (read.bytesRead !== snapshot.size || after.size !== snapshot.size || after.mtimeMs !== snapshot.mtimeMs) throw channelError('CHANNEL_MEDIA_CHANGED', 'تغير الملف أثناء قراءته؛ أوقف الرفع وأعد اختيار الملف.', { providerId: this.id, capability: 'sendMedia' });
    } finally { await handle.close(); }
    if (!matchesMimeSignature(buffer, mimeType)) throw channelError('CHANNEL_MEDIA_SIGNATURE_MISMATCH', 'محتوى الملف لا يطابق نوعه المعلن؛ أوقف الرفع بدل الاعتماد على الامتداد وحده.', { providerId: this.id, capability: 'sendMedia' });
    const form = new FormData();
    form.append('messaging_product', 'whatsapp');
    form.append('type', mimeType);
    form.append('file', new Blob([buffer], { type: mimeType }), path.basename(filePath));
    const uploaded = await this.request(`${c.phoneNumberId}/media`, { method: 'POST', formData: form });
    const mediaId = String(uploaded?.id || '');
    if (!mediaId) throw channelError('CLOUD_API_MEDIA_UPLOAD_INVALID', 'لم يُرجع Cloud API معرّفًا للوسائط بعد الرفع.', { providerId: this.id });
    const media = { id: mediaId };
    if (['image', 'video', 'document'].includes(mediaType) && String(options.caption || '').trim()) media.caption = String(options.caption).trim().slice(0, 1024);
    if (mediaType === 'document') media.filename = path.basename(filePath);
    const result = await this.request(`${c.phoneNumberId}/messages`, { method: 'POST', body: {
      messaging_product: 'whatsapp', recipient_type: 'individual', to: verified.to, type: mediaType, [mediaType]: media,
    } });
    const messageId = String(result?.messages?.[0]?.id || '');
    if (!messageId) throw channelError('SEND_UNCERTAIN', 'أعاد Cloud API استجابة إرسال الوسائط دون معرف رسالة؛ الرفع تم لكن نتيجة الإرسال غير مؤكدة، ولا ينبغي تكراره تلقائيًا.', { providerId: this.id, retryable: false });
    return { providerId: this.id, accepted: true, messageId, mediaId, __chatBotAck: { status: 'accepted', mode: 'cloud_api', id: messageId } };
  }
  async sendVoice() { throw channelError('CHANNEL_CAPABILITY_UNAVAILABLE', 'إرسال Voice Note غير مفعّل في موصل Cloud API الحالي؛ دعم audio العام لا يثبت مسار الرسالة الصوتية.', { providerId: this.id, capability: 'voiceNote' }); }
  async sendPoll() { throw channelError('CHANNEL_CAPABILITY_UNAVAILABLE', 'الاستطلاعات ليست جزءًا من واجهة Cloud API المستخدمة في هذا الموصل.', { providerId: this.id, capability: 'sendPoll' }); }
  async sendEvent() { throw channelError('CHANNEL_CAPABILITY_UNAVAILABLE', 'الأحداث المجدولة ليست مدرجة كقدرة في هذا الموصل.', { providerId: this.id, capability: 'sendEvent' }); }
  async sendReaction() { throw channelError('CHANNEL_CAPABILITY_UNAVAILABLE', 'إرسال Reaction غير مفعّل في هذا الموصل حاليًا.', { providerId: this.id, capability: 'sendReaction' }); }
  normalizeInbound(message, accountId = '') {
    const type = String(message?.type || 'unknown');
    const content = getContent(message, type);
    const id = String(message?.id || '');
    const timestamp = Number(message?.timestamp || 0);
    const phoneNumberId = String(accountId || this.config().accountId || '');
    return {
      eventId: id ? `${this.id}:${phoneNumberId}:${id}` : null,
      provider: this.id, providerVersion: this.config().apiVersion || 'unconfigured', accountId: phoneNumberId,
      conversationId: String(message?.from || ''), messageId: id, providerMessageId: id || null,
      senderId: String(message?.from || ''), senderType: 'contact', fromMe: false,
      quotedMessageId: String(message?.context?.id || '') || null,
      kind: ({ text: 'text', image: 'image', video: 'video', audio: 'audio', document: 'document', sticker: 'sticker', location: 'location', contacts: 'contact', interactive: 'interactive', order: 'order' })[type] || 'unknown',
      text: content.text, caption: content.caption, mimeType: content.mimeType,
      sizeBytes: null, mediaAssetId: content.mediaId || null,
      sentAt: timestamp > 0 ? new Date(timestamp * 1000).toISOString() : null,
      receivedAt: new Date().toISOString(), providerTimestamp: timestamp || null,
      ackState: null, rawProviderType: type, correlationId: id ? `${this.id}:${phoneNumberId}:${id}` : null,
    };
  }
  normalizeWebhook(payload) {
    const normalized = [];
    for (const entry of (Array.isArray(payload?.entry) ? payload.entry : [])) {
      for (const change of (Array.isArray(entry?.changes) ? entry.changes : [])) {
        const value = change?.value || {};
        const accountId = String(value?.metadata?.phone_number_id || entry?.id || this.config().accountId || '');
        for (const message of (Array.isArray(value?.messages) ? value.messages : [])) normalized.push(this.normalizeInbound(message, accountId));
      }
    }
    return normalized;
  }
  async getCapabilities(_accountId, context = {}) {
    const c = this.config();
    const meta = { providerId: this.id, providerVersion: c.apiVersion || this.version, accountId: c.accountId || 'unconfigured', chatType: context.chatType || 'individual' };
    const caps = {
      sendText: { status: c.configured ? 'experimental' : 'unavailable', reason: c.configured ? 'مسار الإرسال مهيأ برمجيًا لكنه غير معتمد باختبار حي؛ القبول الفعلي يخضع لنافذة خدمة العميل والقوالب وسياسات الحساب لدى Meta.' : 'أدخل Graph API version وPhone Number ID وAccess Token لتجهيز الموصل؛ لا يتم الاتصال تلقائيًا.' },
      sendMedia: { status: c.configured ? 'experimental' : 'unavailable', reason: 'رفع ملف محلي حتى 32 ميجابايت للأنواع المدرجة؛ يجب التحقق من حدود الملف والقناة والحساب قبل كل إرسال.', constraints: { maxBytes: CLOUD_MEDIA_MAX_BYTES, maxBytesByType: CLOUD_MEDIA_MAX_BYTES_BY_TYPE, types: ['image', 'video', 'audio', 'document'] } },
      sendPoll: { status: 'unavailable', reason: 'غير مدعوم في تنفيذ Cloud API الحالي.' },
      sendEvent: { status: 'unavailable', reason: 'غير مدعوم في تنفيذ Cloud API الحالي.' },
      sendReaction: { status: 'unavailable', reason: 'غير مفعّل في هذا الإصدار من الموصل.' },
      voiceNote: { status: 'unavailable', reason: 'لم يُفعّل إرسال Voice Note منفصلًا؛ لا يُستنتج من دعم audio العام.' },
      flows: { status: 'account-restricted', reason: 'يتطلب Flow منشورًا وإعدادات حساب وWebhook مؤهلة؛ لم يتم تهيئته من هذا الموصل.' },
      catalog: { status: 'account-restricted', reason: 'يتطلب إعداد Commerce/Catalog وأهلية الحساب؛ لم يتم تهيئته من هذا الموصل.' },
      buttons: { status: 'unavailable', reason: 'قدرة Cloud API الرسمية معروفة، لكن مسار إرسالها التفاعلي غير موصول في هذا الإصدار من adapter.' },
      lists: { status: 'unavailable', reason: 'قدرة Cloud API الرسمية معروفة، لكن مسار إرسالها التفاعلي غير موصول في هذا الإصدار من adapter.' },
    };
    return { providerId: this.id, providerName: this.name, providerVersion: meta.providerVersion, accountId: meta.accountId, chatType: meta.chatType, observedAt: new Date().toISOString(), sessionStatus: c.configured ? 'configured-not-probed' : 'not-configured', sessionReady: c.configured, unofficial: false, capabilities: Object.fromEntries(Object.entries(caps).map(([id, value]) => [id, normalizeCapability(id, { ...value, testedAt: null }, meta)])) };
  }
}

module.exports = { WhatsAppCloudApiAdapter, CLOUD_MEDIA_MAX_BYTES, CLOUD_MEDIA_MAX_BYTES_BY_TYPE, MEDIA_TYPES, matchesMimeSignature };
