'use strict';

const CAPABILITY_STATUSES = new Set(['available', 'unavailable', 'experimental', 'account-restricted', 'deprecated']);
const REQUIRED_PROVIDER_METHODS = Object.freeze([
  'connect', 'disconnect', 'getStatus', 'sendText', 'sendMedia', 'sendVoice', 'sendPoll', 'sendEvent',
  'sendReaction', 'getCapabilities', 'normalizeInbound', 'validateTarget',
]);

function channelError(code, message, details = {}) {
  return Object.assign(new Error(String(message || 'Channel provider operation failed.')), {
    code: String(code || 'CHANNEL_PROVIDER_ERROR'), retryable: details.retryable === true,
    providerId: details.providerId || null, capability: details.capability || null,
    statusCode: Number(details.statusCode) || 0,
  });
}

function normalizeCapability(id, input = {}, meta = {}) {
  const status = CAPABILITY_STATUSES.has(input.status) ? input.status : 'unavailable';
  return {
    id: String(id), status,
    reason: String(input.reason || '').slice(0, 300),
    testedAt: input.testedAt || null,
    providerVersion: String(input.providerVersion || meta.providerVersion || 'unknown'),
    providerId: String(input.providerId || meta.providerId || 'unknown'),
    accountId: String(input.accountId || meta.accountId || 'default'),
    chatType: String(input.chatType || meta.chatType || 'unknown'),
    constraints: input.constraints && typeof input.constraints === 'object' ? { ...input.constraints } : {},
  };
}

class ChannelProvider {
  constructor({ id, name, version = 'unknown' } = {}) {
    if (!id || typeof id !== 'string') throw new TypeError('ChannelProvider requires a stable id.');
    this.id = id;
    this.name = String(name || id);
    this.version = String(version || 'unknown');
  }
  assertContract() {
    const missing = REQUIRED_PROVIDER_METHODS.filter(method => typeof this[method] !== 'function');
    if (missing.length) throw channelError('CHANNEL_PROVIDER_CONTRACT_INVALID', `Provider ${this.id} is missing: ${missing.join(', ')}`, { providerId: this.id });
    return true;
  }
  async connect() { throw channelError('CHANNEL_PROVIDER_NOT_IMPLEMENTED', `${this.id}.connect is not implemented.`, { providerId: this.id }); }
  async disconnect() { throw channelError('CHANNEL_PROVIDER_NOT_IMPLEMENTED', `${this.id}.disconnect is not implemented.`, { providerId: this.id }); }
  async getStatus() { throw channelError('CHANNEL_PROVIDER_NOT_IMPLEMENTED', `${this.id}.getStatus is not implemented.`, { providerId: this.id }); }
  async sendText() { throw channelError('CHANNEL_PROVIDER_NOT_IMPLEMENTED', `${this.id}.sendText is not implemented.`, { providerId: this.id }); }
  async sendMedia() { throw channelError('CHANNEL_PROVIDER_NOT_IMPLEMENTED', `${this.id}.sendMedia is not implemented.`, { providerId: this.id }); }
  async sendVoice() { throw channelError('CHANNEL_PROVIDER_NOT_IMPLEMENTED', `${this.id}.sendVoice is not implemented.`, { providerId: this.id, capability: 'voiceNote' }); }
  async sendPoll() { throw channelError('CHANNEL_PROVIDER_NOT_IMPLEMENTED', `${this.id}.sendPoll is not implemented.`, { providerId: this.id }); }
  async sendEvent() { throw channelError('CHANNEL_PROVIDER_NOT_IMPLEMENTED', `${this.id}.sendEvent is not implemented.`, { providerId: this.id }); }
  async sendReaction() { throw channelError('CHANNEL_PROVIDER_NOT_IMPLEMENTED', `${this.id}.sendReaction is not implemented.`, { providerId: this.id }); }
  async getCapabilities() { return {}; }
  normalizeInbound() { throw channelError('CHANNEL_PROVIDER_NOT_IMPLEMENTED', `${this.id}.normalizeInbound is not implemented.`, { providerId: this.id }); }
  validateTarget() { throw channelError('CHANNEL_PROVIDER_NOT_IMPLEMENTED', `${this.id}.validateTarget is not implemented.`, { providerId: this.id }); }
}

class CapabilityRegistry {
  constructor() { this.records = new Map(); }
  key(providerId, accountId, chatType) { return [providerId, accountId || 'default', chatType || 'unknown'].join('|'); }
  replace(providerId, accountId, chatType, capabilities) {
    const meta = { providerId, accountId, chatType };
    const records = Object.entries(capabilities || {}).map(([id, value]) => normalizeCapability(id, value, meta));
    this.records.set(this.key(providerId, accountId, chatType), records);
    return records.map(record => ({ ...record, constraints: { ...record.constraints } }));
  }
  get(providerId, accountId, chatType) {
    const rows = this.records.get(this.key(providerId, accountId, chatType)) || [];
    return rows.map(record => ({ ...record, constraints: { ...record.constraints } }));
  }
  clear(providerId, accountId, chatType) { this.records.delete(this.key(providerId, accountId, chatType)); }
}

class ProviderRegistry {
  constructor() { this.providers = new Map(); }
  register(provider) {
    if (!provider || typeof provider !== 'object' || typeof provider.assertContract !== 'function') {
      throw channelError('CHANNEL_PROVIDER_CONTRACT_INVALID', 'Provider must implement the ChannelProvider contract.');
    }
    provider.assertContract();
    if (this.providers.has(provider.id)) throw channelError('CHANNEL_PROVIDER_DUPLICATE', `Provider id already registered: ${provider.id}`, { providerId: provider.id });
    this.providers.set(provider.id, provider);
    return provider;
  }
  get(id) { return this.providers.get(String(id || '')) || null; }
  list() { return [...this.providers.values()].map(provider => ({ id: provider.id, name: provider.name, version: provider.version })); }
}

module.exports = {
  CAPABILITY_STATUSES, REQUIRED_PROVIDER_METHODS, ChannelProvider, CapabilityRegistry,
  ProviderRegistry, channelError, normalizeCapability,
};
