'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const os = require('node:os');

let cachedBootId;
function readBootId() {
  if (process.platform !== 'linux') return null;
  if (cachedBootId !== undefined) return cachedBootId;
  try { cachedBootId = fs.readFileSync('/proc/sys/kernel/random/boot_id', 'utf8').trim() || null; }
  catch { cachedBootId = null; }
  return cachedBootId;
}

function readProcessStartTicks(pid) {
  if (process.platform !== 'linux') return null;
  const value = Number(pid);
  if (!Number.isInteger(value) || value <= 0) return null;
  try {
    const stat = fs.readFileSync(`/proc/${value}/stat`, 'utf8');
    // comm (field 2) may contain spaces and closing parentheses; split only after
    // the final ')' so field 22 (starttime) is read from a stable position.
    const close = stat.lastIndexOf(')');
    if (close < 0) return null;
    const fields = stat.slice(close + 1).trim().split(/\s+/);
    const ticks = Number(fields[19]); // fields[0] is proc stat field 3 (state)
    return Number.isSafeInteger(ticks) && ticks > 0 ? ticks : null;
  } catch { return null; }
}

function getProcessIdentity(pid = process.pid) {
  const value = Number(pid);
  if (!Number.isInteger(value) || value <= 0) return { pid: null, processStartTicks: null, bootId: readBootId() };
  return {
    pid: value,
    processStartTicks: readProcessStartTicks(value),
    bootId: readBootId(),
  };
}

function isPidAlive(pid) {
  const value = Number(pid);
  if (!Number.isInteger(value) || value <= 0) return false;
  try { process.kill(value, 0); return true; }
  catch (error) { return error?.code === 'EPERM'; }
}

function isProcessIdentityAlive(pid, expected = {}) {
  const value = Number(pid);
  if (!Number.isInteger(value) || value <= 0) return false;
  try { process.kill(value, 0); }
  catch (error) { return error?.code === 'EPERM'; }

  // PID reuse after a reboot or after a process exits must not keep a stale
  // LocalAuth lock alive forever. When identity metadata is unavailable, fail
  // closed and treat the process as alive rather than guessing that it is stale.
  const expectedBootId = typeof expected.bootId === 'string' ? expected.bootId : '';
  const currentBootId = readBootId();
  if (expectedBootId && currentBootId && expectedBootId !== currentBootId) return false;

  const expectedTicks = Number(expected.processStartTicks);
  if (Number.isSafeInteger(expectedTicks) && expectedTicks > 0 && process.platform === 'linux') {
    const actualTicks = readProcessStartTicks(value);
    if (actualTicks && actualTicks !== expectedTicks) return false;
  }
  return true;
}

function readLock(filePath) {
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    const value = JSON.parse(raw);
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
  } catch { return null; }
}

function lockOwnerAlive(value) {
  if (!value || typeof value !== 'object') return false;
  const nodeAlive = isProcessIdentityAlive(value.pid, {
    processStartTicks: value.processStartTicks,
    bootId: value.bootId,
  });
  const browserAlive = isProcessIdentityAlive(value.browserPid, {
    processStartTicks: value.browserStartTicks,
    bootId: value.browserBootId || value.bootId,
  });
  return nodeAlive || browserAlive;
}

function lockAgeMs(filePath) {
  try { return Math.max(0, Date.now() - fs.statSync(filePath).mtimeMs); }
  catch (error) { return error?.code === 'ENOENT' ? Infinity : 0; }
}

function canRecoverLock(filePath, owner, { corruptGraceMs = 15000 } = {}) {
  const grace = Math.max(1000, Number(corruptGraceMs) || 15000);
  if (!owner || typeof owner !== 'object') {
    // A freshly-created unreadable file can be between wx-open and metadata write.
    return lockAgeMs(filePath) >= grace;
  }

  const hasNodePid = Number.isInteger(Number(owner.pid)) && Number(owner.pid) > 0;
  const hasBrowserPid = Number.isInteger(Number(owner.browserPid)) && Number(owner.browserPid) > 0;
  if (!hasNodePid && !hasBrowserPid) return lockAgeMs(filePath) >= grace;

  // During Chromium launch, there may be a short interval between the browser
  // process being created and its PID being observed by the owner. A dead Node
  // PID alone is not enough to prove the profile is free in that window.
  if (!hasBrowserPid && ['launching', 'running', 'untracked'].includes(String(owner.browserState || '').toLowerCase())) return false;

  return !lockOwnerAlive(owner);
}

function lockError(filePath, owner) {
  const uncertainBrowser = !Number(owner?.browserPid) && ['launching', 'running', 'untracked'].includes(String(owner?.browserState || '').toLowerCase());
  const suffix = uncertainBrowser
    ? ' وكانت حالة تشغيل Chromium غير محسومة؛ لن أزيل القفل تلقائيًا حتى لا أفتح ملف LocalAuth بينما قد يكون المتصفح القديم ما زال يعمل.'
    : ' لا يمكن فتح ملف LocalAuth نفسه من نسختين متزامنتين.';
  const error = new Error(`جلسة WhatsApp محجوزة بالفعل بواسطة عملية أخرى (PID ${Number(owner?.pid) || 'غير معروف'}).${suffix} أوقف النسخة الأخرى أو تحقق من متصفح الجلسة قبل إعادة المحاولة.`);
  error.code = 'WHATSAPP_SESSION_PROCESS_LOCKED';
  error.lockPath = filePath;
  error.ownerPid = Number(owner?.pid) || null;
  error.browserPid = Number(owner?.browserPid) || null;
  error.browserState = String(owner?.browserState || 'unknown');
  return error;
}

function recoveryGatePath(filePath) { return `${filePath}.recovery`; }

function recoveryGateError(filePath) {
  const gatePath = recoveryGatePath(filePath);
  const owner = readLock(path.join(gatePath, 'owner.json'));
  const error = new Error(`تجري عملية استعادة قفل جلسة WhatsApp أو توقفت أثناءها. لن أغيّر ملف LocalAuth بالتوازي. تحقق من توقف PID ${Number(owner?.pid) || 'غير معروف'}، ثم افحص مجلد الاستعادة ${gatePath} قبل إزالته يدويًا.`);
  error.code = 'WHATSAPP_SESSION_RECOVERY_LOCKED';
  error.lockPath = filePath;
  error.recoveryPath = gatePath;
  error.ownerPid = Number(owner?.pid) || null;
  return error;
}

function acquireRecoveryGate(filePath) {
  const gatePath = recoveryGatePath(filePath);
  try { fs.mkdirSync(gatePath, { mode: 0o700 }); }
  catch (error) {
    if (error?.code === 'EEXIST') throw recoveryGateError(filePath);
    throw error;
  }
  const owner = {
    version: 1,
    ...getProcessIdentity(),
    hostname: os.hostname(),
    token: crypto.randomUUID(),
    acquiredAt: new Date().toISOString(),
  };
  try {
    fs.writeFileSync(path.join(gatePath, 'owner.json'), JSON.stringify(owner), { encoding: 'utf8', flag: 'wx', mode: 0o600 });
  } catch (error) {
    try { fs.rmSync(gatePath, { recursive: true, force: true }); } catch {}
    throw error;
  }
  let released = false;
  return {
    release() {
      if (released) return false;
      released = true;
      const current = readLock(path.join(gatePath, 'owner.json'));
      if (current?.token !== owner.token) return false;
      try { fs.rmSync(gatePath, { recursive: true, force: true }); return true; }
      catch (error) { return error?.code === 'ENOENT'; }
    },
  };
}

function writeLockFile(filePath, metadata, { allowRecoveryGate = false } = {}) {
  const token = crypto.randomUUID();
  const initial = {
    version: 2,
    token,
    ...getProcessIdentity(),
    hostname: os.hostname(),
    browserPid: null,
    browserStartTicks: null,
    browserBootId: null,
    browserState: String(metadata.browserState || 'not_started'),
    sessionId: String(metadata.sessionId || '').slice(0, 100),
    acquiredAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  const fd = fs.openSync(filePath, 'wx', 0o600);
  try {
    fs.writeFileSync(fd, JSON.stringify(initial), 'utf8');
    fs.fsyncSync(fd);
    // A process may have passed the first gate check just before a stale-lock
    // recovery began. Such an in-flight claimant must yield to the recovery owner.
    if (!allowRecoveryGate && fs.existsSync(recoveryGatePath(filePath))) {
      try { fs.closeSync(fd); } catch {}
      const current = readLock(filePath);
      if (current?.token === token) { try { fs.unlinkSync(filePath); } catch {} }
      throw recoveryGateError(filePath);
    }
  } catch (error) {
    try { fs.closeSync(fd); } catch {}
    const current = readLock(filePath);
    if (current?.token === token) { try { fs.unlinkSync(filePath); } catch {} }
    throw error;
  }

  let released = false;
  const current = { ...initial };
  return {
    filePath,
    token,
    update(patch = {}) {
      if (released) return false;
      const next = { ...patch };
      if (Object.prototype.hasOwnProperty.call(next, 'browserPid')) {
        const identity = getProcessIdentity(next.browserPid);
        next.browserStartTicks = identity.processStartTicks;
        next.browserBootId = identity.bootId;
      }
      Object.assign(current, next, { updatedAt: new Date().toISOString() });
      try {
        fs.ftruncateSync(fd, 0);
        fs.writeSync(fd, JSON.stringify(current), 0, 'utf8');
        fs.fsyncSync(fd);
        return true;
      } catch { return false; }
    },
    release() {
      if (released) return false;
      released = true;
      try { fs.closeSync(fd); } catch {}
      const owner = readLock(filePath);
      if (owner?.token !== token) return false;
      try { fs.unlinkSync(filePath); return true; }
      catch (error) { return error?.code === 'ENOENT'; }
    },
    get released() { return released; },
  };
}

function acquireSessionProcessLock(filePath, metadata = {}) {
  const target = path.resolve(filePath);
  fs.mkdirSync(path.dirname(target), { recursive: true });

  for (let attempt = 0; attempt < 4; attempt++) {
    if (fs.existsSync(recoveryGatePath(target))) throw recoveryGateError(target);
    try {
      return writeLockFile(target, metadata);
    } catch (error) {
      if (error?.code !== 'EEXIST') throw error;
    }

    const owner = readLock(target);
    if (!canRecoverLock(target, owner)) throw lockError(target, owner || {});

    // Serialize stale-lock recovery. All regular claims check this gate before and
    // after creating their lock file; a claimant racing the gate therefore yields.
    const gate = acquireRecoveryGate(target);
    try {
      const currentOwner = readLock(target);
      if (fs.existsSync(target) && !canRecoverLock(target, currentOwner)) {
        throw lockError(target, currentOwner || {});
      }
      try { fs.unlinkSync(target); }
      catch (error) { if (error?.code !== 'ENOENT') throw error; }

      // A claimant that passed its first gate check just before the gate was created
      // may win the wx race. It will notice the gate and remove only its own token.
      let lastError = null;
      for (let recoveryAttempt = 0; recoveryAttempt < 20; recoveryAttempt++) {
        try { return writeLockFile(target, metadata, { allowRecoveryGate: true }); }
        catch (error) {
          if (error?.code !== 'EEXIST') throw error;
          lastError = error;
          const inFlightOwner = readLock(target);
          if (inFlightOwner && !lockOwnerAlive(inFlightOwner)) {
            // Only reclaim a valid, provably dead owner. Unknown browser-launch
            // state remains fail-closed even when the Node PID has disappeared.
            if (canRecoverLock(target, inFlightOwner)) {
              try { fs.unlinkSync(target); } catch (unlinkError) { if (unlinkError?.code !== 'ENOENT') throw unlinkError; }
            } else {
              Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 10);
            }
          } else {
            // Give an already-running claimant a short opportunity to observe the gate
            // and yield. Do not remove a live owner's file.
            Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 10);
          }
        }
      }
      throw lockError(target, readLock(target) || (lastError ? {} : {}));
    } finally {
      gate.release();
    }
  }
  throw recoveryGateError(target);
}

module.exports = {
  acquireSessionProcessLock,
  isPidAlive,
  isProcessIdentityAlive,
  readProcessStartTicks,
  getProcessIdentity,
  readLock,
  lockOwnerAlive,
  canRecoverLock,
  recoveryGatePath,
};
