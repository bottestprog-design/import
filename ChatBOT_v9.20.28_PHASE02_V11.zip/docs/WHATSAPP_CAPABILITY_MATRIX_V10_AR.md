# مصفوفة قدرات WhatsApp حسب نوع الموصل — V10

> لا تخلط الإمكانيات بين WhatsApp Web عبر whatsapp-web.js وبين WhatsApp Business Platform Cloud API أو مزود BSP. يجب أن يحتفظ النظام بقدرات لكل `provider + account + chatType + version`.

## 1. المصفوفة

| القدرة | WhatsApp Web عبر whatsapp-web.js 1.34.7 | Cloud API/BSP | سياسة البناء |
|---|---|---|---|
| نصوص/ردود/اقتباس | موثق | موثق | مدعوم عبر واجهة موحدة |
| صور/صوت/مستندات | موثق | موثق بقيود مختلفة | Media pipeline يختبر MIME والحجم لكل موصل |
| فيديو | يتطلب Google Chrome حسب توثيق المكتبة | MP4/3GP ضمن حدود Cloud API | لا تُعمم حدود Cloud API على WebJS |
| Voice Note | sendAudioAsVoice في مكتبة WebJS | OGG/Opus وغيره حسب النوع والقيود | فحص codec وlive playback |
| Stickers | موثق | WebP static/animated بحدود تختلف | تحويل وفحص حجم قبل الإرسال |
| Contacts/Location | موثق في WebJS | أنواع ومزايا حسب API | capability discovery |
| Reactions | موثق | دعم حسب واجهة/إصدار API | حفظ reaction event والمرجع الأصلي |
| Poll create/vote | موثق في WebJS؛ مركز المساعدة يشرح الاستطلاعات كمجموعات | ليس افتراضًا عامًا في Cloud API | ابدأ بالمجموعات في WebJS، DM بعد live test فقط |
| Scheduled Events / RSVP | class/API متاحة في WebJS؛ يلزم smoke test على الفردي والمجموعات | لا تفترض توافر event API | native event connector gated + fallback scheduler |
| Buttons | Deprecated في WebJS | reply buttons ضمن شروط API/template | ممنوع بناء ميزة جديدة على Buttons القديمة |
| Lists | Deprecated في WebJS | list messages ضمن الشروط | WebJS fallback نصي؛ Cloud API interactive list |
| WhatsApp Flows | ليست ميزة إرسال موثقة في WebJS الحالي | ميزة Business API مع إعدادات Flow وwebhooks | Cloud-only adapter، opt-in، schema versioning |
| Catalog/Products/Cart | ليست قدرة عامة موثقة في WebJS | تتطلب commerce/catalog setup وأهلية | Cloud/BSP only gated |
| Carousel | لا يوجد support عام موثق في WebJS | يتوفر في templates/BSP/product-specific routes | لا ترسل إلا بعد provider capability/template validation |
| 3D interactive in-bubble | لا يوجد عارض 3D عام موثق | لا يُفترض وجود عارض 3D داخل فقاعة الرسالة | image/video preview + WebAR link |
| Groups | WebJS يدير المجموعات حسب صلاحية الحساب | Cloud groups لها أهلية وقيود مختلفة حسب Meta/provider | لا تنقل افتراضات WebJS إلى Cloud |
| Channels | WebJS يوثق بعض دعم القنوات مع قائمة محتوى محدودة | Cloud API مختلف | feature flags واختبار منفصل |

## 2. حدود Cloud API المنشورة — لا تطبق على WebJS

بحسب دليل AWS لحدود وسائط WhatsApp Business Platform، أمثلة الحدود التي يجب التحقق منها وقت التشغيل:

- الصور JPEG/PNG حتى 5 MB.
- الصوت حتى 16 MB لبعض الأنواع المدعومة (AAC/AMR/MP3/M4A/OGG).
- الفيديو MP4/3GP حتى 16 MB.
- المستندات المدعومة حتى 100 MB.
- ملصق WebP ثابت حتى 100 KB ومتحرك حتى 500 KB.

هذه الحدود يجب تخزينها كـcapability profile قابل للتحديث، لا hard-coded shared مع WebJS. يجب مراجعة توثيق Meta النهائي/المزود قبل كل إصدار.

## 3. استراتيجية fallback

1. إذا كانت capability `supported`: تحقق من النوع والحجم والنافذة والسياسة ثم أرسل.
2. إذا كانت `unsupported` أو `deprecated`: لا تحاول إرسالها؛ اعرض بديل نصي.
3. إذا كانت `account-restricted`: اطلب استكمال أهلية الحساب/القالب/الكتالوج.
4. إذا كانت `experimental`: لا تفعّلها في الإنتاج قبل smoke test معلن.
5. إذا فشل provider في الرد بعد الإرسال: استخدم `uncertain`, لا تعِد الإرسال عميانيًا.

## 4. المصادر

- https://docs.wwebjs.dev/
- https://docs.wwebjs.dev/Client.html
- https://docs.wwebjs.dev/ScheduledEvent.html
- https://faq.whatsapp.com/796470361614974/
- https://developers.facebook.com/docs/whatsapp/cloud-api/
- https://developers.facebook.com/docs/whatsapp/flows/
- https://docs.360dialog.com/partner/waba-management/whatsapp-flows
- https://www.twilio.com/docs/whatsapp/flows
- https://docs.aws.amazon.com/social-messaging/latest/userguide/supported-media-types.html
- https://developers.google.com/ar/develop/scene-viewer
- https://modelviewer.dev/

## 5. طبقة موصلات القنوات — تنفيذ المرحلة 02 (v9.20.28)

- العقد المشترك موجود في `src/channel-provider.js` ويطلب: `connect`, `disconnect`, `getStatus`, `sendText`, `sendMedia`, `sendVoice`, `sendPoll`, `sendEvent`, `sendReaction`, `getCapabilities`, `normalizeInbound`, `validateTarget`.
- `src/whatsapp-web-adapter.js` هو موصل WhatsApp Web الفعلي ويستدعي عمليات WhatsApp Web القائمة من `src/whatsapp.js`؛ أُبقيت واجهات manager القديمة كي لا تتعطل خدمات المحادثات والصوت والوسائط.
- `CapabilityRegistry` متصل الآن بمدير WhatsApp ويحفظ السجل الموحّد حسب الموصل والحساب ونوع المحادثة؛ لا يغيّر ذلك نتيجة الاختبار ولا يملأ `testedAt` تلقائيًا.
- `src/whatsapp-cloud-api-adapter.js` موصل اختياري stateless. لا يتم اختياره افتراضيًا، ولا يرسل أي طلب عند بدء البرنامج. يتطلب إعدادًا صريحًا لـ`WHATSAPP_CLOUD_API_VERSION` و`WHATSAPP_CLOUD_PHONE_NUMBER_ID` و`WHATSAPP_CLOUD_ACCESS_TOKEN`. واجهة النص والوسائط المحلية وحدها مفعلة برمجيًا؛ لها حدود محافظة حسب النوع (صورة 5 MB، فيديو/صوت 16 MB، مستند 32 MB محليًا)، وهي سقوف تنفيذ محلية وليست إعادة صياغة لحدود Meta الرسمية. Poll وEvent وReaction وVoice Note معلّمة غير متاحة هنا.
- القدرات تعاد لكل `provider + accountId + chatType`، مع `status`, `reason`, `testedAt`, `providerVersion` وقيود إضافية. `testedAt` يبقى null حتى يوجد اختبار قبول فعلي؛ `observedAt` وقت قراءة الحالة لا يعني نجاحًا حيًا.
- Poll في WhatsApp Web يظهر `experimental` للمجموعات فقط، ويظل مغلقًا افتراضيًا حتى `WHATSAPP_WEB_ENABLE_EXPERIMENTAL_POLLS=true`. لا يُفعّل في المحادثات الفردية قبل اختبار حي منفصل.
- Scheduled Events تظهر `experimental`، ومغلقة افتراضيًا حتى `WHATSAPP_WEB_ENABLE_EXPERIMENTAL_EVENTS=true` وبعد اختبار الحساب ونوع المحادثة.
- Buttons وLists في WhatsApp Web معلّمتان `deprecated`؛ لا ينشئ الموصل واجهات جديدة عليهما. يجب استخدام نص مرقّم كبديل آمن. Cloud API يعرض قدرات تفاعلية رسمية منفصلة، لكن الأهلية والنافذة والقوالب تبقى شروطًا على مستوى الحساب.
- يرسل الموصل الحالي الحدث المحايد `inbound` إلى جانب حدث `message` الخام القديم. لا تزال الخدمات الحالية تستعمل الحدث الخام حتى لا يتغير سلوكها أثناء هذا الفصل؛ نقل المعالجة بالكامل للعقد الموحد مرحلة مستقلة.

اختبارات المرحلة 02 تغطي العقد، سجل الموصلات والقدرات، التحقق من المستلم، تطبيع الرسائل، الحالات غير المدعومة/التجريبية، حماية MIME الأساسية للوسائط، ومنع تمرير رمز الوصول عبر إعادة توجيه HTTP، وطلبات Cloud API باستخدام fetch وهمي. لا تختبر اعتماد Cloud API حقيقيًا أو حساب WhatsApp حيًا.
