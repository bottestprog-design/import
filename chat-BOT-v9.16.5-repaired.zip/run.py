from __future__ import annotations
import os
import shutil
import subprocess
import sys
import re
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BROWSER_CACHE = ROOT / '.cache' / 'puppeteer'
BROWSER_MARKER = ROOT / '.browser-path'

def run(cmd, env=None):
    try:
        return subprocess.call(cmd, cwd=ROOT, env=env)
    except FileNotFoundError:
        return 127

def capture(cmd, env=None):
    try:
        return subprocess.run(cmd, cwd=ROOT, env=env, text=True, capture_output=True).stdout.strip()
    except Exception:
        return ''

def node_ok(node):
    raw = capture([node, '--version'])
    m = re.match(r'v(\d+)\.', raw)
    return bool(m) and int(m.group(1)) >= 20

def load_browser_marker():
    try:
        value = BROWSER_MARKER.read_text(encoding='utf-8').strip()
        return value if value and Path(value).is_file() else ''
    except Exception:
        return ''

def dependency_gaps(root: Path = ROOT):
    """Return missing or lockfile-mismatched direct npm dependencies.

    Checking only Puppeteer and whatsapp-web.js used to miss Express/Multer or
    other runtime dependencies when a partially populated node_modules existed.
    The lockfile is the source of truth for exact versions when available.
    """
    package_file = root / 'package.json'
    lock_file = root / 'package-lock.json'
    try:
        manifest = json.loads(package_file.read_text(encoding='utf-8'))
    except Exception as exc:
        return [f'package.json غير قابل للقراءة: {exc}']
    try:
        lock = json.loads(lock_file.read_text(encoding='utf-8')) if lock_file.exists() else {}
    except Exception:
        lock = {}
    lock_packages = lock.get('packages', {}) if isinstance(lock, dict) else {}
    declared = manifest.get('dependencies', {})
    gaps = []
    if not isinstance(declared, dict) or not declared:
        return ['لا توجد dependencies صالحة في package.json.']
    for name, requested in sorted(declared.items()):
        module_path = root / 'node_modules' / Path(*name.split('/')) / 'package.json'
        try:
            installed = json.loads(module_path.read_text(encoding='utf-8')).get('version')
        except Exception:
            installed = None
        lock_key = 'node_modules/' + name
        locked = (lock_packages.get(lock_key) or {}).get('version')
        # All direct dependencies in this project are exact-pinned. If a future
        # manifest uses a range, a present install is accepted unless the lock
        # file provides the precise expected version.
        expected = str(locked or requested or '')
        if not installed:
            gaps.append(f'{name}: غير مثبت (المطلوب {expected or requested})')
        elif expected and expected[0].isdigit() and installed != expected:
            gaps.append(f'{name}: المثبت {installed}، المطلوب {expected}')
    return gaps


def main():
    os.environ.setdefault('PORT', '7005')
    os.environ.setdefault('PUPPETEER_CACHE_DIR', str(BROWSER_CACHE))
    BROWSER_CACHE.mkdir(parents=True, exist_ok=True)

    npm = shutil.which('npm.cmd') or shutil.which('npm')
    node = shutil.which('node')
    if not npm or not node:
        print('لم يتم العثور على Node.js/npm. ثبّت Node.js 20 أو أحدث ثم شغّل run.py مرة أخرى.')
        raise SystemExit(127)
    print(f'Node: {capture([node, "--version"])}')
    if not node_ok(node):
        print('إصدار Node.js غير مدعوم. استخدم Node.js 20 أو أحدث.')
        raise SystemExit(2)

    gaps = dependency_gaps(ROOT)
    if gaps:
        print('تم العثور على اعتماديات ناقصة أو غير مطابقة:')
        for item in gaps:
            print(f'  - {item}')
        print('جارٍ تثبيت الاعتماديات المطابقة لملف القفل…')
        # Do not disable dependency install scripts: Puppeteer may need its
        # browser setup, while the project postinstall applies a compatibility patch.
        code = run([npm, 'install', '--no-audit', '--no-fund'], env=os.environ.copy())
        if code != 0:
            print('فشل تثبيت الاعتمادات. لم يبدأ البوت؛ تحقق من اتصال npm ثم أعد المحاولة.')
            raise SystemExit(code)
        gaps = dependency_gaps(ROOT)
        if gaps:
            print('ما زالت هناك اعتماديات ناقصة أو غير مطابقة بعد التثبيت:')
            for item in gaps:
                print(f'  - {item}')
            print('لم يبدأ البوت لتجنب انهيار الخادم عند التشغيل.')
            raise SystemExit(3)

    print('جارٍ تجهيز متصفح WhatsApp…')
    browser = load_browser_marker()
    if not browser:
        code = run([node, str(ROOT / 'scripts' / 'ensure-browser.js')], env=os.environ.copy())
        if code != 0:
            print('تعذر تجهيز Chrome/Chromium. لم يبدأ البوت.')
            raise SystemExit(code)
        browser = load_browser_marker()
    if browser:
        os.environ['CHROME_PATH'] = browser
        os.environ['PUPPETEER_EXECUTABLE_PATH'] = browser
        print(f'Browser: {browser}')

    print('جارٍ فحص توافق whatsapp-web.js…')
    repair = run([npm, 'run', 'repair-whatsapp'], env=os.environ.copy())
    if repair != 0:
        print('تعذر فحص توافق whatsapp-web.js. لم يبدأ البوت حتى لا يعمل بحالة غير سليمة.')
        raise SystemExit(repair)
    # Refuse to start the bot if any verification test was skipped.
    # This prevents a partially installed/broken npm tree from being reported as healthy.
    verify = run([npm, 'run', 'test:strict'], env=os.environ.copy())
    if verify != 0:
        print('فشل فحص سلامة المشروع. لم يبدأ البوت.')
        raise SystemExit(verify)
    raise SystemExit(run([npm, 'start'], env=os.environ.copy()))

if __name__ == '__main__':
    main()
