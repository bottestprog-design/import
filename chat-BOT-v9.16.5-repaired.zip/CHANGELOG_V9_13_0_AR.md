# سجل التغيير — v9.13.0

- إضافة لغة أوامر عربية ثابتة لقواعد الشات مع preview وconfirmation حرفي، متغيرات موثقة، ورفض مدخلات الحقول غير المعروفة.
- دعم contains/exact/starts/ends/similarity/intent/regex/any مع التحقق من عتبة التشابه وسلامة Regex.
- إضافة إعداد محلي على Windows لمحرك whisper.cpp ونموذج ggml-base وFFmpeg، وتنبيه واضح عند غياب المحرك أو النموذج أو FFmpeg؛ لا تُعرض فويسات WhatsApp كجاهزة عند غياب محول OGG/OPUS.
- تحديث رقعة whatsapp-web.js لتوافق `_serialized`/`$1`، وعزل أخطاء المحادثات، وحماية تحديث metadata، ومعالجة سباق تسجيل callbacks أثناء التهيئة.
- تبسيط خيارات QR / رمز الهاتف وتعليمات الربط، مع الحفاظ على مسار إنشاء قاعدة الرد التلقائي القديم.
- الاختبارات وتفاصيل حدود التحقق في `TEST_RESULTS_V9_13_0_AR.txt` و`REQUIREMENTS_FIX_REPORT_V9_13_0_AR.md`.
