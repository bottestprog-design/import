@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title chat BOT - إعداد الصوت المحلي الكامل

echo ============================================================
echo  chat BOT - Whisper + Piper + مدقق عربي محلي
echo ============================================================
echo يحتاج اتصال إنترنت لتنزيل المحركات والنماذج أول مرة.
echo بعد التنزيل تتم معالجة الصوت محليًا؛ لا تُرفع التسجيلات إلى خدمة صوت سحابية.
echo.

echo [1/3] إعداد Whisper لتفريغ الصوت إلى نص...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup-whisper.ps1"
if errorlevel 1 goto :failed

echo.
echo [2/3] إعداد Piper لإنتاج الردود الصوتية العربية...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup-tts.ps1"
if errorlevel 1 goto :failed

echo.
echo.
echo اكتمل إعداد Whisper وPiper المحليين. لا يحتاج إرسال الصوت إلى Ollama أو مدقق لغوي.
echo يمكن إعداد الذكاء المحلي اختياريًا من قسم المحركات عند الحاجة.
echo.
pause
exit /b 0

:failed
echo.
echo لم يكتمل إعداد كل مكونات الصوت. راجع الخطأ الظاهر أعلاه.
echo إذا نجح Whisper وفشل Piper، يمكنك استخدام التفريغ النصي بينما تكمل إعداد النطق بشكل مستقل.
pause
exit /b 1
