@echo off
chcp 65001 >nul
set "ROOT=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%ROOT%scripts\setup-tts.ps1"
if errorlevel 1 (
  echo.
  echo لم يكتمل اعداد الصوت. راجع رسالة الخطأ بالأعلى.
  pause
  exit /b 1
)
