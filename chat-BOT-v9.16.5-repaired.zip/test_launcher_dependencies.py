from __future__ import annotations
import importlib.util
import json
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('chatbot_launcher', ROOT / 'run.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

with tempfile.TemporaryDirectory(prefix='chatbot-launcher-test-') as tmp:
    root = Path(tmp)
    (root / 'node_modules' / 'express').mkdir(parents=True)
    (root / 'node_modules' / 'express' / 'package.json').write_text(json.dumps({'version': '5.2.1'}), encoding='utf-8')
    (root / 'node_modules' / '@scope' / 'adapter').mkdir(parents=True)
    (root / 'node_modules' / '@scope' / 'adapter' / 'package.json').write_text(json.dumps({'version': '2.4.0'}), encoding='utf-8')
    manifest = {'dependencies': {'express': '5.2.1', '@scope/adapter': '2.4.0'}}
    lock = {'packages': {'node_modules/express': {'version': '5.2.1'}, 'node_modules/@scope/adapter': {'version': '2.4.0'}}}
    (root / 'package.json').write_text(json.dumps(manifest), encoding='utf-8')
    (root / 'package-lock.json').write_text(json.dumps(lock), encoding='utf-8')
    assert module.dependency_gaps(root) == [], 'matching direct dependencies should not trigger installation'
    (root / 'node_modules' / 'express' / 'package.json').unlink()
    gaps = module.dependency_gaps(root)
    assert any(item.startswith('express: غير مثبت') for item in gaps), 'missing Express must trigger installation even when node_modules exists'
    (root / 'node_modules' / 'express' / 'package.json').write_text(json.dumps({'version': '4.0.0'}), encoding='utf-8')
    gaps = module.dependency_gaps(root)
    assert any(item.startswith('express: المثبت 4.0.0') for item in gaps), 'wrong pinned version must trigger installation'
print('launcher-dependencies: ok (all direct dependencies, scoped names, missing packages and lockfile version mismatch)')
