# chat BOT 9.0 — Final Architecture & Engineering Review

## 1. Architecture decision

The delivered build remains **local-first and backward-compatible** with 8.9.0: the existing WhatsApp adapter, UI, media, scheduling, automation, reply rules, group handling and session JSON data remain in place. New modules are additive. The local build is suitable for one operator/process and modest workloads; it is **not honestly described as production-scale for millions of messages** until the durable queue, database, multi-worker coordination, observability and provider constraints below are deployed and load-tested.

### Logical flow

```text
WhatsApp Web adapter
  -> inbound validation / normalization
  -> bounded event bus (event IDs + correlation IDs)
  -> priority router
       -> owner commands -> permission checks -> command handler
       -> group events -> group policy / group triggers
       -> inbound messages -> automation rules -> auto-reply match/conflict resolver
       -> media processing pipeline
       -> voice transcript -> intent parser -> confirmation -> command engine
  -> action executor (rate limits, idempotency, retries, audit)
  -> outbound delivery adapter

Scheduler -> due-work queue -> same action executor
Storage ports: local JSON adapter (current) | SQLite (single-host) | PostgreSQL (scale)
Optional scale adapters: Redis/BullMQ queue, object storage, metrics/traces, external speech-to-text
```

## 2. Folder structure

```text
chat-BOT/
  server.js                    # HTTP composition root; kept for compatibility
  run.py                       # Windows/local launcher
  public/                      # Arabic RTL control panel
  src/
    whatsapp.js                # WhatsApp Web boundary; never leak provider objects
    compat.js                  # version/legacy compatibility
    event-bus.js               # bounded in-process domain events
    command-engine.js          # parse, authorize, validate, execute, audit
    trigger-engine.js          # phrase/regex/intent/similarity triggers
    reply-engine.js            # variations, context, cooldown, conflict policy
    anti-conflict.js           # deduplication and action collision policy
    automation-engine.js       # rules, conditions, action execution
    scheduler.js               # timezone-aware local scheduler
    delivery.js                # outbound delivery/retry boundary
    dictionary-engine.js       # normalized terms, aliases and lookup
    voice-to-command.js        # transcript-to-intent parser; execution stays separate
    groups.js                  # group IDs, metadata and validation
    media.js                   # path safety, scanning and media validation
    store.js                   # current local JSON session persistence
    phones.js backgrounds.js interaction.js serverlib.js
  test/                        # smoke, regression, compatibility, engines
  docs/                        # architecture, migrations, runbooks (see docs index)
  data/                        # local runtime state; never commit credentials
```

## 3. Data model

### Current local storage

The application retains per-session JSON files for compatibility. Do not write concurrent multi-process workloads against these files. Back up before upgrades; writes and reads are local-process oriented.

### Recommended PostgreSQL schema for production

- `tenants(id, name, created_at)`
- `sessions(id, tenant_id, provider, status, config_json, created_at, updated_at)`
- `contacts(id, tenant_id, provider_contact_id, display_name, attributes_json, UNIQUE(tenant_id, provider_contact_id))`
- `groups(id, tenant_id, provider_group_id, metadata_json, UNIQUE(tenant_id, provider_group_id))`
- `messages(id, tenant_id, session_id, provider_message_id, chat_id, sender_id, direction, message_type, body_text, media_key, sent_at, received_at, metadata_json, UNIQUE(session_id, provider_message_id))`
- `reply_rules(id, tenant_id, enabled, priority, match_type, match_config_json, responses_json, cooldown_seconds, scope_json, version, updated_at)`
- `automation_rules(id, tenant_id, enabled, trigger_type, condition_json, actions_json, timezone, destructive_confirmation, version)`
- `scheduled_jobs(id, tenant_id, session_id, rule_id, run_at, recurrence_json, status, attempts, idempotency_key, lease_until, last_error, created_at)`
- `mutes(id, tenant_id, session_id, target_id, target_type, starts_at, expires_at, permanent, status)`
- `dictionary_entries(id, tenant_id, term, normalized_term, definition, aliases_json, tags_json, updated_at)`
- `command_definitions(id, tenant_id, name, enabled, permission_policy_json, schema_json, handler_key, version)`
- `event_outbox(id, tenant_id, event_type, aggregate_id, payload_json, created_at, published_at, attempts)`
- `action_runs(id, tenant_id, idempotency_key, action_type, status, started_at, finished_at, result_json, error_code, UNIQUE(tenant_id, idempotency_key))`
- `audit_log(id, tenant_id, actor_id, action, target_id, outcome, correlation_id, created_at, details_json)`

Indexes: `(tenant_id, received_at DESC)` and `(tenant_id, chat_id, received_at DESC)` on messages; `(tenant_id, enabled, priority DESC)` on rules; `(status, run_at)` on jobs; `(tenant_id, normalized_term)` on dictionary; unique idempotency keys. Partition messages by month or tenant/time after measuring real volume; archive older partitions and keep media in object storage, not SQL rows.

## 4. API design

Existing `/api/*` routes remain supported. Current build adds:
- `GET /api/architecture/health` — module status and local storage/scale limitations.
- `POST /api/voice/parse` — accepts `{ transcript, locale?, confidence?, minConfidence? }`; parses intent only and does not execute actions.
- `GET /api/dictionary?q=&limit=&offset=` — bounded dictionary listing for entries registered in this process.
- `GET /api/dictionary/lookup?q=` — dictionary lookup.

Production API conventions:
- `/api/v1/sessions`, `/api/v1/messages`, `/api/v1/reply-rules`, `/api/v1/automation-rules`, `/api/v1/jobs`, `/api/v1/groups`, `/api/v1/mutes`, `/api/v1/dictionary`, `/api/v1/commands`, `/api/v1/media`, `/api/v1/voice/commands`.
- Use cursor pagination, request IDs, structured errors, validation schemas, authentication/authorization, per-tenant quotas and idempotency keys for all mutation/action endpoints.
- Use `202 Accepted` for queued work and a job resource for status; never keep an HTTP request open for a long media job.
- The current local UI is loopback-bound by default. Do not expose it to a LAN/public network without authentication, CSRF protections, secure session handling and rate limiting.

## 5. Event system

Envelope: `{ id, type, at, version, correlationId, payload }`. Core types include `message.received`, `message.sent`, `reaction.received`, `group.updated`, `rule.matched`, `command.requested`, `action.requested`, `action.completed`, `schedule.due`, `mute.expired`, `media.accepted`, `voice.transcribed`, and `voice.command.parsed`.

The included `EventBus` is intentionally bounded and in-process. It provides handler concurrency caps and bounded history, not persistence or cross-process delivery. For production, write domain changes and an outbox record in the same DB transaction; relay to Redis Streams/Kafka/RabbitMQ; use consumer groups, retries with backoff, dead-letter queues, event schema versions and idempotent consumers. Never treat in-memory events as durable.

## 6. Scheduler

Current scheduler is a local interval loop with per-session busy guards and last-run keys. This is compatible with one process but cannot guarantee cluster-wide single execution or durable recovery.

Production scheduler requirements: persist UTC `run_at` plus IANA timezone/recurrence, claim jobs using DB leases/`FOR UPDATE SKIP LOCKED` or queue visibility timeouts, enforce idempotency keys, record attempts and next retry, dead-letter exhausted jobs, recover expired leases, handle DST explicitly, and expose lag/queue-depth metrics. Separate due-job discovery from action workers. Destructive actions require explicit opt-in and audit.

## 7. Command engine

The new `CommandEngine` supports prefix parsing, named registrations, owner-only defaults, permission gates, argument validation, audit callbacks and safe unknown-command fallthrough. Keep command definitions declarative and handler keys allowlisted; never evaluate user-supplied JavaScript, shell commands, regex without limits, or arbitrary file paths. Assign precedence: owner command > explicit slash/bang command > exact trigger > high-confidence intent > similarity > fallback. A denied command must not fall through to a less privileged handler.

## 8. Dictionary engine

The new local `DictionaryEngine` normalizes Unicode and common Arabic letter variants, indexes aliases, bounds entry count and lookup result size, and supports fuzzy prefix/substring matching. It is an in-memory engine in this build; the API list/lookup therefore reflects entries loaded into that process and entries do not yet persist across restarts. Production must use a repository adapter backed by PostgreSQL, normalized-term indexes, full-text/trigram search and tenant scoping.

## 9. Media engine

Existing `src/media.js` remains responsible for local media discovery and safe paths. Production pipeline: upload quarantine -> MIME/signature inspection -> extension allowlist -> size limits -> malware scan -> content hash/dedup -> metadata extraction -> thumbnail/transcode worker -> object storage -> signed short-lived URL. Never trust client filenames or MIME headers; enforce tenant/session ownership; keep large binary blobs out of the database; clean abandoned temporary files.

## 10. Auto-reply engine

Existing rule engine supports variants, trigger types, similarity, intent, context variables, command priority, cooldown, counter thresholds and conflict policy. Production improvements: compile/cache rule matchers by rule version; bound regex execution and message length; prefilter by scope/type; use deterministic seeded variation when audit/reproducibility is needed; store cooldown/dedup keys in shared Redis/DB; add explain-mode showing why each rule matched; add shadow mode and replay-based regression before activation.

## 11. Notification engine

Mute policy model: target type (`contact|group`), target ID, scope/session, start time, expiry or permanent flag, source rule, status and audit record. Expiry should be a durable scheduled job, not only a local timer. Clarify that app-level mute handling and WhatsApp client's actual notification controls may differ by supported provider API. Provide idempotent mute/unmute and reconciliation when provider calls fail.

## 12. Group engine

Normalize and validate provider group IDs; resolve invite codes through the provider; keep metadata freshness timestamps; distinguish owner/admin/member when available; enforce server-side permission checks for each action; reject stale or unknown permissions by default for destructive operations. Group triggers must include group scope, mention policy, participant role checks, cooldown and loop prevention. Do not infer admin privileges from user-supplied fields.

## 13. Voice-to-command engine

Included parser converts recognized Arabic/English transcript phrases to intent objects and rejects low-confidence transcripts. It does not perform speech recognition and never executes actions. Production flow: push-to-talk/explicit recording consent -> speech-to-text adapter -> transcript display -> intent parser -> permission check -> confirmation for destructive/ambiguous actions -> standard command executor -> audit. Speech recognition may need network depending on browser/engine; label that clearly and offer a local offline STT adapter if offline operation is required. Never run a destructive command from a low-confidence transcript.

## 14. Missing features and priority improvements

P0 before public/production exposure:
1. Authentication, owner identity binding, CSRF and API rate limits if not loopback-only.
2. Durable transactional persistence and migrations; JSON backup/restore verification.
3. Shared idempotency and distributed scheduler locks.
4. Queue/outbox, retry policy, dead-letter queue and replay tooling.
5. Secrets management, dependency audit, upload malware checks and log redaction.
6. Operational health/readiness endpoints and structured metrics.

P1 for high quality:
- Repository interfaces so storage can change without rewriting engines.
- Provider adapter contract and compatibility tests against pinned WhatsApp Web versions.
- Rule simulation/explain mode, dry-run, approvals, rollback and change history.
- Retention/export/delete policy and data minimization.
- Contract tests, fuzz tests for regex/command parsing, fault injection and backup restore tests.

P2 for millions of messages:
- PostgreSQL partitioning and retention; Redis for distributed rate limits/cooldowns; queue workers; object storage/CDN for media; horizontal stateless API workers; autoscaling based on queue lag; read replicas only after measurement; OpenTelemetry tracing and dashboards.
- Load tests with realistic burst traffic and provider limits. WhatsApp Web automation itself may be the bottleneck and has reliability/terms constraints; scaling architecture cannot guarantee the upstream client can process millions of messages.

## 15. Acceptance and verification

`npm test` covers current smoke/regression/compatibility tests plus automation/reply engines and the new event bus, command, dictionary and voice parser unit tests. Passing local tests do not prove real WhatsApp delivery, multi-process safety, security review, or million-message throughput. Those require a linked account, integration tests, load testing and deployment infrastructure.
