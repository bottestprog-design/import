@echo off
setlocal
cd /d "%~dp0"
title chat BOT - إعداد الصوت المحلي
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup-whisper.ps1"
if errorlevel 1 (
  echo.
  echo لم يكتمل إعداد الصوت. راجع docs\VOICE_SETUP_AR.md.
  pause
  exit /b 1
)
echo.
echo تم إعداد المكونات التي نجحت عملية تنزيلها. أعد تشغيل البوت الآن.
pause
