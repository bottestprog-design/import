"use strict";
const { EventEmitter } = require('node:events');
const crypto = require('node:crypto');

/** Small bounded in-process event bus. Durable delivery is delegated to the outbox adapter. */
class EventBus extends EventEmitter {
  constructor({ maxListeners = 50, maxHistory = 500, logger = () => {} } = {}) {
    super(); this.setMaxListeners(maxListeners); this.maxHistory = maxHistory; this.logger = logger;
    this.history = []; this.handlers = new Map(); this.closed = false;
  }
  subscribe(type, handler, { id = crypto.randomUUID(), concurrency = 1 } = {}) {
    if (typeof handler !== 'function') throw new TypeError('handler must be a function');
    const list = this.handlers.get(type) || []; const entry = { id, handler, concurrency: Math.max(1, Number(concurrency) || 1), active: 0, queue: [] };
    list.push(entry); this.handlers.set(type, list);
    return () => { const current = this.handlers.get(type) || []; this.handlers.set(type, current.filter(x => x.id !== id)); };
  }
  async publish(type, payload = {}, meta = {}) {
    if (this.closed) throw new Error('EventBus is closed');
    const event = Object.freeze({ id: meta.id || crypto.randomUUID(), type: String(type), at: meta.at || new Date().toISOString(), version: meta.version || 1, correlationId: meta.correlationId || null, payload });
    this.history.push({ id: event.id, type: event.type, at: event.at }); if (this.history.length > this.maxHistory) this.history.splice(0, this.history.length - this.maxHistory);
    this.emit('event', event);
    const jobs = (this.handlers.get(event.type) || []).map(entry => this.#enqueue(entry, event));
    const results = await Promise.allSettled(jobs);
    results.forEach((r, i) => { if (r.status === 'rejected') this.logger('event-handler-error', { type, handler: (this.handlers.get(type) || [])[i]?.id, error: r.reason?.message || String(r.reason) }); });
    return { eventId: event.id, handlers: results.length, failed: results.filter(x => x.status === 'rejected').length };
  }
  #enqueue(entry, event) {
    return new Promise((resolve, reject) => {
      entry.queue.push({ event, resolve, reject }); this.#drain(entry);
    });
  }
  #drain(entry) {
    while (entry.active < entry.concurrency && entry.queue.length) {
      const job = entry.queue.shift(); entry.active++;
      Promise.resolve().then(() => entry.handler(job.event)).then(job.resolve, job.reject).finally(() => { entry.active--; this.#drain(entry); });
    }
  }
  stats() { let queued = 0, active = 0; for (const list of this.handlers.values()) for (const h of list) { queued += h.queue.length; active += h.active; } return { types: this.handlers.size, queued, active, history: this.history.length, closed: this.closed }; }
  close() { this.closed = true; this.removeAllListeners(); this.handlers.clear(); }
}
module.exports = { EventBus };
