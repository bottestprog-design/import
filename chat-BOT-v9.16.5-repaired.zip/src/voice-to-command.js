"use strict";
const { normalizeDictionaryText } = require('./dictionary-engine');
const PHRASES = [
  { intent: 'mute', patterns: [/^(?:اكتم|كتم|اسكت اشعارات|كتم الاشعارات)\s*(.*)$/u, /^(?:mute)\s*(.*)$/i] },
  { intent: 'unmute', patterns: [/^(?:الغاء الكتم|فك الكتم|الغ الكتم)\s*(.*)$/u, /^(?:unmute)\s*(.*)$/i] },
  { intent: 'archive', patterns: [/^(?:ارشف|ارشفة)\s*(.*)$/u, /^(?:archive)\s*(.*)$/i] },
  { intent: 'delete-message', patterns: [/^(?:احذف|حذف)\s+(?:ال)?رسالة(?:\s+(.*))?$/u, /^(?:delete message)(?:\s+(.*))?$/i] },
  { intent: 'help', patterns: [/^(?:مساعدة|الاوامر|ساعدني|help)$/u, /^help$/i] },
  { intent: 'status', patterns: [/^(?:الحالة|حالة النظام|حالة الاتصال|status)$/u, /^status$/i] },
];
function parseVoiceCommand(transcript, { locale = 'ar', confidence = 1, minConfidence = .72 } = {}) {
  const raw = String(transcript || '').trim().slice(0, 1000); if (!raw) return { accepted: false, reason: 'empty' };
  if (Number(confidence) < minConfidence) return { accepted: false, reason: 'low-confidence', transcript: raw, confidence: Number(confidence) };
  const text = normalizeDictionaryText(raw).replace(/[،.!؟?]+$/u, '').trim();
  for (const item of PHRASES) for (const pattern of item.patterns) { const m = text.match(pattern); if (m) return { accepted: true, intent: item.intent, targetText: String(m[1] || '').trim(), transcript: raw, normalized: text, locale, confidence: Number(confidence), requiresConfirmation: ['delete-message', 'delete-chat'].includes(item.intent) }; }
  return { accepted: false, reason: 'unrecognized', transcript: raw, normalized: text, locale, confidence: Number(confidence) };
}
module.exports = { parseVoiceCommand };
