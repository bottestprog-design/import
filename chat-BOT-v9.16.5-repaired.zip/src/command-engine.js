"use strict";
const { randomUUID } = require('node:crypto');
const DEFAULT_PREFIXES = ['!', '/'];
class CommandEngine {
  constructor({ prefixes = DEFAULT_PREFIXES, ownerOnlyByDefault = true, audit = () => {} } = {}) { this.prefixes = prefixes; this.ownerOnlyByDefault = ownerOnlyByDefault; this.audit = audit; this.commands = new Map(); }
  register(name, definition) {
    const key = String(name || '').trim().toLowerCase();
    if (!/^[\p{L}\p{N}_-]{1,48}$/u.test(key)) throw new Error('Invalid command name');
    if (typeof definition?.handler !== 'function') throw new TypeError('Command handler required');
    this.commands.set(key, { name: key, description: String(definition.description || ''), ownerOnly: definition.ownerOnly ?? this.ownerOnlyByDefault, permission: definition.permission || null, schema: definition.schema || null, handler: definition.handler, enabled: definition.enabled !== false });
    return () => this.commands.delete(key);
  }
  parse(input) {
    const text = String(input || '').trim(); if (!text) return null;
    const prefix = this.prefixes.find(p => text.startsWith(p)); if (!prefix) return null;
    const body = text.slice(prefix.length).trim(); if (!body) return null;
    const match = body.match(/^([^\s]+)(?:\s+([\s\S]*))?$/u); if (!match) return null;
    return { id: randomUUID(), prefix, name: match[1].toLocaleLowerCase(), rawArgs: match[2] || '', args: (match[2] || '').match(/(?:"([^"]*)"|'([^']*)'|(\S+))/g)?.map(x => x.replace(/^(?:"(.*)"|'(.*)'|(.*))$/u, (_, a, b, c) => a ?? b ?? c)) || [], input: text };
  }
  async execute(input, context = {}) {
    const parsed = typeof input === 'string' ? this.parse(input) : input;
    if (!parsed) return { handled: false, reason: 'not-command' };
    const cmd = this.commands.get(parsed.name);
    if (!cmd || !cmd.enabled) return { handled: false, reason: 'unknown-command', parsed };
    if (cmd.ownerOnly && context.isOwner !== true) return { handled: true, ok: false, error: 'owner-only' };
    if (cmd.permission && context.permissions?.includes(cmd.permission) !== true) return { handled: true, ok: false, error: 'permission-denied' };
    if (cmd.schema && !cmd.schema(parsed.args, context)) return { handled: true, ok: false, error: 'invalid-arguments' };
    try { const result = await cmd.handler({ ...context, command: parsed, args: parsed.args, rawArgs: parsed.rawArgs }); this.audit({ command: parsed.name, actor: context.actorId || null, ok: true }); return { handled: true, ok: true, result }; }
    catch (error) { this.audit({ command: parsed.name, actor: context.actorId || null, ok: false, error: error.message }); return { handled: true, ok: false, error: error.message }; }
  }
  list() { return [...this.commands.values()].map(({ handler, schema, ...x }) => x); }
}
module.exports = { CommandEngine };
