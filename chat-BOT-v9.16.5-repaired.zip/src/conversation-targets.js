'use strict';

function digits(value) { return String(value || '').replace(/\D/g, ''); }
function chatIdOf(value) {
  if (!value) return '';
  if (typeof value === 'string') return value.trim().toLowerCase();
  return String(value._serialized || value.$1 || value.serialized || value.id?._serialized || value.id?.$1 || value.id || '').trim().toLowerCase();
}
function targetKeyForChat(session, rawChatId, selfChatId = '') {
  const chatId = chatIdOf(rawChatId), self = chatIdOf(selfChatId);
  if (!chatId) return '';
  if (self && (chatId === self || (chatId.endsWith('@c.us') && self.endsWith('@c.us') && digits(chatId) === digits(self)))) return 'self';
  const group = (session.groups || []).find(item => chatIdOf(item.gid) === chatId || chatIdOf(item.chatId) === chatId);
  if (group) return `g:${String(group.id)}`;
  const recipient = (session.recipients || []).find(item => {
    const ids = [item.whatsappJid, item.chatId, item.jid].map(chatIdOf).filter(Boolean);
    if (ids.includes(chatId)) return true;
    if (!chatId.endsWith('@c.us')) return false;
    const number = digits(chatId);
    if (number.length < 5) return false;
    return [item.e164, item.phone, item.digits, item.number, item.international].some(value => digits(value) === number);
  });
  return recipient ? `r:${String(recipient.id)}` : '';
}
function allowedTarget(session, key, selfChatId = '') {
  const wanted = String(key || '').trim();
  if (wanted === 'self') return { key: 'self', label: 'محادثة البوت معك', type: 'self', id: '', chatId: chatIdOf(selfChatId), registered: true };
  if (wanted.startsWith('r:')) {
    const id = wanted.slice(2), person = (session.recipients || []).find(item => String(item.id) === id);
    if (!person) return null;
    const jid = chatIdOf(person.whatsappJid || person.chatId || person.jid);
    const number = digits(person.e164 || person.phone || person.digits || person.number || person.international);
    const chatId = /^(?:\d{5,25}@c\.us|\d{5,25}@lid)$/i.test(jid) ? jid : (number.length >= 5 ? `${number}@c.us` : '');
    return { key: wanted, id, label: String(person.name || person.international || person.phone || 'شخص بدون اسم').slice(0, 160), type: 'recipient', chatId, enabled: person.enabled !== false, person };
  }
  if (wanted.startsWith('g:')) {
    const id = wanted.slice(2), group = (session.groups || []).find(item => String(item.id) === id);
    if (!group) return null;
    const chatId = chatIdOf(group.gid || group.chatId);
    return { key: wanted, id, label: String(group.name || group.gid || 'مجموعة').slice(0, 160), type: 'group', chatId: /^\d+(?:-\d+)*@g\.us$/i.test(chatId) ? chatId : '', enabled: group.enabled !== false, group };
  }
  return null;
}
function listRegisteredTargets(session, selfChatId = '') {
  const rows = [{ key: 'self', id: '', label: 'محادثة البوت معك', type: 'self', chatId: chatIdOf(selfChatId), enabled: true, registered: true }];
  for (const person of session.recipients || []) rows.push(allowedTarget(session, `r:${person.id}`, selfChatId));
  for (const group of session.groups || []) rows.push(allowedTarget(session, `g:${group.id}`, selfChatId));
  return rows.filter(Boolean);
}
function registeredChatFromList(session, chat, selfChatId = '') {
  const chatId = chatIdOf(chat?.id || chat?.chatId);
  const key = targetKeyForChat(session, chatId, selfChatId);
  if (!key) return null;
  const target = allowedTarget(session, key, selfChatId);
  if (!target) return null;
  return { ...target, chatId, name: String(chat?.name || chat?.formattedTitle || target.label).slice(0, 160), isGroup: Boolean(chat?.isGroup || target.type === 'group') };
}
module.exports = { digits, chatIdOf, targetKeyForChat, allowedTarget, listRegisteredTargets, registeredChatFromList };
