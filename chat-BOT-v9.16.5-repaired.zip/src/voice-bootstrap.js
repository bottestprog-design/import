'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { spawn: nodeSpawn } = require('node:child_process');
const ENV_KEYS = new Set(['WHISPER_BACKEND','WHISPER_CPP_BIN','WHISPER_MODEL_PATH','PIPER_BIN','PIPER_MODEL_PATH','FFMPEG_BIN','TTS_REQUIRE_PROOFREAD']);
let task = null;
let current = { state: 'idle', startedAt: null, finishedAt: null, transcriptionReady: false, speechReady: false, message: 'لم يبدأ فحص محركات الصوت بعد.' };
function snapshot() { return { ...current }; }
function emit(logger, level, message) { try { if (typeof logger === 'function') logger(null, level, String(message || '').slice(0, 500)); } catch {} }
function syncLocalEnvironment(root, env = process.env) {
  try {
    const text = fs.readFileSync(path.join(root, '.env'), 'utf8').replace(/^\uFEFF/, '');
    for (const line of text.split(/\r?\n/)) {
      const match = line.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);
      if (!match || !ENV_KEYS.has(match[1])) continue;
      let value = match[2];
      if (value.length >= 2 && ((value[0] === '"' && value[value.length - 1] === '"') || (value[0] === "'" && value[value.length - 1] === "'"))) value = value.slice(1, -1);
      if (value) env[match[1]] = value.replace(/\\"/g, '"');
    }
  } catch {}
}
function runPowerShell(scriptPath, { root, logger, spawnImpl = nodeSpawn, env = process.env } = {}) {
  return new Promise((resolve, reject) => {
    let child, stderr = '', settled = false;
    const finish = (error, result) => { if (settled) return; settled = true; error ? reject(error) : resolve(result); };
    try {
      child = spawnImpl('powershell.exe', ['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',scriptPath], {
        cwd: root, windowsHide: true, stdio: ['ignore','pipe','pipe'], env: { ...env, CHAT_BOT_VOICE_SETUP_NONINTERACTIVE: '1' }
      });
    } catch (error) { finish(error); return; }
    const consume = (chunk, level) => {
      for (const row of String(chunk || '').split(/\r?\n/).map(x => x.trim()).filter(Boolean).slice(-20))
        emit(logger, level === 'WARN' || /error|failed|exception|فشل|تعذر|خطأ/i.test(row) ? 'WARN' : 'INFO', 'إعداد الصوت: ' + row);
    };
    child.stdout?.on('data', chunk => consume(chunk, 'INFO'));
    child.stderr?.on('data', chunk => { stderr = (stderr + String(chunk || '')).slice(-6000); consume(chunk, 'WARN'); });
    child.once('error', error => finish(new Error('تعذر تشغيل إعداد الصوت المحلي: ' + String(error?.message || error).slice(0, 300))));
    child.once('close', code => code === 0 ? finish(null, { ok: true, script: path.basename(scriptPath) }) : finish(new Error(path.basename(scriptPath) + ' انتهى برمز ' + code + (stderr ? ': ' + stderr.slice(-1200) : ''))));
  });
}
async function check(service) { try { return await service.status(); } catch (error) { return { ready: false, message: String(error?.message || error) }; } }
async function startVoiceBootstrap({ root, audioTranscriber, textToSpeech, logger = () => {}, platform = process.platform, spawnImpl = nodeSpawn, env = process.env } = {}) {
  if (task) return task;
  if (platform !== 'win32') {
    current = { state: 'unsupported', startedAt: null, finishedAt: new Date().toISOString(), transcriptionReady: false, speechReady: false, message: 'الإعداد التلقائي للمحركات الصوتية مفعّل حاليًا على Windows. لم تتغير إعدادات النظام.' };
    return snapshot();
  }
  if (String(env.CHAT_BOT_AUTO_VOICE_SETUP || '1').trim() === '0') {
    current = { state: 'disabled', startedAt: null, finishedAt: new Date().toISOString(), transcriptionReady: false, speechReady: false, message: 'الإعداد الصوتي التلقائي متوقف من إعدادات التشغيل.' };
    return snapshot();
  }
  task = (async () => {
    current = { state: 'checking', startedAt: new Date().toISOString(), finishedAt: null, transcriptionReady: false, speechReady: false, message: 'يفحص البوت محركات الصوت المحلية.' };
    let trans = await check(audioTranscriber), speech = await check(textToSpeech);
    current.transcriptionReady = Boolean(trans.ready); current.speechReady = Boolean(speech.ready);
    if (trans.ready && speech.ready) {
      current.state = 'ready'; current.finishedAt = new Date().toISOString(); current.message = 'محركات التفريغ والنطق المحلي جاهزة.';
      return snapshot();
    }
    emit(logger, 'INFO', 'يبدأ إعداد الصوت المحلي تلقائيًا؛ لا حاجة إلى فتح ملفات إعداد يدويًا. يتطلب التشغيل الأول إنترنت ومساحة تخزين كافية لتنزيل المحركات والنماذج.');
    const scripts = [];
    if (!trans.ready) scripts.push({ name: 'setup-whisper.ps1', title: 'تفريغ الصوت إلى نص' });
    if (!speech.ready) scripts.push({ name: 'setup-tts.ps1', title: 'إنتاج الرسائل الصوتية' });
    const errors = [];
    for (const item of scripts) {
      const script = path.join(root, 'scripts', item.name);
      try {
        if (!fs.existsSync(script)) throw new Error('ملف الإعداد غير موجود داخل الحزمة.');
        emit(logger, 'INFO', 'يجري إعداد ' + item.title + ' محليًا.');
        await runPowerShell(script, { root, logger, spawnImpl, env });
        syncLocalEnvironment(root, env);
      } catch (error) {
        errors.push(item.title + ': ' + String(error?.message || error).slice(0, 500));
        emit(logger, 'WARN', 'لم يكتمل إعداد ' + item.title + ': ' + String(error?.message || error).slice(0, 600));
      }
      trans = await check(audioTranscriber); speech = await check(textToSpeech);
      current.transcriptionReady = Boolean(trans.ready); current.speechReady = Boolean(speech.ready);
    }
    current.finishedAt = new Date().toISOString();
    if (current.transcriptionReady && current.speechReady) {
      current.state = 'ready'; current.message = 'تم تجهيز محركات الصوت المحلية بنجاح.'; emit(logger, 'INFO', current.message);
    } else {
      current.state = current.transcriptionReady || current.speechReady ? 'partial' : 'failed';
      const notes = [];
      if (!current.transcriptionReady) notes.push('التفريغ: ' + String(trans.message || 'غير جاهز'));
      if (!current.speechReady) notes.push('إنتاج الصوت: ' + String(speech.message || 'غير جاهز'));
      if (errors.length) notes.push(errors.join(' | '));
      current.message = 'لم تكتمل كل مكونات الصوت تلقائيًا. ستظل الوظائف الأخرى متاحة. ' + notes.join('؛ ');
      emit(logger, 'WARN', current.message);
    }
    return snapshot();
  })().catch(error => {
    current = { ...current, state: 'failed', finishedAt: new Date().toISOString(), message: 'تعذر إكمال الإعداد الصوتي: ' + String(error?.message || error).slice(0, 500) };
    emit(logger, 'ERROR', current.message); return snapshot();
  });
  return task;
}
function getVoiceBootstrapStatus() { return snapshot(); }
module.exports = { startVoiceBootstrap, getVoiceBootstrapStatus, syncLocalEnvironment, runPowerShell };
