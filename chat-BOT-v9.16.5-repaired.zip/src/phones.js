"use strict";
const { parsePhoneNumberFromString, getCountries, getCountryCallingCode } = require('libphonenumber-js');

function arabicDigits(value) {
  return String(value ?? '')
    .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))
    .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - 0x06f0));
}
function cleanDigits(value) {
  return arabicDigits(value).replace(/[^\d+]/g, '').replace(/(?!^)\+/g, '');
}
function parse(input, country = 'OM') {
  const raw = cleanDigits(input);
  if (!raw) throw new Error('اكتب رقم الهاتف.');
  const cc = String(country || 'OM').toUpperCase();
  const normalized = raw.startsWith('00') ? `+${raw.slice(2)}` : raw;
  let p = parsePhoneNumberFromString(normalized, cc);
  if (!p && normalized.startsWith('+')) p = parsePhoneNumberFromString(normalized);
  if (!p || !p.isValid()) throw new Error('رقم الهاتف غير صالح. استخدم رمز الدولة أو اختر الدولة الصحيحة.');
  const out = {
    digits: p.number.replace(/\D/g, ''),
    country: p.country || cc,
    callingCode: String(p.countryCallingCode || ''),
    international: p.formatInternational(),
    formatted: p.formatInternational(),
    national: p.formatNational(),
    e164: p.number,
  };
  return out;
}
function tryParse(input, country = 'OM') { try { return { ok: true, ...parse(input, country) }; } catch (e) { return { ok: false, error: e.message }; } }
function countries() { return getCountries().map(code => ({ code, callingCode: String(getCountryCallingCode(code)), label: `+${getCountryCallingCode(code)} · ${code}` })).sort((a, b) => a.label.localeCompare(b.label)); }
function parseMany(lines, defaultCountry = 'OM') {
  const out = [], failed = [], values = Array.isArray(lines) ? lines : String(lines || '').split(/\r?\n/);
  for (let i = 0; i < Math.min(500, values.length); i++) {
    const line = arabicDigits(String(values[i] || '').trim());
    if (!line) continue;
    const parts = line.includes('|') ? line.split('|') : line.split(/\s*[,؛]\s*/, 2);
    const name = String(parts.length > 1 ? parts[0] : `رقم ${i + 1}`).trim().slice(0, 80);
    const phone = String(parts.length > 1 ? parts.slice(1).join('|') : parts[0]).trim();
    try { out.push({ name, ...parse(phone, defaultCountry) }); }
    catch (e) { failed.push({ line: i + 1, value: line, error: e.message }); }
  }
  return { out, failed };
}
module.exports = { parse, tryParse, countries, parseMany, cleanDigits, arabicDigits };
