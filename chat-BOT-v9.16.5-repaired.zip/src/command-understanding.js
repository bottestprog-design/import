'use strict';

const { similarityScore, normalizeArabic, compact } = require('./trigger-engine');

const FILLER_WORDS = new Set(['انا','عايز','عاوز','عاوزه','ممكن','لو','سمحت','من','فضلك','يا','بوت','اريد','عايزه','عايزك','محتاج','محتاجه','please','can','you','i','want','to','the','me']);
function normalizeCommand(value) {
  return compact(String(value || '')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[إأآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
    .replace(/[\u200e\u200f\u202a-\u202e]/g, '')
    .replace(/اتومات(?:ك|يك|يكي)?|اوتومات(?:ك|يك|يكي)?|اوتوماتيكي|اتوماتيكي/gu, 'تلقائي')
    .replace(/جروبات|جروب|جرووب/gu, 'مجموعات')
    .replace(/واتس(?:اب)?|واتساب/gu, 'واتساب')
    .replace(/الفويسات|فويسات|فويس|فويس نوت/gu, 'صوتية'));
}
function comparisonText(value) {
  return normalizeCommand(value).split(' ').filter(Boolean).filter(word => !FILLER_WORDS.has(word)).join(' ');
}
function tokenSimilarity(a, b) {
  const left = comparisonText(a).split(' ').filter(Boolean);
  const right = comparisonText(b).split(' ').filter(Boolean);
  if (!left.length || !right.length) return 0;
  const used = new Set(); let matched = 0;
  for (const token of left) {
    let bestIndex = -1, bestScore = 0;
    for (let i = 0; i < right.length; i++) {
      if (used.has(i)) continue;
      const score = similarityScore(token, right[i]);
      if (score > bestScore) { bestScore = score; bestIndex = i; }
    }
    if (bestIndex >= 0 && bestScore >= 0.64) { used.add(bestIndex); matched += bestScore; }
  }
  const precision = matched / Math.max(1, left.length);
  const recall = matched / Math.max(1, right.length);
  return precision + recall ? (2 * precision * recall) / (precision + recall) : 0;
}
function commandScore(text, alias) {
  const raw = normalizeCommand(text), target = normalizeCommand(alias);
  const compactScore = similarityScore(raw, target);
  const reducedScore = similarityScore(comparisonText(raw), comparisonText(target));
  const tokensScore = tokenSimilarity(raw, target);
  return Math.max(compactScore, reducedScore * 0.98, tokensScore * 0.92);
}

const COMMANDS = [
  { intent: 'help', aliases: ['مساعدة', 'الاوامر', 'دليل الاستخدام', 'ساعدني', 'help', 'اوامر البوت', 'اعمل ايه', 'مش فاهم استخدمه ازاي', 'ازاي استخدم البوت', 'وريني كل الاوامر', 'ابدأ منين'] },
  { intent: 'status', aliases: ['الحالة', 'حالة الاتصال', 'حالة النظام', 'هل البوت متصل', 'status', 'وريني حالة البوت', 'طمني الاتصال عامل ايه', 'هل واتساب شغال', 'اتأكد انك متصل'] },
  { intent: 'settings-status', aliases: ['حالة الاعدادات', 'اعرض اعدادات البوت', 'ايه الاعدادات الشغالة', 'ما هي الاعدادات المفعلة', 'وريني كل اعدادات التشغيل', 'ايه اللي شغال حاليا', 'الردود شغالة ولا لا', 'ليه البوت مش بيرد', 'ليه الرد التلقائي واقف', 'شخص حالة التفاعل'] },
  { intent: 'list-people', aliases: ['اعرض الاشخاص', 'قائمة الاشخاص', 'جهات الاتصال المحفوظة', 'المستلمين', 'وريني الناس اللي عندي'] },
  { intent: 'list-groups', aliases: ['اعرض المجموعات', 'قائمة المجموعات', 'الجروبات المحفوظة'] },
  { intent: 'list-tasks', aliases: ['اعرض المواعيد', 'قائمة المواعيد', 'جدول الرسائل'] },
  { intent: 'list-rules', aliases: ['اعرض قواعد التفاعل', 'قائمة الردود التلقائية', 'قواعد الرد التلقائي'] },
  { intent: 'list-media', aliases: ['اعرض الوسائط', 'قائمة الملفات', 'الملفات المرفوعة', 'معرض الصور'] },
  { intent: 'list-chats', aliases: ['قائمة المحادثات', 'اعرض المحادثات', 'المحادثات المتاحة', 'هات الشاتات', 'اعرض الدردشات'] },
  { intent: 'capabilities', aliases: ['ماذا تستطيع', 'تقدر تعمل ايه', 'ايه اللي تقدر تعمله', 'كيف تساعدني', 'امكانيات البوت', 'ما الذي يمكنك فعله', 'what can you do'] },
  { intent: 'list-activity', aliases: ['اعرض سجل النشاط', 'اخر العمليات', 'ماذا حدث مؤخرا', 'اعرض الاحداث الاخيرة', 'سجل التنفيذ', 'ايه اخر حاجه حصلت', 'وريني اخر الاخطاء', 'اعرف اخر اللي حصل', 'ايه اللي حصل مؤخرا'] },
  { intent: 'list-stats', aliases: ['ملخص النظام', 'احصائيات البوت', 'عدد العمليات', 'كم رسالة ارسلت', 'ملخص النشاط', 'تقرير سريع عن النظام', 'ملخص سريع', 'البوت عامل ايه'] },
  { intent: 'list-active-rules', aliases: ['اعرض القواعد المفعلة', 'الردود الشغالة', 'ما هي قواعد الرد النشطة', 'القواعد النشطة', 'ايه الردود اللي شغالة', 'وريني القواعد الشغالة', 'الردود المفعلة'] },
  { intent: 'list-counters', aliases: ['اعرض العدادات', 'عدادات الرسائل', 'قواعد العد', 'كم عدد الرسائل لكل محادثة'] },
  { intent: 'test-reply', aliases: ['اختبر الرد التلقائي', 'اختبر قاعدة الرد', 'جرب قواعد الرد', 'حاكي الرد على رسالة', 'اختبر نص الرسالة', 'جرب قاعدة السلام عليكم', 'هل الرسالة دي هترد عليها قاعدة', 'جرب الرد على النص ده'] },
  { intent: 'clear-chat-memory', aliases: ['امسح ذاكرة المحادثة', 'امسح ذاكرة الشات', 'احذف سجل محادثتي مع البوت', 'امسح تاريخ المحادثة المحلية'] },
  { intent: 'add-person', aliases: ['اضف شخص جديد', 'اضافة شخص', 'عايز اضيف شخص', 'سجل جهة اتصال', 'اضف رقم جديد', 'عايز اسجل حد', 'ضيف كونتاكت', 'ضيف شخص عندي'] },
  { intent: 'send-message', aliases: ['ارسل رسالة', 'ابعت رسالة', 'ابعث رسالة', 'عايز ابعت رسالة', 'ارسل رسالة لشخص', 'ابعت لحد رسالة', 'عايز ابعت مسج'] },
  { intent: 'create-schedule', aliases: ['انشئ موعد', 'اضف موعد', 'جدول رسالة', 'اعمل تذكير', 'رسالة مجدولة'] },
  { intent: 'create-rule', aliases: ['انشئ رد تلقائي', 'اضف قاعدة تفاعل', 'اعمل رد تلقائي', 'انشئ قاعدة رد', 'عايز اعمل رد اتوماتك', 'اعمل رد اتوماتيك', 'رد تلقائي جديد'] },
  { intent: 'sync-contacts', aliases: ['استدعاء جهات واتساب', 'مزامنة جهات واتساب', 'اسحب جهات الاتصال من واتساب', 'زامن الاسماء والصور', 'هات ارقام الواتس', 'جيب اصحاب واتساب'] },
  { intent: 'download-media', aliases: ['استخرج الملفات من محادثة', 'نزل المرفقات من محادثة', 'حمل الصور من الشات', 'احفظ مرفقات المحادثة', 'نزل كل ملفات شات', 'جيب صور محادثة'] },
  { intent: 'transcribe-latest', aliases: ['فرغ اخر صوتية', 'حول الفويس الى نص', 'اكتب الصوتية كتابة', 'انسخ الكلام من التسجيل', 'عايز اعرف الصوت بيقول ايه', 'اكتب الكلام اللي في الفويس', 'اسمع اخر فويس واكتب اللي فيه', 'استخرج الكلام من التسجيل', 'حول الرسالة الصوتية لنص مكتوب'] },
  { intent: 'interaction-on', aliases: ['فعل التفاعل', 'شغل الرد التلقائي', 'فعل الردود التلقائية', 'شغل البوت للرد على الناس', 'خلي البوت يرد على الناس', 'ابدأ الرد على الرسائل الواردة', 'رجع الردود التلقائية'] },
  { intent: 'interaction-off', aliases: ['اوقف التفاعل', 'عطل الرد التلقائي', 'اوقف الردود التلقائية', 'لا ترد على الرسائل'] },
  { intent: 'quiet-on', aliases: ['فعل عدم الازعاج', 'شغل وضع الهدوء', 'اوقف الردود وقت الهدوء'] },
  { intent: 'quiet-off', aliases: ['اوقف عدم الازعاج', 'الغ وضع الهدوء', 'اسمح بالرد في كل الاوقات'] },
  { intent: 'smart-reply-on', aliases: ['فعل الذكاء المحلي', 'شغل الرد الذكي', 'استخدم نموذج الذكاء المحلي'] },
  { intent: 'smart-reply-off', aliases: ['اوقف الذكاء المحلي', 'عطل الرد الذكي', 'اوقف نموذج الذكاء'] },
  { intent: 'voice-on', aliases: ['فعل فهم الصوتيات', 'شغل تفريغ الصوت التلقائي', 'حول الفويسات الى نص تلقائيا', 'استمع للفويس واكتب اللي فيه', 'شغل فهم الرسائل الصوتية'] },
  { intent: 'voice-off', aliases: ['اوقف فهم الصوتيات', 'عطل تفريغ الصوت التلقائي'] },
  { intent: 'fallback-on', aliases: ['فعل الرد الاحتياطي', 'شغل الرد عند عدم وجود قاعدة'] },
  { intent: 'fallback-off', aliases: ['اوقف الرد الاحتياطي', 'عطل الرد عند عدم وجود قاعدة'] },
  { intent: 'group-fallback-on', aliases: ['اسمح بالرد الذكي في المجموعات', 'فعل الرد الاحتياطي داخل الجروبات'] },
  { intent: 'group-fallback-off', aliases: ['اوقف الرد الذكي في المجموعات', 'عطل الرد الاحتياطي داخل الجروبات'] },
  { intent: 'group-assistant-on', aliases: ['شغل مساعد المجموعات', 'فعل اوامر تحليل المجموعات', 'شغل تحليل المجموعات'] },
  { intent: 'group-assistant-off', aliases: ['اوقف مساعد المجموعات', 'عطل اوامر تحليل المجموعات', 'اوقف تحليل المجموعات'] },
];

function cueIntent(text) {
  const t = normalizeCommand(text);
  const has = (re) => re.test(t);
  if (has(/(?:طمني|اتأكد|تاكد).*(?:الاتصال|واتساب)|هل واتساب شغال/u)) return 'status';
  if (has(/(?:وريني|اعرض).*(?:كل اعدادات التشغيل|اعدادات البوت)|ليه البوت مش بيرد|ليه الرد التلقائي واقف|الردود شغاله ولا لا/u)) return 'settings-status';
  if (has(/(?:ايه اخر حاجه حصلت|ايه اللي حصل مؤخرا|اعرف اخر اللي حصل|وريني اخر الاخطاء)/u)) return 'list-activity';
  if (has(/(?:ايه الردود اللي شغاله|وريني القواعد الشغاله|الردود المفعله)/u)) return 'list-active-rules';
  if (has(/(?:اسمع|فرغ|افرغ|اكتب|استخرج|حول).*(?:فويس|صوتيه|تسجيل).*(?:اكتب|نص|الكلام|اللي فيه)/u)) return 'transcribe-latest';
  if (has(/خلي البوت (?:يرد|يستجيب)|ابدأ الرد على الرسائل الوارده/u)) return 'interaction-on';
  if (has(/(?:تقدر تعمل ايه|ايه اللي تقدر تعمله|ماذا تستطيع|امكانيات البوت|كيف تساعدني|what can you do)/u)) return 'capabilities';
  if (has(/(?:اختبر|جرب|حاكي).*(?:الرد التلقائي|قواعد الرد|قاعده الرد|نص الرساله|رساله تجريبيه)/u)) return 'test-reply';
  if (has(/(?:امسح|احذف|افرغ).*(?:ذاكره المحادثه|ذاكره الشات|تاريخ المحادثه المحليه)/u)) return 'clear-chat-memory';
  if (has(/(?:سجل النشاط|اخر العمليات|الاحداث الاخيره|سجل التنفيذ|ماذا حدث مؤخرا)/u)) return 'list-activity';
  if (has(/(?:احصائيات|ملخص النظام|عدد العمليات|ملخص النشاط|كم رساله ارسلت)/u)) return 'list-stats';
  if (has(/(?:القواعد النشطه|القواعد المفعله|الردود الشغاله)/u)) return 'list-active-rules';
  if (has(/(?:اعرض العدادات|عدادات الرسائل|قواعد العد)/u)) return 'list-counters';
  // Prioritize explicit setting toggles before broad task verbs.
  if (has(/(?:عدم الازعاج|وضع الهدوء|فتره الهدوء)/u) && has(/(?:فعل|شغل|تشغيل|استخدم|خلي|خله|enable)/u)) return 'quiet-on';
  if (has(/(?:عدم الازعاج|وضع الهدوء|فتره الهدوء)/u) && has(/(?:اوقف|عطل|الغ|الغاء|وقف|disable)/u)) return 'quiet-off';
  if (has(/(?:الذكاء المحلي|الرد الذكي|ollama)/u) && has(/(?:فعل|تفعيل|شغل|تشغيل|enable|استخدم)/u)) return 'smart-reply-on';
  if (has(/(?:الذكاء المحلي|الرد الذكي|ollama)/u) && has(/(?:اوقف|عطل|الغ|وقف|disable)/u)) return 'smart-reply-off';
  if (has(/(?:الصوتيات|الفويسات|الصوت|التفريغ الصوتي|whisper)/u) && has(/(?:فعل|تفعيل|شغل|تشغيل|enable|تلقائي)/u)) return 'voice-on';
  if (has(/(?:الصوتيات|الفويسات|الصوت|التفريغ الصوتي|whisper)/u) && has(/(?:اوقف|عطل|الغ|وقف|disable)/u)) return 'voice-off';
  // Group fallback is a separate setting; classify it before generic fallback phrases.
  if (has(/(?:مجموعات|جروبات|الجروبات|الجروب)/u) && has(/(?:الرد الذكي|الرد الاحتياطي|الرد عند عدم وجود قاعده|الرد بدون قاعده|يرد)/u) && has(/(?:فعل|شغل|تشغيل|اسمح|خلي|enable)/u)) return 'group-fallback-on';
  if (has(/(?:مجموعات|جروبات|الجروبات|الجروب)/u) && has(/(?:الرد الذكي|الرد الاحتياطي|الرد عند عدم وجود قاعده|الرد بدون قاعده|يرد)/u) && has(/(?:اوقف|عطل|امنع|الغ|وقف|disable)/u)) return 'group-fallback-off';
  if (has(/(?:عدم وجود قاعده|الرد الاحتياطي|fallback)/u) && has(/(?:فعل|شغل|تشغيل|enable)/u)) return 'fallback-on';
  if (has(/(?:عدم وجود قاعده|الرد الاحتياطي|fallback)/u) && has(/(?:اوقف|عطل|الغ|disable)/u)) return 'fallback-off';
  if (has(/(?:الرد التلقائي|التفاعل|الردود التلقائيه|البوت للرد)/u) && has(/(?:اوقف|عطل|وقف|لا ترد|disable)/u)) return 'interaction-off';
  if (has(/(?:الرد التلقائي|التفاعل|الردود التلقائيه|البوت للرد|الرسائل الوارده)/u) && has(/(?:فعل|تفعيل|شغل|تشغيل|enable|خلي.*شغال|خلي.*يرد|رجع)/u)) {
    if (has(/(?:انشئ|اضف|عمل|اعمل|سوي).*(?:قاعده|رد تلقائي)/u)) return 'create-rule';
    return 'interaction-on';
  }
  if (has(/(?:مجموعات|جروبات|الجروبات|الجروب)/u) && has(/(?:مساعد|تحليل|او أامر|اوامر|gid)/u) && has(/(?:اوقف|عطل|امنع|وقف|disable)/u)) return 'group-assistant-off';
  if (has(/(?:مجموعات|جروبات|الجروبات|الجروب)/u) && has(/(?:مساعد|تحليل|اوامر|gid)/u) && has(/(?:فعل|شغل|تشغيل|اسمح|خلي|enable)/u)) return 'group-assistant-on';
  if (has(/(?:حاله|وضع|اعدادات).*(?:الاعدادات|الرد|التفاعل|الصوت|الذكاء)/u) || has(/(?:ليه|لماذا|ازاي).*(?:البوت|الرد|الردود).*(?:بيرد|يشتغل|واقف|مش شغال|متوقف)/u)) return 'settings-status';
  if (has(/(?:استدع|زامن|مزامن|اسحب|هات).*(?:جهات|اسماء|ارقام|اصحاب|كونتاكت).*(?:واتساب|واتس|whatsapp)?/u)) return 'sync-contacts';
  if (has(/(?:فرغ|افرغ|حول|اكتب|انسخ|فهم).*(?:اخر )?(?:صوت|فويس|تسجيل|الفويس|audio|voice)/u) || has(/(?:صوتيه|فويس|تسجيل).*(?:نص|كتابه|تفريغ|كلام)/u)) return 'transcribe-latest';
  if (has(/(?:استخرج|نزل|حمل|اسحب|احفظ).*(?:ملفات|مرفقات|صور|فيديو|وسائط).*(?:محادثه|شات|دردشه|محادثات)?/u)) return 'download-media';
  if (has(/(?:اضف|ضيف|سجل|ادخل).*(?:شخص|مستخدم|رقم|جهة اتصال)/u) || has(/(?:شخص|جهة اتصال).*(?:جديد|اضافه|اضيف)/u)) return 'add-person';
  if (has(/(?:موعد|جدوله|رساله مجدوله|تذكير)/u) && has(/(?:انشئ|انشاء|اضف|اعمل|سوي|جدول|حدد|رتب)/u)) return 'create-schedule';
  if (has(/(?:قاعدة تفاعل|قاعده تفاعل|رد تلقائي|قاعدة رد)/u) && has(/(?:انشئ|انشاء|اضف|اعمل|سوي|ضيف)/u)) return 'create-rule';
  if (has(/(?:ارسل|ابعت|ابعث|بعت|ارسلي|ابعثلي).*(?:رساله|لاح|ل |الي|الى|شخص|مجموعه)/u) || has(/(?:رساله|رسالة).*(?:لاح|الي|الى|لشخص)/u)) return 'send-message';
  if (has(/(?:قائمه|اعرض|اظهر|وريني|هات|ايه عندك).*(?:الاشخاص|الناس|المستلمين|جهات الاتصال)/u)) return 'list-people';
  if (has(/(?:قائمه|اعرض|اظهر|وريني|هات).*(?:المجموعات|الجروبات)/u)) return 'list-groups';
  if (has(/(?:قائمه|اعرض|اظهر|وريني|هات).*(?:المواعيد|الجدول|المهام المجدوله)/u)) return 'list-tasks';
  if (has(/(?:قائمه|اعرض|اظهر|وريني|هات).*(?:قواعد التفاعل|الردود التلقائيه|قواعد الرد)/u)) return 'list-rules';
  if (has(/(?:قائمه|اعرض|اظهر|وريني|هات).*(?:الوسائط|الملفات المرفوعه|الصور المرفوعه)/u)) return 'list-media';
  if (has(/(?:قائمه|اعرض|اظهر|وريني|هات).*(?:المحادثات|الشاتات|الدردشات)/u)) return 'list-chats';
  if (has(/(?:مساعده|ساعدني|دليل|الاوامر|مش فاهم|ازاي استخدم)/u)) return 'help';
  if (has(/(?:حاله الاتصال|حاله النظام|هل البوت متصل|هل الواتساب متصل|وضع الاتصال)/u)) return 'status';
  return null;
}

function classifyCommand(value) {
  const text = String(value || '').trim();
  const normalized = normalizeCommand(text);
  if (!normalized) return { intent: null, confidence: 0, alternatives: [] };
  const direct = cueIntent(text);
  // Common shorthand spellings can normalize into a valid command while still
  // being ambiguous in natural conversation. Keep the intent as a suggestion so
  // the owner assistant asks for confirmation instead of skipping straight into
  // a settings wizard. This is especially important for creating auto-replies.
  const ambiguousSurface = /(?:اتوماتك|اوتوماتك|رد\s*اتماتك)/u.test(String(text || '').replace(/[\u064B-\u065F\u0670\u0640]/g, ''));
  if (direct && !ambiguousSurface) return { intent: direct, confidence: 0.96, alternatives: [], normalized };

  const candidates = COMMANDS.map(command => ({
    intent: command.intent,
    confidence: Math.max(...command.aliases.map(alias => commandScore(normalized, alias)), 0),
    alias: command.aliases.find(alias => commandScore(normalized, alias) >= 0.64) || '',
  })).sort((a, b) => b.confidence - a.confidence);
  const best = candidates[0], second = candidates[1];
  if (ambiguousSurface) {
    const intended = direct || best?.intent;
    const selected = candidates.find(item => item.intent === intended) || best;
    const alternatives = [selected, ...candidates.filter(item => item.intent !== selected?.intent)]
      .filter(item => item && item.confidence >= 0.52).slice(0, 3)
      .map(item => ({ intent: item.intent, confidence: Math.max(item.confidence, item.intent === intended ? 0.68 : 0), alias: item.alias }));
    return { intent: null, confidence: selected?.confidence || 0, alternatives, normalized };
  }
  if (best && best.confidence >= 0.74) {
    const ambiguous = second && second.confidence >= 0.74 && best.confidence - second.confidence < 0.055;
    return {
      intent: ambiguous ? null : best.intent,
      confidence: best.confidence,
      alternatives: (ambiguous ? [best, second] : candidates.slice(0, 2).filter(x => x.confidence >= 0.52)).map(x => ({ intent: x.intent, confidence: x.confidence, alias: x.alias })),
      normalized,
    };
  }
  return { intent: null, confidence: best?.confidence || 0, alternatives: candidates.slice(0, 3).filter(x => x.confidence >= 0.44).map(x => ({ intent: x.intent, confidence: x.confidence, alias: x.alias })), normalized };
}

const STRUCTURED_HEADS = [
  { canonical: 'أضف شخص', aliases: ['اضف شخص', 'اضف مستخدم', 'اضف جهة اتصال', 'add recipient'] },
  { canonical: 'أرسل الآن', aliases: ['ارسل الان', 'ارسال الان', 'send now', 'add send'] },
  { canonical: 'أضف موعد', aliases: ['اضف موعد', 'انشئ موعد', 'انشاء موعد', 'add schedule'] },
  { canonical: 'أضف قاعدة تفاعل', aliases: ['اضف قاعدة تفاعل', 'انشئ رد تلقائي', 'اضف رد تلقائي', 'add interaction rule'] },
  { canonical: 'معلومات المجموعة', aliases: ['معلومات المجموعة', 'حلل معلومات المجموعة', 'group info'] },
  { canonical: 'حلل رابط دعوة', aliases: ['حلل رابط دعوة', 'حلل دعوة', 'analyze invite'] },
  { canonical: 'مزامن ملفات WhatsApp', aliases: ['مزامن ملفات واتساب', 'مزامنة ملفات واتساب', 'زامن ملفات واتساب', 'زامن ملف واتساب', 'sync whatsapp contacts'] },
  { canonical: 'اضبط المنطقة الزمنية', aliases: ['اضبط المنطقة الزمنية', 'اضبط المنطقة', 'set timezone'] },
];
function correctStructuredHead(value) {
  const text = normalizeCommand(value);
  if (!text || text.length < 5) return null;
  const matches = STRUCTURED_HEADS.map(item => ({ canonical: item.canonical, confidence: Math.max(...item.aliases.map(alias => commandScore(text, alias))) }))
    .sort((a, b) => b.confidence - a.confidence);
  if (matches[0]?.confidence >= 0.70 && (!matches[1] || matches[0].confidence - matches[1].confidence >= 0.035)) return matches[0];
  return null;
}

module.exports = { normalizeCommand, classifyCommand, correctStructuredHead, COMMANDS };
