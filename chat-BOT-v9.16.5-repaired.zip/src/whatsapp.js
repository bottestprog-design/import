"use strict";
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
function patchUtilsForWhatsApp() {
  // Use the shared, syntax-checked compatibility patcher and verify the media-ID fix.
  const result = require('./compat').patch();
  if (!result.ok) throw new Error((result.notes || []).join(' | ') || 'تعذر إصلاح مكتبة WhatsApp بأمان.');
  try {
    const root = path.dirname(require.resolve('whatsapp-web.js/package.json'));
    const utilsPath = path.join(root, 'src', 'util', 'Injected', 'Utils.js');
    if (fs.existsSync(utilsPath)) {
      const source = fs.readFileSync(utilsPath, 'utf8');
      const begin = source.indexOf('window.WWebJS.sendMessage = async');
      const finish = source.indexOf('window.WWebJS.editMessage = async', begin);
      const sendFunction = begin >= 0 ? source.slice(begin, finish >= 0 ? finish : undefined) : '';
      if (begin < 0 || (!/delete\s+message\.__x_id\s*;/.test(sendFunction) && !/delete\s+mediaOptions\.__x_id\s*;/.test(sendFunction))) {
        throw new Error('لم يثبت فحص توافق إرسال الوسائط داخل whatsapp-web.js؛ أوقف التشغيل لمنع فشل المرفقات بصمت.');
      }
    }
  } catch (error) {
    if (/لم يثبت فحص توافق/.test(String(error?.message || error))) throw error;
    // The package may be mocked by tests before dependencies are installed.
    if (process.env.NODE_ENV !== 'test') throw error;
  }
  return result;
}
const patchResult = patchUtilsForWhatsApp();
process.env.PUPPETEER_CACHE_DIR = process.env.PUPPETEER_CACHE_DIR || path.join(path.resolve(__dirname, '..'), '.cache', 'puppeteer');
const browserMarker = path.join(path.resolve(__dirname, '..'), '.browser-path');
function configuredBrowser() {
  for (const value of [process.env.PUPPETEER_EXECUTABLE_PATH, process.env.CHROME_PATH]) {
    try { if (value && fs.existsSync(value) && fs.statSync(value).isFile()) return value; } catch {}
  }
  return '';
}
function detectSystemBrowser() {
  const candidates = [];
  if (process.platform === 'win32') {
    const roots = [process.env.LOCALAPPDATA, process.env.PROGRAMFILES, process.env['PROGRAMFILES(X86)']].filter(Boolean);
    for (const root of roots) {
      candidates.push(path.join(root, 'Google', 'Chrome', 'Application', 'chrome.exe'));
      candidates.push(path.join(root, 'Microsoft', 'Edge', 'Application', 'msedge.exe'));
      candidates.push(path.join(root, 'Chromium', 'Application', 'chrome.exe'));
    }
  } else if (process.platform === 'linux') {
    candidates.push('/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser');
  } else if (process.platform === 'darwin') {
    candidates.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/msedge', '/Applications/Chromium.app/Contents/MacOS/Chromium');
  }
  for (const candidate of candidates) {
    try { if (candidate && fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate; } catch {}
  }
  return '';
}
function detectPuppeteerBrowser() {
  try {
    const executable = require('puppeteer').executablePath();
    if (executable && fs.existsSync(executable) && fs.statSync(executable).isFile()) return executable;
  } catch {}
  return '';
}
let detectedChrome = configuredBrowser();
if (!detectedChrome) {
  try { const marked = fs.readFileSync(browserMarker, 'utf8').trim(); if (marked && fs.existsSync(marked) && fs.statSync(marked).isFile()) detectedChrome = marked; } catch {}
}
// Prefer the browser installed alongside the pinned Puppeteer version. System Chrome
// auto-updates independently and can invalidate a LocalAuth profile's cached state.
if (!detectedChrome) detectedChrome = detectPuppeteerBrowser() || detectSystemBrowser();
if (detectedChrome) {
  try {
    const oldMarker = fs.existsSync(browserMarker) ? fs.readFileSync(browserMarker, 'utf8').trim() : '';
    if (oldMarker !== detectedChrome) fs.writeFileSync(browserMarker, detectedChrome, 'utf8');
  } catch {}
}
const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const QRCode = require('qrcode');
const EventEmitter = require('node:events');
const { isFromMeMessage } = require('./message-identifiers');

const { toUserFacingError, rawError } = require('./whatsapp-errors');
function safeError(e) { return rawError(e); }
function withTimeout(promise, ms, label) {
  let timer;
  const timeout = new Promise((_, reject) => { timer = setTimeout(() => reject(Object.assign(new Error(`${label || 'العملية'} تجاوزت المهلة.`), { code: 'SEND_TIMEOUT' })), Math.max(1000, Number(ms) || 30000)); timer.unref?.(); });
  return Promise.race([Promise.resolve(promise), timeout]).finally(() => clearTimeout(timer));
}
function idSerialized(id) {
  if (!id) return '';
  if (typeof id === 'string') return id;
  if (id._serialized) return String(id._serialized);
  if (id.$1) return String(id.$1);
  if (id.remote) return idSerialized(id.remote);
  return id.id !== undefined ? String(id.id) : '';
}
function chatIdFromMessage(msg) {
  // id.remote is the chat address for both incoming and outgoing messages.
  // For outgoing messages, `from` may be our own account, not the destination.
  // Match WhatsApp's serialized outgoing-ID fallback here too. Otherwise a
  // LID self-chat can be misread as an incoming chat when fromMe isn't exposed.
  const fromMe = isFromMeMessage(msg);
  const candidates = [msg?.id?.remote, msg?._data?.id?.remote, msg?.msgId?.remote, msg?._data?.chatId, msg?.chatId, fromMe ? msg?.to : msg?.from, msg?.from, msg?.to, msg?.id?._serialized, msg?.id?.$1];
  for (const value of candidates) { const id = idSerialized(value).trim().toLowerCase(); if (id.endsWith('@g.us') || id.endsWith('@c.us') || id.endsWith('@lid')) return id; }
  return '';
}
function groupFromMessage(msg) { const id = chatIdFromMessage(msg); return id.endsWith('@g.us') ? id : null; }
function ackIsDelivered(ack) { return Number(ack) >= 2; }
const MAX_CONTEXT_RECOVERY_ATTEMPTS = 3;
const CONTEXT_RECOVERY_DELAYS_MS = [1800, 4000, 8000];
function isContextNavigationError(error) {
  return /execution context was destroyed|cannot find context with specified id|context\s+destroyed.*navigation|most likely because of a navigation|target closed|session closed/i.test(safeError(error));
}
function navigationRecoveryPlan(error, previousAttempts = 0) {
  const attempts = Math.max(0, Math.floor(Number(previousAttempts) || 0));
  if (!isContextNavigationError(error) || attempts >= MAX_CONTEXT_RECOVERY_ATTEMPTS) return null;
  return { attempt: attempts + 1, maxAttempts: MAX_CONTEXT_RECOVERY_ATTEMPTS, delayMs: CONTEXT_RECOVERY_DELAYS_MS[Math.min(attempts, CONTEXT_RECOVERY_DELAYS_MS.length - 1)] };
}

function normalizePairingPhoneNumber(value) {
  const digitMap = { '٠':'0','١':'1','٢':'2','٣':'3','٤':'4','٥':'5','٦':'6','٧':'7','٨':'8','٩':'9','۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9' };
  let raw = String(value || '').trim().replace(/[٠-٩۰-۹]/g, ch => digitMap[ch] || ch);
  if (!raw) throw new Error('اكتب رقم WhatsApp بالصيغة الدولية، مثل +96891234567.');
  if (raw.startsWith('00')) raw = `+${raw.slice(2)}`;
  if (!raw.startsWith('+') || !/^\+[0-9\s().-]+$/.test(raw)) throw new Error('ابدأ رقم الربط بعلامة + ورمز الدولة، أو استخدم 00 بدل +. لا تكتب الرقم المحلي وحده.');
  let parsed = null;
  try { parsed = require('libphonenumber-js').parsePhoneNumberFromString(raw); } catch {}
  if (parsed) {
    if (!parsed.isValid() || !parsed.countryCallingCode || !parsed.number || !/^\+[1-9][0-9]{7,14}$/.test(parsed.number)) {
      throw new Error('رقم الربط غير صالح حسب خطة الترقيم الدولية. راجع رمز الدولة والرقم ثم أعد المحاولة.');
    }
    return parsed.number.slice(1);
  }
  // Dependency-free strict fallback for test environments before `npm ci`; production uses libphonenumber-js above.
  const digits = raw.replace(/\D/g, '');
  if (digits.length < 8 || digits.length > 15 || digits.startsWith('0') || digits[0] === '0') throw new Error('رقم الربط يجب أن يكون دوليًا صحيح البنية من 8 إلى 15 رقمًا بعد رمز الدولة.');
  return digits;
}
function browserProfileConflictError(error) {
  const message = safeError(error);
  if (!/browser is already running|user data directory is already in use|process singleton.*lock|singletonlock/i.test(message)) return error;
  return Object.assign(new Error('ملف جلسة WhatsApp مستخدم بالفعل بواسطة متصفح أو نسخة أخرى من chat BOT. أوقف النسخة القديمة من البرنامج أو أغلق Chromium الذي يستخدم ملف هذه الجلسة، ثم أعد المحاولة. لم تُحذف بيانات الربط.'), { code: 'BROWSER_PROFILE_IN_USE', originalError: error });
}

class WhatsAppManager extends EventEmitter {
  constructor({ store, log }) { super(); this.store = store; this.log = log; this.clients = new Map(); this.pending = new Map(); this.outgoingIntents = new Map(); this.programmaticMessages = new Map(); }
  entry(id) {
    const sid = this.store.safeSessionId(id);
    if (!this.clients.has(sid)) this.clients.set(sid, { client: null, status: 'idle', ready: false, qr: null, qrRevision: 0, qrUpdatedAt: null, browser: '', info: null, lastAck: null, lastSent: null, lastError: '', starting: null, liveGroups: new Map(), stopping: false, reconnectTimer: null, reconnects: 0, navigationRetries: 0, generation: 0, readyProbe: null, connectedAt: null, connectionStartedAt: null, qrWaitWarning: '', qrWaitTimer: null, navigationProfileReset: false, profileRecoveryNotice: '', selfChatOverride: '', connectionMethod: 'auto', pairingPhoneDigits: '', pairingCode: '', pairingCodeIssuedAt: null, pairingCodeExpiresAt: null, pairingCodeTimer: null, cleanupPromise: null });
    return this.clients.get(sid);
  }
  clearPairingCode(e) {
    if (!e) return;
    clearTimeout(e.pairingCodeTimer); e.pairingCodeTimer = null;
    e.pairingCode = ''; e.pairingCodeIssuedAt = null; e.pairingCodeExpiresAt = null;
  }
  selfChatId(id) {
    const e = this.entry(id);
    if (e.selfChatOverride) return String(e.selfChatOverride).toLowerCase();
    const wid = e.info?.wid || e.client?.info?.wid || e.info?.me || e.client?.info?.me;
    let value = idSerialized(wid).toLowerCase();
    if (!value && wid?.user) value = `${String(wid.user)}@c.us`.toLowerCase();
    return value;
  }
  async isSelfChatMessage(id, msg) {
    const fromMe = isFromMeMessage(msg);
    if (!fromMe) return false;
    const self = this.selfChatId(id);
    let chat = null;
    try { if (typeof msg.getChat === 'function') chat = await withTimeout(msg.getChat(), 6000, 'تحديد المحادثة'); } catch {}
    let actual = idSerialized(chat?.id || msg?.id?.remote || msg?.to || msg?._data?.id?.remote || msg?._data?.to).toLowerCase();
    const acceptSelfChat = () => { if (actual) this.entry(id).selfChatOverride = actual; return true; };
    if (!actual && typeof msg.getContact === 'function') {
      try { const contact = await withTimeout(msg.getContact(), 4000, 'تحديد جهة الاتصال'); if (contact?.isMe === true || contact?.id?.isMe === true) return acceptSelfChat(); } catch {}
    }
    if (actual && self && actual === self) return acceptSelfChat();
    const digits = value => String(value || '').replace(/@(?:c\.us|lid)$/i, '').replace(/[^0-9]/g, '');
    if (actual && self && actual.endsWith('@c.us') && self.endsWith('@c.us') && digits(actual) && digits(actual) === digits(self)) return acceptSelfChat();

    // WhatsApp moved some self-chat destinations to LID identifiers. A LID cannot
    // be compared numerically with the account's @c.us ID. Use explicit model flags
    // first, then a conservative self-title match; never treat every outgoing LID
    // message as a self-chat, since that would answer messages sent to other people.
    const contact = chat?.contact || msg?._data?.contact || null;
    if (chat?.isMe === true || chat?.isSelf === true || chat?.isSelfChat === true || chat?.id?.isMe === true || contact?.isMe === true || contact?.id?.isMe === true) return acceptSelfChat();
    const ownInfo = this.entry(id).info || this.entry(id).client?.info || {};
    const ownNames = [ownInfo.pushname, ownInfo.name, ownInfo.me?.pushname, ownInfo.me?.name, ownInfo.wid?.pushname].map(v => String(v || '').trim().toLocaleLowerCase()).filter(Boolean);
    const chatNames = [chat?.name, chat?.formattedTitle, chat?.contact?.pushname, chat?.contact?.name, msg?._data?.notifyName].map(v => String(v || '').trim().toLocaleLowerCase()).filter(Boolean);
    const selfTitles = new Set(['you', 'you (me)', 'yourself', 'أنت', 'انت', 'أنت (أنت)', 'أنت (نفسك)', 'محادثتك مع نفسك', 'رسالة لنفسك']);
    if (chatNames.some(name => selfTitles.has(name) || ownNames.includes(name))) return acceptSelfChat();
    if (actual && /@lid$/i.test(actual)) this.log?.(id, 'DEBUG', `تم تجاهل رسالة صادرة ذات معرّف LID لعدم وجود دليل كافٍ أنها محادثة النفس (chat=${actual}).`);
    return false;
  }
  outboundIntentKey(sid, chatId) { return `${this.store.safeSessionId(sid)}|${String(chatId || '').toLowerCase()}`; }
  trackOutgoingIntent(sid, chatId, text, label = '') {
    const key = this.outboundIntentKey(sid, chatId), item = { token: `${Date.now()}-${Math.random().toString(36).slice(2)}`, at: Date.now(), text: String(text || '').trim(), expectsMedia: /وسائط|ملف|صورة|مرفق|صوت/i.test(String(label || '')) };
    const list = this.outgoingIntents.get(key) || []; list.push(item); this.outgoingIntents.set(key, list.slice(-30)); return { key, token:item.token };
  }
  removeOutgoingIntent(ref) {
    if (!ref?.key) return;
    const list = this.outgoingIntents.get(ref.key) || [], next = list.filter(item => item.token !== ref.token);
    if (next.length) this.outgoingIntents.set(ref.key, next); else this.outgoingIntents.delete(ref.key);
  }
  rememberProgrammaticMessage(sid, msgOrId) {
    const id = idSerialized(msgOrId?.id || msgOrId?.messageId || msgOrId);
    if (!id) return;
    const now = Date.now(); this.programmaticMessages.set(`${this.store.safeSessionId(sid)}|${id}`, now + 120000);
    if (this.programmaticMessages.size > 5000) for (const [key, expires] of this.programmaticMessages) if (expires < now) this.programmaticMessages.delete(key);
  }
  consumeProgrammaticOutgoing(sid, msg) {
    const session = this.store.safeSessionId(sid), msgId = idSerialized(msg?.id || msg?._data?.id);
    if (msgId) {
      const expires = this.programmaticMessages.get(`${session}|${msgId}`);
      if (expires && expires >= Date.now()) { this.programmaticMessages.delete(`${session}|${msgId}`); return true; }
    }
    const chatId = chatIdFromMessage(msg).toLowerCase();
    if (!chatId) return false;
    const key = this.outboundIntentKey(session, chatId), now = Date.now(), list = this.outgoingIntents.get(key) || [];
    const fresh = list.filter(item => now - item.at < 8000);
    const body = String(msg?.body || msg?.caption || '').trim();
    const isMedia = Boolean(msg?.hasMedia || msg?._data?.mimetype || ['image','video','audio','document','sticker'].includes(String(msg?.type || '').toLowerCase()));
    const index = fresh.findIndex(item => item.text ? (body === item.text || body.includes(item.text.slice(0, Math.min(24, item.text.length)))) : item.expectsMedia && isMedia);
    if (index < 0) { if (fresh.length) this.outgoingIntents.set(key, fresh); else this.outgoingIntents.delete(key); return false; }
    fresh.splice(index, 1); if (fresh.length) this.outgoingIntents.set(key, fresh); else this.outgoingIntents.delete(key);
    return true;
  }
  isProgrammaticOutgoing(sid, msg) {
    if (msg?.__chatBotProgrammatic === true || msg?._chatBotProgrammatic === true) return true;
    return this.consumeProgrammaticOutgoing(sid, msg);
  }
  hasSavedAuth(id) {
    const dir = this.store.getPaths(id).auth;
    try { return fs.existsSync(dir) && fs.readdirSync(dir, { withFileTypes: true }).some(x => x.isDirectory() || x.isFile()); } catch { return false; }
  }
  quarantineNavigationDamagedProfile(id, runtime) {
    const sid = this.store.safeSessionId(id);
    if (runtime.navigationProfileReset) return false;
    const paths = this.store.getPaths(sid);
    // whatsapp-web.js LocalAuth stores the active Chromium user-data directory here.
    // Preserve the old profile intact; never erase session files or the user's message data.
    const profile = path.join(paths.auth, `session-${sid}`);
    try {
      if (!fs.existsSync(profile) || !fs.statSync(profile).isDirectory()) return false;
      const backupRoot = path.join(paths.dir, 'auth-profile-backups');
      fs.mkdirSync(backupRoot, { recursive: true });
      const backup = path.join(backupRoot, `session-${sid}-${Date.now()}`);
      fs.renameSync(profile, backup);
      runtime.navigationProfileReset = true;
      runtime.profileRecoveryNotice = 'تكرر انهيار سياق Chromium. حفظ النظام ملف ربط المتصفح السابق احتياطيًا دون حذفه، ويبدأ الآن ملفًا جديدًا؛ امسح QR الجديد لإعادة الربط. بيانات الأشخاص والرسائل والإعدادات لم تُحذف.';
      runtime.lastError = runtime.profileRecoveryNotice;
      this.log(sid, 'WARN', runtime.profileRecoveryNotice);
      return true;
    } catch (error) {
      runtime.lastError = `تكرر انهيار Chromium ولم أستطع نقل ملف المتصفح احتياطيًا بأمان: ${safeError(error)}`.slice(0, 900);
      this.log(sid, 'ERROR', runtime.lastError);
      return false;
    }
  }
  emitStatus(id) { this.emit('status', id, this.listRuntime(id)); }
  clearReadyProbe(e) { if (e.readyProbe) { clearInterval(e.readyProbe); e.readyProbe = null; } }
  startReadyProbe(sid, client, generation) {
    const e = this.entry(sid); this.clearReadyProbe(e); let attempts = 0;
    e.readyProbe = setInterval(async () => {
      if (generation !== e.generation || e.stopping || e.ready) return this.clearReadyProbe(e);
      if (++attempts > 120) return this.clearReadyProbe(e);
      try { const state = typeof client.getState === 'function' ? await client.getState() : null; if (state === 'CONNECTED') this.markReady(sid, client, generation, 'state'); } catch {}
    }, 1000);
  }
  markReady(sid, client, generation, source = 'ready') {
    const e = this.entry(sid); if (generation !== e.generation || e.stopping) return;
    e.ready = true; e.status = 'ready'; e.qr = null; this.clearPairingCode(e); e.qrRevision++; e.lastError = ''; e.qrWaitWarning = ''; e.profileRecoveryNotice = ''; e.navigationProfileReset = false; clearTimeout(e.qrWaitTimer); e.qrWaitTimer = null; e.navigationRetries = 0; e.browser = 'Chromium/Puppeteer'; e.info = client.info || e.info; e.reconnects = 0; e.connectedAt ||= new Date().toISOString(); this.clearReadyProbe(e);
    this.log(sid, 'INFO', `جلسة WhatsApp جاهزة للإرسال والاستقبال (${source}).`); this.emitStatus(sid);
  }
  async destroyClientSafely(client, label = 'إيقاف متصفح WhatsApp', sid = 'main') {
    if (!client) return true;
    let destroyError = null;
    let child = null;
    try { child = client.pupBrowser?.process?.() || null; } catch {}
    try { await withTimeout(Promise.resolve(client.destroy()), 10000, label); }
    catch (error) { destroyError = error; }
    if (child && child.exitCode == null && child.signalCode == null) {
      await new Promise(resolve => {
        if (child.exitCode != null || child.signalCode != null) return resolve();
        const timer = setTimeout(resolve, destroyError ? 250 : 700);
        child.once('exit', () => { clearTimeout(timer); resolve(); });
      });
      if (child.exitCode == null && child.signalCode == null) {
        try { child.kill('SIGTERM'); } catch {}
        await new Promise(resolve => {
          if (child.exitCode != null || child.signalCode != null) return resolve();
          const timer = setTimeout(resolve, 1400);
          child.once('exit', () => { clearTimeout(timer); resolve(); });
        });
        if (child.exitCode == null && child.signalCode == null) {
          try { child.kill('SIGKILL'); } catch {}
          await new Promise(resolve => {
            if (child.exitCode != null || child.signalCode != null) return resolve();
            const timer = setTimeout(resolve, 1200);
            child.once('exit', () => { clearTimeout(timer); resolve(); });
          });
        }
      }
    }
    const stillAlive = !!child && child.exitCode == null && child.signalCode == null;
    if (destroyError && !stillAlive) this.log?.(sid, 'WARN', `${label}: أُغلق Chromium بعد خطأ الإغلاق الطبيعي: ${safeError(destroyError)}`);
    if (stillAlive) {
      this.log?.(sid, 'ERROR', `${label}: بقي Chromium مفتوحًا بعد محاولة الإغلاق؛ لن تبدأ إعادة الاتصال فوق ملف الجلسة نفسه.`);
      return false;
    }
    return true;
  }

  async recoverRuntimeNavigation(sid, client, generation, error) {
    const e = this.entry(sid);
    if (generation !== e.generation || e.stopping || e.status === 'recovering') return;
    const plan = navigationRecoveryPlan(error, e.navigationRetries);
    this.clearReadyProbe(e);
    // A broken Puppeteer initialize() promise can remain pending after its page has crashed.
    // Detach it before scheduling a replacement instance instead of waiting up to 180 seconds.
    e.starting = null;
    if (!plan) {
      ++e.generation; e.ready = false; e.qr = null; e.qrRevision++; e.status = 'error'; e.lastError = safeError(error).slice(0, 900);
      if (e.client === client) e.client = null;
      this.log(sid, 'ERROR', `فشل استرداد متصفح WhatsApp بعد ${e.navigationRetries} محاولات: ${e.lastError}`);
      this.emitStatus(sid);
      try { await this.destroyClientSafely(client, 'إيقاف متصفح WhatsApp المتعطل', sid); } catch {}
      return;
    }
    const recoveryGeneration = ++e.generation;
    e.navigationRetries = plan.attempt; e.client = null; e.ready = false; e.qr = null; e.qrRevision++;
    e.status = 'recovering'; e.lastError = safeError(error).slice(0, 900);
    clearTimeout(e.reconnectTimer); e.reconnectTimer = null;
    this.log(sid, 'WARN', `تعطل سياق Chromium خلال اتصال WhatsApp؛ إعادة التهيئة ${plan.attempt}/${plan.maxAttempts} بعد ${plan.delayMs}ms.`);
    this.emitStatus(sid);
    let destroyed = true;
    try { destroyed = await this.destroyClientSafely(client, 'إعادة ضبط متصفح WhatsApp', sid); }
    catch { destroyed = false; }
    if (e.generation !== recoveryGeneration || e.stopping) return;
    if (destroyed && plan.attempt >= 2 && this.quarantineNavigationDamagedProfile(sid, e)) e.navigationRetries = 0;
    e.status = 'recovering'; e.client = null; e.ready = false; this.emitStatus(sid);
    e.reconnectTimer = setTimeout(async () => {
      if (e.generation !== recoveryGeneration || e.stopping || e.client) return;
      try {
        if (e.starting) await e.starting.catch(() => {});
        if (e.generation === recoveryGeneration && !e.stopping && !e.client) await this.start(sid, { recovery: true });
      } catch (retryError) {
        const current = this.entry(sid);
        if (!current.stopping) { current.status = 'error'; current.ready = false; current.lastError = safeError(retryError).slice(0, 900); this.emitStatus(sid); }
        this.log(sid, 'ERROR', `فشلت محاولة استعادة اتصال WhatsApp: ${safeError(retryError)}`);
      }
    }, plan.delayMs);
  }
  async start(id, { recovery = false, method, phoneNumber } = {}) {
    const sid = this.store.safeSessionId(id), e = this.entry(sid);
    const methodWasProvided = method !== undefined && method !== null && String(method).trim() !== '';
    const requestedMethod = methodWasProvided ? String(method).trim().toLowerCase() : ((recovery || e.status === 'disconnected') ? (e.connectionMethod || 'auto') : 'auto');
    if (!['auto', 'qr', 'phone'].includes(requestedMethod)) throw new Error('طريقة الربط غير معروفة. اختر الاستعادة التلقائية أو QR أو رمز الهاتف.');
    const requestedPhone = requestedMethod === 'phone' ? normalizePairingPhoneNumber(phoneNumber || (recovery && e.pairingPhoneDigits ? `+${e.pairingPhoneDigits}` : '')) : '';
    if (e.stopping) throw new Error('يتم إيقاف جلسة WhatsApp الآن. انتظر قليلًا ثم أعد المحاولة.');
    if (e.ready && e.client) return this.listRuntime(sid);
    // A session already being authenticated cannot safely switch methods in-place.
    if (e.starting && e.client && ['starting', 'qr', 'pairing_code', 'authenticated'].includes(e.status)) {
      if (methodWasProvided && requestedMethod !== e.connectionMethod) throw new Error('هناك محاولة ربط نشطة. أوقف الجلسة أولًا قبل تغيير طريقة الربط.');
      return this.listRuntime(sid);
    }
    if (e.starting) return e.starting;
    if (e.status === 'recovering' && !recovery) return this.listRuntime(sid);
    if (e.client && ['starting', 'qr', 'pairing_code', 'authenticated'].includes(e.status)) {
      if (methodWasProvided && requestedMethod !== e.connectionMethod) throw new Error('هناك محاولة ربط نشطة. أوقف الجلسة أولًا قبل تغيير طريقة الربط.');
      return this.listRuntime(sid);
    }
    // Wait for cleanup from a previous disconnect before launching another Chromium on the same LocalAuth profile.
    if (e.cleanupPromise) {
      const pendingCleanup = e.cleanupPromise;
      const cleaned = await pendingCleanup.catch(() => false);
      if (e.cleanupPromise === pendingCleanup) e.cleanupPromise = null;
      if (!cleaned) throw new Error('تعذر إغلاق متصفح WhatsApp السابق بأمان؛ لن أفتح متصفحًا ثانيًا فوق ملف الجلسة نفسه. أغلق العملية القديمة ثم أعد التشغيل.');
    }
    clearTimeout(e.reconnectTimer); e.reconnectTimer = null;
    if (e.client) { const previous = e.client; e.client = null; const cleaned = await this.destroyClientSafely(previous, 'تنظيف جلسة WhatsApp السابقة', sid); if (!cleaned) throw new Error('ما زال متصفح الجلسة السابقة يعمل. أوقفه قبل إعادة الربط.'); }
    e.connectionMethod = requestedMethod;
    e.pairingPhoneDigits = requestedPhone;
    this.clearPairingCode(e);
    if (e.status === 'error' || e.status === 'auth_failure') { e.navigationRetries = 0; e.lastError = ''; }
    const generation = ++e.generation; e.status = 'starting'; e.qr = null; e.qrRevision++; e.ready = false; e.connectedAt = null; e.connectionStartedAt = new Date().toISOString(); e.qrUpdatedAt = null; e.qrWaitWarning = ''; e.lastError = '';
    clearTimeout(e.qrWaitTimer); e.qrWaitTimer = setTimeout(() => {
      if (generation !== e.generation || e.stopping || e.ready || e.status !== 'starting' || e.qrUpdatedAt) return;
      e.qrWaitWarning = 'لم يُصدر WhatsApp Web رمز QR بعد مرور 45 ثانية. افحص رسالة الخطأ وسجل الجلسة، وتأكد من السماح بفتح web.whatsapp.com وعدم حجب Chromium بواسطة الشبكة أو برنامج الحماية.';
      this.log(sid, 'WARN', e.qrWaitWarning); this.emitStatus(sid);
    }, 45000);
    e.qrWaitTimer.unref?.();
    this.emitStatus(sid);
    const startPromise = (async () => {
      const p = this.store.getPaths(sid); this.store.ensureDir?.(sid); fs.mkdirSync(p.auth, { recursive: true });
      // Keep desktop browser sandboxing intact. Linux servers running as root need no-sandbox;
      // avoid disabling browser networking/background tasks used by WhatsApp Web.
      const browserArgs = process.platform === 'linux'
        ? ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
        : [];
      const clientOptions = {
        authStrategy: new LocalAuth({ clientId: sid, dataPath: p.auth }),
        puppeteer: { headless: String(process.env.HEADLESS || 'true') !== 'false', executablePath: detectedChrome || undefined, args: browserArgs, timeout: 60000 },
        authTimeoutMs: 60000, takeoverOnConflict: false,
      };
      // whatsapp-web.js 1.34.7 supports this native option: it emits `code` instead of QR
      // for a new/unpaired profile. Existing LocalAuth sessions still restore without pairing.
      if (requestedMethod === 'phone') clientOptions.pairWithPhoneNumber = { phoneNumber: requestedPhone, showNotification: true, intervalMs: 180000 };
      const client = new Client(clientOptions);
      e.client = client;
      // Puppeteer may emit an asynchronous error after initialize() has resolved.
      client.on('error', error => {
        if (generation !== e.generation || e.stopping) return;
        e.lastError = safeError(error).slice(0, 900);
        this.log(sid, 'ERROR', `خطأ في متصفح WhatsApp: ${e.lastError}`);
        if (isContextNavigationError(error)) {
          this.recoverRuntimeNavigation(sid, client, generation, error).catch(recoveryError => {
            const current = this.entry(sid);
            if (!current.stopping) { current.status = 'error'; current.ready = false; current.lastError = safeError(recoveryError).slice(0, 900); this.emitStatus(sid); }
          });
        } else this.emitStatus(sid);
      });
      client.on('qr', qr => {
        if (generation !== e.generation || e.client !== client || e.stopping) return;
        if (typeof qr !== 'string' || !qr.trim()) {
          e.qr = null; e.status = 'error'; e.lastError = 'أصدر عميل WhatsApp حمولة QR فارغة؛ أوقف المحاولة وأعد الاتصال.';
          this.log(sid, 'ERROR', e.lastError); this.emitStatus(sid); return;
        }
        const revision = ++e.qrRevision;
        e.qr = null; this.clearPairingCode(e); e.qrUpdatedAt = new Date().toISOString(); e.status = 'qr'; e.qrWaitWarning = ''; e.lastError = '';
        clearTimeout(e.qrWaitTimer); e.qrWaitTimer = null;
        // Never expose the raw WhatsApp pairing payload as an img src. Publish only a PNG data URL.
        // Publish a pending status immediately, then push the finished image through the same status API.
        this.emitStatus(sid);
        Promise.resolve().then(() => QRCode.toDataURL(qr.trim(), { errorCorrectionLevel: 'H', margin: 2, width: 360, type: 'image/png' })).then(dataUrl => {
          if (generation !== e.generation || e.client !== client || e.stopping || revision !== e.qrRevision) return;
          if (typeof dataUrl !== 'string' || !/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(dataUrl)) throw new Error('لم ينتج محول QR صورة PNG صالحة.');
          e.qr = dataUrl; e.lastError = ''; this.emitStatus(sid);
        }).catch(error => {
          if (generation !== e.generation || e.client !== client || revision !== e.qrRevision) return;
          e.qr = null; e.status = 'error'; e.lastError = `وصل QR من WhatsApp لكن تعذر تحويله إلى صورة: ${safeError(error)}`.slice(0, 900);
          this.log(sid, 'ERROR', e.lastError); this.emitStatus(sid);
        });
      });
      client.on('code', code => {
        if (generation !== e.generation || e.client !== client || e.stopping) return;
        const normalizedCode = String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
        if (!/^[A-Z0-9]{8}$/.test(normalizedCode)) {
          this.clearPairingCode(e); e.status = 'error'; e.lastError = 'وصل رمز ربط غير متوقع التنسيق من مكتبة WhatsApp؛ لم يُعرض الرمز لحماية الربط. حدّث المكتبة أو استخدم QR.';
          clearTimeout(e.qrWaitTimer); e.qrWaitTimer = null; this.log(sid, 'ERROR', e.lastError); this.emitStatus(sid); return;
        }
        clearTimeout(e.qrWaitTimer); e.qrWaitTimer = null; e.qrWaitWarning = '';
        this.clearPairingCode(e);
        e.pairingCode = normalizedCode; e.pairingCodeIssuedAt = Date.now(); e.pairingCodeExpiresAt = e.pairingCodeIssuedAt + 180000;
        e.qr = null; e.qrRevision++; e.qrUpdatedAt = new Date(e.pairingCodeIssuedAt).toISOString(); e.status = 'pairing_code'; e.lastError = '';
        const issuedAt = e.pairingCodeIssuedAt;
        e.pairingCodeTimer = setTimeout(() => {
          if (generation !== e.generation || e.client !== client || e.stopping || e.pairingCodeIssuedAt !== issuedAt || e.ready) return;
          this.clearPairingCode(e); e.status = 'pairing_code_expired';
          e.lastError = 'انتهت مهلة عرض رمز الربط محليًا. اطلب رمزًا جديدًا أو انتظر رمزًا أحدث من WhatsApp.';
          this.log(sid, 'WARN', 'انتهت مهلة عرض رمز ربط الهاتف؛ لم يُسجل الرمز في السجل.');
          this.emitStatus(sid);
        }, 180000); e.pairingCodeTimer.unref?.();
        // This is a local display-safety timer; WhatsApp itself controls official code validity.
        // Pairing codes are credentials. Publish to local session status only; never log them.
        this.emitStatus(sid);
      });
      client.on('authenticated', () => { if (generation !== e.generation || e.stopping) return; clearTimeout(e.qrWaitTimer); e.qrWaitTimer = null; e.qrWaitWarning = ''; e.status = 'authenticated'; e.qr = null; this.clearPairingCode(e); e.qrRevision++; e.lastError = ''; this.startReadyProbe(sid, client, generation); this.emitStatus(sid); });
      client.on('ready', () => this.markReady(sid, client, generation, 'event'));
      client.on('change_state', state => { if (generation !== e.generation || e.stopping) return; if (state === 'CONNECTED' && !e.ready) this.startReadyProbe(sid, client, generation); });
      client.on('auth_failure', msg => {
        if (generation !== e.generation) return;
        e.ready = false; clearTimeout(e.qrWaitTimer); e.qrWaitTimer = null; e.qrWaitWarning = ''; e.status = 'auth_failure'; e.qr = null; this.clearPairingCode(e); e.qrRevision++; e.lastError = safeError(msg).slice(0, 900); this.clearReadyProbe(e);
        this.log(sid, 'ERROR', `فشل توثيق WhatsApp: ${e.lastError}`); this.emitStatus(sid);
      });
      client.on('disconnected', reason => {
        if (generation !== e.generation) return;
        // Invalidate callbacks from this browser immediately. initialize() can reject after
        // disconnected fires; that stale rejection must not overwrite a newer recovery attempt.
        const disconnectedGeneration = ++e.generation;
        e.ready = false; e.starting = null; clearTimeout(e.qrWaitTimer); e.qrWaitTimer = null; e.qrWaitWarning = ''; e.status = 'disconnected'; e.lastError = safeError(reason).slice(0, 900); if (e.client === client) e.client = null; e.qr = null; this.clearPairingCode(e); e.qrRevision++; this.clearReadyProbe(e);
        this.log(sid, 'WARN', `انفصلت جلسة WhatsApp: ${e.lastError}`); this.emitStatus(sid);
        // Critical: the previous version nulled `e.client` and started reconnecting without
        // awaiting Browser.close(). That can leave Chromium holding LocalAuth's profile lock.
        const cleanup = this.destroyClientSafely(client, 'تنظيف متصفح WhatsApp بعد الانفصال', sid).catch(error => {
          this.log(sid, 'ERROR', `تعذر تنظيف المتصفح بعد الانفصال: ${safeError(error)}`); return false;
        });
        e.cleanupPromise = cleanup;
        cleanup.then(cleaned => {
          if (e.cleanupPromise === cleanup) e.cleanupPromise = null;
          if (!cleaned && !e.stopping) {
            e.status = 'error'; e.lastError = 'انقطع WhatsApp لكن بقي متصفح Chromium السابق مفتوحًا. أغلق نسخة chat BOT القديمة قبل المحاولة مجددًا.'; this.emitStatus(sid); return;
          }
          if (e.generation === disconnectedGeneration && !e.stopping && !e.client && this.hasSavedAuth(sid) && e.reconnects < 4) {
            const wait = [2500, 5000, 10000, 20000][Math.min(e.reconnects, 3)]; e.reconnects++; clearTimeout(e.reconnectTimer);
            e.reconnectTimer = setTimeout(async () => {
              if (disconnectedGeneration !== e.generation || e.stopping || e.client) return;
              try { if (e.cleanupPromise) await e.cleanupPromise.catch(() => false); if (disconnectedGeneration === e.generation && !e.stopping && !e.client) await this.start(sid, { recovery: true }); }
              catch (err) { this.log(sid, 'ERROR', `فشل إعادة الاتصال: ${safeError(err)}`); }
            }, wait);
          }
        });
      });
      client.on('message', msg => {
        // Dispatch to reply/automation engines immediately. Group metadata can call
        // WhatsApp Web APIs and must never hold up regular incoming message handling.
        this.emit('message', sid, msg);
        const gid = groupFromMessage(msg);
        if (!gid) return;
        Promise.resolve().then(async () => {
          const rt = this.entry(sid); let info = { gid, name: gid };
          try { const chat = typeof msg.getChat === 'function' ? await withTimeout(msg.getChat(), 8000, 'قراءة محادثة المجموعة') : null; if (chat) info = await this.groupInfoFromChat(chat); }
          catch (error) { this.log(sid, 'DEBUG', `تأخر تحديث بيانات المجموعة ${gid}: ${safeError(error)}`); }
          if (generation === this.entry(sid).generation) rt.liveGroups.set(gid, info);
        }).catch(error => this.log(sid, 'DEBUG', `تأخر تحديث بيانات المجموعة ${gid}: ${safeError(error)}`));
      });
      client.on('message_ack', (msg, ack) => { e.lastAck = { at: new Date().toISOString(), id: idSerialized(msg?.id || msg), chatId: chatIdFromMessage(msg), ack, level: Number(ack) >= 4 ? 'read' : Number(ack) >= 3 ? 'delivered' : Number(ack) >= 2 ? 'server' : Number(ack) === 1 ? 'pending' : 'error' }; this.resolvePending('ack', sid, e.lastAck); this.emit('ack', sid, e.lastAck); });
      client.on('message_create', msg => {
        // Use the shared detector here too: some WhatsApp Web versions expose
        // outgoing self-chat messages only in the serialized ID (true_... / 1_...).
        // A narrower check here silently dropped those messages before the assistant
        // and command bridge ever saw them.
        const fromMe = isFromMeMessage(msg);
        if (!fromMe) return;
        if (this.consumeProgrammaticOutgoing(sid, msg)) msg.__chatBotProgrammatic = true;
        this.resolvePending('message', sid, msg); this.emit('message_create', sid, msg);
      });
      client.on('message_reaction', reaction => { this.emit('reaction', sid, { ...reaction, chatId: idSerialized(reaction?.chatId || reaction?.msgId?.remote || reaction?.id?.remote || reaction?.messageId?.remote || ''), emoji: String(reaction?.reaction || reaction?.emoji || reaction?.value || ''), msgId: reaction?.msgId || reaction?.messageId || reaction?.id || reaction?.message?.id || null, fromMe: !!reaction?.fromMe }); });
      await withTimeout(client.initialize(), 180000, 'تهيئة WhatsApp');
      return this.listRuntime(sid);
    })().catch(async err => {
      err = browserProfileConflictError(err);
      const recovery = generation === e.generation && !e.stopping ? navigationRecoveryPlan(err, e.navigationRetries) : null;
      if (recovery) {
        const recoveryGeneration = ++e.generation;
        const failedClient = e.client;
        e.navigationRetries = recovery.attempt; e.lastError = safeError(err).slice(0, 900); e.client = null; e.ready = false; e.qr = null; e.qrRevision++; e.status = 'recovering'; this.clearReadyProbe(e);
        this.log(sid, 'WARN', `تعطل متصفح WhatsApp أثناء الاتصال؛ إعادة التهيئة ${recovery.attempt}/${recovery.maxAttempts} بعد ${recovery.delayMs}ms.`); this.emitStatus(sid);
        let destroyed = !failedClient;
        if (failedClient) { try { destroyed = await this.destroyClientSafely(failedClient, 'تنظيف جلسة WhatsApp بعد خطأ التنقل', sid); } catch { destroyed = false; } }
        if (destroyed && recovery.attempt >= 2 && this.quarantineNavigationDamagedProfile(sid, e)) e.navigationRetries = 0;
        clearTimeout(e.reconnectTimer);
        e.reconnectTimer = setTimeout(async () => {
          if (e.generation !== recoveryGeneration || e.stopping || e.client) return;
          try { if (e.starting) await e.starting.catch(() => {}); if (e.generation === recoveryGeneration && !e.stopping && !e.client) await this.start(sid, { recovery: true }); }
          catch (retryError) { if (!e.stopping) { e.status = 'error'; e.lastError = safeError(retryError).slice(0, 900); this.emitStatus(sid); } }
        }, recovery.delayMs);
        return this.listRuntime(sid);
      }
      if (generation === e.generation) {
        const failedClient = e.client;
        ++e.generation; // invalidate late QR/disconnect events from the failed browser instance
        e.client = null; e.status = 'error'; e.ready = false; clearTimeout(e.qrWaitTimer); e.qrWaitTimer = null; e.qrWaitWarning = ''; e.qr = null; this.clearPairingCode(e); e.qrRevision++; e.lastError = safeError(err).slice(0, 900); this.clearReadyProbe(e);
        if (failedClient) { const cleaned = await this.destroyClientSafely(failedClient, 'إيقاف الجلسة بعد فشل التشغيل', sid); if (!cleaned) e.lastError += ' | بقي Chromium السابق مفتوحًا؛ أوقفه قبل إعادة المحاولة.'; }
        this.log(sid, 'ERROR', `فشل تشغيل الجلسة: ${e.lastError}`); this.emitStatus(sid);
      } else this.log(sid, 'WARN', `انتهت محاولة تشغيل قديمة بعد تغيير حالة الجلسة: ${safeError(err)}`);
      throw err;
    }).finally(() => { if (e.starting === startPromise) e.starting = null; });
    e.starting = startPromise;
    // Keep the initialization task observed, but never make the HTTP connect request wait for
    // Chromium navigation or QR generation. The client emits status changes while this runs.
    startPromise.catch(() => {});
    return this.listRuntime(sid);
  }
  async ensureReady(id, timeoutMs = 60000) {
    const sid = this.store.safeSessionId(id);
    let entry = this.entry(sid);
    if (entry.ready && entry.client) return entry.client;
    await this.start(sid);
    entry = this.entry(sid);
    if (entry.ready && entry.client) return entry.client;
    const notReadyError = runtime => {
      const state = runtime?.status || this.entry(sid).status || 'غير معروف';
      const detail = runtime?.lastError || this.entry(sid).lastError || '';
      const next = state === 'qr' ? 'امسح رمز QR من الهاتف أولًا، ثم أعد العملية.' : state === 'authenticated' ? 'تم التوثيق ويجري تجهيز الجلسة؛ أعد المحاولة بعد ظهور «متصل وجاهز».' : state === 'starting' ? 'ما زال المتصفح يفتح WhatsApp Web.' : 'افحص رسالة الخطأ وسجل الجلسة ثم أعد الاتصال.';
      return new Error(`جلسة WhatsApp ليست جاهزة للإرسال والاستقبال. الحالة: ${state}. ${next}${detail ? `
التفاصيل: ${detail}` : ''}`);
    };
    return new Promise((resolve, reject) => {
      let settled = false, timer;
      const finish = (error, client) => {
        if (settled) return;
        settled = true; clearTimeout(timer); this.off('status', onStatus);
        if (error) reject(error); else resolve(client);
      };
      const onStatus = (changedId, runtime) => {
        if (changedId !== sid) return;
        const current = this.entry(sid);
        if (runtime?.ready && current.client) return finish(null, current.client);
        // Once a real QR has arrived, stop waiting: a send operation must not sit open
        // until the user eventually scans the code.
        if (['qr', 'error', 'auth_failure', 'disconnected', 'stopped'].includes(runtime?.status)) return finish(notReadyError(runtime));
      };
      this.on('status', onStatus);
      timer = setTimeout(() => finish(notReadyError(this.listRuntime(sid))), Math.max(1000, Number(timeoutMs) || 60000));
      // Do not miss a ready/error event that happened just before the listener was attached.
      const current = this.entry(sid), runtime = this.listRuntime(sid);
      if (current.ready && current.client) return finish(null, current.client);
      if (['qr', 'error', 'auth_failure', 'disconnected', 'stopped'].includes(runtime.status)) return finish(notReadyError(runtime));
    });
  }
  async stop(id, { clearAuth = false } = {}) {
    const sid = this.store.safeSessionId(id), e = this.entry(sid);
    e.stopping = true; ++e.generation; ++e.qrRevision;
    clearTimeout(e.reconnectTimer); e.reconnectTimer = null; clearTimeout(e.qrWaitTimer); e.qrWaitTimer = null; e.qrWaitWarning = ''; this.clearReadyProbe(e);
    const obsoleteStart = e.starting; e.starting = null;
    const oldClient = e.client; e.client = null; e.ready = false; e.qr = null; this.clearPairingCode(e); e.status = 'stopping'; this.emitStatus(sid);
    if (oldClient) await this.destroyClientSafely(oldClient, 'إيقاف جلسة WhatsApp', sid);
    if (e.cleanupPromise) { const pendingCleanup = e.cleanupPromise; await pendingCleanup.catch(() => false); if (e.cleanupPromise === pendingCleanup) e.cleanupPromise = null; }
    if (obsoleteStart) await Promise.race([obsoleteStart.catch(() => {}), new Promise(resolve => setTimeout(resolve, 1200))]);
    if (clearAuth) { try { fs.rmSync(this.store.getPaths(sid).auth, { recursive: true, force: true }); } catch {} }
    e.stopping = false; e.reconnects = 0; e.client = null; e.ready = false; e.qr = null; this.clearPairingCode(e); e.lastError = ''; e.navigationRetries = 0; e.navigationProfileReset = false; e.status = 'stopped'; this.emitStatus(sid);
  }
  async stopAll(opts = {}) { for (const sid of this.clients.keys()) await this.stop(sid, opts); }
  listRuntime(id) { const e = this.entry(id); const digits = String(e.pairingPhoneDigits || ''); return { status: e.status, ready: e.ready, qr: e.qr, pairingCode: e.pairingCode || '', pairingCodeIssuedAt: e.pairingCodeIssuedAt || null, pairingCodeExpiresAt: e.pairingCodeExpiresAt || null, connectionMethod: e.connectionMethod || 'auto', pairingPhoneMasked: digits ? `${'*'.repeat(Math.max(0, digits.length - 4))}${digits.slice(-4)}` : '', qrUpdatedAt: e.qrUpdatedAt, connectionStartedAt: e.connectionStartedAt, qrWaitWarning: e.qrWaitWarning || '', profileRecoveryNotice: e.profileRecoveryNotice || '', browser: e.browser, info: e.info, lastError: e.lastError || '', lastAck: e.lastAck, lastSent: e.lastSent, reconnects: e.reconnects || 0, navigationRetries: e.navigationRetries || 0, connectedAt: e.connectedAt, liveGroups: [...e.liveGroups.values()] }; }
  waitForEvent(kind, sid, matcher, timeoutMs) {
    const key = `${sid}|${kind}`, list = this.pending.get(key) || [], match = typeof matcher === 'function' ? matcher : value => { const want = String(matcher || '').toLowerCase(); return !want || String(kind === 'ack' ? value?.chatId : chatIdFromMessage(value)).toLowerCase() === want; };
    this.pending.set(key, list); let done = false, timer, item;
    const promise = new Promise(resolve => { const finish = value => { if (done) return; done = true; clearTimeout(timer); const index = list.indexOf(item); if (index >= 0) list.splice(index, 1); if (!list.length) this.pending.delete(key); resolve(value); }; item = { match, resolve: finish }; timer = setTimeout(() => finish(null), Math.max(500, Number(timeoutMs) || 5000)); list.push(item); });
    promise.cancel = () => item?.resolve(null); return promise;
  }
  resolvePending(kind, sid, value) { const list = this.pending.get(`${sid}|${kind}`) || []; const item = list.find(x => { try { return x.match(value); } catch { return false; } }); if (item) item.resolve(value); }
  async sendConfirmed(sid, chatId, operation, timeoutMs, label, expectedText = '') {
    const normalizedChat = String(chatId || '').toLowerCase(), started = Date.now();
    const outboundIntent = this.trackOutgoingIntent(sid, normalizedChat, expectedText, label);
    const ackWait = this.waitForEvent('ack', sid, value => String(value?.chatId || '').toLowerCase() === normalizedChat && ackIsDelivered(value?.ack), 5000);
    const expectsMedia = /وسائط|ملف|صورة|مرفق|صوت/i.test(String(label || ''));
    const createdWait = this.waitForEvent('message', sid, msg => {
      if (String(chatIdFromMessage(msg)).toLowerCase() !== normalizedChat) return false;
      if (expectedText) { const body = String(msg?.body || '').trim(); return body === expectedText || body.includes(expectedText.slice(0, Math.min(30, expectedText.length))); }
      return expectsMedia && Boolean(msg?.hasMedia || msg?._data?.mimetype || ['image','video','audio','document','sticker'].includes(String(msg?.type || '').toLowerCase()));
    }, 5000);
    try {
      const result = await withTimeout(operation(), timeoutMs, label);
      if (!result) {
        const event = await Promise.race([ackWait, createdWait]);
        this.removeOutgoingIntent(outboundIntent);
        if (event) { const confirmed = event?.ack !== undefined && ackIsDelivered(event.ack); this.rememberProgrammaticMessage(sid, event); return { result: event, __chatBotAck: { status: confirmed ? 'confirmed' : 'created', mode: confirmed ? 'ack' : 'message_create', waitedMs: Date.now() - started } }; }
        throw Object.assign(new Error(`تم طلب ${label || 'الإرسال'} لكن لم يظهر تأكيد.`), { code: 'SEND_UNCERTAIN' });
      }
      const id = idSerialized(result?.id || result?.messageId || result);
      // Use the returned message ID for late message_create events; remove the text/media intent
      // immediately so the user's next manual self-chat message is not mistaken for bot output.
      this.removeOutgoingIntent(outboundIntent);
      if (id) this.rememberProgrammaticMessage(sid, result);
      const earlyAck = await Promise.race([ackWait, createdWait, new Promise(resolve => setTimeout(() => resolve(null), 700))]);
      if (earlyAck?.ack !== undefined && ackIsDelivered(earlyAck.ack)) { ackWait.cancel(); createdWait.cancel(); return { result, __chatBotAck: { status: 'confirmed', mode: 'ack', id, waitedMs: Date.now() - started } }; }
      if (earlyAck?.body !== undefined || idSerialized(earlyAck?.id)) { ackWait.cancel(); createdWait.cancel(); return { result, __chatBotAck: { status: 'created', mode: 'message_create', id, waitedMs: Date.now() - started } }; }
      // The library returned a Message object, which means the operation created a send.
      // Mark it as created, not falsely as delivered, and never retry it automatically.
      ackWait.cancel(); createdWait.cancel();
      return { result, __chatBotAck: { status: 'created', mode: 'return', id, waitedMs: Date.now() - started } };
    } catch (e) {
      if (e.code === 'SEND_TIMEOUT') { const event = await Promise.race([ackWait, createdWait]); this.removeOutgoingIntent(outboundIntent); if (event) { const confirmed = event?.ack !== undefined && ackIsDelivered(event.ack); this.rememberProgrammaticMessage(sid, event); return { result: event, __chatBotAck: { status: confirmed ? 'confirmed' : 'created', mode: confirmed ? 'ack' : 'message_create', waitedMs: Date.now() - started } }; } throw Object.assign(new Error(`لم نتأكد من نتيجة ${label || 'الإرسال'}؛ لم تتم إعادة الإرسال لمنع التكرار.`), { code: 'SEND_UNCERTAIN' }); }
      this.removeOutgoingIntent(outboundIntent); ackWait.cancel(); createdWait.cancel(); throw e;
    }
  }
  async resolveChatId(id, target) {
    const sid = this.store.safeSessionId(id), client = await this.ensureReady(sid);
    if (target.kind === 'group' || String(target.gid || '').toLowerCase().endsWith('@g.us')) { const gid = String(target.gid || '').trim().toLowerCase(); if (!/^\d+(?:-\d+)*@g\.us$/.test(gid)) throw new Error('معرف المجموعة غير صالح.'); try { const chat = await client.getChatById(gid); return idSerialized(chat?.id) || gid; } catch { return gid; } }
    // Older imported recipients may contain only `digits` or a verified WhatsApp JID.
    const savedJid = String(target.whatsappJid || '').trim().toLowerCase();
    const savedJidDigits = savedJid.match(/^(\d{5,25})@c\.us$/)?.[1] || '';
    const digits = String(target.e164 || target.phone || target.digits || target.number || savedJidDigits || '').replace(/\D/g, '');
    if (!digits) throw new Error(`رقم المستلم مفقود${target.name ? `: ${String(target.name).slice(0, 80)}` : ''}. افتح «الأشخاص» وأعد مزامنة جهات WhatsApp.`);
    if (savedJidDigits && savedJidDigits === digits && typeof client.getContactById === 'function') {
      try { const c = await withTimeout(client.getContactById(savedJid), 10000, 'التحقق من جهة WhatsApp'); if (idSerialized(c?.id).toLowerCase() === savedJid) return savedJid; } catch {}
    }
    const n = await withTimeout(client.getNumberId(digits), 20000, 'فحص رقم WhatsApp');
    if (!n) throw new Error(`الرقم ${digits} (${target.name || 'المستلم'}) غير مسجل على WhatsApp. حدّث جهة الاتصال من حساب WhatsApp أو تحقّق من رمز الدولة.`);
    const resolved = idSerialized(n);
    if (!/^\d{5,25}@c\.us$/i.test(resolved)) throw new Error(`لم يُرجع WhatsApp معرّف هاتف مؤكدًا للمستلم ${target.name || digits}.`);
    return resolved;
  }
  async sendText(id, chatId, text, { timeoutMs = 30000 } = {}) {
    const client = await this.ensureReady(id), content = String(text || '').trim();
    if (!content) throw new Error('النص فارغ.');
    if (!chatId) throw new Error('لم يتم تحديد محادثة WhatsApp للإرسال.');
    const r = await this.sendConfirmed(this.store.safeSessionId(id), chatId, () => client.sendMessage(chatId, content), timeoutMs, 'إرسال النص', content);
    this.entry(id).lastSent = { at: new Date().toISOString(), chatId, kind: 'text' }; return r;
  }
  async sendMedia(id, chatId, file, { timeoutMs = 30000, asDocument = false, asSticker = false, caption = '' } = {}) {
    const client = await this.ensureReady(id), sid = this.store.safeSessionId(id);
    if (!chatId) throw new Error('لم يتم تحديد محادثة WhatsApp للإرسال.');
    if (!file || !fs.existsSync(file) || !fs.statSync(file).isFile()) throw new Error('ملف الإرسال غير موجود؛ أعد رفعه من صفحة «الإرسال».');
    const st = fs.statSync(file);
    if (!st.size) throw new Error('الملف المحدد فارغ ولا يمكن إرساله.');
    if (st.size > 250 * 1024 * 1024) throw new Error('حجم الملف تجاوز الحد الأقصى 250 ميجابايت.');
    let media;
    try { media = MessageMedia.fromFilePath(file); }
    catch (e) { throw new Error(`تعذر تجهيز الملف للإرسال: ${safeError(e)}`); }
    if (asSticker && path.extname(file).toLowerCase() !== '.webp') throw new Error('إرسال الملصق يتطلب ملف WebP.');
    const mediaOptions = { sendMediaAsDocument: Boolean(asDocument), ...(asSticker ? { sendMediaAsSticker: true } : {}) };
    if (String(caption || '').trim() && !asDocument) mediaOptions.caption = String(caption).trim().slice(0, 1024);
    const r = await this.sendConfirmed(sid, chatId, () => client.sendMessage(chatId, media, mediaOptions), timeoutMs, asDocument ? 'إرسال الملف كمستند' : 'إرسال الصورة أو الوسائط', String(mediaOptions.caption || ''));
    this.entry(id).lastSent = { at: new Date().toISOString(), chatId, kind: asDocument ? 'document' : 'media', filename: path.basename(file), bytes: st.size };
    return r;
  }
  async sendVoice(id, chatId, file, { timeoutMs = 45000 } = {}) {
    const client = await this.ensureReady(id), sid = this.store.safeSessionId(id);
    if (!chatId) throw new Error('لم يتم تحديد محادثة WhatsApp لإرسال الصوت.');
    if (!file || !fs.existsSync(file) || !fs.statSync(file).isFile()) throw new Error('ملف الرسالة الصوتية غير موجود.');
    const filePath = path.resolve(file), extension = path.extname(filePath).toLowerCase(), stat = fs.statSync(filePath);
    if (!['.ogg', '.opus'].includes(extension)) throw new Error('رسائل WhatsApp الصوتية يجب أن تكون بصيغة OGG/Opus، وليس WAV أو MP3 خامًا.');
    if (stat.size < 100 || stat.size > 32 * 1024 * 1024) throw new Error('حجم الرسالة الصوتية غير صالح أو أكبر من 32 ميجابايت.');
    let media;
    try { media = MessageMedia.fromFilePath(filePath); }
    catch (error) { throw new Error(`تعذر تجهيز الصوت للإرسال: ${safeError(error)}`); }
    const result = await this.sendConfirmed(sid, chatId, () => client.sendMessage(chatId, media, { sendAudioAsVoice: true, sendMediaAsDocument: false }), timeoutMs, 'إرسال رسالة صوتية', '[رسالة صوتية]');
    this.entry(id).lastSent = { at: new Date().toISOString(), chatId, kind: 'voice', filename: path.basename(filePath), bytes: stat.size };
    return result;
  }
  async replyToMessage(id, message, text) { await this.ensureReady(id); const content = String(text || '').trim(); if (!content) return null; const chatId = chatIdFromMessage(message); try { if (typeof message?.reply === 'function') return await this.sendConfirmed(this.store.safeSessionId(id), chatId, () => message.reply(content), 30000, 'الرد', content); } catch (e) { if (e.code === 'SEND_UNCERTAIN') throw e; } if (!chatId) throw new Error('تعذر تحديد المحادثة للرد.'); return this.sendText(id, chatId, content); }
  async reactToMessage(id, messageId, emoji) { const client = await this.ensureReady(id), mid = idSerialized(messageId); if (!mid) throw new Error('معرف الرسالة غير متاح.'); const m = await withTimeout(client.getMessageById(mid), 15000, 'البحث عن الرسالة'); if (!m) throw new Error('لم أجد الرسالة المطلوبة للـReaction.'); await withTimeout(m.react(String(emoji || '👍')), 15000, 'إرسال Reaction'); return { __chatBotAck: { status: 'confirmed', mode: 'reaction' } }; }
  async getChatSafe(id, chatId) {
    const client = await this.ensureReady(id), wanted = String(chatId || '').trim().toLowerCase();
    if (!/^(?:\d{5,25}(?:-\d+)*@g\.us|\d{5,25}@c\.us|\d{5,25}@lid)$/i.test(wanted)) throw new Error('معرّف المحادثة غير صالح.');
    try { const chat = await withTimeout(client.getChatById(wanted), 15000, 'فتح المحادثة'); if (chat && idSerialized(chat.id).toLowerCase() === wanted) return chat; } catch (error) { if (/معرّف المحادثة/.test(error.message)) throw error; }
    const chats = await withTimeout(client.getChats(), 30000, 'البحث في المحادثات');
    const found = (chats || []).find(chat => idSerialized(chat?.id).toLowerCase() === wanted);
    if (!found) throw new Error('المحادثة غير موجودة في حساب WhatsApp الحالي.');
    return found;
  }
  async actOnChat(id, chatId, action, options = {}) {
    const chat = await this.getChatSafe(id, chatId);
    if (action === 'archive') {
      if (typeof chat.archive !== 'function') throw new Error('هذه النسخة من WhatsApp لا تدعم أرشفة المحادثة.');
      await withTimeout(chat.archive(), 15000, 'أرشفة المحادثة'); return { action, chatId: idSerialized(chat.id) };
    }
    if (action === 'delete') {
      if (typeof chat.delete !== 'function') throw new Error('هذه النسخة من WhatsApp لا تدعم حذف المحادثة.');
      const ok = await withTimeout(chat.delete(), 20000, 'حذف المحادثة');
      if (ok === false) throw new Error('لم يؤكد WhatsApp حذف المحادثة.');
      return { action, chatId: idSerialized(chat.id), confirmed: true };
    }
    if (action === 'mute') {
      if (typeof chat.mute !== 'function') throw new Error('هذه النسخة من WhatsApp لا تدعم كتم الإشعارات.');
      let until = null;
      if (options.until instanceof Date && Number.isFinite(options.until.getTime())) until = options.until;
      else if (options.permanent !== true) {
        const minutes = Math.max(1, Math.min(525600, Number(options.minutes) || 60));
        until = new Date(Date.now() + minutes * 60000);
      }
      const result = until ? await withTimeout(chat.mute(until), 15000, 'كتم الإشعارات') : await withTimeout(chat.mute(), 15000, 'كتم الإشعارات');
      return { action, chatId: idSerialized(chat.id), isMuted: result?.isMuted !== false, muteExpiration: result?.muteExpiration ?? null };
    }
    if (action === 'unmute') {
      if (typeof chat.unmute !== 'function') throw new Error('هذه النسخة من WhatsApp لا تدعم إلغاء كتم الإشعارات.');
      const result = await withTimeout(chat.unmute(), 15000, 'إلغاء كتم الإشعارات');
      return { action, chatId: idSerialized(chat.id), isMuted: result?.isMuted === true };
    }
    throw new Error('إجراء المحادثة غير معروف.');
  }
  async deleteMessage(id, messageOrId, options = {}) {
    const client = await this.ensureReady(id);
    let msg = messageOrId && typeof messageOrId.delete === 'function' ? messageOrId : null;
    if (!msg) {
      const mid = idSerialized(messageOrId);
      if (!mid) throw new Error('معرّف الرسالة غير متاح.');
      msg = await withTimeout(client.getMessageById(mid), 15000, 'البحث عن الرسالة');
    }
    if (!msg || typeof msg.delete !== 'function') throw new Error('لم يتم العثور على رسالة قابلة للحذف.');
    const expectedChat = options.chatId ? String(options.chatId).toLowerCase() : '';
    const actualChat = chatIdFromMessage(msg).toLowerCase();
    if (expectedChat && actualChat && expectedChat !== actualChat) throw new Error('تم إيقاف الحذف لأن الرسالة لا تتطابق مع المحادثة المستهدفة.');
    const mid = idSerialized(msg.id || msg);
    if (!mid) throw new Error('لا يمكن التحقق من معرّف الرسالة.');
    const result = await withTimeout(msg.delete(options.everyone === true), 20000, 'حذف الرسالة');
    return { messageId: mid, chatId: actualChat, everyone: options.everyone === true, result: result ?? true };
  }
  async deleteMessagesOlderThan(id, chatId, cutoffMs, options = {}) {
    const chat = await this.getChatSafe(id, chatId);
    if (typeof chat.fetchMessages !== 'function') throw new Error('تعذر قراءة رسائل المحادثة في هذا الإصدار.');
    const limit = Math.max(1, Math.min(1000, Number(options.limit) || 500));
    const messages = await withTimeout(chat.fetchMessages({ limit }), 45000, 'قراءة الرسائل القديمة');
    const cutoff = Number(cutoffMs);
    if (!Number.isFinite(cutoff) || cutoff <= 0) throw new Error('وقت الاحتفاظ بالرسائل غير صالح.');
    const old = (messages || []).filter(m => {
      const stamp = Number(m?.timestamp || m?._data?.t || m?.t || 0);
      const ms = stamp > 1e12 ? stamp : stamp * 1000;
      return ms > 0 && ms < cutoff && typeof m?.delete === 'function' && !m?.isRevoked;
    });
    let deleted = 0, failed = 0; const errors = [];
    for (const msg of old.slice(0, limit)) {
      try { await this.deleteMessage(id, msg, { everyone: options.everyone === true, chatId }); deleted++; }
      catch (error) { failed++; if (errors.length < 8) errors.push(String(error?.message || error).slice(0, 250)); }
    }
    return { scanned: (messages || []).length, matched: old.length, deleted, failed, errors, limitReached: (messages || []).length >= limit };
  }
  async searchChats(id, { query = '', limit = 20 } = {}) {
    const client = await this.ensureReady(id);
    const chats = await withTimeout(client.getChats(), 30000, 'قراءة قائمة المحادثات');
    const normalize = value => String(value || '').normalize('NFKC').toLocaleLowerCase('ar')
      .replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[إأآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
      .replace(/[^\p{L}\p{N}@.+_-]+/gu, ' ').trim();
    const needle = normalize(query);
    const rows = (Array.isArray(chats) ? chats : []).map(chat => {
      const chatId = idSerialized(chat?.id).trim().toLowerCase();
      const isGroup = chatId.endsWith('@g.us') || chat?.isGroup === true;
      const name = String(chat?.name || chat?.formattedTitle || chat?.pushname || chat?.contact?.name || chat?.contact?.pushname || chatId).trim().slice(0, 160);
      return { id: chatId, name, isGroup, unreadCount: Math.max(0, Number(chat?.unreadCount) || 0), timestamp: Number(chat?.lastMessage?.timestamp || 0) };
    }).filter(row => /^(?:\d{5,25}@c\.us|\d{5,25}@lid|\d{5,25}(?:-\d+)*@g\.us)$/.test(row.id));
    const matches = !needle ? rows : rows.filter(row => normalize(`${row.name} ${row.id}`).includes(needle));
    matches.sort((a, b) => Number(b.timestamp || 0) - Number(a.timestamp || 0) || a.name.localeCompare(b.name, 'ar'));
    return matches.slice(0, Math.max(1, Math.min(100, Number(limit) || 20)));
  }
  async downloadMediaFromChat(id, chatId, { messageLimit = 500, maxFiles = 100, perFileBytes = 100 * 1024 * 1024, totalBytes = 500 * 1024 * 1024, mediaType = 'all' } = {}) {
    const sid = this.store.safeSessionId(id), chat = await this.getChatSafe(sid, chatId);
    const requestedMediaType = String(mediaType || 'all').toLowerCase();
    if (!['all', 'audio', 'image', 'video', 'document', 'sticker'].includes(requestedMediaType)) throw new Error('نوع المرفق المطلوب غير مدعوم؛ استخدم all/audio/image/video/document/sticker.');
    if (typeof chat.fetchMessages !== 'function') throw new Error('نسخة WhatsApp الحالية لا تتيح قراءة سجل المحادثة لتنزيل المرفقات.');
    // These hard ceilings avoid unbounded history scans and memory/disk use while
    // still allowing a much fuller export than the previous 200-message/50-file cap.
    const limit = Math.max(1, Math.min(500, Number(messageLimit) || 500));
    const cap = Math.max(1, Math.min(100, Number(maxFiles) || 100));
    const fileLimit = Math.max(1024, Math.min(100 * 1024 * 1024, Number(perFileBytes) || 100 * 1024 * 1024));
    const totalLimit = Math.max(fileLimit, Math.min(500 * 1024 * 1024, Number(totalBytes) || 500 * 1024 * 1024));
    const messages = await withTimeout(chat.fetchMessages({ limit }), 45000, 'قراءة رسائل المحادثة لتنزيل المرفقات');
    // whatsapp-web.js returns fetched messages oldest-to-newest. Keep the newest
    // candidate set, then process newest-first so a cap doesn't accidentally favor
    // old attachments at the start of a large conversation.
    const allMediaCandidates = (Array.isArray(messages) ? messages : []).filter(message => message?.hasMedia !== false && (message?.hasMedia || message?._data?.mimetype || ['image','video','audio','ptt','document','sticker'].includes(String(message?.type || '').toLowerCase())));
    const mediaKind = message => {
      const type = String(message?.type || '').toLowerCase();
      const mime = String(message?._data?.mimetype || message?.mimetype || '').split(';')[0].toLowerCase();
      if (type === 'sticker') return 'sticker';
      if (['audio', 'ptt', 'voice'].includes(type) || mime.startsWith('audio/')) return 'audio';
      if (type === 'image' || mime.startsWith('image/')) return 'image';
      if (type === 'video' || mime.startsWith('video/')) return 'video';
      if (type === 'document') return 'document';
      return 'document';
    };
    const allCandidates = requestedMediaType === 'all' ? allMediaCandidates : allMediaCandidates.filter(message => mediaKind(message) === requestedMediaType);
    const candidates = allCandidates.slice(-cap).reverse();
    const mediaUtil = require('./media');
    const mediaDir = this.store.getPaths(sid).media;
    fs.mkdirSync(mediaDir, { recursive: true });
    const mimeExt = { 'image/jpeg':'.jpg','image/png':'.png','image/webp':'.webp','image/gif':'.gif','image/avif':'.avif','image/heic':'.heic','image/heif':'.heif','video/mp4':'.mp4','video/webm':'.webm','video/quicktime':'.mov','video/x-matroska':'.mkv','audio/ogg':'.ogg','audio/opus':'.opus','audio/mpeg':'.mp3','audio/mp4':'.m4a','audio/aac':'.aac','audio/wav':'.wav','audio/flac':'.flac','application/pdf':'.pdf','text/plain':'.txt','text/csv':'.csv','application/zip':'.zip','application/x-7z-compressed':'.7z','application/vnd.rar':'.rar','application/json':'.json','application/xml':'.xml','text/xml':'.xml','application/msword':'.doc','application/vnd.openxmlformats-officedocument.wordprocessingml.document':'.docx','application/vnd.ms-excel':'.xls','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':'.xlsx','application/vnd.ms-powerpoint':'.ppt','application/vnd.openxmlformats-officedocument.presentationml.presentation':'.pptx' };
    const downloaded = [], skipped = [], failed = [];
    let total = 0;
    for (const message of candidates) {
      if (downloaded.length >= cap) break;
      try {
        if (typeof message.downloadMedia !== 'function') { skipped.push({ reason: 'download-api-unavailable' }); continue; }
        const payload = await withTimeout(message.downloadMedia(), 30000, 'تنزيل مرفق من WhatsApp');
        if (!payload || typeof payload.data !== 'string' || !payload.data) { skipped.push({ reason: 'media-unavailable', messageId: idSerialized(message?.id) }); continue; }
        const encoded = payload.data.replace(/\s+/g, '');
        if (!/^[A-Za-z0-9+/]*={0,2}$/.test(encoded) || encoded.length % 4 === 1) { skipped.push({ reason: 'invalid-media-encoding', messageId: idSerialized(message?.id) }); continue; }
        if (encoded.length > Math.ceil(fileLimit * 4 / 3) + 8) { skipped.push({ reason: 'file-size-limit', messageId: idSerialized(message?.id) }); continue; }
        const bytes = Buffer.from(encoded, 'base64');
        if (!bytes.length || bytes.length > fileLimit) { skipped.push({ reason: 'file-size-limit', bytes: bytes.length, messageId: idSerialized(message?.id) }); continue; }
        if (total + bytes.length > totalLimit) { skipped.push({ reason: 'total-size-limit', messageId: idSerialized(message?.id) }); break; }
        const mime = String(payload.mimetype || message?._data?.mimetype || 'application/octet-stream').split(';')[0].toLowerCase();
        const suppliedName = String(payload.filename || message?._data?.filename || '').trim();
        let ext = path.extname(suppliedName).toLowerCase();
        if (!/^\.[a-z0-9]{1,12}$/.test(ext) || !mediaUtil.MEDIA_EXT.has(ext)) ext = mimeExt[mime] || '.bin';
        const base = path.basename(suppliedName || `${String(message?.type || 'attachment')}_${Number(message?.timestamp || Date.now())}`, path.extname(suppliedName)).replace(/[^\w\- .\u0600-\u06ff]/g, '_').trim().slice(0, 65) || 'whatsapp_attachment';
        const fileName = mediaUtil.uniqueFileName(mediaDir, base, ext);
        const filePath = mediaUtil.safePath(mediaDir, fileName);
        fs.writeFileSync(filePath, bytes, { flag: 'wx', mode: 0o600 });
        total += bytes.length;
        downloaded.push({ filename: fileName, bytes: bytes.length, mimetype: mime, type: String(message?.type || mime), timestamp: Number(message?.timestamp || 0), messageId: idSerialized(message?.id) });
      } catch (error) { failed.push({ error: String(error?.message || error).slice(0, 180), messageId: idSerialized(message?.id) }); }
    }
    return { chatId: idSerialized(chat?.id).toLowerCase(), chatName: String(chat?.name || chat?.formattedTitle || chatId).slice(0, 160), scanned: (messages || []).length, mediaType: requestedMediaType, mediaFound: allCandidates.length, mediaFoundTotal: allMediaCandidates.length, considered: candidates.length, limits: { messageLimit: limit, maxFiles: cap, perFileBytes: fileLimit, totalBytes: totalLimit }, downloaded, skipped, failed, totalBytes: total, mediaDirectory: `data/sessions/${sid}/media` };
  }
  async getContactProfilePictureUrl(id, jid) {
    const sid = this.store.safeSessionId(id), normalized = String(jid || '').trim().toLowerCase();
    if (!/^\d{5,25}@c\.us$/.test(normalized)) throw new Error('معرّف جهة WhatsApp غير صالح أو لا يرتبط برقم مؤكد.');
    if (normalized === String(this.selfChatId(sid) || '').toLowerCase()) return '';
    const client = await this.ensureReady(sid);
    const profileUrl = async (contact, rawId) => {
      if (typeof contact?.getProfilePicUrl === 'function') {
        try {
          const url = await withTimeout(contact.getProfilePicUrl(), 8000, 'جلب صورة حساب WhatsApp');
          if (typeof url === 'string' && /^https:\/\//i.test(url)) return url;
        } catch {}
      }
      if (typeof client.getProfilePicUrl === 'function') {
        for (const candidate of [...new Set([rawId, normalized].filter(Boolean))]) {
          if (!candidate) continue;
          try {
            const url = await withTimeout(client.getProfilePicUrl(candidate), 8000, 'جلب صورة حساب WhatsApp');
            if (typeof url === 'string' && /^https:\/\//i.test(url)) return url;
          } catch {}
        }
      }
      return '';
    };

    let contact = null, rawJid = normalized;
    if (typeof client.getContactById === 'function') {
      try { contact = await withTimeout(client.getContactById(normalized), 10000, 'قراءة جهة WhatsApp'); } catch {}
      if (contact && idSerialized(contact?.id).toLowerCase() !== normalized) contact = null;
    }
    if (contact) {
      const direct = await profileUrl(contact, normalized);
      if (direct) return direct;
      // Do not stop at an empty result from the direct PN lookup. On current
      // WhatsApp Web builds, the profile thumbnail may be bound to the mapped LID.
    }

    if (typeof client.getContacts !== 'function') return profileUrl(contact, normalized);
    let contacts = [];
    try { contacts = await withTimeout(client.getContacts(), 30000, 'البحث عن جهة WhatsApp'); } catch {}
    contact = (Array.isArray(contacts) ? contacts : []).find(item => idSerialized(item?.id).toLowerCase() === normalized) || null;
    if (contact) {
      const direct = await profileUrl(contact, normalized);
      if (direct) return direct;
    }

    // Newer WhatsApp accounts may expose a LID for a contact. First ask the
    // library to resolve this exact verified phone ID, avoiding a full contacts
    // scan for every image shown in the UI.
    if (typeof client.getContactLidAndPhone === 'function') {
      try {
        const pairs = await withTimeout(client.getContactLidAndPhone([normalized]), 10000, 'ربط معرف جهة WhatsApp');
        for (const pair of Array.isArray(pairs) ? pairs : []) {
          let pn = idSerialized(pair?.pn || pair?.phone).toLowerCase();
          if (/^\d{5,25}$/.test(pn)) pn = `${pn}@c.us`;
          const lid = idSerialized(pair?.lid).trim().toLowerCase();
          if (pn !== normalized || !/^\d{5,25}@lid$/.test(lid)) continue;
          let mapped = (Array.isArray(contacts) ? contacts : []).find(item => idSerialized(item?.id).toLowerCase() === lid) || null;
          if (!mapped && typeof client.getContactById === 'function') {
            try { mapped = await withTimeout(client.getContactById(lid), 8000, 'قراءة جهة WhatsApp المرتبطة'); } catch {}
          }
          const mappedUrl = await profileUrl(mapped, lid);
          if (mappedUrl) return mappedUrl;
        }
      } catch {}

      // Last fallback: scan LIDs already returned by getContacts, in bounded
      // batches. Never derive a phone number from the opaque LID itself.
      const lidContacts = (Array.isArray(contacts) ? contacts : []).filter(item => /^\d{5,25}@lid$/i.test(idSerialized(item?.id)));
      for (let offset = 0; offset < lidContacts.length; offset += 80) {
        const batch = lidContacts.slice(offset, offset + 80);
        try {
          const pairs = await withTimeout(client.getContactLidAndPhone(batch.map(item => idSerialized(item.id))), 15000, 'ربط معرّفات جهات WhatsApp');
          for (const pair of Array.isArray(pairs) ? pairs : []) {
            let pn = idSerialized(pair?.pn || pair?.phone).toLowerCase();
            if (/^\d{5,25}$/.test(pn)) pn = `${pn}@c.us`;
            if (pn !== normalized) continue;
            const lid = idSerialized(pair?.lid).toLowerCase();
            if (!/^\d{5,25}@lid$/.test(lid)) continue;
            const found = batch.find(item => idSerialized(item?.id).toLowerCase() === lid);
            if (!found) continue;
            const mappedUrl = await profileUrl(found, lid);
            if (mappedUrl) return mappedUrl;
          }
        } catch {}
      }
    }
    return profileUrl(contact, rawJid);
  }

  async listContacts(id, { includeProfilePictures = false, onlyJids = null, limit = 2000 } = {}) {
    const sid = this.store.safeSessionId(id), client = await this.ensureReady(sid);
    if (typeof client.getContacts !== 'function') throw new Error('إصدار مكتبة WhatsApp الحالي لا يوفر استدعاء جهات الاتصال.');
    const all = await withTimeout(client.getContacts(), 30000, 'استدعاء جهات WhatsApp');
    const wanted = Array.isArray(onlyJids) ? new Set(onlyJids.map(v => String(v || '').trim().toLowerCase())) : null;
    const self = this.selfChatId(sid), byJid = new Map();
    const max = Math.max(1, Math.min(2000, Number(limit) || 2000));
    const localNameOf = contact => String(contact?.name || '').trim().slice(0, 100);
    const pushNameOf = contact => String(contact?.pushname || '').trim().slice(0, 100);
    const notifyNameOf = contact => String(contact?.notifyName || contact?._data?.notifyName || '').trim().slice(0, 100);
    const add = (contact, verifiedJid, rawJid) => {
      const jid = String(verifiedJid || '').trim().toLowerCase();
      if (!/^\d{5,25}@c\.us$/.test(jid) || jid === self || (wanted && !wanted.has(jid))) return;
      const digits = jid.slice(0, jid.indexOf('@'));
      const localName = localNameOf(contact), pushname = pushNameOf(contact), notifyName = notifyNameOf(contact);
      const shortName = String(contact?.shortName || '').trim().slice(0, 100);
      const looksLikePhone = value => { const v = String(value || '').replace(/[\s()+.-]/g, ''); return !!v && /^\d+$/.test(v) && v.replace(/^0+/, '') === digits.replace(/^0+/, ''); };
      const names = contact?.isMyContact ? [localName, pushname, notifyName, shortName] : [pushname, notifyName, localName, shortName];
      const displayName = names.find(value => value && !looksLikePhone(value)) || localName || pushname || notifyName || shortName || `+${digits}`;
      const rawContactId = idSerialized(contact?.id).trim().toLowerCase() || rawJid || jid;
      const exactPhoneId = rawContactId === jid;
      const rank = (exactPhoneId ? 4 : 0) + (contact?.isMyContact === true ? 2 : 0) + (displayName && !/^\+?\d+$/.test(displayName) ? 1 : 0);
      const previous = byJid.get(jid);
      if (previous && previous._rank >= rank) return;
      byJid.set(jid, {
        jid, digits, name: displayName, pushname, notifyName, isMyContact: contact?.isMyContact === true,
        isWAContact: contact?.isWAContact !== false, isBusiness: contact?.isBusiness === true,
        profilePicUrl: '', _contactForPicture: contact, _contactIdForPicture: rawContactId, _rank: rank,
      });
    };

    const rows = [];
    const lids = [];
    for (const contact of (Array.isArray(all) ? all : [])) {
      const rawJid = idSerialized(contact?.id).trim().toLowerCase();
      if (/^\d{5,25}@c\.us$/.test(rawJid)) add(contact, rawJid, rawJid);
      else if (/^\d{5,25}@lid$/.test(rawJid)) lids.push({ contact, rawJid });
      if (byJid.size >= max && (!wanted || [...wanted].every(jid => byJid.has(jid)))) break;
    }

    // Do not infer phone numbers from LID digits. Only use the official mapping
    // supplied by WhatsApp, which is the supported path for newer contact IDs.
    if (lids.length && typeof client.getContactLidAndPhone === 'function') {
      for (let offset = 0; offset < lids.length; offset += 80) {
        const batch = lids.slice(offset, offset + 80);
        try {
          const pairs = await withTimeout(client.getContactLidAndPhone(batch.map(item => item.rawJid)), 20000, 'ربط معرّفات جهات WhatsApp');
          const lidToPn = new Map();
          for (const pair of Array.isArray(pairs) ? pairs : []) {
            const lid = idSerialized(pair?.lid).trim().toLowerCase();
            let pn = idSerialized(pair?.pn || pair?.phone).trim().toLowerCase();
            if (/^\d{5,25}$/.test(pn)) pn = `${pn}@c.us`;
            if (/^\d{5,25}@lid$/.test(lid) && /^\d{5,25}@c\.us$/.test(pn)) lidToPn.set(lid, pn);
          }
          for (const item of batch) {
            const pn = lidToPn.get(item.rawJid);
            if (pn) add(item.contact, pn, item.rawJid);
          }
        } catch (error) {
          this.log(sid, 'WARN', `تعذر ربط بعض معرّفات WhatsApp الحديثة؛ لم يتم تخمين الأرقام. ${safeError(error).slice(0, 180)}`);
        }
      }
    }

    const selectedRows = [...byJid.values()].sort((a, b) => Number(b.isMyContact) - Number(a.isMyContact) || a.name.localeCompare(b.name, 'ar')).slice(0, max);
    if (includeProfilePictures && selectedRows.length) {
      const pictureRows = selectedRows.slice(0, Math.min(120, selectedRows.length));
      let cursor = 0;
      const workers = Array.from({ length: Math.min(6, pictureRows.length) }, async () => {
        while (cursor < pictureRows.length) {
          const index = cursor++, row = pictureRows[index], contact = row._contactForPicture;
          try {
            let url = typeof contact?.getProfilePicUrl === 'function'
              ? await withTimeout(contact.getProfilePicUrl(), 3500, 'صورة جهة WhatsApp') : '';
            if (typeof url !== 'string' || !/^https:\/\//i.test(url)) {
              if (typeof client.getProfilePicUrl === 'function') url = await withTimeout(client.getProfilePicUrl(row._contactIdForPicture || row.jid), 3500, 'صورة جهة WhatsApp');
            }
            if (typeof url === 'string' && /^https:\/\//i.test(url)) row.profilePicUrl = url;
          } catch {}
        }
      });
      await Promise.all(workers);
    }
    return selectedRows.map(({ _contactForPicture, _contactIdForPicture, _rank, ...item }) => item);
  }

  async listGroups(id) {
    const client = await this.ensureReady(id), e = this.entry(id), out = [], seen = new Set();
    let chats = [];
    try { chats = await withTimeout(client.getChats(), 30000, 'قراءة محادثات WhatsApp'); }
    catch (e2) { this.log(id, 'WARN', `تعذر قراءة محادثات WhatsApp: ${safeError(e2)}`); }
    for (const chat of chats || []) {
      const gid = idSerialized(chat?.id).toLowerCase();
      if (!gid.endsWith('@g.us') && !chat?.isGroup) continue;
      try {
        const info = await this.groupInfoFromChat(chat);
        if (!/^\d+(?:-\d+)*@g\.us$/.test(info.gid) || seen.has(info.gid)) continue;
        seen.add(info.gid); e.liveGroups.set(info.gid, info); out.push(info);
      } catch (err) {
        if (gid.endsWith('@g.us')) e.liveGroups.set(gid, { gid, name: String(chat?.name || chat?.subject || gid), description:'', owner:'', participantsCount:null, participants:[], admins:[], inviteCode:'' });
        this.log(id, 'WARN', `تعذر تحليل مجموعة ${gid || 'غير معروفة'}: ${safeError(err)}`);
      }
    }
    for (const [gid, info] of e.liveGroups) if (!seen.has(gid) && /@g\.us$/.test(gid)) out.push(info);
    const unique = new Map(out.filter(x => x?.gid).map(x => [x.gid, x]));
    return [...unique.values()];
  }
  async groupInfoFromChat(chat) { let inviteCode = ''; try { if (typeof chat.getInviteCode === 'function') inviteCode = await chat.getInviteCode(); } catch {} const gid = idSerialized(chat?.id).toLowerCase(); const raw = Array.isArray(chat?.participants) ? chat.participants : (Array.isArray(chat?.groupMetadata?.participants) ? chat.groupMetadata.participants : []); const participants = raw.map(p => ({ id: idSerialized(p?.id || p).toLowerCase(), name: String(p?.name || p?.pushname || p?.notifyName || '').slice(0,120), admin: Boolean(p?.isAdmin || p?.isSuperAdmin || p?.admin) })).filter(p => p.id).slice(0,2000); const admins = participants.filter(p => p.admin).slice(0,500); return { gid, name: String(chat?.name || chat?.subject || 'مجموعة').slice(0, 120), description: String(chat?.description || '').slice(0, 1000), owner: idSerialized(chat?.groupMetadata?.owner), participantsCount: participants.length || (Array.isArray(raw) ? raw.length : null), participants, admins, inviteCode }; }
  async getGroupInfo(id, gid) { const client = await this.ensureReady(id), want = String(gid || '').trim().toLowerCase(); if (!/^\d+(?:-\d+)*@g\.us$/.test(want)) throw new Error('GID غير صالح.'); try { const chat = await client.getChatById(want); if (chat) return this.groupInfoFromChat(chat); } catch {} try { const chats = await client.getChats(); const chat = (chats || []).find(c => idSerialized(c?.id).toLowerCase() === want); if (chat) return this.groupInfoFromChat(chat); } catch {} const live = this.entry(id).liveGroups.get(want); if (live) return live; throw new Error('لم أستطع الوصول إلى هذه المجموعة داخل الجلسة الحالية. افتح المجموعة أو نفّذ اكتشاف المجموعات ثم أعد المحاولة.'); }
  async analyzeGroupInvite(id, code) { const client = await this.ensureReady(id), c = String(code || '').trim(); if (!c) throw new Error('رابط الدعوة غير صالح.'); if (typeof client.getInviteInfo !== 'function') throw new Error('إصدار المكتبة الحالي لا يوفر تحليل رابط الدعوة من دون فتح المجموعة.'); const info = await withTimeout(client.getInviteInfo(c), 20000, 'تحليل الدعوة'); return { gid: idSerialized(info?.id), name: String(info?.subject || info?.name || 'مجموعة عبر دعوة'), description: String(info?.description || ''), participantsCount: Number.isFinite(Number(info?.size)) ? Number(info.size) : null, inviteCode: c }; }
  async getGroupInfoFromMessage(id, msg) { let chat = null; try { if (typeof msg?.getChat === 'function') chat = await msg.getChat(); } catch {} if (chat) return this.groupInfoFromChat(chat); const gid = groupFromMessage(msg); if (!gid) throw new Error('الرسالة الحالية ليست من مجموعة.'); return this.getGroupInfo(id, gid); }
}
module.exports = { WhatsAppManager, safeError, idSerialized, groupFromMessage, chatIdFromMessage, isContextNavigationError, navigationRecoveryPlan, normalizePairingPhoneNumber, browserProfileConflictError, patchResult };
