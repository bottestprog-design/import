'use strict';

const triggerEngine = require('./trigger-engine');
const interactionTools = require('./interaction');
const replyQuality = require('./reply-quality');

function normalize(value) {
  return String(value || '').normalize('NFKC').toLocaleLowerCase('ar')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[إأآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
    .replace(/[\u200e\u200f\u202a-\u202e]/g, '').replace(/[،؛.!؟?]/g, ' ').replace(/\s+/g, ' ').trim();
}

function parseDiagnosticCommand(input) {
  const text = normalize(input);
  let match = text.match(/^(?:شخص|حلل|فسر|وضح)\s+(?:الرد التلقائي|قواعد التفاعل|قواعد الرد)\s+(?:علي|للنص|بالنص)?\s*(.*)$/u);
  if (match) return { recognized: true, sample: String(match[1] || '').replace(/^[:：-]\s*/u, '').trim(), source: 'rule-diagnostic' };
  match = text.match(/^(?:ليه|لماذا)\s+البوت\s+(?:مش بيرد|لا يرد|لا يجاوب|ما بيردش)\s+(?:علي|للنص)?\s*(.*)$/u);
  if (match) return { recognized: true, sample: String(match[1] || '').replace(/^[:：-]\s*/u, '').trim(), source: 'no-reply-diagnostic' };
  return { recognized: false, sample: '' };
}

function scopeDescription(scope, chatIds = []) {
  if (scope === 'groups') return 'المجموعات فقط؛ يلزم اختيار مجموعة لاختبار النطاق';
  if (scope === 'private') return 'المحادثات الخاصة فقط؛ يلزم اختيار جهة خاصة لاختبار النطاق';
  if (scope === 'selected') return Array.isArray(chatIds) && chatIds.length ? `أهداف محددة (${chatIds.length})؛ لم يحدد الاختبار محادثة` : 'أهداف محددة بلا أهداف محفوظة؛ لن تطابق نطاقًا فعليًا';
  return 'كل المحادثات';
}

function diagnose(session, sample, now = new Date()) {
  const settings = session?.settings || {};
  const rules = Array.isArray(session?.interaction?.rules) ? session.interaction.rules.slice(0, 1000) : [];
  const text = String(sample || '').trim().slice(0, 1500);
  const globalEnabled = settings.interactionEnabled !== false && session?.interaction?.enabled !== false;
  const quiet = interactionTools.quiet(settings, now);
  const options = {
    smartContains: settings.interactionSmartMatching !== false,
    smartThreshold: Number(settings.interactionSmartThreshold) || .82,
    threshold: Number(settings.interactionSimilarityThreshold) || .68,
  };
  const rows = rules.map((rule, index) => {
    let validationError = '';
    let result = { matched: false, score: 0, intent: 'unknown' };
    try {
      triggerEngine.validateTrigger(rule);
      result = triggerEngine.matchTrigger(rule, 'message', text, '', options);
    } catch (error) { validationError = String(error?.message || error).slice(0, 180); }
    let scheduleActive = true;
    try { scheduleActive = interactionTools.ruleActiveNow(rule, settings, now); }
    catch { scheduleActive = false; }
    const reply = String(rule?.then?.reply || rule?.then?.replies?.[0] || '');
    const quality = replyQuality.lintRuleReply(reply);
    const enabled = rule?.enabled !== false;
    const scope = String(rule?.scope || 'all');
    const scopeMissingTargets = scope === 'selected' && !(Array.isArray(rule?.chatIds) && rule.chatIds.length);
    const reasons = [];
    if (!globalEnabled) reasons.push('محرك التفاعل العام متوقف');
    if (!enabled) reasons.push('القاعدة متوقفة');
    if (validationError) reasons.push(`تعريف القاعدة غير صالح: ${validationError}`);
    if (!scheduleActive) reasons.push('خارج وقت/أيام تشغيل القاعدة');
    if (!result.matched) reasons.push('النص لا يطابق الشرط');
    if (!quality.ok) reasons.push(`الرد مرفوض بفحص الجودة: ${quality.issues.map(x => x.message).join('، ')}`);
    if (scopeMissingTargets) reasons.push('نطاق الأهداف المحددة فارغ');
    if (quiet && settings.interactionQuietAction !== 'rules') reasons.push(`فترة عدم الإزعاج مفعّلة (${settings.interactionQuietAction === 'reply' ? 'قد تستبدل الرد برسالة الهدوء' : 'قد تمنع الرد'})`);
    const potentiallyEligible = globalEnabled && enabled && !validationError && scheduleActive && result.matched && quality.ok && !scopeMissingTargets;
    return {
      index, id: String(rule?.id || ''), name: String(rule?.name || `قاعدة ${index + 1}`).slice(0, 100),
      enabled, matched: result.matched, score: Number(result.score) || 0,
      mode: String(rule?.when?.match || 'contains'), trigger: String(rule?.when?.value || '').slice(0, 180),
      scope, scopeLabel: scopeDescription(scope, rule?.chatIds), scheduleActive,
      reply: reply.slice(0, 360), qualityScore: quality.score, qualityIssues: quality.issues.map(x => x.message), qualityWarnings: quality.warnings,
      validationError, reasons, potentiallyEligible,
    };
  });
  const matches = rows.filter(x => x.matched).sort((a, b) => Number(b.potentiallyEligible) - Number(a.potentiallyEligible) || b.score - a.score || a.index - b.index);
  const near = rows.filter(x => !x.matched && !x.validationError).sort((a,b) => b.score-a.score).slice(0, 3);
  const lines = [
    `نتيجة تشخيص القواعد للنص: «${text.slice(0, 220)}»`,
    `المعاينة للقراءة فقط: لم يتم إرسال أي رسالة أو تعديل أي قاعدة.`,
    `محرك التفاعل العام: ${globalEnabled ? 'مفعّل' : 'متوقف'}؛ فترة عدم الإزعاج: ${quiet ? 'نشطة الآن' : 'غير نشطة الآن'}؛ القواعد المحفوظة: ${rules.length}.`,
  ];
  if (matches.length) {
    lines.push(`\nقواعد طابقت النص (${matches.length}):`);
    for (const rule of matches.slice(0, 12)) {
      const state = rule.potentiallyEligible ? 'مرشحة للتنفيذ' : 'لن تنفذ حاليًا';
      lines.push(`• ${rule.name} — ${state} — تطابق ${Math.round(rule.score * 100)}% — النطاق: ${rule.scopeLabel}`);
      if (rule.reply) lines.push(`  الرد المتوقع: ${rule.reply.slice(0, 180)}`);
      if (rule.reasons.length) lines.push(`  السبب/التحذير: ${rule.reasons.slice(0, 3).join('؛ ')}`);
      if (rule.qualityWarnings.length) lines.push(`  جودة الرد: ${rule.qualityWarnings.join('؛ ')}`);
    }
  } else lines.push('\nلم تطابق أي قاعدة هذا النص.');
  if (near.length) lines.push(`\nأقرب شروط غير مطابقة: ${near.map(x => `${x.name} («${x.trigger}»، ${Math.round(x.score * 100)}%)`).join('؛ ')}`);
  const broken = rows.filter(x => x.validationError || x.qualityIssues.length > 0 || (x.enabled && !x.scheduleActive));
  if (broken.length) lines.push(`\nراجِع هذه القواعد: ${broken.slice(0, 8).map(x => x.name).join('، ')}.`);
  lines.push('\nتنبيه: النطاق (خاص/مجموعات/أهداف محددة) والتهدئة ومنع التكرار تعتمد أيضًا على المحادثة الفعلية؛ هذا الفحص لا يرسل أو يختبر رسالة إلى شخص. استخدم «اختبر الرد التلقائي على: النص» للمطابقة البسيطة أو افحص قواعدك من لوحة التفاعل.');
  return { sample: text, globalEnabled, quiet, count: rules.length, matchedCount: matches.length, matches, near, rows, text: lines.join('\n') };
}

module.exports = { normalize, parseDiagnosticCommand, diagnose, scopeDescription };
