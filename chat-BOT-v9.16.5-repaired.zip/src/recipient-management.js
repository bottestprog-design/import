'use strict';

function cleanUniqueIds(value) {
  if (!Array.isArray(value)) throw new Error('يجب إرسال قائمة معرفات الأشخاص المراد حذفهم.');
  const ids = [...new Set(value.map(x => String(x || '').trim()).filter(Boolean))];
  if (ids.length > 2000) throw new Error('عدد العناصر المحددة كبير جدًا؛ احذفها على دفعات أصغر.');
  return ids;
}

function recipientChatId(person) {
  const digits = String(person?.digits || person?.phone || person?.e164 || '').replace(/\D/g, '');
  return digits ? `${digits}@c.us` : '';
}

function deleteRecipients(session, requestedIds) {
  const ids = cleanUniqueIds(requestedIds);
  if (!ids.length) throw new Error('حدد شخصًا واحدًا على الأقل.');
  const wanted = new Set(ids);
  const removedPeople = (session.recipients || []).filter(person => wanted.has(String(person.id)));
  if (!removedPeople.length) throw new Error('لم يتم العثور على الأشخاص المحددين في هذه الجلسة.');
  const removedIds = new Set(removedPeople.map(person => String(person.id)));
  const removedKeys = new Set([...removedIds].map(id => `r:${id}`));
  const removedChats = new Set(removedPeople.map(recipientChatId).filter(Boolean));
  const hadExplicitScheduleTargets = Array.isArray(session.settings?.scheduleTargetKeys) && session.settings.scheduleTargetKeys.length > 0;

  session.recipients = (session.recipients || []).filter(person => !removedIds.has(String(person.id)));
  session.settings ||= {};
  session.settings.scheduleTargetKeys = (session.settings.scheduleTargetKeys || []).filter(key => !removedKeys.has(String(key)));
  const scheduleDisabledToPreventWidening = hadExplicitScheduleTargets && session.settings.scheduleTargetKeys.length === 0;
  if (scheduleDisabledToPreventWidening) session.settings.scheduleEnabled = false;
  session.settings.interactionChatIds = (session.settings.interactionChatIds || []).filter(chat => !removedChats.has(String(chat || '').toLowerCase()));

  session.automation ||= {};
  session.automation.tasks = (session.automation.tasks || []).map(task => ({
    ...task,
    targetKeys: (task.targetKeys || []).filter(key => !removedKeys.has(String(key))),
  }));
  session.automation.rules = (session.automation.rules || []).map(rule => ({
    ...rule,
    targetKeys: Array.isArray(rule.targetKeys) ? rule.targetKeys.filter(key => !removedKeys.has(String(key))) : rule.targetKeys,
    targetChatIds: Array.isArray(rule.targetChatIds) ? rule.targetChatIds.filter(chat => !removedChats.has(String(chat || '').toLowerCase())) : rule.targetChatIds,
  }));

  session.interaction ||= {};
  for (const chat of removedChats) {
    if (session.interaction.contextByChat) delete session.interaction.contextByChat[chat];
    if (session.interaction.counterState?.byChat) delete session.interaction.counterState.byChat[chat];
  }

  return { deleted: removedPeople.map(person => ({ id: String(person.id), name: String(person.name || '') })), removedIds: [...removedIds], removedTargetKeys: [...removedKeys], scheduleDisabledToPreventWidening };
}

module.exports = { deleteRecipients, cleanUniqueIds, recipientChatId };
