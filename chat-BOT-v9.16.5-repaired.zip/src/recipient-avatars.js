'use strict';

function digitsFromRecipient(person = {}) {
  const raw = String(person.digits || person.e164 || person.phone || person.international || '').trim();
  const digits = raw.replace(/\D/g, '');
  return /^\d{5,25}$/.test(digits) ? digits : '';
}

function recipientJid(person = {}) {
  for (const candidate of [person.whatsappJid, person.waChatId, person.chatId]) {
    const value = String(candidate || '').trim().toLowerCase();
    if (/^\d{5,25}@c\.us$/.test(value)) return value;
  }
  const digits = digitsFromRecipient(person);
  return digits ? `${digits}@c.us` : '';
}

function safeAvatarFilename(value) {
  const name = String(value || '').split(/[\\/]/).pop();
  return /^recipient-[a-f0-9-]+\.(?:jpg|jpeg|png|webp|gif|avif)$/i.test(name) ? name : '';
}

function safeProfileFilename(value) {
  const name = String(value || '').split(/[\\/]/).pop();
  return /^[a-f0-9]{24}\.(?:jpg|jpeg|png|webp|gif|avif)$/i.test(name) ? name : '';
}

function avatarView(person, sessionId, updatedAt = '') {
  const recipient = { ...(person || {}) };
  const id = encodeURIComponent(String(recipient.id || ''));
  const session = encodeURIComponent(String(sessionId || 'main'));
  const jid = recipientJid(recipient);
  // Local replacements change immediately; use the session update timestamp so a cached WhatsApp
  // profile check cannot leave the user's newly uploaded avatar stuck in the browser cache.
  const version = encodeURIComponent(String(recipient.localAvatarFile ? (updatedAt || Date.now()) : (recipient.profileCheckedAt || updatedAt || Date.now())));
  let avatarUrl = '';
  if (recipient.localAvatarFile && safeAvatarFilename(recipient.localAvatarFile)) {
    avatarUrl = `/api/recipient/${id}/avatar?sessionId=${session}&v=${version}`;
  } else if (recipient.whatsappProfilePhoto && safeProfileFilename(recipient.whatsappProfilePhoto)) {
    avatarUrl = `/profile/${encodeURIComponent(recipient.whatsappProfilePhoto)}?sessionId=${session}&v=${version}`;
  } else if (recipient.whatsappAvatarFile || recipient.whatsappAvatarUrl) {
    avatarUrl = `/api/recipient/${id}/whatsapp-avatar?sessionId=${session}&v=${version}`;
  } else if (jid) {
    avatarUrl = `/api/whatsapp/contact-picture?sessionId=${session}&jid=${encodeURIComponent(jid)}`;
  }
  const displayName = String(recipient.localName || recipient.name || recipient.whatsappPushname || recipient.whatsappName || recipient.phone || '').trim() || 'بدون اسم';
  return { ...recipient, whatsappJid: String(recipient.whatsappJid || jid || ''), displayName, name: displayName, avatarUrl, localName: String(recipient.localName || '') };
}

function imageExtensionFromBuffer(buffer) {
  if (!Buffer.isBuffer(buffer)) return '';
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return '.jpg';
  if (buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) return '.png';
  if (buffer.length >= 12 && buffer.subarray(0, 4).toString('ascii') === 'RIFF' && buffer.subarray(8, 12).toString('ascii') === 'WEBP') return '.webp';
  if (buffer.length >= 6 && /^GIF8[79]a$/.test(buffer.subarray(0, 6).toString('ascii'))) return '.gif';
  if (buffer.length >= 12 && buffer.subarray(4, 8).toString('ascii') === 'ftyp' && /^(?:avif|avis)$/.test(buffer.subarray(8, 12).toString('ascii'))) return '.avif';
  return '';
}

module.exports = { digitsFromRecipient, recipientJid, safeAvatarFilename, safeProfileFilename, avatarView, imageExtensionFromBuffer };
