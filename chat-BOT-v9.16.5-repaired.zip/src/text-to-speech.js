'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawn: nodeSpawn } = require('node:child_process');
const { execFile: nodeExecFile } = require('node:child_process');
const { promisify } = require('node:util');
const execFileDefault = promisify(nodeExecFile);

const MAX_SPEECH_CHARS = 1800;
function resolveFromRoot(root, value, fallback = '') {
  const raw = String(value || fallback || '').trim();
  if (!raw) return '';
  if (path.isAbsolute(raw) || /^[A-Za-z]:[\\/]/.test(raw)) return raw;
  // Executable names such as `ffmpeg` and `piper` must remain PATH-resolved;
  // relative paths like tools/piper/piper.exe are resolved against the project.
  return /[\\/]/.test(raw) ? path.resolve(root, raw) : raw;
}
function normalizeSpeechText(value) {
  return String(value || '').normalize('NFC').replace(/\u0000/g, '').replace(/\r\n?/g, '\n')
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/!?\[[^\]]*\]\((https?:\/\/[^)]+)\)/g, 'رابط مرفق')
    .replace(/https?:\/\/\S+/giu, 'رابط')
    .replace(/[*_~>#|]/g, ' ')
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, ' ')
    .replace(/[ \t]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{3,}/g, '\n\n')
    .replace(/\s+([،؛.!؟,:])/g, '$1').replace(/([،؛:])(?=\S)/g, (match, punctuation, offset, source) => punctuation === ':' && /\d/.test(source[offset - 1] || '') && /\d/.test(source[offset + 1] || '') ? punctuation : `${punctuation} `)
    .trim();
}
function textTokensForPreservation(text) {
  return [...String(text || '').matchAll(/(?:\d{1,4}:\d{2}(?::\d{2})?|\d+(?:[.,٫٬]\d+)*|https?:\/\/\S+|[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})/g)].map(m => m[0]);
}
function normalizeGrammarCandidate(candidate, original) {
  const clean = normalizeSpeechText(candidate);
  if (!clean || clean.length > MAX_SPEECH_CHARS) return { text: original, used: false, reason: 'empty-or-too-long' };
  const before = textTokensForPreservation(original), after = textTokensForPreservation(clean);
  if (before.length !== after.length || before.some((token, i) => token !== after[i])) return { text: original, used: false, reason: 'protected-token-changed' };
  if (clean.length < original.length * 0.45 && original.length > 100) return { text: original, used: false, reason: 'content-may-have-been-omitted' };
  return { text: clean, used: true, reason: '' };
}

class TextToSpeech {
  constructor({ env = process.env, root = path.resolve(__dirname, '..'), spawnImpl = nodeSpawn, execFileImpl = execFileDefault, localLlm = null, tempRoot = os.tmpdir() } = {}) {
    this.env = env; this.root = root; this.spawn = spawnImpl; this.execFile = execFileImpl; this.localLlm = localLlm; this.tempRoot = tempRoot;
  }
  config() {
    const exe = process.platform === 'win32' ? 'piper.exe' : 'piper';
    const configuredBinary = resolveFromRoot(this.root, this.env.PIPER_BIN, path.join('tools', 'piper', exe));
    const binaryCandidates = [configuredBinary, process.platform === 'win32' ? path.join(this.root, '.voice-venv', 'Scripts', 'piper.exe') : '', path.join(this.root, 'tools', 'piper', exe)].filter(Boolean);
    const binary = binaryCandidates.find(candidate => /[\\/]/.test(candidate) && fs.existsSync(candidate) && fs.statSync(candidate).isFile()) || configuredBinary || path.join(this.root, 'tools', 'piper', exe);
    const configuredModel = resolveFromRoot(this.root, this.env.PIPER_MODEL_PATH, path.join('models', 'ar_JO-kareem-medium.onnx'));
    const modelPath = [configuredModel, path.join(this.root, 'models', 'ar_JO-kareem-medium.onnx')].find(candidate => fs.existsSync(candidate) && fs.statSync(candidate).isFile()) || configuredModel;
    const configuredFfmpeg = resolveFromRoot(this.root, this.env.FFMPEG_BIN, 'ffmpeg');
    const localFfmpeg = [path.join(this.root, 'tools', 'ffmpeg', 'bin', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg'), path.join(this.root, 'tools', 'ffmpeg', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg')].find(candidate => fs.existsSync(candidate) && fs.statSync(candidate).isFile());
    return {
      binary,
      modelPath,
      ffmpegBinary: localFfmpeg || configuredFfmpeg,
      root: this.root,
    };
  }
  async commandExists(command) {
    if (!command) return false;
    if (path.isAbsolute(command) || /[\\/]/.test(command)) return fs.existsSync(command) && fs.statSync(command).isFile();
    try { await this.execFile(process.platform === 'win32' ? 'where.exe' : 'which', [command], { timeout: 2500, windowsHide: true }); return true; } catch { return false; }
  }
  async status() {
    const cfg = this.config();
    const [binaryReady, ffmpegReady] = await Promise.all([this.commandExists(cfg.binary), this.commandExists(cfg.ffmpegBinary)]);
    const modelReady = Boolean(cfg.modelPath && fs.existsSync(cfg.modelPath) && fs.statSync(cfg.modelPath).isFile() && fs.statSync(cfg.modelPath).size > 10 * 1024 * 1024);
    return { ready: binaryReady && modelReady, binaryReady, modelReady, ffmpegReady, language: 'ar', voice: 'ar_JO-kareem-medium', mode: 'local',
      message: binaryReady && modelReady ? (ffmpegReady ? 'النطق العربي المحلي جاهز لإنتاج صوت وتهيئته كرسالة صوتية.' : 'النطق المحلي جاهز للمعاينة؛ يلزم FFmpeg لإرسال تسجيل OGG/Opus كرسالة صوتية.') : `محرك Piper: ${binaryReady ? 'موجود' : 'غير موجود'}؛ نموذج العربية: ${modelReady ? 'موجود' : 'غير موجود'}. سيُعدّ البوت محرك النطق العربي تلقائيًا عند التشغيل الأول لإعدادهما.` };
  }
  async prepareText(text, { proofread = false, model = 'qwen2.5:3b', timeoutMs = 18000 } = {}) {
    const original = normalizeSpeechText(text);
    if (!original) throw new Error('لا يوجد نص صالح لتحويله إلى كلام.');
    if (original.length > MAX_SPEECH_CHARS || String(text || '').length > 10000) throw new Error('النص طويل جدًا؛ اختصر الرد إلى 1800 حرف كحد أقصى للنطق.');
    if (!proofread || !this.localLlm) return { text: original, proofreadUsed: false, proofreadReason: proofread ? 'local-llm-unavailable' : 'disabled' };
    try {
      const candidate = await this.localLlm.generate({ model, timeoutMs, maxTokens: 420,
        system: 'أنت مدقق لغوي عربي دقيق. صحح الإملاء والنحو وعلامات الترقيم فقط، واجعل النص عربيًا فصيحًا واضحًا مناسبًا للقراءة الصوتية. لا تجب عن النص ولا تلخصه ولا تضف أي معلومة. حافظ على جميع الأسماء والأرقام والتواريخ والروابط والحقائق والمعنى. أخرج النص المصحح وحده بلا مقدمات أو علامات اقتباس أو Markdown.',
        messages: [{ role: 'user', content: original }] });
      const checked = normalizeGrammarCandidate(candidate, original);
      return { text: checked.text, proofreadUsed: checked.used, proofreadReason: checked.reason };
    } catch (error) {
      return { text: original, proofreadUsed: false, proofreadReason: `local-review-unavailable: ${String(error?.message || error).slice(0, 160)}` };
    }
  }
  async generate(text, { proofread = false, model = 'qwen2.5:3b', timeoutMs = 18000 } = {}) {
    const cfg = this.config(), status = await this.status();
    if (!status.binaryReady) throw new Error('محرك Piper المحلي غير جاهز. سيُعدّ البوت محرك النطق العربي تلقائيًا عند التشغيل الأول أو عيّن PIPER_BIN في .env.');
    if (!status.modelReady) throw new Error('نموذج النطق العربي المحلي غير موجود. سيُعدّ البوت محرك النطق العربي تلقائيًا عند التشغيل الأول.');
    const prepared = await this.prepareText(text, { proofread, model, timeoutMs });
    const dir = fs.mkdtempSync(path.join(this.tempRoot, 'chatbot-tts-'));
    const wavPath = path.join(dir, `speech-${crypto.randomUUID()}.wav`);
    try {
      await new Promise((resolve, reject) => {
        let settled = false;
        let timer = null;
        const finish = error => { if (settled) return; settled = true; if (timer) clearTimeout(timer); error ? reject(error) : resolve(); };
        let child;
        try { child = this.spawn(cfg.binary, ['--model', cfg.modelPath, '--output_file', wavPath], { cwd: cfg.root, windowsHide: true, stdio: ['pipe', 'ignore', 'pipe'] }); }
        catch (error) { finish(error); return; }
        let stderr = '';
        child.stderr?.on('data', chunk => { stderr = (stderr + String(chunk)).slice(-4000); });
        child.once('error', error => finish(new Error(`تعذر تشغيل Piper: ${String(error?.message || error).slice(0, 200)}`)));
        child.once('close', code => {
          if (code !== 0) return finish(new Error(`فشل توليد الكلام (رمز ${code}): ${stderr.slice(-700)}`));
          try { const stat = fs.statSync(wavPath); if (stat.size < 128 || stat.size > 50 * 1024 * 1024) throw new Error('حجم ملف الصوت الناتج غير صالح.'); }
          catch (error) { return finish(error); }
          finish();
        });
        timer = setTimeout(() => { try { child.kill('SIGTERM'); } catch {} finish(new Error('انتهت مهلة تحويل النص إلى كلام. جرّب ردًا أقصر أو افحص موارد الجهاز.')); }, Math.max(5000, Math.min(120000, Number(this.env.TTS_TIMEOUT_MS) || 45000)));
        child.stdin.on('error', error => finish(new Error(`تعذر تمرير النص إلى محرك النطق: ${String(error?.message || error).slice(0, 150)}`)));
        child.stdin.end(prepared.text + '\n');
      });
      return { ...prepared, wavPath, directory: dir, bytes: fs.statSync(wavPath).size, voice: 'ar_JO-kareem-medium', language: 'ar', mimeType: 'audio/wav' };
    } catch (error) {
      try { fs.rmSync(dir, { recursive: true, force: true }); } catch {}
      throw error;
    }
  }
  async toWhatsAppVoice(wavPath) {
    const cfg = this.config();
    if (!wavPath || !fs.existsSync(wavPath) || !fs.statSync(wavPath).isFile()) throw new Error('ملف الصوت الناتج غير موجود.');
    if (!await this.commandExists(cfg.ffmpegBinary)) throw new Error('يلزم FFmpeg لتحويل WAV إلى OGG/Opus قبل إرساله كرسالة صوتية. شغّل أداة إعداد الصوت وتأكد من FFMPEG_BIN.');
    const output = path.join(path.dirname(wavPath), `voice-${crypto.randomUUID()}.ogg`);
    try {
      await this.execFile(cfg.ffmpegBinary, ['-y', '-i', wavPath, '-vn', '-ac', '1', '-ar', '48000', '-c:a', 'libopus', '-b:a', '32k', '-vbr', 'on', output], { timeout: 90000, maxBuffer: 1024 * 1024, windowsHide: true });
      const stat = fs.statSync(output);
      if (!stat.isFile() || stat.size < 100) throw new Error('لم ينتج FFmpeg ملف OGG/Opus صالحًا.');
      return output;
    } catch (error) {
      try { fs.rmSync(output, { force: true }); } catch {}
      throw new Error(`تعذر تجهيز الصوت كرسالة WhatsApp صوتية: ${String(error?.message || error).slice(0, 400)}`);
    }
  }
  cleanup(result) { const dir = String(result?.directory || (result?.wavPath ? path.dirname(result.wavPath) : '')); if (dir && path.basename(dir).startsWith('chatbot-tts-')) { try { fs.rmSync(dir, { recursive: true, force: true }); return true; } catch {} } return false; }
}

module.exports = { TextToSpeech, MAX_SPEECH_CHARS, normalizeSpeechText, normalizeGrammarCandidate, textTokensForPreservation, resolveFromRoot };
