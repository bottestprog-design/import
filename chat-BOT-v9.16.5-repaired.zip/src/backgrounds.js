"use strict";
const MODES = new Set(["aurora","nebula","meteor","matrix","cyber-grid","plasma","starfield","vortex","galaxy","ocean"]);
const DEFAULT = { speed:1, density:1, glow:.6, intensity:1, mouseStrength:1, brightness:1, contrast:1, saturation:1, hueRotate:0, blur:0, interactive:true, trail:true };
const clamp=(v,a,b,d)=>Number.isFinite(Number(v))?Math.max(a,Math.min(b,Number(v))):d;
function normalize(mode,settings,opacity){
  const m=MODES.has(mode)?mode:"aurora", s={...DEFAULT,...(settings||{})};
  s.speed=clamp(s.speed,.1,3,DEFAULT.speed);
  s.density=clamp(s.density,.2,2,DEFAULT.density);
  s.glow=clamp(s.glow,0,1,DEFAULT.glow);
  s.intensity=clamp(s.intensity,.2,1.8,DEFAULT.intensity);
  s.mouseStrength=clamp(s.mouseStrength,0,2,DEFAULT.mouseStrength);
  s.brightness=clamp(s.brightness,.5,1.5,DEFAULT.brightness);
  s.contrast=clamp(s.contrast,.6,1.5,DEFAULT.contrast);
  s.saturation=clamp(s.saturation,.3,1.8,DEFAULT.saturation);
  s.hueRotate=clamp(s.hueRotate,0,360,DEFAULT.hueRotate);
  s.blur=clamp(s.blur,0,8,DEFAULT.blur);
  s.interactive=s.interactive!==false; s.trail=s.trail!==false;
  return {mode:m,settings:s,opacity:clamp(opacity,.08,.75,.22)};
}
module.exports={MODES,DEFAULT,normalize};
