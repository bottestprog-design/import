"use strict";
function clean(v){return String(v||'').normalize('NFKC').trim().toLowerCase()}
function jidOf(v){ if(!v)return ''; if(typeof v==='string')return v; const x=v||{}; const id=x.id||null; const remote=x.remote||null; const candidate=x._serialized||x.$1||id?._serialized||id?.$1||remote?._serialized||remote?.$1||''; return String(candidate); }
function person(v){ const rawId = typeof v === 'string' ? v : (v?.id || v); return { id: jidOf(rawId).toLowerCase(), name:String(v?.name||v?.pushname||v?.notifyName||v?.formattedName||'').slice(0,120), admin:Boolean(v?.isAdmin||v?.isSuperAdmin||v?.admin) }; }
function normalizeGid(v){
  let s=clean(v).replace(/^jid[:=]\s*/,'').replace(/^whatsapp:\/\//,'');
  s=s.replace(/^(?:https?:\/\/)?[^/]+\/jid\//,'');
  if(/^\d+(?:-\d+)*$/.test(s))s+='@g.us';
  if(!/^\d+(?:-\d+)*@g\.us$/i.test(s))throw new Error('GID غير صالح. استخدم مثل 120363000000-123@g.us');
  return s;
}
function isGroupId(v){try{normalizeGid(v);return true}catch{return false}}
function extractInviteCode(v){
  const s=String(v||'').trim();
  const link=s.match(/^(?:https?:\/\/)?chat\.whatsapp\.com\/([A-Za-z0-9_-]{6,64})(?:[?#].*)?$/i);
  if(link) return link[1];
  return /^[A-Za-z0-9_-]{6,64}$/.test(s) ? s : '';
}
function fromChat(chat){
  const id=chat?.id; const gid=jidOf(id).toLowerCase();
  const rawParticipants = Array.isArray(chat?.participants) ? chat.participants : (Array.isArray(chat?.groupMetadata?.participants) ? chat.groupMetadata.participants : []);
  const participants=rawParticipants.map(person).filter(x=>x.id).slice(0,2000);
  const admins=participants.filter(x=>x.admin);
  return {gid,name:String(chat?.name||chat?.subject||'مجموعة').slice(0,120),description:String(chat?.description||'').slice(0,1000),owner:jidOf(chat?.groupMetadata?.owner),participantsCount:participants.length || (Number.isFinite(Number(chat?.groupMetadata?.size)) ? Number(chat.groupMetadata.size) : null),participants,admins};
}
function normalizeInfo(info,gid=''){const participants=Array.isArray(info?.participants)?info.participants.map(person).filter(x=>x.id).slice(0,2000):[];const admins=Array.isArray(info?.admins)?info.admins.map(person).filter(x=>x.id).slice(0,500):participants.filter(x=>x.admin);return {name:String(info?.name||info?.subject||'مجموعة').slice(0,120),gid:String(info?.gid||gid||'').trim().toLowerCase(),inviteCode:String(info?.inviteCode||''),description:String(info?.description||'').slice(0,1000),owner:String(info?.owner||''),participantsCount:Number.isFinite(Number(info?.participantsCount??info?.size))?Number(info?.participantsCount??info?.size):(participants.length||null),participants,admins}}
function formatGroupAnalysis(info){const x=normalizeInfo(info);const people=x.participants.map(p=>`- ${p.name||'بدون اسم'} | ${p.id}${p.admin?' | مشرف':''}`).join('\n');return `الاسم: ${x.name}\nGID: ${x.gid||'غير متاح'}\nالأعضاء: ${x.participantsCount??'غير معروف'}\nالمشرفون: ${x.admins.length}\nالمالك: ${x.owner||'غير معروف'}\nالوصف: ${x.description||'—'}\nرمز الدعوة: ${x.inviteCode||'غير متاح'}${people?`\n\nالأعضاء:\n${people}`:''}`;}
module.exports={normalizeGid,isGroupId,extractInviteCode,normalizeInfo,formatGroupAnalysis,fromChat};
