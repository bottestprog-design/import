'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFile: nodeExecFile } = require('node:child_process');
const { promisify } = require('node:util');
const execFileDefault = promisify(nodeExecFile);
const MAX_AUDIO_BYTES = 25 * 1024 * 1024;
const AUDIO_EXTENSIONS = new Set(['.ogg', '.opus', '.mp3', '.m4a', '.mp4', '.wav', '.webm', '.aac', '.flac']);
const MIME_EXT = { 'audio/ogg': '.ogg', 'audio/opus': '.opus', 'audio/mpeg': '.mp3', 'audio/mp3': '.mp3', 'audio/mp4': '.m4a', 'audio/x-m4a': '.m4a', 'audio/wav': '.wav', 'audio/x-wav': '.wav', 'audio/webm': '.webm', 'audio/aac': '.aac', 'audio/flac': '.flac' };
const langNames = { ar: 'Arabic', en: 'English', fr: 'French', de: 'German', es: 'Spanish', ur: 'Urdu', hi: 'Hindi', tr: 'Turkish' };
const execErrorText = error => String(error?.message || error || 'خطأ تشغيل غير معروف').replace(/https?:\/\/\S+/gi, '[رابط خدمة]').replace(/(?:[A-Za-z]:\\(?:[^\\\s]+\\)*[^\s,;]*)/g, '[مسار محلي]').replace(/(?:\/[^\s,;]+){2,}/g, '[مسار محلي]').slice(0, 240);

function allowedLanguage(value) {
  const lang = String(value || 'ar').toLowerCase().trim();
  if (!Object.prototype.hasOwnProperty.call(langNames, lang)) throw new Error('لغة التفريغ غير مدعومة. اختر العربية أو الإنجليزية أو إحدى اللغات الموجودة في القائمة.');
  return lang;
}
function safeAudioExtension(name, mimetype = '') {
  const fromName = path.extname(String(name || '')).toLowerCase();
  if (AUDIO_EXTENSIONS.has(fromName)) return fromName;
  const mime = String(mimetype || '').split(';')[0].trim().toLowerCase();
  return MIME_EXT[mime] || '';
}
function loopbackSafeEnvPath(value, fallback) { return String(value || fallback).trim() || fallback; }

class AudioTranscriber {
  constructor({ env = process.env, execFileImpl = execFileDefault, logger = () => {}, tempDir = os.tmpdir(), maxAudioBytes = MAX_AUDIO_BYTES } = {}) {
    this.env = env;
    this.execFile = execFileImpl;
    this.log = logger;
    this.tempDir = tempDir;
    this.maxAudioBytes = Math.max(1024 * 1024, Math.min(50 * 1024 * 1024, Number(maxAudioBytes) || MAX_AUDIO_BYTES));
    this.latestBySession = new Map();
  }
  config() {
    const backend = String(this.env.WHISPER_BACKEND || 'whisper.cpp').trim().toLowerCase();
    const root = path.resolve(__dirname, '..');
    const platformExe = process.platform === 'win32' ? '.exe' : '';
    const resolveConfigured = value => {
      const text = String(value || '').trim();
      if (!text) return '';
      return path.isAbsolute(text) ? text : path.resolve(root, text);
    };
    const resolveCommand = value => {
      const text = String(value || '').trim();
      if (!text) return '';
      if (path.isAbsolute(text) || text.includes('/') || text.includes('\\')) return path.isAbsolute(text) ? text : path.resolve(root, text);
      return text; // bare executable names are searched on PATH
    };
    const firstExisting = candidates => candidates.find(candidate => {
      try { return fs.existsSync(candidate) && fs.statSync(candidate).isFile(); } catch { return false; }
    }) || '';
    const localBinaries = [
      path.join(root, 'tools', 'whisper', `whisper-cli${platformExe}`),
      path.join(root, 'tools', 'whisper', 'bin', `whisper-cli${platformExe}`),
      path.join(root, 'whisper.cpp', 'build', 'bin', `whisper-cli${platformExe}`),
      path.join(root, 'build', 'bin', `whisper-cli${platformExe}`),
      path.join(root, 'tools', 'whisper', `main${platformExe}`),
    ];
    const configuredBinaryText = String(this.env.WHISPER_CPP_BIN || '').trim();
    let binary = resolveCommand(configuredBinaryText);
    const knownBareExecutables = ['whisper-cli', 'whisper', 'whisper-cli.exe', 'main', 'main.exe'];
    // A stale absolute/relative path from a previous setup must not hide a valid
    // executable installed under this project. If none exists, retain the configured
    // path so status() can report the missing executable clearly.
    if (!binary) {
      binary = firstExisting(localBinaries) || (backend === 'whisper' ? 'whisper' : `whisper-cli${platformExe}`);
    } else if (knownBareExecutables.includes(configuredBinaryText.toLowerCase())) {
      binary = firstExisting(localBinaries) || binary;
    } else if ((path.isAbsolute(binary) || /[\\/]/.test(binary)) && !fs.existsSync(binary)) {
      binary = firstExisting(localBinaries) || binary;
    }
    const configuredModelCandidate = resolveConfigured(this.env.WHISPER_MODEL_PATH);
    const configuredModel = configuredModelCandidate && fs.existsSync(configuredModelCandidate) && fs.statSync(configuredModelCandidate).isFile() ? configuredModelCandidate : '';
    const modelCandidates = [
      path.join(root, 'models', 'ggml-large-v3-turbo.bin'),
      path.join(root, 'models', 'ggml-small.bin'),
      path.join(root, 'models', 'ggml-base.bin'),
      path.join(root, 'tools', 'whisper', 'models', 'ggml-base.bin'),
    ];
    const modelPath = configuredModel || firstExisting(modelCandidates) || path.join(root, 'models', 'ggml-small.bin');
    const configuredFfmpegCandidate = resolveConfigured(this.env.FFMPEG_BIN);
    const configuredFfmpeg = configuredFfmpegCandidate && fs.existsSync(configuredFfmpegCandidate) && fs.statSync(configuredFfmpegCandidate).isFile() ? configuredFfmpegCandidate : '';
    const localFfmpeg = firstExisting([
      path.join(root, 'tools', 'ffmpeg', 'bin', `ffmpeg${platformExe}`),
      path.join(root, 'tools', 'ffmpeg', `ffmpeg${platformExe}`),
    ]);
    const rawFfmpeg = String(this.env.FFMPEG_BIN || '').trim();
    const ffmpegBinary = (configuredFfmpeg && !(rawFfmpeg.toLowerCase() === 'ffmpeg' || rawFfmpeg.toLowerCase() === 'ffmpeg.exe'))
      ? configuredFfmpeg : (localFfmpeg || rawFfmpeg || 'ffmpeg');
    return { backend: ['whisper.cpp', 'whisper'].includes(backend) ? backend : 'whisper.cpp', binary, modelPath, ffmpegBinary };
  }
  async commandExists(binary) {
    if (path.isAbsolute(binary) || binary.includes(path.sep)) return fs.existsSync(binary);
    try { await this.execFile(process.platform === 'win32' ? 'where.exe' : 'which', [binary], { timeout: 2000, maxBuffer: 64 * 1024 }); return true; } catch { return false; }
  }
  async status() {
    const cfg = this.config();
    let binaryAvailable = false, modelAvailable = false, ffmpegAvailable = false;
    try { binaryAvailable = await this.commandExists(cfg.binary); } catch {}
    try { modelAvailable = Boolean(cfg.modelPath && fs.existsSync(cfg.modelPath) && fs.statSync(cfg.modelPath).isFile()); } catch { modelAvailable = false; }
    try { ffmpegAvailable = cfg.backend === 'whisper.cpp' ? await this.commandExists(cfg.ffmpegBinary) : false; } catch { ffmpegAvailable = false; }
    const engineModelReady = binaryAvailable && modelAvailable;
    const voiceNotesReady = engineModelReady && (cfg.backend !== 'whisper.cpp' || ffmpegAvailable);
    const statusMessage = !binaryAvailable || !modelAvailable
      ? `التفريغ الصوتي المحلي غير مهيأ بالكامل. ${!binaryAvailable ? `لم أعثر على البرنامج ${path.basename(cfg.binary)}. ` : ''}${!modelAvailable ? `ملف النموذج غير موجود (${path.basename(cfg.modelPath)}). ` : ''}${process.platform === 'win32' ? 'شغّل SETUP-VOICE-WINDOWS.bat من مجلد المشروع لإعداد المحرك والنموذج تلقائيًا. ' : 'راجع docs/VOICE_SETUP_AR.md لإعداد Whisper والنموذج محليًا. '}لا تُرفع الملفات الصوتية إلى خدمة خارجية.`
      : !voiceNotesReady
        ? `المحرك والنموذج موجودان، لكن تفريغ فويسات WhatsApp غير جاهز لأن FFmpeg غير موجود. ثبّت FFmpeg أو شغّل أداة إعداد الصوت؛ لن أعتبر الصوتيات جاهزة قبل نجاح التحويل المحلي. لا تُرسل الصوتيات إلى خدمة سحابية.`
        : `محرك التفريغ المحلي جاهز (${cfg.backend}). ${ffmpegAvailable ? 'تحويل OGG/OPUS جاهز عبر FFmpeg.' : 'قد لا تعمل صوتيات OGG/OPUS.'} لا يُرسل الصوت إلى أي خدمة سحابية.`;
    return {
      ready: voiceNotesReady,
      engineModelReady,
      voiceNotesReady,
      backend: cfg.backend,
      binary: cfg.binary,
      modelConfigured: Boolean(String(this.env.WHISPER_MODEL_PATH || '').trim() || modelAvailable),
      binaryAvailable,
      modelAvailable,
      ffmpegAvailable,
      binaryLabel: path.basename(cfg.binary),
      modelLabel: path.basename(cfg.modelPath),
      ffmpegLabel: path.basename(cfg.ffmpegBinary),
      setupCommand: process.platform === 'win32' ? 'شغّل SETUP-VOICE-WINDOWS.bat من مجلد المشروع' : 'راجع docs/VOICE_SETUP_AR.md لتثبيت whisper.cpp وملف النموذج وFFmpeg محليًا',
      formatSupportNotice: cfg.backend === 'whisper.cpp' && !ffmpegAvailable ? 'FFmpeg غير موجود؛ صوتيات WhatsApp بصيغة OGG/OPUS تحتاج عادةً تحويلًا إلى WAV محليًا. شغّل أداة إعداد الصوت أو ثبّت FFmpeg.' : '',
      maxAudioBytes: this.maxAudioBytes,
      recentAudioCount: [...this.latestBySession.values()].reduce((sum, item) => sum + (Date.now() - item.at < 24 * 60 * 60 * 1000 ? 1 : 0), 0),
      message: statusMessage,
    };
  }
  rememberIncoming(sessionId, msg) {
    if (!msg || msg.fromMe === true && msg.__chatBotProgrammatic) return false;
    const type = String(msg.type || '').toLowerCase();
    const mime = String(msg?._data?.mimetype || msg?.mimetype || msg?._data?.mediaData?.mimetype || '').toLowerCase();
    const hasAudio = ['audio', 'ptt', 'voice'].includes(type) || mime.startsWith('audio/');
    if (!hasAudio || msg.hasMedia === false || typeof msg.downloadMedia !== 'function') return false;
    const sid = String(sessionId || 'main');
    this.latestBySession.set(sid, { message: msg, at: Date.now(), type, mime });
    if (this.latestBySession.size > 200) {
      for (const [key, item] of this.latestBySession) if (Date.now() - item.at > 24 * 60 * 60 * 1000 || this.latestBySession.size > 180) this.latestBySession.delete(key);
    }
    return true;
  }
  async transcribeLatest(sessionId, { language = 'ar' } = {}) {
    const item = this.latestBySession.get(String(sessionId || 'main'));
    if (!item || Date.now() - item.at > 24 * 60 * 60 * 1000) throw new Error('لم أعثر على صوتية حديثة محفوظة في الذاكرة. أرسل الصوتية إلى محادثة WhatsApp التي يتصل بها البوت، ثم اطلب «فرّغ آخر صوتية».');
    return this.transcribeMessage(item.message, { language, source: 'whatsapp' });
  }
  async transcribeMessage(message, { language = 'ar', source = 'whatsapp' } = {}) {
    if (typeof message?.downloadMedia !== 'function') throw new Error('هذه الرسالة لا توفر ملفًا صوتيًا قابلًا للتنزيل من WhatsApp.');
    let media;
    try { media = await message.downloadMedia(); } catch { throw new Error('تعذر تحميل الصوت من WhatsApp. تحقق من الاتصال وأعد إرسال الصوتية إذا انتهت صلاحيتها.'); }
    if (!media?.data || typeof media.data !== 'string') throw new Error('لم يوفر WhatsApp محتوى الصوتية؛ قد تكون غير متاحة أو منتهية الصلاحية.');
    const mime = String(media.mimetype || message?._data?.mimetype || 'audio/ogg').split(';')[0].toLowerCase();
    const ext = safeAudioExtension(`voice${path.extname(String(media.filename || ''))}`, mime) || '.ogg';
    // Avoid allocating a decoded buffer for an oversized/corrupt data URL or
    // arbitrary string that only happens to be present in the media payload.
    const encoded = media.data.replace(/\s+/g, '');
    if (!/^[A-Za-z0-9+/]*={0,2}$/.test(encoded) || encoded.length % 4 === 1) throw new Error('WhatsApp أعاد بيانات صوت غير صالحة؛ أعد إرسال الصوتية ثم حاول مجددًا.');
    if (encoded.length > Math.ceil(this.maxAudioBytes * 4 / 3) + 8) throw new Error(`حجم الصوت يتجاوز الحد (${Math.round(this.maxAudioBytes / 1024 / 1024)} MB).`);
    const bytes = Buffer.from(encoded, 'base64');
    if (!bytes.length || bytes.length > this.maxAudioBytes) throw new Error(`حجم الصوت غير صالح أو تجاوز الحد (${Math.round(this.maxAudioBytes / 1024 / 1024)} MB).`);
    return this.transcribeBuffer(bytes, { extension: ext, language, source });
  }
  async transcribeFile(filePath, { originalName = '', mimetype = '', language = 'ar' } = {}) {
    const ext = safeAudioExtension(originalName || filePath, mimetype);
    if (!ext) throw new Error('صيغة الصوت غير مدعومة. استخدم OGG/OPUS أو MP3 أو M4A أو WAV أو WEBM أو FLAC.');
    const stat = fs.statSync(filePath);
    if (!stat.isFile() || stat.size < 1 || stat.size > this.maxAudioBytes) throw new Error(`حجم الملف الصوتي يجب أن يكون بين 1 بايت و${Math.round(this.maxAudioBytes / 1024 / 1024)} MB.`);
    return this.transcribeBuffer(fs.readFileSync(filePath), { extension: ext, language, source: 'upload' });
  }
  async transcribeBuffer(buffer, { extension = '.ogg', language = 'ar', source = 'upload' } = {}) {
    const lang = allowedLanguage(language);
    const cfg = this.config();
    if (!await this.commandExists(cfg.binary)) throw new Error(`محرك التفريغ غير موجود (${cfg.binary}). ثبّت whisper.cpp ثم حدّد WHISPER_CPP_BIN في .env.`);
    if (!cfg.modelPath || !fs.existsSync(cfg.modelPath) || !fs.statSync(cfg.modelPath).isFile()) throw new Error('ملف نموذج Whisper المحلي غير محدد أو غير موجود. حدّد WHISPER_MODEL_PATH في .env.');
    if (!Buffer.isBuffer(buffer) || !buffer.length || buffer.length > this.maxAudioBytes) throw new Error('بيانات الصوت فارغة أو تتجاوز الحد المسموح.');
    const ffmpegReady = cfg.backend === 'whisper.cpp' && await this.commandExists(cfg.ffmpegBinary);
    if (cfg.backend === 'whisper.cpp' && ['.ogg', '.opus', '.webm', '.m4a', '.mp4', '.aac'].includes(String(extension).toLowerCase()) && !ffmpegReady) {
      throw new Error('تعذر تفريغ صوتية WhatsApp لأن FFmpeg غير موجود. شغّل SETUP-VOICE-WINDOWS.bat أو ثبّت FFmpeg محليًا ثم أعد تشغيل البوت.');
    }
    const work = fs.mkdtempSync(path.join(this.tempDir, 'chatbot-whisper-'));
    const input = path.join(work, `input${AUDIO_EXTENSIONS.has(extension) ? extension : '.ogg'}`);
    const outputBase = path.join(work, 'transcript');
    const outputTxt = cfg.backend === 'whisper' ? path.join(work, 'input.txt') : `${outputBase}.txt`;
    try {
      fs.writeFileSync(input, buffer, { flag: 'wx', mode: 0o600 });
      let effectiveInput = input;
      // WhatsApp voice notes are commonly OGG/OPUS. whisper.cpp installations
      // without FFmpeg support may accept only 16-bit WAV, so transcode locally
      // whenever FFmpeg is available. If the whisper.cpp binary was built with
      // its own FFmpeg support, falling back to the original input is still valid.
      if (cfg.backend === 'whisper.cpp' && ffmpegReady) {
        const wavInput = path.join(work, 'input-16khz-mono.wav');
        try {
          await this.execFile(cfg.ffmpegBinary, ['-y', '-i', input, '-ar', '16000', '-ac', '1', '-c:a', 'pcm_s16le', wavInput], { timeout: 120000, maxBuffer: 1024 * 1024, windowsHide: true, cwd: work });
          const wavStat = fs.statSync(wavInput);
          if (!wavStat.isFile() || wavStat.size <= 44) throw new Error('لم ينتج FFmpeg ملف WAV صالحًا.');
          effectiveInput = wavInput;
        } catch (error) {
          if (!['.wav'].includes(extension.toLowerCase())) {
            throw new Error(`تعذر تحويل الصوت محليًا بواسطة FFmpeg: ${execErrorText(error)}. ثبّت FFmpeg أو شغّل أداة SETUP-VOICE-WINDOWS.bat (Windows)، أو استخدم ملف WAV بصيغة PCM 16-bit.`);
          }
          this.log('WARN', `تعذر تحويل WAV؛ ستتم محاولة قراءة الملف الأصلي: ${execErrorText(error)}`);
        }
      }
      let args;
      if (cfg.backend === 'whisper') {
        args = [effectiveInput, '--model', cfg.modelPath, '--language', langNames[lang], '--task', 'transcribe', '--output_format', 'txt', '--output_dir', work, '--fp16', 'False'];
      } else {
        args = ['-m', cfg.modelPath, '-f', effectiveInput, '-l', lang, '-nt', '-np', '-otxt', '-of', outputBase];
      }
      let execution = { stdout: '' };
      try { execution = await this.execFile(cfg.binary, args, { timeout: 180000, maxBuffer: 3 * 1024 * 1024, windowsHide: true, cwd: work }); }
      catch (error) {
        if (fs.existsSync(outputTxt)) this.log('WARN', `عاد محرك التفريغ برمز خطأ لكن ملف النص موجود: ${execErrorText(error)}`);
        else throw new Error(`فشل التفريغ الصوتي المحلي: ${execErrorText(error)}. تحقق من توافق النموذج والبرنامج.`);
      }
      let transcript = '';
      try { transcript = fs.readFileSync(outputTxt, 'utf8').trim(); } catch {}
      if (!transcript) transcript = String(execution.stdout || '').trim();
      transcript = transcript.replace(/\[BLANK_AUDIO\]/g, '').replace(/\s+/g, ' ').trim().slice(0, 12000);
      if (!transcript) throw new Error('لم يستطع Whisper استخراج كلمات واضحة من الصوت. جرّب صوتًا أوضح أو نموذجًا أدق.');
      return { ok: true, transcript, language: lang, source, backend: cfg.backend, bytes: buffer.length, createdAt: new Date().toISOString(), message: 'اكتمل التفريغ داخل الجهاز المحلي.' };
    } finally {
      try { fs.rmSync(work, { recursive: true, force: true }); } catch {}
    }
  }
}

module.exports = { AudioTranscriber, MAX_AUDIO_BYTES, AUDIO_EXTENSIONS, safeAudioExtension, allowedLanguage };
