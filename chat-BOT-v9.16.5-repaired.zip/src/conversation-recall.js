'use strict';

const crypto = require('node:crypto');
const { isFromMeMessage } = require('./message-identifiers');

function normalize(value) {
  return String(value || '').normalize('NFKC').toLocaleLowerCase('ar')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[إأآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
    .replace(/[\u200e\u200f]/g, '').replace(/[،؛.!؟?]/g, ' ').replace(/\s+/g, ' ').trim();
}

function parseRecallCommand(text) {
  const normalized = normalize(text);
  let match = normalized.match(/^(?:ابحث|دور|فتش|بحث)\s+(?:في|داخل)\s+(?:محادثه|شات|دردشه)\s+(.+?)\s+(?:عن|على)\s+(.+)$/u);
  if (match) {
    const targetQuery = match[1].trim(), query = match[2].trim();
    if (targetQuery && query) return { kind: 'search', targetQuery, query, scanLimit: 500 };
  }
  match = normalized.match(/^(?:هات|جيب|اعرض|وريني|استرجع|اقرا|اقرالي|اعرضلي)\s+(?:لي\s+)?(?:اخر\s+)?(\d{1,2})\s+(?:رسائل|رسايل|الرسائل|الرسايل|رساله|رسايل)\s+(?:من|في)\s+(?:(?:محادثه|شات|دردشه)\s+)?(.+)$/u);
  if (match) {
    const count = Math.max(1, Math.min(50, Number(match[1]) || 10));
    const targetQuery = match[2].trim();
    if (targetQuery) return { kind: 'recent', targetQuery, count, scanLimit: count };
  }
  return null;
}

function resolveRegisteredTarget(session, targetQuery, selfChatId = '') {
  const query = normalize(targetQuery);
  if (!query) return { status: 'missing' };
  const selfAliases = new Set(['البوت', 'محادثه البوت', 'محادثتك مع البوت', 'محادثه النفس', 'النفس', 'مع البوت', 'نفسك', 'self']);
  const all = [
    { key: 'self', id: String(selfChatId || '').trim().toLowerCase(), label: 'محادثة البوت معك', type: 'self', isGroup: false },
    ...(session.recipients || []).map(person => {
      const phone = String(person.e164 || person.phone || person.digits || person.number || person.international || '').replace(/\D/g, '');
      const jid = String(person.whatsappJid || person.chatId || person.jid || '').trim().toLowerCase();
      return { key: `r:${String(person.id)}`, id: /^(?:\d{5,25}@c\.us|\d{5,25}@lid)$/i.test(jid) ? jid : (phone.length >= 5 ? `${phone}@c.us` : ''), label: String(person.name || person.international || person.phone || 'شخص بدون اسم').slice(0,160), type: 'recipient', isGroup: false };
    }),
    ...(session.groups || []).map(group => ({ key: `g:${String(group.id)}`, id: String(group.gid || group.chatId || '').trim().toLowerCase(), label: String(group.name || group.gid || 'مجموعة').slice(0,160), type: 'group', isGroup: true })),
  ].filter(row => row.key === 'self' || row.id);
  if (selfAliases.has(query)) {
    const self = all.find(row => row.key === 'self');
    return self?.id ? { status: 'ok', target: self } : { status: 'unavailable', message: 'معرّف محادثة البوت غير متاح. تحقق من اتصال WhatsApp.' };
  }
  const targets = all.filter(row => row.key !== 'self');
  const exact = targets.filter(row => normalize(row.label) === query || normalize(row.id) === query || normalize(row.id.split('@')[0]) === query);
  const matches = exact.length ? exact : targets.filter(row => normalize(`${row.label} ${row.id}`).includes(query));
  if (matches.length === 1) return { status: matches[0].id ? 'ok' : 'unavailable', target: matches[0], message: matches[0].id ? '' : 'الجهة مسجلة لكن ليس لها معرّف WhatsApp مؤكد؛ حدّث بياناتها من قسم الأشخاص.' };
  if (matches.length > 1) return { status: 'ambiguous', matches: matches.slice(0, 8).map(row => ({ key: row.key, label: row.label, type: row.type })) };
  return { status: 'not-registered' };
}

function rowFromMessage(message, target, chatId) {
  const timestamp = Number(message?.timestamp || message?._data?.t || Date.now() / 1000);
  const fromMe = isFromMeMessage(message) || message?._data?.id?.id?.fromMe === true;
  const rawId = message?.id?._serialized || message?.id?.$1 || message?._data?.id?._serialized || message?._data?.id?.$1 || message?.id?.id?._serialized || message?.id?.id?.$1 || message?._data?.id?.id?.id || (typeof message?.id === 'string' || typeof message?.id === 'number' ? message.id : '');
  const body = String(message?.body ?? message?._data?.body ?? message?.caption ?? '').replace(/\u0000/g, '').slice(0, 20000);
  const id = String(rawId || '').trim() || crypto.createHash('sha256').update([chatId, timestamp, fromMe ? '1' : '0', body, message?._data?.mimetype || message?.mimetype || ''].join('|')).digest('hex').slice(0, 40);
  return {
    targetKey: target.key, chatId, messageId: id.slice(0, 300),
    timestamp, fromMe, body,
    caption: String(message?.caption || message?.body || '').slice(0, 2048),
    type: String(message?.type || (message?.hasMedia ? 'media' : 'chat')).slice(0, 32),
    hasMedia: message?.hasMedia === true || Boolean(message?._data?.mimetype || message?.mimetype),
    mimetype: String(message?._data?.mimetype || message?.mimetype || '').slice(0,140),
    filename: String(message?._data?.filename || message?.filename || '').slice(0,220),
    senderName: String(message?._data?.notifyName || message?._data?.pushName || message?.author || '').slice(0,160),
    ack: Number.isFinite(Number(message?.ack)) ? Number(message.ack) : null,
  };
}

function formatRecallRows(rows, { limit = 10, query = '', targetLabel = '' } = {}) {
  const max = Math.max(1, Math.min(50, Number(limit) || 10));
  const matches = Array.isArray(rows) ? rows.slice().sort((a,b) => Number(a.timestampMs || a.timestamp || 0) - Number(b.timestampMs || b.timestamp || 0)) : [];
  const output = query
    ? matches.filter(row => normalize(`${row.body || ''} ${row.caption || ''} ${row.filename || ''} ${row.type || ''}`).includes(normalize(query))).slice(-max)
    : matches.slice(-max);
  const messages = output.map((row, i) => {
    const stamp = Number(row.timestampMs || row.timestamp || 0);
    const date = stamp ? new Date(stamp < 100000000000 ? stamp * 1000 : stamp) : null;
    const when = date && Number.isFinite(date.getTime()) ? date.toLocaleString('ar-OM', { dateStyle: 'short', timeStyle: 'short' }) : 'وقت غير معروف';
    const sender = row.fromMe ? 'أنت' : String(row.senderName || targetLabel || 'الطرف الآخر').slice(0,80);
    let body = String(row.body || row.caption || '').replace(/\s+/g, ' ').trim();
    if (!body && row.hasMedia) body = `[مرفق: ${row.filename || row.mimetype || row.type || 'ملف'}]`;
    if (!body) body = '[رسالة بلا نص]';
    if (row.hasMedia && body.length < 900) body += ` [مرفق${row.filename ? `: ${row.filename}` : row.mimetype ? `: ${row.mimetype}` : ''}]`;
    return `${i + 1}. ${when} — ${sender}: ${body.slice(0, 700)}`;
  });
  return { messages: output, text: messages.join('\n'), count: output.length };
}

module.exports = { normalize, parseRecallCommand, resolveRegisteredTarget, rowFromMessage, formatRecallRows };
