'use strict';

function normalize(value) {
  return String(value || '').normalize('NFKC').toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[إأآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
    .replace(/[\u200e\u200f\u202a-\u202e]/g, '').trim();
}
function unquote(value) {
  let text = String(value || '').trim();
  const pairs = [['«','»'], ['"','"'], ["'","'"], ['“','”'], ['{','}'], ['[',']']];
  for (const [a, b] of pairs) if (text.startsWith(a) && text.endsWith(b) && text.length >= 2) return text.slice(a.length, text.length - b.length).trim();
  return text;
}
const ALIASES = new Map([
  ['اسم','name'], ['اسم القاعده','name'], ['name','name'],
  ['عندما','trigger'], ['شرط','trigger'], ['اذا','trigger'], ['العباره','trigger'], ['عباره','trigger'], ['كلمه','trigger'], ['trigger','trigger'], ['when','trigger'],
  ['رد','reply'], ['الرد','reply'], ['اجابه','reply'], ['response','reply'], ['reply','reply'],
  ['نطاق','scope'], ['scope','scope'], ['مطابقه','match'], ['نوع المطابقه','match'], ['match','match'],
  ['تهدئه','cooldownSec'], ['فاصل','cooldownSec'], ['cooldown','cooldownSec'],
  ['عتبه','threshold'], ['عتبه التشابه','threshold'], ['threshold','threshold'],
]);
function fieldName(value) { return ALIASES.get(normalize(value)) || ''; }
function cleanTrigger(value) {
  let text = unquote(value).trim();
  text = text.replace(/^(?:تحتوي\s+(?:الرساله|الرسالة)\s+على|(?:اذا|إذا|عندما)\s+(?:كانت\s+)?(?:الرساله|الرسالة)\s+(?:تحتوي\s+على|فيها|تتضمن))\s*/u, '');
  text = text.replace(/^(?:(?:الرساله|الرسالة)\s+)?(?:تحتوي(?:\s+على)?|فيها|تتضمن|تساوي|تبدأ ب|تبدأ بـ|تبدا ب|تبدا بـ)\s*/u, '');
  text = text.replace(/^على\s*/u, '');
  return unquote(text);
}
function normalizeScope(value) {
  const v = normalize(value).replace(/[«»"']/g, '').trim();
  if (!v || /^(?:الكل|كل المحادثات|عام|all|الجميع)$/u.test(v)) return 'all';
  if (/^(?:الخاص|خاص|الرسائل الخاصه|المحادثات الخاصه|private)$/u.test(v)) return 'private';
  if (/^(?:المجموعات|المجموعات فقط|الجروبات|الجروبات فقط|groups)$/u.test(v)) return 'groups';
  return null;
}
function normalizeMatch(value) {
  const v = normalize(value);
  if (!v || /^(?:يحتوي|تحتوي|يحتوي على|contains|جزئي|جزئيه)$/u.test(v)) return 'contains';
  if (/^(?:مطابق تماما|مطابقه تامه|يساوي|بالضبط|exact|equals)$/u.test(v)) return 'exact';
  if (/^(?:يبدا ب|بدايه|starts|starts with|prefix)$/u.test(v)) return 'starts';
  if (/^(?:ينتهي ب|تنتهي ب|نهايه|ends|ends with|suffix)$/u.test(v)) return 'ends';
  if (/^(?:تشابه|مشابه|تقريبي|مطابقه تقريبيه|similarity|similar|fuzzy)$/u.test(v)) return 'similarity';
  if (/^(?:نيه|حسب المعنى|حسب النيه|intent|intent match)$/u.test(v)) return 'intent';
  if (/^(?:regex|تعبير منتظم|نمط منتظم|تعبير نمطي)$/u.test(v)) return 'regex';
  if (/^(?:اي رساله|كل رساله|اي نص|any)$/u.test(v)) return 'any';
  return null;
}
function isRuleCommand(input) {
  const t = normalize(input);
  return /^(?:(?:يا )?بوت[,: ]+)?(?:قاعده(?: تفاعل)?|اضف قاعده(?: تفاعل)?|انشئ قاعده(?: تفاعل)?|اعمل قاعده(?: تفاعل)?|رد تلقائي جديد|مساعده القواعد|طريقه كتابه القواعد)(?:\s|[:：;،|]|$)/u.test(t)
    || /^(?:عندما|شرط|trigger)\s*[:=]/u.test(t)
    || /^(?:اذا)\s+(?:كانت\s+)?(?:الرساله\s+)?(?:تحتوي\s+(?:على|علي)|فيها|تتضمن)\s+/u.test(t);
}
function parseRuleCommand(input) {
  const raw = String(input || '').replace(/\r/g, '').trim();
  if (!raw || !isRuleCommand(raw)) return { recognized: false, values: {} };
  let lines = raw.split('\n');
  const heading = /^(?:قاعدة|قاعده)(?: تفاعل)?$|^(?:أضف|اضف) (?:قاعدة|قاعده)(?: تفاعل)?$|^(?:أنشئ|انشئ) (?:قاعدة|قاعده)(?: تفاعل)?$|^(?:اعمل) (?:قاعدة|قاعده)(?: تفاعل)?$|^رد تلقائي جديد$/iu;
  if (lines.length > 1 && heading.test(lines[0].trim())) lines.shift();
  else lines[0] = lines[0].replace(/^(?:(?:يا )?بوت[,: ]+)?(?:(?:قاعدة|قاعده)(?: تفاعل)?|(?:أضف|اضف) (?:قاعدة|قاعده)(?: تفاعل)?|(?:أنشئ|انشئ) (?:قاعدة|قاعده)(?: تفاعل)?|اعمل (?:قاعدة|قاعده)(?: تفاعل)?|رد تلقائي جديد)\s*[:：]?\s*/iu, '');
  const values = {};
  const unknownFields = [];
  const statements = lines.flatMap(line => String(line).split(/[;؛；|]/u)).map(s => s.trim()).filter(Boolean);
  for (const item of statements) {
    const m = item.match(/^\s*([^:=：]{1,36})\s*[:=：]\s*([\s\S]*)$/u);
    if (!m) {
      const n = item.match(/^(?:اذا|إذا|عندما)\s+(?:كانت\s+)?(?:الرساله|الرسالة)?\s*(?:تحتوي\s+على|فيها|تتضمن)\s+(.+?)\s+(?:رد\s*(?:بـ|ب|على)\s+|فقل\s+|فارسل\s+|فأرسل\s+)([\s\S]+)$/u);
      if (n) { values.trigger = unquote(n[1]); values.reply = unquote(n[2]); }
      continue;
    }
    const field = fieldName(m[1]); if (!field) { unknownFields.push(String(m[1]).trim().slice(0, 36)); continue; }
    const value = field === 'trigger' ? cleanTrigger(m[2]) : unquote(m[2]);
    values[field] = value;
  }
  // Also accept a compact natural command, but only by explicit markers.
  if (!values.trigger || !values.reply) {
    const n = raw.match(/(?:اذا|إذا|عندما)\s+(?:كانت\s+)?(?:الرساله|الرسالة)?\s*(?:تحتوي\s+على|فيها|تتضمن)\s*[«"'{\[]?([^»"'}\]\n;؛；|]+)[»"'}\]]?\s+(?:رد\s*(?:بـ|ب|على)\s+|فقل\s+|فارسل\s+|فأرسل\s+)([\s\S]+)$/u);
    if (n) { if (!values.trigger) values.trigger = unquote(n[1]); if (!values.reply) values.reply = unquote(n[2]); }
  }
  if (values.scope !== undefined) values.scope = normalizeScope(values.scope);
  if (values.match !== undefined) values.match = normalizeMatch(values.match);
  if (values.cooldownSec !== undefined) { const x = Number(values.cooldownSec); values.cooldownSec = Number.isFinite(x) ? Math.max(0, Math.min(86400, Math.round(x))) : null; }
  if (values.threshold !== undefined) { const x = Number(values.threshold); values.threshold = Number.isFinite(x) && x >= 0.30 && x <= 0.98 ? x : null; }
  const invalid = [...(values.scope === null ? ['scope'] : []), ...(values.match === null ? ['match'] : []), ...(values.cooldownSec === null ? ['cooldownSec'] : []), ...(values.threshold === null ? ['threshold'] : []), ...unknownFields.map(field => `field:${field}`)];
  if (values.match === 'similarity' && values.threshold === undefined) values.threshold = 0.75;
  if (values.match === 'regex' && String(values.trigger || '').trim()) {
    try { require('./trigger-engine').validateTrigger({ when: { type: 'message', match: 'regex', value: String(values.trigger) } }); }
    catch { invalid.push('regex'); }
  }
  values.name = String(values.name || (values.trigger ? `رد عند: ${values.trigger.slice(0, 40)}` : '')).trim().slice(0, 100);
  return { recognized: true, values, missing: ['trigger','reply'].filter(k => !String(values[k] || '').trim()), invalid: [...new Set(invalid)], unknownFields, source: raw.slice(0, 4000) };
}
function formatRulePreview(values) {
  const scope = ({ all: 'كل المحادثات', private: 'المحادثات الخاصة فقط', groups: 'المجموعات فقط' })[values.scope || 'all'];
  const match = ({ contains: 'تحتوي على', exact: 'تطابق تمامًا', starts: 'تبدأ بـ', ends: 'تنتهي بـ', similarity: `تشابه (عتبة ${Number(values.threshold ?? 0.75).toFixed(2)})`, intent: 'حسب النية/المعنى', regex: 'بتعبير منتظم آمن', any: 'أي رسالة غير فارغة' })[values.match || 'contains'];
  return `راجع ما فهمته قبل الحفظ:\nاسم القاعدة: ${values.name || `رد عند: ${values.trigger}`}\nالشرط: الرسالة ${match} «${values.trigger}»\nالرد: ${values.reply}\nالنطاق: ${scope}\nالفاصل بين الردود: ${Number(values.cooldownSec ?? 45)} ثانية\n\nلم أحفظ القاعدة بعد. اكتب «تأكيد القاعدة» للحفظ، أو «تعديل القاعدة» لإعادة إدخالها، أو «إلغاء».\nالمتغيرات المسموحة في الرد: {{sender}} و{{firstName}} و{{message}} و{{chat}} و{{time}}.`;
}
function helpText() {
  return `طريقة ثابتة لإنشاء قاعدة من الشات — انسخ النموذج وغيّر القيم:\n\nقاعدة تفاعل\nاسم: ترحيب\nعندما: تحتوي الرسالة على {السلام عليكم}\nمطابقة: يحتوي\nرد: وعليكم السلام يا {{sender}}\nنطاق: الكل\nتهدئة: 30\n\nالكلمات قبل النقطتين هي أسماء الحقول، وما بعدها هو القيمة التي يقرأها البوت. المطلوب فقط «عندما» و«رد»، والباقي اختياري.\nالنطاق: الكل أو الخاص أو المجموعات. المطابقة: يحتوي أو يساوي أو يبدأ بـ أو ينتهي بـ أو تشابه أو نية أو تعبير منتظم أو أي رسالة. التشابه عتبته الافتراضية 0.75 ويمكن ضبط «عتبة: 0.30 إلى 0.98». التعبير المنتظم يخضع لفحص أمان.\nيمكنك وضع الحقول في رسالة واحدة وفصلها بـ ؛. إذا كتبت اسم حقل لا يعرفه البوت فسيرفض الحفظ ليطلب تصحيحه.\n\nسيعرض البوت ملخصًا لما فهمه، ولن يحفظ القاعدة إلا بعد كتابة «تأكيد القاعدة». اكتب «إلغاء» للتراجع.\nالمتغيرات في الرد: {{sender}} اسم المرسل، {{firstName}} الاسم الأول، {{message}} نص الرسالة، {{chat}} المحادثة، {{time}} الوقت.`;
}
module.exports = { parseRuleCommand, isRuleCommand, formatRulePreview, helpText, normalizeScope, normalizeMatch };
