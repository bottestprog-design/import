'use strict';

const triggerEngine = require('./trigger-engine');
const ALLOWED_MODES = new Set(['inherit', 'custom', 'disabled']);
const ALLOWED_MATCHES = new Set(['contains', 'exact', 'startsWith', 'endsWith', 'any']);

function normalizeReplyProfile(input = {}) {
  const raw = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
  const mode = ALLOWED_MODES.has(String(raw.mode || 'inherit')) ? String(raw.mode || 'inherit') : 'inherit';
  const rules = (Array.isArray(raw.rules) ? raw.rules : []).slice(0, 30).map((item, index) => {
    const r = item && typeof item === 'object' ? item : {};
    const match = ALLOWED_MATCHES.has(String(r.match || 'contains')) ? String(r.match || 'contains') : 'contains';
    const name = String(r.name || `قاعدة ${index + 1}`).trim().slice(0, 100) || `قاعدة ${index + 1}`;
    const value = String(r.value || '').slice(0, 500);
    const reply = String(r.reply || '').slice(0, 4000);
    return { id: String(r.id || `pr-${index + 1}`).slice(0, 80), name, enabled: r.enabled !== false, match, value, reply };
  });
  return {
    mode,
    enabled: raw.enabled !== false,
    fallbackToGlobal: raw.fallbackToGlobal !== false,
    defaultReply: String(raw.defaultReply || '').slice(0, 4000),
    cooldownSec: Math.max(0, Math.min(86400, Number.isFinite(Number(raw.cooldownSec)) ? Math.trunc(Number(raw.cooldownSec)) : 45)),
    rules,
  };
}

function validateReplyProfile(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('إعداد الرد الشخصي غير صالح.');
  if (Array.isArray(input.rules) && input.rules.length > 30) throw new Error('الحد الأقصى 30 قاعدة رد لكل شخص.');
  const rawRules = Array.isArray(input.rules) ? input.rules : [];
  for (let i = 0; i < rawRules.length; i++) {
    const r = rawRules[i];
    if (!r || typeof r !== 'object' || Array.isArray(r)) throw new Error(`القاعدة الشخصية ${i + 1} غير صالحة.`);
    const match = String(r.match || 'contains');
    if (!ALLOWED_MATCHES.has(match)) throw new Error(`نوع المطابقة في القاعدة ${i + 1} غير مدعوم.`);
    if (match !== 'any' && !String(r.value || '').trim()) throw new Error(`اكتب نص المطابقة للقاعدة ${i + 1}.`);
    if (!String(r.reply || '').trim()) throw new Error(`اكتب الرد للقاعدة ${i + 1}.`);
    if (String(r.value || '').length > 500 || String(r.reply || '').length > 4000) throw new Error(`القاعدة ${i + 1} تتجاوز الحد المسموح للنص.`);
  }
  const mode = String(input.mode || 'inherit');
  if (!ALLOWED_MODES.has(mode)) throw new Error('اختر وضع الرد الشخصي من القائمة.');
  return normalizeReplyProfile(input);
}

function matchPersonalRule(rule, text) {
  if (!rule || rule.enabled === false) return false;
  const input = triggerEngine.normalizeArabic(text);
  if (!input) return false;
  const mode = String(rule.match || 'contains');
  if (mode === 'any') return true;
  const value = triggerEngine.normalizeArabic(rule.value || '');
  if (!value) return false;
  if (mode === 'exact') return input === value;
  if (mode === 'startsWith') return input.startsWith(value);
  if (mode === 'endsWith') return input.endsWith(value);
  return input.includes(value);
}

function recipientForChat(session, chatId) {
  const id = String(chatId || '').trim().toLowerCase();
  if (!id || id.endsWith('@g.us')) return null;
  const people = Array.isArray(session?.recipients) ? session.recipients : [];
  // LIDs only resolve when the exact ID was already saved for this contact.
  const byKnownJid = people.find(person => [
    person.whatsappJid, person.chatId, person.jid, person.lid, person.lidJid
  ].some(value => String(value || '').trim().toLowerCase() === id));
  if (byKnownJid) return byKnownJid;
  if (!/^\d{5,25}@c\.us$/i.test(id)) return null;
  const digits = id.slice(0, -5).replace(/\D/g, '');
  if (!digits) return null;
  return people.find(person => {
    const candidates = [person.digits, person.phone, person.e164, person.international]
      .map(value => String(value || '').replace(/\D/g, '')).filter(Boolean);
    return candidates.includes(digits);
  }) || null;
}

function recipientIsPaused(session, chatId) {
  const id = String(chatId || '').trim().toLowerCase();
  if (!id) return false;
  const paused = item => Boolean(item && (item.enabled === false || item.paused === true || item.stopped === true));
  const groups = Array.isArray(session?.groups) ? session.groups : [];
  const group = groups.find(item => [item.gid, item.chatId, item.whatsappJid, item.jid]
    .some(value => String(value || '').trim().toLowerCase() === id));
  if (group) return paused(group);
  let person = recipientForChat(session, id);
  if (person) return paused(person);
  const match = id.match(/^(\d{5,25})@(?:c\.us|lid)$/i);
  const digits = match?.[1] || (/^\d{5,25}$/.test(id) ? id : '');
  if (!digits) return false;
  const people = Array.isArray(session?.recipients) ? session.recipients : [];
  person = people.find(item => [item.e164, item.phone, item.digits, item.number, item.international, item.whatsappJid, item.chatId, item.jid, item.lid, item.lidJid].some(value => {
    const candidate = String(value || '').trim().toLowerCase();
    if (candidate === id) return true;
    if (/^\d{5,25}@(?:c\.us|lid)$/i.test(candidate)) return candidate.slice(0, candidate.lastIndexOf('@')) === digits;
    return candidate.replace(/\D/g, '') === digits;
  })) || null;
  return paused(person);
}

module.exports = { normalizeReplyProfile, validateReplyProfile, matchPersonalRule, recipientForChat, recipientIsPaused, ALLOWED_MODES, ALLOWED_MATCHES };
