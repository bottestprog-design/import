"use strict";
const { canonicalMode } = require('./trigger-engine');
function isCommandCandidate(candidate) {
  const value = String(candidate?.rule?.when?.value || candidate?.trigger?.command || '');
  return candidate?.kind === 'command' || candidate?.rule?.commandPriority === true || candidate?.trigger?.commandPriority === true || (candidate?.rule?.when?.type === 'message' && /^\s*[!/]/.test(value));
}
function specificity(candidate) {
  const mode = canonicalMode(candidate?.rule?.when?.match || candidate?.trigger?.match || 'contains');
  return ({ exact: 700, starts: 600, ends: 600, regex: 500, contains: 400, intent: 300, similarity: 200, any: 0 })[mode] || 0;
}
function scoreCandidate(candidate) {
  const priority = Math.max(-1000, Math.min(1000, Number(candidate?.priority ?? candidate?.rule?.priority ?? candidate?.trigger?.priority ?? 0)));
  const base = isCommandCandidate(candidate) ? 10_000_000 : 0;
  return base + priority * 1000 + specificity(candidate) + Math.round(Math.max(0, Math.min(1, Number(candidate?.matchScore || 0))) * 100);
}
function rankCandidates(candidates, mode = 'highest-score') {
  return [...candidates].sort((a, b) => {
    if (mode === 'first-match') {
      const ac = isCommandCandidate(a) ? 1 : 0, bc = isCommandCandidate(b) ? 1 : 0;
      return bc - ac || (Number(b.priority ?? b.rule?.priority ?? b.trigger?.priority ?? 0) - Number(a.priority ?? a.rule?.priority ?? a.trigger?.priority ?? 0)) || (Number(a.order) || 0) - (Number(b.order) || 0);
    }
    return scoreCandidate(b) - scoreCandidate(a) || (Number(a.order) || 0) - (Number(b.order) || 0);
  });
}
module.exports = { isCommandCandidate, specificity, scoreCandidate, rankCandidates };
