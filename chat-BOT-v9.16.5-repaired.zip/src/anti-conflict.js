'use strict';
const { rankCandidates } = require('./command-priority');
const { replyVariants } = require('./reply-engine');

function channelsFor(candidate) {
  const item = candidate?.item || candidate?.rule || candidate?.trigger || {};
  const action = item?.then || item || {};
  const channels = [];
  const actionType = candidate?.kind === 'counter' ? (item.actionType || 'reply') : '';
  if (actionType === 'log') channels.push('log');
  else {
    if (actionType === 'reply' || (!actionType && replyVariants(item).length)) channels.push('reply');
    if (actionType === 'reaction' || action.reaction) channels.push('reaction');
  }
  return [...new Set(channels)];
}
function conflictKey(candidate) {
  return String(candidate?.conflictGroup || candidate?.item?.conflictGroup || candidate?.rule?.conflictGroup || candidate?.trigger?.conflictGroup || channelsFor(candidate).join('+') || 'action');
}
function resolveCandidates(candidates, mode = 'first-match') {
  const ranked = rankCandidates(candidates, mode === 'first-match' ? 'first-match' : 'highest-score');
  // In one-action mode, keep fallback candidates: the leading action can be cooling down or fail.
  if (mode !== 'allow-multiple') return ranked;
  const usedChannels = new Set(), usedGroups = new Set(), out = [];
  for (const candidate of ranked) {
    if (candidate?.allowConflict === true || candidate?.item?.allowConflict === true) { out.push(candidate); continue; }
    const group = String(candidate?.conflictGroup || candidate?.item?.conflictGroup || candidate?.rule?.conflictGroup || candidate?.trigger?.conflictGroup || '').trim();
    const channels = channelsFor(candidate);
    if ((group && usedGroups.has(group)) || channels.some(channel => usedChannels.has(channel))) continue;
    out.push(candidate);
    if (group) usedGroups.add(group);
    channels.forEach(channel => usedChannels.add(channel));
  }
  return out;
}
module.exports = { conflictKey, channelsFor, resolveCandidates };
