"use strict";
const norm = s => String(s || '').normalize('NFKC').toLocaleLowerCase().replace(/[\u064B-\u065F\u0670ـ]/g, '').replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').trim();
class DictionaryEngine {
  constructor({ maxEntries = 20000 } = {}) { this.maxEntries = maxEntries; this.entries = new Map(); }
  upsert(entry) {
    const term = String(entry?.term || '').trim().slice(0, 160); if (!term) throw new Error('term required');
    const key = norm(term); const aliases = [...new Set((entry.aliases || []).map(norm).filter(Boolean))].slice(0, 40);
    const item = { id: entry.id || key, term, normalized: key, aliases, definition: String(entry.definition || '').slice(0, 8000), tags: [...new Set((entry.tags || []).map(x => String(x).slice(0, 40)))].slice(0, 30), updatedAt: new Date().toISOString() };
    if (!this.entries.has(key) && this.entries.size >= this.maxEntries) throw new Error('dictionary capacity reached');
    this.entries.set(key, item); for (const alias of aliases) this.entries.set(`alias:${alias}`, item); return item;
  }
  remove(term) { const key = norm(term), item = this.entries.get(key); if (!item) return false; for (const [k, v] of this.entries) if (v.id === item.id) this.entries.delete(k); return true; }
  lookup(query) { const q = norm(query); if (!q) return null; const direct = this.entries.get(q) || this.entries.get(`alias:${q}`); if (direct) return direct; let best = null, score = 0; for (const item of new Set(this.entries.values())) { const candidates = [item.normalized, ...item.aliases]; const s = Math.max(...candidates.map(x => x === q ? 1 : x.includes(q) || q.includes(x) ? Math.min(x.length, q.length) / Math.max(x.length, q.length) * .9 : 0)); if (s > score) { score = s; best = item; } } return score >= .45 ? { ...best, matchScore: Math.round(score * 100) / 100 } : null; }
  list({ limit = 100, offset = 0, query = '' } = {}) { const q = norm(query); return [...new Map([...this.entries.values()].map(x => [x.id, x])).values()].filter(x => !q || x.normalized.includes(q) || x.aliases.some(a => a.includes(q))).slice(Math.max(0, offset), Math.max(0, offset) + Math.max(1, Math.min(500, limit))); }
}
module.exports = { DictionaryEngine, normalizeDictionaryText: norm };
