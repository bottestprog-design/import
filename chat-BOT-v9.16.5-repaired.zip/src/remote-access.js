'use strict';

const crypto = require('node:crypto');

function normalizedHost(host) {
  return String(host || '').trim().toLowerCase().replace(/^\[|\]$/g, '');
}

function isLoopbackHost(host) {
  const value = normalizedHost(host);
  return value === 'localhost' || value === '::1' || value === '::ffff:127.0.0.1' || /^127(?:\.\d{1,3}){3}$/.test(value);
}

function createConfig(host, env = process.env) {
  const loopbackOnly = isLoopbackHost(host);
  const password = String(env.DASHBOARD_PASSWORD || '');
  // Localhost is frictionless by default. Supplying a password also enables
  // the same gate on loopback so a TLS reverse proxy cannot accidentally
  // expose an unauthenticated dashboard through a local upstream.
  if (loopbackOnly && !password) return Object.freeze({ enabled: false, loopbackOnly: true });
  const username = String(env.DASHBOARD_USERNAME || 'admin').trim();
  if (!username || username.length > 100 || /[:\r\n\u0000-\u001f]/u.test(username)) {
    throw new Error('DASHBOARD_USERNAME غير صالح؛ استخدم اسمًا من دون نقطتين أو محارف تحكم.');
  }
  if (password.length < 16 || password.length > 1024 || /[\r\n\u0000-\u001f\u007f]/u.test(password)) {
    throw new Error('للاستماع خارج الجهاز المحلي، أو لتشغيل خلف وكيل HTTPS مع مصادقة، عيّن DASHBOARD_PASSWORD بطول 16 محرفًا على الأقل. لم يبدأ الخادم لحماية لوحة التحكم.');
  }
  return Object.freeze({ enabled: true, loopbackOnly, username, password });
}

function safeEqual(a, b) {
  const left = Buffer.from(String(a ?? ''), 'utf8');
  const right = Buffer.from(String(b ?? ''), 'utf8');
  if (left.length !== right.length) return false;
  return crypto.timingSafeEqual(left, right);
}

function requestPath(req) {
  try { return new URL(String(req.url || req.path || '/'), 'http://local.invalid').pathname; }
  catch { return '/'; }
}

function tokenProtectedPath(pathname) {
  // These routes authenticate with one-time enrollment/device tokens or the
  // high-entropy webhook bearer token in the URL. All other remote requests,
  // including static dashboard assets, require dashboard Basic Auth.
  return /^\/api\/integrations\/agents\/(?:claim|heartbeat|tasks|result)\/?$/u.test(pathname) || /^\/api\/integrations\/hooks\/[^/]+\/?$/u.test(pathname);
}

function hasValidBasicAuth(header, config) {
  if (!config?.enabled) return true;
  const match = String(header || '').match(/^Basic\s+([A-Za-z0-9+/]+={0,2})$/iu);
  if (!match) return false;
  let decoded;
  try { decoded = Buffer.from(match[1], 'base64').toString('utf8'); }
  catch { return false; }
  const separator = decoded.indexOf(':');
  if (separator < 1) return false;
  const username = decoded.slice(0, separator);
  const password = decoded.slice(separator + 1);
  const userOk = safeEqual(username, config.username);
  const passwordOk = safeEqual(password, config.password);
  return userOk && passwordOk;
}

function authorizeRequest(req, config) {
  if (!config?.enabled) return { authorized: true, reason: 'loopback' };
  if (tokenProtectedPath(requestPath(req))) return { authorized: true, reason: 'endpoint-token' };
  if (hasValidBasicAuth(req.headers?.authorization, config)) return { authorized: true, reason: 'basic-auth' };
  return { authorized: false, reason: 'credentials-required' };
}

const CHALLENGE = 'Basic realm="chat-BOT Local Dashboard", charset="UTF-8"';

module.exports = { isLoopbackHost, createConfig, hasValidBasicAuth, tokenProtectedPath, authorizeRequest, CHALLENGE };
