'use strict';

const fs = require('node:fs');
const path = require('node:path');

function parseEnv(source) {
  const result = Object.create(null);
  for (const original of String(source || '').replace(/^\uFEFF/, '').split(/\r?\n/)) {
    let line = original.trim();
    if (!line || line.startsWith('#')) continue;
    if (line.startsWith('export ')) line = line.slice(7).trim();
    const match = line.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (!match) continue;
    const key = match[1];
    let value = match[2].trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      const quote = value[0];
      value = value.slice(1, -1);
      if (quote === '"') value = value.replace(/\\n/g, '\n').replace(/\\r/g, '\r').replace(/\\"/g, '"').replace(/\\\\/g, '\\');
    } else {
      value = value.replace(/\s+#.*$/, '').trim();
    }
    result[key] = value;
  }
  return result;
}

function loadEnv(filePath = path.resolve(process.cwd(), '.env'), target = process.env, { override = false } = {}) {
  let source;
  try { source = fs.readFileSync(filePath, 'utf8'); }
  catch (error) { if (error?.code === 'ENOENT') return { loaded: false, count: 0, filePath }; throw error; }
  const parsed = parseEnv(source);
  let count = 0;
  for (const [key, value] of Object.entries(parsed)) {
    if (override || target[key] === undefined) { target[key] = value; count++; }
  }
  return { loaded: true, count, filePath };
}

module.exports = { parseEnv, loadEnv };
