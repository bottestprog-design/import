'use strict';

// Password-encrypted, local-only backup of application data. No network services.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const zlib = require('node:zlib');

const MAGIC = Buffer.from('CBOTBK01', 'ascii');
const HEADER_BYTES = MAGIC.length + 16 + 12 + 16;
const MAX_TOTAL_FILE_BYTES = 128 * 1024 * 1024;
const MAX_FILE_BYTES = 64 * 1024 * 1024;
const MAX_FILES = 20000;
const MAX_ARCHIVE_BYTES = 180 * 1024 * 1024;
const MAX_JSON_BYTES = 190 * 1024 * 1024;
const PASSWORD_MIN = 12;

function validatePassword(value) {
  const password = String(value ?? '');
  if (password.length < PASSWORD_MIN || password.length > 256 || /[\r\n\u0000-\u001f\u007f]/u.test(password)) {
    throw new Error(`استخدم كلمة مرور للنسخة الاحتياطية بطول ${PASSWORD_MIN} إلى 256 محرفًا، من دون محارف تحكم.`);
  }
  return password;
}

function isExcluded(rel, name) {
  if (String(rel).split(/[\\/]/u).includes('_temp')) return true;
  if (/^(?:\.tmp(?:-|$)|.*\.tmp(?:-|$)|.*\.lock)$/iu.test(name)) return true;
  return false;
}

function collectFiles(root) {
  const result = [];
  let totalBytes = 0;
  const base = path.resolve(root);
  if (!fs.existsSync(base)) throw new Error('مجلد البيانات المحلي غير موجود أو غير صالح.');
  const rootStat = fs.lstatSync(base);
  if (rootStat.isSymbolicLink() || !rootStat.isDirectory()) throw new Error('مجلد البيانات المحلي غير صالح أو يشير إلى رابط رمزي.');
  function visit(current, rel) {
    const entries = fs.readdirSync(current, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name));
    for (const entry of entries) {
      const relative = rel ? `${rel}/${entry.name}` : entry.name;
      if (isExcluded(relative, entry.name)) continue;
      const full = path.join(current, entry.name);
      const stat = fs.lstatSync(full);
      if (stat.isSymbolicLink()) throw new Error(`تعذر إنشاء النسخة: يحتوي مجلد البيانات على رابط رمزي (${relative}).`);
      if (stat.isDirectory()) { visit(full, relative); continue; }
      if (!stat.isFile()) continue;
      if (stat.size > MAX_FILE_BYTES) throw new Error(`الملف ${relative} أكبر من الحد المسموح للنسخ (${Math.round(MAX_FILE_BYTES / 1024 / 1024)} MB).`);
      const normalizedRelative = relative.replace(/\\/g, '/');
      if (!safeRelativePath(normalizedRelative)) throw new Error(`تعذر إنشاء النسخة: مسار الملف لا يمكن استعادته بأمان على الأنظمة المدعومة (${normalizedRelative}).`);
      totalBytes += stat.size;
      if (totalBytes > MAX_TOTAL_FILE_BYTES) throw new Error(`حجم البيانات المراد نسخها تجاوز ${Math.round(MAX_TOTAL_FILE_BYTES / 1024 / 1024)} MB. قلّل الوسائط أو انسخها على دفعات.`);
      result.push({ path: normalizedRelative, mode: stat.mode & 0o777, mtimeMs: Math.floor(stat.mtimeMs), data: fs.readFileSync(full).toString('base64') });
      if (result.length > MAX_FILES) throw new Error(`عدد الملفات تجاوز حد النسخ (${MAX_FILES}).`);
    }
  }
  visit(base, '');
  if (!result.some(file => file.path.startsWith('sessions/'))) throw new Error('لا توجد بيانات جلسات يمكن نسخها.');
  return { files: result, totalBytes };
}

function deriveKey(password, salt) {
  return crypto.scryptSync(validatePassword(password), salt, 32, { N: 32768, r: 8, p: 1, maxmem: 128 * 1024 * 1024 });
}

function createEncryptedBackup(root, password, appVersion = 'unknown') {
  password = validatePassword(password);
  const collected = collectFiles(root);
  const payload = Buffer.from(JSON.stringify({
    format: 'chat-bot-local-backup',
    formatVersion: 1,
    appVersion: String(appVersion).slice(0, 40),
    createdAt: new Date().toISOString(),
    totalBytes: collected.totalBytes,
    files: collected.files,
  }), 'utf8');
  const compressed = zlib.gzipSync(payload, { level: 6 });
  const salt = crypto.randomBytes(16), iv = crypto.randomBytes(12), key = deriveKey(password, salt);
  try {
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
    const ciphertext = Buffer.concat([cipher.update(compressed), cipher.final()]);
    const archive = Buffer.concat([MAGIC, salt, iv, cipher.getAuthTag(), ciphertext]);
    if (archive.length > MAX_ARCHIVE_BYTES) throw new Error(`حجم النسخة المشفرة تجاوز ${Math.round(MAX_ARCHIVE_BYTES / 1024 / 1024)} MB.`);
    return { buffer: archive, fileCount: collected.files.length, totalBytes: collected.totalBytes, createdAt: new Date().toISOString() };
  } finally { key.fill(0); }
}

function safeRelativePath(value) {
  if (typeof value !== 'string' || !value || value.length > 1024 || value.includes('\\') || value.includes('\0')) return false;
  if (value.startsWith('/') || /^[a-z]:/iu.test(value)) return false;
  const parts = value.split('/');
  if (parts.some(part => !part || part === '.' || part === '..' || /[<>:"|?*]/u.test(part) || /[ .]$/u.test(part) || /^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?$/iu.test(part))) return false;
  if (parts[0] === '_temp') return false;
  return parts.length === 1 ? parts[0] !== 'sessions' && /^[A-Za-z0-9._-]{1,128}$/u.test(parts[0]) : parts[0] === 'sessions' && parts.length >= 3 && /^[A-Za-z0-9_-]{1,80}$/u.test(parts[1]);
}

function decryptAndValidateBackup(input, password) {
  const archive = Buffer.isBuffer(input) ? input : Buffer.from(input || []);
  if (archive.length < HEADER_BYTES + 1 || archive.length > MAX_ARCHIVE_BYTES) throw new Error('حجم ملف النسخة الاحتياطية غير صالح أو يتجاوز الحد المسموح.');
  if (!archive.subarray(0, MAGIC.length).equals(MAGIC)) throw new Error('صيغة ملف النسخة الاحتياطية غير معروفة.');
  const saltStart = MAGIC.length, ivStart = saltStart + 16, tagStart = ivStart + 12, bodyStart = tagStart + 16;
  const salt = archive.subarray(saltStart, ivStart), iv = archive.subarray(ivStart, tagStart), tag = archive.subarray(tagStart, bodyStart), ciphertext = archive.subarray(bodyStart);
  const key = deriveKey(password, salt);
  let plaintext;
  try {
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(tag);
    const compressed = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
    plaintext = zlib.gunzipSync(compressed, { maxOutputLength: MAX_JSON_BYTES });
  } catch {
    throw new Error('تعذر فك النسخة الاحتياطية. تحقق من كلمة المرور وسلامة الملف.');
  } finally { key.fill(0); }

  let bundle;
  try { bundle = JSON.parse(plaintext.toString('utf8')); } catch { throw new Error('محتوى النسخة الاحتياطية تالف أو غير صالح.'); }
  if (!bundle || bundle.format !== 'chat-bot-local-backup' || bundle.formatVersion !== 1 || !Array.isArray(bundle.files)) throw new Error('ملف النسخة لا يطابق صيغة النسخ الاحتياطي المدعومة.');
  if (bundle.files.length < 1 || bundle.files.length > MAX_FILES) throw new Error('عدد الملفات في النسخة غير صالح.');
  const seen = new Set();
  let totalBytes = 0;
  const cleanFiles = [];
  const sessionIds = new Set();
  for (const file of bundle.files) {
    if (!file || !safeRelativePath(file.path) || seen.has(file.path) || typeof file.data !== 'string' || file.data.length > Math.ceil(MAX_FILE_BYTES * 4 / 3) + 8) throw new Error('تحتوي النسخة على مسار أو ملف غير آمن.');
    const bytes = Buffer.from(file.data, 'base64');
    if (bytes.toString('base64') !== file.data.replace(/\s/g, '') || bytes.length > MAX_FILE_BYTES) throw new Error(`بيانات الملف غير صالحة: ${file.path}`);
    totalBytes += bytes.length;
    if (totalBytes > MAX_TOTAL_FILE_BYTES) throw new Error('حجم البيانات المفكوكة يتجاوز الحد المسموح.');
    seen.add(file.path);
    if (file.path.startsWith('sessions/')) sessionIds.add(file.path.split('/')[1]);
    cleanFiles.push({ path: file.path, data: bytes });
  }
  if (!sessionIds.size) throw new Error('النسخة لا تحتوي على بيانات جلسات.');
  const activeEntry = cleanFiles.find(file => file.path === 'active-session');
  if (activeEntry) {
    const active = activeEntry.data.toString('utf8').trim().replace(/[^A-Za-z0-9_-]/g, '').slice(0, 80);
    if (!active || !sessionIds.has(active)) throw new Error('الجلسة النشطة داخل النسخة لا تطابق أي جلسة محفوظة.');
  }
  return { appVersion: String(bundle.appVersion || 'unknown'), createdAt: String(bundle.createdAt || ''), fileCount: cleanFiles.length, totalBytes, files: cleanFiles };
}

function restoreValidatedBackup(root, bundle) {
  // Build a fresh tree beside data/ first. Swapping the directory is synchronous
  // and the caller must pause background work before invoking this function.
  const dataRoot = path.resolve(root);
  const parent = path.dirname(dataRoot);
  const stage = path.join(parent, `.chat-bot-restore-${process.pid}-${crypto.randomBytes(6).toString('hex')}`);
  const previous = path.join(parent, `.chat-bot-previous-${process.pid}-${crypto.randomBytes(6).toString('hex')}`);
  fs.mkdirSync(path.join(stage, 'sessions'), { recursive: true, mode: 0o700 });
  try {
    for (const file of bundle.files) {
      const target = path.resolve(stage, ...file.path.split('/'));
      if (target !== stage && !target.startsWith(stage + path.sep)) throw new Error('مسار غير آمن داخل النسخة.');
      fs.mkdirSync(path.dirname(target), { recursive: true, mode: 0o700 });
      fs.writeFileSync(target, file.data, { mode: 0o600, flag: 'wx' });
    }
    fs.mkdirSync(path.join(stage, '_temp'), { recursive: true, mode: 0o700 });
    if (!fs.existsSync(dataRoot)) fs.mkdirSync(dataRoot, { recursive: true, mode: 0o700 });
    fs.renameSync(dataRoot, previous);
    try { fs.renameSync(stage, dataRoot); }
    catch (error) { fs.renameSync(previous, dataRoot); throw error; }
    try { fs.rmSync(previous, { recursive: true, force: true, maxRetries: 3, retryDelay: 100 }); } catch { /* Keep old data rather than risking the successful restore. */ }
    return { fileCount: bundle.fileCount, totalBytes: bundle.totalBytes, appVersion: bundle.appVersion, createdAt: bundle.createdAt };
  } catch (error) {
    try { fs.rmSync(stage, { recursive: true, force: true, maxRetries: 3, retryDelay: 100 }); } catch {}
    throw error;
  }
}

module.exports = { MAGIC, MAX_TOTAL_FILE_BYTES, MAX_FILE_BYTES, MAX_FILES, MAX_ARCHIVE_BYTES, PASSWORD_MIN, validatePassword, safeRelativePath, collectFiles, createEncryptedBackup, decryptAndValidateBackup, restoreValidatedBackup };
