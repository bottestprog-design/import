'use strict';
// Small companion agent for a trusted computer on the same private network.
// It supports a fixed allowlist only; it never runs shell commands or accepts code from the hub.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const execFileAsync = promisify(execFile);
const VERSION = '1.0.0';
const HTTP_TIMEOUT_MS = 6500;
const MAX_READ_BYTES = 20 * 1024 * 1024;
const COMMANDS = Object.freeze({
  node: { bin: process.execPath, args: ['--version'], label: 'Node.js' },
  npm: { bin: process.platform === 'win32' ? 'npm.cmd' : 'npm', args: ['--version'], label: 'npm' },
  python: { bin: process.platform === 'win32' ? 'python' : 'python3', args: ['--version'], label: 'Python' },
  git: { bin: 'git', args: ['--version'], label: 'Git' },
  ollama: { bin: 'ollama', args: ['--version'], label: 'Ollama المحلي' },
  curl: { bin: 'curl', args: ['--version'], label: 'curl' },
});
function args(argv) { const out = {}; for (let i=0;i<argv.length;i++) { if (!argv[i].startsWith('--')) continue; const key=argv[i].slice(2); if (key==='allow-root') { out.allowRoots ||= []; if (argv[i+1] && !argv[i+1].startsWith('--')) out.allowRoots.push(argv[++i]); else throw new Error('خيار --allow-root يحتاج مسارًا.'); } else if (argv[i+1] && !argv[i+1].startsWith('--')) out[key]=argv[++i]; else out[key]=true; } return out; }
function statePath() { return path.join(process.env.INTEGRATION_AGENT_HOME || path.join(os.homedir(), '.chat-bot-integration-agent'), 'state.json'); }
function loadState() { try { return JSON.parse(fs.readFileSync(statePath(),'utf8')); } catch (e) { if (e.code==='ENOENT') return null; throw new Error('ملف إعداد الجهاز المحلي تالف؛ احتفظ بنسخة منه قبل الإصلاح.'); } }
function saveState(state) { const file=statePath(); fs.mkdirSync(path.dirname(file),{recursive:true,mode:0o700}); const temp=`${file}.tmp-${process.pid}`; fs.writeFileSync(temp,JSON.stringify(state,null,2),{mode:0o600}); fs.renameSync(temp,file); }
function validateServer(value) { let u; try {u=new URL(String(value||''));} catch {throw new Error('أدخل عنوان الخادم المحلي الصحيح.');} if(!['http:','https:'].includes(u.protocol)||u.username||u.password||u.search||u.hash) throw new Error('عنوان الخادم يجب أن يكون HTTP/HTTPS بلا بيانات دخول أو معاملات.'); return u.origin; }
function isAllowedPath(candidate, roots) { let real; try { real=fs.realpathSync(candidate); } catch { throw new Error('المسار غير موجود أو ليس متاحًا.'); } const allowed=(roots||[]).some(root=>{ try {const rr=fs.realpathSync(root); const rel=path.relative(rr,real); return rel==='' || (!rel.startsWith(`..${path.sep}`)&&rel!=='..'&&!path.isAbsolute(rel));} catch{return false;} }); if(!allowed) throw new Error('رفض قراءة المسار: يجب أن يكون داخل مجلد سمحت به مسبقًا عبر --allow-root.'); return real; }
function sanitizeError(error) { return String(error?.message||error||'تعذر التنفيذ.').replace(/(authorization|cookie|token|api[_-]?key|password|secret)\s*[:=]\s*[^\s,;]+/ig,'$1=[مخفي]').slice(0,500); }
async function request(server, endpoint, { method='GET', body, token, timeout=HTTP_TIMEOUT_MS }={}) { const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeout); timer.unref?.(); try { const response=await fetch(new URL(endpoint,server),{method,redirect:'manual',signal:controller.signal,headers:{'Accept':'application/json','Content-Type':'application/json',...(token?{'x-integration-agent-token':token}:{})},...(body!==undefined?{body:JSON.stringify(body)}:{})}); if(response.status>=300&&response.status<400){await response.body?.cancel();throw new Error('رفض الوكيل تحويل خادم مركز التكاملات إلى عنوان آخر لحماية رمز الجهاز. تحقق من عنوان الخادم وإعداد HTTPS.');} const raw=await response.text(); if(raw.length>100000) throw new Error('الرد من الخادم أكبر من الحد المتوقع.'); let data={}; try{data=raw?JSON.parse(raw):{};}catch{throw new Error(`أعاد الخادم ردًا غير صالح (HTTP ${response.status}).`);} if(!response.ok||data.ok===false) throw new Error(data.error||`خطأ HTTP ${response.status}.`); return data; } catch(e) { if(e.name==='AbortError') throw new Error('انتهت مهلة الاتصال بالخادم.'); throw e; } finally {clearTimeout(timer);} }
async function inspectCommand(command) { const cmd=COMMANDS[String(command||'node')]; if(!cmd) throw new Error('هذا البرنامج غير موجود في القائمة الآمنة.'); const result=await execFileAsync(cmd.bin,cmd.args,{timeout:3500,windowsHide:true,shell:false,maxBuffer:64000}); return {ok:true,command,label:cmd.label,version:String(result.stdout||result.stderr||'').trim().slice(0,300),readOnly:true,summary:`${cmd.label}: ${String(result.stdout||result.stderr||'').trim().slice(0,180)}`}; }
async function runTask(task,state) {
  if(task.action==='device.info') return {ok:true,summary:`الجهاز متاح: ${os.platform()} ${os.arch()}`,platform:os.platform(),arch:os.arch(),hostname:os.hostname(),node:process.version,uptimeSeconds:Math.round(os.uptime()),agentVersion:VERSION};
  if(task.action==='command.version') return inspectCommand(task.params?.command || 'node');
  if(task.action==='folder.list') {const root=isAllowedPath(String(task.params?.path||''),state.allowRoots); const st=fs.statSync(root); if(!st.isDirectory()) throw new Error('المسار المحدد ليس مجلدًا.'); const entries=fs.readdirSync(root,{withFileTypes:true}).slice(0,100).map(x=>({name:x.name.slice(0,200),type:x.isDirectory()?'مجلد':x.isFile()?'ملف':'نوع آخر'})); return {ok:true,path:root,count:entries.length,entries,readOnly:true,summary:`قُرئ ${entries.length} اسمًا من المجلد؛ لم تُقرأ محتويات الملفات.`}; }
  if(task.action==='database.inspect') {const file=isAllowedPath(String(task.params?.path||''),state.allowRoots),st=fs.statSync(file); if(!st.isFile()||st.size>MAX_READ_BYTES) throw new Error('الملف ليس ملفًا عاديًا أو حجمه أكبر من 20 ميجابايت.'); const ext=path.extname(file).toLowerCase(); if(ext==='.json'){const v=JSON.parse(fs.readFileSync(file,'utf8'));return {ok:true,format:'JSON',bytes:st.size,rootType:Array.isArray(v)?'array':typeof v,keys:v&&typeof v==='object'&&!Array.isArray(v)?Object.keys(v).slice(0,100):[],readOnly:true,summary:'تمت قراءة بنية JSON فقط.'};} if(ext==='.csv'){const lines=fs.readFileSync(file,'utf8').split(/\r?\n/u).filter(Boolean);return {ok:true,format:'CSV',bytes:st.size,columns:(lines[0]||'').split(',').map(x=>x.trim().replace(/^"|"$/g,'')).slice(0,100),rowCount:Math.max(0,lines.length-1),readOnly:true,summary:`تم فحص CSV: ${Math.max(0,lines.length-1)} صفًا.`};} if(!['.db','.sqlite','.sqlite3'].includes(ext))throw new Error('نوع الملف غير مدعوم.'); const py="import sys,sqlite3,json,urllib.parse\np=sys.argv[1]\nc=sqlite3.connect('file:'+urllib.parse.quote(p.replace('\\\\','/'),safe='/ :')+'?mode=ro',uri=True,timeout=2)\nt=[r[0] for r in c.execute(\"SELECT name FROM sqlite_master WHERE type='table' ORDER BY name\").fetchall() if not r[0].startswith('sqlite_')]\nprint(json.dumps({'tables':[{'name':n,'rows':c.execute('SELECT COUNT(*) FROM \"'+n.replace('\"','\"\"')+'\"').fetchone()[0]} for n in t[:100]],'readOnly':True}))\nc.close()"; const result=await execFileAsync(process.platform==='win32'?'python':'python3',['-c',py,file],{timeout:5000,windowsHide:true,maxBuffer:256000}); return {ok:true,...JSON.parse(result.stdout),format:'SQLite',bytes:st.size,summary:'تم فحص الجداول بوضع القراءة فقط.'}; }
  if(task.action==='http.probe') {let url;try{url=new URL(String(task.params?.url||''));}catch{throw new Error('الرابط غير صالح.');}if(!['http:','https:'].includes(url.protocol)||url.username||url.password)throw new Error('الرابط المسموح HTTP/HTTPS فقط ومن دون بيانات دخول داخل الرابط.');const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),HTTP_TIMEOUT_MS);timer.unref?.();try{const start=Date.now(),r=await fetch(url,{method:'GET',redirect:'manual',signal:controller.signal,headers:{'Accept':'application/json, text/html, */*','User-Agent':'chat-BOT-IntegrationAgent/1.0'}});if(r.status>=300&&r.status<400){await r.body?.cancel();throw new Error('توقف فحص الموقع عند التحويل؛ افحص العنوان النهائي مباشرة لتجنب التحويل إلى وجهة غير مقصودة.');}let bytes=0;const reader=r.body?.getReader();if(reader){try{while(true){const {done,value}=await reader.read();if(done)break;bytes+=value.byteLength;if(bytes>512*1024){await reader.cancel();throw new Error('استجابة الموقع تتجاوز نصف ميجابايت.');}}}finally{try{reader.releaseLock();}catch{}}}return {ok:r.status<500,status:r.status,latencyMs:Date.now()-start,bytes,summary:`HTTP ${r.status} خلال ${Date.now()-start}ms`};}finally{clearTimeout(timer);}}
  throw new Error('إجراء المهمة غير مدعوم في هذه النسخة من الوكيل.');
}
async function main() {
  const cli=args(process.argv.slice(2)); let state=loadState();
  const server=validateServer(cli.server||state?.server||'');
  const sessionId=String(cli.session||state?.sessionId||'main'); if(!/^[A-Za-z0-9_-]{1,80}$/.test(sessionId)) throw new Error('معرّف الجلسة غير صالح.');
  const roots=[...(state?.allowRoots||[]),...(cli.allowRoots||[]),...(String(process.env.INTEGRATION_AGENT_ALLOWED_ROOTS||'').split(path.delimiter).filter(Boolean))];
  const realRoots=[...new Set(roots.map(x=>{try{return fs.realpathSync(x);}catch{throw new Error(`مجلد السماح غير موجود: ${x}`);}}))];
  if (!state || cli.token) {
    const enrollmentToken=String(cli.token||''); if(!enrollmentToken) throw new Error('لربط هذا الجهاز أول مرة، أضف الرمز الذي أنشأه مركز التكاملات عبر --token.');
    const claimed=await request(server,'/api/integrations/agents/claim',{method:'POST',body:{token:enrollmentToken,name:String(cli.name||os.hostname()),os:os.platform(),arch:os.arch(),hostname:os.hostname(),agentVersion:VERSION}});
    state={server,sessionId:claimed.sessionId,deviceId:claimed.device.id,deviceToken:claimed.deviceToken,allowRoots:realRoots}; saveState(state); console.log(`تم ربط الجهاز محليًا: ${claimed.device.name} (${claimed.device.id}). لم يتم حفظ رمز التسجيل المؤقت.`);
  } else {
    state.server=server; state.allowRoots=realRoots.length?realRoots:state.allowRoots||[]; saveState(state);
  }
  let stopping=false; const stop=()=>{stopping=true;}; process.once('SIGINT',stop);process.once('SIGTERM',stop);
  console.log(`وكيل التكامل يعمل مع ${state.server}. اضغط Ctrl+C للإيقاف. لا يُنفذ إلا الأوامر الآمنة المحددة.`);
  while(!stopping){
    try {
      await request(state.server,'/api/integrations/agents/heartbeat',{method:'POST',token:state.deviceToken,body:{sessionId:state.sessionId,deviceId:state.deviceId,os:os.platform(),arch:os.arch(),hostname:os.hostname(),agentVersion:VERSION}});
      const pending=await request(state.server,'/api/integrations/agents/tasks',{method:'POST',token:state.deviceToken,body:{sessionId:state.sessionId,deviceId:state.deviceId}});
      for(const task of pending.tasks||[]){let result;try{result=await runTask(task,state);}catch(e){result={ok:false,error:sanitizeError(e),summary:`تعذر تنفيذ ${task.action}: ${sanitizeError(e)}`};}try{await request(state.server,'/api/integrations/agents/result',{method:'POST',token:state.deviceToken,body:{sessionId:state.sessionId,deviceId:state.deviceId,taskId:task.id,result}});}catch(e){console.error(`تعذر حفظ نتيجة المهمة ${task.id}: ${sanitizeError(e)}`);}}
    } catch(error) { console.error(`تعذر الوصول إلى مركز التكاملات: ${sanitizeError(error)}. ستتم إعادة المحاولة.`); }
    await new Promise(resolve=>setTimeout(resolve,20000));
  }
  console.log('تم إيقاف وكيل التكامل.');
}
if(require.main===module) main().catch(error=>{console.error(`خطأ في وكيل التكامل: ${sanitizeError(error)}`);process.exitCode=1;});
module.exports={VERSION,COMMANDS,args,validateServer,isAllowedPath,runTask,request};
