"use strict";
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const BAD_LINE = /(^|\r?\n)\s*(?:if\s*\(message\s*&&\s*message\.__x_id\)\s*delete\s+message\.__x_id\s*;?|message\.__x_id\s*=.*?;)(?=\r?\n|$)/g;
const MARKERS = /(^|\r?\n)\s*\/\*\s*CHAT_BOT_[^*]*COMPAT[^*]*\*\/\s*/g;

function syntaxOk(source, filename) {
  try { new vm.Script(String(source), { filename }); return true; }
  catch { return false; }
}

function patchUtilsText(source) {
  let out = String(source);
  const before = out;
  // Never write a known malformed object-field injection back into the library.
  // Older chat BOT builds inserted executable code inside the message object.
  // Remove only that known broken line/marker. Never inject statements into Utils.js.
  out = out.replace(BAD_LINE, '\n').replace(MARKERS, '\n');

  // Safe compatibility fallbacks for message IDs used by newer WhatsApp Web builds.
  const replacements = [
    ['window.Store.Msg.get(newMsgKey._serialized)', 'window.Store.Msg.get(newMsgKey._serialized || newMsgKey.$1)'],
    ['window.Store.Msg.get(msg.id._serialized)', 'window.Store.Msg.get(msg.id._serialized || msg.id.$1)'],
    ['window.Store.Msg.get(chat.lastReceivedKey._serialized)', 'window.Store.Msg.get(chat.lastReceivedKey._serialized || chat.lastReceivedKey.$1)'],
    ['window.Store.Msg.getMessagesById([chat.lastReceivedKey._serialized])', 'window.Store.Msg.getMessagesById([chat.lastReceivedKey._serialized || chat.lastReceivedKey.$1])'],
    ['window.Store.WidFactory.createWid(chat.id._serialized)', 'window.Store.WidFactory.createWid(chat.id._serialized || chat.id.$1)'],
    ['WAWebCollections.Msg.get(chat.lastReceivedKey._serialized)', 'WAWebCollections.Msg.get(chat.lastReceivedKey._serialized || chat.lastReceivedKey.$1)'],
    [`window.require('WAWebCollections').Msg.get(chat.lastReceivedKey._serialized)`, `window.require('WAWebCollections').Msg.get(chat.lastReceivedKey._serialized || chat.lastReceivedKey.$1)`],
    [`window.require('WAWebCollections').Msg.get(msg.id._serialized)`, `window.require('WAWebCollections').Msg.get(msg.id._serialized || msg.id.$1)`],
    [`window.require('WAWebCollections').Msg.getMessagesById([chat.lastReceivedKey._serialized])`, `window.require('WAWebCollections').Msg.getMessagesById([chat.lastReceivedKey._serialized || chat.lastReceivedKey.$1])`],
    ['WAWebCollections.Msg.get(msg.id._serialized)', 'WAWebCollections.Msg.get(msg.id._serialized || msg.id.$1)'],
    [`WAWebCollections.Msg.get(chat.lastReceivedKey._serialized) || await window.require('WAWebCollections').Msg.getMessagesById([chat.lastReceivedKey._serialized])`, `WAWebCollections.Msg.get(chat.lastReceivedKey._serialized || chat.lastReceivedKey.$1) || await window.require('WAWebCollections').Msg.getMessagesById([chat.lastReceivedKey._serialized || chat.lastReceivedKey.$1])`],
    [`window.require('WAWebWidFactory').createWid(chat.id._serialized)`, `window.require('WAWebWidFactory').createWid(chat.id._serialized || chat.id.$1)`],
  ];
  for (const [from, to] of replacements) out = out.replaceAll(from, to);

  // WhatsApp Web 2.3000.x can expose MediaData.__x_id as an enumerable
  // private field. In v1.34.7 it is spread into the outgoing message object
  // and can overwrite the real Msg id. Remove it only after the message object
  // has been assembled; never reference an out-of-scope mediaOptions variable.
  if (out.includes('const message = {') && !out.includes('CHAT_BOT_MEDIA_ID_SAFE') && !out.includes('delete message.__x_id;')) {
    // Preserve the statement after the closing brace of the assembled message object.
    // Upstream whatsapp-web.js uses different blank-line formatting across releases,
    // so anchor on its canonicalUrl comment rather than requiring a brittle exact string.
    const messageStart = out.indexOf('const message = {');
    const commentIndex = out.indexOf("// Bot's won't reply if canonicalUrl is set (linking)", messageStart);
    if (messageStart >= 0 && commentIndex > messageStart) {
      const lineStart = out.lastIndexOf('\n', commentIndex) + 1;
      const indent = (out.slice(lineStart, commentIndex).match(/^[ \t]*/) || [''])[0];
      const injection = `${indent}/* CHAT_BOT_MEDIA_ID_SAFE */\n${indent}delete message.__x_id;\n`;
      out = out.slice(0, lineStart) + injection + out.slice(lineStart);
    }
  }

  out = out.replaceAll('WAWebCollections.Msg.get(newMsgKey._serialized)', 'WAWebCollections.Msg.get(newMsgKey._serialized || newMsgKey.$1)');

  // WhatsApp Web 2.3000.x renamed some serialized message keys from `_serialized` to `$1`.
  // Add a single compatibility accessor and restore the stable key on serialized messages,
  // so existing downstream code continues to see `message.id._serialized`.
  if (!out.includes('window.WWebJS.getMsgKeyId =')) {
    const messageModelMarker = 'window.WWebJS.getMessageModel = (message) => {';
    const helper = `window.WWebJS.getMsgKeyId = (key) => key?._serialized ?? key?.$1 ?? undefined;\n\n    `;
    if (out.includes(messageModelMarker)) out = out.replace(messageModelMarker, helper + messageModelMarker);
  }
  if (out.includes('window.WWebJS.getMessageModel = (message) => {') && !out.includes('CHAT_BOT_SERIALIZED_MESSAGE_ID')) {
    const msgStatement = 'const msg = message.serialize();';
    const at = out.indexOf(msgStatement, out.indexOf('window.WWebJS.getMessageModel = (message) => {'));
    if (at >= 0) {
      const restore = `const msg = message.serialize();\n\n        /* CHAT_BOT_SERIALIZED_MESSAGE_ID */\n        if (typeof msg.id === 'object' && msg.id && msg.id._serialized == null) {\n            const serializedId = window.WWebJS.getMsgKeyId(msg.id);\n            if (serializedId) msg.id = Object.assign({}, msg.id, { _serialized: serializedId });\n        }`;
      out = out.slice(0, at) + out.slice(at).replace(msgStatement, restore, 1);
    }
  }

  // One malformed or LID-based chat must not make getChats() fail for every chat.
  // This exact upstream block is guarded so unknown library layouts fail closed below.
  const getChatsBlock = /window\.WWebJS\.getChats = async \(\) => \{\s*const chats = window\.require\('WAWebCollections'\)\.Chat\.getModelsArray\(\);\s*const chatPromises = chats\.map\(\(chat\) =>\s*window\.WWebJS\.getChatModel\(chat\),\s*\);\s*return await Promise\.all\(chatPromises\);\s*\};/m;
  if (getChatsBlock.test(out)) {
    out = out.replace(getChatsBlock, `window.WWebJS.getChats = async () => {\n        /* CHAT_BOT_LID_CHAT_ISOLATION */\n        const chats = window.require('WAWebCollections').Chat.getModelsArray();\n        const results = [];\n        for (const chat of chats) {\n            try {\n                const model = await window.WWebJS.getChatModel(chat);\n                if (model) results.push(model);\n            } catch {\n                // Skip only the chat whose LID/group metadata cannot be read.\n            }\n        }\n        return results;\n    };`);
  } else if (/window\.WWebJS\.getChats = async \(\) =>/.test(out) && !out.includes('CHAT_BOT_LID_CHAT_ISOLATION') && /Promise\.all\(chatPromises\)/.test(out)) {
    return { text: before, changed: [], ok: false, note: 'تغيّر تركيب getChats في نسخة whatsapp-web.js؛ أُلغي الإصلاح بدل ترك قائمة المحادثات عرضة لفشل شامل.' };
  }

  // Group metadata updates can fail for some LID chats because the ID is not indexed yet.
  // Continue with the locally available serialized metadata instead of aborting the chat list.
  const groupUpdate = /await groupMetadata\.update\(chatWid\);/g;
  if (!out.includes('CHAT_BOT_LID_GROUP_METADATA_GUARD')) out = out.replace(groupUpdate, '/* CHAT_BOT_LID_GROUP_METADATA_GUARD */ try { await groupMetadata.update(chatWid); } catch { /* LID metadata may not be indexed yet. */ }');

  if (!syntaxOk(out, 'whatsapp-web.js/src/util/Injected/Utils.js')) {
    return { text: before, changed: [], ok: false, note: 'النص الناتج من إصلاح Utils.js غير صالح نحويًا؛ لم يتم الكتابة على المكتبة.' };
  }
  const changed = out !== before ? ['Utils.js-sanitized', ...(out.includes('CHAT_BOT_LID_CHAT_ISOLATION') ? ['Utils.js-chat-LID-isolation'] : []), ...(out.includes('CHAT_BOT_SERIALIZED_MESSAGE_ID') ? ['Utils.js-serialized-id-fallback'] : [])] : [];
  return { text: out, changed, ok: true };
}


function patchClientText(source) {
  let out = String(source);
  const before = out;
  const authPoll = /let start = Date\.now\(\);\s*let timeout = this\.options\.authTimeoutMs;\s*let res = false;\s*while \(start > Date\.now\(\) - timeout\) \{\s*res = await this\.pupPage\.evaluate\(\s*(['"])window\.Debug\?\.VERSION != undefined\1,?\s*\);\s*if \(res\) \{\s*break;\s*\}\s*await new Promise\(\(r\) => setTimeout\(r, 200\)\);\s*\}\s*if \(!res\) \{\s*throw ['"]auth timeout['"];\s*\}/m;
  if (authPoll.test(out)) {
    out = out.replace(authPoll, `try {
                // waitForFunction survives WhatsApp Web navigations; evaluate-based polling
                // rejects when Chromium destroys the current execution context.
                const timeout = this.options.authTimeoutMs || 30000;
                await this.pupPage.waitForFunction('window.Debug?.VERSION != undefined', {
                    timeout,
                });
            } catch (error) {
                if (error?.name === 'TimeoutError' || /waiting failed.*timeout/i.test(String(error?.message || error))) {
                    throw 'auth timeout';
                }
                throw error;
            }`);
  } else if (!out.includes("waitForFunction('window.Debug?.VERSION != undefined'")) {
    return { text: before, changed: [], ok: false, note: 'لم يتم العثور على حلقة فحص Debug.VERSION المعروفة في Client.js؛ أُلغي الإصلاح لتجنب تعديل مكتبة غير متوافقة.' };
  }

  const readyPoll = /let start = Date\.now\(\);\s*let res = false;\s*while \(start > Date\.now\(\) - 30000\) \{\s*(?:\/\/[^\r\n]*\s*)?res = await this\.pupPage\.evaluate\(\s*(['"])window\.WWebJS != undefined\1,?\s*\);\s*if \(res\) \{\s*break;\s*\}\s*await new Promise\(\(r\) => setTimeout\(r, 200\)\);\s*\}\s*if \(!res\) \{\s*throw ['"]ready timeout['"];\s*\}/m;
  if (readyPoll.test(out)) {
    out = out.replace(readyPoll, `try {
                            // This wait is also navigation-safe and avoids a stale-context
                            // failure while the injected helpers become available.
                            await this.pupPage.waitForFunction('window.WWebJS != undefined', {
                                timeout: 30000,
                            });
                        } catch (error) {
                            if (error?.name === 'TimeoutError' || /waiting failed.*timeout/i.test(String(error?.message || error))) {
                                throw 'ready timeout';
                            }
                            throw error;
                        }`);
  } else if (!out.includes("waitForFunction('window.WWebJS != undefined'")) {
    return { text: before, changed: [], ok: false, note: 'لم يتم العثور على حلقة انتظار WWebJS المعروفة في Client.js؛ أُلغي الإصلاح لتجنب تعديل مكتبة غير متوافقة.' };
  }

  // Retry only the known context-lost navigation failure, and serialize concurrent
  // injections from initialize() and framenavigated. Do not retry unrelated errors.
  if (!out.includes('async _chatBotInjectOnce()')) {
    const publicInject = /\n\s*async inject\(\) \{/;
    if (!publicInject.test(out)) return { text: before, changed: [], ok: false, note: 'تعذر العثور على Client.inject() لإضافة إعادة المحاولة الآمنة.' };
    const wrapper = `
        async inject() {
            if (this.__chatBotInjectTask) return this.__chatBotInjectTask;
            const task = this._chatBotInjectWithNavigationRetry();
            this.__chatBotInjectTask = task;
            try { return await task; }
            finally { if (this.__chatBotInjectTask === task) this.__chatBotInjectTask = null; }
        }

        async _chatBotInjectWithNavigationRetry() {
            let lastError;
            for (let attempt = 0; attempt < 3; attempt++) {
                try { return await this._chatBotInjectOnce(); }
                catch (error) {
                    lastError = error;
                    const message = String(error?.message || error || '');
                    const navigationFailure = /execution context was destroyed|cannot find context with specified id|most likely because of a navigation/i.test(message);
                    if (!navigationFailure || attempt >= 2) throw error;
                    // Give Chromium time to commit the new document before re-injecting.
                    try {
                        if (this.pupPage && !this.pupPage.isClosed()) {
                            await this.pupPage.waitForFunction('document.readyState === "complete"', { timeout: 20000 });
                        }
                    } catch {}
                    await new Promise(resolve => setTimeout(resolve, 350 * (attempt + 1)));
                }
            }
            throw lastError;
        }

        async _chatBotInjectOnce() {`;
    out = out.replace(publicInject, wrapper);
  }

  // Listen for main-frame navigation before the initial injection. The upstream order
  // installs this listener afterwards, missing the navigation that destroys the context.
  const navBlock = /await this\.inject\(\);\s*this\.pupPage\.on\('framenavigated', async \(frame\) => \{\s*(if \(frame\.url\(\)\.includes\('post_logout=1'\) \|\| this\.lastLoggedOut\) \{[\s\S]*?\})\s*await this\.inject\(\);\s*\}\);/m;
  const navMatch = out.match(navBlock);
  if (navMatch) {
    const listener = `this.pupPage.on('framenavigated', async (frame) => {
                if (frame !== this.pupPage.mainFrame()) return;
                ${navMatch[1]}
                try { await this.inject(); }
                catch (error) { this.emit('error', error); }
            });

            await this.inject();`;
    out = out.replace(navBlock, listener);
  } else if (!out.includes('if (frame !== this.pupPage.mainFrame()) return;')) {
    return { text: before, changed: [], ok: false, note: 'ترتيب مراقب تنقل الإطار في Client.js غير معروف؛ أُلغي الإصلاح بدل المخاطرة بفقدان QR.' };
  }

  if (!syntaxOk(out, 'whatsapp-web.js/src/Client.js')) {
    return { text: before, changed: [], ok: false, note: 'Client.js الناتج من إصلاح دورة التنقل غير صالح نحويًا؛ لم تتم الكتابة.' };
  }
  const changed = out !== before ? ['Client.js-navigation-safe-injection'] : [];
  return { text: out, changed, ok: true, note: changed.length ? 'تم إصلاح الانتظار أثناء التنقل وإعادة حقن Client بأمان.' : 'Client.js يحتوي الإصلاحات المطلوبة بالفعل.' };
}

function patchClientProfilePicText(source) {
  const before = String(source);
  let out = before;
  const start = out.indexOf('async getProfilePicUrl(contactId)');
  const end = start >= 0 ? out.indexOf('async getCommonGroups(', start) : -1;
  if (start < 0 || end < 0) {
    if (/findOrCreateLatestChat\s*\(wid\)/.test(out) && /requestProfilePicFromServer\(chat\)/.test(out)) {
      return { text: before, changed: false, ok: true, note: 'Client.js يحتوي على إصلاح جلب صورة الملف الشخصي بالفعل.' };
    }
    return { text: before, changed: false, ok: false, note: 'لم يتم العثور على حدود getProfilePicUrl المتوقعة؛ لم يتم تعديل Client.js.' };
  }
  const method = out.slice(start, end);
  if (/findOrCreateLatestChat\s*\(wid\)/.test(method) && /requestProfilePicFromServer\(chat\)/.test(method)) {
    return { text: before, changed: false, ok: true, note: 'إصلاح جلب صورة الملف الشخصي موجود بالفعل.' };
  }
  const pattern = /const\s+chat\s*=\s*await\s+window\.WWebJS\.getChat\(contactId\)\s*;\s*return\s+await\s+window\s*\.require\(['"]WAWebContactProfilePicThumbBridge['"]\)\s*\.requestProfilePicFromServer\(chat\)\s*;/s;
  const replacement = `const wid = window.require('WAWebWidFactory').createWid(contactId);\n                    const result = await window.require('WAWebFindChatAction').findOrCreateLatestChat(wid);\n                    const chat = result && (result.chat || result);\n                    if (!chat) return undefined;\n                    return await window.require('WAWebContactProfilePicThumbBridge').requestProfilePicFromServer(chat);`;
  const patchedMethod = method.replace(pattern, replacement);
  if (patchedMethod === method) {
    return { text: before, changed: false, ok: false, note: 'تغيّر تركيب getProfilePicUrl في Client.js؛ لم يتم تعديل الملف بشكل تخميني.' };
  }
  out = out.slice(0, start) + patchedMethod + out.slice(end);
  if (!syntaxOk(out, 'whatsapp-web.js/src/Client.js')) {
    return { text: before, changed: false, ok: false, note: 'فشل فحص صياغة Client.js بعد إصلاح جلب الصورة؛ تم إلغاء التعديل.' };
  }
  return { text: out, changed: true, ok: true, note: 'تم إصلاح جلب صورة WhatsApp باستخدام واجهات العثور على المحادثة الأحدث.' };
}

function patchPuppeteerText(source) {
  const before = String(source);
  let out = before;
  const marker = 'CHAT_BOT_EXPOSE_FUNCTION_RACE_GUARD';

  // whatsapp-web.js 1.34.7 has shipped with multiple formatting variants of
  // exposeFunctionIfAbsent. Some builds already include the upstream race guard
  // (try/catch + "already exists") but do not contain our marker. Treat that as
  // already repaired instead of failing npm postinstall.
  const fnStartMatch = out.match(/async\s+function\s+exposeFunctionIfAbsent\s*\(/);
  if (!fnStartMatch) {
    return {
      text: before,
      changed: false,
      ok: false,
      note: 'لم يتم العثور على دالة exposeFunctionIfAbsent في Puppeteer.js؛ لم يتم تغيير المكتبة.'
    };
  }

  const start = fnStartMatch.index;
  const exportAt = out.indexOf('module.exports', start);
  const end = exportAt >= 0 ? exportAt : out.length;
  const method = out.slice(start, end);

  if (method.includes(marker)) {
    return { text: before, changed: false, ok: true, note: 'Puppeteer.js يحتوي حارس تكرار exposeFunction بالفعل.' };
  }

  const hasExposeCall = /page\s*\.\s*exposeFunction\s*\(\s*name\s*,\s*fn\s*\)/.test(method);
  const hasEquivalentGuard = hasExposeCall &&
    /catch\s*\(\s*(?:err|error)\s*\)[\s\S]*?(?:already\s+exists|already exists)/i.test(method) &&
    /try\s*\{[\s\S]*?page\s*\.\s*exposeFunction\s*\(\s*name\s*,\s*fn\s*\)/.test(method);

  if (hasEquivalentGuard) {
    return {
      text: before,
      changed: false,
      ok: true,
      note: 'Puppeteer.js يحتوي حماية مكافئة من تسجيل callback مكرر؛ تم الإبقاء على كود المكتبة دون تعديل.'
    };
  }

  // Change only the exposeFunction call, rather than matching the whole function
  // body. This accepts harmless whitespace/brace changes between library builds.
  const callPattern = /^([ \t]*)await\s+page\s*\.\s*exposeFunction\s*\(\s*name\s*,\s*fn\s*\)\s*;/m;
  if (!callPattern.test(method)) {
    return {
      text: before,
      changed: false,
      ok: false,
      note: 'تركيب exposeFunctionIfAbsent مختلف ولا يحتوي استدعاء exposeFunction المتوقع؛ لم يتم تعديل Puppeteer.js.'
    };
  }

  const patchedMethod = method.replace(callPattern, (_match, indent) =>
    `${indent}try {\n` +
    `${indent}    await page.exposeFunction(name, fn);\n` +
    `${indent}} catch (error) {\n` +
    `${indent}    /* ${marker}: duplicate concurrent registration is safe. */\n` +
    `${indent}    if (!/already exists/i.test(String(error?.message || error))) throw error;\n` +
    `${indent}}`
  );
  out = out.slice(0, start) + patchedMethod + out.slice(end);

  if (!syntaxOk(out, 'whatsapp-web.js/src/util/Puppeteer.js')) {
    return { text: before, changed: false, ok: false, note: 'Puppeteer.js الناتج غير صالح نحويًا؛ أُلغي التعديل.' };
  }
  return {
    text: out,
    changed: out !== before,
    ok: true,
    note: 'تمت إضافة حماية من انهيار الربط عند تسجيل callback مكرر بالتزامن.'
  };
}

function packageRoot() {
  try { return path.dirname(require.resolve('whatsapp-web.js/package.json')); }
  catch { return null; }
}

function patch() {
  const result = { ok: true, changed: [], notes: [], packageVersion: null };
  let packageMetadataAvailable = false;
  try {
    const root = packageRoot();
    if (!root) {
      result.notes.push('whatsapp-web.js غير مثبت بعد. سيتم تنفيذ الإصلاح بعد تثبيت الاعتماديات.');
      return result;
    }
    try {
      const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
      packageMetadataAvailable = true;
      result.packageVersion = pkg.version || null;
    } catch {}

    const utils = path.join(root, 'src', 'util', 'Injected', 'Utils.js');
    if (fs.existsSync(utils)) {
      const before = fs.readFileSync(utils, 'utf8');
      const fixed = patchUtilsText(before);
      if (!fixed.ok) { result.ok = false; result.notes.push(fixed.note || 'تعذر إصلاح Utils.js بأمان.'); return result; }
      if (fixed.text !== before) {
        const tmp = `${utils}.chatbot.tmp`;
        fs.writeFileSync(tmp, fixed.text, 'utf8');
        if (!syntaxOk(fixed.text, utils)) { fs.rmSync(tmp, { force: true }); result.ok = false; result.notes.push('فشل فحص الصياغة بعد إصلاح Utils.js؛ تم إلغاء الكتابة.'); return result; }
        fs.renameSync(tmp, utils); result.changed.push(...fixed.changed);
      }
      result.notes.push(fixed.changed.length ? 'تم إصلاح Utils.js للتوافق مع $1 ومعرّفات LID وعزل المحادثات المتعطلة.' : 'Utils.js سليم ولا يحتاج إصلاحًا إضافيًا.');
    } else {
      result.notes.push('Utils.js غير موجود؛ لم تُجرَ تعديلات عليه.');
    }

    const puppeteerFile = path.join(root, 'src', 'util', 'Puppeteer.js');
    if (fs.existsSync(puppeteerFile)) {
      const before = fs.readFileSync(puppeteerFile, 'utf8');
      const fix = patchPuppeteerText(before);
      if (!fix.ok) { result.ok = false; result.notes.push(fix.note); return result; }
      if (fix.text !== before) {
        const tmp = `${puppeteerFile}.chatbot.tmp`;
        fs.writeFileSync(tmp, fix.text, 'utf8');
        if (!syntaxOk(fix.text, puppeteerFile)) { fs.rmSync(tmp, { force: true }); result.ok = false; result.notes.push('فشل فحص صياغة Puppeteer.js؛ تم إلغاء الكتابة.'); return result; }
        fs.renameSync(tmp, puppeteerFile); result.changed.push('Puppeteer.js-expose-function-race-guard');
      }
      result.notes.push(fix.note);
    }

    const clientFile = path.join(root, 'src', 'Client.js');
    if (fs.existsSync(clientFile)) {
      const before = fs.readFileSync(clientFile, 'utf8');
      const navigationFix = patchClientText(before);
      if (!navigationFix.ok) { result.ok = false; result.notes.push(navigationFix.note || 'تعذر إصلاح Client.js بأمان.'); return result; }
      // The v8.6 compatibility repair for profile photos was missing from v9.9.4.
      // Apply it to the navigation-fixed source, then commit both changes atomically.
      const profileFix = patchClientProfilePicText(navigationFix.text);
      if (!profileFix.ok) { result.ok = false; result.notes.push(profileFix.note || 'تعذر إصلاح جلب صور الحسابات بأمان.'); return result; }
      const finalText = profileFix.text;
      if (finalText !== before) {
        const tmp = `${clientFile}.chatbot.tmp`;
        fs.writeFileSync(tmp, finalText, 'utf8');
        if (!syntaxOk(finalText, clientFile)) { fs.rmSync(tmp, { force: true }); result.ok = false; result.notes.push('فشل فحص الصياغة بعد إصلاحات Client.js؛ تم إلغاء الكتابة.'); return result; }
        fs.renameSync(tmp, clientFile);
        result.changed.push(...navigationFix.changed);
        if (profileFix.changed) result.changed.push('Client.js-profile-picture-compat');
      }
      result.notes.push(navigationFix.note);
      result.notes.push(profileFix.note);
    } else if (packageMetadataAvailable && process.env.NODE_ENV !== 'test') {
      result.ok = false;
      result.notes.push('Client.js غير موجود داخل whatsapp-web.js؛ لا يمكن ضمان إصلاح مشكلة QR والصور.');
    } else {
      result.notes.push('لم يظهر مصدر Client.js في مسار مكتبة محاكى/غير مكتمل؛ تم تخطي فحص المصدر فقط.');
    }
    return result;
  } catch (e) {
    result.ok = false;
    result.notes.push(e?.message || String(e));
    return result;
  }
}

if (require.main === module) {
  const r = patch();
  console.log(JSON.stringify(r, null, 2));
  if (!r.ok) process.exitCode = 1;
}

module.exports = { patch, patchUtilsText, patchClientText, patchClientProfilePicText, patchPuppeteerText, syntaxOk };
