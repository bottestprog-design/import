'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

function pidIsAlive(pid) {
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try { process.kill(pid, 0); return true; }
  catch (error) { return error?.code === 'EPERM'; }
}

function readLock(file) {
  try {
    const raw = fs.readFileSync(file, 'utf8');
    const value = JSON.parse(raw);
    if (Number.isInteger(value?.pid) && value.pid > 0 && typeof value.token === 'string') return { raw, value };
    return { raw, value: null };
  } catch { return null; }
}

function acquireProcessLock(lockPath) {
  const file = path.resolve(lockPath);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const token = crypto.randomUUID();
  const record = JSON.stringify({ pid: process.pid, token, startedAt: new Date().toISOString() });
  for (let attempt = 0; attempt < 3; attempt++) {
    let fd;
    try {
      fd = fs.openSync(file, 'wx', 0o600);
      fs.writeFileSync(fd, record, 'utf8');
      fs.fsyncSync(fd);
      fs.closeSync(fd); fd = undefined;
      let released = false;
      const release = () => {
        if (released) return;
        released = true;
        const current = readLock(file);
        if (current?.value?.pid === process.pid && current.value.token === token) {
          try { fs.unlinkSync(file); } catch {}
        }
      };
      process.once('exit', release);
      return { path: file, pid: process.pid, release };
    } catch (error) {
      if (fd !== undefined) { try { fs.closeSync(fd); } catch {} }
      if (error?.code !== 'EEXIST') throw error;
      const existing = readLock(file);
      if (existing?.value && pidIsAlive(existing.value.pid)) {
        throw Object.assign(new Error(`يبدو أن نسخة أخرى من chat BOT تعمل بالفعل (PID ${existing.value.pid}). أغلق النسخة القديمة قبل تشغيل هذه النسخة حتى لا تتعارض جلسة WhatsApp وملف Chromium.`), { code: 'CHATBOT_ALREADY_RUNNING', existingPid: existing.value.pid });
      }
      // Only reclaim a valid dead-PID lock. Malformed files must age before cleanup to avoid
      // racing the tiny window between another process creating and writing its lock record.
      if (!existing?.value) {
        let age = 0;
        try { age = Date.now() - fs.statSync(file).mtimeMs; } catch { continue; }
        if (age < 30000) throw new Error('ملف قفل تشغيل chat BOT غير مكتمل. انتظر ثواني قليلة ثم أعد المحاولة؛ لم يتم حذف أي بيانات.');
      }
      const before = existing?.raw;
      const fresh = readLock(file);
      if (fresh?.raw !== before) continue;
      try { fs.unlinkSync(file); } catch { continue; }
    }
  }
  throw new Error('تعذر الحصول على قفل تشغيل chat BOT بعد عدة محاولات. تحقق من وجود نسخة قديمة ما زالت تعمل.');
}

module.exports = { acquireProcessLock, pidIsAlive };
