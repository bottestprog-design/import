"use strict";
function parts(date, tz) { const p = new Intl.DateTimeFormat('en-US', { timeZone: tz, weekday: 'short', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(date); const g = k => p.find(x => x.type === k)?.value; const wd = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[g('weekday')]; return { year: +g('year'), month: +g('month'), day: +g('day'), hour: +g('hour'), minute: +g('minute'), weekday: wd }; }
function validTime(v) { const m = String(v || '17:30').match(/^(\d{2}):(\d{2})$/); return m && +m[1] < 24 && +m[2] < 60 ? { h: +m[1], m: +m[2] } : null; }
function zonedDateToUtc(dateText, timeText, tz) { const [y, m, d] = String(dateText).split('-').map(Number), tm = validTime(timeText); if (!y || !m || !d || !tm) return null; let guess = new Date(Date.UTC(y, m - 1, d, tm.h, tm.m, 0)); for (let i = 0; i < 8; i++) { const p = parts(guess, tz), asUtc = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute), wantUtc = Date.UTC(y, m - 1, d, tm.h, tm.m), diff = wantUtc - asUtc; if (Math.abs(diff) < 1000) return guess; guess = new Date(guess.getTime() + diff); } return guess; }
function localDate(x) { return `${x.year}-${String(x.month).padStart(2, '0')}-${String(x.day).padStart(2, '0')}`; }
function dateAdd(y, m, d, offset) { const dt = new Date(Date.UTC(y, m - 1, d) + offset * 86400000); return { year: dt.getUTCFullYear(), month: dt.getUTCMonth() + 1, day: dt.getUTCDate() }; }
function matchesCalendar(p, item) { const mode = item.mode || 'weekly'; if (mode === 'daily') return true; if (mode === 'weekly') return p.weekday === Number(item.day ?? 5); if (mode === 'monthly') return p.day === Number(item.dayOfMonth || 1) && (!item.month || Number(item.month) === p.month) && (!item.year || Number(item.year) === p.year); if (mode === 'yearly') return p.day === Number(item.dayOfMonth || 1) && Number(item.month) === p.month && (!item.year || Number(item.year) === p.year); if (mode === 'once') return true; return false; }
function dueForItem(now, item) { const tz = item.timezone || 'Asia/Muscat', p = parts(now, tz), tm = validTime(item.time || '17:30'); if (!tm || item.enabled === false) return { due: false, key: '' }; const minute = p.hour * 60 + p.minute, target = tm.h * 60 + tm.m; if (minute < target || minute > target + 5) return { due: false, key: '' }; if (item.mode === 'once') { if (String(item.date) !== localDate(p)) return { due: false, key: '' }; } else if (!matchesCalendar(p, item)) return { due: false, key: '' }; const key = `${item.id || 'legacy'}|${item.mode || 'weekly'}|${localDate(p)}|${item.time}`; return { due: item.lastRunKey !== key, key }; }
function nextRunForItem(item, now = new Date()) { if (item.enabled === false) return null; const tz = item.timezone || 'Asia/Muscat', mode = item.mode || 'weekly', time = String(item.time || '17:30'); if (mode === 'once') { const target = zonedDateToUtc(item.date, time, tz); return target && target.getTime() >= now.getTime() ? target.toISOString() : null; } const start = parts(now, tz); for (let off = 0; off < 800; off++) { const x = dateAdd(start.year, start.month, start.day, off), p = { ...x, weekday: new Date(Date.UTC(x.year, x.month - 1, x.day)).getUTCDay(), hour: 0, minute: 0 }; if (!matchesCalendar(p, item)) continue; const target = zonedDateToUtc(localDate(x), time, tz); if (target && target.getTime() >= now.getTime()) return target.toISOString(); } return null; }
function legacy(s) { const st = s.settings || {}; return { id: 'legacy', enabled: st.scheduleEnabled, mode: st.scheduleMode, time: st.scheduleTime, date: st.scheduleDate, day: st.scheduleDay, dayOfMonth: st.scheduleMonthDay, month: st.scheduleMonth, year: st.scheduleYear, timezone: st.timezone, lastRunKey: s.scheduleState?.lastRunKey || '' }; }
function due(now, s) { return dueForItem(now, legacy(s)); }
function nextRun(s, now = new Date()) { return nextRunForItem(legacy(s), now); }
class ReliableScheduler {
  constructor({ store, run, runTask, runAutomation, log }) { this.store = store; this.run = run; this.runTask = runTask; this.runAutomation = runAutomation; this.log = log; this.busy = new Set(); this.taskBusy = new Set(); this.lastFail = new Map(); this.paused = false; this.activeTicks = 0; this.timer = setInterval(() => { if (!this.paused) this.tick().catch(e => this.log(null, 'ERROR', `Scheduler: ${e.message}`)); }, 1000); }
  stop() { clearInterval(this.timer); }
  async pause() { this.paused = true; for (let i = 0; i < 300 && this.activeTicks > 0; i++) await new Promise(resolve => setTimeout(resolve, 50)); if (this.activeTicks > 0) { this.paused = false; throw new Error('لم يتوقف مجدول الرسائل بأمان لأن مهمة ما زالت تعمل. أعد المحاولة بعد انتهائها.'); } }
  resume() { this.paused = false; }
  async tick() { this.activeTicks++; try { if (this.paused) return; for (const id of this.store.listSessionIds()) { try { await this.tickSession(id); } catch (e) { this.log(id, 'ERROR', `Scheduler: ${e.message}`); } } } finally { this.activeTicks--; } }
  async tickSession(id) {
    if (this.busy.has(id)) return;
    let s = this.store.loadSession(id), now = new Date(), legacyDue = due(now, s);
    if (legacyDue.due && Date.now() - (this.lastFail.get(`legacy:${id}`) || 0) > 10000) { this.busy.add(id); try { const result = await this.run(id); const fresh = this.store.loadSession(id); if (result?.ok === true || result?.complete === true) { fresh.scheduleState.lastRunKey = legacyDue.key; this.lastFail.delete(`legacy:${id}`); } else this.lastFail.set(`legacy:${id}`, Date.now()); this.store.saveSession(fresh); } catch (e) { this.lastFail.set(`legacy:${id}`, Date.now()); this.log(id, 'ERROR', `فشل الموعد: ${e.message}`); } finally { this.busy.delete(id); } }
    s = this.store.loadSession(id);
    if (s.settings.automationEnabled === false || s.automation.enabled === false) { if (typeof this.runAutomation === 'function') await this.runAutomation(id, now); return; }
    for (const task of s.automation.tasks || []) {
      const td = dueForItem(now, { ...task, timezone: s.settings.timezone }); if (!td.due) continue;
      const key = `task:${id}:${task.id}`; if (this.taskBusy.has(key) || Date.now() - (this.lastFail.get(key) || 0) < 10000) continue;
      this.taskBusy.add(key);
      try {
        const result = await this.runTask(id, task), after = this.store.loadSession(id), saved = after.automation.tasks.find(x => x.id === task.id);
        if (saved && (result?.ok === true || result?.complete === true)) { saved.lastRunKey = td.key; saved.lastResult = result; saved.updatedAt = new Date().toISOString(); if (saved.mode === 'once') saved.enabled = false; after.automation.recent = [...(after.automation.recent || []), { at: new Date().toISOString(), taskId: saved.id, name: saved.name, ok: true, result: { sent: result.sent?.length || 0, failed: result.failed?.length || 0 } }].slice(-100); this.store.saveSession(after); this.lastFail.delete(key); } else this.lastFail.set(key, Date.now());
      } catch (e) { this.lastFail.set(key, Date.now()); const fresh = this.store.loadSession(id); fresh.automation.recent = [...(fresh.automation.recent || []), { at: new Date().toISOString(), taskId: task.id, name: task.name, ok: false, error: e.message }].slice(-200); this.store.saveSession(fresh); this.log(id, 'ERROR', `فشل الموعد ${task.name || task.id}: ${e.message}`); } finally { this.taskBusy.delete(key); }
    }
    if (typeof this.runAutomation === 'function') {
      try { await this.runAutomation(id, now); }
      catch (e) { this.log(id, 'ERROR', `فشل محرك الأتمتة: ${e.message || e}`); }
    }
  }
}
module.exports = { ReliableScheduler, parts, due, nextRun, zonedDateToUtc, dueForItem, nextRunForItem, validTime };
