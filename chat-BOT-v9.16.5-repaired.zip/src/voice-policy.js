'use strict';
const { quiet, scopeOk } = require('./interaction');

/** Keep diagnostic replies for unconfigured voice processing inside the same
 * delivery controls as ordinary interactions. The owner's self-chat is always
 * allowed to receive a local setup diagnostic. */
function maySendVoiceSetupNotice({ session, chatId, isSelfChat = false, isGroup = false, now = new Date() } = {}) {
  if (isSelfChat) return true;
  const settings = session?.settings || {};
  if (settings.interactionEnabled === false || session?.interaction?.enabled === false) return false;
  if (isGroup && settings.groupAssistantEnabled === false) return false;
  if (quiet(settings, now)) return false;
  return scopeOk(settings.interactionScope || 'all', String(chatId || ''), settings.interactionChatIds || []);
}
module.exports = { maySendVoiceSetupNotice };
