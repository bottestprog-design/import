'use strict';

const { inferIntent, normalizeArabic } = require('./trigger-engine');

const DEFAULT_SYSTEM_PROMPT = `أنت مساعد خدمة عملاء محترف، مهذب وموجز، تكتب بلغة العميل ولهجته قدر الإمكان. اقرأ كامل سياق المحادثة قبل الإجابة، وافهم المقصود حتى مع الأخطاء الإملائية البسيطة. لا تخترع أسعارًا أو مخزونًا أو سياسات أو مواعيد أو معلومات غير موجودة في السياق. عند نقص البيانات اسأل سؤالًا واحدًا واضحًا. لا تطلب كلمات مرور أو رموز تحقق أو بيانات دفع حساسة. لا تعد العميل بإجراء لم يحدث. لا تذكر أنك نموذج ذكاء اصطناعي إلا إذا سُئلت. أعد نص الرد فقط دون مقدمات أو علامات اقتباس.`;

function templateReply(message, { sender = 'أهلًا بك', fallbackReply = '' } = {}) {
  const text = String(message || '').trim();
  const intent = inferIntent(text);
  if (intent === 'greeting') return `وعليكم السلام ورحمة الله وبركاته، أهلًا بك${sender && sender !== 'صديق' ? ` يا ${sender}` : ''} 🌷 كيف أقدر أساعدك؟`;
  if (intent === 'thanks') return 'العفو، يسعدنا خدمتك 🌷 هل تحتاج أي مساعدة أخرى؟';
  if (intent === 'farewell') return 'في أمان الله، سعدنا بتواصلك. يسعدنا خدمتك في أي وقت 🌷';
  if (intent === 'price') return 'يسعدني أساعدك بالسعر. ما اسم المنتج أو الخدمة التي تسأل عنها، وأي حجم أو نوع تقصد؟ لا أريد أن أعطيك سعرًا غير دقيق.';
  if (intent === 'availability') return 'أهلًا بك! ما المنتج أو الخدمة التي تريد التأكد من توفرها؟ اذكر الاسم أو أرسل صورة حتى أتحقق من المقصود.';
  if (intent === 'complaint') return 'أعتذر لك عن التجربة غير المرضية. اشرح لي المشكلة باختصار، واذكر رقم الطلب إن وجد من دون مشاركة أي بيانات دفع أو رموز سرية، حتى نحدد الخطوة المناسبة.';
  if (intent === 'help') return 'بالطبع، أنا هنا للمساعدة. ما الذي تحتاجه تحديدًا؟ يمكنك شرح طلبك أو إرسال صورة توضح المشكلة.';
  if (intent === 'confirmation') return 'تمام، شكرًا للتوضيح. هل هناك تفاصيل أخرى تريد إضافتها؟';
  if (intent === 'negation') return 'حسنًا، فهمت. ما الذي تريد تغييره أو ما الخيار الذي يناسبك أكثر؟';
  if (intent === 'question') return 'سأساعدك قدر الإمكان. هل يمكنك توضيح الشيء الذي تسأل عنه أو ذكر اسم المنتج/الخدمة حتى تكون الإجابة دقيقة؟';
  if (String(fallbackReply || '').trim()) return String(fallbackReply).replace(/\{\{message\}\}/g, text.slice(0, 300)).replace(/\{\{sender\}\}/g, sender).slice(0, 1500);
  return 'شكرًا لتواصلك معنا 🌷 أريد التأكد من فهم طلبك بشكل صحيح. هل يمكنك توضيح ما تحتاجه أو إرسال تفاصيل أكثر؟';
}

function conversationSystemPrompt(custom = '') {
  const supplied = String(custom || '').trim().slice(0, 3000);
  return supplied ? `${DEFAULT_SYSTEM_PROMPT}\n\nتعليمات مالك البوت الإضافية:\n${supplied}` : DEFAULT_SYSTEM_PROMPT;
}

function messageLooksLikeEmptyMedia(message) {
  return !String(message || '').trim();
}

module.exports = { templateReply, conversationSystemPrompt, DEFAULT_SYSTEM_PROMPT, messageLooksLikeEmptyMedia };
