'use strict';

function cleanOutboundText(value) {
  return String(value ?? '').normalize('NFC').replace(/\u0000/g, '').replace(/\r\n?/g, '\n').replace(/[\t\u00A0]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{4,}/g, '\n\n\n').trim();
}
function validateOutboundText(value, { maxLength = 60000, allowEmpty = false } = {}) {
  const text = cleanOutboundText(value), issues = [];
  if (!text && !allowEmpty) issues.push({ code: 'EMPTY', message: 'نص الرسالة فارغ.' });
  if (text.length > maxLength) issues.push({ code: 'TOO_LONG', message: `نص الرسالة تجاوز الحد المسموح (${maxLength} حرفًا).` });
  const placeholders = [...text.matchAll(/\{\{\s*([^{}\s]+)\s*\}\}/g)].map(match => match[1]).slice(0, 8);
  if (placeholders.length) issues.push({ code: 'UNRESOLVED_TEMPLATE', message: `توجد متغيرات لم تُستبدل: ${placeholders.join('، ')}.` });
  if (/(?:undefined|null)(?:\s|$)/iu.test(text)) issues.push({ code: 'LEAKED_VALUE', message: 'قد يحتوي النص على قيمة برمجية غير مقصودة.' });
  return { ok: issues.length === 0, text, issues, length: text.length };
}
function lintRuleReply(value) {
  const check = validateOutboundText(value, { maxLength: 60000 });
  const warnings = [];
  if (/\b(?:TODO|FIXME|lorem ipsum)\b/i.test(check.text)) warnings.push('يحتوي الرد على نص تجريبي غير مكتمل.');
  const lines = check.text.split('\n').map(line => line.trim()).filter(Boolean);
  if (lines.length >= 3 && new Set(lines).size <= Math.ceil(lines.length / 2)) warnings.push('توجد أسطر متكررة بشكل ملحوظ.');
  return { ...check, warnings, score: Math.max(0, 100 - check.issues.length * 45 - warnings.length * 10) };
}
module.exports = { cleanOutboundText, validateOutboundText, lintRuleReply };
