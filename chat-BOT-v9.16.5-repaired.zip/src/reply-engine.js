"use strict";
const { inferIntent } = require('./trigger-engine');

function replyVariants(item) {
  const then = item?.then || item || {};
  const source = Array.isArray(then.replies) && then.replies.length ? then.replies : Array.isArray(then.replyVariants) && then.replyVariants.length ? then.replyVariants : [then.reply || ''];
  return [...new Set(source.map(x => String(x ?? '').trim()).filter(Boolean))].slice(0, 80).map(x => x.slice(0, 1500));
}
function shuffle(values) {
  const out = [...values];
  for (let i = out.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [out[i], out[j]] = [out[j], out[i]]; }
  return out;
}
function pickReply(item, variantState = {}, key = '') {
  const variants = replyVariants(item);
  if (!variants.length) return '';
  if (variants.length === 1) return variants[0];
  const bucketKey = String(key || item.id || 'default');
  let bucket = variantState[bucketKey];
  if (!bucket || !Array.isArray(bucket.order) || !Array.isArray(bucket.used)) bucket = { order: [], used: [], last: -1, picks: 0 };
  if (!bucket.order.length) {
    const remaining = variants.map((_, i) => i).filter(i => !bucket.used.includes(i));
    if (!remaining.length) { bucket.used = []; remaining.push(...variants.map((_, i) => i)); }
    bucket.order = shuffle(remaining);
    if (bucket.order.length > 1 && bucket.order[0] === bucket.last) [bucket.order[0], bucket.order[1]] = [bucket.order[1], bucket.order[0]];
  }
  const idx = bucket.order.shift();
  bucket.used.push(idx); bucket.last = idx; bucket.picks = Number(bucket.picks || 0) + 1;
  if (bucket.used.length >= variants.length) bucket.used = [];
  variantState[bucketKey] = bucket;
  const keys = Object.keys(variantState);
  if (keys.length > 2000) for (const stale of keys.slice(0, keys.length - 2000)) delete variantState[stale];
  return variants[idx] || variants[0];
}
function renderTemplate(template, ctx = {}, timezone = 'Asia/Muscat') {
  let time = '';
  try { time = new Intl.DateTimeFormat('ar-OM', { timeZone: timezone, hour: '2-digit', minute: '2-digit' }).format(new Date()); } catch { time = new Date().toLocaleTimeString(); }
  const message = String(ctx.message || ''), sender = String(ctx.sender || 'صديق');
  const firstName = String(ctx.firstName || sender.split(/[\s_-]+/)[0] || sender);
  const intent = String(ctx.intent || inferIntent(message));
  const vars = {
    message, sender, firstName, chat: String(ctx.chat || ''), time, type: String(ctx.type || ''), emoji: String(ctx.emoji || ''),
    count: String(ctx.count ?? ctx.messageCount ?? ''), messageCount: String(ctx.messageCount ?? ctx.count ?? ''),
    lastMessage: String(ctx.lastMessage || ''), lastIntent: String(ctx.lastIntent || ''), intent,
    day: (() => { try { return new Intl.DateTimeFormat('ar-OM', { timeZone: timezone, weekday: 'long' }).format(new Date()); } catch { return ''; } })()
  };
  return String(template || '').replace(/\{\{\s*([a-zA-Z]+)\s*\}\}/g, (match, key) => Object.prototype.hasOwnProperty.call(vars, key) ? vars[key] : match).trim().slice(0, 4000);
}
module.exports = { replyVariants, pickReply, renderTemplate };
