'use strict';

const crypto = require('node:crypto');
const recipientManagement = require('./recipient-management');
const whatsappContacts = require('./whatsapp-contacts');
const { classifyCommand } = require('./command-understanding');
const interactionTools = require('./interaction');
const triggerEngine = require('./trigger-engine');
const chatRuleLanguage = require('./chat-rule-language');
const conversationTargets = require('./conversation-targets');
const conversationRecall = require('./conversation-recall');
const ruleDiagnostics = require('./rule-diagnostics');

const WELCOME_GUIDE = `أهلًا بك في chat BOT 🤖
أنا مساعدك المحلي داخل محادثة «الرسائل إلى نفسك». لا أستخدم API ذكاء اصطناعي خارجيًا؛ أفهم الأوامر المحلية وأدير حوارات قصيرة خطوة بخطوة.

ابدأ بكتابة أحد الأوامر:
• مساعدة — عرض الأوامر.
• الحالة — حالة الاتصال والأعداد.
• عايز أضيف شخص جديد — حوار إضافة اسم ودولة ورقم، مع معالجة التكرار.
• أرسل رسالة — اختيار مستلم، كتابة الرسالة، ثم تأكيد الإرسال.
• أنشئ موعد — إعداد رسالة مجدولة خطوة بخطوة.
• أنشئ رد تلقائي — تحديد العبارة والرد ثم تأكيد الحفظ.
• استدعاء جهات واتساب — معاينة جهات WhatsApp؛ ثم اكتب «تأكيد المزامنة» لاستيراد الجهات الرقمية الجديدة.
• استخرج الملفات من محادثة أحمد، أو استخرج الصوتيات/الصور/المستندات من محادثة أحمد — اختر المحادثة ثم اكتب «تأكيد التنزيل» حرفيًا.
• قائمة المحادثات — عرض محادثات الأشخاص والمجموعات المسجلة في المشروع فقط.
• هات آخر 10 رسائل من أحمد — اقرأ آخر رسائل جهة مسجلة من دون إرسال لها.
• ابحث في محادثة أحمد عن فاتورة — ابحث في السجل المتاح والأرشيف المحلي لجهة مسجلة.
• قائمة الأشخاص / قائمة المجموعات / سجل النشاط / اعرض المواعيد / اعرض الوسائط.
• ماذا تستطيع أن تفعل؟ — شرح الإمكانيات. «ملخص النظام»، «القواعد المفعّلة»، «العدادات».
• تشخيص محادثي: «طمني الاتصال عامل ايه»، «ليه البوت مش بيرد»، «وريني كل اعدادات التشغيل»، «ايه آخر حاجة حصلت».
• إدارة القواعد: «مساعدة القواعد» لعرض صيغة ثابتة، ثم استخدم «قاعدة تفاعل» مع حقول اسم/عندما/رد/نطاق/تهدئة. سيعرض البوت فهمه ولن يحفظ إلا بعد «تأكيد القاعدة».
• اختبار القواعد: «اختبر الرد التلقائي على: السلام عليكم» — محاكاة دون إرسال رسالة. «شخّص الرد التلقائي على: السلام عليكم» يوضح سبب التعارض أو توقف القاعدة.
• الصوت الوارد: «فرّغ آخر صوتية»؛ يحتاج Whisper المحلي.
• صوت البوت: «انطق آخر رد» لتحويل آخر رد إلى رسالة صوتية عربية محلية؛ «فحص النطق» يراجع جاهزية المحرك والتدقيق، و«اختبر النطق» يرسل عينة لنفسك فقط.
• قواعد التفاعل: اكتب «مساعدة القواعد» لنسخ القالب الثابت؛ يمكن تحديد الشرط والرد والنطاق ونوع المطابقة والتهدئة. لا تُحفظ أي قاعدة قبل مراجعة الملخص وكتابة «تأكيد القاعدة».
• أوامر مباشرة: أرسل الآن | إلى=أحمد | الرسالة=مرحبًا، وأضف موعد | الاسم=تذكير | التكرار=مرة | التاريخ=2026-11-01 | الوقت=17:30 | إلى=أحمد | الرسالة=النص.
• مساعدة الإرسال / مساعدة المواعيد / مساعدة التفاعل / مساعدة المجموعات.
• دليل الاستخدام — إعادة عرض هذه الرسالة.

يمكنك كتابة «إلغاء» أثناء أي حوار لإيقافه. الإرسال والحذف وتشغيل موعد يدويًا يتطلب تأكيدًا صريحًا. إدارة الأسماء والردود والمواعيد مرتبطة بالجلسة الحالية فقط.
للاستدعاء الانتقائي للأسماء والصور وتحديث الملف الشخصي، افتح لوحة chat BOT ثم «الأشخاص» ← «استدعاء ومزامنة جهات WhatsApp».
• تفريغ صوتية: أرسل صوتية إلى هذه المحادثة ثم اكتب «فرغ آخر صوتية». يحتاج تفريغ الصوت إلى إعداد Whisper محلي في .env؛ لا يتم رفع الصوت إلى خدمة سحابية.`;

function normalize(value) {
  return String(value || '').normalize('NFKC').toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[إأآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
    .replace(/[ـ\u200e\u200f]/g, '').replace(/[،؛.!؟?]/g, ' ').replace(/\s+/g, ' ').trim();
}
function isCancel(text) { return /^(?:الغاء|الغاء الامر|تراجع|وقف|الغاء الحوار|cancel|stop)$/u.test(normalize(text)); }
function isConfirm(text) { return /^(?:تاكيد|اكد|نعم|موافق|نفذ|نفذها|نفذ الان|ارسل|تاكيد الارسال|تاكيد الحفظ|اكد المزامنه|تاكيد المزامنه|تاكيد التنزيل|ابدأ التنزيل|ابدا التنزيل|موافقه|تمام|ماشي|ايوه|بالضبط|صح|يلا|ok|confirm)$/u.test(normalize(text)); }
function isExactConfirmation(text, kind) {
  const p = normalize(text);
  const allowed = {
    download: ['تاكيد التنزيل', 'ابدا التنزيل'],
    sync: ['تاكيد المزامنه'],
  };
  return (allowed[kind] || []).includes(p);
}
function safeAuditText(value) {
  return String(value || '').replace(/(?:bearer\s+)[A-Za-z0-9._~+\/-]+/gi, 'Bearer [محجوب]')
    .replace(/(?:token|password|secret|auth|session|qr|pairingCode)\s*[:=]\s*[^\s,;]+/gi, '[قيمة حساسة محجوبة]')
    .replace(/https?:\/\/[^\s]+/gi, '[رابط محجوب]')
    .replace(/(?:[A-Za-z]:\\(?:[^\\\s]+\\)*[^\s,;]*)/g, '[مسار محلي]')
    .slice(0, 220);
}
function phoneDigits(person) { return String(person?.digits || person?.phone || person?.e164 || '').replace(/\D/g, ''); }
function ownTarget(session, target) {
  if (target?.type === 'group') return { key: `g:${target.id}`, chatId: String(target.gid || '').toLowerCase(), label: target.name || target.gid };
  const digits = phoneDigits(target);
  return { key: `r:${target.id}`, chatId: digits ? `${digits}@c.us` : String(target?.chatId || '').toLowerCase(), label: target?.name || target?.international || digits };
}
function countryCode(value) {
  const input = normalize(value).toUpperCase();
  const map = new Map([
    ['OM','OM'],['عمان','OM'],['سلطنة عمان','OM'],['oman','OM'],
    ['SA','SA'],['السعوديه','SA'],['السعودية','SA'],['saudi arabia','SA'],
    ['AE','AE'],['الامارات','AE'],['الإمارات','AE'],['uae','AE'],
    ['EG','EG'],['مصر','EG'],['egypt','EG'],['QA','QA'],['قطر','QA'],
    ['KW','KW'],['الكويت','KW'],['BH','BH'],['البحرين','BH'],
    ['JO','JO'],['الاردن','JO'],['الأردن','JO'],['IQ','IQ'],['العراق','IQ'],
    ['US','US'],['امريكا','US'],['الولايات المتحده','US'],['GB','GB'],['بريطانيا','GB'],
    ['IN','IN'],['الهند','IN'],['PK','PK'],['باكستان','PK'],
  ]);
  return map.get(input) || (/^[A-Z]{2}$/.test(input) ? input : '');
}

class OwnerAssistant {
  constructor({ store, whatsapp, phones, log, audioTranscriber = null, localLlm = null, delivery = null, speechSynthesizer = null, conversationArchive = null }) {
    this.store = store; this.whatsapp = whatsapp; this.phones = phones; this.log = log; this.audioTranscriber = audioTranscriber; this.localLlm = localLlm; this.delivery = delivery; this.speechSynthesizer = speechSynthesizer; this.conversationArchive = conversationArchive; this.lastReplies = new Map();
    this.contactSync = whatsappContacts;
    this.welcomeInFlight = new Set();
  }
  session(id) {
    const session = this.store.loadSession(id);
    session.ownerAssistant ||= { flow: null, welcomeSentAt: '', recent: [] };
    const rememberedReply = this.lastReplies.get(this.store.safeSessionId(id));
    if (rememberedReply) session.ownerAssistant.lastReply = rememberedReply;
    session.ownerAssistant.recent = Array.isArray(session.ownerAssistant.recent) ? session.ownerAssistant.recent.slice(-50) : [];
    return session;
  }
  save(session) {
    const sid = this.store.safeSessionId(session.id), rememberedReply = this.lastReplies.get(sid);
    if (rememberedReply) { session.ownerAssistant ||= { flow: null, recent: [] }; session.ownerAssistant.lastReply = rememberedReply; }
    return this.store.saveSession(session);
  }
  async reply(id, text, { remember = true, hint = true } = {}) {
    const chatId = this.whatsapp.selfChatId(id);
    if (!chatId) throw new Error('لم أستطع تأكيد معرّف محادثة النفس. تحقق من اتصال WhatsApp ثم أعد المحاولة.');
    const body = String(text || '').slice(0, hint ? 59000 : 60000).trim();
    if (!body) throw new Error('لن أرسل ردًا فارغًا.');
    const suffix = '\n\n_🔈 لتحويل آخر رد إلى صوت، اكتب: انطق آخر رد_';
    const payload = hint && !/انطق آخر رد|تحويل آخر رد إلى صوت/u.test(body) ? `${body}${suffix}` : body;
    const result = await this.whatsapp.sendText(id, chatId, payload);
    if (remember) {
      const item = { text: body, at: new Date().toISOString() };
      const sid = this.store.safeSessionId(id); this.lastReplies.set(sid, item);
      try { const fresh = this.store.loadSession(sid); fresh.ownerAssistant ||= { flow: null, recent: [] }; fresh.ownerAssistant.lastReply = item; this.store.saveSession(fresh); }
      catch (error) { this.log?.(sid, 'WARN', `تعذر حفظ آخر رد للنطق: ${String(error?.message || error).slice(0, 160)}`); }
    }
    return result;
  }
  async testSpeech(id, session) {
    if (!this.speechSynthesizer || typeof this.speechSynthesizer.generate !== 'function' || typeof this.whatsapp?.sendVoice !== 'function') {
      await this.reply(id, 'اختبار النطق غير متاح: محرك Piper أو موصل إرسال الرسائل الصوتية غير مربوط. اكتب «فحص النطق» للتشخيص.', { hint: false });
      return { handled: true, action: 'speech-preview-unavailable' };
    }
    let generated = null;
    try {
      const status = await this.speechSynthesizer.status();
      if (!status.ready || !status.ffmpegReady) throw new Error(`${status.message || 'محرك الصوت غير جاهز.'} تأكد من Piper والنموذج العربي وFFmpeg أولًا.`);
      const sample = 'مرحبًا بك. هذا اختبار للنطق باللغة العربية. سأقرأ الجمل بوضوح، مع مراعاة علامات الترقيم وسلامة الكلمات.';
      const settings = session.settings || {};
      const proofread = settings.ttsProofreadEnabled !== false;
      generated = await this.speechSynthesizer.generate(sample, { proofread, model: String(settings.smartReplyModel || 'qwen2.5:3b'), timeoutMs: Number(settings.smartReplyTimeoutMs) || 12000 });
      const proofreadRequired = settings.ttsRequireProofread === undefined
        ? !/^(?:0|false|no|off)$/i.test(String(process.env.TTS_REQUIRE_PROOFREAD || 'true'))
        : settings.ttsRequireProofread !== false;
      if (proofreadRequired && !generated.proofreadUsed) throw new Error('لم ينجح التدقيق اللغوي المحلي؛ لم أرسل عينة صوت غير مراجعة. شغّل Ollama وثبّت النموذج المحدد أو غيّر اشتراط التدقيق صراحةً.');
      const voiceFile = await this.speechSynthesizer.toWhatsAppVoice(generated.wavPath);
      const selfId = this.whatsapp.selfChatId(id);
      if (!selfId) throw new Error('معرّف محادثة النفس غير جاهز؛ لم يتم إرسال الصوت.');
      await this.whatsapp.sendVoice(id, selfId, voiceFile);
      const latest = this.session(id);
      latest.ownerAssistant.recent.push({ at: new Date().toISOString(), type: 'text-to-speech-preview', chars: generated.text.length, proofreadUsed: generated.proofreadUsed === true });
      this.save(latest);
      await this.reply(id, `أُرسلت عينة النطق إلى محادثة النفس فقط. التدقيق اللغوي المحلي: ${generated.proofreadUsed ? 'نجح' : 'غير مستخدم'}. للاستماع إلى رد عادي اكتب «انطق آخر رد».`, { remember: false, hint: false });
      return { handled: true, action: 'speech-preview-sent', proofreadUsed: generated.proofreadUsed === true };
    } catch (error) {
      await this.reply(id, `لم أرسل عينة الصوت: ${String(error?.message || error).slice(0, 600)}\nاكتب «فحص النطق» لمعرفة المكوّن الناقص.`, { remember: false, hint: false });
      return { handled: true, action: 'speech-preview-failed' };
    } finally { if (generated) this.speechSynthesizer.cleanup(generated); }
  }
  async speakLastReply(id, session) {
    const sid = this.store.safeSessionId(id);
    const last = this.lastReplies.get(sid) || session.ownerAssistant?.lastReply;
    if (!last?.text) { await this.reply(id, 'لا يوجد رد سابق محفوظ لتحويله إلى صوت. أرسل سؤالًا أو أمرًا أولًا، ثم اكتب «انطق آخر رد».', { remember: false, hint: false }); return { handled: true, action: 'speech-no-last-reply' }; }
    if (!this.speechSynthesizer) { await this.reply(id, 'محرك النطق المحلي غير موصول في هذا الإصدار. لم أرسل ملفًا صوتيًا.', { remember: false, hint: false }); return { handled: true, action: 'speech-unavailable' }; }
    let generated = null;
    try {
      const settings = session.settings || {};
      const proofread = settings.ttsProofreadEnabled !== false;
      generated = await this.speechSynthesizer.generate(last.text, { proofread, model: String(settings.smartReplyModel || 'qwen2.5:3b'), timeoutMs: Number(settings.smartReplyTimeoutMs) || 12000 });
      const proofreadRequired = settings.ttsRequireProofread === undefined
        ? !/^(?:0|false|no|off)$/i.test(String(process.env.TTS_REQUIRE_PROOFREAD || 'true'))
        : settings.ttsRequireProofread !== false;
      if (proofreadRequired && !generated.proofreadUsed) throw new Error('لم ينجح التدقيق اللغوي بنموذج عربي محلي؛ أوقفت إرسال الصوت حتى لا أنطق نصًا غير مراجع. فعّل نموذج التدقيق المحلي أو غيّر خيار اشتراط التدقيق صراحةً.');
      const voiceFile = await this.speechSynthesizer.toWhatsAppVoice(generated.wavPath);
      await this.whatsapp.sendVoice(id, this.whatsapp.selfChatId(id), voiceFile);
      await this.reply(id, `تم إرسال الرد الأخير كرسالة صوتية عربية محلية.${generated.proofreadUsed ? ' تمت مراجعته لغويًا باستخدام النموذج المحلي.' : ' لم يتوفر تدقيق لغوي بنموذج محلي؛ استُخدم النص الأصلي بعد تنقيته للقراءة.'}`, { remember: false, hint: false });
      const latest = this.session(id); latest.ownerAssistant.recent.push({ at: new Date().toISOString(), type: 'text-to-speech', chars: generated.text.length, proofreadUsed: generated.proofreadUsed === true }); this.save(latest);
      return { handled: true, action: 'speech-sent', proofreadUsed: generated.proofreadUsed === true };
    } catch (error) {
      await this.reply(id, `تعذر إرسال الرد صوتيًا: ${String(error?.message || error).slice(0, 500)}
لم أرسل صوتًا غير مكتمل. افحص حالة النطق من صفحة المحركات الذكية، أو أعد إعداد Piper وFFmpeg.`, { remember: false, hint: false });
      return { handled: true, action: 'speech-failed' };
    } finally { if (generated) this.speechSynthesizer.cleanup(generated); }
  }
  registeredChatTargets(session, selfChatId = '') {
    return conversationTargets.listRegisteredTargets(session, selfChatId).filter(target => target.key !== 'self').map(target => ({
      ...target, id: target.chatId, name: target.label, isGroup: target.type === 'group', registeredTargetKey: target.key,
    })).filter(target => target.id);
  }
  async maybeSendWelcome(id) {
    const sessionId = this.store.safeSessionId(id);
    if (this.welcomeInFlight.has(sessionId)) return false;
    this.welcomeInFlight.add(sessionId);
    try {
      const s = this.session(sessionId);
      if (s.ownerAssistant.welcomeSentAt) return false;
      if (!this.whatsapp.listRuntime(sessionId)?.ready || !this.whatsapp.selfChatId(sessionId)) return false;
      // Persist only after the local send accepted, so reconnects can retry a failed welcome.
      await this.reply(sessionId, WELCOME_GUIDE);
      const fresh = this.session(sessionId);
      if (fresh.ownerAssistant.welcomeSentAt) return false;
      fresh.ownerAssistant.welcomeSentAt = new Date().toISOString();
      fresh.ownerAssistant.recent.push({ at: fresh.ownerAssistant.welcomeSentAt, type: 'welcome-guide-sent' });
      this.save(fresh);
      return true;
    } finally {
      this.welcomeInFlight.delete(sessionId);
    }
  }
  async handleSelfChatMessage(id, msg) {
    const text = String(msg?.body || msg?._data?.body || '').trim();
    if (!text || text.length > 60000) return { handled: false, fallback: true };
    const s = this.session(id), assistant = s.ownerAssistant;
    const normalizedText = normalize(text);
    if (/^(?:انطق اخر رد|انطق اخر اجابه|حول اخر رد لصوت|حول اخر رد الى صوت|اقرا اخر رد بصوت|ارسل اخر رد صوتي)$/u.test(normalizedText)) return this.speakLastReply(id, s);
    if (/^(?:فحص النطق|افحص النطق|حاله النطق|حالة النطق|تشخيص الصوت|افحص الصوت)$/u.test(normalizedText)) {
      const speechStatus = this.speechSynthesizer?.status ? await this.speechSynthesizer.status().catch(error => ({ ready: false, ffmpegReady: false, message: String(error?.message || error) })) : { ready: false, ffmpegReady: false, message: 'محرك النطق غير مربوط في البرنامج.' };
      const proofreadRequired = s.settings?.ttsRequireProofread !== false;
      const proofreadEnabled = s.settings?.ttsProofreadEnabled !== false;
      let llmStatus = { available: false, models: [], message: 'خدمة التدقيق المحلي غير مربوطة.' };
      if (proofreadRequired && proofreadEnabled && this.localLlm?.status) llmStatus = await this.localLlm.status().catch(error => ({ available: false, models: [], message: String(error?.message || error) }));
      const model = String(s.settings?.smartReplyModel || 'qwen2.5:3b');
      const modelReady = Array.isArray(llmStatus.models) && llmStatus.models.some(name => name === model || name.startsWith(`${model}-`) || name.startsWith(`${model}:`));
      const lines = [
        `محرك النطق المحلي: ${speechStatus.ready ? 'جاهز' : 'غير جاهز'}.`,
        `نموذج العربية: ${speechStatus.modelReady ? 'موجود' : 'غير موجود'}. محرك Piper: ${speechStatus.binaryReady ? 'موجود' : 'غير موجود'}. FFmpeg: ${speechStatus.ffmpegReady ? 'موجود' : 'غير موجود'}.`,
        `التدقيق اللغوي قبل الإرسال: ${proofreadRequired ? 'إلزامي' : 'غير إلزامي'}؛ الإعداد: ${proofreadEnabled ? 'مفعّل' : 'متوقف'}.`,
        proofreadRequired && proofreadEnabled ? `Ollama المحلي: ${llmStatus.available ? 'متصل' : 'غير متصل'}؛ النموذج ${model}: ${modelReady ? 'موجود' : 'غير مؤكد/غير مثبت'}.` : 'التدقيق المحلي ليس مطلوبًا بالإعداد الحالي، لكن جودة النص الأصلي لا تكون مضمونة لغويًا.',
        `التفاصيل: ${speechStatus.message || '—'}`,
        'هذا فحص جاهزية فقط ولم يرسل أي صوت. اكتب «اختبر النطق» لإرسال عينة صوتية عربية إلى محادثة النفس فقط.'
      ];
      await this.reply(id, lines.join('\n'), { hint: false });
      return { handled: true, action: 'speech-status', ready: speechStatus.ready === true, ffmpegReady: speechStatus.ffmpegReady === true, proofreadRequired };
    }
    if (/^(?:اختبر النطق|جرب النطق|اختبر صوت البوت|ارسل عينه صوتيه|أرسل عينة صوتية)$/u.test(normalizedText)) return this.testSpeech(id, s);
    const diagnostic = ruleDiagnostics.parseDiagnosticCommand(text);
    if (diagnostic.recognized) {
      if (!diagnostic.sample) {
        await this.reply(id, 'اكتب النص الذي تريد تشخيص قواعده. مثال: «شخّص الرد التلقائي على: السلام عليكم» أو «ليه البوت مش بيرد على: صباح الخير». التشخيص للقراءة فقط ولا يرسل رسائل.', { hint: false });
        return { handled: true, action: 'rule-diagnostic-needs-text' };
      }
      const report = ruleDiagnostics.diagnose(s, diagnostic.sample);
      await this.reply(id, report.text, { hint: false });
      return { handled: true, action: 'rule-diagnostic', matched: report.matchedCount, sampleLength: report.sample.length };
    }
    const transcriptRequest = /(?:فرغ|افرغ|تفريغ|حول|اكتب|انسخ|transcrib).*(?:صوت|تسجيل|audio)/u.test(normalizedText)
      || /(?:صوت|تسجيل|audio).*(?:نص|كتابه|تفريغ|transcrib)/u.test(normalizedText);
    if (transcriptRequest) {
      if (!this.audioTranscriber) {
        await this.reply(id, 'ميزة التفريغ الصوتي غير مهيأة داخل هذا الإصدار. راجع إعدادات Whisper المحلي في .env ثم أعد تشغيل البرنامج.');
        return { handled: true, action: 'transcription-not-configured' };
      }
      try {
        const language = /(?:انجليزي|الانجليزيه|english)/u.test(normalizedText) ? 'en' : 'ar';
        const result = await this.audioTranscriber.transcribeLatest(id, { language });
        const chunks = String(result.transcript || '').match(/[\s\S]{1,9000}/g) || [];
        await this.reply(id, `تم تفريغ الصوتية محليًا (${language === 'ar' ? 'العربية' : 'الإنجليزية'}):\n\n${chunks[0] || 'لم يُستخرج نص.'}${chunks.length > 1 ? '\n\n(تم عرض الجزء الأول فقط؛ يمكنك تفريغ الملف من لوحة المحركات الذكية لنسخ النص كاملًا.)' : ''}`);
        assistant.recent.push({ at: new Date().toISOString(), type: 'audio-transcription', language, chars: String(result.transcript || '').length });
        this.save(s);
        return { handled: true, action: 'transcription-complete', chars: String(result.transcript || '').length };
      } catch (error) {
        await this.reply(id, `لم أستطع تفريغ الصوتية: ${String(error?.message || error).slice(0, 1000)}\nأرسل الصوتية إلى محادثة النفس أولًا، أو استخدم صفحة «المحركات الذكية» لرفع ملف صوتي من جهازك.`);
        return { handled: true, action: 'transcription-failed' };
      }
    }
    if (/^(?:مساعده القواعد|طريقة كتابة القواعد|طريقه كتابه القواعد|help rules)$/iu.test(normalizedText)) {
      await this.reply(id, chatRuleLanguage.helpText()); return { handled: true, action: 'rule-language-help' };
    }
    const ruleCommand = chatRuleLanguage.parseRuleCommand(text);
    if (ruleCommand.recognized) return this.beginChatRuleDraft(id, s, ruleCommand.values, ruleCommand.invalid, ruleCommand.source);
    if (isCancel(text)) {
      if (!assistant.flow) return { handled: false, fallback: true };
      assistant.flow = null; this.save(s); await this.reply(id, 'تم إلغاء الحوار. لم يُرسل شيء ولم تُحفظ تغييرات هذا الحوار.'); return { handled: true };
    }
    if (assistant.flow) {
      const handled = await this.stepFlow(id, s, text);
      if (handled) return { handled: true };
    }
    const recall = await this.handleConversationRecall(id, s, text);
    if (recall) return recall;
    const p = normalize(text);
    if (/^(?:مساعده|ساعدني|الاوامر|الاوامر المتاحه|help|دليل الاستخدام|ارسل الدليل)$/u.test(p) || /^(?:دليل الاستخدام|مساعدة البوت)$/u.test(p)) {
      await this.reply(id, WELCOME_GUIDE); return { handled: true };
    }
    if (/^(?:الحاله|حاله النظام|حاله الاتصال|status|هل انت متصل)$/u.test(p)) {
      const current = this.session(id), runtime = this.whatsapp.listRuntime(id);
      const status = runtime.ready ? 'متصل' : runtime.status === 'qr' ? 'بانتظار مسح QR' : (runtime.status || 'غير متصل');
      await this.reply(id, `حالة الجلسة «${current.name}»: ${status}.\nالأشخاص: ${current.recipients.length}، المجموعات: ${current.groups.length}.\nقواعد التفاعل: ${(current.interaction.rules || []).filter(x => x.enabled !== false).length} مفعّلة.\nالمواعيد: ${(current.automation.tasks || []).filter(x => x.enabled !== false).length} مفعّلة.\nالأتمتة: ${current.settings.automationEnabled === false ? 'متوقفة' : 'مفعّلة'}.`);
      return { handled: true };
    }
    if (/(?:قائمه|اعرض|اسماء|عدد|كم).*(?:الاشخاص|المستلمين|جهات الارسال)|^(?:الاشخاص|المستلمين|قائمة الاشخاص)$/u.test(p)) {
      const list = s.recipients.slice(0, 50).map((x, i) => `${i + 1}. ${x.name || 'بدون اسم'} — ${x.international || x.e164 || x.phone || ''}${x.enabled === false ? ' (متوقف)' : ''}`);
      await this.reply(id, `الأشخاص المحفوظون: ${s.recipients.length}.${list.length ? `\n${list.join('\n')}` : '\nلا توجد جهات محفوظة.'}${s.recipients.length > list.length ? `\n... وهناك ${s.recipients.length - list.length} جهة إضافية.` : ''}`);
      return { handled: true };
    }
    if (/(?:قائمه|اعرض|عدد|كم).*(?:المجموعات)|^(?:المجموعات|قائمة المجموعات)$/u.test(p)) {
      const list = s.groups.slice(0, 50).map((x, i) => `${i + 1}. ${x.name || 'مجموعة'} — ${x.gid}`);
      await this.reply(id, `المجموعات المحفوظة: ${s.groups.length}.${list.length ? `\n${list.join('\n')}` : '\nلا توجد مجموعات محفوظة.'}`); return { handled: true };
    }
    if (/(?:سجل النشاط|اخر العمليات|اخر الاخطاء|السجل)$/u.test(p)) {
      const list = (s.logs || []).slice(-12).reverse().map(x => `• ${x.at || x.time || ''} ${x.level || ''} ${x.message || x.text || ''}`.trim());
      await this.reply(id, list.length ? `آخر النشاطات:\n${list.join('\n')}` : 'لا توجد نشاطات مسجلة بعد.'); return { handled: true };
    }
    if (/(?:اضافه|اضيف|ضيف|اضف|سجل).*(?:شخص|مستخدم|رقم|جهة)|(?:شخص|مستخدم|رقم جديد|جهة اتصال جديدة)/u.test(p)) {
      assistant.flow = { type: 'add-recipient', step: 'name', data: {} }; this.save(s);
      await this.reply(id, 'حوار إضافة شخص (1/3)\nما اسم الشخص الذي تريد إضافته؟'); return { handled: true };
    }
    if (/(?:استدعاء|مزامنه|مزامنة|سحب).*(?:جهات|اشخاص|اسماء).*(?:واتساب|whatsapp)|^(?:استدعاء جهات واتساب|مزامنة واتساب|مزامنه واتساب)$/u.test(p)) {
      const contacts = await this.whatsapp.listContacts(id, { limit: 1000 });
      if (!contacts.length) { await this.reply(id, 'لم أعثر على جهات رقمية قابلة للاستدعاء في الجلسة المتصلة. تأكد من اكتمال مزامنة WhatsApp ومنح الجلسة وقتًا لتحميل جهات الاتصال.'); return { handled: true }; }
      assistant.flow = { type: 'sync-confirm', step: 'confirm', data: { jids: contacts.slice(0, 100).map(x => x.jid), totalAvailable: contacts.length } }; this.save(s);
      const preview = contacts.slice(0, 12).map((x, i) => `${i + 1}. ${x.name} — +${x.digits}`).join('\n');
      await this.reply(id, `وجدت ${contacts.length} جهة رقمية في WhatsApp. لأمانك، ستُضاف بحد أقصى 100 جهة جديدة في هذا الأمر؛ لن أستبدل أسماءك المخصصة ولن أنفّذ إرسالًا.\n${preview}${contacts.length > 12 ? '\n…' : ''}\n\nاكتب «تأكيد المزامنة» للمتابعة أو «إلغاء» للإلغاء. للمزامنة الانتقائية والصور استخدم صفحة الأشخاص في لوحة التحكم.`);
      return { handled: true };
    }
    if (/^(?:قائمه المحادثات|قائمة المحادثات|اعرض المحادثات|المحادثات)$/u.test(p)) {
      const chats = this.registeredChatTargets(s, this.whatsapp.selfChatId(id));
      const list = chats.slice(0, 50).map((chat, i) => `${i + 1}. ${chat.name}${chat.isGroup ? ' (مجموعة)' : ''} — ${chat.id}`).join('\n');
      await this.reply(id, `المحادثات المسجلة في المشروع: ${chats.length}. لا أعرض محادثات غير مسجلة ولا أستورد رسائلها.\n${list || 'لا توجد جهات/مجموعات مسجلة ذات معرّف قابل للاستخدام. أضف الشخص أولًا من «الأشخاص».'}\nلفتح السجل كاملًا استخدم صفحة «سجل المحادثات» في لوحة التحكم. لتنزيل المرفقات: «استخرج الملفات من محادثة الاسم» ثم «تأكيد التنزيل».`);
      return { handled: true, action: 'list-chats-registered-only' };
    }
    const mediaCommand = p.match(/^(?:استخرج|استخراج|نزل|حمل|اسحب|احفظ)\s+(?:كل\s+)?(?<kind>الملفات الصوتيه|الرسائل الصوتيه|التسجيلات الصوتيه|الصوتيات|الصوت|المستندات|الصور|الفيديوهات|الفيديو|الستيكرات|الملفات|المرفقات|الوسائط)(?:\s+(?:من|في)\s+(?:محادثه|شات|دردشه)\s*(?<target>.*))?$/u);
    if (mediaCommand) {
      const kind = String(mediaCommand.groups?.kind || 'الملفات').trim();
      const mediaType = /(?:الصوت|الصوتيه|الصوتيات|التسجيلات)/u.test(kind) ? 'audio'
        : /مستند/u.test(kind) ? 'document'
        : /صور/u.test(kind) ? 'image'
        : /فيديو/u.test(kind) ? 'video'
        : /ستيكر/u.test(kind) ? 'sticker' : 'all';
      const mediaLabel = ({ all: 'كل أنواع المرفقات', audio: 'الصوتيات والرسائل الصوتية', image: 'الصور', video: 'الفيديوهات', document: 'المستندات والملفات', sticker: 'الملصقات' })[mediaType];
      const query = String(mediaCommand.groups?.target || '').trim();
      const allTargets = this.registeredChatTargets(s, this.whatsapp.selfChatId(id));
      const candidates = allTargets.filter(chat => !query || normalize(`${chat.name} ${chat.id}`).includes(normalize(query)));
      if (!candidates.length) { await this.reply(id, query ? `لم أجد جهة مسجلة تطابق «${query}». لأمان المحادثات لا أبحث في دردشات غير مضافة إلى المشروع. أضف الشخص/المجموعة أولًا من لوحة التحكم ثم أعد الأمر.` : 'لا توجد محادثات مرتبطة بأشخاص أو مجموعات مسجلة. أضف الجهات المطلوبة أولًا ثم أعد الأمر.'); return { handled: true }; }
      assistant.flow = { type: 'download-chat-media', step: candidates.length === 1 && query ? 'confirm' : 'choose', data: { candidates, target: candidates.length === 1 && query ? candidates[0] : null, mediaType, mediaLabel } }; this.save(s);
      if (assistant.flow.step === 'confirm') await this.reply(id, `وجدت المحادثة «${candidates[0].name}».\nالمطلوب: ${mediaLabel}. سأفحص آخر 500 رسالة وأحفظ حتى 100 ملف بحد إجمالي 500 MB، من دون إرسال أو حذف أي شيء.\nاكتب «تأكيد التنزيل» حرفيًا للمتابعة أو «إلغاء».`);
      else await this.reply(id, `اختر المحادثة المراد استخراج ${mediaLabel} منها بإرسال رقمها:\n${candidates.map((chat, i) => `${i + 1}. ${chat.name}${chat.isGroup ? ' (مجموعة)' : ''}`).join('\n')}\nأو اكتب «قائمة المحادثات» لعرض القائمة الموسّعة. لن يبدأ التنزيل إلا بعد تأكيدك.`);
      return { handled: true };
    }
    if (/(?:ارسل|ابعث|ابعت|ارسال|ابعاث).*(?:رساله|رسالة)|^(?:ارسل رسالة|ابعت رسالة|ارسال رساله)$/u.test(p)) {
      assistant.flow = { type: 'send-message', step: 'target', data: {} }; this.save(s);
      await this.reply(id, 'حوار إرسال رسالة (1/3)\nاكتب اسم الشخص أو المجموعة المحفوظة، أو رقمًا دوليًا مثل ‎+968…‎.'); return { handled: true };
    }
    if (/(?:انشئ|انشاء|اعمل|سوي|سجل|اضف).*(?:موعد|جدول|رساله مجدوله)|^(?:موعد جديد|إنشاء موعد)$/u.test(p)) {
      assistant.flow = { type: 'schedule', step: 'target', data: {} }; this.save(s);
      await this.reply(id, 'حوار إنشاء موعد (1/5)\nلمن تريد إرسال الرسالة؟ اكتب اسم شخص/مجموعة محفوظة أو رقمًا دوليًا.'); return { handled: true };
    }
    if (/(?:انشئ|انشاء|اعمل|سوي|سجل|اضف|اضافه).*(?:رد تلقائي|قاعده رد|قاعدة رد|تفاعل تلقائي)|^(?:رد تلقائي جديد|قاعدة رد جديدة)$/u.test(p)) {
      assistant.flow = { type: 'auto-reply', step: 'trigger', data: {} }; this.save(s);
      await this.reply(id, 'حوار إنشاء رد تلقائي (1/3)\nاكتب عبارة أو كلمة الرسالة التي ستفعّل الرد (حرفان على الأقل).\nإذا أردت التحكم في نوع المطابقة والنطاق والتهدئة، استخدم القالب المفصل «قاعدة تفاعل» أو اكتب «مساعدة القواعد».');
      return { handled: true, action: 'auto-reply-wizard-started' };
    }
    if (/^(?:السلام عليكم|مرحبا|مرحباً|اهلا|اهلا وسهلا|صباح الخير|مساء الخير|hi|hello)$/u.test(p)) {
      await this.reply(id, 'وعليكم السلام وأهلًا بك! اكتب «مساعدة» لعرض الأوامر، أو ابدأ بعبارة «عايز أضيف شخص جديد» أو «أرسل رسالة».'); return { handled: true };
    }
    const understood = classifyCommand(text);
    if (understood.intent && understood.confidence >= .66) {
      return this.handleInterpretedCommand(id, s, text, understood);
    }
    const suggestion = understood.alternatives?.[0];
    if (suggestion && suggestion.confidence >= .58 && /(?:عايز|عاوز|اريد|أريد|اعمل(?:لي)?|شغل|فعل|ضيف|اضف|ابعت|ابعث|ارسل|حول|استخرج|مزامن|نزل|حمل|خلي|خله|سوي)/u.test(p)) {
      const label = this.intentLabel(suggestion.intent);
      assistant.flow = { type: 'clarify-command', step: 'confirm', data: { intent: suggestion.intent, label, originalText: text.slice(0, 2000), confidence: suggestion.confidence } };
      this.save(s);
      await this.reply(id, `لم أتأكد من قصدك بالكامل، لكن أظن أنك تقصد: «${label}».
هل هذا صحيح؟ اكتب «نعم» لأبدأ الخطوات المناسبة، أو «لا» لإلغاء الاقتراح. لم أنفّذ أي إجراء بعد.`);
      return { handled: true, action: 'clarify-command', confidence: suggestion.confidence };
    }
    return this.conversationalFallback(id, s, text);
  }
  async beginChatRuleDraft(id, session, inputValues = {}, invalid = [], source = '') {
    const values = { name: '', trigger: '', reply: '', scope: 'all', match: 'contains', cooldownSec: 45, ...(inputValues || {}) };
    if (invalid?.length) {
      const labels = { scope: 'النطاق: الكل أو الخاص أو المجموعات', match: 'المطابقة: يحتوي، يساوي، يبدأ، ينتهي، تشابه، نية، regex أو أي رسالة', cooldownSec: 'التهدئة: عدد صحيح من 0 إلى 86400 ثانية', threshold: 'عتبة التشابه: رقم من 0.30 إلى 0.98', regex: 'تعبير منتظم غير صالح أو قد يسبب بطئًا؛ بسّطه' };
      const issues = invalid.map(key => key.startsWith('field:') ? `اسم الحقل «${key.slice(6)}» غير معروف` : (labels[key] || key));
      await this.reply(id, `وجدت قيمة غير صالحة في القاعدة: ${issues.join('؛ ')}.\nلم أحفظ شيئًا. صحّح القيمة ثم أرسل قالب «قاعدة تفاعل» مرة أخرى، أو اكتب «مساعدة القواعد».`);
      return { handled: true, action: 'rule-draft-invalid' };
    }
    const flow = { type: 'chat-rule', step: '', data: { ...values, source: String(source || '').slice(0, 4000) } };
    if (!String(values.trigger || '').trim()) flow.step = 'trigger';
    else if (!String(values.reply || '').trim()) flow.step = 'reply';
    else flow.step = 'confirm';
    session.ownerAssistant ||= { flow: null, recent: [] };
    session.ownerAssistant.flow = flow;
    this.save(session);
    if (flow.step === 'trigger') {
      await this.reply(id, `فهمت أنك تريد إنشاء قاعدة تفاعل جديدة. لن أضيفها الآن.\nأرسل قيمة «عندما» فقط: ما العبارة التي يبحث عنها البوت في الرسالة؟\nمثال: السلام عليكم\nاكتب «إلغاء» للتراجع.`);
    } else if (flow.step === 'reply') {
      await this.reply(id, `فهمت الشرط: الرسالة تحتوي على «${values.trigger}». لم أحفظ القاعدة.\nاكتب الرد الذي تريد إرساله، مثل: وعليكم السلام يا {{sender}}.\nاكتب «إلغاء» للتراجع.`);
    } else {
      await this.reply(id, chatRuleLanguage.formatRulePreview(values));
    }
    return { handled: true, action: 'chat-rule-draft', step: flow.step };
  }
  intentLabel(intent) {
    return ({
      help: 'عرض المساعدة والأوامر', status: 'عرض حالة الاتصال والنظام', 'settings-status': 'عرض الإعدادات وحالة المحركات',
      capabilities: 'شرح ما يستطيع البوت فعله', 'list-activity': 'عرض آخر عمليات النظام', 'list-stats': 'عرض الإحصائيات', 'list-active-rules': 'عرض قواعد الرد المفعّلة', 'list-counters': 'عرض عدادات الرسائل', 'test-reply': 'محاكاة قواعد الرد على نص تجريبي دون إرسال', 'clear-chat-memory': 'مسح ذاكرة المحادثة المحلية بعد التأكيد',
      'list-people': 'عرض قائمة الأشخاص', 'list-groups': 'عرض قائمة المجموعات', 'list-tasks': 'عرض المواعيد', 'list-rules': 'عرض قواعد الرد التلقائي', 'list-media': 'عرض الملفات والوسائط', 'list-chats': 'عرض محادثات WhatsApp',
      'add-person': 'إضافة شخص جديد', 'send-message': 'إرسال رسالة (مع مراجعة المستلم والنص)', 'create-schedule': 'إنشاء موعد', 'create-rule': 'إنشاء قاعدة رد تلقائي', 'sync-contacts': 'استدعاء جهات WhatsApp ومزامنتها', 'download-media': 'استخراج المرفقات من محادثة', 'transcribe-latest': 'تفريغ آخر صوتية إلى نص',
      'interaction-on': 'تشغيل التفاعل والرد التلقائي', 'interaction-off': 'إيقاف التفاعل والرد التلقائي', 'group-assistant-on': 'تشغيل أوامر تحليل المجموعات', 'group-assistant-off': 'إيقاف أوامر تحليل المجموعات', 'quiet-on': 'تفعيل عدم الإزعاج', 'quiet-off': 'إيقاف عدم الإزعاج', 'smart-reply-on': 'تفعيل الذكاء المحلي', 'smart-reply-off': 'إيقاف الذكاء المحلي', 'voice-on': 'تفعيل تفريغ الصوتيات', 'voice-off': 'إيقاف تفريغ الصوتيات', 'fallback-on': 'تفعيل الرد الاحتياطي', 'fallback-off': 'إيقاف الرد الاحتياطي', 'group-fallback-on': 'تفعيل الرد الاحتياطي داخل المجموعات', 'group-fallback-off': 'إيقاف الرد الاحتياطي داخل المجموعات'
    })[intent] || 'تنفيذ الأمر المطلوب';
  }
  async conversationalFallback(id, session, text) {
    const settings = session.settings || {};
    const assistant = session.ownerAssistant || (session.ownerAssistant = { flow: null, recent: [] });
    const history = Array.isArray(assistant.conversation) ? assistant.conversation.slice(-8) : [];
    if (settings.smartReplyEnabled === true && this.localLlm) {
      try {
        const status = await this.localLlm.status();
        const model = String(settings.smartReplyModel || 'qwen2.5:3b');
        const modelReady = status.available && (status.models || []).some(name => name === model || String(name).split(':')[0] === model.split(':')[0]);
        if (!status.available || !modelReady) {
          await this.reply(id, `الرد الذكي مفعّل في الإعدادات لكنه غير جاهز الآن: ${!status.available ? status.message : `النموذج «${model}» غير مثبت.`}
لن أخمّن تنفيذ أمر. استخدم «حالة الإعدادات» للتشخيص، أو اكتب «مساعدة».`);
          return { handled: true, action: 'local-model-unavailable' };
        }
        const response = await this.localLlm.generate({
          model, system: `أنت مساعد مالك محلي داخل محادثة WhatsApp مع نفسه. أجب بالعربية الواضحة وباختصار، واستوضح أي نقص. تستطيع شرح طريقة استعمال النظام لكن لا تدّع تنفيذ إرسال أو تغيير أو حذف. لا تنفذ الأوامر عبر النص؛ العمليات تتطلب مسار الأمر الرسمي والتأكيد. إذا طلب المستخدم مهمة تشغيلية، اطلب البيانات الناقصة وقدّمه إلى أحد أوامر المساعدة. تعليمات المالك: ${String(settings.smartReplySystemPrompt || '').slice(0, 2500)}`,
          messages: [...history, { role: 'user', content: text.slice(0, 1200) }], timeoutMs: settings.smartReplyTimeoutMs || 12000, maxTokens: 240,
        });
        await this.reply(id, response);
        assistant.conversation = [...history, { role: 'user', content: text.slice(0, 1200) }, { role: 'assistant', content: response.slice(0, 2000) }].slice(-10);
        assistant.recent.push({ at: new Date().toISOString(), type: 'local-chat', source: 'ollama-local' });
        this.save(session);
        return { handled: true, action: 'local-conversation', source: 'ollama-local' };
      } catch (error) {
        this.log?.(id, 'WARN', `تعذر الرد المحلي داخل محادثة النفس: ${String(error?.message || error).slice(0, 180)}`);
        await this.reply(id, `لم أستطع الوصول إلى نموذج الذكاء المحلي. لم أنفّذ أي إجراء. تحقق من Ollama والنموذج من «حالة الإعدادات»، أو اكتب «مساعدة» لاستخدام الأوامر المحلية.`);
        return { handled: true, action: 'local-conversation-unavailable' };
      }
    }
    const understood = classifyCommand(text);
    const likelyAction = /(?:ارسل|ابعت|ابعث|احذف|حذف|ضيف|اضف|شغل|فعل|اوقف|عطل|مزامن|استدع|استخرج|نزل|حول|فرغ|موعد|تذكير|رد تلقائي)/u.test(normalize(text));
    const reply = likelyAction
      ? `أريد التأكد من المطلوب قبل تنفيذ أي شيء. لم أفهم الأمر بشكل كافٍ لأتصرف بأمان.
اكتب «مساعدة» لعرض الأمثلة، أو جرّب صيغة مثل:
• أرسل رسالة (وسأطلب المستلم والنص ثم التأكيد)
• أضف شخص جديد
• أنشئ موعد
• أنشئ رد تلقائي
• اعرض الأشخاص / اعرض المواعيد
• حالة الإعدادات
لم يتم إرسال رسالة أو تغيير إعدادات.`
      : `وصلتني رسالتك، لكن لا أريد أن أخمّن قصدك. ${understood.alternatives?.[0] ? `هل كنت تقصد «${this.intentLabel(understood.alternatives[0].intent)}»؟` : 'هل يمكنك توضيح ما الذي تريد مني فعله؟'}
اكتب «مساعدة» للأوامر المتاحة. لم يتم تنفيذ أي إجراء.`;
    await this.reply(id, reply);
    return { handled: true, action: 'clarification-required' };
  }
  async handleInterpretedCommand(id, session, rawText, understood) {
    const intent = understood.intent;
    const canonical = {
      help: 'مساعدة', status: 'الحالة', 'list-people': 'اعرض الأشخاص', 'list-groups': 'اعرض المجموعات',
      'list-tasks': 'اعرض المواعيد', 'list-rules': 'اعرض قواعد التفاعل', 'list-media': 'اعرض الوسائط', 'list-chats': 'قائمة المحادثات',
      'settings-status': null, 'sync-contacts': 'استدعاء جهات واتساب', 'download-media': 'استخرج الملفات من محادثة', 'transcribe-latest': 'فرغ آخر صوتية',
      'add-person': 'عايز أضيف شخص جديد', 'create-schedule': 'أنشئ موعد', 'create-rule': 'أنشئ رد تلقائي'
    };
    if (intent === 'capabilities') {
      await this.reply(id, `أقدر أساعدك في إدارة المشروع من محادثة النفس، مع تأكيد قبل الإرسال أو الحذف:

1. جهات الاتصال: أضف شخصًا، استدعِ جهات WhatsApp، اعرض الأشخاص.
2. الرسائل والوسائط: أرسل رسالة، أرفق ملفًا، اعرض الوسائط، ونزّل مرفقات محادثة بعد التأكيد.
3. قواعد التفاعل: أنشئ ردودًا تلقائية بنص مطابق أو مطابقة تقريبية أو نية أو تعبير منتظم آمن، وحدد النطاق ووقت التشغيل والتهدئة والردود البديلة.
4. المواعيد: أنشئ موعدًا مرة واحدة أو متكررًا، واعرضه أو عدّله أو أوقفه.
5. الصوتيات: اكتب «فرّغ آخر صوتية» لتفريغها محليًا، إذا كان Whisper والنموذج مجهزين.
6. الإعدادات: شغّل أو أوقف التفاعل وعدم الإزعاج والرد الاحتياطي والذكاء المحلي والصوتيات، ثم اكتب «حالة الإعدادات».
7. الفحص: «سجل النشاط»، «ملخص النظام»، «القواعد المفعّلة»، «اختبر الرد التلقائي على: السلام عليكم».

أستخدم قواعد محلية افتراضيًا. إذا لم أفهم الأمر فسأسألك بدل التخمين، ومحاكاة القواعد لا ترسل رسالة لأي شخص.`);
      return { handled: true, action: 'capabilities' };
    }
    if (intent === 'list-activity') {
      const entries = [...(Array.isArray(session.logs) ? session.logs : []), ...(Array.isArray(session.ownerAssistant?.recent) ? session.ownerAssistant.recent : [])].slice(-20).reverse();
      const lines = entries.map((entry, i) => {
        const at = entry.at || entry.time || entry.timestamp || '';
        const level = entry.level || entry.type || 'INFO';
        const message = safeAuditText(entry.message || entry.action || entry.ruleName || entry.source || JSON.stringify(entry));
        return `${i + 1}. ${at ? `${at} — ` : ''}${String(level).toUpperCase()}: ${message}`;
      });
      await this.reply(id, `آخر النشاطات المحلية (${lines.length}):\n${lines.join('\n') || 'لا توجد أحداث محفوظة بعد.'}\n\nهذا سجل محلي مختصر؛ قد لا يحتوي كل أحداث مكتبة WhatsApp.`);
      return { handled: true, action: 'list-activity', count: lines.length };
    }
    if (intent === 'list-stats') {
      const stats = session.stats || {}, runtime = this.whatsapp.listRuntime(id) || {};
      const rules = session.interaction?.rules || [], tasks = session.automation?.tasks || [];
      const lines = [
        `حالة WhatsApp: ${runtime.ready ? 'متصل' : runtime.status || 'غير متصل'}`,
        `الأشخاص: ${(session.recipients || []).length} (${(session.recipients || []).filter(x => x.enabled !== false).length} مفعّل)`,
        `المجموعات: ${(session.groups || []).length} (${(session.groups || []).filter(x => x.enabled !== false).length} مفعّل)`,
        `قواعد التفاعل: ${rules.length} (${rules.filter(x => x.enabled !== false).length} مفعّل)`,
        `المواعيد: ${tasks.length} (${tasks.filter(x => x.enabled !== false).length} مفعّل)`,
        `رسائل مؤكدة: ${Number(stats.sentMessages) || 0}؛ صور: ${Number(stats.sentImages) || 0}؛ ملفات: ${Number(stats.sentFiles) || 0}`,
        `إخفاقات الإرسال: ${Number(stats.failedSends) || 0}؛ أخطاء التفاعل: ${Number(stats.interactionErrors) || 0}`,
        `الرد التلقائي: ${session.settings?.interactionEnabled !== false && session.interaction?.enabled !== false ? 'مفعّل' : 'متوقف'}؛ الأتمتة: ${session.settings?.automationEnabled === false ? 'متوقفة' : 'مفعّلة'}`,
      ];
      await this.reply(id, `ملخص النظام:\n${lines.join('\n')}\n\nالأرقام تخص الإحصاءات المخزنة محليًا وقد لا تثبت قراءة الرسائل من المستلم.`);
      return { handled: true, action: 'list-stats' };
    }
    if (intent === 'list-active-rules') {
      const rules = (session.interaction?.rules || []).filter(rule => rule.enabled !== false);
      await this.reply(id, `القواعد المفعّلة: ${rules.length}\n${rules.slice(0, 40).map((rule, i) => `${i + 1}. ${rule.name || 'قاعدة'} — ${rule.when?.type || 'message'}/${rule.when?.match || 'contains'} «${rule.when?.value || ''}» — النطاق ${rule.scope || 'all'} — تهدئة ${Number(rule.cooldownSec) || 0}ث`).join('\n') || 'لا توجد قواعد مفعّلة.'}\n\nاكتب «اعرض قواعد التفاعل» لرؤية المفعّلة والمتوقفة.`);
      return { handled: true, action: 'list-active-rules', count: rules.length };
    }
    if (intent === 'list-counters') {
      const triggers = session.interaction?.counterTriggers || [];
      await this.reply(id, `عدادات التفاعل: ${triggers.length}\n${triggers.slice(0, 40).map((trigger, i) => `${i + 1}. ${trigger.name || trigger.id} — ${trigger.enabled === false ? 'متوقف' : 'مفعّل'} — عند ${trigger.threshold || trigger.when?.threshold || 1} — ${trigger.actionType || 'reply'}`).join('\n') || 'لا توجد عدادات محفوظة.'}`);
      return { handled: true, action: 'list-counters', count: triggers.length };
    }
    if (intent === 'test-reply') {
      const sample = String(rawText || '').replace(/^(?:من فضلك\s*)?(?:اختبر|جرب|حاكي)\s+(?:الرد التلقائي|قواعد الرد|قاعدة الرد|نص الرسالة|رسالة تجريبية)?\s*(?:على|للنص|بالنص)?\s*[:：-]?\s*/u, '').trim();
      if (!sample || /^(?:اختبر الرد التلقائي|جرب قواعد الرد|حاكي الرد على رسالة)$/u.test(normalize(sample))) {
        await this.reply(id, 'اكتب نصًا لاختباره دون إرسال، مثال: «اختبر الرد التلقائي على: السلام عليكم». سأعرض القواعد المطابقة فقط.');
        return { handled: true, action: 'test-reply-needs-text' };
      }
      const rules = (session.interaction?.rules || []).filter(rule => rule.enabled !== false && interactionTools.ruleActiveNow(rule, session.settings || {}));
      const options = { smartContains: session.settings?.interactionSmartMatching !== false, smartThreshold: Number(session.settings?.interactionSmartThreshold) || .82 };
      const matched = rules.map(rule => ({ rule, result: triggerEngine.matchTrigger(rule, 'message', sample, '', options) })).filter(x => x.result.matched)
        .sort((a, b) => (Number(b.rule.priority) || 0) - (Number(a.rule.priority) || 0) || b.result.score - a.result.score);
      await this.reply(id, `محاكاة محلية للنص: «${sample.slice(0, 300)}»\nلم أرسل أي رسالة ولم أغير أي إعداد.\n${matched.length ? `القواعد المطابقة (${matched.length}):\n${matched.slice(0, 20).map((item, i) => `${i + 1}. ${item.rule.name} — أولوية ${Number(item.rule.priority) || 0} — نتيجة ${Math.round(item.result.score * 100)}% — ${item.rule.then?.reply || item.rule.then?.replies?.[0] || (item.rule.then?.reaction ? `تفاعل ${item.rule.then.reaction}` : 'من دون نص')}`).join('\n')}` : 'لم تطابق أي قاعدة مفعّلة هذا النص.'}\nراجع النطاق وفترة الهدوء ووقت القاعدة والتهدئة أيضًا؛ هذه محاكاة للعبارة وليست إرسالًا حيًا.`);
      return { handled: true, action: 'test-reply', matches: matched.length };
    }
    if (intent === 'clear-chat-memory') {
      const fresh = this.session(id); fresh.ownerAssistant ||= { flow: null, recent: [] };
      fresh.ownerAssistant.flow = { type: 'clear-chat-memory', step: 'confirm', data: {} }; this.save(fresh);
      await this.reply(id, 'هل تريد مسح سجل المحادثة المحلية الذي يستخدمه الذكاء المحلي لتحسين سياق الرد؟ لن أحذف الأشخاص أو القواعد أو المواعيد أو سجل WhatsApp. اكتب «تأكيد مسح الذاكرة» للمتابعة أو «إلغاء».');
      return { handled: true, action: 'clear-chat-memory-pending' };
    }
    if (intent === 'list-tasks') {
      const tasks = session.automation?.tasks || [];
      await this.reply(id, `المواعيد المحفوظة: ${tasks.length}\n${tasks.slice(0, 40).map((item, i) => `${i + 1}. ${item.name || 'موعد'} — ${item.enabled === false ? 'متوقف' : 'مفعّل'} — ${item.mode || ''} ${item.time || ''}${item.date ? ` — ${item.date}` : ''}`).join('\n') || 'لا توجد مواعيد محفوظة.'}`);
      return { handled: true, action: 'list-tasks' };
    }
    if (intent === 'list-rules') {
      const rules = session.interaction?.rules || [];
      await this.reply(id, `قواعد التفاعل: ${rules.length}\n${rules.slice(0, 40).map((item, i) => `${i + 1}. ${item.name || 'قاعدة'} — ${item.enabled === false ? 'متوقفة' : 'مفعّلة'} — ${item.when?.value || ''} ← ${(item.then?.reply || item.then?.replies?.[0] || '').slice(0, 100)}`).join('\n') || 'لا توجد قواعد محفوظة.'}`);
      return { handled: true, action: 'list-rules' };
    }
    if (intent === 'list-media') {
      const files = typeof this.delivery?.files === 'function' ? this.delivery.files(id) : [];
      await this.reply(id, `الوسائط المرفوعة: ${files.length}\n${files.slice(0, 60).map((item, i) => `${i + 1}. ${item.filename} — ${item.isImage ? 'صورة' : item.ext || 'ملف'} — ${(Number(item.size) / 1048576).toFixed(2)} MB`).join('\n') || 'لا توجد وسائط أو محرك الوسائط غير مربوط.'}`);
      return { handled: true, action: 'list-media' };
    }
    if (intent === 'list-chats') {
      const chats = await this.whatsapp.searchChats(id, { limit: 30 });
      await this.reply(id, chats.length ? `محادثات WhatsApp المتاحة:\n${chats.map((chat, i) => `${i + 1}. ${chat.name}${chat.isGroup ? ' (مجموعة)' : ''} — ${chat.id}`).join('\n')}` : 'لم يتم العثور على محادثات. تأكد من أن جلسة WhatsApp متصلة.');
      return { handled: true, action: 'list-chats' };
    }
    if (Object.prototype.hasOwnProperty.call(canonical, intent) && canonical[intent]) {
      return this.handleSelfChatMessage(id, { body: canonical[intent] });
    }
    if (intent === 'send-message') {
      const targets = [
        ...(session.recipients || []).filter(item => item.enabled !== false).map(item => ({ ...ownTarget(session, item), source: item, type: 'recipient' })),
        ...(session.groups || []).filter(item => item.enabled !== false).map(item => ({ ...ownTarget(session, { ...item, type: 'group' }), source: item, type: 'group' })),
      ].filter(item => normalize(item.label).length >= 2 && normalize(rawText).includes(normalize(item.label))).sort((a, b) => normalize(b.label).length - normalize(a.label).length);
      if (targets.length > 1 && normalize(targets[0].label).length === normalize(targets[1].label).length) {
        await this.reply(id, `وجدت أكثر من مستلم محتمل: ${targets.slice(0, 5).map(x => x.label).join('، ')}. اكتب «أرسل رسالة» ثم اختر الاسم الكامل.`);
        return { handled: true, action: 'ambiguous-recipient' };
      }
      const data = {};
      if (targets[0]) {
        data.target = await this.resolveTarget(session, targets[0].label);
        let remaining = String(rawText || '').replace(new RegExp(targets[0].source.name || targets[0].label, 'iu'), ' ');
        remaining = remaining.replace(/(?:عايز|اريد|ممكن|لو سمحت|يا بوت|ابعت(?:لي)?|ابعث(?:لي)?|ارسل(?:لي)?|ارسال|رساله|الرساله|قل له|قول له|الى|الي|له|بسرعه)/giu, ' ').replace(/(^|\s)ل(?=\s)/gu, ' ').replace(/[|:،,؛.!؟?\-]+/gu, ' ').replace(/\s+/g, ' ').trim();
        const leftover = normalize(remaining);
        if (leftover.length >= 3 && !/^(?:رساله|الرساله|من فضلك|لو سمحت)$/u.test(leftover)) data.message = remaining;
      }
      session.ownerAssistant ||= { flow: null, recent: [] };
      session.ownerAssistant.flow = { type: 'send-message', step: data.message ? 'confirm' : data.target ? 'text' : 'target', data };
      this.save(session);
      if (!data.target) await this.reply(id, 'تمام، سأجهّز الإرسال لكن لن أرسل شيئًا قبل التأكيد. لمن تريد إرسال الرسالة؟ اكتب الاسم المحفوظ أو الرقم الدولي.');
      else if (!data.message) await this.reply(id, `فهمت أن المستلم هو «${data.target.label}». اكتب نص الرسالة كاملًا؛ سأعرضه عليك للتأكيد قبل الإرسال.`);
      else await this.reply(id, `مراجعة الإرسال قبل التنفيذ:
إلى: ${data.target.label}
النص: ${data.message.slice(0, 1200)}${data.message.length > 1200 ? '…' : ''}

هل أرسل هذه الرسالة؟ اكتب «تأكيد الإرسال» أو «إلغاء».`);
      return { handled: true, action: 'send-wizard-started' };
    }
    if (intent === 'interaction-on' || intent === 'interaction-off' || intent === 'group-assistant-on' || intent === 'group-assistant-off' || intent === 'quiet-on' || intent === 'quiet-off' || intent === 'smart-reply-on' || intent === 'smart-reply-off' || intent === 'voice-on' || intent === 'voice-off' || intent === 'fallback-on' || intent === 'fallback-off' || intent === 'group-fallback-on' || intent === 'group-fallback-off') {
      const fresh = this.session(id), settings = fresh.settings || (fresh.settings = {});
      const enabled = intent.endsWith('-on');
      if (intent === 'interaction-on' || intent === 'interaction-off') {
        settings.interactionEnabled = enabled; fresh.interaction ||= {}; fresh.interaction.enabled = enabled;
      } else if (intent === 'group-assistant-on' || intent === 'group-assistant-off') {
        settings.groupAssistantEnabled = enabled;
      } else if (intent.startsWith('quiet-')) settings.interactionQuietEnabled = enabled;
      else if (intent.startsWith('smart-reply-')) {
        if (enabled) {
          if (!this.localLlm) { await this.reply(id, 'لا يوجد محرك Ollama مربوط بهذا الخادم؛ لم أفعّل الرد الذكي.'); return { handled: true, action: 'smart-reply-not-configured' }; }
          const status = await this.localLlm.status(); const model = String(settings.smartReplyModel || 'qwen2.5:3b');
          if (!status.available) { await this.reply(id, `لم أفعّل الذكاء المحلي لأن Ollama غير متصل: ${status.message}`); return { handled: true, action: 'smart-reply-unavailable' }; }
          if (!(status.models || []).some(name => name === model || String(name).split(':')[0] === model.split(':')[0])) { await this.reply(id, `Ollama يعمل لكن النموذج «${model}» غير مثبت. ثبّته محليًا بالأمر: ollama pull ${model}
لم أفعّل الرد الذكي حتى لا يبدو أنه يعمل وهو غير جاهز.`); return { handled: true, action: 'smart-model-missing' }; }
        }
        settings.smartReplyEnabled = enabled;
      } else if (intent.startsWith('voice-')) settings.voiceAutoTranscribeEnabled = enabled;
      else if (intent.startsWith('fallback-')) settings.interactionFallbackEnabled = enabled;
      else if (intent.startsWith('group-fallback-')) settings.interactionFallbackInGroups = enabled;
      this.save(fresh);
      let message = `تم ${enabled ? 'التفعيل' : 'الإيقاف'} وحفظ الإعداد.`;
      if (intent.startsWith('voice-') && enabled && this.audioTranscriber) {
        const status = await this.audioTranscriber.status();
        if (!status.ready) message += `
لكن التفريغ لن يعمل حتى تجهّز Whisper والنموذج المحلي: ${status.message}`;
        else message += '\nمحرك تفريغ الصوت جاهز محليًا.';
      }
      if (intent === 'interaction-on' || intent === 'interaction-off') message += enabled ? '\nالردود ستتبع القواعد والنطاق وفترة عدم الإزعاج.' : '\nلن يرسل محرك التفاعل ردودًا تلقائية حتى تعيد تشغيله.';
      if (intent === 'group-assistant-on' || intent === 'group-assistant-off') message += enabled ? '\nتم تفعيل أوامر GID وتحليل معلومات المجموعات. هذا لا يغيّر قواعد الرد التلقائي العادية.' : '\nتم إيقاف أوامر تحليل المجموعات. إعدادات الرد التلقائي العادية لم تتغير.';
      await this.reply(id, message);
      return { handled: true, action: 'setting-updated', setting: intent, enabled };
    }
    if (intent === 'settings-status') {
      const fresh = this.session(id), st = fresh.settings || {};
      let llm = { available: false, message: 'محرك Ollama غير مربوط.' }, audio = { ready: false, message: 'محرك الصوت غير مربوط.' };
      try { if (this.localLlm) llm = await this.localLlm.status(); } catch (error) { llm.message = String(error?.message || error); }
      try { if (this.audioTranscriber) audio = await this.audioTranscriber.status(); } catch (error) { audio.message = String(error?.message || error); }
      const out = [
        `التفاعل/الرد التلقائي: ${st.interactionEnabled !== false && fresh.interaction?.enabled !== false ? 'مفعّل' : 'متوقف'}`,
        `أوامر GID وتحليل المجموعات: ${st.groupAssistantEnabled !== false ? 'مفعّلة' : 'متوقفة'}`, 
        `الرد الاحتياطي بدون قاعدة: ${st.interactionFallbackEnabled === true ? 'مفعّل' : 'متوقف'}`,
        `الرد الاحتياطي في المجموعات: ${st.interactionFallbackInGroups === true ? 'مفعّل' : 'متوقف'}`,
        `عدم الإزعاج: ${st.interactionQuietEnabled === true ? `مفعّل (${st.interactionQuietStart || '23:00'}–${st.interactionQuietEnd || '07:00'}، السلوك ${st.interactionQuietAction || 'silence'})` : 'متوقف'}`,
        `مطابقة الأخطاء الإملائية: ${st.interactionSmartMatching !== false ? `مفعّلة عند ${Math.round(Number(st.interactionSmartThreshold ?? .82) * 100)}%` : 'متوقفة'}`,
        `الذكاء المحلي: ${st.smartReplyEnabled === true ? 'مفعّل في الإعدادات' : 'متوقف'}؛ الخدمة: ${llm.available ? 'متاحة' : 'غير متاحة'}؛ ${llm.message}`,
        `تفريغ الصوت تلقائيًا: ${st.voiceAutoTranscribeEnabled !== false ? 'مفعّل كخيار' : 'متوقف'}؛ المحرك: ${audio.ready ? 'جاهز' : 'غير جاهز'}؛ ${audio.message}`,
      ].join('\n');
      await this.reply(id, `${out}

لتغييرها عبر الشات: «شغّل الرد التلقائي»، «فعّل عدم الإزعاج»، «شغّل الرد الذكي»، «فعّل فهم الصوتيات».`);
      return { handled: true, action: 'settings-status' };
    }
    return this.conversationalFallback(id, session, rawText);
  }
  async handleConversationRecall(id, session, text) {
    const command = conversationRecall.parseRecallCommand(text);
    if (!command) return null;
    if (typeof this.whatsapp?.getChatSafe !== 'function') {
      await this.reply(id, 'استرجاع المحادثات غير متاح لأن موصل WhatsApp لا يوفّر قراءة المحادثة في الوقت الحالي.');
      return { handled: true, action: 'conversation-recall-unavailable' };
    }
    const targetResult = conversationRecall.resolveRegisteredTarget(session, command.targetQuery, this.whatsapp.selfChatId(id));
    if (targetResult.status === 'ambiguous') {
      await this.reply(id, `الاسم «${command.targetQuery}» يطابق أكثر من محادثة مسجلة:\n${targetResult.matches.map((row, i) => `${i + 1}. ${row.label}${row.type === 'group' ? ' (مجموعة)' : ''}`).join('\n')}\nاكتب الاسم الكامل كما يظهر في قسم الأشخاص أو المجموعات. لم أقرأ أي محادثة.`);
      return { handled: true, action: 'conversation-recall-ambiguous' };
    }
    if (targetResult.status !== 'ok' || !targetResult.target) {
      const message = targetResult.status === 'unavailable' ? targetResult.message : `لم أجد جهة مسجلة تطابق «${command.targetQuery}». لأمانك، لا أسترجع الرسائل إلا من محادثة موجودة في قسم الأشخاص/المجموعات أو محادثة البوت.`;
      await this.reply(id, message || 'لم أتمكن من تحديد المحادثة المسجلة.');
      return { handled: true, action: 'conversation-recall-target-rejected' };
    }
    const target = targetResult.target;
    const actualChatId = String(target.id || '').trim().toLowerCase();
    if (!/^(?:\d{5,25}(?:-\d+)*@g\.us|\d{5,25}@c\.us|\d{5,25}@lid)$/i.test(actualChatId)) {
      await this.reply(id, 'معرّف المحادثة غير صالح أو غير مؤكد. حدّث بيانات هذه الجهة من لوحة المشروع ثم أعد المحاولة.');
      return { handled: true, action: 'conversation-recall-invalid-chat-id' };
    }
    try {
      const cap = command.kind === 'search' ? 500 : command.count;
      const chat = await this.whatsapp.getChatSafe(id, actualChatId);
      const verifiedChatId = conversationTargets.chatIdOf(chat?.id);
      if (!verifiedChatId || verifiedChatId !== actualChatId) throw new Error('لم يطابق WhatsApp المحادثة الفعلية بالجهة المختارة؛ أوقفت الاسترجاع لحماية الخصوصية.');
      if (typeof chat.fetchMessages !== 'function') throw new Error('موصل WhatsApp لا يدعم استرجاع سجل الرسائل في هذه الجلسة.');
      const fetched = await chat.fetchMessages({ limit: cap });
      const messages = Array.isArray(fetched) ? fetched : [];
      const rows = messages.map(message => conversationRecall.rowFromMessage(message, target, actualChatId));
      let stored = { stored: 0, duplicates: 0, failed: 0 };
      if (this.conversationArchive && rows.length) stored = this.conversationArchive.recordMany(id, rows);
      let outputRows = rows;
      if (command.kind === 'search') {
        let localRows = [];
        try { localRows = this.conversationArchive?.search(id, command.query, { limit: 500, targetKey: target.key }) || []; } catch {}
        outputRows = [...new Map([...rows, ...localRows.filter(row => row.targetKey === target.key)].map(row => [`${row.chatId}|${row.messageId || row.id}`, row])).values()]
          .filter(row => row.targetKey === target.key);
      }
      const result = conversationRecall.formatRecallRows(outputRows, { limit: command.kind === 'search' ? 12 : command.count, query: command.kind === 'search' ? command.query : '', targetLabel: target.label });
      const title = command.kind === 'search' ? `نتائج البحث عن «${command.query}» في «${target.label}»` : `آخر ${command.count} رسائل من «${target.label}»`;
      const details = result.count ? result.text : (command.kind === 'search' ? 'لم أجد العبارة في آخر السجل الذي أتاحه WhatsApp أو في الأرشيف المحلي. جرّب استيراد سجل أعمق من صفحة «سجل المحادثات».' : 'لم يُعد WhatsApp أي رسالة لهذه المحادثة.');
      const note = command.kind === 'search'
        ? `\n\nبحثت في حتى ${messages.length} رسالة أتاحها WhatsApp مع الأرشيف المحلي. لاستكشاف رسائل أقدم استخدم «سجل المحادثات» واستيراد حتى 20,000 رسالة في العملية. لا يتم إرسال أي رسالة إلى الجهة المحددة.`
        : `\n\nتمت قراءة ${messages.length} رسالة متاحة في هذه العملية. حُفظ ${Number(stored.stored || 0)} جديدًا في الأرشيف المحلي، وتجاوز ${Number(stored.duplicates || 0)} مكررًا. لم أرسل أي شيء إلى هذه الجهة.`;
      await this.reply(id, `${title} (${result.count} نتيجة):\n${details}${note}`);
      this.log?.(id, 'INFO', `استرجاع سجل محادثة مسجلة: الهدف ${target.key}، النوع ${command.kind}، النتائج ${result.count}، الجديد ${Number(stored.stored || 0)}.`);
      return { handled: true, action: `conversation-recall-${command.kind}`, targetKey: target.key, count: result.count };
    } catch (error) {
      await this.reply(id, `تعذر قراءة المحادثة «${target.label}»: ${String(error?.message || error).slice(0, 500)}. لم أرسل أو أحذف شيئًا.`);
      return { handled: true, action: 'conversation-recall-failed' };
    }
  }
  async resolveTarget(session, value) {
    const query = normalize(value);
    if (!query) throw new Error('لم تكتب اسم الجهة أو رقمها.');
    const all = [
      ...session.recipients.map(x => ({ ...ownTarget(session, x), type: 'recipient', source: x })),
      ...session.groups.map(x => ({ ...ownTarget(session, { ...x, type: 'group' }), type: 'group', source: x })),
    ];
    const exact = all.filter(x => normalize(x.label) === query || normalize(x.chatId) === query);
    const found = exact.length ? exact : all.filter(x => normalize(x.label).includes(query) || normalize(x.chatId).includes(query));
    if (found.length === 1) return found[0];
    if (found.length > 1) throw new Error(`الاسم يطابق أكثر من جهة:\n${found.slice(0, 8).map(x => `• ${x.label}`).join('\n')}\nاكتب الاسم الكامل.`);
    if (/^\d{5,25}@g\.us$/i.test(value.trim())) return { key: '', chatId: value.trim().toLowerCase(), label: value.trim(), type: 'group' };
    try {
      const parsed = this.phones.parse(value, 'OM');
      const chatId = await this.whatsapp.resolveChatId(session.id, { e164: parsed.e164, phone: parsed.digits });
      return { key: '', chatId, label: parsed.international, type: 'recipient' };
    } catch (error) {
      throw new Error(`لم أعثر على جهة مطابقة «${value}». استخدم الاسم المحفوظ كما هو أو رقمًا دوليًا صالحًا. ${error.message}`);
    }
  }
  async stepFlow(id, session, text) {
    const assistant = session.ownerAssistant, flow = assistant.flow, value = String(text || '').trim(), p = normalize(value), d = flow.data || (flow.data = {});
    if (flow.type === 'clear-chat-memory') {
      if (/^(?:لا|لأ|الغاء|تراجع|no|cancel)$/u.test(p)) {
        assistant.flow = null; this.save(session); await this.reply(id, 'تم الإلغاء. لم أمسح أي سجل.'); return true;
      }
      if (!/^(?:تأكيد مسح الذاكرة|تاكيد مسح الذاكره|امسحها|موافق|confirm)$/u.test(p)) {
        await this.reply(id, 'للتأكيد اكتب حرفيًا «تأكيد مسح الذاكرة»، أو اكتب «إلغاء». لم أمسح أي بيانات.'); return true;
      }
      assistant.conversation = [];
      assistant.recent = (assistant.recent || []).filter(item => !['local-chat','audio-transcription'].includes(item.type));
      assistant.flow = null; this.save(session);
      await this.reply(id, 'تم مسح تاريخ محادثتك المحلية مع المساعد وسياق الرد الذكي. لم أحذف جهات الاتصال أو القواعد أو المواعيد أو ملفات الوسائط.');
      return true;
    }
    if (flow.type === 'clarify-command') {
      if (/^(?:لا|لأ|مش قصدي|مش ده|الغاء|إلغاء|تراجع|no|cancel)$/u.test(p)) {
        assistant.flow = null; this.save(session);
        await this.reply(id, 'تمام، لن أنفّذ أي إجراء. اكتب طلبك بصياغة أخرى أو «مساعدة» لعرض الأمثلة.');
        return true;
      }
      if (!/^(?:نعم|ايوه|أيوه|تمام|موافق|صح|بالضبط|نفذ|ابدأ|yes|ok|confirm)$/u.test(p)) {
        await this.reply(id, `هل تقصد: ${flow.data?.label || 'الأمر المقترح'}؟
اكتب «نعم» للمتابعة أو «لا» للإلغاء. لم أنفّذ أي إجراء حتى الآن.`);
        return true;
      }
      const original = String(flow.data?.originalText || '');
      const intent = String(flow.data?.intent || '');
      assistant.flow = null; this.save(session);
      const latest = this.session(id);
      await this.handleInterpretedCommand(id, latest, original, { intent, confidence: Number(flow.data?.confidence) || .7, alternatives: [] });
      return true;
    }
    if (flow.type === 'sync-confirm') {
      if (!isExactConfirmation(value, 'sync')) { await this.reply(id, 'لم تتم المزامنة. اكتب «تأكيد المزامنة» حرفيًا للمتابعة أو «إلغاء» للتراجع. «تمام» وحدها لا تنفذ العملية.'); return true; }
      const result = await this.contactSync.syncContacts({ store: this.store, whatsapp: this.whatsapp, phones: this.phones, sessionId: id, jids: d.jids, importMissing: true, updateNames: false, updatePictures: true });
      // Contact sync saves its own fresh session snapshot. Reload it before clearing this flow so imports aren't overwritten.
      const latest = this.session(id); latest.ownerAssistant.flow = null; latest.ownerAssistant.recent.push({ at: new Date().toISOString(), type: 'whatsapp-contact-sync', imported: result.imported.length, updated: result.updated.length }); this.save(latest);
      await this.reply(id, `${result.message}\nحافظت على الأسماء المحلية التي كتبتها بنفسك، وتم تحديث أسماء WhatsApp ونسخ الصور المتاحة إلى ملف المشروع. لعرض الصور والبحث والاختيار الانتقائي افتح «الأشخاص» في لوحة التحكم.`); return true;
    }
    if (flow.type === 'download-chat-media') {
      if (flow.step === 'choose') {
        const index = Number(p);
        if (!Number.isInteger(index) || index < 1 || index > (d.candidates || []).length) {
          await this.reply(id, `اختر رقمًا من 1 إلى ${(d.candidates || []).length}، أو اكتب «إلغاء».`); return true;
        }
        d.target = d.candidates[index - 1]; flow.step = 'confirm'; this.save(session);
        await this.reply(id, `المحادثة: ${d.target.name}\nنوع المرفقات: ${d.mediaLabel || 'كل أنواع المرفقات'}\nسيبحث البرنامج في آخر 500 رسالة ويحمّل المرفقات إلى مكتبة الوسائط المحلية، بحد أقصى 100 ملف و500 MB إجمالًا (100 MB للملف الواحد). لن يرسل رسائل أو يحذف شيئًا.\nاكتب «تأكيد التنزيل» حرفيًا للمتابعة أو «إلغاء».`); return true;
      }
      if (flow.step === 'confirm') {
        if (!isExactConfirmation(value, 'download')) { await this.reply(id, 'لم يتم تنزيل أي ملف. اكتب «تأكيد التنزيل» حرفيًا للمتابعة أو «إلغاء». «تمام» وحدها لا تنفذ التنزيل.'); return true; }
        if (!d.target?.id || !d.target?.registeredTargetKey) { assistant.flow = null; this.save(session); await this.reply(id, 'أوقفت التنزيل لأن المحادثة المختارة ليست مرتبطة بجهة مسجلة.'); return true; }
        try {
          const fresh = this.session(id);
          const registered = conversationTargets.allowedTarget(fresh, d.target.registeredTargetKey, this.whatsapp.selfChatId(id));
          if (!registered || !registered.chatId || String(registered.chatId).toLowerCase() !== String(d.target.id).toLowerCase()) throw new Error('تم حذف الجهة أو تغيّر معرّفها منذ اختيار المحادثة. اختر جهة مسجلة من جديد.');
          const result = await this.whatsapp.downloadMediaFromChat(id, d.target.id, { messageLimit: 500, maxFiles: 100, perFileBytes: 100 * 1024 * 1024, totalBytes: 500 * 1024 * 1024, mediaType: d.mediaType || 'all' });
          const latest = this.session(id); latest.ownerAssistant.flow = null; latest.ownerAssistant.recent.push({ at: new Date().toISOString(), type: 'chat-media-download', chatId: result.chatId, downloaded: result.downloaded.length, failed: result.failed.length }); this.save(latest);
          const names = result.downloaded.slice(0, 20).map((item, i) => `${i + 1}. ${item.filename} (${Math.ceil(item.bytes / 1024)} KB)`).join('\n');
          await this.reply(id, `اكتمل فحص المحادثة «${result.chatName}».\nالرسائل التي فُحصت: ${result.scanned}. المرفقات المطابقة للنوع المطلوب: ${result.mediaFound}${Number.isFinite(Number(result.mediaFoundTotal)) ? ` من إجمالي ${result.mediaFoundTotal} مرفقًا مكتشفًا` : ''} (عولجت ${result.considered ?? result.mediaFound} ضمن الحدود الآمنة). نُزّل: ${result.downloaded.length}. تعذّر/تخطّي: ${result.failed.length + result.skipped.length}.\n${names || 'لم يُنزّل أي مرفق متاح.'}\n\nالمجلد المحلي: ${result.mediaDirectory}\nيمكنك فتح «الوسائط» في لوحة التحكم لعرض الملفات.`);
        } catch (error) { assistant.flow = null; this.save(session); await this.reply(id, `تعذر تنزيل مرفقات المحادثة: ${String(error?.message || error).slice(0, 500)}\nتحقق من اتصال WhatsApp وصلاحيات قراءة المحادثة ثم أعد المحاولة.`); }
        return true;
      }
    }
    if (flow.type === 'add-recipient') {
      if (flow.step === 'name') {
        if (value.length < 2 || value.length > 80) { await this.reply(id, 'اكتب اسمًا واضحًا من حرفين إلى 80 حرفًا.'); return true; }
        d.name = value; flow.step = 'country'; this.save(session);
        await this.reply(id, `تم تسجيل الاسم: ${d.name}.\nحوار إضافة شخص (2/3)\nاكتب الدولة (مثل: عمان، السعودية، الإمارات، مصر) أو رمز الدولة مثل OM.`); return true;
      }
      if (flow.step === 'country') {
        let cc = countryCode(value);
        if (!cc && value.startsWith('+')) { d.rawPhone = value; d.country = 'OM'; flow.step = 'phone'; this.save(session); await this.finishAddRecipient(id, session, d.rawPhone); return true; }
        if (!cc) { await this.reply(id, 'لم أتعرف على الدولة. اكتب الاسم أو رمز ISO من حرفين، مثل OM أو SA، أو اكتب الرقم مع + ورمز الدولة مباشرة.'); return true; }
        d.country = cc; flow.step = 'phone'; this.save(session);
        await this.reply(id, 'حوار إضافة شخص (3/3)\nاكتب رقم الهاتف. يمكن أن تكتبه محليًا للدولة المحددة أو بصيغة دولية تبدأ بـ +.'); return true;
      }
      if (flow.step === 'phone') { await this.finishAddRecipient(id, session, value); return true; }
      if (flow.step === 'duplicate') {
        if (/^(?:استبدال|غير الاسم|تحديث الاسم|استبدل الاسم|1)$/u.test(p)) {
          const person = session.recipients.find(x => x.id === d.existingId);
          if (person) { person.name = d.name; Object.assign(person, d.parsed); person.whatsappSyncedAt = new Date().toISOString(); }
          assistant.flow = null; this.save(session); await this.reply(id, `تم تحديث جهة الرقم ${d.parsed.international} بالاسم «${d.name}».`); return true;
        }
        if (/^(?:احتفظ|الاسم الحالي|احتفاظ|2)$/u.test(p)) {
          const person = session.recipients.find(x => x.id === d.existingId);
          if (person) Object.assign(person, d.parsed);
          assistant.flow = null; this.save(session); await this.reply(id, 'تم الاحتفاظ بالاسم المحفوظ وتحديث الرقم المعياري فقط.'); return true;
        }
        await this.reply(id, 'اكتب «استبدال الاسم» أو «الاحتفاظ بالاسم» أو «إلغاء».'); return true;
      }
    }
    if (flow.type === 'send-message') {
      if (flow.step === 'target') {
        try { d.target = await this.resolveTarget(session, value); flow.step = 'text'; this.save(session); await this.reply(id, `المستلم: ${d.target.label}.\nحوار إرسال رسالة (2/3)\nاكتب نص الرسالة كاملًا.`); }
        catch (error) { await this.reply(id, `${error.message}\nحاول مرة أخرى أو اكتب «إلغاء».`); }
        return true;
      }
      if (flow.step === 'text') {
        if (!value || value.length > 60000) { await this.reply(id, 'اكتب رسالة من 1 إلى 60,000 حرف.'); return true; }
        d.message = value; flow.step = 'confirm'; this.save(session);
        await this.reply(id, `حوار إرسال رسالة (3/3)\nإلى: ${d.target.label}\nالنص:\n${value.slice(0, 1500)}${value.length > 1500 ? '\n… (سيتم إرسال النص كاملًا)' : ''}\n\nلم يُرسل شيء بعد. اكتب «تأكيد الإرسال» للتنفيذ أو «إلغاء».`); return true;
      }
      if (flow.step === 'confirm') {
        if (!isConfirm(value)) { await this.reply(id, 'لم يتم الإرسال. اكتب «تأكيد الإرسال» للتنفيذ أو «إلغاء» للتوقف.'); return true; }
        const target = d.target;
        if (!target?.chatId) { assistant.flow = null; this.save(session); await this.reply(id, 'أوقفت الإرسال لأن معرّف المستلم غير صالح.'); return true; }
        try {
          const result = await this.whatsapp.sendText(id, target.chatId, d.message);
          const latest = this.session(id); latest.ownerAssistant.flow = null; latest.ownerAssistant.recent.push({ at: new Date().toISOString(), type: 'send-message', target: target.label, chars: d.message.length }); this.save(latest);
          await this.reply(id, `تم تمرير طلب الإرسال إلى WhatsApp. الحالة: ${result?.__chatBotAck?.status || 'قبول الإرسال'}، المستلم: ${target.label}. راجع حالة الرسالة من WhatsApp إذا كنت تحتاج تأكيد وصولها.`);
        } catch (error) {
          // A transport failure can be uncertain: clear confirmation to avoid accidental duplicate sends.
          const latest = this.session(id); latest.ownerAssistant.flow = null; latest.ownerAssistant.recent.push({ at: new Date().toISOString(), type: 'send-message-failed', target: target.label, error: String(error?.message || error).slice(0, 300) }); this.save(latest);
          await this.reply(id, `تعذر تأكيد الإرسال: ${error.message}\nأوقفت المحاولة حتى لا تتكرر الرسالة عند عدم وضوح الحالة. تحقق من المحادثة في WhatsApp قبل إنشاء طلب جديد.`);
        }
        return true;
      }
    }
    if (flow.type === 'schedule') {
      if (flow.step === 'target') {
        try { d.target = await this.resolveTarget(session, value); flow.step = 'message'; this.save(session); await this.reply(id, `المستلم: ${d.target.label}.\nحوار الموعد (2/5)\nاكتب الرسالة التي ستُرسل في الموعد.`); }
        catch (error) { await this.reply(id, `${error.message}\nحاول مرة أخرى أو اكتب «إلغاء».`); }
        return true;
      }
      if (flow.step === 'message') {
        if (!value || value.length > 60000) { await this.reply(id, 'اكتب رسالة من 1 إلى 60,000 حرف.'); return true; }
        d.message = value; flow.step = 'mode'; this.save(session); await this.reply(id, 'حوار الموعد (3/5)\nاختر: مرة واحدة، يومي، أو أسبوعي.'); return true;
      }
      if (flow.step === 'mode') {
        if (/مرة|واحد|one/i.test(value)) d.mode = 'once'; else if (/يوم|daily/i.test(value)) d.mode = 'daily'; else if (/اسبوع|weekly/i.test(p)) d.mode = 'weekly'; else { await this.reply(id, 'اكتب «مرة واحدة» أو «يومي» أو «أسبوعي».'); return true; }
        flow.step = 'time'; this.save(session); await this.reply(id, 'حوار الموعد (4/5)\nاكتب الوقت بصيغة 24 ساعة، مثل 17:30.'); return true;
      }
      if (flow.step === 'time') {
        if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(value)) { await this.reply(id, 'الوقت غير صالح. استخدم HH:MM مثل 17:30.'); return true; }
        d.time = value;
        if (d.mode === 'once') { flow.step = 'date'; this.save(session); await this.reply(id, 'اكتب التاريخ بصيغة YYYY-MM-DD، مثل 2026-11-01.'); }
        else { d.date = ''; flow.step = 'confirm'; this.save(session); await this.showScheduleConfirmation(id, d); }
        return true;
      }
      if (flow.step === 'date') {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || Number.isNaN(Date.parse(`${value}T12:00:00Z`))) { await this.reply(id, 'التاريخ غير صالح. استخدم YYYY-MM-DD، أو «إلغاء».'); return true; }
        d.date = value; flow.step = 'confirm'; this.save(session); await this.showScheduleConfirmation(id, d); return true;
      }
      if (flow.step === 'confirm') {
        if (!isConfirm(value)) { await this.reply(id, 'لم أحفظ الموعد بعد. اكتب «تأكيد الحفظ» أو «إلغاء».'); return true; }
        if (!d.target?.key) { assistant.flow = null; this.save(session); await this.reply(id, 'لا يمكن إنشاء موعد تلقائي لهذا الهدف لأنه غير محفوظ في قائمة الأشخاص أو المجموعات. احفظ الهدف أولًا ثم أعد المحاولة.'); return true; }
        const task = this.store.normalizeAutomationTask({ id: crypto.randomUUID(), name: `موعد من محادثة WhatsApp - ${d.target.label}`.slice(0, 100), enabled: true, mode: d.mode, time: d.time, date: d.date || '', day: new Date().getDay(), dayOfMonth: 1, month: new Date().getMonth()+1, year: new Date().getFullYear(), targetKeys: [d.target.key], mediaIds: [], mediaMode: 'selected', preText: d.message, postText: '', scheduledGroupsEnabled: true, sendOrder: 'target-first' });
        session.automation.tasks.push(task); session.automation.enabled = true; assistant.flow = null; assistant.recent.push({ at: new Date().toISOString(), type: 'schedule-created', taskId: task.id }); this.save(session);
        await this.reply(id, `تم حفظ الموعد «${task.name}».\nالتكرار: ${task.mode}، الوقت: ${task.time}${task.date ? `، التاريخ: ${task.date}` : ''}.\nلم يتم الإرسال الآن؛ سينفّذ المجدول الموعد في وقته إذا ظلت الجلسة متصلة والأتمتة مفعّلة.`); return true;
      }
    }
    if (flow.type === 'chat-rule') {
      if (flow.step === 'trigger') {
        const trigger = String(value || '').trim();
        if (trigger.length < 2 || trigger.length > 500) { await this.reply(id, 'اكتب شرطًا واضحًا من حرفين إلى 500 حرف، أو «إلغاء».'); return true; }
        d.trigger = trigger.replace(/^[{«"']|[}»"']$/gu, '').trim();
        d.name = String(d.name || `رد عند: ${d.trigger.slice(0, 40)}`).slice(0, 100);
        if (!d.reply) { flow.step = 'reply'; this.save(session); await this.reply(id, `الشرط الذي فهمته: الرسالة تحتوي على «${d.trigger}».\nالآن أرسل الرد المطلوب. مثال: أهلًا {{sender}}\nلم تُحفظ القاعدة بعد.`); }
        else { flow.step = 'confirm'; this.save(session); await this.reply(id, chatRuleLanguage.formatRulePreview(d)); }
        return true;
      }
      if (flow.step === 'reply') {
        if (!value || value.length > 4000) { await this.reply(id, 'اكتب ردًا من حرف واحد إلى 4000 حرف.'); return true; }
        d.reply = value; flow.step = 'confirm'; this.save(session); await this.reply(id, chatRuleLanguage.formatRulePreview(d)); return true;
      }
      if (flow.step === 'confirm') {
        if (/^(?:تعديل القاعده|تعديل القاعدة|edit rule)$/iu.test(p)) { flow.step = 'trigger'; d.trigger = ''; d.reply = ''; this.save(session); await this.reply(id, 'سنعدّل القاعدة من البداية. أرسل عبارة الشرط («عندما»). لم يتم حفظ أي شيء.'); return true; }
        if (!/^(?:تاكيد القاعده|تأكيد القاعدة|احفظ القاعده|احفظ القاعدة|confirm rule)$/u.test(normalize(value))) { await this.reply(id, 'لم أحفظ القاعدة بعد. راجع الملخص ثم اكتب حرفيًا «تأكيد القاعدة» للحفظ، أو «تعديل القاعدة»، أو «إلغاء».'); return true; }
        const supportedMatch = ['contains','exact','starts','ends','similarity','intent','regex','any'].includes(d.match) ? d.match : 'contains';
        const trigger = String(d.trigger || '').slice(0,500);
        try { triggerEngine.validateTrigger({ when: { type: 'message', match: supportedMatch, value: trigger, threshold: d.threshold } }); } catch (error) { flow.step = 'confirm'; this.save(session); await this.reply(id, `لا يمكن حفظ هذه القاعدة: ${String(error.message || error)}\nلم أحفظ أي شيء. اكتب «تعديل القاعدة» أو «إلغاء».`); return true; }
        const rule = { id: crypto.randomUUID(), name: String(d.name || `رد عند: ${trigger.slice(0,40)}`).slice(0,100), enabled: true, priority: 10, when: { type: 'message', match: supportedMatch, value: trigger, threshold: Number(d.threshold ?? 0.75) }, then: { reply: String(d.reply).slice(0,4000), replies: [String(d.reply).slice(0,4000)], stopAfter: true }, scope: ['all','private','groups'].includes(d.scope) ? d.scope : 'all', chatIds: [], cooldownSec: Math.max(0, Math.min(86400, Number(d.cooldownSec ?? 45) || 0)), commandPriority: false, conflictGroup: '' };
        session.interaction ||= { rules: [] }; session.interaction.rules ||= []; session.interaction.rules.push(rule); session.interaction.rules = session.interaction.rules.slice(-500);
        assistant.flow = null; assistant.recent ||= []; assistant.recent.push({ at: new Date().toISOString(), type: 'reply-rule-created', ruleId: rule.id, source: 'chat-rule-language' }); this.save(session);
        await this.reply(id, `تم حفظ قاعدة «${rule.name}» بنجاح وهي مفعّلة.\nالشرط: الرسالة ${({ exact: 'تطابق', starts: 'تبدأ بـ', ends: 'تنتهي بـ', similarity: 'تشبه', intent: 'يُحلل معناها على أساس', regex: 'تطابق النمط المنتظم', any: 'أي رسالة غير فارغة', contains: 'تحتوي على' })[supportedMatch]} «${rule.when.value}»\nالرد: ${rule.then.reply.slice(0,800)}\nالنطاق: ${{ all: 'الكل', private: 'الخاص', groups: 'المجموعات' }[rule.scope]}\nالتهدئة: ${rule.cooldownSec} ثانية.\nنصيحة: اكتب «اختبر الرد التلقائي على: ${rule.when.value}» لمحاكاتها دون إرسال، ثم تحقق من تفعيل التفاعل العام والنطاق.`);
        return true;
      }
    }
    if (flow.type === 'auto-reply') {
      if (flow.step === 'trigger') {
        if (value.length < 2 || value.length > 500) { await this.reply(id, 'اكتب عبارة مطابقة من حرفين إلى 500 حرف.'); return true; }
        d.trigger = value; flow.step = 'reply'; this.save(session); await this.reply(id, `عبارة المطابقة: «${value}».\nحوار الرد التلقائي (2/3)\nاكتب الرد الذي سيرسله البوت. يمكنك استخدام {{sender}} و{{message}} و{{chat}} و{{time}}.`); return true;
      }
      if (flow.step === 'reply') {
        if (!value || value.length > 4000) { await this.reply(id, 'اكتب ردًا من 1 إلى 4,000 حرف.'); return true; }
        d.reply = value; flow.step = 'confirm'; this.save(session);
        await this.reply(id, `حوار الرد التلقائي (3/3)\nعند وصول رسالة تحتوي: «${d.trigger}»\nسيرد البوت: «${value.slice(0, 1200)}${value.length > 1200 ? '…' : ''}»\n\nاكتب «تأكيد الحفظ» لإضافة القاعدة أو «إلغاء».`); return true;
      }
      if (flow.step === 'confirm') {
        if (!isConfirm(value)) { await this.reply(id, 'اكتب «تأكيد الحفظ» أو «إلغاء».'); return true; }
        const rule = { id: crypto.randomUUID(), name: `قاعدة من WhatsApp: ${d.trigger.slice(0, 50)}`, enabled: true, priority: 10, when: { type: 'message', match: 'contains', value: d.trigger }, then: { reply: d.reply, replies: [d.reply], stopAfter: true }, scope: 'all', chatIds: [], cooldownSec: 45, commandPriority: false, conflictGroup: '' };
        session.interaction.rules.push(rule); session.interaction.rules = session.interaction.rules.slice(-500); assistant.flow = null; assistant.recent.push({ at: new Date().toISOString(), type: 'reply-rule-created', ruleId: rule.id }); this.save(session);
        await this.reply(id, `تم حفظ قاعدة الرد «${rule.name}». ستطابق الرسائل الواردة في المحادثات التي يسمح بها نطاق التفاعل. راجع صفحة «التفاعل» لتغيير النطاق أو إيقافها.`); return true;
      }
    }
    return false;
  }
  async finishAddRecipient(id, session, input) {
    const flow = session.ownerAssistant.flow, data = flow?.data || {};
    let parsed;
    try { parsed = this.phones.parse(input, data.country || 'OM'); }
    catch (error) { await this.reply(id, `رقم الهاتف غير صالح: ${error.message}\nاكتب الرقم مجددًا، أو «إلغاء».`); return; }
    const existing = session.recipients.find(x => String(x.digits || x.phone || '').replace(/\D/g, '') === parsed.digits || String(x.e164 || '') === parsed.e164);
    if (existing) {
      flow.step = 'duplicate'; Object.assign(data, { existingId: existing.id, parsed }); this.save(session);
      await this.reply(id, `هذا الرقم موجود بالفعل باسم «${existing.name}» (${parsed.international}).\nاكتب «استبدال الاسم» لتغييره إلى «${data.name}»، أو «الاحتفاظ بالاسم» للإبقاء على الاسم الحالي، أو «إلغاء».`); return;
    }
    const person = { id: crypto.randomUUID(), name: String(data.name || parsed.international).slice(0, 80), ...parsed, enabled: true };
    session.recipients.push(person); session.setupComplete = true; session.ownerAssistant.flow = null; session.ownerAssistant.recent.push({ at: new Date().toISOString(), type: 'recipient-added', recipientId: person.id }); this.save(session);
    await this.reply(id, `تمت إضافة «${person.name}» بنجاح.\nالرقم المحفوظ: ${parsed.international}\nيمكنك الآن كتابة «أرسل رسالة» لاختيار مستلم وإرسال رسالة بعد تأكيدك.`);
  }
  async showScheduleConfirmation(id, d) {
    await this.reply(id, `راجع الموعد قبل حفظه:\nالهدف: ${d.target.label}\nالرسالة: ${d.message.slice(0, 1000)}${d.message.length > 1000 ? '…' : ''}\nالتكرار: ${d.mode}\nالوقت: ${d.time}${d.date ? `\nالتاريخ: ${d.date}` : ''}\n\nاكتب «تأكيد الحفظ» لإنشاء الموعد، أو «إلغاء».`);
  }
}

module.exports = { OwnerAssistant, WELCOME_GUIDE, normalize, isCancel, isConfirm };
