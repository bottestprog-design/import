'use strict';

/**
 * WhatsApp Web normally exposes Message.fromMe, but some refreshed wrappers
 * only retain that flag in the serialized message key. Keep this check shared
 * so self-chat routing and archive handling cannot disagree on message origin.
 */
function isFromMeMessage(message) {
  const serializedId = String(
    message?.id?._serialized || message?._data?.id?._serialized ||
    message?.id?.$1 || message?._data?.id?.$1 ||
    message?.id?.id?._serialized || message?._data?.id?.id?._serialized ||
    message?.id?.id?.$1 || message?._data?.id?.id?.$1 || ''
  );
  return message?.fromMe === true ||
    message?._data?.id?.fromMe === true ||
    message?.id?.fromMe === true ||
    /^(?:true|1)_/i.test(serializedId);
}

module.exports = { isFromMeMessage };
