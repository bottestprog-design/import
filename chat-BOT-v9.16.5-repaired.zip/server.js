"use strict";

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
require('./src/env-loader').loadEnv(path.join(__dirname, '.env'));
const HOST = process.env.HOST || '127.0.0.1';
const remoteAccess = require('./src/remote-access');
const REMOTE_ACCESS_CONFIG = remoteAccess.createConfig(HOST, process.env);
const express = require('express');
const multer = require('multer');

const store = require('./src/store');
const { acquireProcessLock } = require('./src/process-lock');
const serverProcessLock = acquireProcessLock(path.join(__dirname, '.runtime', 'server.lock'));
const media = require('./src/media');
const phones = require('./src/phones');
const groups = require('./src/groups');
const backgrounds = require('./src/backgrounds');
const { WhatsAppManager, safeError, groupFromMessage } = require('./src/whatsapp');
const { DeliveryService } = require('./src/delivery');
const { InteractionEngine } = require('./src/interaction');
const { ReliableScheduler, nextRun, due, dueForItem, nextRunForItem } = require('./src/scheduler');
const { AutomationEngine, normalizeAutomationRule, normalizeMute } = require('./src/automation-engine');
const { logFactory, replyError, randomId } = require('./src/serverlib');
const { EventBus } = require('./src/event-bus');
const { CommandEngine } = require('./src/command-engine');
const { DictionaryEngine, normalizeDictionaryText } = require('./src/dictionary-engine');
const { parseVoiceCommand } = require('./src/voice-to-command');
const recipientReplies = require('./src/recipient-replies');
const recipientManagement = require('./src/recipient-management');
const { OwnerAssistant } = require('./src/owner-assistant');
const { LocalCommandBridge } = require('./src/local-command-bridge');
const whatsappContacts = require('./src/whatsapp-contacts');
const recipientAvatars = require('./src/recipient-avatars');
const { LocalLLM } = require('./src/local-llm');
const { AudioTranscriber } = require('./src/audio-transcriber');
const { startVoiceBootstrap, getVoiceBootstrapStatus } = require('./src/voice-bootstrap');
const { isFromMeMessage } = require('./src/message-identifiers');
const { ConversationArchive } = require('./src/conversation-archive');
const { TextToSpeech } = require('./src/text-to-speech');
const conversationTargets = require('./src/conversation-targets');
const { conversationSystemPrompt } = require('./src/smart-reply');
const { validateRuntimeSettings, modelInstalled } = require('./src/settings-readiness');
const { maySendVoiceSetupNotice } = require('./src/voice-policy');
const { IntegrationHub } = require('./src/integration-hub');
const localBackup = require('./src/local-backup');

const PORT = store.toInt(process.env.PORT, 7005, 1, 65535);
const TEMP = path.join(store.DATA_DIR, '_temp');
fs.mkdirSync(TEMP, { recursive: true });

const log = logFactory(store);
const eventBus = new EventBus({ maxHistory: 500, logger: (type, detail) => log(null, 'WARN', `${type}: ${JSON.stringify(detail)}`) });
const commandEngine = new CommandEngine({ audit: entry => eventBus.publish('command.audit', entry).catch(() => {}) });
const dictionaryEngine = new DictionaryEngine();
const whatsapp = new WhatsAppManager({ store, log });
const localLlm = new LocalLLM();
const audioTranscriber = new AudioTranscriber({ logger: (level, message) => log(null, level, message), tempDir: TEMP });
const conversationArchive = new ConversationArchive({ store });
const textToSpeech = new TextToSpeech({ localLlm });
let voiceBootstrapTask = null;
const delivery = new DeliveryService({ store, whatsapp, log });
const interaction = new InteractionEngine({ store, whatsapp, log, localLlm });
const ownerAssistant = new OwnerAssistant({ store, whatsapp, phones, log, audioTranscriber, localLlm, delivery, speechSynthesizer: textToSpeech, conversationArchive });
const localCommandBridge = new LocalCommandBridge({ store, whatsapp, delivery, phones, log, saveGroup, normalizeAutomationPayload });
const automationEngine = new AutomationEngine({ store, whatsapp, log });
const scheduler = new ReliableScheduler({ store, run: id => delivery.scheduledRun(id), runTask: (id, task) => delivery.scheduledTaskRun(id, task), runAutomation: (id, now) => automationEngine.runDueRules(id, now, dueForItem), log });
const integrationHub = new IntegrationHub({ store, logger: log, whatsapp });

function sid(req) {
  return store.safeSessionId(req.body?.sessionId || req.query?.sessionId || store.activeSessionId());
}
function boolValue(value, fallback = false) {
  if (value === undefined || value === null) return fallback;
  if (typeof value === 'boolean') return value;
  const x = String(value).trim().toLowerCase();
  if (['true', '1', 'yes', 'on', 'نعم', 'تشغيل', 'مفعّل'].includes(x)) return true;
  if (['false', '0', 'no', 'off', 'لا', 'إيقاف', 'متوقف'].includes(x)) return false;
  return fallback;
}
function uniqueStrings(values) {
  return [...new Set((Array.isArray(values) ? values : []).map(v => String(v || '').trim()).filter(Boolean))];
}
function validTargetKeys(session, keys) {
  const allowed = new Set([
    ...session.recipients.map(x => `r:${x.id}`),
    ...session.groups.map(x => `g:${x.id}`),
  ]);
  return uniqueStrings(keys).filter(k => allowed.has(k));
}
function normalizeRuleChatIds(chatIds) {
  return uniqueStrings(chatIds).map(v => v.toLowerCase());
}
function validIsoDate(value) {
  const x = String(value || '').trim(), m = x.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return false;
  const y = Number(m[1]), mo = Number(m[2]), d = Number(m[3]);
  if (mo < 1 || mo > 12 || d < 1 || d > 31) return false;
  const dt = new Date(Date.UTC(y, mo - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === mo - 1 && dt.getUTCDate() === d;
}
function saveGroup(id, info) {
  const s = store.loadSession(id);
  const n = store.normalizeGroup(info);
  n.gid = groups.normalizeGid(n.gid);
  if (!groups.isGroupId(n.gid)) throw new Error('GID المجموعة غير صالح.');
  const old = s.groups.find(x => x.gid === n.gid);
  if (old) {
    const enabled = old.enabled;
    const discoveredAt = old.discoveredAt;
    const before = JSON.stringify({ name: old.name, gid: old.gid, inviteCode: old.inviteCode, description: old.description, owner: old.owner, participantsCount: old.participantsCount, participants: old.participants, admins: old.admins, enabled });
    Object.assign(old, n, { enabled, discoveredAt, updatedAt: old.updatedAt || new Date().toISOString() });
    const after = JSON.stringify({ name: old.name, gid: old.gid, inviteCode: old.inviteCode, description: old.description, owner: old.owner, participantsCount: old.participantsCount, participants: old.participants, admins: old.admins, enabled });
    if (before !== after) { old.updatedAt = new Date().toISOString(); store.saveSession(s); log(id, 'INFO', `تم تحديث بيانات المجموعة: ${old.name || old.gid}`); }
    return old;
  }
  s.groups.push(n);
  s.setupComplete = true;
  store.saveSession(s);
  log(id, 'INFO', `تم ربط مجموعة جديدة: ${n.name || n.gid}`);
  return n;
}
function removeTargetFromSchedule(s, key) {
  const current = Array.isArray(s.settings.scheduleTargetKeys) ? s.settings.scheduleTargetKeys : [];
  const hadExplicitTargets = current.length > 0;
  s.settings.scheduleTargetKeys = current.filter(x => x !== key);
  if (hadExplicitTargets && s.settings.scheduleTargetKeys.length === 0) s.settings.scheduleEnabled = false;
}
function snapshot(id) {
  const s = store.loadSession(id);
  const scan = media.scan(store.getPaths(id).media, s.settings.maxImageSizeMB);
  return {
    version: store.APP_VERSION,
    session: { id: s.id, name: s.name, setupComplete: s.setupComplete },
    media: scan.files.map(x => ({ ...x, url: `/media/${encodeURIComponent(x.filename)}?sessionId=${encodeURIComponent(id)}` })),
    activeSessionId: store.activeSessionId(),
    sessions: store.listSessionIds().map(x => {
      const ss = store.loadSession(x);
      const runtime = whatsapp.listRuntime(x);
      const summary = media.quickSummary(store.getPaths(x).media);
      return { id: ss.id, name: ss.name, status: runtime.status, ready: runtime.ready, recipients: ss.recipients.filter(y => y.enabled !== false).length, groups: ss.groups.filter(y => y.enabled !== false).length, images: summary.images, files: summary.files };
    }),
    recipients: s.recipients.map(person => recipientAvatars.avatarView(person, id, s.updatedAt)),
    groups: s.groups,
    images: scan.images.map(x => ({ ...x, url: `/media/${encodeURIComponent(x.filename)}?sessionId=${encodeURIComponent(id)}` })),
    invalidImages: scan.invalid,
    duplicates: scan.duplicates,
    currentImage: delivery.currentImage(id),
    cycle: s.cycle,
    settings: s.settings,
    interaction: s.interaction,
    whatsapp: whatsapp.listRuntime(id),
    schedule: { ...due(new Date(), s), nextRun: nextRun(s) },
    automation: { enabled: s.automation.enabled !== false, tasks: (s.automation.tasks || []).map(t => ({ ...t, nextRun: nextRunForItem({ ...t, timezone: s.settings.timezone }) })), rules: s.automation.rules || [], mutes: s.automation.mutes || [], eventState: { totalMessages: Number(s.automation.eventState?.totalMessages || 0), chatCount: Object.keys(s.automation.eventState?.byChat || {}).length }, groupPermissions: s.settings.automationGroupPermissions || {}, recent: s.automation.recent || [] },
    background: {
      mode: s.settings.backgroundMode,
      imageName: s.settings.backgroundImage,
      imageUrl: s.settings.backgroundImage ? `/background/${encodeURIComponent(s.settings.backgroundImage)}?sessionId=${encodeURIComponent(id)}&v=${encodeURIComponent(s.updatedAt)}` : null,
      opacity: s.settings.backgroundOpacity,
      settings: s.settings.backgroundSettings,
    },
    stats: s.stats,
    lastRun: s.lastRun,
    logs: s.logs.slice(-60).reverse(),
  };
}

function localAssistantResponse(id, prompt) {
  const raw = String(prompt || '').trim().slice(0, 1000);
  if (!raw) throw new Error('اكتب سؤالك أو الأمر المحلي أولًا.');
  const query = normalizeDictionaryText(raw).replace(/[،.!؟?]+/gu, '').trim();
  const s = store.loadSession(id);
  const runtime = whatsapp.listRuntime(id);
  const p = query.replace(/\s+/g, ' ');
  const pageTargets = [
    { page: 'dashboard', words: ['الرئيسيه','الرئيسية','الداشبورد','dashboard'] },
    { page: 'send', words: ['الارسال','الإرسال','ارسال','send'] },
    { page: 'people', words: ['الاشخاص','الأشخاص','المستلمين','جهات الارسال','جهات الإرسال','people'] },
    { page: 'groups', words: ['المجموعات','groups'] },
    { page: 'interaction', words: ['التفاعل','الردود التلقائيه','الردود التلقائية','interaction'] },
    { page: 'automation', words: ['الاتمته','الأتمتة','الجدوله','الجدولة','automation'] },
    { page: 'session', words: ['الجلسه','الجلسة','الاتصال','واتساب','session'] },
    { page: 'settings', words: ['الاعدادات','الإعدادات','settings'] },
    { page: 'tools', words: ['المحركات الذكيه','المحركات الذكية','المحركات','tools'] },
    { page: 'guide', words: ['الدليل','المساعده','المساعدة','guide'] },
    { page: 'updates', words: ['التعديلات','الاصدارات','الإصدارات','سجل التغييرات','updates'] },
    { page: 'assistant', words: ['المساعد المحلي','المساعد','assistant'] },
    { page: 'owner-center', words: ['مركز المساعد','لوحة المساعد','owner center'] },
    { page: 'appearance', words: ['المظهر','الخلفيات'] },
    { page: 'operation', words: ['التشغيل المتقدم','اعدادات التشغيل','إعدادات التشغيل'] },
  ];
  const openMatch = p.match(/^(?:افتح|انتقل(?:\s+إلى)?|اذهب(?:\s+إلى)?|روح(?:\s+ل)?|وديني(?:\s+إلى)?|اعرض\s+صفحة)\s*(.*)$/u);
  if (openMatch) {
    const target = normalizeDictionaryText(openMatch[1]);
    const found = pageTargets.find(item => item.words.some(word => target === normalizeDictionaryText(word) || target.includes(normalizeDictionaryText(word))));
    if (found) return { reply: `سأفتح صفحة «${found.words[0]}». لم يتم تنفيذ أي إرسال أو تغيير خارجي.`, navigate: found.page };
    return { reply: 'لم أتعرف على اسم الصفحة. جرّب: الرئيسية، الإرسال، الأشخاص، المجموعات، التفاعل، الأتمتة، الجلسة، الإعدادات، المحركات الذكية، أو التعديلات.' };
  }

  if (/(?:الحاله|حاله النظام|حاله الاتصال|متصل|الاتصال|status)/u.test(p)) {
    const status = runtime.ready ? 'متصل' : runtime.status === 'qr' ? 'بانتظار مسح رمز QR' : runtime.status || 'غير متصل';
    const enabledRecipients = s.recipients.filter(x => x.enabled !== false).length;
    const enabledGroups = s.groups.filter(x => x.enabled !== false).length;
    return { reply: `حالة الجلسة «${s.name}»: ${status}.\nالأشخاص المفعّلون: ${enabledRecipients}/${s.recipients.length}.\nالمجموعات المفعّلة: ${enabledGroups}/${s.groups.length}.\nقواعد الرد: ${(s.interaction.rules || []).filter(x => x.enabled !== false).length} مفعّلة.\nمهام الأتمتة: ${(s.automation.tasks || []).filter(x => x.enabled !== false).length} مفعّلة.` };
  }
  if (/(?:كم|عدد|قائمة|اعرض|اسماء).*(?:الاشخاص|المستلمين|جهات الارسال)|(?:الاشخاص|المستلمين|جهات الارسال).*(?:كم|عدد|قائمة|اسماء)/u.test(p)) {
    const list = s.recipients.slice(0, 15).map(x => `• ${x.name || 'بدون اسم'} — ${x.international || x.e164 || x.phone || ''}${x.enabled === false ? ' (متوقف)' : ''}`);
    return { reply: `لديك ${s.recipients.length} شخص محفوظ في الجلسة الحالية.${list.length ? `\n${list.join('\n')}${s.recipients.length > list.length ? `\n... و${s.recipients.length - list.length} إضافي` : ''}` : '\nلم تضف أشخاصًا بعد.'}` };
  }
  if (/(?:كم|عدد|قائمة|اعرض|اسماء).*(?:المجموعات)|(?:المجموعات).*(?:كم|عدد|قائمة|اسماء)/u.test(p)) {
    const list = s.groups.slice(0, 15).map(x => `• ${x.name || x.gid} — ${x.gid || ''}`);
    return { reply: `لديك ${s.groups.length} مجموعة محفوظة.${list.length ? `\n${list.join('\n')}${s.groups.length > list.length ? `\n... و${s.groups.length - list.length} إضافي` : ''}` : '\nلم تربط أي مجموعة بعد.'}` };
  }
  if (/(?:قواعد|الردود|التفاعل)/u.test(p)) {
    const rules = s.interaction.rules || [];
    return { reply: `قواعد التفاعل في الجلسة الحالية: ${rules.length}.\nالمفعّل: ${rules.filter(x => x.enabled !== false).length}.\nالمتوقف: ${rules.filter(x => x.enabled === false).length}.\nيمكنك فتح صفحة «التفاعل» لمراجعة القواعد وتعديلها.` , navigate: /(?:افتح|انتقل)/u.test(p) ? 'interaction' : undefined };
  }
  if (/(?:المواعيد|مهام الاتمته|الجدوله|الجدولة|الاتمته|الأتمتة|automation)/u.test(p)) {
    return { reply: `لديك ${(s.automation.tasks || []).length} موعدًا محفوظًا، و${(s.automation.rules || []).length} قاعدة أتمتة.\nلا أغيّر المواعيد من هذه المحادثة؛ افتح صفحة الأتمتة لمراجعتها قبل تعديلها.`, navigate: 'automation' };
  }
  if (/(?:سجل النشاط|اخر العمليات|آخر العمليات|السجل)/u.test(p)) {
    const rows = (s.logs || []).slice(-6).reverse().map(x => `• ${x.at || x.time || ''} ${x.level || ''} ${x.message || x.text || ''}`.trim());
    return { reply: rows.length ? `آخر الأنشطة المسجلة:\n${rows.join('\n')}` : 'لا توجد أنشطة مسجلة في هذه الجلسة حتى الآن.', navigate: 'owner-center' };
  }
  const defMatch = p.match(/^(?:ما معنى|معنى|تعريف|عرف|اشرح مصطلح)\s+(.+)$/u);
  if (defMatch) {
    const entry = dictionaryEngine.lookup(defMatch[1]);
    return entry ? { reply: `${entry.term}\n${entry.definition || 'لا يوجد تعريف محفوظ لهذا المصطلح.'}` } : { reply: `لم أجد تعريفًا محفوظًا لـ «${defMatch[1]}» في القاموس المحلي الحالي. القاموس لا يخترع تعريفات غير موجودة.` };
  }
  if (/^(?:مساعدة|الاوامر|ساعدني|help)$/u.test(p)) {
    return { reply: 'أنا مساعد محلي يعتمد على أوامر وقواعد معروفة، ولا أتصل بخدمة ذكاء اصطناعي خارجية.\nجرّب: «الحالة»، «قائمة الأشخاص»، «قائمة المجموعات»، «قواعد التفاعل»، «الأتمتة»، «سجل النشاط»، أو «افتح الإعدادات».\nيمكن تحليل أوامر مكتوبة أو مفرّغة من الصوت في صفحة المحركات الذكية. لا أنفّذ حذفًا أو إرسالًا من هذه المحادثة.' };
  }
  const parsed = parseVoiceCommand(raw, { locale: 'ar', confidence: 1, minConfidence: .72 });
  if (parsed.accepted) {
    const description = { mute: 'كتم الإشعارات', unmute: 'إلغاء الكتم', archive: 'أرشفة محادثة', 'delete-message': 'حذف رسالة', help: 'مساعدة', status: 'حالة النظام' }[parsed.intent] || parsed.intent;
    return { reply: `تعرفت على الأمر: ${description}${parsed.targetText ? `\nالهدف النصي: ${parsed.targetText}` : ''}.\nهذا تحليل فقط؛ لم يتم تنفيذ أي إجراء على WhatsApp.${parsed.requiresConfirmation ? '\nهذا الإجراء يحتاج مراجعة وتأكيدًا صريحًا.' : ''}`, parsed, navigate: parsed.intent === 'status' ? 'owner-center' : undefined };
  }
  return { reply: 'لم أتعرف على هذا السؤال ضمن الأوامر المحلية المعروفة. جرّب صياغة أخرى أو فعّل نموذج Ollama المحلي من إعدادات الردود الذكية للحصول على إجابات أكثر مرونة.', fallback: true };
}

let backupMaintenanceInProgress = false;
let backupSessionRestartPending = false;
let activeApiRequests = 0;
function currentlyActiveSessionIds() {
  const inactive = new Set(['idle', 'stopped', 'disconnected', 'error', 'auth_failure']);
  return store.listSessionIds().filter(id => {
    try { const runtime = whatsapp.listRuntime(id); return Boolean(runtime.ready) || !inactive.has(String(runtime.status || '').toLowerCase()); }
    catch { return false; }
  });
}
function scheduleSavedSessionRestart(delayMs, label, explicitSessionIds = null) {
  backupSessionRestartPending = true;
  const explicit = Array.isArray(explicitSessionIds) ? new Set(explicitSessionIds) : null;
  const timer = setTimeout(async () => {
    try {
      for (const id of store.listSessionIds()) {
        try {
          const session = store.loadSession(id);
          const hasSavedAuth = whatsapp.hasSavedAuth(id);
          const shouldStart = explicit ? explicit.has(id) : Boolean(session.settings.autoStartSession && hasSavedAuth);
          if (shouldStart && (explicit || hasSavedAuth) && !whatsapp.listRuntime(id).ready) {
            try { await whatsapp.start(id, { recovery: true }); }
            catch (error) { log(id, 'WARN', `تعذر إعادة تشغيل الجلسة بعد ${label}: ${safeError(error)}`); }
          }
        } catch (error) { log(id, 'WARN', `تعذر تهيئة الجلسة بعد ${label}: ${safeError(error)}`); }
      }
    } finally {
      backupSessionRestartPending = false;
    }
  }, delayMs);
  timer.unref?.();
}
const app = express();
app.disable('x-powered-by');
app.use((req, res, next) => {
  const access = remoteAccess.authorizeRequest(req, REMOTE_ACCESS_CONFIG);
  if (access.authorized) return next();
  res.set('WWW-Authenticate', remoteAccess.CHALLENGE);
  return res.status(401).type('text/plain').send('لوحة التحكم تتطلب تسجيل الدخول. اضبط DASHBOARD_USERNAME وDASHBOARD_PASSWORD على الخادم.');
});
app.use(express.json({ limit: '6mb' }));
app.use(express.urlencoded({ extended: true, limit: '6mb' }));
app.use((req, res, next) => {
  const pathname = String(req.path || req.url || '/').split('?')[0];
  const isApi = pathname.startsWith('/api/');
  const isBackupApi = pathname.startsWith('/api/backup/');
  if (backupMaintenanceInProgress && isApi && !isBackupApi) return res.status(503).json({ ok: false, error: 'تجري استعادة النسخة الاحتياطية. أعد المحاولة بعد اكتمالها.' });
  if (isApi && !isBackupApi) {
    activeApiRequests++;
    let finished = false;
    const release = () => { if (!finished) { finished = true; activeApiRequests = Math.max(0, activeApiRequests - 1); } };
    res.once('finish', release);
    res.once('close', release);
  }
  next();
});
app.use(express.static(path.join(store.ROOT, 'public')));

app.get('/api/health', (_req, res) => res.json({ ok: true, version: store.APP_VERSION, time: new Date().toISOString(), node: process.version, whatsappStatusEndpoint: true }));
app.get('/api/architecture/health', (_req, res) => res.json({ ok: true, version: store.APP_VERSION, modules: { eventBus: eventBus.stats(), commandEngine: commandEngine.list().length, dictionaryEngine: dictionaryEngine.entries.size, voiceParser: true, voiceTranscriber: true, textToSpeech: true, conversationArchive: true, localLlm: true, persistence: 'session-json-local', productionScaleAdapter: 'not configured' } }));

// Local encrypted backup/restore. Includes session JSON, media, WhatsApp profile data,
// integration settings, and the matching vault keys; transient processing files are excluded.
app.post('/api/backup/export', async (req, res) => {
  if (backupMaintenanceInProgress || backupSessionRestartPending) return res.status(409).json({ ok: false, error: 'تجري عملية نسخ أو تهيئة جلسات بعد الاستعادة؛ أعد المحاولة بعدها.' });
  let password;
  try { password = localBackup.validatePassword(req.body?.password); }
  catch (error) { return res.status(422).json({ ok: false, error: safeError(error) }); }
  backupMaintenanceInProgress = true;
  let schedulerPaused = false, hubPaused = false, restartSessionsAfterExport = [];
  try {
    for (let i = 0; i < 200 && activeApiRequests > 0; i++) await new Promise(resolve => setTimeout(resolve, 50));
    if (activeApiRequests > 0) throw new Error('ما زالت هناك طلبات نشطة؛ لم تبدأ عملية النسخ. أعد المحاولة بعد هدوء النشاط.');
    await scheduler.pause(); schedulerPaused = true;
    await integrationHub.pause(); hubPaused = true;
    const ids = store.listSessionIds();
    restartSessionsAfterExport = currentlyActiveSessionIds();
    for (const id of ids) await whatsapp.stop(id);
    const archive = localBackup.createEncryptedBackup(store.DATA_DIR, password, store.APP_VERSION);
    const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    res.set('Content-Type', 'application/octet-stream');
    res.set('Content-Disposition', `attachment; filename=\"chat-bot-local-backup-${date}.cbotbackup\"`);
    res.set('Cache-Control', 'no-store, max-age=0');
    res.set('X-Backup-File-Count', String(archive.fileCount));
    res.set('X-Backup-Data-Bytes', String(archive.totalBytes));
    res.status(200).send(archive.buffer);
  } catch (error) {
    if (!res.headersSent) res.status(422).json({ ok: false, error: safeError(error) });
  } finally {
    if (hubPaused) integrationHub.resume();
    if (schedulerPaused) scheduler.resume();
    if (restartSessionsAfterExport.length) scheduleSavedSessionRestart(700, 'النسخ الاحتياطي', restartSessionsAfterExport);
    backupMaintenanceInProgress = false;
  }
});
app.post('/api/backup/restore', express.raw({ type: 'application/octet-stream', limit: localBackup.MAX_ARCHIVE_BYTES }), async (req, res) => {
  if (backupMaintenanceInProgress || backupSessionRestartPending) return res.status(409).json({ ok: false, error: 'هناك عملية نسخ أو تهيئة جلسات قيد التنفيذ.' });
  let bundle, restorePassword;
  try {
    const encodedPassword = String(req.get('x-backup-password-b64') || '');
    const decodedPassword = Buffer.from(encodedPassword, 'base64');
    if (!encodedPassword || decodedPassword.toString('base64') !== encodedPassword) throw new Error('بيانات كلمة مرور النسخة غير صالحة.');
    restorePassword = localBackup.validatePassword(decodedPassword.toString('utf8'));
    bundle = localBackup.decryptAndValidateBackup(req.body, restorePassword);
  }
  catch (error) { return res.status(400).json({ ok: false, error: safeError(error) }); }
  backupMaintenanceInProgress = true;
  let schedulerPaused = false, hubPaused = false, preRestoreBackupPath = '', restoredResult = null, priorActiveSessionIds = [];
  try {
    for (let i = 0; i < 200 && activeApiRequests > 0; i++) await new Promise(resolve => setTimeout(resolve, 50));
    if (activeApiRequests > 0) throw new Error('ما زالت هناك طلبات نشطة؛ لم تُستبدل البيانات. أعد المحاولة بعد هدوء النشاط.');
    await scheduler.pause(); schedulerPaused = true;
    await integrationHub.pause(); hubPaused = true;
    priorActiveSessionIds = currentlyActiveSessionIds();
    for (const id of store.listSessionIds()) await whatsapp.stop(id);
    // Keep an encrypted rollback snapshot of the current state, using the same password.
    const beforeRestore = localBackup.createEncryptedBackup(store.DATA_DIR, restorePassword, store.APP_VERSION);
    const rollbackDir = path.join(store.ROOT, '.runtime', 'pre-restore-backups');
    fs.mkdirSync(rollbackDir, { recursive: true, mode: 0o700 });
    preRestoreBackupPath = path.join(rollbackDir, `before-restore-${new Date().toISOString().replace(/[:.]/g, '-')}.cbotbackup`);
    fs.writeFileSync(preRestoreBackupPath, beforeRestore.buffer, { mode: 0o600, flag: 'wx' });
    const priorSnapshots = fs.readdirSync(rollbackDir).filter(name => /^before-restore-.*\.cbotbackup$/u.test(name)).sort().reverse();
    for (const stale of priorSnapshots.slice(3)) { try { fs.rmSync(path.join(rollbackDir, stale), { force: true }); } catch {} }
    restoredResult = localBackup.restoreValidatedBackup(store.DATA_DIR, bundle);
    // Drop in-memory snapshots after replacing the entire data directory.
    conversationArchive.sessions.clear();
    audioTranscriber.latestBySession?.clear?.();
    interaction.conversationHistory?.clear?.();
    interaction.seen?.clear?.();
    interaction.cool?.clear?.();
    interaction.fallbackCool?.clear?.();
    interaction.quietCool?.clear?.();
    fs.mkdirSync(TEMP, { recursive: true });
    const restoredIds = store.listSessionIds();
    log(null, 'WARN', `تمت استعادة نسخة محلية مشفرة تحتوي ${restoredResult.fileCount} ملفًا ضمن ${restoredIds.length} جلسة. أُوقفت جلسات WhatsApp لإعادة تهيئتها من الملفات المستعادة.`);
    res.set('Cache-Control', 'no-store');
    res.json({ ok: true, message: 'تمت الاستعادة. حُفظت نسخة مشفّرة من البيانات السابقة داخل .runtime/pre-restore-backups؛ استخدم كلمة المرور نفسها لفكها. ستُعاد تهيئة الجلسات المحفوظة تلقائيًا إذا كان التشغيل التلقائي مفعّلًا.', fileCount: restoredResult.fileCount, totalBytes: restoredResult.totalBytes, sessions: restoredIds.length, backupCreatedAt: restoredResult.createdAt, backupAppVersion: restoredResult.appVersion, preRestoreBackup: path.relative(store.ROOT, preRestoreBackupPath) });
    // Start every restored session so missing WhatsApp authentication triggers the QR/pairing flow.
    const restoreRestartIds = [...restoredIds];
    scheduleSavedSessionRestart(700, 'الاستعادة', restoreRestartIds);
  } catch (error) {
    if (!res.headersSent) {
      if (restoredResult) res.status(200).json({ ok: true, warning: safeError(error), message: 'اكتمل استبدال البيانات، لكن حدث تنبيه بعد الاستعادة. راجع السجل المحلي.', fileCount: restoredResult.fileCount, totalBytes: restoredResult.totalBytes, preRestoreBackup: path.relative(store.ROOT, preRestoreBackupPath) });
      else res.status(409).json({ ok: false, error: safeError(error) });
    }
    if (!restoredResult && priorActiveSessionIds.length) scheduleSavedSessionRestart(700, 'إلغاء الاستعادة', priorActiveSessionIds);
  } finally {
    if (hubPaused) integrationHub.resume();
    if (schedulerPaused) scheduler.resume();
    backupMaintenanceInProgress = false;
  }
});

// Integration Hub: local-first adapters, safe discovery, 320 auditable test scenarios,
// supported-only rule activation and an in-project activity inbox.
app.get('/api/integrations', (req, res) => { try { res.json(integrationHub.overview(sid(req))); } catch (e) { replyError(res, e, 500); } });
app.get('/api/integrations/health', (req, res) => { try { res.json(integrationHub.health(sid(req))); } catch (e) { replyError(res, e, 500); } });
app.get('/api/integrations/catalog', (_req, res) => res.json({ ok: true, count: require('./src/integration-hub').TEST_CATALOG.length, families: require('./src/integration-hub').FAMILIES, templates: require('./src/integration-hub').RULE_TEMPLATES }));
app.post('/api/integrations/devices/enroll', (req, res) => { try { res.status(201).json({ ok: true, ...integrationHub.createAgentEnrollment(sid(req), { name: req.body?.name }) }); } catch (e) { replyError(res, e, 422); } });
app.delete('/api/integrations/devices/:id', (req, res) => { try { res.json({ ok: true, device: integrationHub.removeDevice(sid(req), req.params.id) }); } catch (e) { replyError(res, e, 422); } });
app.post('/api/integrations/devices/:id/tasks', (req, res) => { try { res.status(202).json({ ok: true, task: integrationHub.createAgentTask(sid(req), req.params.id, req.body || {}) }); } catch (e) { replyError(res, e, 422); } });
app.post('/api/integrations/agents/claim', (req, res) => { try { const token=String(req.body?.token||''); if(token.length<32||token.length>100) throw new Error('رمز تسجيل الجهاز غير صالح.'); res.status(201).json({ ok: true, ...integrationHub.claimAgent(token, req.body || {}) }); } catch (e) { replyError(res, e, 401); } });
app.post('/api/integrations/agents/heartbeat', (req, res) => { try { if(!req.body?.sessionId||!req.body?.deviceId) throw new Error('بيانات الجهاز ناقصة.'); const token=String(req.get('x-integration-agent-token')||''); res.json({ ok: true, ...integrationHub.heartbeatAgent(sid(req), String(req.body.deviceId), token, req.body || {}) }); } catch (e) { replyError(res, e, 401); } });
app.post('/api/integrations/agents/tasks', (req, res) => { try { if(!req.body?.sessionId||!req.body?.deviceId) throw new Error('بيانات الجهاز ناقصة.'); const token=String(req.get('x-integration-agent-token')||''); res.json({ ok: true, ...integrationHub.takeAgentTasks(sid(req), String(req.body.deviceId), token) }); } catch (e) { replyError(res, e, 401); } });
app.post('/api/integrations/agents/result', (req, res) => { try { if(!req.body?.sessionId||!req.body?.deviceId||!req.body?.taskId) throw new Error('بيانات نتيجة المهمة ناقصة.'); const token=String(req.get('x-integration-agent-token')||''); res.json({ ok: true, task: integrationHub.completeAgentTask(sid(req), String(req.body.deviceId), token, String(req.body.taskId), req.body.result || {}) }); } catch (e) { replyError(res, e, 401); } });
app.post('/api/integrations/plugins', (req, res) => { try { res.status(201).json({ ok: true, plugin: integrationHub.registerPlugin(sid(req), req.body?.manifest || req.body) }); } catch (e) { replyError(res, e, 422); } });
app.delete('/api/integrations/plugins/:id', (req, res) => { try { integrationHub.deletePlugin(sid(req), req.params.id); res.json({ ok: true }); } catch (e) { replyError(res, e, 422); } });
app.post('/api/integrations/plugins/:id/connect', (req, res) => { try { const result=integrationHub.connectionFromPlugin(sid(req), req.params.id, req.body || {}); res.status(201).json({ ok: true, ...result, webhookPath: result.hookToken ? `/api/integrations/hooks/${result.hookToken}` : '' }); } catch (e) { replyError(res, e, 422); } });
app.post('/api/integrations/connections', (req, res) => { try { const result = integrationHub.createConnection(sid(req), req.body || {}); log(sid(req), 'INFO', `تم إنشاء تكامل محلي: ${result.connection.name} (${result.connection.type}).`); res.status(201).json({ ok: true, ...result, webhookPath: result.hookToken ? `/api/integrations/hooks/${result.hookToken}` : '' }); } catch (e) { replyError(res, e, 422); } });
app.put('/api/integrations/connections/:id', (req, res) => { try { res.json({ ok: true, connection: integrationHub.updateConnection(sid(req), req.params.id, req.body || {}) }); } catch (e) { replyError(res, e, 422); } });
app.put('/api/integrations/connections/:id/credentials', (req, res) => { try { res.json({ ok: true, ...integrationHub.updateCredentials(sid(req), req.params.id, req.body?.headers || {}) }); } catch (e) { replyError(res, e, 422); } });
app.delete('/api/integrations/connections/:id', (req, res) => { try { integrationHub.deleteConnection(sid(req), req.params.id); log(sid(req), 'INFO', `تم حذف تعريف التكامل ${req.params.id}. لم تُحذف ملفات الهدف. `); res.json({ ok: true }); } catch (e) { replyError(res, e, 422); } });
app.post('/api/integrations/connections/:id/discover', async (req, res) => { try { res.json({ ok: true, ...(await integrationHub.discover(sid(req), req.params.id)) }); } catch (e) { replyError(res, e, 422); } });
app.post('/api/integrations/connections/:id/test', async (req, res) => { try { const result = await integrationHub.runTests(sid(req), req.params.id); res.json({ ok: true, ...result }); } catch (e) { replyError(res, e, 422); } });
app.post('/api/integrations/connections/:id/rules/template', (req, res) => { try { const template = require('./src/integration-hub').RULE_TEMPLATES.find(x => x.id === String(req.body?.templateId || '')); if (!template) throw new Error('قالب القاعدة غير موجود.'); const overview = integrationHub.overview(sid(req)); const c = overview.connections.find(x => x.id === req.params.id); const t = c?.templates.find(x => x.id === template.id); if (!t?.supported) throw new Error(t?.reason || 'لا يمكن تفعيل القالب قبل اكتشاف القدرات.'); const rule = integrationHub.createRule(sid(req), { connectionId: req.params.id, name: template.name, description: template.description, action: template.action, requiredCapability: template.capability, templateId: template.id, triggerType: req.body?.triggerType || 'manual', everyMinutes: req.body?.everyMinutes || 15, enabled: false }); res.status(201).json({ ok: true, rule, message: 'أُضيف القالب كقاعدة متوقفة. راجع إعدادها ثم شغّلها بنفسك.' }); } catch (e) { replyError(res, e, 422); } });
app.post('/api/integrations/rules', (req, res) => { try { const rule = integrationHub.createRule(sid(req), req.body || {}); res.status(201).json({ ok: true, rule }); } catch (e) { replyError(res, e, 422); } });
app.post('/api/integrations/rules/:id/toggle', (req, res) => { try { const enabled = boolValue(req.body?.enabled, false); const rule = integrationHub.toggleRule(sid(req), req.params.id, enabled); res.json({ ok: true, rule }); } catch (e) { replyError(res, e, 422); } });
app.post('/api/integrations/rules/:id/run', async (req, res) => { try { const result = await integrationHub.runRule(sid(req), req.params.id, { source: 'manual' }); res.json({ ok: true, ...result }); } catch (e) { replyError(res, e, 422); } });
app.delete('/api/integrations/rules/:id', (req, res) => { try { const d = integrationHub.read(sid(req)); const before = d.rules.length; d.rules = d.rules.filter(r => r.id !== req.params.id); if (before === d.rules.length) throw new Error('القاعدة غير موجودة.'); integrationHub.write(sid(req), d); res.json({ ok: true }); } catch (e) { replyError(res, e, 422); } });
app.put('/api/integrations/settings', (req, res) => { try { res.json({ ok: true, settings: integrationHub.updateSettings(sid(req), req.body || {}) }); } catch (e) { replyError(res, e, 422); } });
app.post('/api/integrations/connections/:id/webhook-secret', (req, res) => { try { const d = integrationHub.read(sid(req)), c = d.connections.find(x => x.id === req.params.id); if (!c || c.type !== 'webhook') throw new Error('هذا الاتصال ليس من نوع Webhook.'); const token = crypto.randomBytes(32).toString('base64url'); c.webhookTokenHash = integrationHub.tokenHash(token); c.updatedAt = new Date().toISOString(); integrationHub.write(sid(req), d); res.json({ ok: true, webhookPath: `/api/integrations/hooks/${token}`, message: 'تم إنشاء رابط جديد وإبطال الرابط السابق. احتفظ بالرابط في مكان آمن.' }); } catch (e) { replyError(res, e, 422); } });
app.post('/api/integrations/hooks/:token', async (req, res) => { try { const bytes = Buffer.byteLength(JSON.stringify(req.body || {})); if (bytes > 512 * 1024) return res.status(413).json({ ok: false, error: 'محتوى Webhook أكبر من 512 كيلوبايت.' }); res.json({ ok: true, ...(await integrationHub.handleWebhook(req.params.token, req.body || {})) }); } catch (e) { replyError(res, e, 401); } });
app.get('/api/integrations/runs/:id', (req, res) => { try { res.json({ ok: true, run: integrationHub.report(sid(req), req.params.id) }); } catch (e) { replyError(res, e, 404); } });

app.get('/api/assistant/llm-status', async (_req, res) => { try { res.json({ ok: true, ...(await localLlm.status()) }); } catch (error) { res.json({ ok: true, available: false, models: [], message: String(error?.message || 'تعذر فحص الخدمة المحلية.') }); } });
app.get('/api/transcription/status', async (_req, res) => { try { res.json({ ok: true, ...(await audioTranscriber.status()), voiceSetup: getVoiceBootstrapStatus() }); } catch (error) { res.json({ ok: true, ready: false, voiceSetup: getVoiceBootstrapStatus(), message: String(error?.message || 'تعذر فحص محرك التفريغ.') }); } });

app.get('/api/tts/status', async (req, res) => {
  try {
    const status = await textToSpeech.status();
    const session = store.loadSession(sid(req));
    const proofreadRequired = session.settings.ttsRequireProofread === undefined
      ? !/^(?:0|false|no|off)$/i.test(String(process.env.TTS_REQUIRE_PROOFREAD || 'false'))
      : session.settings.ttsRequireProofread !== false;
    let llmStatus = { available: false, models: [] };
    try { llmStatus = await localLlm.status(); } catch {}
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, ...status, voiceSetup: getVoiceBootstrapStatus(), proofreaderRequired, proofreaderAvailable: Boolean(llmStatus.available && (llmStatus.models || []).some(name => String(name).split(':')[0] === String(session.settings.smartReplyModel || 'qwen2.5:3b').split(':')[0])), proofreaderModel: session.settings.smartReplyModel || 'qwen2.5:3b' });
  } catch (error) { res.json({ ok: true, ready: false, message: String(error?.message || 'تعذر فحص محرك النطق المحلي.') }); }
});

function withTimeoutPromise(promise, ms, label) {
  let timer;
  return Promise.race([Promise.resolve(promise), new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`انتهت مهلة ${label}.`)), ms); timer.unref?.(); })]).finally(() => clearTimeout(timer));
}
function validWhatsAppChatId(value) {
  return /^(?:\d{5,25}(?:-\d+)*@g\.us|\d{5,25}@c\.us|\d{5,25}@lid)$/i.test(String(value || '').trim());
}
function allowedConversationTarget(sessionId, targetKey) {
  const session = store.loadSession(sessionId);
  const target = conversationTargets.allowedTarget(session, targetKey, whatsapp.selfChatId(sessionId));
  if (!target) throw Object.assign(new Error('المحادثة غير موجودة ضمن الأشخاص أو المجموعات المسجلة في المشروع.'), { statusCode: 404 });
  return { session, target };
}
function archiveRecordFromMessage(message, chatId, targetKey, fromMe) {
  const body = String(message?.body ?? message?._data?.body ?? message?.caption ?? '').slice(0, 20000);
  const mimetype = String(message?._data?.mimetype || message?.mimetype || '').slice(0, 140);
  return {
    targetKey, chatId, messageId: message?.__chatBotArchiveId || message?.id?._serialized || message?.id?.$1 || message?._data?.id?._serialized || message?._data?.id?.$1 || message?.id?.id || message?.id || '',
    timestamp: message?.timestamp || message?._data?.t || Date.now(), fromMe: fromMe === true,
    body, caption: body, type: String(message?.type || (message?.hasMedia ? 'media' : 'chat')),
    hasMedia: message?.hasMedia === true || Boolean(mimetype), mimetype,
    filename: String(message?._data?.filename || message?.filename || ''),
    senderName: String(message?._data?.notifyName || message?._data?.pushName || message?.author || message?.sender?.pushname || ''),
    ack: Number.isFinite(Number(message?.ack)) ? Number(message.ack) : null,
  };
}
async function archiveWhatsAppMessage(sessionId, message, fromMeHint = null) {
  try {
    const id = store.safeSessionId(sessionId), session = store.loadSession(id);
    const fromMe = fromMeHint === null ? isFromMeMessage(message) : fromMeHint === true;
    let chatId = '';
    const candidates = fromMe
      ? [message?.chatId, message?.to, message?.id?.remote, message?._data?.id?.remote, message?._data?.to]
      : [message?.chatId, message?.from, message?.id?.remote, message?._data?.id?.remote, message?._data?.from];
    for (const value of candidates) {
      const candidate = conversationTargets.chatIdOf(value);
      if (validWhatsAppChatId(candidate)) { chatId = candidate; break; }
    }
    if (!chatId && typeof message?.getChat === 'function') {
      try { const chat = await withTimeoutPromise(message.getChat(), 8000, 'تحديد محادثة الرسالة'); const candidate = conversationTargets.chatIdOf(chat?.id); if (validWhatsAppChatId(candidate)) chatId = candidate; } catch {}
    }
    if (!chatId) return { stored: false, reason: 'unknown-chat' };
    const targetKey = conversationTargets.targetKeyForChat(session, chatId, whatsapp.selfChatId(id));
    // Privacy boundary: only self-chat plus contacts/groups explicitly stored in this session.
    if (!targetKey) return { stored: false, reason: 'not-registered' };
    return conversationArchive.record(id, archiveRecordFromMessage(message, chatId, targetKey, fromMe));
  } catch (error) {
    log(sessionId, 'WARN', `تعذر أرشفة رسالة محادثة: ${String(error?.message || error).slice(0, 180)}`);
    return { stored: false, reason: 'archive-error' };
  }
}

app.get('/api/conversations/targets', (req, res) => {
  try {
    const id = sid(req), session = store.loadSession(id), summary = new Map(conversationArchive.summary(id).map(row => [row.targetKey, row]));
    const targets = conversationTargets.listRegisteredTargets(session, whatsapp.selfChatId(id)).map(target => ({
      key: target.key, id: target.id, label: target.label, type: target.type, enabled: target.enabled !== false,
      hasChatId: Boolean(target.chatId), archivedCount: Number(summary.get(target.key)?.count || 0),
      mediaCount: Number(summary.get(target.key)?.mediaCount || 0), lastAt: summary.get(target.key)?.lastAt || '',
      lastText: summary.get(target.key)?.lastText || '',
    }));
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, sessionId: id, targets, totalArchived: targets.reduce((n, row) => n + row.archivedCount, 0), policy: 'يتم حفظ رسائل محادثة النفس والأشخاص والمجموعات المسجلة فقط، في ملفات محلية خاصة بالجلسة.' });
  } catch (error) { replyError(res, error, 422); }
});
app.get('/api/conversations/messages', (req, res) => {
  try {
    const id = sid(req), { target } = allowedConversationTarget(id, req.query?.targetKey);
    const result = conversationArchive.list(id, target.key, { limit: req.query?.limit, before: req.query?.before, query: req.query?.q || '' });
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, target: { key: target.key, label: target.label, type: target.type }, ...result });
  } catch (error) { replyError(res, error, Number(error?.statusCode) || 422); }
});
app.get('/api/conversations/search', (req, res) => {
  try {
    const id = sid(req), session = store.loadSession(id), query = String(req.query?.q || '').trim();
    if (!query) return res.status(422).json({ ok: false, error: 'اكتب كلمة أو عبارة للبحث.' });
    const allowed = new Map(conversationTargets.listRegisteredTargets(session, whatsapp.selfChatId(id)).map(target => [target.key, target]));
    const requestedKey = String(req.query?.targetKey || '').trim();
    if (requestedKey && !allowed.has(requestedKey)) throw Object.assign(new Error('المحادثة المطلوبة غير مسجلة في المشروع.'), { statusCode: 404 });
    const results = conversationArchive.search(id, query, { limit: req.query?.limit || 100, targetKey: requestedKey || null, targetKeys: requestedKey ? null : [...allowed.keys()] })
      .filter(row => allowed.has(row.targetKey))
      .map(row => ({ ...row, targetLabel: allowed.get(row.targetKey).label }));
    res.setHeader('Cache-Control', 'no-store'); res.json({ ok: true, query, targetKey: requestedKey || null, count: results.length, results });
  } catch (error) { replyError(res, error, Number(error?.statusCode) || 422); }
});
app.post('/api/conversations/import', async (req, res) => {
  try {
    const id = sid(req), { session, target } = allowedConversationTarget(id, req.body?.targetKey);
    if (!validWhatsAppChatId(target.chatId)) throw new Error('لا يوجد معرّف WhatsApp مؤكد لهذه الجهة. حدّث بياناتها من صفحة الأشخاص أو اتصل بـ WhatsApp أولًا.');
    const limit = Math.max(1, Math.min(20000, Number(req.body?.limit) || 1000));
    const chat = await whatsapp.getChatSafe(id, target.chatId);
    const actualChatId = conversationTargets.chatIdOf(chat?.id);
    if (!validWhatsAppChatId(actualChatId) || conversationTargets.targetKeyForChat(session, actualChatId, whatsapp.selfChatId(id)) !== target.key) {
      throw new Error('لم يطابق WhatsApp المحادثة المختارة بالجهة المسجلة؛ أوقف الاستيراد لحماية الخصوصية.');
    }
    if (typeof chat.fetchMessages !== 'function') throw new Error('نسخة WhatsApp الحالية لا تتيح استيراد سجل الرسائل.');
    const importTimeoutMs = Math.min(180000, 45000 + Math.ceil(limit / 1000) * 5000);
    const messages = await withTimeoutPromise(chat.fetchMessages({ limit }), importTimeoutMs, 'استيراد سجل المحادثة');
    const rows = (Array.isArray(messages) ? messages : []).map(message => archiveRecordFromMessage(message, actualChatId, target.key, isFromMeMessage(message)));
    const outcome = conversationArchive.recordMany(id, rows);
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, targetKey: target.key, targetLabel: target.label, fetched: rows.length, stored: outcome.stored, duplicates: outcome.duplicates, failed: outcome.failed, requestedLimit: limit, limitReached: rows.length >= limit, completeHistoryGuaranteed: false, message: `استورد WhatsApp ${rows.length} رسالة/عنصر من السجل الذي أتاحه للتطبيق. لم تتكرر ${outcome.duplicates} رسالة محفوظة من قبل. ${rows.length >= limit ? `وصلت إلى حد هذه العملية (${limit} رسالة)، وقد توجد رسائل أقدم.` : 'قد لا يتيح WhatsApp كل التاريخ رغم أن العدد أقل من الحد.'} جميع البيانات المحفوظة هنا محلية.` });
  } catch (error) { replyError(res, error, Number(error?.statusCode) || 422); }
});

app.post('/api/voice/parse', (req, res) => { try { const parsed = parseVoiceCommand(req.body?.transcript, { locale: req.body?.locale || 'ar', confidence: req.body?.confidence ?? 1, minConfidence: req.body?.minConfidence ?? .72 }); res.json({ ok: true, parsed, message: parsed.requiresConfirmation ? 'يتطلب هذا الأمر تأكيدًا صريحًا قبل التنفيذ.' : undefined }); } catch (e) { replyError(res, e, 422); } });
app.post('/api/assistant/local', async (req, res) => {
  try {
    const id = sid(req), result = localAssistantResponse(id, req.body?.prompt), settings = store.loadSession(id).settings || {};
    if (result.fallback && settings.smartReplyEnabled === true) {
      const model = String(settings.smartReplyModel || 'qwen2.5:3b');
      const status = await localLlm.status();
      if (!status.available || !modelInstalled(status, model)) {
        result.llmWarning = !status.available ? status.message : `النموذج «${model}» غير مثبت محليًا.`;
        result.reply = `الرد الذكي غير جاهز رغم حفظ الإعداد: ${result.llmWarning} لم أرسل رسالتك إلى خدمة سحابية ولم أنفّذ أي إجراء.`;
        result.source = 'local-diagnostic';
      } else {
        try {
          const suppliedMessages = Array.isArray(req.body?.messages) ? req.body.messages : [];
          const conversationMessages = suppliedMessages.slice(-10).map(item => ({
            role: item?.role === 'assistant' ? 'assistant' : 'user',
            content: String(item?.content || '').slice(0, 1000),
          })).filter(item => item.content);
          if (!conversationMessages.length || conversationMessages[conversationMessages.length - 1]?.content !== String(req.body?.prompt || '').slice(0, 1000)) {
            conversationMessages.push({ role: 'user', content: String(req.body?.prompt || '').slice(0, 1000) });
          }
          result.reply = await localLlm.generate({ model, system: conversationSystemPrompt(settings.smartReplySystemPrompt), messages: conversationMessages.slice(-10), timeoutMs: settings.smartReplyTimeoutMs || 12000, maxTokens: 260 });
          result.source = 'ollama-local'; delete result.fallback;
        } catch (error) {
          result.llmWarning = `تعذر النموذج المحلي: ${String(error?.message || error).slice(0, 180)}`;
          result.reply = `تعذر الرد عبر Ollama: ${result.llmWarning} لم يُنفذ أي إجراء.`;
          result.source = 'local-diagnostic';
        }
      }
    }
    res.json({ ok: true, ...result, source: result.source || 'local-rules' });
  } catch (e) { replyError(res, e, 422); }
});
app.get('/api/dictionary/lookup', (req, res) => { const entry = dictionaryEngine.lookup(req.query?.q); res.json({ ok: true, entry }); });
app.get('/api/dictionary', (req, res) => res.json({ ok: true, entries: dictionaryEngine.list({ query: req.query?.q || '', limit: Number(req.query?.limit) || 100, offset: Number(req.query?.offset) || 0 }) }));
app.get('/api/state', (req, res) => { try { res.json({ ok: true, ...snapshot(sid(req)) }); } catch (e) { replyError(res, e, 500); } });
app.get('/api/countries', (_req, res) => { try { res.json({ ok: true, countries: phones.countries() }); } catch (e) { replyError(res, e, 500); } });
app.post('/api/phone/validate', (req, res) => { try { const country = String(req.body?.country || 'OM').toUpperCase(); const phone = phones.parse(req.body?.phone || '', country); res.json({ ok: true, valid: true, phone }); } catch (e) { res.status(422).json({ ok: false, valid: false, error: safeError(e) }); } });
app.get('/api/whatsapp/contacts', async (req, res) => {
  try {
    const id = sid(req), contacts = await whatsapp.listContacts(id, { limit: 2000, includeProfilePictures: false });
    const localPicture = item => `/api/whatsapp/contact-picture?sessionId=${encodeURIComponent(id)}&jid=${encodeURIComponent(item.jid)}`;
    const safeContacts = contacts.map(({ profilePicUrl, ...item }) => ({ ...item,
      pictureUrl: whatsappContacts.isAllowedProfileUrl(profilePicUrl) ? profilePicUrl : localPicture(item),
      pictureFallbackUrl: localPicture(item), profileSynced: Boolean(whatsappContacts.isAllowedProfileUrl(profilePicUrl)),
    }));
    res.setHeader('Cache-Control', 'no-store');
    // Start a bounded local avatar-cache warm-up after returning the contact list.
    // The list is usable immediately; selected people are still explicitly imported,
    // while existing recipients get their photos/metadata refreshed in the background.
    const photoRows = contacts.slice(0, 100);
    const profileUrls = Object.fromEntries(photoRows.filter(item => whatsappContacts.isAllowedProfileUrl(item.profilePicUrl)).map(item => [item.jid, item.profilePicUrl]));
    setImmediate(() => whatsappContacts.refreshContactPictures({ store, whatsapp, sessionId: id, jids: photoRows.map(item => item.jid), profileUrls })
      .then(result => log(id, 'DEBUG', `تهيئة صور قائمة جهات WhatsApp: مخزّن محليًا ${result.photosCached || result.photosUpdated}، رابط آمن احتياطي ${result.photosRemoteFallback || 0}، غير متاحة ${result.photosFailed}.`))
      .catch(error => log(id, 'DEBUG', `تأجل تحديث صور قائمة جهات WhatsApp: ${safeError(error)}`)));
    res.json({ ok: true, sessionId: id, count: contacts.length, contacts: safeContacts,
      message: `تم استدعاء ${contacts.length} جهة وعرضها فورًا. يجري تجهيز صور أول ${photoRows.length} جهة في الخلفية من دون انتظار الشبكة. لا تتم إضافة بقية جهات WhatsApp إلى قائمة الإرسال تلقائيًا؛ أضف الأشخاص الذين تريدهم.` });
  } catch (e) { replyError(res, e, 422); }
});
app.get('/api/whatsapp/contact-picture', async (req, res) => {
  const id = sid(req), jid = String(req.query?.jid || '').trim().toLowerCase();
  if (!/^\d{5,25}@c\.us$/.test(jid)) return res.status(400).end();
  try {
    const picture = await whatsappContacts.ensureContactPicture({ store, whatsapp, sessionId: id, jid, refresh: req.query?.refresh === '1' });
    if (!picture?.filename) {
      // v8.6 rendered verified WhatsApp CDN avatars directly. Retain that
      // compatibility as a safe fallback when the local cache cannot decode a
      // genuine photo; never redirect to arbitrary hosts or caller-supplied URLs.
      if (picture?.remoteUrl && whatsappContacts.isAllowedProfileUrl(picture.remoteUrl)) {
        res.setHeader('Cache-Control', 'private, max-age=60');
        res.setHeader('Referrer-Policy', 'no-referrer');
        return res.redirect(302, picture.remoteUrl);
      }
      res.setHeader('Cache-Control', 'no-store'); res.setHeader('X-Chat-BOT-Photo', 'unavailable-or-private'); return res.status(404).end();
    }
    const file = media.safePath(store.getPaths(id).profiles, picture.filename);
    if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return res.status(404).end();
    res.setHeader('Cache-Control', 'private, max-age=3600');
    res.type(path.extname(file));
    res.sendFile(file, error => { if (error && !res.headersSent) res.status(404).end(); });
  } catch (e) {
    log(id, 'DEBUG', `صورة جهة WhatsApp غير متاحة (${jid}): ${safeError(e)}`);
    res.setHeader('Cache-Control', 'no-store');
    res.status(404).end();
  }
});
app.post('/api/whatsapp/contact/import', async (req, res) => {
  try {
    const id = sid(req), jid = String(req.body?.jid || '').trim().toLowerCase();
    if (!/^\d{5,25}@c\.us$/.test(jid)) throw new Error('معرّف جهة WhatsApp غير صالح. استدعِ القائمة واختر جهة ظاهرة فيها.');
    const result = await whatsappContacts.syncContacts({ store, whatsapp, phones, sessionId: id, jids: [jid], importMissing: true, updateNames: false, updatePictures: false });
    const ids = [...new Set([...(result.imported || []), ...(result.updated || [])].map(person => String(person.id || '')).filter(Boolean))];
    log(id, 'INFO', `إضافة جهة من قائمة WhatsApp: ${result.imported.length} جديدة، ${result.updated.length} موجودة؛ ستُحمّل الصورة عند عرضها.`);
    res.json({ ok: true, ...result, addedToSendList: ids, photoLoading: 'lazy' });
    setImmediate(() => whatsappContacts.refreshContactPictures({ store, whatsapp, sessionId: id, jids: [jid] })
      .then(photoResult => log(id, 'DEBUG', `اكتمل تحديث صورة جهة WhatsApp: ${photoResult.photosUpdated} محفوظة، ${photoResult.photosFailed} غير متاحة.`))
      .catch(error => log(id, 'WARN', `تعذر تحديث صورة جهة WhatsApp: ${safeError(error)}`)));
  } catch (e) { replyError(res, e, 422); }
});
app.post('/api/whatsapp/contacts/sync', async (req, res) => {
  try {
    const id = sid(req), jids = uniqueStrings(req.body?.jids).slice(0, 500);
    const updatePictures = boolValue(req.body?.updatePictures, false);
    if (!jids.length) throw new Error('حدد جهات WhatsApp للمزامنة أولًا.');
    if (updatePictures && jids.length > 100) throw new Error('مزامنة الصور محدودة بـ 100 جهة في المرة الواحدة؛ قسّم الاختيارات إلى دفعات.');
    // Persist names/recipients first. Profile/CDN lookups must not delay adding
    // selected contacts to the project or the send list; photos hydrate separately.
    const result = await whatsappContacts.syncContacts({ store, whatsapp, phones, sessionId: id, jids, importMissing: boolValue(req.body?.importMissing, true), updateNames: boolValue(req.body?.updateNames, false), updatePictures: false });
    log(id, 'INFO', `مزامنة جهات WhatsApp: جديد ${result.imported.length}، حدّث ${result.updated.length}؛ أُحفظت الجهات قبل تحديث الصور.`);
    if (updatePictures) {
      setImmediate(() => whatsappContacts.refreshContactPictures({ store, whatsapp, sessionId: id, jids })
        .then(photoResult => log(id, 'INFO', `انتهى تحديث صور الجهات: ${photoResult.photosUpdated} محفوظة، ${photoResult.photosFailed} غير متاحة.`))
        .catch(error => log(id, 'WARN', `تعذر إكمال تحديث صور الجهات: ${safeError(error)}`)));
    }
    const message = `${result.message}${updatePictures ? ' يجري تحديث الصور في الخلفية؛ إضافة الأشخاص إلى المشروع وقائمة الإرسال لا تنتظر اكتمال الصور.' : ' تُحمّل الصور المتاحة عند عرضها.'}`;
    res.json({ ok: true, ...result, message, photoLoading: updatePictures ? 'background' : 'lazy' });
  } catch (e) { replyError(res, e, 422); }
});

app.get('/api/diagnostics', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), p = store.getPaths(id), scan = media.scan(p.media, s.settings.maxImageSizeMB), runtime = whatsapp.listRuntime(id);
    res.json({ ok: true, version: store.APP_VERSION, checks: {
      session: true, mediaFolder: fs.existsSync(p.media), authFolder: fs.existsSync(p.auth), mediaCount: scan.files.length,
      groups: s.groups.length, recipients: s.recipients.length, interactionRules: s.interaction.rules.length, whatsapp: !!runtime.ready,
      scheduleTargets: validTargetKeys(s, s.settings.scheduleTargetKeys).length, compatPatched: true,
    }, runtime, dependency: 'whatsapp-web.js 1.34.7' });
  } catch (e) { replyError(res, e, 500); }
});

const upload = multer({ dest: TEMP, limits: { files: 100, fileSize: 250 * 1024 * 1024 } });
const audioUpload = multer({ dest: TEMP, limits: { files: 1, fileSize: 25 * 1024 * 1024 }, fileFilter: (_req, file, callback) => { const ext = path.extname(file.originalname || '').toLowerCase(); if (require('./src/audio-transcriber').AUDIO_EXTENSIONS.has(ext) || /^audio\//i.test(String(file.mimetype || ''))) return callback(null, true); callback(new Error('الملف المحدد لا يبدو ملفًا صوتيًا مدعومًا.')); } });
const bgUpload = multer({ dest: TEMP, limits: { fileSize: 15 * 1024 * 1024, files: 1 } });
const avatarUpload = multer({ dest: TEMP, limits: { fileSize: 5 * 1024 * 1024, files: 1 }, fileFilter: (_req, file, callback) => { const mime = String(file.mimetype || '').toLowerCase(); if (!mime || /^image\//.test(mime) || mime === 'application/octet-stream') return callback(null, true); callback(new Error('اختر ملف صورة؛ سيتم التحقق من محتواه قبل حفظه.')); } });

app.post('/api/sessions', (req, res) => { try { const s = store.createSession(req.body?.name); res.json({ ok: true, session: { id: s.id, name: s.name } }); } catch (e) { replyError(res, e); } });
app.post('/api/sessions/switch', async (req, res) => {
  try {
    const target = store.safeSessionId(req.body?.sessionId);
    if (!store.listSessionIds().includes(target)) throw new Error('الجلسة غير موجودة.');
    const s = store.setActiveSession(target);
    if (s.settings.autoStartSession && whatsapp.hasSavedAuth(target) && !whatsapp.listRuntime(target).ready) whatsapp.start(target).catch(err => log(target, 'WARN', `تعذر تشغيل الجلسة عند التبديل: ${safeError(err)}`));
    res.json({ ok: true, session: s.id });
  } catch (e) { replyError(res, e); }
});
app.put('/api/sessions/:id', (req, res) => { try { res.json({ ok: true, session: store.renameSession(req.params.id, req.body?.name) }); } catch (e) { replyError(res, e); } });
app.delete('/api/sessions/:id', async (req, res) => { try { await whatsapp.stop(req.params.id, { clearAuth: true }); res.json({ ok: true, ...store.deleteSession(req.params.id) }); } catch (e) { replyError(res, e); } });

app.get('/api/session/status', (req, res) => {
  try {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.set('Pragma', 'no-cache');
    res.json({ ok: true, runtime: whatsapp.listRuntime(sid(req)) });
  } catch (e) { replyError(res, e, 500); }
});
app.post('/api/session/connect', async (req, res) => {
  try {
    const method = ['auto', 'qr', 'phone'].includes(String(req.body?.method || 'auto').trim().toLowerCase()) ? String(req.body?.method || 'auto').trim().toLowerCase() : 'auto';
    const runtime = await whatsapp.start(sid(req), { method, phoneNumber: req.body?.phoneNumber });
    // Browser initialization and real pairing events are asynchronous; UI polling receives
    // the actual QR/code/ready state without blocking this request.
    const message = runtime.ready ? 'الجلسة جاهزة.' : runtime.status === 'pairing_code' ? 'وصل رمز الربط الحقيقي من WhatsApp. أدخله في الهاتف لإكمال الربط.' : runtime.status === 'qr' && runtime.qr ? 'تم تجهيز رمز QR الحقيقي من WhatsApp.' : method === 'phone' ? 'بدأ طلب رمز ربط الهاتف. سيظهر هنا عند وصوله من WhatsApp Web.' : 'بدأ الاتصال في الخلفية؛ ستظهر حالة QR تلقائيًا عند صدورها من WhatsApp.';
    res.status(202).set('Cache-Control', 'no-store').json({ ok: true, runtime, message });
  } catch (e) { replyError(res, e); }
});
app.post('/api/session/stop', async (req, res) => { try { await whatsapp.stop(sid(req)); res.json({ ok: true }); } catch (e) { replyError(res, e); } });
app.post('/api/session/unlink', async (req, res) => { try { await whatsapp.stop(sid(req), { clearAuth: true }); res.json({ ok: true }); } catch (e) { replyError(res, e); } });

app.post('/api/recipient', (req, res) => {
  try {
    const s = store.loadSession(sid(req));
    const parsed = phones.parse(req.body?.phone, String(req.body?.country || 'OM'));
    const name = String(req.body?.name || '').trim();
    if (!name) throw new Error('اكتب اسم المستلم.');
    if (s.recipients.some(x => x.phone === parsed.digits || x.e164 === parsed.e164)) throw new Error('الرقم مكرر في الجلسة.');
    const recipient = { id: randomId(), name: name.slice(0, 80), ...parsed, enabled: true };
    s.recipients.push(recipient); s.setupComplete = true;
    store.saveSession(s); res.json({ ok: true, recipient });
  } catch (e) { replyError(res, e); }
});
app.post('/api/recipients/bulk', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), parsed = phones.parseMany(req.body?.lines, String(req.body?.country || 'OM'));
    const added = [];
    for (const item of parsed.out) {
      if (s.recipients.some(x => x.phone === item.digits || x.e164 === item.e164)) continue;
      const { name, ...number } = item;
      added.push({ id: randomId(), name, ...number, enabled: true });
    }
    s.recipients.push(...added); if (added.length) s.setupComplete = true; store.saveSession(s);
    res.json({ ok: true, added, failed: parsed.failed, skippedDuplicates: parsed.out.length - added.length });
  } catch (e) { replyError(res, e); }
});
function removeRecipientAvatarFile(sessionId, filename) {
  const safe = recipientAvatars.safeAvatarFilename(filename);
  if (!safe) return;
  try { fs.rmSync(media.safePath(store.getPaths(sessionId).avatars, safe), { force: true }); } catch {}
}

app.get('/api/recipient/:id/avatar', (req, res) => {
  try {
    const id = sid(req), person = store.loadSession(id).recipients.find(item => item.id === req.params.id);
    if (!person) return res.status(404).end();
    const name = recipientAvatars.safeAvatarFilename(person.localAvatarFile);
    if (!name) return res.status(404).end();
    const file = media.safePath(store.getPaths(id).avatars, name);
    if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return res.status(404).end();
    res.setHeader('Cache-Control', 'private, max-age=300');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.type(path.extname(name));
    res.sendFile(file, error => { if (error && !res.headersSent) res.status(404).end(); });
  } catch { res.status(404).end(); }
});

app.get('/api/recipient/:id/whatsapp-avatar', async (req, res) => {
  const id = sid(req);
  try {
    const session = store.loadSession(id), person = session.recipients.find(item => item.id === req.params.id);
    if (!person) return res.status(404).end();
    const legacyFile = recipientAvatars.safeAvatarFilename(person.whatsappAvatarFile);
    if (legacyFile) {
      const cached = media.safePath(store.getPaths(id).avatars, legacyFile);
      if (fs.existsSync(cached) && fs.statSync(cached).isFile()) {
        res.setHeader('Cache-Control', 'private, max-age=1800'); res.setHeader('X-Content-Type-Options', 'nosniff'); res.type(path.extname(legacyFile));
        return res.sendFile(cached, error => { if (error && !res.headersSent) res.status(404).end(); });
      }
    }
    const jid = recipientAvatars.recipientJid(person);
    if (jid && whatsapp.listRuntime(id).ready) {
      try {
        const picture = await whatsappContacts.ensureContactPicture({ store, whatsapp, sessionId: id, jid, refresh: req.query?.refresh === '1' });
        if (picture?.filename && recipientAvatars.safeProfileFilename(picture.filename)) {
          const profileFile = media.safePath(store.getPaths(id).profiles, picture.filename);
          if (fs.existsSync(profileFile) && fs.statSync(profileFile).isFile()) {
            const fresh = store.loadSession(id), updated = fresh.recipients.find(item => item.id === person.id);
            if (updated) { updated.whatsappJid = jid; updated.whatsappProfilePhoto = picture.filename; updated.profileCheckedAt = new Date().toISOString(); updated.profileError = ''; store.saveSession(fresh); }
            res.setHeader('Cache-Control', 'private, max-age=1800'); res.setHeader('X-Content-Type-Options', 'nosniff'); res.type(path.extname(profileFile));
            return res.sendFile(profileFile, error => { if (error && !res.headersSent) res.status(404).end(); });
          }
        }
        if (picture?.remoteUrl && whatsappContacts.isAllowedProfileUrl(picture.remoteUrl)) {
          res.setHeader('Cache-Control', 'private, max-age=60'); res.setHeader('Referrer-Policy', 'no-referrer');
          return res.redirect(302, picture.remoteUrl);
        }
      } catch (error) { log(id, 'DEBUG', `تعذر جلب صورة المستلم ${person.id}: ${safeError(error)}`); }
    }
    const legacyRemote = whatsappContacts.isAllowedProfileUrl(person.whatsappAvatarUrl) ? person.whatsappAvatarUrl : '';
    if (legacyRemote) { res.setHeader('Cache-Control', 'private, max-age=60'); res.setHeader('Referrer-Policy', 'no-referrer'); return res.redirect(302, legacyRemote); }
    res.setHeader('Cache-Control', 'no-store'); res.setHeader('X-Chat-BOT-Photo', jid ? 'not-available-or-private' : 'no-verified-number');
    return res.status(404).end();
  } catch (error) { log(id, 'DEBUG', `تعذر عرض صورة WhatsApp: ${safeError(error)}`); res.setHeader('Cache-Control', 'no-store'); return res.status(404).end(); }
});

app.post('/api/recipient/:id/avatar', avatarUpload.single('file'), (req, res) => {
  let temp = req.file?.path || '';
  try {
    const id = sid(req), session = store.loadSession(id), person = session.recipients.find(item => item.id === req.params.id);
    if (!person) throw new Error('المستلم غير موجود.');
    if (!req.file) throw new Error('اختر صورة أولًا.');
    const bytes = fs.readFileSync(temp), ext = recipientAvatars.imageExtensionFromBuffer(bytes);
    if (!ext) throw new Error('محتوى الملف ليس صورة سليمة أو أن صيغته غير مدعومة.');
    if (!bytes.length || bytes.length > 5 * 1024 * 1024) throw new Error('حجم الصورة يجب ألا يتجاوز 5 ميجابايت.');
    const filename = `recipient-${crypto.randomUUID()}${ext}`;
    const target = media.safePath(store.getPaths(id).avatars, filename);
    fs.renameSync(temp, target); temp = '';
    const previous = person.localAvatarFile;
    person.localAvatarFile = filename; store.saveSession(session);
    if (previous && previous !== filename) removeRecipientAvatarFile(id, previous);
    res.json({ ok: true, avatarUrl: `/api/recipient/${encodeURIComponent(person.id)}/avatar?sessionId=${encodeURIComponent(id)}&v=${Date.now()}` });
  } catch (error) { if (temp) { try { fs.rmSync(temp, { force: true }); } catch {} } replyError(res, error, 422); }
});

app.delete('/api/recipient/:id/avatar', (req, res) => {
  try {
    const id = sid(req), session = store.loadSession(id), person = session.recipients.find(item => item.id === req.params.id);
    if (!person) throw new Error('المستلم غير موجود.');
    removeRecipientAvatarFile(id, person.localAvatarFile); person.localAvatarFile = ''; store.saveSession(session);
    res.json({ ok: true, message: 'تمت إزالة الصورة المحلية؛ ستظهر صورة WhatsApp إن كانت متاحة.' });
  } catch (error) { replyError(res, error, 422); }
});

app.post('/api/recipient/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), r = s.recipients.find(x => x.id === req.params.id); if (!r) throw new Error('المستلم غير موجود.'); r.enabled = !r.enabled; store.saveSession(s); res.json({ ok: true, enabled: r.enabled }); } catch (e) { replyError(res, e); } });
app.get('/api/recipient/:id/reply-profile', (req, res) => { try { const s = store.loadSession(sid(req)), r = s.recipients.find(x => x.id === req.params.id); if (!r) throw new Error('المستلم غير موجود.'); res.json({ ok: true, profile: recipientReplies.normalizeReplyProfile(r.replyProfile) }); } catch (e) { replyError(res, e); } });
app.put('/api/recipient/:id/reply-profile', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), r = s.recipients.find(x => x.id === req.params.id);
    if (!r) throw new Error('المستلم غير موجود.');
    r.replyProfile = recipientReplies.validateReplyProfile(req.body?.profile);
    store.saveSession(s);
    res.json({ ok: true, profile: r.replyProfile, message: 'تم حفظ إعداد الرد الخاص بالشخص.' });
  } catch (e) { replyError(res, e, 422); }
});
app.delete('/api/recipients/bulk', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), result = recipientManagement.deleteRecipients(s, req.body?.ids);
    store.saveSession(s);
    log(s.id, 'INFO', `حذف جماعي: تم حذف ${result.deleted.length} شخصًا وتنظيف الأهداف المرتبطة.${result.scheduleDisabledToPreventWidening ? ' تم إيقاف الجدولة لأن جميع أهدافها المحددة حُذفت.' : ''}`);
    res.json({ ok: true, ...result, message: `تم حذف ${result.deleted.length} شخصًا وتنظيف الأهداف المرتبطة بالجدولة والأتمتة.${result.scheduleDisabledToPreventWidening ? ' أوقفت الجدولة تلقائيًا لأن أهدافها المحددة حُذفت، لتجنب توسيعها وإرسالها لجهات أخرى.' : ''}` });
  } catch (e) { replyError(res, e, 422); }
});
app.delete('/api/recipient/:id', (req, res) => {
  try { const s = store.loadSession(sid(req)), key = `r:${req.params.id}`, removed = s.recipients.find(x => x.id === req.params.id), before = s.recipients.length; s.recipients = s.recipients.filter(x => x.id !== req.params.id); if (before === s.recipients.length) throw new Error('المستلم غير موجود.'); removeRecipientAvatarFile(s.id, removed?.localAvatarFile); removeRecipientAvatarFile(s.id, removed?.whatsappAvatarFile); removeTargetFromSchedule(s, key); s.automation.tasks = (s.automation.tasks || []).map(t => ({ ...t, targetKeys: (t.targetKeys || []).filter(k => k !== key) })); store.saveSession(s); res.json({ ok: true }); }
  catch (e) { replyError(res, e); }
});

app.post('/api/groups/discover', async (req, res) => { try { const id = sid(req), found = await whatsapp.listGroups(id), saved = found.filter(x => x.gid).map(x => saveGroup(id, x)); res.json({ ok: true, found: found.length, saved, message: `تم اكتشاف ${saved.length} مجموعة في هذه الجلسة.` }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/refresh-all', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), saved = [], failed = [];
    for (const g of s.groups) { try { saved.push(saveGroup(id, await whatsapp.getGroupInfo(id, g.gid))); } catch (e) { failed.push({ id: g.id, name: g.name, error: safeError(e) }); } }
    res.json({ ok: true, saved, failed, message: failed.length ? `تم تحديث ${saved.length} مجموعة، وتعذر تحديث ${failed.length}.` : 'تم تحديث المجموعات.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/groups/add-gid', async (req, res) => { try { const id = sid(req), gid = groups.normalizeGid(req.body?.gid); if (!groups.isGroupId(gid)) throw new Error('GID المجموعة غير صالح.'); const info = await whatsapp.getGroupInfo(id, gid); res.json({ ok: true, group: saveGroup(id, info), message: 'تمت إضافة المجموعة إلى هذه الجلسة.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/connect', async (req, res) => {
  try {
    const id = sid(req), value = String(req.body?.value || '').trim();
    if (!value) throw new Error('أدخل GID أو رابط دعوة.');
    let info;
    if (/chat\.whatsapp\.com\//i.test(value)) {
      info = await whatsapp.analyzeGroupInvite(id, groups.extractInviteCode(value));
      if (info?.gid) { try { info = await whatsapp.getGroupInfo(id, groups.normalizeGid(info.gid)); } catch {} }
    } else {
      info = await whatsapp.getGroupInfo(id, groups.normalizeGid(value));
    }
    if (!info?.gid) throw new Error('لم أستطع الحصول على GID للمجموعة من WhatsApp.');
    const group = saveGroup(id, info);
    res.json({ ok: true, group, message: 'تم الربط والتحليل داخل الجلسة الحالية.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/groups/save', (req, res) => { try { const id = sid(req), g = req.body?.group || {}; if (!groups.isGroupId(g.gid)) throw new Error('GID المجموعة غير صالح.'); res.json({ ok: true, group: saveGroup(id, g), message: 'تم حفظ المجموعة داخل الجلسة الحالية.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/add-invite', async (req, res) => {
  try {
    const id = sid(req), code = groups.extractInviteCode(req.body?.url || req.body?.code), info = await whatsapp.analyzeGroupInvite(id, code);
    if (!info.gid) throw new Error('تم تحليل الدعوة لكن WhatsApp لم يعطِ GID لهذه المجموعة؛ افتح المجموعة أو استخدم الاكتشاف من الجلسة ثم أضفها.');
    res.json({ ok: true, group: saveGroup(id, info), message: 'تمت إضافة المجموعة إلى هذه الجلسة.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/groups/analyze-gid', async (req, res) => { try { const id=sid(req), info=await whatsapp.getGroupInfo(id, groups.normalizeGid(req.body?.gid)); res.json({ ok:true, group:saveGroup(id, info), message:'تم تحديث بيانات المجموعة داخل الجلسة.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/analyze-invite', async (req, res) => { try { const id=sid(req), info=await whatsapp.analyzeGroupInvite(id, groups.extractInviteCode(req.body?.url || req.body?.code)); res.json({ ok:true, group: info?.gid ? saveGroup(id, info) : info, message: info?.gid ? 'تم تحديث بيانات المجموعة.' : 'تم تحليل الدعوة؛ لم يوفر WhatsApp GID.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), g = s.groups.find(x => x.id === req.params.id); if (!g) throw new Error('المجموعة غير موجودة.'); g.enabled = !g.enabled; store.saveSession(s); res.json({ ok: true, enabled: g.enabled }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/:id/refresh', async (req, res) => { try { const id = sid(req), s = store.loadSession(id), g = s.groups.find(x => x.id === req.params.id); if (!g) throw new Error('المجموعة غير موجودة.'); res.json({ ok: true, group: saveGroup(id, await whatsapp.getGroupInfo(id, g.gid)) }); } catch (e) { replyError(res, e); } });
app.delete('/api/groups/:id', (req, res) => {
  try { const s = store.loadSession(sid(req)), key = `g:${req.params.id}`, removed = s.groups.find(x => x.id === req.params.id); if (!removed) throw new Error('المجموعة غير موجودة.'); s.groups = s.groups.filter(x => x.id !== req.params.id); removeTargetFromSchedule(s, key); const removedGid = String(removed.gid || '').toLowerCase(); s.settings.interactionChatIds = (s.settings.interactionChatIds || []).filter(x => String(x).toLowerCase() !== removedGid); s.automation.tasks = (s.automation.tasks || []).map(t => ({ ...t, targetKeys: (t.targetKeys || []).filter(k => k !== key) })).filter(t => (t.targetKeys || []).length || (t.preText || t.postText || (t.mediaIds || []).length)); store.saveSession(s); res.json({ ok: true }); }
  catch (e) { replyError(res, e); }
});

app.post('/api/transcription/transcribe-latest', async (req, res) => {
  try { const result = await audioTranscriber.transcribeLatest(sid(req), { language: req.body?.language || 'ar' }); res.json(result); }
  catch (error) { res.status(422).json({ ok: false, error: String(error?.message || 'تعذر تفريغ الصوتية.') }); }
});
app.post('/api/transcription/upload', audioUpload.single('file'), async (req, res) => {
  try {
    if (!req.file) throw new Error('اختر ملفًا صوتيًا أولًا.');
    const result = await audioTranscriber.transcribeFile(req.file.path, { originalName: req.file.originalname, mimetype: req.file.mimetype, language: req.body?.language || 'ar' });
    res.json(result);
  } catch (error) { res.status(422).json({ ok: false, error: String(error?.message || 'تعذر تفريغ الملف الصوتي.') }); }
  finally { try { if (req.file?.path) fs.rmSync(req.file.path, { force: true }); } catch {} }
});

app.post('/api/media', upload.array('files', 100), (req, res) => {
  try {
    const id = sid(req), dir = store.getPaths(id).media, saved = [], duplicates = [], rejected = [];
    const replaceDuplicates = boolValue(req.body?.replaceDuplicates, false);
    const existing = new Map();
    for (const entry of media.scan(dir, store.loadSession(id).settings.maxImageSizeMB).files) {
      try { existing.set(`${entry.size}:${media.hashFile(media.safePath(dir, entry.filename))}`, entry.filename); } catch {}
    }
    for (const file of req.files || []) {
      const ext = path.extname(file.originalname || '').toLowerCase();
      if (!media.MEDIA_EXT.has(ext)) { rejected.push({ filename: file.originalname, error: 'نوع غير مدعوم' }); fs.rmSync(file.path, { force: true }); continue; }
      const hash = media.hashFile(file.path);
      const duplicateName = existing.get(`${fs.statSync(file.path).size}:${hash}`);
      if (duplicateName && !replaceDuplicates) {
        duplicates.push({ incoming: file.originalname, existing: duplicateName }); fs.rmSync(file.path, { force: true }); continue;
      }
      if (duplicateName && replaceDuplicates) {
        fs.renameSync(file.path, media.safePath(dir, duplicateName)); saved.push(duplicateName); continue;
      }
      const name = media.IMAGE_EXT.has(ext) ? media.nextImageName(dir, ext) : media.uniqueFileName(dir, path.basename(file.originalname, path.extname(file.originalname)), ext);
      fs.renameSync(file.path, media.safePath(dir, name));
      existing.set(`${fs.statSync(media.safePath(dir, name)).size}:${media.hashFile(media.safePath(dir, name))}`, name);
      saved.push(name);
    }
    res.json({ ok: true, saved, duplicates, rejected, message: duplicates.length ? `تم رفع ${saved.length} ملف، ووجدت ${duplicates.length} ملفًا مكررًا لم يتم استبداله.` : `تم رفع ${saved.length} ملف.` });
  } catch (e) {
    for (const f of req.files || []) { try { fs.rmSync(f.path, { force: true }); } catch {} }
    replyError(res, e);
  }
});
app.delete('/api/media/:filename', (req, res) => { try { const id = sid(req), name = decodeURIComponent(req.params.filename); fs.rmSync(media.safePath(store.getPaths(id).media, name), { force: true }); const s = store.loadSession(id); s.automation.tasks = (s.automation.tasks || []).map(t => ({ ...t, mediaIds: (t.mediaIds || []).filter(x => String(x) !== name) })); if (s.settings.scheduleMediaId === name) s.settings.scheduleMediaId = ''; store.saveSession(s); res.json({ ok: true, message: 'تم حذف الملف.' }); } catch (e) { replyError(res, e); } });
app.get('/media/:filename', (req, res) => { try { res.sendFile(media.safePath(store.getPaths(sid(req)).media, decodeURIComponent(req.params.filename))); } catch { res.status(404).end(); } });

app.post('/api/send', async (req, res) => {
  try {
    const result = await delivery.sendNow(sid(req), req.body || {});
    // DeliveryService returns per-target arrays, not numeric counts. Number([object]) yields NaN.
    const sentCount = Array.isArray(result.sent) ? result.sent.length : Number(result.sent || result.success || 0);
    const failed = Array.isArray(result.failed) ? result.failed : [];
    const failedCount = Array.isArray(result.failed) ? failed.length : Number(result.failed || 0);
    const failedDetails = failed.slice(0, 8).map(item => ({ target: item.target || 'مستلم', targetId: item.targetId || '', kind: item.kind || '', error: String(item.error || 'تعذر الإرسال').slice(0, 420), code: item.code || '', retryable: item.retryable === true }));
    const sent = Array.isArray(result.sent) ? result.sent : [];
    const uniqueTargetKey = item => `${item.kind || 'recipient'}:${item.targetId || item.target || ''}`;
    const sentRecipientCount = new Set(sent.map(uniqueTargetKey)).size;
    const failedRecipientCount = new Set(failed.filter(item => item.targetId || item.target).map(uniqueTargetKey)).size;
    res.json({ ...result, ok: true, deliveryOk: result.ok === true, sentCount, failedCount, sentRecipientCount, failedRecipientCount, failedDetails, message: failedCount ? `اكتملت ${sentCount} عملية إرسال إلى ${sentRecipientCount} مستلم، وفشلت ${failedCount} عملية تشمل ${failedRecipientCount} مستلم. راجع الأخطاء قبل إعادة المحاولة.` : `اكتملت ${sentCount} عملية إرسال إلى ${sentRecipientCount} مستلم بنجاح.` });
  } catch (e) { replyError(res, e); }
});
app.post('/api/schedule', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), b = req.body || {}, time = String(b.scheduleTime || '17:30'), tm = time.match(/^(\d{2}):(\d{2})$/);
    const mode = ['weekly', 'monthly', 'once'].includes(b.scheduleMode) ? b.scheduleMode : 'weekly';
    if (!tm || Number(tm[1]) > 23 || Number(tm[2]) > 59) throw new Error('وقت الجدولة غير صالح.');
    if (mode === 'once' && !validIsoDate(b.scheduleDate)) throw new Error('أدخل تاريخًا تقويميًا صالحًا للجدولة مرة واحدة.');
    if (mode === 'monthly' && !(Number(b.scheduleMonthDay) >= 1 && Number(b.scheduleMonthDay) <= 31)) throw new Error('اختر يومًا صحيحًا من 1 إلى 31 للجدولة الشهرية.');
    const requestedTargets = Array.isArray(b.scheduleTargetKeys) ? b.scheduleTargetKeys : []; const targetKeys = validTargetKeys(s, requestedTargets.length ? requestedTargets : [...s.recipients.filter(x => x.enabled !== false).map(x => `r:${x.id}`), ...s.groups.filter(x => x.enabled !== false).map(x => `g:${x.id}`)]);
    Object.assign(s.settings, {
      scheduleMode: mode, scheduleTime: time,
      scheduleDay: store.toInt(b.scheduleDay, 5, 0, 6),
      scheduleMonthDay: store.toInt(b.scheduleMonthDay, 1, 1, 31),
      scheduleDate: String(b.scheduleDate || ''), scheduleEnabled: boolValue(b.scheduleEnabled, true),
      scheduledGroupsEnabled: true, scheduleTargetKeys: targetKeys,
      scheduleMediaId: String(b.scheduleMediaId || ''), schedulePreText: String(b.schedulePreText ?? ''), schedulePostText: String(b.schedulePostText ?? ''),
    });
    if (!targetKeys.length) throw new Error('أضف رقمًا أو مجموعة للجدولة.');
    if (s.settings.scheduleMediaId && !media.scan(store.getPaths(s.id).media, s.settings.maxImageSizeMB).files.some(x => x.id === s.settings.scheduleMediaId)) throw new Error('ملف الجدولة المحدد غير موجود.');
    s.scheduleState.lastRunKey = '';
    store.saveSession(s);
    res.json({ ok: true, nextRun: nextRun(s), targets: targetKeys.length, message: 'تم حفظ الجدولة.' });
  } catch (e) { replyError(res, e); }
});

function normalizeInteractionRulePayload(s, body, existing = null) {
  const b = body || {}, previous = existing || {};
  const whenIn = { ...(previous.when || {}), ...(b.when || {}) };
  const thenIn = { ...(previous.then || {}), ...(b.then || {}) };
  let rawReplies = thenIn.replies ?? thenIn.replyVariants;
  if (rawReplies == null || (Array.isArray(rawReplies) && rawReplies.length === 0 && String(thenIn.reply || '').trim())) rawReplies = thenIn.reply ? String(thenIn.reply).split(/\r?\n/) : [];
  if (!Array.isArray(rawReplies)) rawReplies = [rawReplies];
  const replies = [...new Set(rawReplies.map(x => String(x ?? '').trim()).filter(Boolean))].slice(0, 80).map(x => x.slice(0, 1500));
  const singleReply = String(thenIn.reply || '').trim().slice(0, 1500);
  if (singleReply && !replies.includes(singleReply) && !Array.isArray(thenIn.replies) && !Array.isArray(thenIn.replyVariants)) replies.unshift(singleReply);
  const scheduleInput = b.schedule && typeof b.schedule === 'object' ? { ...(previous.schedule || {}), ...b.schedule } : (previous.schedule || {});
  const scheduleDays = Array.isArray(scheduleInput.days) ? [...new Set(scheduleInput.days.map(Number))] : [];
  const rule = {
    ...previous,
    id: previous.id || randomId(),
    name: String(b.name ?? previous.name ?? 'قاعدة').trim().slice(0, 100) || 'قاعدة',
    enabled: b.enabled === undefined ? (previous.enabled !== false) : boolValue(b.enabled, true),
    priority: store.toInt(b.priority, Number(previous.priority) || 0, -1000, 1000),
    commandPriority: b.commandPriority === undefined ? previous.commandPriority === true : boolValue(b.commandPriority, false),
    conflictGroup: String(b.conflictGroup ?? previous.conflictGroup ?? '').trim().slice(0, 80),
    when: {
      type: whenIn.type === 'reaction' ? 'reaction' : 'message',
      match: ['any','contains','exact','starts','ends','regex','similarity','intent'].includes(require('./src/trigger-engine').canonicalMode(whenIn.match)) ? require('./src/trigger-engine').canonicalMode(whenIn.match) : 'contains',
      value: String(whenIn.value ?? '').slice(0, 500),
      ignoreCase: whenIn.ignoreCase !== false,
      ...(whenIn.threshold !== undefined ? { threshold: Math.max(.30, Math.min(.98, Number(whenIn.threshold) || .68)) } : {}),
    },
    then: {
      reply: replies[0] || singleReply,
      replies,
      reaction: String(thenIn.reaction ?? '').trim().slice(0, 24),
      stopAfter: thenIn.stopAfter !== false,
    },
    scope: ['all','groups','private','selected'].includes(b.scope ?? previous.scope) ? (b.scope ?? previous.scope) : 'all',
    chatIds: normalizeRuleChatIds(b.chatIds === undefined ? previous.chatIds : b.chatIds),
    cooldownSec: store.toInt(b.cooldownSec, Number(previous.cooldownSec ?? 30), 0, 86400),
    schedule: {
      enabled: boolValue(scheduleInput.enabled, false),
      start: String(scheduleInput.start || '09:00'), end: String(scheduleInput.end || '17:00'),
      days: scheduleDays, timezone: String(scheduleInput.timezone || s.settings.timezone || 'Asia/Muscat'),
    },
  };
  if (!rule.then.reply && !rule.then.reaction) throw new Error('أضف ردًا واحدًا على الأقل أو Reaction.');
  require('./src/interaction').valid(rule);
  return rule;
}

app.post('/api/interaction/rules', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), r = normalizeInteractionRulePayload(s, req.body || {});
    s.interaction.rules.push(r); store.saveSession(s); res.json({ ok: true, rule: r, message: 'تم حفظ القاعدة.' });
  } catch (e) { replyError(res, e); }
});
app.put('/api/interaction/rules/:id', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), existing = s.interaction.rules.find(x => x.id === req.params.id);
    if (!existing) throw new Error('القاعدة غير موجودة.');
    const updated = normalizeInteractionRulePayload(s, req.body || {}, existing);
    Object.assign(existing, updated, { id: existing.id, updatedAt: new Date().toISOString() });
    store.saveSession(s); res.json({ ok: true, rule: existing, message: 'تم تحديث القاعدة.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/interaction/rules/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), r = s.interaction.rules.find(x => x.id === req.params.id); if (!r) throw new Error('القاعدة غير موجودة.'); r.enabled = !r.enabled; store.saveSession(s); res.json({ ok: true, enabled: r.enabled }); } catch (e) { replyError(res, e); } });
app.delete('/api/interaction/rules/:id', (req, res) => { try { const s = store.loadSession(sid(req)), before = s.interaction.rules.length; s.interaction.rules = s.interaction.rules.filter(x => x.id !== req.params.id); if (before === s.interaction.rules.length) throw new Error('القاعدة غير موجودة.'); store.saveSession(s); res.json({ ok: true }); } catch (e) { replyError(res, e); } });

function makeCounterTrigger(s, body, existing = null) {
  const b = body || {}, previous = existing || {}, priorThen = previous.then || {};
  const rawReplies = b.replies ?? b.then?.replies ?? b.then?.replyVariants ?? b.reply ?? b.then?.reply ?? priorThen.replies ?? priorThen.reply ?? '';
  let repliesInput = Array.isArray(rawReplies) ? rawReplies : String(rawReplies).split(/\r?\n/);
  if (!repliesInput.length && String(b.reply ?? b.then?.reply ?? priorThen.reply ?? '').trim()) repliesInput = String(b.reply ?? b.then?.reply ?? priorThen.reply).split(/\r?\n/);
  const replies = [...new Set(repliesInput.map(x => String(x ?? '').trim()).filter(Boolean))].slice(0, 80).map(x => x.slice(0, 1500));
  const actionType = ['reply','reaction','log'].includes(b.actionType ?? previous.actionType) ? (b.actionType ?? previous.actionType) : 'reply';
  const threshold = store.toInt(b.threshold, Number(previous.threshold) || 100, 1, 100000000);
  const state = s.interaction.counterState || { totalCount: 0, byChat: {}, fired: {}, pending: {} };
  const scope = (b.scope ?? previous.scope) === 'chat' ? 'chat' : 'session';
  const current = scope === 'session' ? Number(state.totalCount || 0) : 0;
  const trigger = {
    ...previous, id: previous.id || randomId(), name: String(b.name ?? previous.name ?? `عداد ${threshold}`).trim().slice(0, 100) || `عداد ${threshold}`,
    enabled: b.enabled === undefined ? previous.enabled !== false : boolValue(b.enabled, true), threshold,
    priority: store.toInt(b.priority, Number(previous.priority) || 0, -1000, 1000), scope, actionType,
    then: { reply: replies[0] || '', replies, reaction: String(b.reaction ?? b.then?.reaction ?? priorThen.reaction ?? '').trim().slice(0, 24) },
    armedAtCount: existing ? current : (Number(previous.armedAtCount) || current), updatedAt: new Date().toISOString(),
  };
  if (actionType === 'reply' && !trigger.then.replies.length) throw new Error('أضف ردًا واحدًا على الأقل لإجراء العداد.');
  if (actionType === 'reaction' && !trigger.then.reaction) throw new Error('أضف إيموجي للعداد.');
  return trigger;
}
app.post('/api/interaction/counters', (req, res) => {
  try { const s = store.loadSession(sid(req)), trigger = makeCounterTrigger(s, req.body || {}); s.interaction.counterTriggers ||= []; s.interaction.counterTriggers.push(trigger); store.saveSession(s); res.json({ ok: true, trigger, message: 'تم حفظ عداد الرسائل.' }); }
  catch (e) { replyError(res, e); }
});
app.put('/api/interaction/counters/:id', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), trigger = (s.interaction.counterTriggers || []).find(x => x.id === req.params.id);
    if (!trigger) throw new Error('العداد غير موجود.');
    const next = makeCounterTrigger(s, req.body || {}, trigger);
    Object.assign(trigger, next, { id: trigger.id });
    const cs = s.interaction.counterState ||= { totalCount: 0, byChat: {}, fired: {}, pending: {} };
    for (const map of [cs.fired, cs.pending]) for (const group of Object.values(map || {})) for (const key of Object.keys(group || {})) if (key.startsWith(`${trigger.id}:`)) delete group[key];
    store.saveSession(s); res.json({ ok: true, trigger, message: 'تم تحديث العداد.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/interaction/counters/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), t = (s.interaction.counterTriggers || []).find(x => x.id === req.params.id); if (!t) throw new Error('العداد غير موجود.'); t.enabled = !t.enabled; store.saveSession(s); res.json({ ok: true, enabled: t.enabled }); } catch (e) { replyError(res, e); } });
app.delete('/api/interaction/counters/:id', (req, res) => { try { const s = store.loadSession(sid(req)), before = (s.interaction.counterTriggers || []).length; s.interaction.counterTriggers = s.interaction.counterTriggers.filter(x => x.id !== req.params.id); if (before === s.interaction.counterTriggers.length) throw new Error('العداد غير موجود.'); store.saveSession(s); res.json({ ok: true }); } catch (e) { replyError(res, e); } });
app.post('/api/interaction/counters/reset', (req, res) => {
  try {
    const s = store.loadSession(sid(req));
    s.interaction.counterState = { totalCount: 0, byChat: {}, fired: {}, pending: {} };
    for (const trigger of s.interaction.counterTriggers || []) trigger.armedAtCount = 0;
    store.saveSession(s); res.json({ ok: true, message: 'تم تصفير العدادات وإعادة تسليح المحفزات.' });
  } catch (e) { replyError(res, e); }
});


function normalizeAutomationPayload(id, b, existing = null) {
  const base = existing || {};
  const raw = { ...base, ...(b || {}) };
  const mode = ['daily', 'weekly', 'monthly', 'yearly', 'once'].includes(String(raw.mode || '')) ? String(raw.mode) : 'weekly';
  const time = String(raw.time || '17:30');
  if (!/^\d{2}:\d{2}$/.test(time) || Number(time.slice(0, 2)) > 23 || Number(time.slice(3)) > 59) throw new Error('وقت الموعد غير صالح.');
  if (mode === 'once' && !validIsoDate(raw.date)) throw new Error('أدخل تاريخًا تقويميًا صالحًا.');
  if (mode !== 'once' && mode !== 'weekly' && !(Number(raw.dayOfMonth) >= 1 && Number(raw.dayOfMonth) <= 31)) throw new Error('يوم الشهر يجب أن يكون بين 1 و31.');
  if (mode === 'yearly' && !(Number(raw.month) >= 1 && Number(raw.month) <= 12)) throw new Error('اختر الشهر السنوي.');
  const s = store.loadSession(id), targets = validTargetKeys(s, Array.isArray(raw.targetKeys) ? raw.targetKeys : []), mediaIds = uniqueStrings(raw.mediaIds);
  const available = new Set(media.scan(store.getPaths(id).media, s.settings.maxImageSizeMB).files.map(x => x.id));
  const mediaOk = mediaIds.filter(x => available.has(x));
  if (mediaIds.length !== mediaOk.length) throw new Error('بعض ملفات الموعد غير موجودة.');
  if (!targets.length) throw new Error('اختر مستلمًا أو مجموعة للموعد.');
  const mediaMode = raw.mediaMode === 'cycle' ? 'cycle' : 'selected';
  const hasCycleImages = mediaMode === 'cycle' && media.scan(store.getPaths(id).media, s.settings.maxImageSizeMB).images.length > 0;
  if (!mediaOk.length && !String(raw.preText || '').trim() && !String(raw.postText || '').trim() && !hasCycleImages) throw new Error('أضف نصًا أو ملفًا للموعد، أو فعّل دورة الصور مع وجود صور.');
  return store.normalizeAutomationTask({ ...raw, id: base.id || undefined, name: raw.name, mode, time, date: raw.date, day: store.toInt(raw.day, 5, 0, 6), dayOfMonth: store.toInt(raw.dayOfMonth, 1, 1, 31), month: raw.month === '' ? '' : store.toInt(raw.month, 1, 1, 12), year: raw.year === '' ? '' : store.toInt(raw.year, new Date().getFullYear(), 2020, 2100), targetKeys: targets, mediaIds: mediaOk });
}
app.get('/api/automation/rules', (req, res) => { try { const s = store.loadSession(sid(req)); res.json({ ok: true, rules: s.automation.rules || [], mutes: s.automation.mutes || [], groupPermissions: s.settings.automationGroupPermissions || {}, eventState: { totalMessages: Number(s.automation.eventState?.totalMessages || 0), byChat: s.automation.eventState?.byChat || {} }, recent: s.automation.recent || [] }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/rules', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), rule = normalizeAutomationRule(req.body || {}, s);
    try { new Intl.DateTimeFormat('en-US', { timeZone: rule.timezone }).format(); } catch { throw new Error('المنطقة الزمنية غير صالحة.'); }
    if (rule.mode === 'once' && !validIsoDate(rule.date)) throw new Error('تاريخ القاعدة لمرة واحدة غير صالح.');
    if (['time','message-age'].includes(rule.triggerType) && rule.targetMode === 'current' && rule.action !== 'log') throw new Error('اختر هدفًا محددًا أو كل الأهداف للقاعدة المجدولة.');
    if (rule.triggerType === 'message-age' && rule.action !== 'cleanup-old-messages') throw new Error('قاعدة عمر الرسائل تستخدم إجراء تنظيف الرسائل القديمة.');
    s.automation.rules.push(rule); s.automation.rules = s.automation.rules.slice(-500); s.automation.enabled = true; store.saveSession(s);
    res.json({ ok: true, rule, message: 'تم حفظ قاعدة الأتمتة.' });
  } catch (e) { replyError(res, e); }
});
app.put('/api/automation/rules/:id', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), index = (s.automation.rules || []).findIndex(x => x.id === req.params.id);
    if (index < 0) throw new Error('قاعدة الأتمتة غير موجودة.');
    const rule = normalizeAutomationRule({ ...s.automation.rules[index], ...(req.body || {}), id: req.params.id, createdAt: s.automation.rules[index].createdAt }, s);
    try { new Intl.DateTimeFormat('en-US', { timeZone: rule.timezone }).format(); } catch { throw new Error('المنطقة الزمنية غير صالحة.'); }
    if (rule.mode === 'once' && !validIsoDate(rule.date)) throw new Error('تاريخ القاعدة لمرة واحدة غير صالح.');
    if (['time','message-age'].includes(rule.triggerType) && rule.targetMode === 'current' && rule.action !== 'log') throw new Error('اختر هدفًا محددًا أو كل الأهداف للقاعدة المجدولة.');
    if (rule.triggerType === 'message-age' && rule.action !== 'cleanup-old-messages') throw new Error('قاعدة عمر الرسائل تستخدم إجراء تنظيف الرسائل القديمة.');
    s.automation.rules[index] = { ...rule, id: req.params.id, createdAt: s.automation.rules[index].createdAt }; store.saveSession(s);
    res.json({ ok: true, rule: s.automation.rules[index], message: 'تم تحديث قاعدة الأتمتة.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/automation/rules/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), r = (s.automation.rules || []).find(x => x.id === req.params.id); if (!r) throw new Error('قاعدة الأتمتة غير موجودة.'); r.enabled = !r.enabled; r.updatedAt = new Date().toISOString(); store.saveSession(s); res.json({ ok: true, enabled: r.enabled }); } catch (e) { replyError(res, e); } });
app.delete('/api/automation/rules/:id', (req, res) => { try { const s = store.loadSession(sid(req)), before = s.automation.rules.length; s.automation.rules = s.automation.rules.filter(x => x.id !== req.params.id); if (s.automation.rules.length === before) throw new Error('قاعدة الأتمتة غير موجودة.'); store.saveSession(s); res.json({ ok: true, message: 'تم حذف قاعدة الأتمتة.' }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/rules/:id/run', async (req, res) => { try { const id = sid(req), s = store.loadSession(id), r = (s.automation.rules || []).find(x => x.id === req.params.id); if (!r) throw new Error('قاعدة الأتمتة غير موجودة.'); if (r.triggerType === 'message' || r.triggerType === 'group-message' || r.triggerType === 'message-count') throw new Error('هذه القاعدة تحتاج رسالة حدث؛ اختبرها بإرسال رسالة مطابقة.'); const result = await automationEngine.executeRule(id, r, { event: 'manual', scheduledAt: new Date().toISOString() }); res.json({ ok: true, result, message: 'اكتمل تنفيذ القاعدة اليدوي.' }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/group-permissions', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), b = req.body || {}, prior = s.settings.automationGroupPermissions || {};
    const keys = ['allowDeleteMessage','allowDeleteChat','allowArchive','allowMute','adminsOnly'];
    s.settings.automationGroupPermissions = { ...prior };
    for (const key of keys) if (b[key] !== undefined) s.settings.automationGroupPermissions[key] = boolValue(b[key], prior[key] === true);
    store.saveSession(s); res.json({ ok: true, groupPermissions: s.settings.automationGroupPermissions, message: 'تم حفظ صلاحيات الأتمتة للمجموعات.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/automation/mutes', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), mute = normalizeMute(req.body || {});
    const target = mute.chatId;
    // Owner-selected targets are checked against saved contacts/groups or accepted as a syntactically valid JID.
    await whatsapp.actOnChat(id, target, 'mute', { permanent: mute.mode === 'permanent', until: mute.expiresAt ? new Date(mute.expiresAt) : null, minutes: mute.minutes });
    const old = (s.automation.mutes || []).find(m => m.chatId === target && m.enabled !== false);
    if (old) Object.assign(old, mute, { id: old.id, createdAt: old.createdAt, updatedAt: new Date().toISOString() }); else s.automation.mutes.push(mute);
    s.automation.mutes = s.automation.mutes.slice(-1000); store.saveSession(s);
    automationEngine.muteApplied.set(`${id}|${old?.id || mute.id}`, `${target}|${mute.expiresAt || 'permanent'}`);
    res.json({ ok: true, mute: old || mute, message: mute.mode === 'permanent' ? 'تم كتم المحادثة حتى الإلغاء يدويًا.' : 'تم كتم المحادثة مؤقتًا.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/automation/mutes/:id/unmute', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), mute = (s.automation.mutes || []).find(x => x.id === req.params.id);
    if (!mute) throw new Error('إعداد الكتم غير موجود.');
    await whatsapp.actOnChat(id, mute.chatId, 'unmute'); mute.enabled = false; mute.updatedAt = new Date().toISOString(); mute.expiredAt = new Date().toISOString(); store.saveSession(s);
    automationEngine.muteApplied.delete(`${id}|${mute.id}`); res.json({ ok: true, message: 'تم إلغاء كتم المحادثة.' });
  } catch (e) { replyError(res, e); }
});
app.delete('/api/automation/mutes/:id', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), mute = (s.automation.mutes || []).find(x => x.id === req.params.id);
    if (!mute) throw new Error('إعداد الكتم غير موجود.');
    if (mute.enabled !== false) await whatsapp.actOnChat(id, mute.chatId, 'unmute');
    s.automation.mutes = s.automation.mutes.filter(x => x.id !== req.params.id); store.saveSession(s); automationEngine.muteApplied.delete(`${id}|${mute.id}`);
    res.json({ ok: true, message: 'تم إلغاء الكتم وحذف الإعداد.' });
  } catch (e) { replyError(res, e); }
});

app.get('/api/automation/tasks', (req, res) => { try { const s = store.loadSession(sid(req)); res.json({ ok: true, tasks: (s.automation.tasks || []).map(t => ({ ...t, nextRun: nextRunForItem({ ...t, timezone: s.settings.timezone }) })) }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/task', (req, res) => { try { const id = sid(req), s = store.loadSession(id), task = normalizeAutomationPayload(id, req.body || {}); s.automation.tasks.push(task); s.automation.enabled = true; store.saveSession(s); res.json({ ok: true, task: { ...task, nextRun: nextRunForItem({ ...task, timezone: s.settings.timezone }) }, message: 'تم حفظ الموعد داخل الجلسة الحالية.' }); } catch (e) { replyError(res, e); } });
app.put('/api/automation/task/:id', (req, res) => { try { const id = sid(req), s = store.loadSession(id), task = s.automation.tasks.find(x => x.id === req.params.id); if (!task) throw new Error('الموعد غير موجود.'); const updated = normalizeAutomationPayload(id, req.body || {}, task); Object.assign(task, updated, { id: task.id, updatedAt: new Date().toISOString() }); store.saveSession(s); res.json({ ok: true, task: { ...task, nextRun: nextRunForItem({ ...task, timezone: s.settings.timezone }) }, message: 'تم تحديث الموعد.' }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/task/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), t = s.automation.tasks.find(x => x.id === req.params.id); if (!t) throw new Error('الموعد غير موجود.'); t.enabled = !t.enabled; t.updatedAt = new Date().toISOString(); store.saveSession(s); res.json({ ok: true, enabled: t.enabled, message: t.enabled ? 'تم تشغيل الموعد.' : 'تم إيقاف الموعد.' }); } catch (e) { replyError(res, e); } });
app.delete('/api/automation/task/:id', (req, res) => { try { const s = store.loadSession(sid(req)), before = s.automation.tasks.length; s.automation.tasks = s.automation.tasks.filter(x => x.id !== req.params.id); if (before === s.automation.tasks.length) throw new Error('الموعد غير موجود.'); store.saveSession(s); res.json({ ok: true, message: 'تم حذف الموعد.' }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/task/:id/run', async (req, res) => { try { const s = store.loadSession(sid(req)), t = s.automation.tasks.find(x => x.id === req.params.id); if (!t) throw new Error('الموعد غير موجود.'); res.json({ ok: true, ...(await delivery.scheduledTaskRun(s.id, t)), message: 'تم تنفيذ الموعد.' }); } catch (e) { replyError(res, e); } });

app.post('/api/interaction/test', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), body = String(req.body?.message || ''), chatId = String(req.body?.chatId || 'test@c.us').toLowerCase();
    const rule = req.body?.rule || {};
    if (!body && rule.when?.type === 'message' && rule.when?.match !== 'any') throw new Error('اكتب رسالة اختبار.');
    const interaction = require('./src/interaction');
    const triggerEngine = require('./src/trigger-engine');
    triggerEngine.validateTrigger(rule);
    const matchResult = triggerEngine.matchTrigger(rule, rule.when?.type === 'reaction' ? 'reaction' : 'message', body, String(req.body?.emoji || ''), { threshold: s.settings.interactionSimilarityThreshold });
    const syntaxMatch = matchResult.matched;
    const activeNow = interaction.ruleActiveNow(rule, s.settings, new Date());
    const matched = syntaxMatch && activeNow;
    const replyEngine = require('./src/reply-engine');
    const reply = replyEngine.pickReply(rule, {}, 'test');
    res.json({ ok: true, matched, syntaxMatch, activeNow, intent: matchResult.intent, score: matchResult.score, rendered: interaction.render(reply || rule.then?.reply || '', { message: body, sender: String(req.body?.sender || 'مستخدم'), chat: chatId, type: rule.when?.type || 'message', emoji: String(req.body?.emoji || ''), intent: matchResult.intent }, s.settings.timezone), message: !syntaxMatch ? 'الرسالة لا تطابق الشرط.' : !activeNow ? 'الشرط مطابق، لكن القاعدة خارج وقت التشغيل المحدد.' : 'الشرط والوقت مطابقان.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/settings', async (req, res) => {
  try {
    const s = store.loadSession(sid(req)), b = req.body || {};
    const settingsWarnings = await validateRuntimeSettings({ settings: s.settings, body: b, localLlm, audioTranscriber });
    for (const key of ['timezone', 'sendOrder', 'interactionScope', 'interactionQuietStart', 'interactionQuietEnd']) {
      if (b[key] === undefined) continue;
      const value = String(b[key]).trim();
      if (key === 'timezone') { try { new Intl.DateTimeFormat('en-US', { timeZone: value }).format(); } catch { throw new Error('المنطقة الزمنية غير صالحة. استخدم اسمًا مثل Asia/Muscat.'); } }
      if (['interactionQuietStart', 'interactionQuietEnd'].includes(key) && !/^([01]\d|2[0-3]):[0-5]\d$/.test(value)) throw new Error('وقت الهدوء يجب أن يكون بصيغة HH:MM.');
      s.settings[key] = value;
    }
    if (b.interactionQuietAction !== undefined) {
      const action = String(b.interactionQuietAction);
      if (!['silence', 'reply', 'rules'].includes(action)) throw new Error('اختر سلوكًا صحيحًا لفترة الهدوء.');
      s.settings.interactionQuietAction = action;
    }
    if (b.interactionQuietReply !== undefined) s.settings.interactionQuietReply = String(b.interactionQuietReply).slice(0, 1000);
    if (b.interactionQuietCooldownSec !== undefined) s.settings.interactionQuietCooldownSec = store.toInt(b.interactionQuietCooldownSec, 300, 0, 86400);
    if (Array.isArray(b.interactionChatIds)) s.settings.interactionChatIds = normalizeRuleChatIds(b.interactionChatIds);
    if (b.interactionConflictMode !== undefined) { const mode = String(b.interactionConflictMode); if (!['first-match','highest-score','allow-multiple'].includes(mode)) throw new Error('وضع حل التعارض غير صالح.'); s.settings.interactionConflictMode = mode; }
    if (b.interactionSimilarityThreshold !== undefined) { const threshold = Number(b.interactionSimilarityThreshold); if (!Number.isFinite(threshold) || threshold < .30 || threshold > .98) throw new Error('عتبة التشابه يجب أن تكون بين 0.30 و0.98.'); s.settings.interactionSimilarityThreshold = threshold; }
    if (b.interactionSmartThreshold !== undefined) { const threshold = Number(b.interactionSmartThreshold); if (!Number.isFinite(threshold) || threshold < .72 || threshold > .98) throw new Error('عتبة المطابقة الذكية يجب أن تكون بين 0.72 و0.98.'); s.settings.interactionSmartThreshold = threshold; }
    if (b.interactionFallbackCooldownSec !== undefined) s.settings.interactionFallbackCooldownSec = store.toInt(b.interactionFallbackCooldownSec, 45, 10, 86400);
    if (b.smartReplyTimeoutMs !== undefined) s.settings.smartReplyTimeoutMs = store.toInt(b.smartReplyTimeoutMs, 12000, 1500, 60000);
    if (b.smartReplyModel !== undefined) { const model = String(b.smartReplyModel || '').trim(); if (!/^[\w.:-]{1,100}$/.test(model)) throw new Error('اسم نموذج Ollama غير صالح.'); s.settings.smartReplyModel = model; }
    if (b.interactionFallbackReply !== undefined) s.settings.interactionFallbackReply = String(b.interactionFallbackReply || '').slice(0, 1500);
    if (b.smartReplySystemPrompt !== undefined) s.settings.smartReplySystemPrompt = String(b.smartReplySystemPrompt || '').slice(0, 3000);
    if (b.voiceTranscribeLanguage !== undefined) s.settings.voiceTranscribeLanguage = ['ar','en','fr','de','es','ur','hi','tr'].includes(String(b.voiceTranscribeLanguage)) ? String(b.voiceTranscribeLanguage) : 'ar';
    if (b.ttsRequireProofread !== undefined) s.settings.ttsRequireProofread = boolValue(b.ttsRequireProofread, true);
    if (b.appearance && typeof b.appearance === 'object') {
      const a = b.appearance, isHex = v => /^#[0-9a-f]{6}$/i.test(String(v || ''));
      const current = s.settings.appearance || {};
      s.settings.appearance = {
        ...current,
        accent: isHex(a.accent) ? String(a.accent) : current.accent,
        accent2: isHex(a.accent2) ? String(a.accent2) : current.accent2,
        panelOpacity: Number.isFinite(Number(a.panelOpacity)) ? Math.max(.72, Math.min(.97, Number(a.panelOpacity))) : current.panelOpacity,
        panelBlur: Number.isFinite(Number(a.panelBlur)) ? Math.max(4, Math.min(28, Number(a.panelBlur))) : current.panelBlur,
        radius: Number.isFinite(Number(a.radius)) ? Math.max(12, Math.min(28, Number(a.radius))) : current.radius,
        glow: Number.isFinite(Number(a.glow)) ? Math.max(0, Math.min(1, Number(a.glow))) : current.glow,
      };
    }
    for (const key of ['sendTimeoutMs', 'sendDelayMs', 'retryAttempts', 'retryDelayMs', 'maxImageSizeMB', 'maxActionsPerMinute']) if (b[key] !== undefined) { const max = key === 'retryAttempts' ? 4 : key === 'maxImageSizeMB' ? 250 : key === 'sendTimeoutMs' ? 180000 : key === 'sendDelayMs' ? 60000 : key === 'retryDelayMs' ? 120000 : 1000; s.settings[key] = store.toInt(b[key], s.settings[key], key === 'sendDelayMs' ? 0 : 1, max); }
    for (const key of ['interactionEnabled', 'groupAssistantEnabled', 'interactionIgnoreOwn', 'interactionQuietEnabled', 'interactionSmartMatching', 'interactionFallbackEnabled', 'interactionFallbackInGroups', 'voiceAutoTranscribeEnabled', 'voiceAutoTranscribeSelfChat', 'autoStartSession', 'automationEnabled']) if (b[key] !== undefined) s.settings[key] = boolValue(b[key], s.settings[key]);
    if (b.interactionEnabled !== undefined) s.interaction.enabled = boolValue(b.interactionEnabled, s.interaction.enabled);
    if (b.automationEnabled !== undefined) s.automation.enabled = boolValue(b.automationEnabled, s.automation.enabled);
    store.saveSession(s); res.json({ ok: true, message: settingsWarnings.length ? 'تم حفظ الإعدادات، لكن بعض المحركات الاختيارية غير جاهزة بعد.' : 'تم حفظ الإعدادات.', warnings: settingsWarnings, runtime: { smartReplyEnabled: s.settings.smartReplyEnabled === true, voiceAutoTranscribeEnabled: s.settings.voiceAutoTranscribeEnabled !== false } });
  } catch (e) { replyError(res, e); }
});
app.post('/api/settings/background', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), b = req.body || {}, n = backgrounds.normalize(b.mode, b.settings, b.opacity);
    s.settings.backgroundMode = n.mode; s.settings.backgroundSettings = n.settings; s.settings.backgroundOpacity = n.opacity;
    if (b.removeImage && s.settings.backgroundImage) { try { fs.rmSync(media.safePath(store.getPaths(id).backgrounds, s.settings.backgroundImage), { force: true }); } catch {} s.settings.backgroundImage = ''; }
    store.saveSession(s); res.json({ ok: true, message: 'تم تطبيق المظهر فعليًا.' });
  } catch (e) { replyError(res, e); }
});
app.get('/profile/:filename', (req, res) => {
  try {
    const name = String(req.params.filename || '');
    if (!/^[a-f0-9]{24}\.(?:jpg|jpeg|png|webp|gif|avif)$/i.test(name)) return res.status(404).end();
    const file = media.safePath(store.getPaths(sid(req)).profiles, name);
    if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return res.status(404).end();
    res.setHeader('Cache-Control', 'private, max-age=3600');
    res.type(path.extname(name));
    res.sendFile(file);
  } catch { res.status(404).end(); }
});

app.post('/api/background', bgUpload.single('file'), (req, res) => {

  try {
    const id = sid(req), file = req.file; if (!file) throw new Error('اختر صورة خلفية.');
    const ext = path.extname(file.originalname || '').toLowerCase(); if (!['.jpg', '.jpeg', '.png', '.webp'].includes(ext)) throw new Error('صيغة الخلفية غير مدعومة.');
    const s = store.loadSession(id), dir = store.getPaths(id).backgrounds, name = `background${ext}`;
    for (const oldExt of ['.jpg','.jpeg','.png','.webp']) { const oldName = `background${oldExt}`; if (oldName !== name) { try { fs.rmSync(media.safePath(dir, oldName), { force: true }); } catch {} } }
    fs.renameSync(file.path, media.safePath(dir, name)); s.settings.backgroundImage = name; store.saveSession(s); res.json({ ok: true, message: 'تم رفع الخلفية وتطبيقها.' });
  } catch (e) { try { if (req.file) fs.rmSync(req.file.path, { force: true }); } catch {} replyError(res, e); }
});
app.get('/background/:filename', (req, res) => { try { const s = store.loadSession(sid(req)), name = decodeURIComponent(req.params.filename); if (s.settings.backgroundImage !== name) return res.status(404).end(); res.sendFile(media.safePath(store.getPaths(s.id).backgrounds, name)); } catch { res.status(404).end(); } });

whatsapp.on('status', (id, runtime) => {
  if (runtime?.ready) ownerAssistant.maybeSendWelcome(id).catch(error => log(id, 'WARN', `تعذر إرسال دليل محادثة النفس: ${safeError(error)}`));
});

function messageWithBody(message, body, extra = {}) {
  const input = Object.create(message && typeof message === 'object' ? message : Object.prototype);
  Object.defineProperty(input, 'body', { configurable: true, enumerable: true, value: String(body || '') });
  for (const [key, value] of Object.entries(extra)) Object.defineProperty(input, key, { configurable: true, enumerable: true, value });
  return input;
}
async function withVoiceTranscript(id, msg, { selfChat = false } = {}) {
  const hasAudio = audioTranscriber.rememberIncoming(id, msg);
  const session = store.loadSession(id);
  if (session.settings.voiceAutoTranscribeEnabled === false || (selfChat && session.settings.voiceAutoTranscribeSelfChat === false)) return msg;
  if (!hasAudio) return msg;
  try {
    const status = await audioTranscriber.status();
    if (!status.ready) {
      log(id, 'WARN', `وصلت صوتية لكن التفريغ المحلي غير جاهز: ${status.message}`);
      if (selfChat) await ownerAssistant.reply(id, `وصلتني الصوتية، لكن محرك التفريغ المحلي غير جاهز. ${status.message}
بعد تثبيت Whisper والنموذج المحلي، أرسل الصوتية مرة أخرى أو اطلب «فرّغ آخر صوتية».`);
      else {
        const chatId = String(msg?.from || msg?.to || msg?._data?.from || '').toLowerCase();
        const isGroup = chatId.endsWith('@g.us') || msg?.isGroupMsg === true;
        if (maySendVoiceSetupNotice({ session, chatId, isGroup })) await whatsapp.replyToMessage(id, msg, `وصلني التسجيل الصوتي، لكن التفريغ المحلي غير مهيأ بعد. سيحتاج مالك البوت إلى إعداد Whisper محليًا لتتمكن قواعد الرد من فهم الصوت.`);
      }
      return null;
    }
    const result = await audioTranscriber.transcribeMessage(msg, { language: session.settings.voiceTranscribeLanguage || 'ar' });
    const transcript = String(result?.text || result?.transcript || '').trim();
    if (!transcript) {
      if (selfChat) await ownerAssistant.reply(id, 'لم يتمكن Whisper من استخراج كلمات واضحة من الصوتية. جرّب تسجيلًا أوضح، أو اطلب «فرّغ آخر صوتية» بعد التحقق من الإعدادات.');
      else await whatsapp.replyToMessage(id, msg, 'لم أتمكن من استخراج كلام واضح من التسجيل. جرّب إرسال صوتية أوضح.');
      return null;
    }
    log(id, 'INFO', `تم تفريغ صوتية محليًا (${transcript.length} حرفًا؛ ${session.settings.voiceTranscribeLanguage || 'ar'}).`);
    return messageWithBody(msg, transcript, { __chatBotTranscript: true, __chatBotTranscriptText: transcript });
  } catch (error) {
    log(id, 'WARN', `تعذر تفريغ الصوتية: ${safeError(error)}`);
    if (selfChat) await ownerAssistant.reply(id, `تعذر تفريغ الصوتية: ${String(error?.message || error).slice(0, 350)}
يمكنك استخدام لوحة «تفريغ صوت إلى نص» لمعرفة حالة المحرك.`);
    else await whatsapp.replyToMessage(id, msg, 'تعذر فهم التسجيل الصوتي الآن. تحقق من إعداد Whisper المحلي، ثم أعد إرسال الصوتية.');
    return null;
  }
}
whatsapp.on('message', async (id, msg) => {
  await archiveWhatsAppMessage(id, msg, false);
  eventBus.publish('message.received', { sessionId: id, chatId: String(msg?.from || ''), messageId: String(msg?.id?._serialized || msg?.id || ''), fromMe: !!msg?.fromMe, type: String(msg?.type || 'chat'), timestamp: Number(msg?.timestamp || Date.now() / 1000) }).catch(() => {});
  const inboundChatId = conversationTargets.chatIdOf(msg?.from || msg?._data?.from || msg?.id?.remote || msg?._data?.id?.remote || '');
  if (recipientReplies.recipientIsPaused(store.loadSession(id), inboundChatId)) {
    log(id, 'INFO', 'تم تجاهل رسالة جهة متوقفة: ' + inboundChatId + '؛ لن تعمل الأتمتة أو قواعد الرد أو الرد الذكي.');
    return;
  }
  let processed = msg;
  const audioType = ['audio','ptt','voice'].includes(String(msg?.type || '').toLowerCase()) || String(msg?._data?.mimetype || '').toLowerCase().startsWith('audio/');
  if (audioType && voiceBootstrapTask) {
    try {
      const voiceStatus = await audioTranscriber.status();
      if (!voiceStatus.ready) {
        try { audioTranscriber.rememberIncoming(id, msg); } catch {}
        await withTimeoutPromise(voiceBootstrapTask, 50 * 60 * 1000, 'إعداد محركات الصوت المحلية');
      }
    } catch (error) { log(id, 'WARN', 'تعذر انتظار الإعداد الصوتي التلقائي: ' + safeError(error)); }
  }
  if (audioType) {
    try { processed = await withVoiceTranscript(id, msg, { selfChat: false }); }
    catch (error) { log(id, 'ERROR', `معالجة الصوتية الواردة: ${safeError(error)}`); return; }
    if (!processed) return;
    if (processed?.__chatBotTranscript === true && processed?.__chatBotTranscriptText) {
      const baseId = String(msg?.id?._serialized || msg?.id?.$1 || msg?.id?.id || msg?.id || 'voice');
      const transcriptMessage = messageWithBody(msg, processed.__chatBotTranscriptText, { __chatBotArchiveId: `${baseId}:transcript`, type: 'transcript', __chatBotTranscript: true });
      await archiveWhatsAppMessage(id, transcriptMessage, false);
    }
  }
  // The automation engine is auxiliary: an automation exception must never suppress
  // normal auto-replies, and a reply error must never prevent group-command routing.
  try {
    const result = await automationEngine.handleMessage(id, processed);
    if (result?.reason) log(id, 'DEBUG', `التفاعل الآلي تخطى رسالة (${result.reason}).`);
  } catch (error) { log(id, 'ERROR', `محرك الأتمتة: ${safeError(error)}`); }
  try {
    const result = await interaction.onMessage(id, processed);
    if (result && result.handled === false && result.reason && !['duplicate','scope'].includes(result.reason)) log(id, 'DEBUG', `لم يرسل الرد التلقائي: ${result.reason}.`);
  } catch (error) { log(id, 'ERROR', `محرك الرد التلقائي: ${safeError(error)}`); }
  try { await groupCommand(id, processed); }
  catch (error) { log(id, 'ERROR', `أمر المجموعة: ${safeError(error)}`); }
});
whatsapp.on('message_create', async (id, msg) => {
  try {
    const fromMe = isFromMeMessage(msg);
    if (fromMe) await archiveWhatsAppMessage(id, msg, true);
    if (!fromMe || msg.__chatBotProgrammatic || msg._chatBotProgrammatic) return;
    if (typeof whatsapp.isProgrammaticOutgoing === 'function' && whatsapp.isProgrammaticOutgoing(id, msg)) return;
    if (typeof whatsapp.isSelfChatMessage !== 'function') return;
    if (!await whatsapp.isSelfChatMessage(id, msg)) {
      const chatRef = String(msg?.id?.remote || msg?._data?.id?.remote || msg?.to || '').toLowerCase();
      log(id, 'DEBUG', `تم تجاهل رسالة صادرة لأنها لم تُثبت كمحادثة النفس؛ لن أرسل ردًا إلى جهة أخرى. chat=${chatRef || 'غير معروف'}`);
      return;
    }
    let assistantMessage = msg;
    const audioType = ['audio','ptt','voice'].includes(String(msg?.type || '').toLowerCase()) || String(msg?._data?.mimetype || '').toLowerCase().startsWith('audio/');
    if (audioType) {
      assistantMessage = await withVoiceTranscript(id, msg, { selfChat: true });
      if (!assistantMessage) return;
      if (assistantMessage?.__chatBotTranscript === true && assistantMessage?.__chatBotTranscriptText) {
        const baseId = String(msg?.id?._serialized || msg?.id?.$1 || msg?.id?.id || msg?.id || 'voice');
        const transcriptMessage = messageWithBody(msg, assistantMessage.__chatBotTranscriptText, { __chatBotArchiveId: `${baseId}:transcript`, type: 'transcript', __chatBotTranscript: true });
        await archiveWhatsAppMessage(id, transcriptMessage, true);
      }
    } else audioTranscriber.rememberIncoming(id, msg);
    // Keep both conversational wizards and the original compact one-line command style.
    // An active owner wizard keeps priority, while an already-pending one-line command
    // takes priority so its confirmation cannot be interpreted as a different action.
    const current = store.loadSession(id);
    const bridgePending = Boolean(current.commandBridge?.pending);
    const ownerFlow = Boolean(current.ownerAssistant?.flow);
    if (bridgePending || !ownerFlow) {
      let commandResult;
      try { commandResult = await localCommandBridge.handle(id, assistantMessage?.body || assistantMessage?._data?.body || ''); }
      catch (error) {
        log(id, 'ERROR', `تعذر تنفيذ الأمر المباشر: ${safeError(error)}`);
        await ownerAssistant.reply(id, `لم أنفّذ الأمر بسبب خطأ: ${safeError(error)}\nتحقق من الاسم والحقول ثم أعد المحاولة. لم أغيّر بيانات الأمر قبل تأكيده.`);
        return;
      }
      if (commandResult?.handled) {
        await ownerAssistant.reply(id, commandResult.response);
        return;
      }
    }
    const result = await ownerAssistant.handleSelfChatMessage(id, assistantMessage);
    if (result?.handled && !result?.fallback) return;
    const input = Object.create(Object.getPrototypeOf(msg) || Object.prototype);
    Object.assign(input, assistantMessage);
    Object.defineProperty(input, 'fromMe', { configurable: true, enumerable: true, value: false });
    Object.defineProperty(input, '__chatBotSelfInput', { configurable: true, enumerable: true, value: true });
    await interaction.onMessage(id, input);
  } catch (error) { log(id, 'ERROR', `تعذر معالجة رسالة محادثة النفس: ${safeError(error)}`); }
});
whatsapp.on('reaction', (id, reaction) => interaction.onReaction(id, reaction).catch(e => log(id, 'ERROR', safeError(e))));

async function groupCommand(id, msg) {
  try {
    if (msg?.fromMe) return;
    const gid = groupFromMessage(msg); if (!gid) return;
    const s = store.loadSession(id);
    if (!s.settings.groupAssistantEnabled) return;
    const body = String(msg?.body || '').trim();
    const command = /^(?:!|\/)?(?:gid|group\s*id|groupid|group\s*info|group\s*analysis|معرف\s*(?:المجموعة|القروب)|تحليل\s*(?:المجموعة|القروب)|معلومات\s*(?:المجموعة|القروب)|معلومات\s*الجروب)(?=\s|$)/iu;
    const invite = body.match(/(?:https?:\/\/)?chat\.whatsapp\.com\/[A-Za-z0-9_-]+/i);
    const gidMention = body.match(/(?:^|[\s(])\d{5,25}(?:-\d+)*@g\.us(?=$|[\s)])/i);
    // Critical privacy/behavior rule from v8.6.0: a normal group message must not
    // discover or persist a group. Continue only for an explicit group command,
    // an invite link, or an explicit GID mention.
    if (!command.test(body) && !invite && !gidMention) return;
    let info = null;
    try { info = await whatsapp.getGroupInfoFromMessage(id, msg); } catch {}
    let target = invite ? invite[0] : gidMention ? gidMention[0] : body.replace(command, '').trim();
    if (!target) target = gid;
    if (groups.isGroupId(target)) info = await whatsapp.getGroupInfo(id, groups.normalizeGid(target));
    else if (invite) info = await whatsapp.analyzeGroupInvite(id, groups.extractInviteCode(target));
    else info = info || await whatsapp.getGroupInfo(id, gid);
    if (info?.gid) saveGroup(id, info);
    await whatsapp.replyToMessage(id, msg, `تحليل المجموعة\n${groups.formatGroupAnalysis(info)}`);
  } catch (e) {
    try { if (msg && !msg.fromMe) await whatsapp.replyToMessage(id, msg, `تعذر تحليل المجموعة: ${safeError(e)}`); } catch {}
  }
}

app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  const message = err?.code === 'LIMIT_FILE_SIZE' ? 'حجم الملف أكبر من الحد المسموح.' : err?.code === 'LIMIT_FILE_COUNT' ? 'عدد الملفات أكبر من الحد المسموح.' : safeError(err);
  res.status(Number(err?.status) || 400).json({ ok: false, error: message });
});
process.on('unhandledRejection', reason => log(null, 'ERROR', `Unhandled Promise Rejection: ${safeError(reason)}`));

async function shutdown(signal) {
  log(null, 'INFO', `إيقاف الخادم (${signal})…`);
  scheduler.stop();
  integrationHub.stop();
  eventBus.close();
  await whatsapp.stopAll().catch(() => {});
  process.exit(0);
}
process.once('SIGINT', () => shutdown('SIGINT'));
process.once('SIGTERM', () => shutdown('SIGTERM'));

app.listen(PORT, HOST, () => { integrationHub.start(); voiceBootstrapTask = startVoiceBootstrap({ root: store.ROOT, audioTranscriber, textToSpeech, logger: log }).catch(error => { log(null, 'WARN', 'تعذر بدء الإعداد الصوتي التلقائي: ' + safeError(error)); return getVoiceBootstrapStatus(); }); if (REMOTE_ACCESS_CONFIG.enabled) log(null, 'WARN', 'لوحة التحكم البعيدة محمية بتسجيل دخول Basic. استخدم شبكة موثوقة أو وكيل HTTPS؛ HTTP وحده لا يشفّر كلمة المرور أو رمز الجهاز.'); log(null, 'INFO', `لوحة التحكم تعمل على http://${HOST}:${PORT}`); setTimeout(() => { for (const id of store.listSessionIds()) { const s = store.loadSession(id); if (s.settings.autoStartSession && whatsapp.hasSavedAuth(id) && !whatsapp.listRuntime(id).ready) whatsapp.start(id).catch(err => log(id, 'WARN', `التشغيل التلقائي للجلسة لم يكتمل: ${safeError(err)}`)); } }, 500); });
