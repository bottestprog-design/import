# تقرير مراجعة v9.16.3

التاريخ: 26 أكتوبر 2026

## الإصلاحات
1. توحيد تعريف الرسائل الصادرة عبر `src/message-identifiers.js` ليستخدمه كل من `server.js` و`src/whatsapp.js`.
2. إذا فقد غلاف الرسالة خاصية `fromMe` ولكن بقيت في المعرّف المتسلسل (`true_` أو `1_`)، فلا تُسقط الرسالة قبل فحص كونها محادثة النفس.
3. عند عدم إثبات أنها محادثة النفس، يسجل النظام سبب التجاهل على مستوى DEBUG ولا يرسل ردًا إلى محادثة أخرى.
4. الاحتفاظ بإصلاحات إعداد Whisper المحلي في الإصدار السابق: تحديد مسار المحرك، استخدام النموذج متعدد اللغات `ggml-small.bin`، تجاهل مسار نموذج قديم مفقود، وإظهار النقص المحلي في FFmpeg.

## الاختبارات المنفذة
- اختبارات سلوكية لوحدة `isFromMeMessage`: الحقل الصريح، المعرّف `true_`، المعرّف المتداخل `$1`، وحالة الرسالة غير الصادرة.
- `test/self-chat-routing.js`
- `test/audio-transcriber.js`
- `test/static.js`
- `test/whatsapp-restoration-ui.js`
- `test/reference-restoration.js`
- `test/media-gallery.js`
- `test/local-backup.js`
- `test/smart-reply.js`
- `test/smoke.js`
- `test/text-to-speech.js`
- `test/whatsapp-chat-tools.js`
- `test/whatsapp-connection.js`
- `test/whatsapp-errors.js`
- `test/whatsapp-profile-manager.js`
- `test/whatsapp-profile-pictures.js`

## القيود المعروفة
- لم يكتمل تشغيل مجموعة `npm test` كلها في محاولة سابقة ضمن بيئة البناء، لذا لا يُدّعى اجتياز المجموعة الكاملة.
- اختبار تكامل Express قد يُتخطى إذا لم تكن الاعتماديات مثبتة في بيئة البناء.
- لا يمكن تأكيد الرد عبر حساب WhatsApp حي أو دقة التفريغ العربي الفعلية قبل التجربة على Windows. يحتاج إعداد الصوت لتنزيل المحرك والنموذج مرة واحدة، كما تحتاج فويسات OGG/OPUS عادةً إلى FFmpeg.
- لا يُرفع الصوت إلى خدمة صوتية سحابية؛ المعالجة بعد الإعداد تتم محليًا.
