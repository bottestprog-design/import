"use strict";
const { patch } = require('../src/compat');
const result = patch();
console.log(JSON.stringify(result, null, 2));
if (!result.ok) process.exitCode = 1;
