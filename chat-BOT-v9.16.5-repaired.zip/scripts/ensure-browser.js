"use strict";
const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");
const { spawnSync } = require("node:child_process");

const ROOT = path.resolve(__dirname, "..");
const cacheDir = process.env.PUPPETEER_CACHE_DIR || path.join(ROOT, ".cache", "puppeteer");
const marker = path.join(ROOT, ".browser-path");
fs.mkdirSync(cacheDir, { recursive: true });

function isFile(p) { try { return !!p && fs.statSync(p).isFile(); } catch { return false; } }
function configuredCandidate() {
  if (process.env.PUPPETEER_EXECUTABLE_PATH && isFile(process.env.PUPPETEER_EXECUTABLE_PATH)) return process.env.PUPPETEER_EXECUTABLE_PATH;
  if (process.env.CHROME_PATH && isFile(process.env.CHROME_PATH)) return process.env.CHROME_PATH;
  return '';
}
function markerCandidate() {
  try { const value = fs.readFileSync(marker, 'utf8').trim(); return isFile(value) ? value : ''; } catch { return ''; }
}
function candidates() {
  const home = os.homedir();
  const local = process.env.LOCALAPPDATA || path.join(home, "AppData", "Local");
  const pf = process.env.ProgramFiles || "C:\\Program Files";
  const pfx86 = process.env["ProgramFiles(x86)"] || "C:\\Program Files (x86)";
  return [
    path.join(local, "Google", "Chrome", "Application", "chrome.exe"),
    path.join(pf, "Google", "Chrome", "Application", "chrome.exe"),
    path.join(pfx86, "Google", "Chrome", "Application", "chrome.exe"),
    path.join(local, "Microsoft", "Edge", "Application", "msedge.exe"),
    path.join(pf, "Microsoft", "Edge", "Application", "msedge.exe"),
    path.join(pfx86, "Microsoft", "Edge", "Application", "msedge.exe"),
    "/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/usr/bin/chromium", "/usr/bin/chromium-browser",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  ].filter(isFile);
}
function puppeteerPath() {
  try {
    const puppeteer = require("puppeteer");
    const p = puppeteer.executablePath();
    if (isFile(p)) return p;
  } catch {}
  return "";
}
function cacheSearch() {
  const root = path.join(cacheDir, "chrome");
  if (!fs.existsSync(root)) return "";
  const stack = [root];
  while (stack.length) {
    const dir = stack.pop();
    let entries = [];
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { continue; }
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isFile() && /^chrome(\.exe)?$/i.test(e.name)) return full;
      if (e.isDirectory()) stack.push(full);
    }
  }
  return "";
}
function writeMarker(executable) {
  if (!isFile(executable)) return false;
  fs.writeFileSync(marker, executable, "utf8");
  return true;
}

if (process.argv.includes("--check")) {
  const found = fs.existsSync(marker) ? marker && fs.readFileSync(marker, "utf8").trim() : "";
  const executable = configuredCandidate() || (found && isFile(found) && found) || puppeteerPath() || cacheSearch() || candidates()[0] || '';
  console.log(JSON.stringify({ ok: !!executable, executable: executable || null, cacheDir }, null, 2));
  process.exit(executable ? 0 : 2);
}

let executable = configuredCandidate() || markerCandidate() || puppeteerPath() || cacheSearch() || candidates()[0] || '';
if (!executable) {
  const bin = process.platform === "win32" ? path.join(ROOT, "node_modules", ".bin", "puppeteer.cmd") : path.join(ROOT, "node_modules", ".bin", "puppeteer");
  const command = isFile(bin) ? bin : (process.platform === "win32" ? "npx.cmd" : "npx");
  const args = isFile(bin) ? ["browsers", "install", "chrome"] : ["--yes", "puppeteer", "browsers", "install", "chrome"];
  console.log("لم أجد Chrome جاهزًا؛ سيتم تجهيز المتصفح المحلي المطلوب تلقائيًا…");
  const result = spawnSync(command, args, { cwd: ROOT, env: { ...process.env, PUPPETEER_CACHE_DIR: cacheDir }, stdio: "inherit" });
  if (result.error || result.status !== 0) process.exit(result.status || 1);
  executable = puppeteerPath() || cacheSearch();
}
if (!writeMarker(executable)) {
  console.error("تعذر تحديد ملف Chrome بعد التجهيز.");
  process.exit(2);
}
console.log(JSON.stringify({ ok: true, executable, cacheDir }, null, 2));
