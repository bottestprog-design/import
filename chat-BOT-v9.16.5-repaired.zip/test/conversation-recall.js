'use strict';
const assert = require('node:assert/strict');
const recall = require('../src/conversation-recall');

const recent = recall.parseRecallCommand('هات آخر 10 رسائل من أحمد');
assert.deepEqual(recent, { kind: 'recent', targetQuery: 'احمد', count: 10, scanLimit: 10 });
const search = recall.parseRecallCommand('ابحث في محادثة أحمد عن الفاتورة');
assert.deepEqual(search, { kind: 'search', targetQuery: 'احمد', query: 'الفاتوره', scanLimit: 500 });
assert.equal(recall.parseRecallCommand('احذف رسائل أحمد'), null);
assert.equal(recall.parseRecallCommand('هات آخر 99 رسالة من أحمد').count, 50);

const session = {
  recipients: [
    { id: 'a', name: 'أحمد', phone: '+96891234567' },
    { id: 'b', name: 'أحمد سالم', phone: '+96892345678' },
    { id: 'c', name: 'أحمد', phone: '+96893456789' },
  ],
  groups: [{ id: 'g1', name: 'فريق العمل', gid: '120363001234567890@g.us' }],
};
assert.equal(recall.resolveRegisteredTarget(session, 'أحمد سالم').target.key, 'r:b');
assert.equal(recall.resolveRegisteredTarget(session, 'أحمد').status, 'ambiguous');
assert.equal(recall.resolveRegisteredTarget(session, 'شخص غير مسجل').status, 'not-registered');
assert.equal(recall.resolveRegisteredTarget(session, 'البوت', '96891234567@c.us').target.key, 'self');
assert.equal(recall.resolveRegisteredTarget(session, 'فريق العمل').target.isGroup, true);

const target = { key: 'r:a', label: 'أحمد', type: 'recipient' };
const row = recall.rowFromMessage({ id: { $1: 'msg-1' }, timestamp: 1792944000, fromMe: false, body: 'أرسل الفاتورة', type: 'chat', hasMedia: true, _data: { mimetype: 'application/pdf', filename: 'invoice.pdf', notifyName: 'أحمد' } }, target, '96891234567@c.us');
assert.equal(row.messageId, 'msg-1');
assert.equal(row.targetKey, 'r:a');
assert.equal(row.hasMedia, true);
const serializedOutgoingRow = recall.rowFromMessage({ id: { _serialized: 'true_96890000000@lid_msg1' }, timestamp: 1792944000, fromMe: false, body: 'رد البوت' }, target, '96890000000@lid');
assert.equal(serializedOutgoingRow.fromMe, true, 'serialized outgoing IDs should keep owner/bot messages classified as outgoing');
const fallbackRow = recall.rowFromMessage({ timestamp: 1792944000, body: 'رسالة بلا معرّف', fromMe: false }, target, '96891234567@c.us');
assert.match(fallbackRow.messageId, /^[a-f0-9]{40}$/);
assert.equal(recall.rowFromMessage({ timestamp: 1792944000, body: 'رسالة بلا معرّف', fromMe: false }, target, '96891234567@c.us').messageId, fallbackRow.messageId, 'missing IDs need deterministic de-duplication keys');
const formatted = recall.formatRecallRows([row], { query: 'الفاتورة', targetLabel: 'أحمد' });
assert.equal(formatted.count, 1);
assert.match(formatted.text, /أرسل الفاتورة/);
assert.match(formatted.text, /invoice\.pdf/);

console.log('conversation-recall: ok (fixed Arabic command grammar, registered-target-only lookup, ambiguous-name stop, bounded counts, media metadata, and history formatting)');
