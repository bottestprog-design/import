'use strict';
const assert = require('node:assert/strict');
const targets = require('../src/conversation-targets');
const session = {
  recipients: [{ id: 'a', name: 'أحمد', digits: '96890000000', e164: '+96890000000', whatsappJid: '96890000000@c.us' }],
  groups: [{ id: 'g1', name: 'الفريق', gid: '120363123456789@g.us' }],
};
assert.equal(targets.targetKeyForChat(session, '96890000000@c.us', '96899999999@c.us'), 'r:a');
assert.equal(targets.targetKeyForChat(session, '120363123456789@g.us', ''), 'g:g1');
assert.equal(targets.targetKeyForChat(session, '96891111111@c.us', ''), '', 'unregistered chats must not enter archive searches');
assert.equal(targets.targetKeyForChat(session, '96899999999@c.us', '96899999999@c.us'), 'self');
assert.equal(targets.allowedTarget(session, 'r:a').chatId, '96890000000@c.us');
assert.equal(targets.allowedTarget(session, 'r:missing'), null);
assert.equal(targets.allowedTarget(session, 'g:g1').chatId, '120363123456789@g.us');
assert.equal(targets.allowedTarget(session, 'g:missing'), null);
assert.deepEqual(targets.listRegisteredTargets(session).map(x => x.key), ['self', 'r:a', 'g:g1']);
console.log('conversation-targets: ok (self, saved people/groups and strict rejection of unregistered chats)');
