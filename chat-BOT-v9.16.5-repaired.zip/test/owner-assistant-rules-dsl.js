'use strict';
const assert = require('node:assert/strict');
const { OwnerAssistant } = require('../src/owner-assistant');
function rig() {
  let stored = { id:'main', name:'test', recipients:[], groups:[], settings:{ interactionEnabled:true, interactionFallbackEnabled:false, voiceAutoTranscribeEnabled:true, smartReplyEnabled:false }, interaction:{ enabled:true, rules:[] }, automation:{ tasks:[] }, logs:[], ownerAssistant:{ flow:null, recent:[] } };
  const sent=[];
  const store={ safeSessionId:x=>x||'main', loadSession:()=>JSON.parse(JSON.stringify(stored)), saveSession:s=>(stored=JSON.parse(JSON.stringify(s))), get current(){return JSON.parse(JSON.stringify(stored));} };
  const whatsapp={ selfChatId:()=> '96890000000@c.us', listRuntime:()=>({ready:true,status:'ready'}), sendText:async(_sid,chatId,text)=>{sent.push({chatId,text});return {ok:true};}, resolveChatId:async(_sid,d)=>`${d.digits||'96890000000'}@c.us`, listContacts:async()=>[] };
  const phones={parse:value=>({digits:String(value).replace(/\D/g,''),e164:`+${String(value).replace(/\D/g,'')}`,international:String(value),phone:String(value),country:'OM'})};
  const assistant=new OwnerAssistant({store,whatsapp,phones,log:()=>{},audioTranscriber:null,localLlm:null,delivery:{files:()=>[]}});
  return { assistant, store, sent };
}
async function send(r, body){ return r.assistant.handleSelfChatMessage('main',{body}); }
(async()=>{
 const help=rig(); const helpResult=await send(help,'مساعدة القواعد');
 assert.equal(helpResult.action,'rule-language-help'); assert.match(help.sent.at(-1).text,/قاعدة تفاعل/);
 const r=rig();
 const cmd=`قاعدة تفاعل\nاسم: ترحيب خاص\nعندما: تحتوي الرسالة على {السلام عليكم}\nمطابقة: يحتوي\nرد: وعليكم السلام يا {{sender}}\nنطاق: الخاص\nتهدئة: 30`;
 const draft=await send(r,cmd);
 assert.equal(draft.action,'chat-rule-draft'); assert.equal(r.store.current.interaction.rules.length,0,'rules must not be saved before explicit confirmation');
 assert.equal(r.store.current.ownerAssistant.flow.type,'chat-rule'); assert.equal(r.store.current.ownerAssistant.flow.step,'confirm');
 assert.match(r.sent.at(-1).text,/لم أحفظ القاعدة بعد/); assert.match(r.sent.at(-1).text,/المحادثات الخاصة فقط/);
 await send(r,'تمام'); assert.equal(r.store.current.interaction.rules.length,0,'generic confirmations must not save a rule');
 await send(r,'تأكيد القاعدة');
 assert.equal(r.store.current.interaction.rules.length,1); const rule=r.store.current.interaction.rules[0];
 assert.equal(rule.when.value,'السلام عليكم'); assert.equal(rule.when.match,'contains'); assert.equal(rule.scope,'private'); assert.equal(rule.cooldownSec,30); assert.equal(rule.then.reply,'وعليكم السلام يا {{sender}}');
 const cancel=rig(); await send(cancel,'قاعدة تفاعل: عندما=مرحبا؛ رد=أهلا'); await send(cancel,'إلغاء'); assert.equal(cancel.store.current.interaction.rules.length,0); assert.equal(cancel.store.current.ownerAssistant.flow,null);
 const missing=rig(); await send(missing,'قاعدة تفاعل\nعندما: صباح الخير'); assert.equal(missing.store.current.ownerAssistant.flow.step,'reply'); assert.match(missing.sent.at(-1).text,/اكتب الرد/); assert.equal(missing.store.current.interaction.rules.length,0);
 const unknown=rig(); await send(unknown,'قاعدة تفاعل\nعندما: مرحبا\nرد: أهلا\nلون: أزرق'); assert.equal(unknown.store.current.interaction.rules.length,0); assert.match(unknown.sent.at(-1).text,/غير معروف/);
 console.log('owner-assistant-rules-dsl: ok (preview before saving, exact confirmation, fields, cancel, missing values, unknown field rejection)');
})().catch(error=>{console.error(error);process.exitCode=1;});
