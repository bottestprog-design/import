const assert = require('node:assert/strict');
  const { recipientIsPaused } = require('../src/recipient-replies');
  const session = {
    recipients: [
      { id: 'x', name: 'Disabled by phone', e164: '+96890001111', enabled: false },
      { id: 'y', name: 'Paused LID', digits: '96890002222', jid: '96890002222@c.us', enabled: true, paused: true },
      { id: 'z', name: 'Running', digits: '96890003333', enabled: true }
    ],
    groups: [{ id: 'g1', name: 'Muted group', gid: '120363000000001@g.us', enabled: false }]
  };
  assert.equal(recipientIsPaused(session, '96890001111@c.us'), true);
  assert.equal(recipientIsPaused(session, '96890002222@lid'), true);
  assert.equal(recipientIsPaused(session, '120363000000001@g.us'), true);
  assert.equal(recipientIsPaused(session, '96890003333@c.us'), false);
  assert.equal(recipientIsPaused(session, '96890004444@c.us'), false);
  console.log('recipient-paused: ok');
  