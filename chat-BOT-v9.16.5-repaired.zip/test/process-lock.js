'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { acquireProcessLock } = require('../src/process-lock');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-process-lock-'));
try {
  const lock = path.join(root, '.runtime', 'server.lock');
  fs.mkdirSync(path.dirname(lock), { recursive: true });
  fs.writeFileSync(lock, JSON.stringify({ pid: 2147483647, token: 'stale', startedAt: new Date(0).toISOString() }));
  const owner = acquireProcessLock(lock);
  const record = JSON.parse(fs.readFileSync(lock, 'utf8'));
  assert.equal(record.pid, process.pid, 'stale locks must be replaced by the active process');
  assert.equal(record.token.length > 10, true, 'lock ownership token must be unique');
  assert.throws(() => acquireProcessLock(lock), error => error.code === 'CHATBOT_ALREADY_RUNNING' && /نسخة أخرى/.test(error.message));
  owner.release();
  assert.equal(fs.existsSync(lock), false, 'only the lock owner may release its lock');
  console.log('process-lock: ok (stale PID recovery, duplicate server prevention, owner-only release)');
} finally { fs.rmSync(root, { recursive: true, force: true }); }
