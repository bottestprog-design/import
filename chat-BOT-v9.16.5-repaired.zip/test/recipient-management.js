'use strict';
const assert = require('node:assert/strict');
const { deleteRecipients } = require('../src/recipient-management');

const session = {
  recipients: [
    { id: 'a', name: 'أحمد', digits: '96890000000' },
    { id: 'b', name: 'سارة', e164: '+96891111111' },
    { id: 'c', name: 'مريم', digits: '96892222222' },
  ],
  settings: { scheduleTargetKeys: ['r:a', 'r:b', 'r:c', 'g:g1'], interactionChatIds: ['96890000000@c.us', '96891111111@c.us', 'external@c.us'] },
  automation: {
    tasks: [{ id: 'task', targetKeys: ['r:a', 'r:b', 'g:g1'] }, { id: 'task-empty', targetKeys: ['r:c'] }],
    rules: [{ id: 'rule', targetKeys: ['r:a', 'r:c', 'g:g1'], targetChatIds: ['96890000000@c.us', 'external@c.us'] }],
  },
  interaction: { contextByChat: { '96890000000@c.us': { count: 1 }, 'external@c.us': { count: 2 } }, counterState: { byChat: { '96891111111@c.us': { count: 1 } } } },
};
const result = deleteRecipients(session, ['a', 'b', 'a', 'not-there']);
assert.deepEqual(result.removedIds.sort(), ['a', 'b']);
assert.deepEqual(session.recipients.map(x => x.id), ['c']);
assert.deepEqual(session.settings.scheduleTargetKeys, ['r:c', 'g:g1']);
assert.deepEqual(session.settings.interactionChatIds, ['external@c.us']);
assert.deepEqual(session.automation.tasks.map(x => x.targetKeys), [['g:g1'], ['r:c']]);
assert.deepEqual(session.automation.rules[0].targetKeys, ['r:c', 'g:g1']);
assert.deepEqual(session.automation.rules[0].targetChatIds, ['external@c.us']);
assert.equal(session.interaction.contextByChat['96890000000@c.us'], undefined);
assert.equal(session.interaction.counterState.byChat['96891111111@c.us'], undefined);
assert.throws(() => deleteRecipients(session, []), /حدد/);
assert.throws(() => deleteRecipients(session, ['missing']), /العثور/);
const onlyScheduledRecipient = { recipients: [{ id: 'last', phone: '96890000000' }], settings: { scheduleEnabled: true, scheduleTargetKeys: ['r:last'] }, automation: { tasks: [], rules: [] }, interaction: {} };
const lastDelete = deleteRecipients(onlyScheduledRecipient, ['last']);
assert.equal(lastDelete.scheduleDisabledToPreventWidening, true);
assert.equal(onlyScheduledRecipient.settings.scheduleEnabled, false, 'a schedule should stop rather than silently broaden to all remaining targets');
assert.deepEqual(onlyScheduledRecipient.settings.scheduleTargetKeys, []);
console.log('recipient-management: ok (bulk delete, duplicate ids, schedule/task/rule cleanup and chat-state cleanup)');
