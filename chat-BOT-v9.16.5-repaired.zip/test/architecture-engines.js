"use strict";
const assert = require('node:assert/strict');
const { EventBus } = require('../src/event-bus');
const { CommandEngine } = require('../src/command-engine');
const { DictionaryEngine } = require('../src/dictionary-engine');
const { parseVoiceCommand } = require('../src/voice-to-command');
(async () => {
  const bus = new EventBus({ maxHistory: 2 }); let seen = 0; bus.subscribe('message.received', async e => { seen++; assert.equal(e.payload.chatId, 'c1'); });
  await bus.publish('message.received', { chatId: 'c1' }); await bus.publish('x'); await bus.publish('y'); assert.equal(seen, 1); assert.equal(bus.history.length, 2); assert.equal(bus.stats().queued, 0);
  const commands = new CommandEngine(); commands.register('status', { ownerOnly: true, handler: () => 'ok' });
  assert.equal((await commands.execute('!status', { isOwner: false })).error, 'owner-only'); assert.equal((await commands.execute('!status', { isOwner: true })).result, 'ok'); assert.equal((await commands.execute('hello')).handled, false);
  const dict = new DictionaryEngine(); dict.upsert({ term: 'مرحبا', aliases: ['اهلا'], definition: 'تحية' }); assert.equal(dict.lookup('اهلا').definition, 'تحية'); assert.equal(dict.lookup('مرحب').term, 'مرحبا');
  assert.equal(parseVoiceCommand('اكتم احمد').intent, 'mute'); assert.equal(parseVoiceCommand('احذف الرسالة').requiresConfirmation, true); assert.equal(parseVoiceCommand('الحالة', { confidence: .2 }).accepted, false);
  bus.close(); console.log('architecture-engines: ok');
})().catch(e => { console.error(e); process.exit(1); });
