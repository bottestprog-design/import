'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { OwnerAssistant, WELCOME_GUIDE, isConfirm } = require('../src/owner-assistant');

const clone = value => JSON.parse(JSON.stringify(value));
function createHarness() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-owner-assistant-'));
  const original = {
    id: 'main', name: 'الجلسة الرئيسية', setupComplete: true,
    recipients: [{ id: 'ahmed', name: 'أحمد', digits: '96890000000', e164: '+96890000000', international: '+968 9000 0000', enabled: true }],
    groups: [], logs: [], settings: { automationEnabled: true },
    interaction: { rules: [], enabled: true }, automation: { tasks: [], enabled: true },
  };
  let saved = clone(original);
  const store = {
    safeSessionId: value => String(value || 'main'),
    loadSession: () => clone(saved),
    saveSession: session => { saved = clone(session); return clone(saved); },
    normalizeAutomationTask: task => ({ ...clone(task), id: task.id || 'task-1', targetKeys: [...(task.targetKeys || [])] }),
    getPaths: () => ({ dir: root, profiles: path.join(root, 'profiles') }),
    cleanup: () => fs.rmSync(root, { recursive: true, force: true }),
    get current() { return clone(saved); },
  };
  const sent = [];
  const contactCalls = [];
  const whatsapp = {
    selfChatId: () => '15555555555@c.us',
    listRuntime: () => ({ ready: true, status: 'ready' }),
    sendText: async (id, chatId, text) => { sent.push({ id, chatId, text }); return { __chatBotAck: { status: 'accepted' } }; },
    resolveChatId: async (_id, data) => `${String(data.phone || '96895555555')}@c.us`,
    listContacts: async (_id, opts) => { contactCalls.push(opts); return [{ jid: '96897777777@c.us', digits: '96897777777', name: 'جهة واتساب', isMyContact: true }]; },
  };
  const phones = { parse: value => {
    const digits = String(value).replace(/\D/g, '');
    if (digits.length < 8) throw new Error('رقم غير صالح للاختبار');
    return { digits, e164: `+${digits}`, international: `+${digits}`, formatted: `+${digits}`, national: digits, country: 'OM', callingCode: '968' };
  } };
  const assistant = new OwnerAssistant({ store, whatsapp, phones, log: () => {} });
  return { assistant, store, whatsapp, phones, sent, contactCalls };
}
async function send(h, body) { return h.assistant.handleSelfChatMessage('main', { body, fromMe: true }); }
(async () => {
  const h = createHarness();
  assert.equal(isConfirm('تأكيد الإرسال'), true, 'Arabic confirmation with hamza must work after normalization');
  assert.equal(await h.assistant.maybeSendWelcome('main'), true);
  assert.match(h.sent[0].text, /الرسائل إلى نفسك/);
  assert.equal(await h.assistant.maybeSendWelcome('main'), false, 'welcome guide must not be repeated on every status event');
  const concurrent = createHarness();
  const welcomeResults = await Promise.all([concurrent.assistant.maybeSendWelcome('main'), concurrent.assistant.maybeSendWelcome('main')]);
  assert.equal(welcomeResults.filter(Boolean).length, 1, 'concurrent ready events must only send one welcome');
  assert.equal(concurrent.sent.filter(item => item.text.startsWith(WELCOME_GUIDE)).length, 1);
  assert.match(concurrent.sent[0].text, /انطق آخر رد/, 'bot replies should include the subtle text-to-speech hint');
  concurrent.store.cleanup();

  await send(h, 'عايز أضيف شخص جديد');
  await send(h, 'ليلى');
  await send(h, 'عمان');
  await send(h, '+96891234567');
  assert.ok(h.store.current.recipients.some(person => person.name === 'ليلى' && person.digits === '96891234567'), 'self-chat add-person wizard saves a recipient');

  let chatReadCalls = 0;
  const recallLimits = [];
  h.whatsapp.getChatSafe = async (_id, chatId) => {
    chatReadCalls++;
    return { id: chatId, fetchMessages: async ({ limit }) => {
      recallLimits.push(limit);
      assert.ok(limit > 0 && limit <= 500, 'recall reads are bounded');
      return [{ id: { $1: 'recall-message-1' }, timestamp: 1792944000, fromMe: false, body: 'هذه الفاتورة الشهرية', type: 'chat', hasMedia: false, _data: { notifyName: 'أحمد' } }];
    } };
  };
  const archiveCalls = [];
  h.assistant.conversationArchive = {
    recordMany: (_id, rows) => { archiveCalls.push(...rows); return { stored: rows.length, duplicates: 0, failed: 0 }; },
    search: () => [],
  };
  await send(h, 'ابحث في محادثة أحمد عن الفاتورة');
  assert.match(h.sent.at(-1).text, /هذه الفاتورة الشهرية/);
  assert.equal(archiveCalls.length, 1, 'messages read from a registered chat should enter the local archive');
  const recentRecall = await send(h, 'هات آخر 2 رسائل من أحمد');
  assert.equal(recentRecall.action, 'conversation-recall-recent');
  assert.equal(recallLimits.at(-1), 2, 'recent-message recall must request only the requested bounded number');
  assert.match(h.sent.at(-1).text, /آخر 2 رسائل من «أحمد»/);
  const readsBeforeUnregistered = chatReadCalls;
  await send(h, 'هات آخر 2 رسائل من شخص غير مسجل');
  assert.equal(chatReadCalls, readsBeforeUnregistered, 'unregistered target names must be rejected without reading WhatsApp chats');
  assert.match(h.sent.at(-1).text, /لا أسترجع الرسائل إلا من محادثة/);

  const voiceCalls = [];
  h.whatsapp.sendVoice = async (id, chatId, file) => { voiceCalls.push({ id, chatId, file }); return { __chatBotAck: { status: 'confirmed' } }; };
  h.assistant.speechSynthesizer = {
    status: async () => ({ ready: true, binaryReady: true, modelReady: true, ffmpegReady: true, message: 'محرك الاختبار جاهز.' }),
    generate: async text => ({ wavPath: '/tmp/chatbot-tts-test/speech.wav', directory: '/tmp/chatbot-tts-test', text, proofreadUsed: true }),
    toWhatsAppVoice: async () => '/tmp/chatbot-tts-test/voice.ogg',
    cleanup: () => true,
  };
  await send(h, 'انطق آخر رد');
  assert.equal(voiceCalls.length, 1, 'the speech command should send one generated OGG/Opus voice message');
  assert.equal(voiceCalls[0].chatId, '15555555555@c.us');
  await send(h, 'فحص النطق');
  assert.match(h.sent.at(-1).text, /محرك النطق المحلي: جاهز/);
  const countBeforePreview = voiceCalls.length;
  await send(h, 'اختبر النطق');
  assert.equal(voiceCalls.length, countBeforePreview + 1, 'the explicit pronunciation test sends only a preview voice to self-chat');
  assert.match(h.sent.at(-1).text, /عينة النطق إلى محادثة النفس فقط/);
  h.assistant.speechSynthesizer.generate = async text => ({ wavPath: '/tmp/chatbot-tts-test/speech.wav', directory: '/tmp/chatbot-tts-test', text, proofreadUsed: false });
  const voiceCountBeforeBlocked = voiceCalls.length;
  await send(h, 'انطق آخر رد');
  assert.equal(voiceCalls.length, voiceCountBeforeBlocked, 'strict proofreading must block sending an unreviewed voice reply');
  assert.match(h.sent.at(-1).text, /لم أرسل صوتًا غير مكتمل/);

  const priorCount = h.sent.filter(item => item.chatId === '96890000000@c.us').length;
  await send(h, 'أرسل رسالة');
  await send(h, 'أحمد');
  await send(h, 'رسالة اختبار آمنة');
  assert.equal(h.sent.filter(item => item.chatId === '96890000000@c.us').length, priorCount, 'message is not sent before confirmation');
  await send(h, 'تأكيد الإرسال');
  assert.equal(h.sent.filter(item => item.chatId === '96890000000@c.us' && item.text === 'رسالة اختبار آمنة').length, 1, 'confirmation triggers exactly one send');
  assert.equal(h.store.current.ownerAssistant.flow, null);

  await send(h, 'أنشئ موعد');
  await send(h, 'أحمد');
  await send(h, 'رسالة موعد');
  await send(h, 'يومي');
  await send(h, '17:30');
  await send(h, 'تأكيد الحفظ');
  assert.equal(h.store.current.automation.tasks.length, 1, 'schedule wizard stores the task only after confirmation');
  assert.deepEqual(h.store.current.automation.tasks[0].targetKeys, ['r:ahmed']);

  await send(h, 'أنشئ رد تلقائي');
  await send(h, 'حالة الطلب');
  await send(h, 'سيتم التحقق من طلبك');
  await send(h, 'تأكيد الحفظ');
  assert.ok(h.store.current.interaction.rules.some(rule => rule.when?.value === 'حالة الطلب'), 'auto-reply wizard stores a rule');
  await send(h, 'شخّص الرد التلقائي على: حالة الطلب');
  assert.match(h.sent.at(-1).text, /قواعد طابقت النص/);
  assert.match(h.sent.at(-1).text, /لم يتم إرسال أي رسالة/);

  await send(h, 'استدعاء جهات واتساب');
  await send(h, 'تمام');
  assert.equal(h.store.current.ownerAssistant.flow?.type, 'sync-confirm', 'generic acknowledgement must not run a contact import');
  assert.equal(h.contactCalls.length, 1, 'a generic acknowledgement must not query contacts for the import phase');
  await send(h, 'تأكيد المزامنة');
  assert.ok(h.store.current.recipients.some(person => person.digits === '96897777777'), 'self-chat WhatsApp contact sync imports missing numeric contacts');
  assert.equal(h.contactCalls.length, 2, "preview plus explicitly confirmed sync query WhatsApp contacts");
  assert.equal(h.store.current.ownerAssistant.flow, null);

  let mediaDownloads = 0;
  const requestedMediaTypes = [];
  h.whatsapp.downloadMediaFromChat = async (_id, chatId, limits) => {
    mediaDownloads++;
    requestedMediaTypes.push(limits.mediaType);
    assert.equal(chatId, '96890000000@c.us');
    assert.equal(limits.maxFiles, 100);
    return { chatId, chatName: 'أحمد', scanned: 12, mediaFound: 1, considered: 1, downloaded: [{ filename: 'voice.ogg', bytes: 2048 }], failed: [], skipped: [], mediaDirectory: '/local/media' };
  };
  await send(h, 'استخرج الملفات من محادثة أحمد');
  assert.equal(h.store.current.ownerAssistant.flow?.type, 'download-chat-media');
  await send(h, 'تمام');
  assert.equal(mediaDownloads, 0, 'generic acknowledgement cannot authorize downloading private chat attachments');
  assert.equal(h.store.current.ownerAssistant.flow?.step, 'confirm');
  await send(h, 'تأكيد التنزيل');
  assert.equal(mediaDownloads, 1, 'explicit download confirmation runs the scoped attachment operation once');
  assert.equal(requestedMediaTypes[0], 'all');
  assert.match(h.sent.at(-1).text, /اكتمل فحص المحادثة/);
  await send(h, 'استخرج الصوتيات من محادثة أحمد');
  assert.match(h.sent.at(-1).text, /الصوتيات والرسائل الصوتية/);
  await send(h, 'تمام');
  assert.equal(mediaDownloads, 1, 'a generic acknowledgement must not authorize audio extraction');
  await send(h, 'تأكيد التنزيل');
  assert.equal(mediaDownloads, 2, 'audio-only extraction is supported as a distinct command');
  assert.equal(requestedMediaTypes[1], 'audio', 'the requested attachment filter reaches the WhatsApp downloader');
  assert.equal(h.store.current.ownerAssistant.flow, null);

  await send(h, 'أنشئ موعد');
  await send(h, 'إلغاء');
  assert.equal(h.store.current.ownerAssistant.flow, null, 'cancel abandons any pending wizard');
  h.store.cleanup();
  console.log('owner-assistant: ok (welcome, add-person wizard, explicit send confirmation, scheduling, safe registered-chat recall, Arabic rule diagnostics, local TTS status/preview, auto-reply, contact sync, cancellation)');
})().catch(error => { console.error(error); process.exitCode = 1; });
