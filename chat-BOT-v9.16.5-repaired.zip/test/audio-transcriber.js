'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { AudioTranscriber, safeAudioExtension, allowedLanguage } = require('../src/audio-transcriber');
assert.equal(safeAudioExtension('voice.ogg', ''), '.ogg');
assert.equal(safeAudioExtension('voice.bin', 'audio/opus'), '.opus');
assert.equal(safeAudioExtension('payload.exe', 'application/octet-stream'), '');
assert.equal(allowedLanguage('ar'), 'ar');
assert.throws(() => allowedLanguage('xx'), /لغة التفريغ غير مدعومة/);
// A stale .env path must not mask a working local model installed by the setup script.
{ const root = path.resolve(__dirname, '..'); const small = path.join(root, 'models', 'ggml-small.bin'); const base = path.join(root, 'models', 'ggml-base.bin'); const originalSmall = fs.existsSync(small) ? fs.readFileSync(small) : null; const originalBase = fs.existsSync(base) ? fs.readFileSync(base) : null; const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'whisper-stale-model-')); try { fs.mkdirSync(path.dirname(small), { recursive: true }); fs.writeFileSync(small, 'small'); fs.writeFileSync(base, 'base'); const t = new AudioTranscriber({ env: { WHISPER_MODEL_PATH: path.join(temp, 'missing-ggml-base.bin') }, execFileImpl: async () => ({ stdout: '' }) }); assert.equal(t.config().modelPath, small, 'missing configured model should fall back to installed higher-accuracy local model'); } finally { if (originalSmall) fs.writeFileSync(small, originalSmall); else fs.rmSync(small, { force: true }); if (originalBase) fs.writeFileSync(base, originalBase); else fs.rmSync(base, { force: true }); fs.rmSync(temp, { recursive: true, force: true }); } }
// A stale configured executable path must not mask a local whisper-cli installed by the setup script.
{ const root = path.resolve(__dirname, '..'); const relative = path.join('tools', 'whisper', `whisper-cli${process.platform === 'win32' ? '.exe' : ''}`); const binary = path.join(root, relative); const dir = path.dirname(binary); const hadDir = fs.existsSync(dir); const hadFile = fs.existsSync(binary); const original = hadFile ? fs.readFileSync(binary) : null; const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'whisper-stale-bin-')); try { fs.mkdirSync(dir, { recursive: true }); if (!hadFile) fs.writeFileSync(binary, 'test executable'); const t = new AudioTranscriber({ env: { WHISPER_CPP_BIN: path.join(temp, 'missing-whisper-cli.exe') } }); assert.equal(t.config().binary, binary, 'missing configured binary should fall back to the installed project-local executable'); } finally { if (original) fs.writeFileSync(binary, original); else fs.rmSync(binary, { force: true }); if (!hadDir && fs.existsSync(dir)) { try { fs.rmdirSync(dir); fs.rmdirSync(path.dirname(dir)); } catch {} } fs.rmSync(temp, { recursive: true, force: true }); } }

(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'whisper-transcriber-test-'));
  const modelPath = path.join(dir, 'model.bin'); fs.writeFileSync(modelPath, 'test model');
  const invocations = [];
  const fakeExec = async (binary, args, opts = {}) => {
    invocations.push({ binary, args, opts });
    if (binary === 'which' || binary === 'where.exe') return { stdout: 'whisper-cli' };
    if (binary === 'ffmpeg') { fs.writeFileSync(args.at(-1), Buffer.concat([Buffer.alloc(44), Buffer.from('mock PCM audio')])); return { stdout: '' }; }
    const at = args.indexOf('-of');
    if (at >= 0) fs.writeFileSync(`${args[at + 1]}.txt`, 'مرحبا بك، هذا نص تجريبي.');
    return { stdout: '' };
  };
  try {
    const transcriber = new AudioTranscriber({ env: { WHISPER_BACKEND: 'whisper.cpp', WHISPER_CPP_BIN: 'whisper-cli', WHISPER_MODEL_PATH: modelPath }, execFileImpl: fakeExec, tempDir: dir });
    const status = await transcriber.status();
    assert.equal(status.ready, true);
    const result = await transcriber.transcribeBuffer(Buffer.from('mock audio'), { extension: '.ogg', language: 'ar' });
    assert.equal(result.transcript, 'مرحبا بك، هذا نص تجريبي.');
    assert.equal(result.backend, 'whisper.cpp');
    assert.ok(invocations.some(x => x.args.includes('-l') && x.args[x.args.indexOf('-l') + 1] === 'ar'));
    assert.ok(invocations.some(x => x.binary === 'ffmpeg' && x.args.includes('-ar') && x.args.includes('16000')), 'WhatsApp-style OGG/OPUS should be normalized locally for whisper.cpp');

    assert.ok(invocations.some(x => x.args.includes('-f') && String(x.args[x.args.indexOf('-f') + 1]).endsWith('input-16khz-mono.wav')), 'whisper.cpp should receive the normalized PCM WAV when FFmpeg is available');
    const noFfmpeg = new AudioTranscriber({ env: { WHISPER_BACKEND: 'whisper.cpp', WHISPER_CPP_BIN: 'whisper-cli', WHISPER_MODEL_PATH: modelPath }, execFileImpl: async (binary, args) => {
      if ((binary === 'which' || binary === 'where.exe') && args[0] === 'whisper-cli') return { stdout: 'whisper-cli' };
      if ((binary === 'which' || binary === 'where.exe') && args[0] === 'ffmpeg') throw new Error('not found');
      throw new Error(`unexpected command ${binary}`);
    }, tempDir: dir });
    const noFfmpegStatus = await noFfmpeg.status();
    assert.equal(noFfmpegStatus.engineModelReady, true);
    assert.equal(noFfmpegStatus.voiceNotesReady, false, 'WhatsApp voice-notes readiness requires local FFmpeg conversion');
    assert.equal(noFfmpegStatus.ready, false);
    await assert.rejects(() => noFfmpeg.transcribeBuffer(Buffer.from('mock audio'), { extension: '.ogg', language: 'ar' }), /FFmpeg غير موجود/);

    const message = { type: 'ptt', hasMedia: true, downloadMedia: async () => ({ data: Buffer.from('voice').toString('base64'), mimetype: 'audio/ogg' }) };
    assert.equal(transcriber.rememberIncoming('session', message), true);
    const latest = await transcriber.transcribeLatest('session', { language: 'ar' });
    assert.equal(latest.source, 'whatsapp');
    assert.equal(latest.transcript, 'مرحبا بك، هذا نص تجريبي.');
    assert.equal(transcriber.rememberIncoming('session', { type: 'image', hasMedia: true, downloadMedia: async () => ({}) }), false);
    await assert.rejects(() => transcriber.transcribeLatest('missing'), /لم أعثر على صوتية/);
    console.log('audio-transcriber: ok (language validation, local Whisper command, upload data and latest voice memo)');
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
})().catch(error => { console.error(error); process.exitCode = 1; });
