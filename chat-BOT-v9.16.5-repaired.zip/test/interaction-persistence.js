'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const store = require('../src/store');
const id = `reply-persistence-${Date.now()}`;
try {
  const session = store.loadSession(id);
  session.settings.interactionConflictMode = 'highest-score';
  session.settings.interactionSimilarityThreshold = .73;
  session.interaction.rules.push({ id: 'variants-persist', name: 'رد متعدد', enabled: true, priority: 12, when: { type: 'message', match: 'similarity', value: 'مرحبا' }, then: { reply: 'أهلًا', replies: ['أهلًا', 'نورت'] }, scope: 'all', cooldownSec: 2 });
  session.interaction.counterTriggers.push({ id: 'persist-counter', name: 'عداد محفوظ', enabled: true, threshold: 500, priority: 8, scope: 'session', actionType: 'reply', then: { reply: 'وصلنا {{count}}', replies: ['وصلنا {{count}}'] }, armedAtCount: 20 });
  session.interaction.counterState.totalCount = 23;
  session.interaction.variantState['variants-persist|chat'] = { order: [1], used: [0], last: 0, picks: 1 };
  session.interaction.contextByChat['persist@c.us'] = { lastMessage: 'مرحبا', lastIntent: 'greeting', count: 23 };
  store.saveSession(session);
  const restored = store.loadSession(id);
  assert.equal(restored.schemaVersion, 8);
  assert.equal(restored.settings.interactionConflictMode, 'highest-score');
  assert.equal(restored.settings.interactionSimilarityThreshold, .73);
  assert.deepEqual(restored.interaction.rules.find(rule => rule.id === 'variants-persist').then.replies, ['أهلًا', 'نورت']);
  assert.equal(restored.interaction.counterTriggers.find(trigger => trigger.id === 'persist-counter').threshold, 500);
  assert.equal(restored.interaction.counterState.totalCount, 23);
  assert.equal(restored.interaction.contextByChat['persist@c.us'].lastIntent, 'greeting');
  assert.equal(restored.interaction.variantState['variants-persist|chat'].picks, 1);
  console.log('interaction-persistence: ok (engine settings, variants, counters, context, variation state survive reload)');
} finally {
  fs.rmSync(store.getPaths(id).dir, { recursive: true, force: true });
}
