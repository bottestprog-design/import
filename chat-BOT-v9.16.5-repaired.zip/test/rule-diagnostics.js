'use strict';
const assert = require('node:assert/strict');
const diagnostics = require('../src/rule-diagnostics');

assert.deepEqual(diagnostics.parseDiagnosticCommand('شخّص الرد التلقائي على: السلام عليكم'), { recognized: true, sample: 'السلام عليكم', source: 'rule-diagnostic' });
assert.equal(diagnostics.parseDiagnosticCommand('ليه البوت مش بيرد على: صباح الخير').sample, 'صباح الخير');
assert.equal(diagnostics.parseDiagnosticCommand('أرسل رسالة إلى أحمد').recognized, false);
assert.equal(diagnostics.parseDiagnosticCommand('شخّص الرد التلقائي').sample, '');

const session = {
  settings: { interactionEnabled: true, interactionSmartMatching: true, interactionQuietEnabled: false },
  interaction: { enabled: true, rules: [
    { id: 'r1', name: 'ترحيب', enabled: true, scope: 'all', cooldownSec: 0, when: { type: 'message', match: 'contains', value: 'السلام عليكم' }, then: { reply: 'وعليكم السلام ورحمة الله وبركاته.' } },
    { id: 'r2', name: 'متوقفة', enabled: false, scope: 'groups', when: { type: 'message', match: 'contains', value: 'السلام عليكم' }, then: { reply: 'أهلًا' } },
    { id: 'r3', name: 'رد ناقص', enabled: true, scope: 'all', when: { type: 'message', match: 'contains', value: 'السلام عليكم' }, then: { reply: '{{customer}}' } },
    { id: 'r4', name: 'شيء آخر', enabled: true, scope: 'all', when: { type: 'message', match: 'contains', value: 'فاتورة' }, then: { reply: 'تم الاستلام' } },
  ] }
};
const before = JSON.stringify(session);
const report = diagnostics.diagnose(session, 'السلام عليكم', new Date('2026-10-25T10:00:00Z'));
assert.equal(report.matchedCount, 3);
assert.equal(report.matches.find(x => x.id === 'r1').potentiallyEligible, true);
assert.equal(report.matches.find(x => x.id === 'r2').potentiallyEligible, false);
assert.ok(report.matches.find(x => x.id === 'r2').reasons.includes('القاعدة متوقفة'));
assert.equal(report.matches.find(x => x.id === 'r3').potentiallyEligible, false);
assert.ok(report.matches.find(x => x.id === 'r3').qualityIssues.length > 0);
assert.equal(JSON.stringify(session), before, 'diagnostics must not mutate the session');
assert.match(report.text, /لم يتم إرسال أي رسالة/);
console.log('rule-diagnostics: ok (fixed Arabic command, disabled-rule reasons, placeholder blocking, ranking and no mutations)');
