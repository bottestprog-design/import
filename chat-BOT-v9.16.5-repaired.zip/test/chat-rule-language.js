'use strict';
const assert = require('node:assert/strict');
const { parseRuleCommand, helpText } = require('../src/chat-rule-language');
const multiline = `قاعدة تفاعل
اسم: ترحيب
عندما: تحتوي الرسالة على {السلام عليكم}
مطابقة: يحتوي
رد: وعليكم السلام يا {{sender}}
نطاق: الخاص
تهدئة: 30`;
const parsed = parseRuleCommand(multiline);
assert.equal(parsed.recognized, true);
assert.deepEqual(parsed.invalid, []);
assert.equal(parsed.values.name, 'ترحيب');
assert.equal(parsed.values.trigger, 'السلام عليكم');
assert.equal(parsed.values.reply, 'وعليكم السلام يا {{sender}}');
assert.equal(parsed.values.scope, 'private');
assert.equal(parsed.values.cooldownSec, 30);
const compact = parseRuleCommand('قاعدة تفاعل: عندما=مرحبا؛ رد=أهلًا {{sender}}؛ نطاق=الخاص');
assert.equal(compact.values.trigger, 'مرحبا');
assert.equal(compact.values.reply, 'أهلًا {{sender}}');
assert.equal(compact.values.scope, 'private');
const natural = parseRuleCommand('إذا الرسالة تحتوي على مرحبا رد بـ أهلا وسهلا');
assert.equal(natural.recognized, true);
assert.equal(natural.values.trigger, 'مرحبا');
assert.equal(natural.values.reply, 'أهلا وسهلا');
assert.ok(parseRuleCommand('قاعدة تفاعل\nعندما: مرحبا\nرد: أهلًا\nلون: أزرق').invalid.some(x => x.startsWith('field:')));
assert.ok(parseRuleCommand('قاعدة تفاعل\nعندما: مرحبا\nرد: أهلًا\nنطاق: مكان مجهول').invalid.includes('scope'));
assert.equal(parseRuleCommand('هذه رسالة عادية فقط').recognized, false);
assert.match(helpText(), /تأكيد القاعدة/);
assert.match(helpText(), /نطاق:/);

const ends = parseRuleCommand('قاعدة تفاعل\nعندما: مساء الخير\nمطابقة: ينتهي بـ\nرد: مساء النور');
assert.equal(ends.values.match, 'ends');
const similarity = parseRuleCommand('قاعدة تفاعل\nعندما: اشتقت لك\nمطابقة: تشابه\nعتبة: 0.82\nرد: وأنا أيضًا');
assert.equal(similarity.values.match, 'similarity');
assert.equal(similarity.values.threshold, 0.82);
assert.deepEqual(similarity.invalid, []);
const defaultSimilarity = parseRuleCommand('قاعدة تفاعل\nعندما: صباح الخير\nمطابقة: تقريبي\nرد: صباح النور');
assert.equal(defaultSimilarity.values.threshold, 0.75);
const badThreshold = parseRuleCommand('قاعدة تفاعل\nعندما: مرحبا\nمطابقة: تشابه\nعتبة: 1.5\nرد: أهلًا');
assert.ok(badThreshold.invalid.includes('threshold'));
const invalidRegex = parseRuleCommand('قاعدة تفاعل\nعندما: (a+)+$\nمطابقة: regex\nرد: أهلًا');
assert.ok(invalidRegex.invalid.includes('regex'));
const any = parseRuleCommand('قاعدة تفاعل\nعندما: *\nمطابقة: أي رسالة\nرد: وصلتني رسالة');
assert.equal(any.values.match, 'any');

console.log('chat-rule-language: ok (fixed Arabic DSL, multiline/compact/natural forms, strict unknown fields and validation)');
