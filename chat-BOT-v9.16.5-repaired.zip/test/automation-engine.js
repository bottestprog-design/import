"use strict";
const assert = require('node:assert/strict');
const { AutomationEngine, normalizeAutomationRule, normalizeMute, matchText, getTargets } = require('../src/automation-engine');
const { dueForItem, nextRunForItem } = require('../src/scheduler');

function makeSession() {
  return {
    id: 'test', settings: { timezone: 'UTC', automationEnabled: true, automationGroupPermissions: { allowDeleteMessage: false, allowDeleteChat: false, allowArchive: true, allowMute: true, adminsOnly: false } },
    recipients: [{ id: 'r1', phone: '96891234567', enabled: true, name: 'Contact' }],
    groups: [{ id: 'g1', gid: '120363000000@g.us', name: 'Group', enabled: true, admins: [{ id: '96890000000@c.us', admin: true }], participants: [] }],
    automation: { enabled: true, tasks: [], rules: [], mutes: [], eventState: { totalMessages: 0, byChat: {}, seenMessages: {}, ruleCounts: {} }, recent: [] },
    stats: {},
  };
}
function message(chat, suffix, body = 'مرحبا') {
  return { from: chat, author: '96891230000@c.us', fromMe: false, body, timestamp: Math.floor(Date.now() / 1000), id: { _serialized: `true_${chat}_${suffix}`, remote: chat } };
}
(async () => {
  assert.equal(matchText({ matchMode: 'contains', pattern: 'مرحبا' }, 'أهلًا مرحبا بك'), true);
  assert.equal(matchText({ matchMode: 'starts', pattern: 'أهلًا' }, 'أهلًا بك'), true);
  assert.equal(matchText({ matchMode: 'ends', pattern: 'بك' }, 'أهلًا بك'), true);
  assert.equal(matchText({ matchMode: 'exact', pattern: 'مرحبا' }, 'مرحبا'), true);
  assert.equal(matchText({ matchMode: 'regex', pattern: '^مرحب[اًا]' }, 'مرحبا'), true);
  assert.equal(matchText({ matchMode: 'regex', pattern: '[' }, 'anything'), false);

  const base = makeSession();
  assert.throws(() => normalizeAutomationRule({ name: 'unsafe', triggerType: 'message', action: 'delete-message', matchMode: 'any' }, base), /تأكيد/);
  const deleteRule = normalizeAutomationRule({ name: 'delete matched message', triggerType: 'message', action: 'delete-message', matchMode: 'contains', pattern: 'مرحبا', confirmDestructive: true, targetMode: 'current' }, base);
  assert.equal(deleteRule.action, 'delete-message');
  const ageRule = normalizeAutomationRule({ name: 'retention', triggerType: 'message-age', action: 'log', mode: 'daily', time: '22:00', targetMode: 'all', confirmDestructive: true }, base);
  assert.equal(ageRule.action, 'cleanup-old-messages');

  const temporary = normalizeMute({ chatId: '96891234567@c.us', mode: 'temporary', minutes: 10 });
  assert.equal(temporary.mode, 'temporary');
  assert.ok(new Date(temporary.expiresAt).getTime() > Date.now());
  const permanent = normalizeMute({ chatId: '120363000000@g.us', mode: 'permanent' });
  assert.equal(permanent.mode, 'permanent');
  assert.equal(permanent.expiresAt, '');
  assert.throws(() => normalizeMute({ chatId: 'not-a-jid', mode: 'permanent' }), /غير صالح/);

  assert.deepEqual(getTargets(base, { targetMode: 'all', targetKeys: [], targetChatIds: [] }, '' ).sort(), ['120363000000@g.us', '96891234567@c.us']);
  const schedulerItem = { id: 'daily', enabled: true, mode: 'daily', time: '22:00', timezone: 'UTC', lastRunKey: '' };
  const due = dueForItem(new Date('2026-10-22T22:02:00.000Z'), schedulerItem);
  assert.equal(due.due, true);
  assert.equal(dueForItem(new Date('2026-10-22T22:02:00.000Z'), { ...schedulerItem, lastRunKey: due.key }).due, false);
  assert.equal(nextRunForItem({ ...schedulerItem, time: '23:59' }, new Date('2026-10-22T22:00:00.000Z'))?.slice(0, 10), '2026-10-22');

  let session = makeSession();
  const store = { loadSession: () => session, saveSession: s => { session = s; return s; } };
  const executed = { deleted: 0, chatActions: [] };
  const whatsapp = {
    deleteMessage: async (_id, msg, opts) => { executed.deleted++; return { messageId: msg.id._serialized, everyone: opts.everyone }; },
    actOnChat: async (_id, id, action) => { executed.chatActions.push([id, action]); return { action }; },
    deleteMessagesOlderThan: async (_id, id, cutoff, opts) => ({ chatId: id, cutoff, deleted: 2, failed: 0, everyone: opts.everyone }),
  };
  const engine = new AutomationEngine({ store, whatsapp });
  session.automation.rules.push(deleteRule);
  const r = await engine.handleMessage('test', message('96890001111@c.us', 'one', 'رسالة مرحبا'));
  assert.equal(r.handled, true);
  assert.equal(executed.deleted, 1);
  assert.equal(session.automation.eventState.totalMessages, 1);

  session = makeSession();
  const counter = normalizeAutomationRule({ name: 'threshold', triggerType: 'message-count', action: 'archive-chat', threshold: 2, countScope: 'chat', targetMode: 'current' }, session);
  session.automation.rules.push(counter);
  const engine2 = new AutomationEngine({ store, whatsapp });
  const one = await engine2.handleMessage('test', message('96890002222@c.us', 'two', 'hello'));
  const two = await engine2.handleMessage('test', message('96890002222@c.us', 'three', 'hello'));
  assert.equal(one.handled, false);
  assert.equal(two.handled, true);
  assert.deepEqual(executed.chatActions.at(-1), ['96890002222@c.us', 'archive']);

  session = makeSession();
  const groupPermissionRule = normalizeAutomationRule({ name: 'blocked group delete', triggerType: 'group-message', action: 'delete-message', pattern: 'مرحبا', matchMode: 'contains', targetMode: 'current', confirmDestructive: true }, session);
  session.automation.rules.push(groupPermissionRule);
  const engine3 = new AutomationEngine({ store, whatsapp });
  const previousDeleted = executed.deleted;
  await engine3.handleMessage('test', message('120363000000@g.us', 'four', 'مرحبا'));
  assert.equal(executed.deleted, previousDeleted, 'group destructive action should be blocked unless owner enables group delete permission');

  console.log('PASS automation triggers, destructive confirmation, message actions, recurring scheduler, mutes, group permissions and message counters');
})().catch(error => { console.error(error); process.exitCode = 1; });
