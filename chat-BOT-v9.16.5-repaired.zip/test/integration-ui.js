'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'public/app.js'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const hub = fs.readFileSync(path.join(root, 'src/integration-hub.js'), 'utf8');
const agent = fs.readFileSync(path.join(root, 'src/integration-agent.js'), 'utf8');
for (const [label, pattern] of [
  ['device enrollment UI', /createAgentEnrollmentBtn/], ['one-time token copy UI', /copyIntegrationAgentCommand/],
  ['agent revocation UI', /data-revoke-agent/], ['safe plugin manifest UI', /integrationPluginManifest/],
  ['plugin create and connect actions', /addIntegrationPluginBtn[\s\S]*data-connect-plugin/],
  ['320-case report UI', /downloadIntegrationReport[\s\S]*actualTargetProbes/],
  ['connection credential editor', /data-edit-integration-credentials/],
]) { assert.match(app, pattern, label); }
for (const route of ['/api/integrations/devices/enroll', '/api/integrations/agents/claim', '/api/integrations/agents/heartbeat', '/api/integrations/agents/tasks', '/api/integrations/agents/result', '/api/integrations/plugins']) assert.ok(server.includes(route), `missing route ${route}`);
assert.match(hub, /AES-256-GCM|aes-256-gcm/i); assert.match(hub, /timingSafeEqual/); assert.match(agent, /--allow-root/); assert.match(agent, /shell:\s*false/);
console.log('integration-ui: ok (device pairing UI, plugin management, credential controls, integration reports and backend routes)');
