'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { DeliveryService } = require('../src/delivery');

const clone = value => JSON.parse(JSON.stringify(value));
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jH9sAAAAASUVORK5CYII=', 'base64');
(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-send-media-'));
  try {
    const mediaDir = path.join(root, 'media'); fs.mkdirSync(mediaDir, { recursive: true });
    const imageFile = path.join(mediaDir, 'img.1.png'); fs.writeFileSync(imageFile, PNG);
    const source = fs.readFileSync(path.join(__dirname, '..', 'src', 'whatsapp.js'), 'utf8');
    assert.match(source, /MessageMedia\.fromFilePath\(file\)/, 'real send path must construct a WhatsApp media payload from the local file');
    assert.match(source, /target\.digits/, 'legacy recipient records with digits alone must still resolve');
    assert.match(source, /!fs\.existsSync\(file\)/, 'media sending must report missing files before calling WhatsApp');

    const person = { id: 'r1', name: 'جهة تجريبية', digits: '96890000000', e164: '+96890000000', enabled: true };
    let saved = {
      id: 'main', recipients: [person], groups: [], settings: { timezone: 'Asia/Muscat', sendDelayMs: 0, retryAttempts: 1, retryDelayMs: 250, sendTimeoutMs: 5000, maxImageSizeMB: 100, preText: '', postText: '', scheduledGroupsEnabled: true },
      cycle: { round: 1, currentIndex: 0, imageOrder: [], delivery: {}, manualGuard: {} },
      stats: { sentMessages: 0, sentImages: 0, sentFiles: 0, confirmedAcks: 0, createdSends: 0, uncertainSends: 0, failedSends: 0, successfulRuns: 0, failedRuns: 0 },
    };
    const deliveryStore = {
      safeSessionId: value => String(value || 'main'),
      loadSession: () => clone(saved), saveSession: value => { saved = clone(value); return clone(saved); },
      getPaths: () => ({ dir: root, media: mediaDir, images: mediaDir }),
    };
    const sent = [];
    const fakeWhatsApp = {
      ensureReady: async () => true,
      resolveChatId: async (_id, target) => `${target.digits}@c.us`,
      sendText: async (_id, chatId, text) => { sent.push({ kind: 'text', chatId, text }); return { __chatBotAck: { status: 'confirmed' } }; },
      sendMedia: async (_id, chatId, file) => { sent.push({ kind: 'media', chatId, file }); return { __chatBotAck: { status: 'confirmed' } }; },
    };
    const delivery = new DeliveryService({ store: deliveryStore, whatsapp: fakeWhatsApp, log: () => {} });
    const report = await delivery.sendNow('main', { targetKeys: ['r:r1'], mediaIds: ['img.1.png'], preText: 'اختبار الإرسال', repeatGuard: false });
    assert.equal(report.sent.length, 1);
    assert.equal(report.failed.length, 0);
    assert.deepEqual(sent.map(x => x.kind), ['text', 'media']);
    assert.equal(saved.stats.sentMessages, 1);
    assert.equal(saved.stats.sentImages, 1);
    sent.length = 0;
    const imageFirst = await delivery.sendNow('main', { targetKeys: ['r:r1'], mediaIds: ['img.1.png'], preText: 'النص بعد الصورة', sendOrder: 'image-first', repeatGuard: false });
    assert.equal(imageFirst.failed.length, 0);
    assert.deepEqual(sent.map(x => x.kind), ['media', 'text'], 'image-first must change order inside each recipient sequence, not only the outer loop');
    sent.length = 0;
    const failedWhatsApp = { ...fakeWhatsApp, sendText: async () => { throw Object.assign(new Error('Forbidden: permission denied (HTTP 403)'), { statusCode: 403 }); } };
    const failingDelivery = new DeliveryService({ store: deliveryStore, whatsapp: failedWhatsApp, log: () => {} });
    const failedReport = await failingDelivery.sendNow('main', { targetKeys: ['r:r1'], preText: 'اختبار الأذونات', repeatGuard: false });
    assert.equal(failedReport.failed.length, 1);
    assert.equal(failedReport.failed[0].code, 'WHATSAPP_PERMISSION_DENIED');
    assert.equal(failedReport.failed[0].retryable, false);
    assert.match(failedReport.failed[0].error, /الصلاحيات أو قيود الحساب/);
    console.log('send-media: ok (legacy targets, text/media path, image-first ordering, and actionable permission failures)');
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
})().catch(error => { console.error(error); process.exitCode = 1; });
