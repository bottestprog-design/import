'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createEncryptedBackup, decryptAndValidateBackup, restoreValidatedBackup, safeRelativePath, PASSWORD_MIN } = require('../src/local-backup');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-backup-test-'));
const restored = `${root}-restored`;
const password = 'A-strong-backup-password-For-Local-Only-2026!';
try {
  fs.mkdirSync(path.join(root, 'sessions', 'main', 'auth', 'Default'), { recursive: true });
  fs.mkdirSync(path.join(root, 'sessions', 'main', 'media'), { recursive: true });
  fs.writeFileSync(path.join(root, 'active-session'), 'main', 'utf8');
  fs.writeFileSync(path.join(root, 'sessions', 'main', 'session.json'), JSON.stringify({ id: 'main', name: 'جلسة تجريبية' }), 'utf8');
  fs.writeFileSync(path.join(root, 'sessions', 'main', 'auth', 'Default', 'Preferences'), 'PRIVATE-WHATSAPP-AUTH', 'utf8');
  fs.writeFileSync(path.join(root, 'sessions', 'main', 'media', 'sample.dat'), Buffer.from([0, 1, 2, 250, 255]));
  fs.mkdirSync(path.join(root, '_temp'), { recursive: true });
  fs.writeFileSync(path.join(root, '_temp', 'private-temp.txt'), 'never include this', 'utf8');
  fs.mkdirSync(path.join(root, 'sessions', 'main', '_temp'), { recursive: true });
  fs.writeFileSync(path.join(root, 'sessions', 'main', '_temp', 'nested-temp.txt'), 'also excluded', 'utf8');

  const made = createEncryptedBackup(root, password, '9.16.5');
  assert.ok(Buffer.isBuffer(made.buffer));
  assert.ok(made.buffer.subarray(0, 8).toString('ascii') === 'CBOTBK01');
  assert.equal(made.fileCount, 4, 'includes session records and auth profile but excludes transient temp data');
  assert.equal(made.buffer.includes(Buffer.from('PRIVATE-WHATSAPP-AUTH')), false, 'archive contents are encrypted');
  assert.throws(() => createEncryptedBackup(root, 'short'), /كلمة مرور/);
  fs.mkdirSync(path.join(root, 'unsupported-folder'), { recursive: true });
  fs.writeFileSync(path.join(root, 'unsupported-folder', 'secret.json'), '{}', 'utf8');
  assert.throws(() => createEncryptedBackup(root, password), /لا يمكن استعادته بأمان/);
  fs.rmSync(path.join(root, 'unsupported-folder'), { recursive: true, force: true });
  assert.throws(() => decryptAndValidateBackup(made.buffer, 'wrong-password-123'), /كلمة المرور/);
  const damaged = Buffer.from(made.buffer); damaged[damaged.length - 1] ^= 0xff;
  assert.throws(() => decryptAndValidateBackup(damaged, password), /كلمة المرور/);
  assert.equal(safeRelativePath('../outside.txt'), false);
  assert.equal(safeRelativePath('sessions/main/../../outside.txt'), false);
  assert.equal(safeRelativePath('/tmp/evil'), false);
  assert.equal(safeRelativePath('sessions'), false, 'the sessions directory cannot also be restored as a regular file');
  assert.equal(safeRelativePath('sessions/CON/session.json'), false, 'Windows reserved directory names are rejected');
  assert.equal(safeRelativePath('system.log'), true);
  assert.equal(safeRelativePath('sessions/main/session.json'), true);
  assert.ok(PASSWORD_MIN >= 12);

  const unpacked = decryptAndValidateBackup(made.buffer, password);
  assert.equal(unpacked.fileCount, 4);
  fs.mkdirSync(path.join(restored, 'sessions', 'old'), { recursive: true });
  fs.writeFileSync(path.join(restored, 'sessions', 'old', 'session.json'), 'old data', 'utf8');
  const outcome = restoreValidatedBackup(restored, unpacked);
  assert.equal(outcome.fileCount, 4);
  assert.equal(fs.readFileSync(path.join(restored, 'active-session'), 'utf8'), 'main');
  assert.equal(fs.readFileSync(path.join(restored, 'sessions', 'main', 'auth', 'Default', 'Preferences'), 'utf8'), 'PRIVATE-WHATSAPP-AUTH');
  assert.equal(fs.readFileSync(path.join(restored, 'sessions', 'main', 'media', 'sample.dat'))[4], 255);
  assert.equal(fs.existsSync(path.join(restored, 'sessions', 'old')), false, 'restore replaces rather than silently merges old state');
  assert.equal(fs.existsSync(path.join(restored, '_temp')), true, 'fresh temp directory is recreated');
  console.log('local-backup: ok (password encryption, authentication and media inclusion, temp exclusion, tamper/wrong-password rejection, path validation and replacement restore)');
} finally {
  fs.rmSync(root, { recursive: true, force: true });
  fs.rmSync(restored, { recursive: true, force: true });
  fs.rmSync(`${restored}-does-not-exist`, { recursive: true, force: true });
}
