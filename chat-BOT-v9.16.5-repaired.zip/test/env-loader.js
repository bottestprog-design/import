'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { parseEnv, loadEnv } = require('../src/env-loader');
const parsed = parseEnv('\uFEFF# comment\nPORT=7005 # port\nexport NAME="hello world"\nTOKEN=\'abc#123\'\nMULTI="a\\nb"\nnot-an-env-line\n');
assert.equal(parsed.PORT, '7005');
assert.equal(parsed.NAME, 'hello world');
assert.equal(parsed.TOKEN, 'abc#123');
assert.equal(parsed.MULTI, 'a\nb');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-env-test-'));
try {
  const file = path.join(dir, '.env'); fs.writeFileSync(file, 'ALPHA=from-file\nBETA=from-file\n');
  const target = { ALPHA: 'from-shell' };
  const loaded = loadEnv(file, target);
  assert.equal(loaded.loaded, true); assert.equal(loaded.count, 1);
  assert.equal(target.ALPHA, 'from-shell'); assert.equal(target.BETA, 'from-file');
  loadEnv(file, target, { override: true }); assert.equal(target.ALPHA, 'from-file');
  assert.equal(loadEnv(path.join(dir, 'missing.env'), {}).loaded, false);
} finally { fs.rmSync(dir, { recursive: true, force: true }); }
console.log('env-loader: ok (safe .env parsing, shell-variable precedence and optional file)');
