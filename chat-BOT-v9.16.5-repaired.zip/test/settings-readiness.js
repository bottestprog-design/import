'use strict';
const assert = require('node:assert/strict');
const { validateRuntimeSettings, modelInstalled } = require('../src/settings-readiness');

(async () => {
  assert.equal(modelInstalled({ available: true, models: ['qwen2.5:3b'] }, 'qwen2.5:3b'), true);
  assert.equal(modelInstalled({ available: true, models: ['qwen2.5:3b'] }, 'llama3:8b'), false);

  const unavailable = { smartReplyEnabled: false, smartReplyModel: 'qwen2.5:3b' };
  const unavailableWarnings = await validateRuntimeSettings({ settings: unavailable, body: { smartReplyEnabled: true }, localLlm: { status: async () => ({ available: false, models: [], message: 'Ollama is down' }) }, audioTranscriber: { status: async () => ({ ready: true }) } });
  assert.equal(unavailable.smartReplyEnabled, false, 'do not persist a true/working flag if Ollama is unavailable');
  assert.ok(unavailableWarnings.some(x => x.includes('لم يتم تفعيل الذكاء المحلي')));

  const missingModel = { smartReplyEnabled: false };
  const modelWarnings = await validateRuntimeSettings({ settings: missingModel, body: { smartReplyEnabled: true, smartReplyModel: 'llama3:8b' }, localLlm: { status: async () => ({ available: true, models: ['qwen2.5:3b'], message: 'ok' }) }, audioTranscriber: { status: async () => ({ ready: true }) } });
  assert.equal(missingModel.smartReplyEnabled, false, 'model not installed should keep local AI disabled');
  assert.ok(modelWarnings.some(x => x.includes('غير مثبت')));

  const ready = { smartReplyEnabled: false };
  const readyWarnings = await validateRuntimeSettings({ settings: ready, body: { smartReplyEnabled: true, smartReplyModel: 'qwen2.5:3b' }, localLlm: { status: async () => ({ available: true, models: ['qwen2.5:3b'] }) }, audioTranscriber: { status: async () => ({ ready: true }) } });
  assert.equal(ready.smartReplyEnabled, true);
  assert.deepEqual(readyWarnings, []);

  const voice = { voiceAutoTranscribeEnabled: false };
  const voiceWarnings = await validateRuntimeSettings({ settings: voice, body: { voiceAutoTranscribeEnabled: true }, localLlm: { status: async () => ({ available: false, models: [] }) }, audioTranscriber: { status: async () => ({ ready: false, message: 'Whisper missing' }) } });
  assert.ok(voiceWarnings.some(x => x.includes('التفريغ لن يعمل')));

  const disabled = { smartReplyEnabled: true };
  await validateRuntimeSettings({ settings: disabled, body: { smartReplyEnabled: false }, localLlm: null, audioTranscriber: null });
  assert.equal(disabled.smartReplyEnabled, false);
  console.log('settings-readiness: ok (honest dependency-aware AI toggle, missing model diagnostics, voice engine warnings, explicit disable)');
})().catch(error => { console.error(error); process.exitCode = 1; });
