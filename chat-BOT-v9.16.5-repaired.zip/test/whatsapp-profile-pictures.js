'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { ensureContactPicture, downloadProfile, isAllowedProfileUrl, isAvifPayload, imageExtensionFromBuffer, profileKey, cachedProfile, syncContacts, refreshContactPictures } = require('../src/whatsapp-contacts');

function headers(values) { return { get: name => values[String(name).toLowerCase()] || null }; }
function response({ status = 200, contentType = 'image/jpeg', location = '', bytes = Buffer.from([0xff, 0xd8, 0xff, 0xd9]) } = {}) {
  return { status, ok: status >= 200 && status < 300, headers: headers({ 'content-type': contentType, 'content-length': String(bytes.length), location }), arrayBuffer: async () => bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) };
}
(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-wa-photo-'));
  const originalFetch = global.fetch;
  try {
    assert.equal(isAllowedProfileUrl('https://pps.whatsapp.net/profile'), true);
    assert.equal(isAllowedProfileUrl('https://cdn.fbcdn.net/profile'), true);
    assert.equal(isAllowedProfileUrl('https://evil.example/photo.jpg'), false);
    assert.equal(isAllowedProfileUrl('http://pps.whatsapp.net/photo.jpg'), false);
    assert.equal(isAllowedProfileUrl('https://127.0.0.1/photo.jpg'), false);

    let fetchCount = 0;
    global.fetch = async url => {
      fetchCount++;
      if (String(url) === 'https://pps.whatsapp.net/start') return response({ status: 302, location: 'https://media.whatsapp.net/profile.jpg' });
      if (String(url) === 'https://media.whatsapp.net/profile.jpg') return response();
      throw new Error('unexpected URL');
    };
    const profileDir = path.join(root, 'profiles');
    fs.mkdirSync(profileDir, { recursive: true });
    const corruptJid = '96890000009@c.us';
    const corruptPath = path.join(profileDir, `${profileKey(corruptJid)}.jpg`);
    fs.writeFileSync(corruptPath, '<html>stale proxy page</html>');
    assert.equal(cachedProfile(profileDir, corruptJid), '', 'a stale non-empty HTML cache must not be treated as a usable account photo');
    assert.equal(fs.existsSync(corruptPath), false, 'invalid cached photos must be deleted so a later request can retry');
    assert.equal(imageExtensionFromBuffer(Buffer.from([0xff, 0xd8, 0xff, 0xd9])), '.jpg');
    assert.equal(imageExtensionFromBuffer(Buffer.from('<html>not a photo</html>')), '');
    const store = {
      safeSessionId: value => String(value || 'main'),
      getPaths: () => ({ dir: root, profiles: profileDir }),
    };
    const whatsapp = { getContactProfilePictureUrl: async (_id, jid) => { assert.match(jid, /^9689000000\d@c\.us$/); return 'https://pps.whatsapp.net/start'; } };
    const picture = await ensureContactPicture({ store, whatsapp, sessionId: 'main', jid: '96890000000@c.us' });
    assert.equal(picture.filename, `${profileKey('96890000000@c.us')}.jpg`);
    assert.equal(picture.cached, false);
    assert.ok(fs.statSync(path.join(profileDir, picture.filename)).size > 0);
    const again = await ensureContactPicture({ store, whatsapp, sessionId: 'main', jid: '96890000000@c.us' });
    assert.equal(again.cached, true);
    assert.equal(fetchCount, 2, 'cached profile must avoid repeated CDN calls');
    const concurrentStart = fetchCount;
    const concurrentJid = '96890000001@c.us';
    const parallel = await Promise.all([
      ensureContactPicture({ store, whatsapp, sessionId: 'main', jid: concurrentJid, refresh: true }),
      ensureContactPicture({ store, whatsapp, sessionId: 'main', jid: concurrentJid, refresh: true }),
    ]);
    assert.ok(parallel.every(item => item?.filename), 'concurrent avatar requests should return the cached local picture');
    assert.equal(fetchCount - concurrentStart, 2, 'identical concurrent profile requests must share one CDN redirect/download chain');
    await assert.rejects(() => ensureContactPicture({ store, whatsapp, sessionId: 'main', jid: '112233@lid' }), /غير صالح/);

    let maliciousFetchCount = 0;
    global.fetch = async () => { maliciousFetchCount++; return response({ status: 302, location: 'https://evil.example/collect' }); };
    const rejected = await downloadProfile('https://pps.whatsapp.net/redirect', path.join(profileDir, 'untrusted'));
    assert.equal(rejected, false);
    assert.equal(maliciousFetchCount, 1, 'must refuse an untrusted redirect without following it');

    // A CDN may return a real JPEG with a generic MIME type. Its validated binary
    // signature should take precedence, so valid avatars do not disappear.
    global.fetch = async () => response({ contentType: 'application/octet-stream' });
    const genericMimePhoto = await downloadProfile('https://pps.whatsapp.net/generic-mime', path.join(profileDir, 'generic-mime-photo'));
    assert.equal(genericMimePhoto, 'generic-mime-photo.jpg');
    assert.ok(fs.statSync(path.join(profileDir, genericMimePhoto)).size > 0);

    // Accept AVIF even when ISO-BMFF lists mif1 as the major brand and AVIF as
    // a compatible brand (a legal layout that the previous signature check missed).
    const avifFtyp = Buffer.alloc(24);
    avifFtyp.writeUInt32BE(24, 0); avifFtyp.write('ftyp', 4, 'ascii');
    avifFtyp.write('mif1', 8, 'ascii'); avifFtyp.writeUInt32BE(0, 12); avifFtyp.write('avif', 16, 'ascii');
    assert.equal(isAvifPayload(avifFtyp), true);
    global.fetch = async () => response({ contentType: 'image/avif', bytes: avifFtyp });
    const avifPhoto = await downloadProfile('https://pps.whatsapp.net/avif-profile', path.join(profileDir, 'avif-compatible-brand'));
    assert.equal(avifPhoto, 'avif-compatible-brand.avif');

    // If a trusted image URL is valid but cannot be cached locally, keep a safe
    // direct-URL fallback so browser rendering can still match the v8.6 behavior.
    global.fetch = async () => response({ contentType: 'text/html', bytes: Buffer.from('<html>blocked</html>') });
    const fallback = await ensureContactPicture({ store, whatsapp: { getContactProfilePictureUrl: async () => 'https://pps.whatsapp.net/avatar-blocked' }, sessionId: 'main', jid: '96890000002@c.us' });
    assert.equal(fallback?.remoteUrl, 'https://pps.whatsapp.net/avatar-blocked');

    // Exercise selected-contact synchronization, including avatar files and current profile names.
    const syncRoot = path.join(root, 'sync');
    const syncProfileDir = path.join(syncRoot, 'profiles');
    let activeFetches = 0, maxFetches = 0;
    global.fetch = async url => {
      activeFetches++;
      maxFetches = Math.max(maxFetches, activeFetches);
      await new Promise(resolve => setTimeout(resolve, 8));
      activeFetches--;
      assert.match(String(url), /^https:\/\/pps\.whatsapp\.net\//);
      return response();
    };
    const syncJids = Array.from({ length: 7 }, (_, i) => `9689000000${i}@c.us`);
    let syncedSession = { id: 'main', recipients: [], groups: [], settings: {}, automation: { tasks: [], rules: [] }, interaction: { rules: [] }, logs: [] };
    const syncStore = {
      safeSessionId: value => String(value || 'main'),
      loadSession: () => JSON.parse(JSON.stringify(syncedSession)),
      saveSession: value => { syncedSession = JSON.parse(JSON.stringify(value)); return JSON.parse(JSON.stringify(syncedSession)); },
      getPaths: () => ({ dir: syncRoot, profiles: syncProfileDir }),
    };
    const syncWhatsApp = {
      listContacts: async (_id, options) => syncJids.filter(jid => options.onlyJids.includes(jid)).map((jid, i) => ({
        jid, digits: jid.split('@')[0], name: `اسم الدفتر ${i}`, pushname: `اسم الملف الحالي ${i}`,
        isMyContact: true, profilePicUrl: `https://pps.whatsapp.net/avatar-${i}.jpg`,
      })),
    };
    const syncPhones = { parse: value => { const digits = String(value).replace(/\D/g, ''); return { digits, e164: `+${digits}`, international: `+${digits}`, formatted: `+${digits}`, country: 'OM' }; } };
    const synced = await syncContacts({ store: syncStore, whatsapp: syncWhatsApp, phones: syncPhones, sessionId: 'main', jids: syncJids, importMissing: true, updateNames: false, updatePictures: true });
    assert.equal(synced.imported.length, syncJids.length);
    assert.equal(synced.photosUpdated, syncJids.length, 'every valid WhatsApp avatar should be saved locally during sync');
    assert.ok(maxFetches > 1 && maxFetches <= 4, `profile download pool must use bounded parallelism (observed ${maxFetches})`);
    assert.ok(syncedSession.recipients.every(person => fs.existsSync(path.join(syncProfileDir, person.whatsappProfilePhoto))), 'synced profile photos must exist in session storage');
    assert.equal(syncedSession.recipients[0].whatsappPushname, 'اسم الملف الحالي 0', 'current WhatsApp profile name must be preserved separately from address-book name');
    const backgroundJid = syncJids[0];
    const backgroundResult = await refreshContactPictures({ store: syncStore, whatsapp: syncWhatsApp, sessionId: 'main', jids: [backgroundJid] });
    assert.equal(backgroundResult.photosUpdated, 1, 'background image hydration should update already-imported recipients');
    assert.ok(typeof syncedSession.recipients[0].whatsappProfilePhoto === 'string' && syncedSession.recipients[0].whatsappProfilePhoto.endsWith('.jpg'), 'background image hydration must persist the filename string, not its internal result object');
    assert.equal(syncedSession.recipients[0].whatsappAvatarUrl || '', '', 'a local successful cache clears the remote fallback');

    // When the trusted CDN returns an unsupported or blocked payload, persist the
    // allowlisted remote URL fallback to the matching recipient for UI rendering.
    const remoteJid = '96890000199@c.us';
    syncedSession.recipients.push({ id: 'remote-fallback-recipient', name: 'بديل الصورة', digits: '96890000199', e164: '+96890000199', whatsappJid: remoteJid });
    global.fetch = async () => response({ contentType: 'text/html', bytes: Buffer.from('<html>temporarily blocked</html>') });
    const remoteFallback = await refreshContactPictures({ store: syncStore, whatsapp: syncWhatsApp, sessionId: 'main', jids: [remoteJid], profileUrls: { [remoteJid]: 'https://pps.whatsapp.net/avatar-fallback' } });
    assert.equal(remoteFallback.photosRemoteFallback, 1, 'trusted CDN URL is retained when local image decode/cache fails and there is no valid cached image');
    assert.equal(syncedSession.recipients.find(person => person.whatsappJid === remoteJid)?.whatsappAvatarUrl, 'https://pps.whatsapp.net/avatar-fallback');
    global.fetch = async () => response({ contentType: 'text/html', bytes: Buffer.from('<html>bad refresh</html>') });
    const keptOldPhoto = await refreshContactPictures({ store: syncStore, whatsapp: syncWhatsApp, sessionId: 'main', jids: [syncJids[0]], profileUrls: { [syncJids[0]]: 'https://pps.whatsapp.net/temporary-bad-refresh' } });
    assert.equal(keptOldPhoto.photosUpdated, 1, 'a failed refresh must retain a previously valid local photo');
    assert.ok(syncedSession.recipients.find(person => person.whatsappJid === syncJids[0]).whatsappProfilePhoto.endsWith('.jpg'));
    const overLimitJids = Array.from({ length: 101 }, (_, i) => `${96890000000 + i}@c.us`);
    await assert.rejects(() => syncContacts({ store: syncStore, whatsapp: syncWhatsApp, phones: syncPhones, sessionId: 'main', jids: overLimitJids, importMissing: true, updateNames: false, updatePictures: true }), /100 جهة/);

    const whatsappSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'whatsapp.js'), 'utf8');
    assert.match(whatsappSource, /async getContactProfilePictureUrl\(id, jid\)/, 'WhatsApp manager must resolve profile pictures from the real client');
    assert.match(whatsappSource, /getContactById\(normalized\)/, 'profile lookup should query the exact verified contact first');
    assert.match(whatsappSource, /const names = contact\?\.isMyContact \? \[localName, pushname, notifyName, shortName\] : \[pushname, notifyName, localName, shortName\]/, 'saved contacts prefer their address-book name while unsaved contacts prefer their profile name');
    assert.match(whatsappSource, /if \(direct\) return direct;[\s\S]{0,240}mapped LID/, 'an empty direct profile lookup must continue to the verified LID fallback');
    assert.match(whatsappSource, /Promise\.all\(workers\)/, 'bulk profile lookup uses bounded concurrency');
    console.log('whatsapp-profile-pictures: ok (profile URLs, safe redirects/cache, verified JIDs, current names, bounded parallel photo sync, and selected-contact limits)');
  } finally {
    global.fetch = originalFetch;
    fs.rmSync(root, { recursive: true, force: true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
