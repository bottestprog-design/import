'use strict';
const assert = require('node:assert/strict');
const { classifyCommand, correctStructuredHead } = require('../src/command-understanding');

const cases = [
  ['ضيف الشخص الجديد', 'add-person'],
  ['عايز اضيف شخص جديد', 'add-person'],
  ['ابعت لاحمد صباح الخير', 'send-message'],
  ['مزامنه جهات الواتس', 'sync-contacts'],
  ['حول الفويس لنص', 'transcribe-latest'],
  ['شغل عدم الازعاج', 'quiet-on'],
  ['اوقف عدم الازعاج', 'quiet-off'],
  ['شغل الردود التلقائيه', 'interaction-on'],
  ['اوقف الردود التلقائيه', 'interaction-off'],
  ['شغل مساعد المجموعات', 'group-assistant-on'],
  ['اوقف مساعد المجموعات', 'group-assistant-off'],
  ['شغل الرد الاحتياطي في المجموعات', 'group-fallback-on'],
  ['حال الاعدادات', 'settings-status'],
  ['اعرض الاشخاس', 'list-people'],
  ['تقدر تعمل ايه', 'capabilities'],
  ['وريني سجل النشاط', 'list-activity'],
  ['ملخص النظام', 'list-stats'],
  ['اعرض القواعد المفعلة', 'list-active-rules'],
  ['اعرض العدادات', 'list-counters'],
  ['اختبر الرد التلقائي على السلام عليكم', 'test-reply'],
  ['امسح ذاكرة المحادثة', 'clear-chat-memory'],
  ['طمني الاتصال عامل ايه', 'status'],
  ['ليه البوت مش بيرد', 'settings-status'],
  ['وريني كل اعدادات التشغيل', 'settings-status'],
  ['ايه اخر حاجه حصلت', 'list-activity'],
  ['ايه الردود اللي شغالة', 'list-active-rules'],
  ['اسمع اخر فويس واكتب اللي فيه', 'transcribe-latest'],
  ['خلي البوت يرد على الناس', 'interaction-on'],
];
for (const [phrase, expected] of cases) {
  const got = classifyCommand(phrase);
  assert.equal(got.intent, expected, `${phrase} should map to ${expected}; got ${JSON.stringify(got)}`);
  assert.ok(got.confidence >= .66, `${phrase} should have useful confidence`);
}
const typoRule = classifyCommand('عايز اعمل رد اتوماتك');
assert.equal(typoRule.intent, null, 'uncertain/typo-heavy phrase should not execute immediately');
assert.ok(typoRule.alternatives.some(x => x.intent === 'create-rule' && x.confidence >= .58), 'a near phrase should offer the closest relevant action');
assert.equal(correctStructuredHead('ارسل الا')?.canonical, 'أرسل الآن', 'small typo in a structured command should be corrected');
assert.equal(correctStructuredHead('abc')?.canonical, undefined, 'short/unrelated values must not be auto-corrected');
console.log('command-understanding: ok (Arabic variants, typo matching, confirmation-level ambiguity, and structured command correction)');
