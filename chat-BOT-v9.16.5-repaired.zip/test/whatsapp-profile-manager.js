'use strict';
const assert = require('node:assert/strict');
const Module = require('node:module');
const originalLoad = Module._load;
const originalResolve = Module._resolveFilename;
Module._resolveFilename = function (request, parent, isMain, options) {
  if (request === 'whatsapp-web.js/package.json') return '/tmp/chatbot-test-whatsapp/package.json';
  return originalResolve.call(this, request, parent, isMain, options);
};
Module._load = function (request, parent, isMain) {
  if (request === 'whatsapp-web.js') return { Client: class Client {}, LocalAuth: class LocalAuth {}, MessageMedia: { fromFilePath: file => ({ file }) } };
  if (request === 'qrcode') return { toDataURL: async value => `data:image/png;base64,${Buffer.from(String(value)).toString('base64')}` };
  return originalLoad.call(this, request, parent, isMain);
};
let WhatsAppManager;
try { ({ WhatsAppManager } = require('../src/whatsapp')); }
finally { Module._load = originalLoad; Module._resolveFilename = originalResolve; }

(async () => {
  const phoneJid = '96890000000@c.us';
  const lidJid = '123456789@lid';
  const pnContact = { id: { _serialized: phoneJid }, isMyContact: true, getProfilePicUrl: async () => '' };
  const lidContact = { id: { _serialized: lidJid }, isMyContact: true, getProfilePicUrl: async () => 'https://pps.whatsapp.net/real-profile.jpg' };
  const mappingCalls = [];
  const client = {
    getContactById: async jid => jid === phoneJid ? pnContact : jid === lidJid ? lidContact : null,
    getContacts: async () => [pnContact, lidContact],
    getContactLidAndPhone: async ids => { mappingCalls.push([...ids]); return [{ lid: lidJid, pn: phoneJid }]; },
    getProfilePicUrl: async () => '',
  };
  const manager = new WhatsAppManager({ store: { safeSessionId: id => String(id || 'main') }, log: () => {} });
  const entry = manager.entry('main'); entry.client = client; entry.ready = true; entry.status = 'ready';
  const url = await manager.getContactProfilePictureUrl('main', phoneJid);
  assert.equal(url, 'https://pps.whatsapp.net/real-profile.jpg', 'if PN profile is empty, use the verified LID-associated contact image');
  assert.deepEqual(mappingCalls[0], [phoneJid], 'first LID resolution call is scoped to the exact phone contact, not every contact in the address book');
  assert.ok(mappingCalls.length <= 2, 'profile image lookup should not scan the full contact book when direct mapping succeeds');
  console.log('whatsapp-profile-manager: ok (fallback from empty phone profile to officially mapped LID profile, bounded lookup)');
})().catch(error => { console.error(error); process.exitCode = 1; });
