const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'public/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'public/styles.css'), 'utf8');
const checks = [
  ['additional settings button', app.includes('id="moreSettingsBtn"')],
  ['additional settings menu', app.includes('id="moreSettingsMenu"')],
  ['original-style sidebar workspace', app.includes('class="workspace-layout"') && app.includes('class="sidebar"')],
  ['grouped vertical navigation', app.includes('class="nav-group"') && css.includes('.workspace-layout{display:grid;grid-template-columns:228px minmax(0,1fr)')],
  ['original-style robot companion', app.includes('id="assistantRobotButton"') && css.includes('.assistant-robot-button')],
  ['light/dark toggle is wired', app.includes('id="modeToggleBtn"') && app.includes("localStorage.setItem('chatbot-ui-mode'")],
  ['change log page route', app.includes("state.page === 'updates'")],
  ['release log includes architecture', app.includes("version: 'v9.0.0'")],
  ['additional engines remain accessible', app.includes("['tools', '⌘', 'المحركات الذكية']") && app.includes("['updates', '↗', 'التعديلات والإصدارات']")],
  ['mobile sidebar layout', css.includes('@media(max-width:850px)') && css.includes('.sidebar .navrow') && css.includes('.more-settings-menu')],
];
let failed = false;
for (const [label, ok] of checks) { console.log(`${ok ? 'OK' : 'FAIL'} visual ${label}`); if (!ok) failed = true; }
if (failed) process.exit(1);
