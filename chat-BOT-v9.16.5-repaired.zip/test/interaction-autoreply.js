'use strict';
const assert = require('node:assert/strict');
const { InteractionEngine, match, activeWindow, ruleActiveNow, quiet } = require('../src/interaction');

function makeSession(overrides = {}) {
  return {
    id: 'session-one', name: 'Test', timezone: 'Asia/Muscat',
    settings: {
      timezone: 'Asia/Muscat', interactionEnabled: true, interactionIgnoreOwn: true,
      interactionScope: 'all', interactionChatIds: [], interactionQuietEnabled: false,
      interactionQuietStart: '00:00', interactionQuietEnd: '23:59', interactionQuietAction: 'silence',
      interactionQuietReply: 'أنا في فترة الهدوء: {{message}}', interactionQuietCooldownSec: 3600,
      maxActionsPerMinute: 100, interactionCooldownCapSec: 86400,
      ...overrides.settings,
    },
    interaction: { enabled: true, rules: [], recent: [] },
    stats: { interactionActions: 0, interactionErrors: 0 },
  };
}
function makeMessage({ id, text, chatId = 'self@c.us', fromMe = false, programmatic = false }) {
  return {
    fromMe, body: text, notifyName: 'Test user', __chatBotSelfInput: fromMe,
    __chatBotProgrammatic: programmatic,
    id: { _serialized: id, remote: { _serialized: chatId } },
    from: chatId, to: chatId,
    getChat: async () => ({ id: { _serialized: chatId }, name: 'Self chat' }),
  };
}
function engineFor(session) {
  const sent = [];
  const store = {
    loadSession: () => session,
    saveSession: value => Object.assign(session, value),
  };
  const whatsapp = {
    replyToMessage: async (id, msg, text) => { sent.push({ id, chatId: msg.id.remote._serialized, text, reply: true }); return { __chatBotAck: { status: 'created' } }; },
    sendText: async (id, chatId, text) => { sent.push({ id, chatId, text, reply: false }); return { __chatBotAck: { status: 'created' } }; },
    reactToMessage: async () => ({}),
  };
  const engine = new InteractionEngine({ store, whatsapp, log: () => {} });
  return { engine, sent, session };
}
(async () => {
  assert.equal(match({ when: { match: 'contains', value: 'سعر' } }, 'message', 'ممكن اعرف سعر المنتج؟'), true);
  assert.equal(match({ when: { match: 'exact', value: 'مرحبا' } }, 'message', 'مرحبا بك'), false);
  assert.equal(match({ when: { match: 'exact', value: 'مرحبا' } }, 'message', 'مرحبا'), true);
  const fridayDay = 5; // 2026-10-16 is a Friday.
  assert.equal(activeWindow('09:00', '17:00', [fridayDay], new Date('2026-10-16T06:00:00Z'), 'Asia/Muscat'), true);
  assert.equal(activeWindow('09:00', '17:00', [4], new Date('2026-10-16T06:00:00Z'), 'Asia/Muscat'), false);
  assert.equal(activeWindow('22:00', '07:00', [4], new Date('2026-10-15T22:30:00Z'), 'Asia/Muscat'), true);
  assert.equal(ruleActiveNow({ schedule: { enabled: false } }, {}, new Date()), true);
  assert.equal(quiet({ interactionQuietEnabled: false }), false);

  // A manually typed self-chat message, normalized by the WhatsApp event adapter, should trigger real rules.
  const session = makeSession();
  session.interaction.rules.push({
    id: 'contains-price', name: 'رد السعر', enabled: true, priority: 10, cooldownSec: 0,
    when: { type: 'message', match: 'contains', value: 'سعر', ignoreCase: true },
    then: { reply: 'أهلًا {{sender}}، وصل سؤالك: {{message}}', reaction: '', stopAfter: true },
    scope: 'all', chatIds: [], schedule: { enabled: false },
  });
  const { engine, sent } = engineFor(session);
  const manualSelfMessage = makeMessage({ id: 'manual-1', text: 'ممكن اعرف سعر المنتج؟', fromMe: true });
  const result = await engine.onMessage(session.id, manualSelfMessage);
  assert.equal(result.handled, true);
  assert.equal(sent.length, 1, 'a manual self-chat message should trigger one rule reply');
  assert.match(sent[0].text, /وصل سؤالك/);
  await engine.onMessage(session.id, manualSelfMessage);
  assert.equal(sent.length, 1, 'replayed event for the same message id must not send a duplicate');

  // Rule-specific window: a currently inactive rule must not fire, but another matching rule can.
  const scheduled = makeSession();
  scheduled.interaction.rules.push({
    id: 'wrong-day', name: 'يوم غير صحيح', enabled: true, priority: 20, cooldownSec: 0,
    when: { type: 'message', match: 'contains', value: 'سعر' }, then: { reply: 'wrong day', reaction: '', stopAfter: true },
    scope: 'all', chatIds: [], schedule: { enabled: true, start: '09:00', end: '17:00', days: [4], timezone: 'Asia/Muscat' },
  });
  scheduled.interaction.rules.push({
    id: 'all-hours', name: 'بديل', enabled: true, priority: 10, cooldownSec: 0,
    when: { type: 'message', match: 'contains', value: 'سعر' }, then: { reply: 'fallback rule', reaction: '', stopAfter: true },
    scope: 'all', chatIds: [], schedule: { enabled: false },
  });
  const scheduledRig = engineFor(scheduled);
  // The current clock might not be Friday morning. Validate the scheduler predicate deterministically above;
  // exercise a disabled schedule below and ensure scheduling metadata remains accepted.
  const now = new Date();
  const parts = new Intl.DateTimeFormat('en-US', { timeZone: 'Asia/Muscat', weekday: 'short' }).format(now);
  const jsDay = ({ Sun:0, Mon:1, Tue:2, Wed:3, Thu:4, Fri:5, Sat:6 })[parts];
  scheduled.interaction.rules[0].schedule.days = [((jsDay + 1) % 7)];
  await scheduledRig.engine.onMessage(scheduled.id, makeMessage({ id: 'scheduled-1', text: 'سعر', chatId: 'someone@c.us' }));
  assert.equal(scheduledRig.sent.length, 1);
  assert.equal(scheduledRig.sent[0].text, 'fallback rule', 'out-of-window rule should be skipped while another active rule may answer');

  // Quiet hours can explicitly silence, send a custom response, or run rules.
  const quietSilence = makeSession({ settings: { interactionQuietEnabled: true, interactionQuietAction: 'silence' } });
  quietSilence.interaction.rules.push({ id:'should-not-fire', name:'normal', enabled:true, cooldownSec:0, when:{type:'message',match:'any',value:''}, then:{reply:'normal rule',reaction:'',stopAfter:true}, scope:'all',chatIds:[] });
  const silenceRig = engineFor(quietSilence);
  const silenceResult = await silenceRig.engine.onMessage(quietSilence.id, makeMessage({ id:'quiet-silence', text:'hello', chatId:'quiet@c.us' }));
  assert.equal(silenceResult.action, 'silence'); assert.equal(silenceRig.sent.length, 0);

  const quietReply = makeSession({ settings: { interactionQuietEnabled: true, interactionQuietAction: 'reply', interactionQuietReply: 'وقت الهدوء: {{message}}', interactionQuietCooldownSec: 3600 } });
  const replyRig = engineFor(quietReply);
  const quietResult = await replyRig.engine.onMessage(quietReply.id, makeMessage({ id:'quiet-reply-1', text:'هل أنت هنا؟', chatId:'quiet-reply@c.us' }));
  assert.equal(quietResult.action, 'reply'); assert.equal(replyRig.sent.length, 1); assert.equal(replyRig.sent[0].text, 'وقت الهدوء: هل أنت هنا؟');
  const cooldownResult = await replyRig.engine.onMessage(quietReply.id, makeMessage({ id:'quiet-reply-2', text:'رسالة ثانية', chatId:'quiet-reply@c.us' }));
  assert.equal(cooldownResult.action, 'cooldown'); assert.equal(replyRig.sent.length, 1, 'quiet reply cooldown limits repeated auto-responses per conversation');

  const quietRules = makeSession({ settings: { interactionQuietEnabled: true, interactionQuietAction: 'rules' } });
  quietRules.interaction.rules.push({ id:'quiet-rule',name:'وقت الهدوء',enabled:true,cooldownSec:0,when:{type:'message',match:'contains',value:'help'},then:{reply:'help reply',reaction:'',stopAfter:true},scope:'all',chatIds:[],schedule:{enabled:false} });
  const rulesRig = engineFor(quietRules);
  const rulesResult = await rulesRig.engine.onMessage(quietRules.id, makeMessage({id:'quiet-rule-1',text:'help please',chatId:'quiet-rules@c.us'}));
  assert.equal(rulesResult.handled,true); assert.equal(rulesRig.sent.length,1); assert.equal(rulesRig.sent[0].text,'help reply');

  console.log('interaction-autoreply: ok (manual self-chat rules, duplicate protection, exact/contains, time windows, quiet silence/reply/rules and cooldown)');
})().catch(error => { console.error(error); process.exitCode = 1; });
