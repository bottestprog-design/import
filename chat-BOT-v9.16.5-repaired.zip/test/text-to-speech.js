'use strict';
const assert = require('node:assert/strict');
const { TextToSpeech, normalizeSpeechText, normalizeGrammarCandidate, textTokensForPreservation, MAX_SPEECH_CHARS, resolveFromRoot } = require('../src/text-to-speech');
assert.equal(normalizeSpeechText('**مرحبًا** [الرابط](https://example.com) 😀'), 'مرحبًا رابط مرفق');
assert.equal(resolveFromRoot('/project', 'ffmpeg'), 'ffmpeg');
assert.equal(resolveFromRoot('/project', 'C:\\project\\tools\\piper\\piper.exe'), 'C:\\project\\tools\\piper\\piper.exe', 'absolute Windows paths must stay unchanged');
assert.equal(
  resolveFromRoot('/project', 'tools/piper/piper.exe'),
  require('node:path').resolve('/project', 'tools/piper/piper.exe'),
  'relative executable paths must resolve according to the host operating system'
);
const hostPath = require('node:path');
const windowsProjectRoot = hostPath.resolve('C:/chat-BOT-test');
assert.equal(
  resolveFromRoot(windowsProjectRoot, 'tools/piper/piper.exe'),
  hostPath.resolve(windowsProjectRoot, 'tools/piper/piper.exe'),
  'relative executable paths must resolve correctly even when the project folder contains Windows path segments'
);
assert.equal(normalizeGrammarCandidate('أحمد، سيصل غدًا الساعة 17:30.', 'أحمد سيصل غدًا الساعة 17:30.').used, true);
assert.equal(normalizeGrammarCandidate('أحمد سيصل الساعة 18:00.', 'أحمد سيصل الساعة 17:30.').used, false, 'proofreader must not change protected numbers');
const longOriginal = 'هذا نص طويل يجب الحفاظ على معناه ومحتواه كله تقريبًا حتى لا يغيّر المدقق المطلوب، وتجب المحافظة على الأرقام والتواريخ والأسماء والحقائق دون اختصار أو حذف أي معنى مهم. '.repeat(2);
assert.equal(normalizeGrammarCandidate('ملخص أقصر بكثير', longOriginal).used, false, 'proofreader must not shorten a long reply into a summary');
assert.deepEqual(textTokensForPreservation('رقم 17:30 ورابط https://example.com'), ['17:30', 'https://example.com']);
(async () => {
  const tts = new TextToSpeech({ env: { PIPER_BIN: '/missing/piper', PIPER_MODEL_PATH: '/missing/model.onnx', FFMPEG_BIN: '/missing/ffmpeg' }, root: '/tmp' });
  const status = await tts.status();
  assert.equal(status.ready, false);
  assert.equal(status.modelReady, false);
  await assert.rejects(() => tts.prepareText('x'.repeat(MAX_SPEECH_CHARS + 1), { proofread: false }), /1800/);

  // Exercise the complete generation and Opus conversion flow with local mock executables.
  const { EventEmitter } = require('node:events');
  const fs = require('node:fs');
  const os = require('node:os');
  const path = require('node:path');
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-tts-pipeline-'));
  try {
    const piper = path.join(root, 'piper.exe'), modelPath = path.join(root, 'arabic.onnx'), ffmpeg = path.join(root, 'ffmpeg.exe');
    fs.writeFileSync(piper, 'mock'); fs.writeFileSync(ffmpeg, 'mock');
    const modelFd = fs.openSync(modelPath, 'w'); fs.ftruncateSync(modelFd, 10 * 1024 * 1024 + 1); fs.closeSync(modelFd);
    let spokenText = '', conversionArgs = null;
    const pipe = (binary, args) => {
      assert.equal(binary, piper);
      const child = new EventEmitter(); child.stderr = new EventEmitter(); child.stdin = new EventEmitter();
      const outPath = args[args.indexOf('--output_file') + 1];
      child.stdin.end = input => { spokenText = String(input); fs.writeFileSync(outPath, Buffer.alloc(512, 3)); setImmediate(() => child.emit('close', 0)); };
      child.kill = () => {};
      return child;
    };
    const exec = async (binary, args) => {
      assert.equal(binary, ffmpeg); conversionArgs = args;
      fs.writeFileSync(args.at(-1), Buffer.alloc(1024, 4)); return { stdout: '', stderr: '' };
    };
    const local = { generate: async ({ messages }) => messages[0].content };
    const readyTts = new TextToSpeech({ root, tempRoot: root, env: { PIPER_BIN: piper, PIPER_MODEL_PATH: modelPath, FFMPEG_BIN: ffmpeg, TTS_TIMEOUT_MS: '5000' }, spawnImpl: pipe, execFileImpl: exec, localLlm: local });
    const generated = await readyTts.generate('مرحبًا، الاجتماع غدًا الساعة 17:30.');
    assert.equal(generated.proofreadUsed, true);
    assert.match(spokenText, /17:30/, 'time is spoken without punctuation corruption');
    const ogg = await readyTts.toWhatsAppVoice(generated.wavPath);
    assert.ok(ogg.endsWith('.ogg'));
    assert.ok(fs.statSync(ogg).size > 100);
    assert.ok(conversionArgs.includes('libopus'));
    assert.equal(readyTts.cleanup(generated), true);
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
  console.log('text-to-speech: ok (Arabic text cleanup, protected-token proofreading, fail-closed readiness, local generation pipeline and OGG/Opus conversion)');
})().catch(error => { console.error(error); process.exitCode = 1; });
