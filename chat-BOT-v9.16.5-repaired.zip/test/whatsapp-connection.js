'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const EventEmitter = require('node:events');
const Module = require('node:module');

const originalLoad = Module._load;
const originalResolve = Module._resolveFilename;
const clients = [];
let conversionDelay = 30;
let initializeMode = 'sync';
class FakeClient extends EventEmitter {
  constructor(options) { super(); this.options = options; this.destroyCount = 0; clients.push(this); }
  async initialize() {
    if (this.options.pairWithPhoneNumber?.phoneNumber) { this.emit('code', 'AB12CD34'); return true; }
    if (initializeMode === 'delayed-qr-pending') {
      setTimeout(() => this.emit('qr', 'REAL-CLIENT-QR-PAYLOAD'), 15);
      return new Promise(() => {});
    }
    this.emit('qr', 'REAL-CLIENT-QR-PAYLOAD'); return true;
  }
  async destroy() { this.destroyCount++; }
  async getState() { return null; }
}
Module._resolveFilename = function (request, parent, isMain, options) {
  if (request === 'whatsapp-web.js/package.json') return '/tmp/chatbot-connection-test/package.json';
  return originalResolve.call(this, request, parent, isMain, options);
};
Module._load = function (request, parent, isMain) {
  if (request === 'whatsapp-web.js') return { Client: FakeClient, LocalAuth: class LocalAuth { constructor(options) { this.options = options; } }, MessageMedia: { fromFilePath: file => ({ file }) } };
  if (request === 'qrcode') return { toDataURL: async (value, options) => {
    await new Promise(resolve => setTimeout(resolve, conversionDelay));
    assert.equal(value, 'REAL-CLIENT-QR-PAYLOAD');
    assert.equal(options.width, 360);
    assert.equal(options.errorCorrectionLevel, 'H');
    return 'data:image/png;base64,aGVsbG8=';
  } };
  return originalLoad.call(this, request, parent, isMain);
};

(async () => {
  process.env.NODE_ENV = 'test';
  let WhatsAppManager, navigationRecoveryPlan, normalizePairingPhoneNumber, browserProfileConflictError;
  try { ({ WhatsAppManager, navigationRecoveryPlan, normalizePairingPhoneNumber, browserProfileConflictError } = require('../src/whatsapp')); }
  finally { Module._load = originalLoad; Module._resolveFilename = originalResolve; }
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-connection-'));
  try {
    const store = {
      safeSessionId: id => String(id || 'main'),
      ensureDir(id) { fs.mkdirSync(path.join(root, String(id)), { recursive: true }); },
      getPaths(id) { const dir = path.join(root, String(id)); return { dir, auth: path.join(dir, 'auth') }; },
    };
    const manager = new WhatsAppManager({ store, log: () => {} });
    const started = await manager.start('main');
    assert.equal(started.status, 'qr');
    assert.equal(started.qr, null, 'must not expose raw QR payload before conversion is finished');
    assert.equal(manager.listRuntime('main').qr, null);
    await new Promise(resolve => setTimeout(resolve, conversionDelay + 15));
    let runtime = manager.listRuntime('main');
    assert.equal(runtime.status, 'qr');
    assert.match(runtime.qr, /^data:image\/png;base64,/);
    assert.notEqual(runtime.qr, 'REAL-CLIENT-QR-PAYLOAD');
    assert.ok(runtime.qrUpdatedAt, 'QR timestamp exists for live refreshes');

    // Repeated Connect must leave the active QR client intact.
    const again = await manager.start('main');
    assert.equal(again.status, 'qr');
    assert.equal(clients.length, 1, 'second click must not create a competing WhatsApp client');
    assert.equal(clients[0].destroyCount, 0, 'second click must not destroy the active QR flow');

    assert.ok(navigationRecoveryPlan(new Error('Execution context was destroyed, most likely because of a navigation')));
    assert.equal(navigationRecoveryPlan(new Error('ordinary invalid phone number')), null);

    // Repeated context destruction can be caused by a Chromium profile created by a different
    // browser build. Preserve the old profile as a backup and let LocalAuth generate a fresh QR.
    const damagedPaths = store.getPaths('damaged');
    const damagedProfile = path.join(damagedPaths.auth, 'session-damaged');
    fs.mkdirSync(damagedProfile, { recursive: true });
    fs.writeFileSync(path.join(damagedProfile, 'Preferences'), '{"profile":{"test":true}}');
    const damagedRuntime = manager.entry('damaged');
    assert.equal(manager.quarantineNavigationDamagedProfile('damaged', damagedRuntime), true);
    assert.equal(fs.existsSync(damagedProfile), false, 'damaged profile must no longer be used by LocalAuth');
    assert.equal(damagedRuntime.navigationProfileReset, true);
    assert.match(damagedRuntime.profileRecoveryNotice, /احتياطيًا/);
    const backups = path.join(damagedPaths.dir, 'auth-profile-backups');
    const backupDirs = fs.readdirSync(backups);
    assert.equal(backupDirs.length, 1);
    assert.equal(fs.readFileSync(path.join(backups, backupDirs[0], 'Preferences'), 'utf8'), '{"profile":{"test":true}}', 'previous credentials/profile must be preserved, not deleted');

    await manager.stop('main');
    assert.equal(manager.listRuntime('main').status, 'stopped');

    // A real Chromium initialize() may stay pending while WhatsApp Web is navigating.
    // Connect must return immediately, and a later QR event must still reach the poll endpoint.
    initializeMode = 'delayed-qr-pending';
    const startedAt = Date.now();
    const slowStart = await manager.start('pending');
    assert.ok(Date.now() - startedAt < 500, 'connection start must not wait for browser navigation to finish');
    assert.equal(slowStart.status, 'starting');
    await new Promise(resolve => setTimeout(resolve, conversionDelay + 35));
    runtime = manager.listRuntime('pending');
    assert.equal(runtime.status, 'qr');
    assert.match(runtime.qr, /^data:image\/png;base64,/);
    const notReadyStartedAt = Date.now();
    await assert.rejects(() => manager.ensureReady('pending', 1000), /امسح رمز QR/);
    assert.ok(Date.now() - notReadyStartedAt < 250, 'send paths should explain QR pairing promptly instead of hanging until timeout');
    await manager.stop('pending');
    initializeMode = 'sync';

    const source = fs.readFileSync(path.join(__dirname, '..', 'public', 'app.js'), 'utf8');
    const server = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf8');
    assert.match(source, /refreshSessionRuntime\(\)/, 'the UI needs a live state poll for async QR events');
    assert.match(source, /setInterval\(\(\) => \{ if \(state\.page === 'session'\) refreshSessionRuntime\(\); \}, 1400\)/);
    assert.match(source, /id="sessionQrImage"/);
    assert.match(source, /sessionQrPlaceholder/);
    assert.match(source, /runtime\.qrWaitWarning/);
    assert.match(source, /img\.hidden = !goodQr/);
    assert.match(source, /ERR_BLOCKED_BY_ADMINISTRATOR/,'network administrator blocks should show a specific actionable hint');
    assert.match(source, /لن يتم إنشاء رمز وهمي/,'the UI must not imply a QR exists when WhatsApp Web could not open');
    assert.match(server, /app\.get\('\/api\/session\/status'/);
    assert.match(server, /Cache-Control', 'no-store/);
    const compat = fs.readFileSync(path.join(__dirname, '..', 'src', 'compat.js'), 'utf8');
    const browserLoader = fs.readFileSync(path.join(__dirname, '..', 'scripts', 'ensure-browser.js'), 'utf8');
    const managerSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'whatsapp.js'), 'utf8');
    assert.match(compat, /waitForFunction\('window\.Debug\?\.VERSION != undefined'/, 'Debug polling must survive execution-context resets');
    assert.match(compat, /waitForFunction\('window\.WWebJS != undefined'/, 'injected-helper polling must survive navigation');
    assert.match(compat, /_chatBotInjectWithNavigationRetry/, 'inject must retry context-loss errors in a bounded way');
    assert.match(managerSource, /quarantineNavigationDamagedProfile/, 'repeated context loss must preserve the bad profile and start with a fresh QR profile');
    assert.match(browserLoader, /configuredCandidate\(\) \|\| markerCandidate\(\) \|\| puppeteerPath\(\)/, 'browser choice should prefer an explicitly configured or pinned executable');

    // Phone-based pairing is an actual whatsapp-web.js option, not merely a visible UI choice.
    assert.equal(normalizePairingPhoneNumber('+968 9123-4567'), '96891234567');
    assert.equal(normalizePairingPhoneNumber('+٩٦٨ ٩١٢٣-٤٥٦٧'), '96891234567', 'Arabic numerals should be normalized before validation');
    assert.equal(normalizePairingPhoneNumber('00968 9123 4567'), '96891234567', 'international 00 prefix should work as a simpler alternative to +');
    assert.throws(() => normalizePairingPhoneNumber('91234567'), /رمز الدولة|الصيغة الدولية|دوليًا/);
    assert.throws(() => normalizePairingPhoneNumber('123'), /رقم الربط/);
    const pairingStart = await manager.start('pairing', { method: 'phone', phoneNumber: '+968 9123 4567' });
    assert.equal(pairingStart.status, 'pairing_code');
    assert.equal(pairingStart.pairingCode, 'AB12CD34');
    assert.equal(clients.at(-1).options.pairWithPhoneNumber.phoneNumber, '96891234567');
    assert.equal(clients.at(-1).options.pairWithPhoneNumber.intervalMs, 180000);
    assert.equal((await manager.start('pairing', { method: 'phone', phoneNumber: '+968 9123 4567' })).pairingCode, 'AB12CD34');
    const pairingClientCount = clients.length;
    assert.equal(clients.at(-1).destroyCount, 0, 'repeat Connect during a pairing code session must not destroy the active browser');
    assert.equal(clients.length, pairingClientCount);
    await assert.rejects(() => manager.start('invalid-pairing', { method: 'phone', phoneNumber: '123' }), /رقم الربط/);
    const recoveryEntry = manager.entry('recovery-phone');
    recoveryEntry.connectionMethod = 'phone'; recoveryEntry.pairingPhoneDigits = '96891234567'; recoveryEntry.status = 'disconnected';
    await manager.start('recovery-phone', { recovery: true });
    assert.equal(clients.at(-1).options.pairWithPhoneNumber.phoneNumber, '96891234567', 'recovery should preserve phone pairing mode and never silently switch back to QR');
    await manager.stop('recovery-phone');
    const profileConflict = browserProfileConflictError(new Error('The browser is already running for C:\\secret\\profile. Use a different userDataDir or stop the running browser first.'));
    assert.equal(profileConflict.code, 'BROWSER_PROFILE_IN_USE');
    assert.match(profileConflict.message, /أوقف النسخة القديمة/);

    // The old disconnect handler started another client while Chrome still owned the same
    // profile. Verify that the new start waits for old-client cleanup first.
    const beforeReconnect = clients.length;
    const reconnectStart = await manager.start('reconnect', { method: 'qr' });
    assert.equal(reconnectStart.status, 'qr');
    const disconnectedClient = clients.at(-1);
    await new Promise(resolve => setTimeout(resolve, 20));
    disconnectedClient.emit('disconnected', 'test disconnect');
    await manager.start('reconnect', { method: 'qr' });
    await new Promise(resolve => setTimeout(resolve, conversionDelay + 30));
    assert.equal(clients.length, beforeReconnect + 2, 'the reconnect request should wait for the previous Chrome instance to be cleaned');
    await manager.stop('pairing');
    await manager.stop('reconnect');
    console.log('whatsapp-connection: ok (QR, official phone pairing code, duplicate-start guard, profile-lock diagnostics, disconnect cleanup and bounded context recovery)');
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
})().catch(error => { console.error(error); process.exitCode = 1; });
