'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const { VERSION, args: parseArgs, validateServer, isAllowedPath, runTask, request } = require('../src/integration-agent');

(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-agent-test-'));
  let redirectServer, redirectedAgentToken = null;
  try {
    const allowed = path.join(root, 'allowed'), sibling = path.join(root, 'allowed-evil');
    fs.mkdirSync(allowed); fs.mkdirSync(sibling); fs.writeFileSync(path.join(sibling, 'not-allowed.txt'), 'blocked');
    fs.writeFileSync(path.join(allowed, 'note.txt'), 'do not read file contents');
    fs.writeFileSync(path.join(allowed, 'test.json'), JSON.stringify({ name: 'sample', count: 2 }));
    assert.equal(validateServer('http://127.0.0.1:7005'), 'http://127.0.0.1:7005');
    assert.deepEqual(parseArgs(['--allow-root', allowed, '--allow-root', sibling, '--token', 'abc']).allowRoots, [allowed, sibling], 'repeated allow-root arguments must be collected rather than ignored');
    assert.throws(() => validateServer('file:///tmp'), /HTTP\/HTTPS/);
    assert.equal(isAllowedPath(path.join(allowed, 'note.txt'), [allowed]), fs.realpathSync(path.join(allowed, 'note.txt')));
    assert.throws(() => isAllowedPath(path.join(sibling, 'not-allowed.txt'), [allowed]), /داخل مجلد سمحت/);
    redirectServer = http.createServer((req, res) => { redirectedAgentToken = req.headers['x-integration-agent-token'] || null; res.writeHead(302, { location: 'http://127.0.0.1:1/steal' }); res.end(); });
    await new Promise((resolve, reject) => { redirectServer.once('error', reject); redirectServer.listen(0, '127.0.0.1', resolve); });
    await assert.rejects(() => request(`http://127.0.0.1:${redirectServer.address().port}`, '/', { method: 'POST', token: 'sensitive-device-token', body: {} }), /رفض الوكيل تحويل/);
    assert.equal(redirectedAgentToken, 'sensitive-device-token', 'the token may be sent only to the configured server, not followed to the redirect destination');

    const info = await runTask({ action: 'device.info', params: {} }, { allowRoots: [] });
    assert.equal(info.ok, true); assert.equal(info.agentVersion, VERSION);
    const version = await runTask({ action: 'command.version', params: { command: 'node' } }, { allowRoots: [] });
    assert.equal(version.ok, true); assert.match(version.version, /v\d+/);
    const listed = await runTask({ action: 'folder.list', params: { path: allowed } }, { allowRoots: [allowed] });
    assert.equal(listed.count, 2); assert.equal(Object.hasOwn(listed.entries[0], 'contents'), false);
    const db = await runTask({ action: 'database.inspect', params: { path: path.join(allowed, 'test.json') } }, { allowRoots: [allowed] });
    assert.equal(db.format, 'JSON'); assert.deepEqual(db.keys.sort(), ['count', 'name']); assert.equal(Object.hasOwn(db, 'rows'), false);
    await assert.rejects(() => runTask({ action: 'folder.list', params: { path: sibling } }, { allowRoots: [allowed] }), /داخل مجلد سمحت/);
    await assert.rejects(() => runTask({ action: 'shell.exec', params: { command: 'rm -rf /' } }, { allowRoots: [] }), /غير مدعوم/);
    console.log('integration-agent: ok (server URL validation, allowlisted device actions, fixed command list, folder-boundary enforcement, metadata-only inspection and redirect-token-leak prevention)');
  } finally { if (redirectServer) await new Promise(resolve => redirectServer.close(resolve)); fs.rmSync(root, { recursive: true, force: true }); }
})().catch(error => { console.error(error); process.exitCode = 1; });
