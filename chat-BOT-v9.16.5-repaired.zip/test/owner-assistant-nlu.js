'use strict';
const assert = require('node:assert/strict');
const { OwnerAssistant } = require('../src/owner-assistant');

function rig({ settings = {}, localLlm = null, audioTranscriber = null } = {}) {
  let stored = {
    id: 'main', name: 'test', recipients: [{ id: 'ahmed', name: 'أحمد', digits: '96890000000', e164: '+96890000000', international: '+968 9000 0000', enabled: true }],
    groups: [], settings: { interactionEnabled: true, interactionFallbackEnabled: true, interactionQuietEnabled: false, voiceAutoTranscribeEnabled: true, smartReplyEnabled: false, smartReplyModel: 'qwen2.5:3b', ...settings },
    interaction: { enabled: true, rules: [] }, automation: { tasks: [] }, logs: [], ownerAssistant: { flow: null, recent: [] },
  };
  const sent = [];
  const store = { safeSessionId: x => x || 'main', loadSession: () => JSON.parse(JSON.stringify(stored)), saveSession: s => { stored = JSON.parse(JSON.stringify(s)); return stored; }, get current() { return JSON.parse(JSON.stringify(stored)); } };
  const whatsapp = { selfChatId: () => '96890000000@c.us', listRuntime: () => ({ ready: true, status: 'ready' }), sendText: async (_id, chatId, text) => { sent.push({ chatId, text }); return { ok: true }; }, resolveChatId: async (_id, data) => `${data.digits || data.phone || '96890000000'}@c.us`, listContacts: async () => [] };
  const phones = { parse: value => { const digits = String(value).replace(/\D/g, ''); if (digits.length < 8) throw new Error('رقم غير صالح'); return { digits, e164: `+${digits}`, international: `+${digits}`, phone: digits, country: 'OM' }; } };
  const delivery = { files: () => [] };
  const assistant = new OwnerAssistant({ store, whatsapp, phones, log: () => {}, audioTranscriber, localLlm, delivery });
  return { assistant, store, sent, setCurrent: value => { stored = JSON.parse(JSON.stringify(value)); } };
}
async function send(r, body) { return r.assistant.handleSelfChatMessage('main', { body }); }
(async () => {
  const r = rig();
  await send(r, 'شغل عدم الازعاج');
  assert.equal(r.store.current.settings.interactionQuietEnabled, true, 'chat command should persist do-not-disturb');
  await send(r, 'اوقف الردود التلقائيه');
  assert.equal(r.store.current.settings.interactionEnabled, false, 'chat command should persist global interaction disable');
  assert.equal(r.store.current.interaction.enabled, false, 'interaction engine enable flag must mirror setting');

  const near = rig();
  const unclear = await send(near, 'عايز اعمل رد اتوماتك');
  assert.equal(unclear.action, 'clarify-command');
  assert.equal(near.store.current.ownerAssistant.flow.type, 'clarify-command');
  assert.match(near.sent.at(-1).text, /لم أنفّذ أي إجراء/);
  await send(near, 'نعم');
  assert.equal(near.store.current.ownerAssistant.flow.type, 'auto-reply', 'confirmation of a fuzzy command should open the proper wizard, not execute a reply without details');

  const target = rig();
  const staged = await send(target, 'ابعت لأحمد صباح الخير');
  assert.equal(staged.action, 'send-wizard-started');
  assert.equal(target.store.current.ownerAssistant.flow.type, 'send-message');
  assert.equal(target.store.current.ownerAssistant.flow.step, 'confirm');
  assert.equal(target.store.current.ownerAssistant.flow.data.target.label, 'أحمد');
  assert.match(target.store.current.ownerAssistant.flow.data.message, /صباح الخير/);
  assert.match(target.sent.at(-1).text, /تأكيد الإرسال/);


  const groupSwitch = rig({ settings: { groupAssistantEnabled: false } });
  await send(groupSwitch, 'شغل مساعد المجموعات');
  assert.equal(groupSwitch.store.current.settings.groupAssistantEnabled, true, 'group assistant command should activate the real group analysis setting');
  await send(groupSwitch, 'اوقف مساعد المجموعات');
  assert.equal(groupSwitch.store.current.settings.groupAssistantEnabled, false, 'group assistant disable command should persist');

  const modelMissing = rig({ settings: { smartReplyEnabled: false } });
  await send(modelMissing, 'شغل الرد الذكي');
  assert.equal(modelMissing.store.current.settings.smartReplyEnabled, false, 'must not mark local AI active when there is no local provider');
  assert.match(modelMissing.sent.at(-1).text, /لم أفعّل/);

  let llmArgs = null;
  const model = rig({ settings: { smartReplyEnabled: true, smartReplyModel: 'qwen2.5:3b' }, localLlm: { status: async () => ({ available: true, models: ['qwen2.5:3b'] }), generate: async args => { llmArgs = args; return 'هل تقصد أن أبدأ بإضافة الشخص؟'; } } });
  const conversational = await send(model, 'ممكن تشرح لي الفرق بين المواعيد والقواعد؟');
  assert.equal(conversational.action, 'local-conversation');
  assert.ok(llmArgs.messages.length >= 1);
  assert.match(model.sent.at(-1).text, /هل تقصد/);
  assert.equal(model.store.current.ownerAssistant.conversation.length, 2, 'self-chat conversation history should be persisted');

  const diagnostics = rig();
  const connectionStatus = await send(diagnostics, 'طمني الاتصال عامل ايه');
  assert.equal(connectionStatus.handled, true, 'natural connection-status phrasing should route to the real status handler');
  assert.match(diagnostics.sent.at(-1).text, /حالة الجلسة/);
  const settingsDiagnosis = await send(diagnostics, 'ليه البوت مش بيرد');
  assert.equal(settingsDiagnosis.action, 'settings-status');
  assert.match(diagnostics.sent.at(-1).text, /عدم الإزعاج/);
  const activity = await send(diagnostics, 'ايه اخر حاجه حصلت');
  assert.equal(activity.action, 'list-activity');
  const activeRules = await send(diagnostics, 'ايه الردود اللي شغالة');
  assert.equal(activeRules.action, 'list-active-rules');
  assert.match(diagnostics.sent.at(-1).text, /القواعد المفعّلة/);

  const tools = rig();
  const toolsSession = tools.store.current;
  toolsSession.ownerAssistant = { flow: null, recent: [], conversation: [{ role: 'user', content: 'old' }, { role: 'assistant', content: 'old reply' }] };
  toolsSession.interaction.rules = [{ id: 'greeting', name: 'ترحيب', enabled: true, priority: 15, cooldownSec: 0, when: { type: 'message', match: 'contains', value: 'السلام عليكم' }, then: { reply: 'وعليكم السلام {{sender}}', replies: ['وعليكم السلام {{sender}}'] }, scope: 'all', chatIds: [], schedule: { enabled: false } }];
  tools.setCurrent(toolsSession);
  const dryRun = await send(tools, 'اختبر الرد التلقائي على: السلام عليكم يا أحمد');
  assert.equal(dryRun.action, 'test-reply');
  assert.equal(dryRun.matches, 1);
  assert.match(tools.sent.at(-1).text, /لم أرسل أي رسالة/);
  const capabilities = await send(tools, 'تقدر تعمل ايه؟');
  assert.equal(capabilities.action, 'capabilities');
  assert.match(tools.sent.at(-1).text, /قواعد التفاعل/);
  await send(tools, 'امسح ذاكرة المحادثة');
  assert.equal(tools.store.current.ownerAssistant.flow.type, 'clear-chat-memory');
  assert.equal(tools.store.current.ownerAssistant.conversation.length, 2, 'memory must not clear before exact confirmation');
  await send(tools, 'تأكيد مسح الذاكرة');
  assert.deepEqual(tools.store.current.ownerAssistant.conversation, [], 'confirmed local memory clear empties saved LLM context');
  console.log('owner-assistant-nlu: ok (chat settings, fuzzy-command confirmation, natural send preview, local AI history, capability help, safe dry-run, confirmed memory clear)');
})().catch(error => { console.error(error); process.exitCode = 1; });
