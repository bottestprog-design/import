'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const { IntegrationHub, TEST_CATALOG, RULE_TEMPLATES, parseOpenApi, validateHttpUrl } = require('../src/integration-hub');

(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-integration-hub-'));
  let server, targetServer, targetUrl = '', redirectedAuthorization = null;
  try {
    const sessionDir = path.join(root, 'main'); fs.mkdirSync(sessionDir, { recursive: true });
    const store = {
      safeSessionId(value) { const v = String(value || 'main'); if (!/^[A-Za-z0-9_-]{1,80}$/.test(v)) throw new Error('invalid session'); return v; },
      getPaths(value) { const dir = path.join(root, this.safeSessionId(value)); fs.mkdirSync(dir, { recursive: true }); return { dir }; },
      listSessionIds() { return ['main']; },
      loadSession() { return { groups: [], recipients: [] }; },
    };
    const spec = { openapi: '3.0.3', info: { title: 'Test API', version: '1.0.0' }, paths: { '/health': { get: { summary: 'Health' } }, '/items': { get: { summary: 'List items' }, post: { summary: 'Create item' } } } };
    server = http.createServer((req, res) => {
      if (req.url === '/openapi.json') { res.writeHead(200, { 'content-type': 'application/json', 'x-content-type-options': 'nosniff' }); res.end(JSON.stringify(spec)); return; }
      if (req.url === '/redirect') { res.writeHead(302, { location: '/health' }); res.end(); return; }
      if (req.url === '/cross-origin-redirect') { res.writeHead(302, { location: `${targetUrl}/capture` }); res.end(); return; }
      if (req.url === '/health') { res.writeHead(200, { 'content-type': 'application/json', 'x-content-type-options': 'nosniff' }); res.end('{"ok":true}'); return; }
      if (req.url === '/secure') { if (req.headers.authorization !== 'Bearer test-secret-123') { res.writeHead(401, { 'content-type': 'application/json' }); res.end('{"error":"auth required"}'); } else { res.writeHead(200, { 'content-type': 'application/json' }); res.end('{"ok":true}'); } return; }
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); res.end('<!doctype html><title>Local test target</title>');
    });
    await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
    targetServer = http.createServer((req, res) => { if (req.url === '/capture') redirectedAuthorization = req.headers.authorization || null; res.writeHead(200, { 'content-type': 'application/json' }); res.end('{"ok":true}'); });
    await new Promise((resolve, reject) => { targetServer.once('error', reject); targetServer.listen(0, '127.0.0.1', resolve); });
    targetUrl = `http://127.0.0.1:${targetServer.address().port}`;
    const port = server.address().port, baseUrl = `http://127.0.0.1:${port}/`;
    const hub = new IntegrationHub({ store, logger: () => {} });

    assert.equal(TEST_CATALOG.length, 320, 'test catalog count must not silently shrink');
    assert.equal(RULE_TEMPLATES.length, 20, 'exactly 20 ready-made rules are expected');
    assert.equal(parseOpenApi(JSON.stringify(spec)).paths.length, 3);
    assert.equal(parseOpenApi('openapi: 3.0.3\ninfo:\n  title: YAML API\npaths:\n  /health:\n    get:\n      summary: health').paths.length, 1);
    assert.throws(() => validateHttpUrl('file:///etc/passwd'), /HTTP أو HTTPS/);
    assert.throws(() => validateHttpUrl('https://example.test/?api_key=secret/i'), /مفاتيح السر/);

    const made = hub.createConnection('main', { name: 'Local test web app', type: 'http', url: baseUrl });
    const discovered = await hub.discover('main', made.connection.id);
    assert.ok(discovered.capabilities.includes('http.health'));
    assert.ok(discovered.capabilities.includes('openapi.read'));
    assert.ok(discovered.specSummary.paths >= 2);
    assert.ok(discovered.evidence.length >= 2);
    assert.equal(discovered.templates.length, 20);

    const redirectProbe = await hub.safeFetch(`${baseUrl}cross-origin-redirect`, { headers: { Authorization: 'Bearer must-not-leak' } });
    assert.equal(redirectProbe.status, 200);
    assert.equal(redirectedAuthorization, null, 'stored credentials must not be forwarded to a different origin after redirect');

    const secure = hub.createConnection('main', { name: 'Authenticated local API', type: 'http', url: `${baseUrl}secure`, headers: { Authorization: 'Bearer test-secret-123' } });
    assert.equal(secure.connection.hasCredentials, true);
    assert.equal(Object.hasOwn(secure.connection, 'secretHeadersEncrypted'), false, 'API output must never return encrypted credential fields');
    const storedIntegrations = fs.readFileSync(hub.fileFor('main'), 'utf8');
    assert.equal(storedIntegrations.includes('test-secret-123'), false, 'credentials must not be stored in plaintext');
    const securedDiscovery = await hub.discover('main', secure.connection.id);
    assert.equal(securedDiscovery.probe.status, 200, 'configured auth header must be used for the selected API');
    assert.equal(hub.getConnection('main', secure.connection.id).hasCredentials, undefined);
    const secureRecord = hub.getConnection('main', secure.connection.id);
    assert.equal(Boolean(secureRecord.secretHeadersEncrypted?.data), true);
    const credentialsCleared = hub.updateCredentials('main', secure.connection.id, {});
    assert.equal(credentialsCleared.connection.hasCredentials, false);
    const deniedDiscovery = await hub.discover('main', secure.connection.id);
    assert.equal(deniedDiscovery.probe.status, 401, 'cleared credentials should no longer authorize the API');
    const testReport = await hub.runTests('main', made.connection.id);
    assert.equal(testReport.run.total, 320);
    assert.ok(testReport.summary.actualTargetProbes >= 1 && testReport.summary.actualTargetProbes < 320, 'must report real network probes separately from catalog scenarios');
    assert.ok(['PASS', 'WARN', 'FAIL'].includes(testReport.run.results[0].status));
    assert.ok(testReport.run.results.some(item => item.status === 'SKIPPED'));
    assert.ok(testReport.run.results.some(item => item.status === 'UNSUPPORTED'));
    assert.ok(testReport.run.results.some(item => item.status === 'INCONCLUSIVE'));
    assert.equal(testReport.run.catalogScenarios, 320);
    assert.equal(testReport.summary.executedCases, testReport.run.results.filter(item => item.executed).length);
    assert.ok(testReport.run.results.filter(item => item.status === 'INCONCLUSIVE').every(item => item.executed === false), 'evidence-only scenarios must never be counted as executed passes');
    assert.ok(testReport.run.results.filter(item => item.manualReview).every(item => item.status === 'SKIPPED'), 'manual-review scenarios must remain skipped');
    assert.equal(hub.report('main', testReport.run.id).results.length, 320);

    const rule = hub.createRule('main', { connectionId: made.connection.id, name: 'Check site', action: 'http_health', requiredCapability: 'http.health', triggerType: 'manual' });
    assert.equal(rule.supported, true);
    const enabled = hub.toggleRule('main', rule.id, true);
    assert.equal(enabled.enabled, true);
    const ran = await hub.runRule('main', rule.id);
    assert.equal(ran.result.ok, true);
    assert.match(ran.result.summary, /HTTP 200/);

    const tlsConnection = hub.createConnection('main', { name: 'TLS policy test', type: 'http', url: 'https://example.test/' }).connection;
    const tlsData = hub.read('main');
    const tlsStored = tlsData.connections.find(x => x.id === tlsConnection.id);
    tlsStored.capabilities = ['hub.safety', 'http.tls']; tlsStored.discoveredAt = new Date().toISOString();
    hub.write('main', tlsData);
    const tlsRule = hub.createRule('main', { connectionId: tlsConnection.id, name: 'HTTPS policy', action: 'http_tls', requiredCapability: 'http.tls' });
    assert.equal((await hub.runRule('main', tlsRule.id)).result.ok, true, 'HTTPS template action must have a real implementation');

    const folder = path.join(root, 'folder'); fs.mkdirSync(folder); fs.writeFileSync(path.join(folder, 'hello.txt'), 'safe');
    const folderConnection = hub.createConnection('main', { name: 'Folder', type: 'folder', folderPath: folder }).connection;
    const folderDiscovery = await hub.discover('main', folderConnection.id);
    assert.ok(folderDiscovery.capabilities.includes('folder.list'));
    assert.equal(hub.getConnection('main', folderConnection.id).folderSummary.count, 1);

    assert.throws(() => hub.createConnection('main', { name: 'Unsafe command', type: 'command', command: 'whoami' }), /القائمة الآمنة/);
    const commandConnection = hub.createConnection('main', { name: 'Node version', type: 'command', command: 'node' }).connection;
    const commandResult = await hub.discover('main', commandConnection.id);
    assert.ok(commandResult.capabilities.includes('command.run'));

    const webhookMade = hub.createConnection('main', { name: 'Safe webhook', type: 'webhook' });
    assert.ok(webhookMade.hookToken);
    assert.equal(hub.getConnection('main', webhookMade.connection.id).webhookTokenHash, hub.tokenHash(webhookMade.hookToken));
    await assert.rejects(() => hub.handleWebhook('not-the-token', { ok: false }), /غير صحيح/);
    const malformedWebhookData = hub.read('main');
    malformedWebhookData.connections.find(x => x.id === webhookMade.connection.id).webhookTokenHash = 'broken-hash';
    hub.write('main', malformedWebhookData);
    await assert.rejects(() => hub.handleWebhook(webhookMade.hookToken, { event: 'malformed-storage' }), /غير صحيح/);
    const restoredWebhookData = hub.read('main');
    restoredWebhookData.connections.find(x => x.id === webhookMade.connection.id).webhookTokenHash = hub.tokenHash(webhookMade.hookToken);
    hub.write('main', restoredWebhookData);
    const received = await hub.handleWebhook(webhookMade.hookToken, { event: 'test' });
    assert.equal(received.received, 1);
    assert.equal(hub.getConnection('main', webhookMade.connection.id).webhookReceived, 1);

    const plugin = hub.registerPlugin('main', { id:'school-api', name:'School API', version:'1.0.0', description:'Safe local preset', adapter:'http', url:baseUrl });
    assert.equal(plugin.sourceType, 'declarative-safe');
    const pluginConnection = hub.connectionFromPlugin('main', plugin.id, { name:'School API test instance' });
    assert.equal(pluginConnection.connection.pluginId, plugin.id);
    assert.throws(() => hub.registerPlugin('main', { id:'school-api', name:'Duplicate', adapter:'http', url:baseUrl }), /بالفعل/);

    const enrollment = hub.createAgentEnrollment('main', { name:'Test device' });
    assert.ok(enrollment.token.length >= 32);
    const claimed = hub.claimAgent(enrollment.token, { name:'Test laptop', os:'linux', arch:'x64', hostname:'test-host', agentVersion:'1.0.0' });
    assert.equal(claimed.device.status, 'online');
    assert.throws(() => hub.claimAgent(enrollment.token, { name:'Replay attempt' }), /استُخدم من قبل/);
    const deviceToken = claimed.deviceToken;
    assert.equal(hub.heartbeatAgent('main', claimed.device.id, deviceToken, { hostname:'test-host' }).device.status, 'online');
    const deviceTask = hub.createAgentTask('main', claimed.device.id, { action:'device.info' });
    const polled = hub.takeAgentTasks('main', claimed.device.id, deviceToken);
    assert.equal(polled.tasks[0].id, deviceTask.id);
    const done = hub.completeAgentTask('main', claimed.device.id, deviceToken, deviceTask.id, { ok:true, summary:'Test device ready' });
    assert.equal(done.status, 'done');
    assert.equal(hub.completeAgentTask('main', claimed.device.id, deviceToken, deviceTask.id, { ok:true, summary:'retry' }).status, 'done', 'duplicate result must be idempotent');
    assert.throws(() => hub.createAgentTask('main', claimed.device.id, { action:'shell.exec', params:{command:'rm -rf /'} }), /قائمة إجراءات الجهاز الآمنة/);
    hub.removeDevice('main', claimed.device.id);
    assert.throws(() => hub.heartbeatAgent('main', claimed.device.id, deviceToken, {}), /غير صحيحة أو تم إلغاء الجهاز/);

    const overview = hub.overview('main');
    assert.equal(overview.connections.length, 7);
    assert.equal(overview.plugins.length, 1);
    assert.equal(overview.devices.length, 1);
    assert.ok(overview.inbox.length > 0);
    const health = hub.health('main');
    assert.equal(health.mode, 'read-only-local-audit');
    assert.equal(health.summary.connections, 7);
    assert.equal(health.summary.devices, 1);
    assert.equal(health.summary.revokedDevices, 1);
    assert.ok(health.summary.neverChecked >= 1, 'health report should flag connections that were never checked');
    assert.ok(health.checks.some(item => item.id === 'never-checked'));
    assert.ok(health.notes.some(note => /لا يتصل بالأهداف/.test(note)));
    assert.equal(JSON.stringify(health).includes('test-secret-123'), false, 'health report must not expose credentials');
    console.log('integration-hub: ok (320 scenario catalog, honest probe counts, OpenAPI JSON/YAML, local HTTP discovery, supported-only rules, safe command allowlist, folder read, token hashing, webhook validation including malformed stored hashes, HTTPS rule execution, cross-origin credential stripping and read-only health report)');
  } finally {
    if (server) await new Promise(resolve => server.close(resolve));
    if (targetServer) await new Promise(resolve => targetServer.close(resolve));
    fs.rmSync(root, { recursive: true, force: true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
