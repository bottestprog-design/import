'use strict';
const assert = require('node:assert/strict');
const { resolveSenderName } = require('../src/interaction');
const session = {
  settings:{ interactionUseRecipientNames:true },
  recipients:[
    { id:'recipient-one', name:'الاسم في المشروع', localName:'الاسم المحلي', whatsappName:'اسم واتساب', phone:'96873450000', digits:'96873450000', e164:'+96873450000', waChatId:'96873450000@c.us' },
    { id:'recipient-two', name:'جهة LID', phone:'96873450001', e164:'+96873450001', waChatId:'abc123@lid' },
  ],
};
assert.equal(resolveSenderName(session, { from:'96873450000@c.us', notifyName:'اسم واتساب الأصلي' }), 'الاسم المحلي', 'project-local names should be used when enabled');
assert.equal(resolveSenderName(session, { author:'abc123@lid', notifyName:'Profile Name' }), 'جهة LID', 'LID contact identifiers should resolve by their recorded WhatsApp ID');
assert.equal(resolveSenderName(session, { from:'unknown@c.us', notifyName:'اسم من واتساب' }), 'اسم من واتساب', 'unregistered sender must fall back to the WhatsApp-provided name');
assert.equal(resolveSenderName({ ...session, settings:{ interactionUseRecipientNames:false } }, { from:'96873450000@c.us', notifyName:'اسم واتساب الأصلي' }), 'اسم واتساب الأصلي', 'the setting must restore WhatsApp-provided names');
assert.equal(resolveSenderName(session, { author:'someone@lid', notifyName:'Profile Name' }, null, ['96873450001@c.us']), 'جهة LID', 'resolved phone/LID aliases must find the project contact');
console.log('interaction-recipient-name: ok (project names, phone JID, LID aliases, fallback, opt-out)');
