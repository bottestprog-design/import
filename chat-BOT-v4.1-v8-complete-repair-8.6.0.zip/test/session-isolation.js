'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const store = require('../src/store');
const suffix = `${process.pid}-${Date.now()}`;
const oldActive = store.activeSessionId();
let a, b, inactive;
try {
  a = store.createSession(`Isolation A ${suffix}`);
  const activeBeforeInactiveCreate = store.activeSessionId();
  inactive = store.createSessionInactive(`Isolation inactive ${suffix}`);
  assert.ok(store.listSessionIds().includes(inactive.id), 'inactive session must be registered');
  assert.equal(store.activeSessionId(), activeBeforeInactiveCreate, 'creating an inactive session must not change active session');
  assert.notEqual(store.getPaths(inactive.id).auth, store.getPaths(a.id).auth, 'inactive session must have a separate auth directory');
  store.deleteSession(inactive.id); inactive = null;
  a.recipients = [{ id:'only-a', name:'A only', digits:'96890000001', e164:'+96890000001', enabled:true }];
  a.ownerAssistant.messages = [{ id:'a-msg', role:'assistant', text:'A support feed' }];
  store.saveSession(a);
  b = store.createSession(`Isolation B ${suffix}`);
  b.recipients = [{ id:'only-b', name:'B only', digits:'96890000002', e164:'+96890000002', enabled:true }];
  b.ownerAssistant.messages = [{ id:'b-msg', role:'assistant', text:'B support feed' }];
  store.saveSession(b);
  assert.notEqual(store.getPaths(a.id).dir, store.getPaths(b.id).dir, 'session directories must be distinct');
  assert.notEqual(store.getPaths(a.id).auth, store.getPaths(b.id).auth, 'WhatsApp auth must be distinct per session');
  assert.notEqual(store.getPaths(a.id).media, store.getPaths(b.id).media, 'media library must be distinct per session');
  assert.equal(store.loadSession(a.id).recipients[0].id, 'only-a');
  assert.equal(store.loadSession(b.id).recipients[0].id, 'only-b');
  assert.equal(store.loadSession(a.id).ownerAssistant.messages[0].id, 'a-msg');
  assert.equal(store.loadSession(b.id).ownerAssistant.messages[0].id, 'b-msg');
  store.setActiveSession(b.id);
  const deleted = store.deleteSession(a.id);
  assert.equal(deleted.activeSessionId, b.id, 'deleting a background session must not switch the active session');
  assert.ok(!store.listSessionIds().includes(a.id), 'deleted session must disappear from session index');
  assert.ok(!fs.existsSync(store.getPaths(a.id).json), 'deleted session data must stay deleted');
  assert.equal(store.activeSessionId(), b.id, 'active session remains independent');
  store.deleteSession(b.id);
  assert.ok(!store.listSessionIds().includes(b.id));
  if (store.listSessionIds().includes(oldActive)) store.setActiveSession(oldActive);
  console.log('session-isolation: ok (independent data/auth/media/support feeds, safe deletion, stable active session)');
} catch (error) {
  for (const s of [a,b,inactive]) if (s?.id) { try { fs.rmSync(store.getPaths(s.id).dir, { recursive:true, force:true }); } catch {} }
  if (oldActive && store.listSessionIds().includes(oldActive)) store.setActiveSession(oldActive);
  throw error;
}
