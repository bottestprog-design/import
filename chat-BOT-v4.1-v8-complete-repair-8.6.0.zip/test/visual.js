'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'public/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'public/styles.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'public/index.html'), 'utf8');
for (const token of [
  'function nav()', 'nav-group-label', 'sidebar-foot', 'workspace-layout', 'modeToggleBtn',
  'chatbot-ui-mode', 'task-workspace', 'الإرسال التلقائي والمواعيد', 'aria-current',
  "root.dataset.uiMode = state.uiMode || 'dark'", 'function pageAssistant(', 'function bindLocalAssistant(', 'assistantCommandForm', 'assistantChatForm', 'assistantExportCommands', 'assistantImportCommands', 'assistantTeachLast', 'LocalAssistantEngine', 'chatbot-local-assistant-commands-v1'
]) assert.ok(app.includes(token) || fs.readFileSync(path.join(root, 'public/local-assistant.js'), 'utf8').includes(token), `Missing new UI feature token: ${token}`);
for (const token of [
  '.workspace-layout{display:grid', '.sidebar{position:sticky', '.nav-group', '.task-workspace>summary',
  'html[data-ui-mode="light"]', '@media(max-width:820px)', '@media(max-width:580px)',
  '@media(prefers-reduced-motion:reduce)', ':focus-visible'
]) assert.ok(css.includes(token), `Missing responsive/accessibility styling: ${token}`);
for (const token of ['id="app"','id="bgCanvas"','id="bgImageLayer"','src="local-assistant.js"']) assert.ok(html.includes(token), `Missing HTML hook: ${token}`);
for (const token of ['.assistant-workspace{display:grid', '.assistant-messages{', '.assistant-composer{', '.assistant-command-card', '@media(max-width:980px)', '.assistant-command-editor']) assert.ok(css.includes(token), `Missing assistant UI styling: ${token}`);
assert.ok((app.match(/id="scheduleBtn"/g)||[]).length <= 1, 'Unexpected duplicated schedule button template literal');
assert.ok((app.match(/id="modeToggleBtn"/g)||[]).length === 1, 'Theme toggle must be rendered exactly once per shell');
const oldControls = ['sendNowBtn','selectAllTargets','scheduleBtn','addRecipientBtn','connectGroupBtn','addRuleBtn','connectSessionBtn','saveUiThemeBtn','saveOperationReliability'];
for (const id of oldControls) assert.ok(app.includes(`id="${id}"`), `Existing workflow missing: ${id}`);
console.log('visual: ok (30+ checks)');
