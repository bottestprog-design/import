'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require.resolve('../src/whatsapp'), 'utf8');
function extract(name) {
  const re = new RegExp(`function ${name}\\([\\s\\S]*?\\n}`);
  const match = source.match(re);
  assert.ok(match, `Cannot find ${name} in WhatsApp service`);
  return match[0];
}
const context = { safeError: e => String(e?.message || e || '') , Date, Boolean, String, Number };
const extractSimple = name => { const match = source.match(new RegExp(`function ${name}\\([\\s\\S]*?\\n}`)); assert.ok(match, `Cannot find ${name} in WhatsApp service`); return match[0]; };
vm.runInNewContext(`${extract('idSerialized')}\n${extract('chatIdFromMessage')}\nconst MAX_CONTEXT_RECOVERY_ATTEMPTS = 3; const CONTEXT_RECOVERY_DELAYS_MS = [1800, 4000, 8000];\n${extractSimple('isContextNavigationError')}\n${extractSimple('navigationRecoveryPlan')}\n${extractSimple('matchesOutgoingIntent')}\n${extractSimple('matchesOutgoingConfirmation')}\nthis.chatIdFromMessage=chatIdFromMessage; this.isContextNavigationError=isContextNavigationError; this.navigationRecoveryPlan=navigationRecoveryPlan; this.matchesOutgoingIntent=matchesOutgoingIntent; this.matchesOutgoingConfirmation=matchesOutgoingConfirmation;`, context);
const chatIdFromMessage = context.chatIdFromMessage;
assert.equal(chatIdFromMessage({ fromMe:true, from:{_serialized:'11111111111@c.us'}, to:{_serialized:'96890000000@c.us'}, id:{remote:{_serialized:'96890000000@c.us'}} }), '96890000000@c.us', 'Outgoing messages must map to the recipient, not the account owner');
assert.equal(chatIdFromMessage({ from:{_serialized:'96890000000@c.us'}, to:{_serialized:'11111111111@c.us'}, id:{remote:{_serialized:'96890000000@c.us'}} }), '96890000000@c.us', 'Incoming messages must map to the sender');
assert.equal(chatIdFromMessage({ fromMe:true, from:'11111111111@c.us', to:'120363123@g.us', id:{remote:'120363123@g.us'} }), '120363123@g.us', 'Outgoing group messages must map to the group');

assert.equal(context.matchesOutgoingIntent({ at:1000, text:'hello', expectsMedia:false }, { body:'hello' }, 2000), true, 'exact outgoing text must match the pending send intent');

const manualSelfMessage = { fromMe:true, body:'رسالة يدوية جديدة', id:{remote:{_serialized:'96890000000@c.us'}} };
assert.equal(context.matchesOutgoingConfirmation(manualSelfMessage,'96890000000@c.us','','إرسال الملف كمرفق',1000,1100),false,'a text message must never be treated as confirmation of a captionless media send');
assert.equal(context.matchesOutgoingConfirmation({ ...manualSelfMessage, hasMedia:true, type:'document' },'96890000000@c.us','','إرسال الملف كمرفق',1000,1100),true,'a real outgoing attachment may confirm a captionless media send');
assert.equal(context.matchesOutgoingConfirmation({ ...manualSelfMessage, body:'different text' },'96890000000@c.us','hello','إرسال النص',1000,1100),false,'partial or unrelated text must not satisfy the send waiter');
assert.equal(context.matchesOutgoingConfirmation({ ...manualSelfMessage, body:'hello' },'other@c.us','hello','إرسال النص',1000,1100),false,'a message in a different chat must not confirm this send');
assert.equal(context.matchesOutgoingConfirmation({ fromMe:true, body:'hello', id:{remote:{_serialized:'96890000000@lid'}} },'96890000000@c.us','hello','إرسال النص',1000,1100,{chatIdAliases:['96890000000@c.us','96890000000@lid'],allowResolvedAlias:true}),true,'a mapped WhatsApp LID should confirm the same contact when the sender JID was a phone JID');
assert.equal(context.matchesOutgoingConfirmation({ fromMe:true, body:'hello', id:{remote:{_serialized:'96891111111@lid'}} },'96890000000@c.us','hello','إرسال النص',1000,1100,{chatIdAliases:['96890000000@c.us','96890000000@lid'],allowResolvedAlias:true}),false,'an unrelated LID must never confirm the outgoing message');
assert.equal(context.matchesOutgoingIntent({ at:1000, text:'hello', expectsMedia:false }, { body:'hello world' }, 2000), false, 'partial text must not suppress a manual self-chat message');
assert.equal(context.matchesOutgoingIntent({ at:1000, text:'', expectsMedia:true }, { hasMedia:true, type:'image' }, 2000), true, 'media intent must identify the generated outgoing attachment');
assert.equal(context.matchesOutgoingIntent({ at:1000, text:'hello', expectsMedia:false }, { body:'hello' }, 20000), false, 'expired intent must not suppress a later manual message');
assert.equal(context.isContextNavigationError(new Error('Execution context was destroyed, most likely because of a navigation.')), true, 'Chromium navigation failures should enter the bounded recovery path');
assert.equal(context.isContextNavigationError(new Error('QR authentication failed')), false, 'authentication failures must not be misclassified as context navigation');
assert.deepEqual(JSON.parse(JSON.stringify(context.navigationRecoveryPlan(new Error('Execution context was destroyed, most likely because of a navigation.'),0))), {attempt:1,maxAttempts:3,delayMs:1800});
assert.equal(context.navigationRecoveryPlan(new Error('Execution context was destroyed, most likely because of a navigation.'),1).delayMs,4000);
assert.equal(context.navigationRecoveryPlan(new Error('Execution context was destroyed, most likely because of a navigation.'),2).delayMs,8000);
assert.equal(context.navigationRecoveryPlan(new Error('Execution context was destroyed, most likely because of a navigation.'),3),null,'automatic recovery must stop at the configured bound');
assert.equal(context.navigationRecoveryPlan(new Error('QR authentication failed'),0),null,'normal QR authentication errors must not enter Chromium recovery');
console.log('whatsapp-identifiers: ok (chat IDs, LID aliases, outgoing-intent loop guard, exact matching, expiration and bounded Chromium recovery plan)');
