'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require.resolve('../src/whatsapp'), 'utf8');
const start = source.indexOf('  async lookupRecipientProfile(');
const end = source.indexOf('\n  async listWhatsAppContacts(', start);
const listStart = end + 1;
const listEnd = source.indexOf('\n  outboundKey(', listStart);
assert.ok(start >= 0 && end > start, 'recipient profile lookup must exist');
assert.ok(listStart > 0 && listEnd > listStart, 'WhatsApp contact list method must exist');
let method = source.slice(start, end).trim().replace(/^async lookupRecipientProfile\(/, 'async function lookupRecipientProfile(');
let listMethod = source.slice(listStart, listEnd).trim().replace(/^async listWhatsAppContacts\(/, 'async function listWhatsAppContacts(');
const context = {
  URL, Date, Set, String, Boolean, Array, Promise,
  withTimeout: promise => Promise.resolve(promise),
  safeError: error => String(error?.message || error || 'unknown error'),
};
vm.runInNewContext(`${method}\n${listMethod}\nthis.lookupRecipientProfile = lookupRecipientProfile; this.listWhatsAppContacts = listWhatsAppContacts;`, context);
const aliases = ['96873450000@c.us', '123456789@lid'];
const aliasMap = new Map();
let mappedPhone = '';
let noPicture = false;
const calls = [];
const profileCache = new Map();
const entry = { contactProfileCache: profileCache, chatAliasResolved: new Set() };
const client = {
  getContacts: async () => [{ id: { _serialized: aliases[0] }, number: '96899999999', name: 'اسم دفتر العناوين', pushname: 'اسم ملف WhatsApp', notifyName: 'اسم الإشعار', isGroup: false, isMe: false }],
  getContactLidAndPhone: async ids => ids.map(id => mappedPhone ? ({ lid: id, pn: { _serialized: `${mappedPhone}@c.us` } }) : null),
  getContactById: async id => {
    calls.push(['contact', id]);
    return { name: 'اسم دفتر العناوين', pushname: 'اسم ملف WhatsApp', notifyName: 'اسم الإشعار' };
  },
  getProfilePicUrl: async id => {
    calls.push(['picture', id]);
    if (noPicture) return null;
    return id === '123456789@lid' ? 'https://pps.whatsapp.net/profile.jpg?token=example' : null;
  },
};
const manager = {
  store: { safeSessionId: value => value },
  log: () => {},
  entry: () => entry,
  ensureReady: async () => client,
  normalizeWhatsAppAlias(value) {
    const id = String(value?._serialized || value || '').trim().toLowerCase();
    return /^(?:\d{6,20}@c\.us|\d{6,30}@lid)$/.test(id) ? id : '';
  },
  chatIdAliases: async () => aliases,
  cachedChatAliases: (_sid, id) => aliasMap.get(String(id?._serialized || id || '').toLowerCase()) || [String(id?._serialized || id || '').toLowerCase()],
  rememberChatAliases: (_sid, ids) => { const values = ids.map(value => String(value?._serialized || value?.$1 || value || '').toLowerCase()).filter(value => /^(?:\d{6,20}@c\.us|\d{6,30}@lid)$/.test(value)); for (const value of values) aliasMap.set(value, values); return values; },
};
(async () => {
  const recipient = { phone: '7345xxxx', e164: '+96873450000', waChatId: aliases[0] };
  const profile = await context.lookupRecipientProfile.call(manager, 'unit', recipient);
  assert.equal(profile.whatsappName, 'اسم ملف WhatsApp', 'profile name must prefer WhatsApp pushname over the app/local address-book name');
  assert.equal(profile.avatarStatus, 'available', 'a profile photo found through a linked LID must be reported as available');
  assert.equal(profile.whatsappAvatarUrl, 'https://pps.whatsapp.net/profile.jpg?token=example', 'the original WhatsApp profile photo URL should be retained for caching');
  assert.ok(calls.some(([kind, id]) => kind === 'picture' && id === '123456789@lid'), 'the lookup must retry profile-picture lookup across linked WhatsApp IDs');
  assert.equal(profileCache.get(aliases[1]), profile, 'profile result should be cached for each linked identifier');

  const listed = await context.listWhatsAppContacts.call(manager, 'unit');
  assert.equal(listed[0].name, 'اسم ملف WhatsApp', 'the WhatsApp contact picker must prefer the name set on the WhatsApp profile over the address-book label');
  assert.equal(listed[0].whatsappName, 'اسم ملف WhatsApp', 'the profile name must be kept separately for contact creation');
  assert.equal(listed[0].phone, '96873450000', 'the validated c.us JID must outrank inconsistent address-book number fields');

  client.getContacts = async () => [{ id: { _serialized: '123456789@lid' }, number: '123456789', name: 'جهة غير محسومة', pushname: 'اسم آخر' }];
  const unresolved = await context.listWhatsAppContacts.call(manager, 'unit');
  assert.equal(unresolved.length, 1);
  assert.equal(unresolved[0].phone, '', 'an LID numeric suffix must never be treated as a phone number');
  assert.equal(unresolved[0].canAdd, false, 'unverified LID-only contacts must not be added to the sending list');
  assert.equal(unresolved[0].phone, '', 'a plausible-looking address-book number must not bypass LID verification');
  mappedPhone = '96870000000';
  const resolved = await context.listWhatsAppContacts.call(manager, 'unit');
  assert.equal(resolved[0].phone, '96870000000', 'a phone number supplied by WhatsApp LID-to-PN mapping should become usable');
  assert.equal(resolved[0].idVerified, true, 'LID-to-PN mapped contacts should be marked as verified');

  noPicture = true;
  calls.length = 0;
  const withoutPhoto = await context.lookupRecipientProfile.call(manager, 'unit', recipient);
  assert.equal(withoutPhoto.avatarStatus, 'none', 'a confirmed missing profile photo should not be reported as an unexplained error');
  assert.equal(withoutPhoto.avatarReadOk, true, 'a confirmed missing photo is a successful lookup result');
  assert.equal(withoutPhoto.whatsappAvatarUrl, '', 'missing picture result should not reuse a stale remote URL');

  client.getProfilePicUrl = async () => { throw new Error('profile picture permission denied'); };
  const failed = await context.lookupRecipientProfile.call(manager, 'unit', recipient);
  assert.equal(failed.avatarStatus, 'error', 'failed image lookups must be distinguishable from a confirmed missing photo');
  assert.ok(failed.avatarError.includes('permission denied'), 'image lookup failure should remain diagnosable');
  console.log('whatsapp-profile-lookup: ok (WhatsApp profile-name priority in profile lookup and contact picker, linked-ID photo retry, confirmed no-photo state, explicit lookup errors, alias cache)');
})().catch(error => { console.error(error); process.exitCode = 1; });
