'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const store = require('../src/store');
const { DeliveryService } = require('../src/delivery');

const sid = `send-media-${Date.now()}`;
const paths = store.getPaths(sid);
const s = store.loadSession(sid);
s.settings.preText = '';
s.settings.postText = '';
s.settings.sendDelayMs = 0;
s.settings.retryAttempts = 1;
s.settings.retryDelayMs = 250;
s.settings.sendTimeoutMs = 5000;
s.settings.maxImageSizeMB = 10;
s.recipients = [{ id:'r1', name:'Test recipient', digits:'96890000000', e164:'+96890000000', phone:'96890000000', country:'OM', enabled:true }];
s.groups = [];
store.saveSession(s);
fs.mkdirSync(paths.media, { recursive:true });
fs.writeFileSync(path.join(paths.media,'img.1.jpg'), Buffer.from([0xff,0xd8,0xff,0xd9]));
fs.writeFileSync(path.join(paths.media,'img.2.jpg'), Buffer.from([0xff,0xd8,0x00,0xff,0xd9]));
fs.writeFileSync(path.join(paths.media,'guide.pdf'), Buffer.from('%PDF-1.4\n% test data\n%%EOF'));
const operations = [];
const fakeWhatsApp = {
  async resolveChatId(_id, target) {
    assert.equal(target.id, 'r1');
    assert.equal(target.e164, '+96890000000');
    return '96890000000@c.us';
  },
  async sendText(_id, chatId, text) { operations.push({ kind:'text', chatId, text }); return { __chatBotAck:{status:'confirmed'} }; },
  async sendMedia(_id, chatId, file, options) { operations.push({ kind:'media', chatId, filename:path.basename(file), ...options }); return { __chatBotAck:{status:'confirmed'} }; },
};
const delivery = new DeliveryService({ store, whatsapp:fakeWhatsApp, log:()=>{} });
const opts = { targetKeys:['r:r1'], repeatGuard:false, sendDelayMs:0, preText:'', postText:'' };
(async () => {
  // Image captions must use WhatsApp media options and keep the image as an image.
  let result = await delivery.sendNow(sid, { ...opts, mediaIds:['img.1.jpg'], text:'Photo caption', textMode:'caption' });
  assert.equal(result.sent.length,1); assert.equal(result.failed.length,0);
  let mediaOp = operations.find(x=>x.kind==='media');
  assert.equal(mediaOp.filename,'img.1.jpg'); assert.equal(mediaOp.chatId,'96890000000@c.us'); assert.equal(mediaOp.caption,'Photo caption'); assert.equal(mediaOp.asDocument,false);

  // The main message is sent once per recipient, not repeated before every selected image.
  operations.length = 0;
  result = await delivery.sendNow(sid, { ...opts, mediaIds:['img.1.jpg','img.2.jpg'], text:'Opening message', textMode:'before' });
  assert.equal(result.sent.length,2); assert.equal(result.failed.length,0);
  assert.deepEqual(operations.map(x=>x.kind),['text','media','media']);
  assert.equal(operations.filter(x=>x.kind==='text' && x.text==='Opening message').length,1);

  // A document cannot carry an image caption; auto mode must preserve the text separately.
  operations.length = 0;
  result = await delivery.sendNow(sid, { ...opts, mediaIds:['guide.pdf'], text:'Document note', textMode:'auto' });
  assert.equal(result.sent.length,1); assert.deepEqual(operations.map(x=>x.kind),['text','media']);
  mediaOp = operations.find(x=>x.kind==='media'); assert.equal(mediaOp.filename,'guide.pdf'); assert.equal(mediaOp.asDocument,true); assert.equal(mediaOp.caption,'');

  // After mode must put the standalone message after the attachment.
  operations.length = 0;
  result = await delivery.sendNow(sid, { ...opts, mediaIds:['img.1.jpg'], text:'Closing note', textMode:'after' });
  assert.equal(result.sent.length,1); assert.deepEqual(operations.map(x=>x.kind),['media','text']); assert.equal(operations[1].text,'Closing note');

  // Text-only mode remains a normal message to the selected person.
  operations.length = 0;
  result = await delivery.sendNow(sid, { ...opts, text:'Standalone text', textMode:'before' });
  assert.equal(result.sent.length,1); assert.deepEqual(operations.map(x=>x.kind),['text']); assert.equal(operations[0].text,'Standalone text');

  // An empty target selection must never fall back to sending to every recipient.
  operations.length = 0;
  await assert.rejects(() => delivery.sendNow(sid, { ...opts, targetKeys:[], mediaIds:['img.1.jpg'] }), /حدد مستلمًا أو مجموعة/);
  assert.equal(operations.length,0);
  await assert.rejects(() => delivery.sendNow(sid, { ...opts, mediaIds:[], text:'ignored', textMode:'none' }), /اكتب رسالة أو اختر ملفًا/);
  assert.equal(operations.length,0);

  fs.rmSync(paths.dir,{recursive:true,force:true});
  console.log('send-media: ok (image caption, target routing, text placement, multi-file no-repeat, document fallback)');
})().catch(error => { try { fs.rmSync(paths.dir,{recursive:true,force:true}); } catch {} console.error(error); process.exitCode=1; });
