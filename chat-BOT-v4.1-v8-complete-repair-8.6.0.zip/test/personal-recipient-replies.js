'use strict';
const assert = require('node:assert/strict');
const { InteractionEngine } = require('../src/interaction');
const { normalizeRecipientAutoReply } = require('../src/store');
function newSession(autoReply, settings = {}) {
  return {
    id:'personal-test', name:'اختبار',
    settings:{ timezone:'Asia/Muscat', interactionEnabled:true, interactionIgnoreOwn:true, interactionScope:'all', interactionChatIds:[], interactionQuietEnabled:false, interactionQuietStart:'23:00', interactionQuietEnd:'07:00', interactionQuietAction:'silence', interactionQuietReply:'', interactionQuietCooldownSec:3600, interactionFallbackEnabled:true, interactionFallbackCooldownSec:30, interactionFallbackReply:'رد عام {{sender}}', maxActionsPerMinute:100, interactionCooldownCapSec:86400, interactionUseRecipientNames:true, ...settings },
    interaction:{ enabled:true, rules:[{id:'global',name:'قاعدة عامة',enabled:true,priority:1,when:{type:'message',match:'any',value:''},then:{reply:'رد عام'},scope:'all',chatIds:[],cooldownSec:0}], recent:[], health:{} },
    recipients:[{id:'recipient-1',name:'الاسم الافتراضي',localName:'اسمي في المشروع',whatsappName:'اسم واتساب',phone:'96890000000',e164:'+96890000000',waChatId:'96890000000@c.us',enabled:true,autoReply:normalizeRecipientAutoReply(autoReply)}],
    stats:{ interactionActions:0, interactionErrors:0 }
  };
}
function makeMessage(body, id = 'message-1') {
  return { id:{_serialized:id,remote:{_serialized:'96890000000@c.us'}}, from:'96890000000@c.us', to:'96890000000@c.us', chatId:'96890000000@c.us', body, notifyName:'اسم ملف واتساب', fromMe:false, getChat:async()=>({id:{_serialized:'96890000000@c.us'},name:'اسم ملف واتساب'}) };
}
function rig(session) {
  const sent=[];
  const store={loadSession:()=>session,saveSession:value=>{ Object.assign(session,value); }};
  const whatsapp={sendText:async(id,chatId,text)=>{sent.push({kind:'send',chatId,text});return {};},replyToMessage:async(id,msg,text)=>{sent.push({kind:'reply',chatId:msg.chatId,text});return {};},reactToMessage:async()=>({})};
  return {engine:new InteractionEngine({store,whatsapp,log:()=>{}}),sent,session};
}
(async()=>{
  const longReply='رسالة طويلة '.repeat(1500);
  const custom=rig(newSession({mode:'custom',rules:[{id:'hi',match:'contains',value:'سعر',reply:'{{sender}} قال: {{message}}'}],fallbackToGlobal:true,cooldownSec:0}));
  const result=await custom.engine.onMessage('personal-test',makeMessage('كم السعر؟'));
  assert.equal(result.action,'personal-reply');
  assert.equal(custom.sent[0].text,'اسمي في المشروع قال: كم السعر؟','per-recipient response should use local project name, not WhatsApp display name');

  const disabled=rig(newSession({mode:'off',rules:[],fallbackToGlobal:true}));
  const disabledResult=await disabled.engine.onMessage('personal-test',makeMessage('أي رسالة'));
  assert.equal(disabledResult.reason,'personal-disabled');
  assert.equal(disabled.sent.length,0,'individual off switch must override global rules/fallbacks');

  const long=rig(newSession({mode:'custom',rules:[{id:'long',match:'any',value:'',reply:longReply}],fallbackToGlobal:false,cooldownSec:0}));
  const longResult=await long.engine.onMessage('personal-test',makeMessage('أرسل ردًا طويلًا','message-long'));
  assert.equal(longResult.action,'personal-reply');
  assert.equal(long.sent[0].text.length,longReply.trim().length,'personal rule text must not be silently truncated; only surrounding whitespace is normalized');

  const fallback=rig(newSession({mode:'custom',rules:[],fallbackReply:'رسالة مخصصة لـ {{sender}}: {{message}}',fallbackToGlobal:false,cooldownSec:0}));
  const fallbackResult=await fallback.engine.onMessage('personal-test',makeMessage('استفسار جديد','message-fallback'));
  assert.equal(fallbackResult.action,'personal-reply');
  assert.equal(fallback.sent[0].text,'رسالة مخصصة لـ اسمي في المشروع: استفسار جديد');

  const normalized=normalizeRecipientAutoReply({mode:'custom',rules:[{match:'contains',value:'سعر',reply:longReply}],fallbackReply:longReply});
  assert.equal(normalized.rules[0].reply.length,longReply.length);
  assert.equal(normalized.fallbackReply.length,longReply.length);
  console.log('personal recipient replies: ok');
})().catch(error=>{console.error(error);process.exitCode=1;});
