'use strict';
const assert = require('node:assert/strict');
const { patchUtilsText, patchClientProfilePicText, syntaxOk } = require('../src/compat');

const bad = `const message={id:1};\nif (message && message.__x_id) delete message.__x_id;\nconst x = message.id;`;
const fixed = patchUtilsText(bad);
assert.equal(fixed.ok, true);
assert.equal(syntaxOk(fixed.text, 'synthetic-utils.js'), true);
assert.equal(fixed.text.includes('message && message.__x_id'), false);

// Mirrors the actual whatsapp-web.js 1.34.7 sendMessage structure. This is
// the regression that produced the user's exact error for images and documents.
const modern = `window.WWebJS.sendMessage = async (chat, content, options = {}) => {\n  let mediaOptions = {};\n  mediaOptions = await window.WWebJS.processMediaData(options.media, {});\n  const newMsgKey = makeMsgKey();\n  const ephemeralFields = {};\n  const message = {\n    ...options,\n    id: newMsgKey,\n    body: content,\n    ...ephemeralFields,\n    ...mediaOptions,\n    ...(mediaOptions.toJSON ? mediaOptions.toJSON() : {}),\n  };\n  // Bot's won't reply if canonicalUrl is set (linking)\n  if (botOptions) { delete message.canonicalUrl; }\n  return window.require('WAWebCollections').Msg.get(newMsgKey._serialized);\n};\nwindow.WWebJS.editMessage = async () => {};\nwindow.WWebJS.getChats = async () => {};`;
const modernFixed = patchUtilsText(modern);
assert.equal(modernFixed.ok, true, modernFixed.note);
assert.equal(syntaxOk(modernFixed.text, 'modern-utils.js'), true);
assert.equal(modernFixed.text.includes('delete message.__x_id;'), true);
assert.ok(modernFixed.text.indexOf('delete message.__x_id;') > modernFixed.text.indexOf('...mediaOptions'));
assert.ok(modernFixed.text.indexOf('delete message.__x_id;') < modernFixed.text.indexOf('// Bot\'s won\'t reply'));
assert.equal(modernFixed.text.includes('newMsgKey._serialized || newMsgKey.$1'), true);
assert.ok(modernFixed.text.includes('CHAT_BOT_MSGKEY_SERIALIZED_COMPAT'), 'WhatsApp Web MsgKey $1 compatibility shim must be injected');
assert.ok(modernFixed.text.includes("Object.defineProperty(msgKeyPrototype, '_serialized'"), 'MsgKey serialized getter must tolerate WhatsApp Web 2.3000.x');
assert.ok(modernFixed.text.includes('window.WWebJS.getMsgKeyId = (key) => key?._serialized ?? key?.$1 ?? undefined;'));

// Idempotency: postinstall and server startup may both invoke the patcher.
const twice = patchUtilsText(modernFixed.text);
assert.equal(twice.ok, true, twice.note);
assert.equal((twice.text.match(/delete message\.__x_id\s*;/g) || []).length, 1, 'media id deletion must not be duplicated');
assert.equal((twice.text.match(/CHAT_BOT_MSGKEY_SERIALIZED_COMPAT/g) || []).length, 1, 'MsgKey compatibility must be idempotent');

// Windows CRLF archives must also receive the fix correctly.
const crlf = patchUtilsText(modern.replace(/\n/g, '\r\n'));
assert.equal(crlf.ok, true, crlf.note);
assert.equal(syntaxOk(crlf.text, 'modern-utils-crlf.js'), true);
assert.equal((crlf.text.match(/delete message\.__x_id\s*;/g) || []).length, 1);

// Unknown source layouts must fail closed rather than claim the media fix worked.
const unknown = patchUtilsText(`window.WWebJS.sendMessage = async () => { const msg = {}; return msg; };`);
assert.equal(unknown.ok, false, 'unknown whatsapp-web.js layout must not be reported as fixed');

const valid = `const message={id:1};\nconst x = message.id;`;
const untouched = patchUtilsText(valid);
assert.equal(untouched.ok, true);
assert.equal(untouched.text, valid);


// WhatsApp Web changed the Chat object expected by getProfilePicUrl in the
// pinned whatsapp-web.js 1.34.7 client. Patch only the expected method body.
const clientSource = `class Client {
 async getProfilePicUrl(contactId) {
   const profilePic = await this.pupPage.evaluate(async (contactId) => {
     try {
       const chat = await window.WWebJS.getChat(contactId);
       return await window
         .require('WAWebContactProfilePicThumbBridge')
         .requestProfilePicFromServer(chat);
     } catch (err) {
       if (err.name === 'ServerStatusCodeError') return undefined;
       throw err;
     }
   }, contactId);
   return profilePic ? profilePic.eurl : undefined;
 }
 async getCommonGroups(contactId) { return []; }
}`;
const picFixed = patchClientProfilePicText(clientSource);
assert.equal(picFixed.ok, true, picFixed.note);
assert.equal(picFixed.changed, true);
assert.ok(picFixed.text.includes("window.require('WAWebWidFactory').createWid(contactId)"));
assert.ok(picFixed.text.includes("window.require('WAWebFindChatAction').findOrCreateLatestChat(wid)"));
assert.ok(picFixed.text.includes("requestProfilePicFromServer(chat)"));
assert.equal(syntaxOk(picFixed.text, 'synthetic-client.js'), true);
const picTwice = patchClientProfilePicText(picFixed.text);
assert.equal(picTwice.ok, true);
assert.equal(picTwice.changed, false, 'profile-pic patch must be idempotent');
assert.equal(patchClientProfilePicText('class Client { async getProfilePicUrl(id) {} }').ok, false, 'unknown method layout must not be guessed');

console.log('OK compat media ID and WhatsApp profile-picture compatibility, CRLF, idempotency, fail-closed validation');
