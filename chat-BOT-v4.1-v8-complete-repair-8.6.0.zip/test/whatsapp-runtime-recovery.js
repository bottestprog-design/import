'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require.resolve('../src/whatsapp'), 'utf8');
const start = source.indexOf('  async recoverRuntimeNavigation(');
const end = source.indexOf('\n  async start(', start);
assert.ok(start >= 0 && end > start, 'runtime navigation recovery method must exist');
let method = source.slice(start, end).trim();
method = method.replace(/^async recoverRuntimeNavigation\(/, 'async function recoverRuntimeNavigation(');
const context = {
  Date, Math, Promise, setTimeout, clearTimeout,
  safeError: e => String(e?.message || e || 'unknown'),
  withTimeout: promise => Promise.resolve(promise),
  navigationRecoveryPlan(error, previousAttempts = 0) {
    if (!/execution context was destroyed|cannot find context with specified id|context\s+destroyed.*navigation|most likely because of a navigation/i.test(String(error?.message || error))) return null;
    const delays = [1800, 4000, 8000], attempts = Math.max(0, Math.floor(Number(previousAttempts) || 0));
    return attempts >= 3 ? null : { attempt:attempts + 1, maxAttempts:3, delayMs:delays[Math.min(attempts, delays.length - 1)] };
  },
};
vm.runInNewContext(`${method}\nthis.recoverRuntimeNavigation = recoverRuntimeNavigation;`, context);
function managerFor(id) {
  const entry = { id, client:null, status:'idle', ready:false, qr:null, stopping:false, generation:0, navigationRetries:0, lastError:'', reconnectTimer:null, readyProbe:null };
  const manager = {
    entry: value => { assert.equal(value, id); return entry; },
    clearReadyProbe: e => { if (e.readyProbe) clearInterval(e.readyProbe); e.readyProbe=null; },
    log: () => {}, emitStatus: () => {},
    start: async () => ({ status:'ready', ready:true }),
  };
  return { manager, entry };
}
(async () => {
  const runtime = managerFor('runtime');
  const brokenClient = { destroy: async () => true };
  Object.assign(runtime.entry, { client:brokenClient, ready:true, status:'ready', generation:4, navigationRetries:0, stopping:false, lastError:'', reconnectTimer:null, readyProbe:null });
  await context.recoverRuntimeNavigation.call(runtime.manager, 'runtime', brokenClient, 4, new Error('Execution context was destroyed, most likely because of a navigation.'));
  assert.equal(runtime.entry.status,'recovering');
  assert.equal(runtime.entry.ready,false);
  assert.equal(runtime.entry.client,null);
  assert.equal(runtime.entry.navigationRetries,1);
  assert.ok(runtime.entry.lastError.includes('Execution context was destroyed'));
  assert.ok(runtime.entry.reconnectTimer,'a bounded retry should be scheduled');
  clearTimeout(runtime.entry.reconnectTimer); runtime.entry.reconnectTimer=null;

  const exhausted = managerFor('exhausted');
  const finalClient = { destroy: async () => true };
  Object.assign(exhausted.entry, { client:finalClient, ready:true, status:'ready', generation:9, navigationRetries:3, stopping:false, lastError:'', reconnectTimer:null, readyProbe:null });
  await context.recoverRuntimeNavigation.call(exhausted.manager, 'exhausted', finalClient, 9, new Error('Execution context was destroyed, most likely because of a navigation.'));
  assert.equal(exhausted.entry.status,'error','the recovery limit should produce a visible error rather than looping forever');
  assert.equal(exhausted.entry.ready,false);
  assert.equal(exhausted.entry.client,null);
  assert.equal(exhausted.entry.navigationRetries,3);
  console.log('whatsapp-runtime-recovery: ok (runtime context error recovery, retained diagnostics, bounded retries, terminal error state)');
})().catch(error => { console.error(error); process.exitCode=1; });
