'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const { LocalCommandEngine, HELP, parseFields } = require('../src/local-command-engine');

// Stub only the existing phone parser dependency so this suite remains executable
// without installing npm packages. Production code uses src/phones.js unchanged.
const phonePath = require.resolve('../src/phones');
require.cache[phonePath] = { id: phonePath, filename: phonePath, loaded: true, exports: {
  countries() { return ['OM','SA','EG','AE','KW','QA','BH','JO','IQ','YE','LB','SY','PS','MA','DZ','TN','LY','SD','IN','PK','TR','GB','US','CA','DE','FR','BD','PH'].map(code=>({code})); },
  parse(input, country='OM') {
    let raw=String(input||'').trim().replace(/[^\d+]/g,''); if(!raw) throw new Error('رقم الهاتف فارغ.');
    if(raw.startsWith('00')) raw='+'+raw.slice(2);
    let digits=raw.replace(/\D/g,''); let detected=String(country||'OM').toUpperCase();
    if(raw.startsWith('+')) {
      if(digits.startsWith('968')) detected='OM'; else if(digits.startsWith('966')) detected='SA'; else if(digits.startsWith('20')) detected='EG'; else if(digits.startsWith('971')) detected='AE';
    } else if(detected==='OM'&&digits.length===8) digits='968'+digits;
    else if(detected==='SA'&&digits.length===9) digits='966'+digits;
    if(digits.length<8||digits.length>15) throw new Error('رقم الهاتف غير صالح.');
    return {digits, country:detected, callingCode:detected==='SA'?'966':detected==='EG'?'20':detected==='AE'?'971':'968', e164:'+'+digits, international:'+'+digits, formatted:'+'+digits, national:digits.slice(-8)};
  }
}};
const { phones } = { phones: require('../src/phones') };
const sessions = new Map(); let activeSession = 'main'; const selfSendCalls=[];
fs.mkdirSync(path.join('/tmp','chatbot-local-command-test','main','media'),{recursive:true});
fs.writeFileSync(path.join('/tmp','chatbot-local-command-test','main','media','manual.pdf'),'mock-pdf-content');
const initial = {
  id:'main',name:'الجلسة الرئيسية',setupComplete:false,
  settings:{timezone:'Asia/Muscat',sendDelayMs:0,scheduledGroupsEnabled:true,interactionEnabled:true,interactionScope:'all',interactionIgnoreOwn:true,interactionChatIds:[],automationEnabled:true,preText:'',postText:'',maxImageSizeMB:20},
  recipients:[],groups:[],automation:{enabled:true,tasks:[],recent:[]},
  interaction:{enabled:true,rules:[],recent:[]},ownerAssistant:{messages:[],issues:[],activity:[],pendingNotifications:[]},
  stats:{},cycle:{},logs:[]
};
sessions.set('main', JSON.parse(JSON.stringify(initial)));
const store={
  loadSession(id){const s=sessions.get(id);if(!s)throw new Error('الجلسة غير موجودة.');return JSON.parse(JSON.stringify(s));},
  saveSession(s){const next=JSON.parse(JSON.stringify(s));sessions.set(next.id,next);return JSON.parse(JSON.stringify(next));},
  listSessionIds(){return [...sessions.keys()]},
  deleteSession(id){if(!sessions.has(id))throw new Error('الجلسة غير موجودة.');if(sessions.size<=1)throw new Error('لا يمكن حذف آخر جلسة.');sessions.delete(id);return {deletedSessionId:id,activeSessionId:activeSession,sessions:[...sessions.keys()]};},
  activeSessionId(){return activeSession;},
  createSessionInactive(name){const id='s-created-'+(sessions.size+1);sessions.set(id,{...JSON.parse(JSON.stringify(initial)),id,name,recipients:[],groups:[],automation:{enabled:true,tasks:[],recent:[]},interaction:{enabled:true,rules:[],recent:[]},ownerAssistant:{messages:[],issues:[],activity:[],pendingNotifications:[]}});return this.loadSession(id);},
  renameSession(id,name){const s=this.loadSession(id);s.name=name;return this.saveSession(s);},
  getPaths(id){return {id,dir:path.join('/tmp','chatbot-local-command-test',id),media:path.join('/tmp','chatbot-local-command-test',id,'media'),images:path.join('/tmp','chatbot-local-command-test',id,'media')};},
  normalizeAutomationTask(task){return {...task,id:task.id||'task-'+(sessions.get('main').automation.tasks.length+1),createdAt:task.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString(),enabled:task.enabled!==false,lastRunKey:task.lastRunKey||'',lastResult:task.lastResult||null};},
};
let ready=true; const sentCalls=[], groupCalls=[];
const whatsapp={
  listRuntime:()=>({ready,status:ready?'ready':'disconnected',info:{wid:{user:'96891230000'}}}),
  selfChatId:()=> '96891230000@c.us',
  stop:async()=>({}),
  listGroups:async()=>[{gid:'120363000000000001@g.us',name:'فريق العمل',participantsCount:3,participants:[],admins:[]}],
  sendText:async(_id,chatId,text)=>{selfSendCalls.push({chatId,text});return {__chatBotAck:{status:'confirmed'}};},
  analyzeGroupInvite:async code=>({gid:'120363000000000001@g.us',name:'فريق العمل',inviteCode:code,description:'وصف الاختبار',participantsCount:3,participants:[],admins:[]}),
  getGroupInfo:async(_id,gid)=>({gid,name:'فريق العمل',description:'وصف الاختبار',participantsCount:3,participants:[],admins:[]}),
  resolveChatId:async(_id,target)=>`${target.digits}@c.us`,
};
const delivery={
  files:(id)=>fs.existsSync(path.join(store.getPaths(id).media,'manual.pdf'))?[{id:'manual.pdf',filename:'manual.pdf',isImage:false,size:1024}]:[],
  sendNow:async(id,payload)=>{sentCalls.push({id,payload});return {ok:true,sent:[{target:'أحمد',status:'confirmed'}],failed:[]};},
  scheduledTaskRun:async(id,task)=>({ok:true,sent:[{target:'أحمد'}],failed:[],taskId:task.id}),
};
function saveGroup(id,info){const s=store.loadSession(id);let g=s.groups.find(x=>x.gid===info.gid);if(!g){g={id:'group-'+(s.groups.length+1),...info,enabled:true};s.groups.push(g);}else Object.assign(g,info);store.saveSession(s);groupCalls.push(g.gid);return g;}
function normalizeAutomationPayload(id,body){
  const s=store.loadSession(id); if(!Array.isArray(body.targetKeys)||!body.targetKeys.length)throw new Error('حدد مستلمًا.');
  if(!/^\d{2}:\d{2}$/.test(body.time))throw new Error('وقت غير صحيح.');
  if(body.mode==='once'&&!/^\d{4}-\d{2}-\d{2}$/.test(body.date))throw new Error('التاريخ غير صحيح.');
  for(const k of body.targetKeys) if(![...s.recipients.map(x=>'r:'+x.id),...s.groups.map(x=>'g:'+x.id)].includes(k))throw new Error('المستلم غير موجود.');
  return store.normalizeAutomationTask({...body,id:'task-'+(s.automation.tasks.length+1)});
}
const engine=new LocalCommandEngine({store,whatsapp,delivery,saveGroup,normalizeAutomationPayload,log:()=>{},refreshRecipientProfile:async(id,recipientId)=>{const saved=store.loadSession(id),person=saved.recipients.find(x=>x.id===recipientId);if(!person)return {ok:false,error:'missing'};person.whatsappName='اسم WhatsApp المحدث';person.whatsappAvatarUrl='https://pps.whatsapp.net/profile-test';person.whatsappAvatarFile='recipient-wa-avatar.jpg';person.profileCheckedAt=new Date().toISOString();if(!person.localName)person.name=person.whatsappName;store.saveSession(saved);return {ok:true,profile:{whatsappName:person.whatsappName,avatarStatus:'available'}};}});
(async()=>{
  assert.ok(HELP.includes('أضف شخصًا')&&HELP.includes('أرسل الآن')&&HELP.includes('أنشئ موعدًا')&&HELP.includes('أنشئ ردًا تلقائيًا')&&HELP.includes('مساعدة التفاعل'),'help must contain actionable, conversational command syntax');
  assert.ok(HELP.length < 3200, 'the welcome instructions must fit within the WhatsApp message limit');
  assert.deepEqual(parseFields('أضف موعد | الاسم=تذكير | التاريخ=2026-10-20 | الوقت=18:30 | إلى=أحمد | الرسالة=مرحبا'),{name:'تذكير',date:'2026-10-20',time:'18:30',to:'أحمد',text:'مرحبا'});

  let r=await engine.run('main','أنشئ جلسة | الاسم=حساب تجريبي ثاني'); assert.equal(r.ok,true); assert.ok(r.response.includes('حساب تجريبي ثاني')); assert.equal(store.activeSessionId(),'main','creating a session from self chat must not switch active session'); assert.equal(store.listSessionIds().length,2);
  r=await engine.run('main','غيّر اسم الجلسة إلى الجلسة الرئيسية المحدثة'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').name,'الجلسة الرئيسية المحدثة');

  r=await engine.run('main','أضف الرقم +96891234567 باسم أحمد');
  assert.equal(r.ok,true); assert.equal(r.action,'add-recipient');
  let s=store.loadSession('main'); assert.equal(s.recipients.length,1); assert.equal(s.recipients[0].name,'أحمد'); assert.equal(s.recipients[0].e164,'+96891234567');
  r=await engine.run('main','اعرض الأشخاص'); assert.ok(r.response.includes('أحمد')&&r.response.includes('+96891234567'));
  r=await engine.run('main','غيّر اسم المستلم أحمد إلى أحمد الجديد'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').recipients[0].name,'أحمد الجديد');
  r=await engine.run('main','عطّل المستلم أحمد الجديد'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').recipients[0].enabled,false);
  r=await engine.run('main','فعّل المستلم أحمد الجديد'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').recipients[0].enabled,true);

  r=await engine.run('main','حلل المجموعة https://chat.whatsapp.com/InviteExampleCode');
  assert.equal(r.ok,true); assert.equal(r.action,'analyze-group'); assert.ok(r.response.includes('فريق العمل'));
  s=store.loadSession('main'); assert.equal(s.groups.length,1); assert.equal(s.groups[0].gid,'120363000000000001@g.us');
  r=await engine.run('main','اعرض المجموعات'); assert.ok(r.response.includes('فريق العمل'));
  r=await engine.run('main','معلومات المجموعة فريق العمل'); assert.equal(r.action,'group-details'); assert.ok(r.response.includes('فريق العمل'));
  r=await engine.run('main','غيّر اسم المجموعة فريق العمل إلى فريق التجربة'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').groups[0].name,'فريق التجربة'); assert.ok(r.response.includes('لم أغيّر اسم مجموعة WhatsApp نفسها'));
  const otherGroup={id:'group-duplicate',gid:'120363000000000002@g.us',name:'مجموعة أخرى',enabled:true}; s=store.loadSession('main'); s.groups.push(otherGroup); store.saveSession(s);
  let duplicateNameError=''; try { await engine.run('main','غيّر اسم المجموعة فريق التجربة إلى مجموعة أخرى'); } catch (e) { duplicateNameError=e.message; } assert.ok(duplicateNameError.includes('مستخدم بالفعل')); assert.equal(store.loadSession('main').groups[0].name,'فريق التجربة','duplicate local group names must not be allowed');
  store.loadSession('main').groups=store.loadSession('main').groups.filter(g=>g.id!=='group-duplicate'); store.saveSession(store.loadSession('main'));
  r=await engine.run('main','غيّر اسم المجموعة فريق التجربة إلى فريق العمل'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').groups[0].name,'فريق العمل');
  r=await engine.run('main','افحص الرقم +96891234567'); assert.equal(r.ok,true); assert.equal(r.action,'validate-phone'); assert.ok(r.response.includes('أكد WhatsApp'));
  r=await engine.run('main','عطّل المجموعة فريق العمل'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').groups[0].enabled,false);
  r=await engine.run('main','فعّل المجموعة فريق العمل'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').groups[0].enabled,true);

  const date=new Date(Date.now()+5*86400000).toISOString().slice(0,10);
  r=await engine.run('main',`أضف موعد | الاسم=رسالة اختبار | التكرار=مرة | التاريخ=${date} | الوقت=18:30 | إلى=أحمد الجديد | الرسالة=رسالة مجدولة`);
  assert.equal(r.ok,true); assert.equal(r.action,'create-schedule');
  s=store.loadSession('main'); assert.equal(s.automation.tasks.length,1); assert.equal(s.automation.tasks[0].text,'رسالة مجدولة'); assert.deepEqual(s.automation.tasks[0].targetKeys,['r:'+s.recipients[0].id]);
  r=await engine.run('main','اعرض المواعيد'); assert.ok(r.response.includes('رسالة اختبار'));
  const originalTaskId=store.loadSession('main').automation.tasks[0].id;
  r=await engine.run('main','عدّل الموعد رسالة اختبار | الوقت=19:15 | الرسالة=رسالة محدثة');
  assert.equal(r.ok,true); assert.equal(r.action,'edit-schedule'); s=store.loadSession('main');
  assert.equal(s.automation.tasks[0].id,originalTaskId,'editing a schedule must retain its stable ID');
  assert.equal(s.automation.tasks[0].time,'19:15'); assert.equal(s.automation.tasks[0].text,'رسالة محدثة');
  assert.deepEqual(s.automation.tasks[0].targetKeys,['r:'+s.recipients[0].id],'editing a schedule must preserve unspecified targets');
  r=await engine.run('main','تعديل الموعد | الموعد=رسالة اختبار | الاسم=موعد معدّل'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').automation.tasks[0].name,'موعد معدّل'); s=store.loadSession('main');
  r=await engine.run('main','اعرض المواعيد'); assert.ok(r.response.includes('موعد معدّل'));
  r=await engine.run('main','أوقف الموعد موعد معدّل'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').automation.tasks[0].enabled,false);
  r=await engine.run('main','فعّل الموعد موعد معدّل'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').automation.tasks[0].enabled,true);
  r=await engine.run('main',`نفّذ الموعد ${s.automation.tasks[0].name}`); assert.equal(r.ok,true); assert.equal(r.action,'run-schedule');

  r=await engine.run('main','أرسل الآن | إلى=أحمد الجديد | ملف=manual.pdf | الرسالة=هذه نسخة الاختبار');
  assert.equal(r.ok,true); assert.equal(r.action,'send-result'); assert.equal(sentCalls.length,1); assert.deepEqual(sentCalls[0].payload.targetKeys,['r:'+s.recipients[0].id]); assert.deepEqual(sentCalls[0].payload.mediaIds,['manual.pdf']); assert.equal(sentCalls[0].payload.text,'هذه نسخة الاختبار');
  r=await engine.run('main','اختبر الإرسال لنفسي | الرسالة=اختبار مسار الإرسال'); assert.equal(r.ok,true); assert.equal(r.action,'self-send-test'); assert.equal(selfSendCalls.length,1); assert.equal(selfSendCalls[0].chatId,'96891230000@c.us'); assert.ok(selfSendCalls[0].text.includes('اختبار مسار الإرسال'));
  r=await engine.run('main','احذف الملف manual.pdf'); assert.equal(r.ok,true); assert.equal(r.action,'delete-media'); assert.equal(delivery.files('main').length,0); assert.ok(!fs.existsSync(path.join(store.getPaths('main').media,'manual.pdf')),'file delete command must delete the actual file');

  r=await engine.run('main','أضف قاعدة تفاعل | الاسم=ترحيب | عندما=السلام عليكم | المطابقة=يحتوي | الرد=وعليكم السلام');
  assert.equal(r.ok,true); s=store.loadSession('main'); assert.equal(s.interaction.rules.length,1); assert.equal(s.interaction.rules[0].then.reply,'وعليكم السلام');
  r=await engine.run('main','عدّل قاعدة التفاعل ترحيب | الاسم=التحية الجديدة | عندما=أهلًا | المطابقة=دقيق | الرد=أهلًا {{sender}} | فاصل القاعدة=45'); assert.equal(r.ok,true); s=store.loadSession('main'); assert.equal(s.interaction.rules[0].name,'التحية الجديدة'); assert.equal(s.interaction.rules[0].when.value,'أهلًا'); assert.equal(s.interaction.rules[0].when.match,'exact'); assert.equal(s.interaction.rules[0].then.reply,'أهلًا {{sender}}'); assert.equal(s.interaction.rules[0].cooldownSec,45);
  r=await engine.run('main','فعّل اختبار التفاعل مع نفسي'); assert.equal(r.ok,true); s=store.loadSession('main'); assert.equal(s.settings.interactionIgnoreOwn,false); assert.equal(s.settings.interactionScope,'selected'); assert.ok(s.settings.interactionChatIds.includes('96891230000@c.us'));
  r=await engine.run('main','اضبط تأخير الإرسال | مللي ثانية=500'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').settings.sendDelayMs,500);
  r=await engine.run('main','اضبط المنطقة الزمنية | المنطقة=Europe/London'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').settings.timezone,'Europe/London');
  let badTimezone=''; try { await engine.run('main','اضبط المنطقة الزمنية | المنطقة=Not/A-Real-Timezone'); } catch (e) { badTimezone=e.message; } assert.ok(badTimezone.includes('غير معروفة')); assert.equal(store.loadSession('main').settings.timezone,'Europe/London','invalid timezone must not mutate settings');
  r=await engine.run('main','اضبط المنطقة الزمنية | المنطقة=Asia/Muscat'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').settings.timezone,'Asia/Muscat');
  r=await engine.run('main','فعّل مساعد المجموعات'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').settings.groupAssistantEnabled,true);
  r=await engine.run('main','اضبط النطاق | النطاق=خاص'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').settings.interactionScope,'private');
  r=await engine.run('main','اضبط فترة الهدوء | البداية=22:00 | النهاية=06:30 | السلوك=رد مخصص | نص الرد=سأتواصل لاحقًا. | تفعيل=نعم | فاصل الرد=600'); assert.equal(r.ok,true); s=store.loadSession('main');
  assert.equal(s.settings.interactionQuietStart,'22:00'); assert.equal(s.settings.interactionQuietEnd,'06:30'); assert.equal(s.settings.interactionQuietAction,'reply'); assert.equal(s.settings.interactionQuietReply,'سأتواصل لاحقًا.'); assert.equal(s.settings.interactionQuietEnabled,true); assert.equal(s.settings.interactionQuietCooldownSec,600);
  r=await engine.run('main','أوقف فترة الهدوء'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').settings.interactionQuietEnabled,false);
  r=await engine.run('main','اضبط حد التفاعل | العدد=35'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').settings.maxActionsPerMinute,35);
  r=await engine.run('main','أوقف استخدام أسماء المشروع'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').settings.interactionUseRecipientNames,false);
  r=await engine.run('main','فعّل استخدام أسماء المشروع'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').settings.interactionUseRecipientNames,true);
  r=await engine.run('main','غيّر كلمة تشغيل الأوامر إلى يا نجم، يا مساعد'); assert.equal(r.ok,true); assert.deepEqual(store.loadSession('main').settings.commandTriggerWords,['يا نجم','يا مساعد']);
  r=await engine.run('main','فعّل اشتراط كلمة تشغيل الأوامر'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').settings.commandTriggerRequired,true);
  r=await engine.run('main','يا نجم أوقف اشتراط كلمة تشغيل الأوامر'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').settings.commandTriggerRequired,false);
  r=await engine.run('main','اعرض إعدادات التفاعل'); assert.equal(r.ok,true); assert.ok(r.response.includes('النطاق: المحادثات الخاصة')&&r.response.includes('يا نجم، يا مساعد'));
  // Return scope to its baseline so the later conversation-specific commands remain isolated.
  r=await engine.run('main','اضبط النطاق | النطاق=كل المحادثات'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').settings.interactionScope,'all');
  s=store.loadSession('main'); s.ownerAssistant.issues=[{id:'issue-1',title:'خطأ اختبار',details:'تفصيل',code:'TEST',status:'open'}]; store.saveSession(s);
  r=await engine.run('main','اعرض المشاكل'); assert.ok(r.response.includes('خطأ اختبار')&&r.response.includes('issue-1'));
  r=await engine.run('main','حل المشكلة issue-1'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').ownerAssistant.issues[0].status,'resolved');
  r=await engine.run('main','أوقف إشعارات المساعد'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').ownerAssistant.notificationsEnabled,false);
  r=await engine.run('main','فعّل إشعارات المساعد'); assert.equal(r.ok,true); assert.equal(store.loadSession('main').ownerAssistant.notificationsEnabled,true);
  r=await engine.run('main','اعرض إعدادات الإرسال'); assert.ok(r.response.includes('500 ms'));
  s=store.loadSession('main'); s.recipients[0].localName='الاسم المحلي'; s.recipients[0].localAvatarFile='local-avatar.png'; store.saveSession(s);
  r=await engine.run('main','زامن ملف WhatsApp | إلى=أحمد الجديد'); assert.equal(r.ok,true); assert.equal(r.action,'recipient-profile-sync'); assert.ok(r.response.includes('تحدّثت')||r.response.includes('تغييرات ظاهرة: 2'));
  s=store.loadSession('main'); assert.equal(s.recipients[0].whatsappName,'اسم WhatsApp المحدث'); assert.equal(s.recipients[0].whatsappAvatarFile,'recipient-wa-avatar.jpg'); assert.equal(s.recipients[0].localName,'الاسم المحلي'); assert.equal(s.recipients[0].localAvatarFile,'local-avatar.png');
  r=await engine.run('main','زامن ملفات WhatsApp | إلى=الكل'); assert.equal(r.ok,true); assert.equal(r.action,'recipient-profile-sync'); assert.ok(r.response.includes('نجح: 1'));

  r=await engine.run('main','احذف المستلم أحمد الجديد'); assert.equal(r.ok,true); s=store.loadSession('main'); assert.equal(s.recipients.length,0); assert.equal(s.automation.tasks[0].targetKeys.length,0);

  // Simulate the exact messages the user writes in WhatsApp self-chat, across turns.
  r=await engine.run('main','عايز اضيف رقم مستخدم جديد'); assert.equal(r.action,'conversation-start'); assert.ok(r.response.includes('الخطوة 1/3')); assert.equal(store.loadSession('main').recipients.length,0);
  r=await engine.run('main','أحمد'); assert.equal(r.action,'conversation-name'); assert.ok(r.response.includes('الخطوة 2/3'));
  r=await engine.run('main','دولة خيالية'); assert.equal(r.action,'conversation-invalid-country'); assert.ok(r.response.includes('لم أتعرف')); assert.equal(store.loadSession('main').recipients.length,0,'invalid country must never save a recipient');
  r=await engine.run('main','عمان'); assert.equal(r.action,'conversation-country'); assert.ok(r.response.includes('الخطوة 3/3'));
  r=await engine.run('main','123'); assert.equal(r.action,'conversation-invalid-phone'); assert.ok(r.response.includes('غير صالح')); assert.equal(store.loadSession('main').recipients.length,0,'invalid phone must never save a recipient');
  r=await engine.run('main','+966501234567'); assert.equal(r.action,'conversation-country-mismatch'); assert.ok(r.response.includes('دولة مختلفة'));
  r=await engine.run('main','+96891234568'); assert.equal(r.ok,true); assert.equal(r.action,'conversation-add-recipient'); assert.ok(r.response.includes('اكتملت الخطوات 3/3'));
  s=store.loadSession('main'); assert.equal(s.recipients.length,1); assert.equal(s.recipients[0].name,'أحمد'); assert.equal(s.recipients[0].e164,'+96891234568'); assert.equal(s.ownerAssistant.conversation,null,'dialogue state must clear after verified completion');
  r=await engine.run('main','كيف أضيف رقم مستخدم جديد؟'); assert.equal(r.action,'faq-add-recipient'); assert.ok(r.response.includes('الاسم، ثم الدولة، ثم رقم الهاتف'));
  r=await engine.run('main','السلام عليكم'); assert.equal(r.action,'faq-greeting'); assert.ok(r.response.includes('أهلًا'));
  r=await engine.run('main','إلغاء'); assert.equal(r.action,'conversation-cancel'); assert.equal(store.loadSession('main').recipients.length,1,'cancel with no active wizard must not delete data');
  r=await engine.run('main','هذا كلام غير معروف'); assert.equal(r.handled,false); assert.equal(r.ok,undefined); assert.ok(r.response.includes('فهمت رسالتك') || r.response.includes('لم أنفّذ'));
  r=await engine.run('main','اعرض قواعد التفاعل'); assert.ok(r.response.includes('قواعد التفاعل'));
  r=await engine.run('main',`احذف قاعدة التفاعل ${store.loadSession('main').interaction.rules[0].name}`); assert.equal(r.ok,true); assert.equal(store.loadSession('main').interaction.rules.length,0);
  // Natural, multi-turn command flows: direct send, schedule creation, and interactive rule creation.
  const sendsBeforeWizard = sentCalls.length;
  r=await engine.run('main','أرسل رسالة'); assert.equal(r.action,'conversation-send-start'); assert.match(r.response,/المستلم/);
  r=await engine.run('main','أحمد'); assert.equal(r.action,'conversation-send-target'); assert.match(r.response,/نص الرسالة/);
  r=await engine.run('main','رسالة من المحادثة'); assert.equal(r.action,'conversation-send-result'); assert.equal(sentCalls.length,sendsBeforeWizard+1); assert.match(r.response,/اكتمل الإرسال/);

  const schedulesBeforeWizard = store.loadSession('main').automation.tasks.length;
  const wizardDate = new Date(Date.now()+8*86400000).toISOString().slice(0,10);
  r=await engine.run('main','أنشئ موعدًا'); assert.equal(r.action,'conversation-schedule-start','Arabic tanween form of موعد must start the schedule wizard');
  r=await engine.run('main','تذكير من المحادثة'); assert.equal(r.action,'conversation-schedule-name');
  r=await engine.run('main',wizardDate); assert.equal(r.action,'conversation-schedule-date');
  r=await engine.run('main','18:30'); assert.equal(r.action,'conversation-schedule-time');
  r=await engine.run('main','أحمد'); assert.equal(r.action,'conversation-schedule-target');
  r=await engine.run('main','رسالة الموعد من المحادثة'); assert.equal(r.action,'conversation-schedule-result'); assert.equal(store.loadSession('main').automation.tasks.length,schedulesBeforeWizard+1);

  r=await engine.run('main','أنشئ ردًا تلقائيًا'); assert.equal(r.action,'conversation-rule-start','Arabic tanween form of ردًا تلقائيًا must start the rule wizard');
  r=await engine.run('main','كلمة خاصة للاختبار'); assert.equal(r.action,'conversation-rule-trigger');
  r=await engine.run('main','أهلًا {{sender}}، وصلت: {{message}}'); assert.equal(r.action,'conversation-rule-result');
  s=store.loadSession('main'); assert.ok(s.interaction.rules.some(rule=>rule.when.value==='كلمة خاصة للاختبار' && rule.then.reply.includes('{{sender}}'))); assert.equal(s.settings.interactionEnabled,true);

  ready=false;
  let offlineError=''; try { await engine.run('main','اكتشف المجموعات'); } catch (e) { offlineError=e.message; }
  assert.ok(offlineError.includes('اربط WhatsApp'),'group discovery must explicitly require a live session');
  const extraId=store.listSessionIds().find(x=>x!=='main'); assert.ok(extraId);
  let deleteRequiredConfirm=false; try { await engine.run('main',`احذف الجلسة ${extraId}`); } catch(e) { deleteRequiredConfirm=e.message.includes('تأكيدًا صريحًا'); }
  assert.equal(deleteRequiredConfirm,true,'session deletion must require an explicit confirmation'); assert.ok(store.listSessionIds().includes(extraId),'unconfirmed deletion must not mutate session storage');
  r=await engine.run('main',`احذف الجلسة ${extraId} | تأكيد=نعم`); assert.equal(r.ok,true); assert.ok(!store.listSessionIds().includes(extraId)); assert.equal(store.activeSessionId(),'main','self-chat session deletion must not switch the active session');
  console.log('local-command-engine: ok (recipient CRUD, live number check, group analysis/details/activation, schedule CRUD/edit/run, real targeted send, self-send test, media deletion, interaction rules, assistant issues/settings, no false success)');
})().catch(error=>{ console.error(error);process.exitCode=1; });
