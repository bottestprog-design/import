'use strict';
const assert = require('node:assert/strict');
const { InteractionEngine, match, valid, ruleActiveNow, quiet } = require('../src/interaction');

function localParts(date, timeZone = 'Asia/Muscat') {
  const parts = new Intl.DateTimeFormat('en-US', { timeZone, weekday:'short', hour:'2-digit', minute:'2-digit', hourCycle:'h23' }).formatToParts(date);
  const get = type => parts.find(x => x.type === type)?.value || '';
  return { day:({Sun:0,Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6})[get('weekday')], minutes:Number(get('hour'))*60+Number(get('minute')) };
}
function hhmm(total) { total=(total+1440)%1440; return `${String(Math.floor(total/60)).padStart(2,'0')}:${String(total%60).padStart(2,'0')}`; }
function session({ settings = {}, rules = [] } = {}) {
  return {
    id:'interaction-test', name:'test',
    settings:{ timezone:'Asia/Muscat', interactionEnabled:true, interactionIgnoreOwn:true, interactionScope:'all', interactionChatIds:[], interactionQuietEnabled:false, interactionQuietStart:'23:00', interactionQuietEnd:'07:00', interactionQuietAction:'silence', interactionQuietReply:'أنا في الهدوء: {{message}}', interactionQuietCooldownSec:3600, interactionFallbackEnabled:true, interactionFallbackCooldownSec:300, interactionFallbackReply:'أهلًا {{sender}}، استلمت: {{message}}', maxActionsPerMinute:100, interactionCooldownCapSec:86400, ...settings },
    interaction:{ enabled:true, rules, recent:[] },
    stats:{ interactionActions:0, interactionErrors:0 },
  };
}
function rule({ id, name = id, match = 'contains', value = 'test', reply = 'رد تلقائي', priority = 1, cooldownSec = 0, schedule = { enabled:false }, stopAfter = true } = {}) {
  return { id, name, enabled:true, priority, cooldownSec, when:{type:'message',match,value,ignoreCase:true}, then:{reply,reaction:'',stopAfter}, scope:'all', chatIds:[], schedule };
}
function message({ id, body, chatId='96890000000@c.us', fromMe=false, selfInput=false, programmatic=false }) {
  return {
    fromMe, body, chatId, from:chatId, to:chatId, notifyName:'المستخدم', __chatBotSelfInput:selfInput, __chatBotProgrammatic:programmatic,
    id:{_serialized:id, remote:{_serialized:chatId}},
    getChat:async()=>({id:{_serialized:chatId},name:'محادثة الاختبار'}),
  };
}
function rig(s) {
  const sent=[];
  const store={loadSession:()=>s,saveSession:v=>Object.assign(s,v)};
  const whatsapp={
    sendText:async(id,chatId,text)=>{sent.push({kind:'sendText',id,chatId,text});return {__chatBotAck:{status:'created'}};},
    replyToMessage:async(id,msg,text)=>{sent.push({kind:'reply',id,chatId:msg.chatId||msg.id?.remote?._serialized,text});return {__chatBotAck:{status:'created'}};},
    reactToMessage:async()=>({}),
  };
  return { engine:new InteractionEngine({store,whatsapp,log:()=>{}}),sent,s };
}
(async()=>{
  // Matching modes must retain their intended semantics.
  assert.equal(match({when:{match:'contains',value:'سعر'}},'message','كم السعر؟'),true);
  assert.equal(match({when:{match:'exact',value:'مرحبا'}},'message','مرحبا بك'),false);
  assert.equal(match({when:{match:'exact',value:'مرحبا'}},'message','مرحبا'),true);
  assert.equal(match({when:{match:'starts',value:'أهلا'}},'message','أهلا بك'),true);
  assert.equal(match({when:{match:'ends',value:'تمام'}},'message','كله تمام'),true);
  assert.equal(match({when:{type:'reaction',match:'exact',value:'👍'}},'message','👍',''),false,'reaction rules must not run against ordinary messages');
  assert.equal(match({when:{type:'message',match:'exact',value:'مرحبا'}},'reaction','','مرحبا'),false,'message rules must not run against reactions');

  const friday = new Date('2026-10-16T09:00:00Z'); // 13:00 in Muscat on Friday.
  assert.equal(ruleActiveNow({schedule:{enabled:true,start:'12:00',end:'18:00',days:[5],timezone:'Asia/Muscat'}},'Asia/Muscat',friday),true);
  assert.equal(ruleActiveNow({schedule:{enabled:true,start:'12:00',end:'18:00',days:[4],timezone:'Asia/Muscat'}},'Asia/Muscat',friday),false);
  assert.equal(ruleActiveNow({schedule:{enabled:true,start:'22:00',end:'07:00',days:[4],timezone:'Asia/Muscat'}},'Asia/Muscat',new Date('2026-10-15T22:30:00Z')),true,'overnight windows attribute after-midnight hours to the previous start day');
  assert.equal(ruleActiveNow({schedule:{enabled:false}},'Asia/Muscat',friday),true);
  assert.throws(()=>valid(rule({id:'bad-time',schedule:{enabled:true,start:'25:00',end:'26:00',days:[5]}})),/وقت تشغيل القاعدة/);
  assert.throws(()=>valid(rule({id:'no-days',schedule:{enabled:true,start:'09:00',end:'17:00',days:[]}})),/اختر يومًا واحدًا/);

  // Manual self-chat input is normalized as user input and triggers the configured keyword rule once.
  const core = rig(session({rules:[rule({id:'price',value:'السعر',reply:'وصل سؤالك {{sender}}: {{message}}',match:'contains'})]}));
  const manual = message({id:'manual-self-1',body:'كم السعر؟',fromMe:false,selfInput:true});
  const handled = await core.engine.onMessage('interaction-test',manual);
  assert.equal(handled.handled,true); assert.equal(handled.ruleId,'price'); assert.equal(core.sent.length,1); assert.equal(core.sent[0].kind,'sendText','self-chat replies are sent to the self chat, not quoted against the original own message');
  assert.match(core.sent[0].text,/وصل سؤالك/);
  await core.engine.onMessage('interaction-test',manual);
  assert.equal(core.sent.length,1,'the same message event must not run twice');

  // The production self-chat path must accept a genuine Message object marked fromMe.
  const selfRig = rig(session({rules:[rule({id:'real-self',value:'ردني',reply:'رد المحادثة الذاتية'})]}));
  const rawOwnMessage = message({id:'raw-own-message-1',body:'ردني من فضلك',fromMe:true,chatId:'96890000000@c.us'});
  const rawSelfOutcome = await selfRig.engine.onSelfChatMessage('interaction-test', rawOwnMessage, '96890000000@c.us');
  assert.equal(rawSelfOutcome.handled,true,'self-chat handler should explicitly normalize an outgoing WhatsApp Message');
  assert.equal(selfRig.sent.length,1);
  assert.equal(selfRig.sent[0].kind,'sendText','an own message must be answered by sending directly to the self chat');
  assert.equal(selfRig.sent[0].chatId,'96890000000@c.us');
  let getChatCalls = 0;
  const noBrowserRoundTrip = message({ id:'no-getchat-roundtrip', body:'ردني', fromMe:true, chatId:'96890000000@c.us' });
  noBrowserRoundTrip.getChat = () => { getChatCalls++; return new Promise(() => {}); };
  const fastStart = Date.now();
  const fastOutcome = await selfRig.engine.onSelfChatMessage('interaction-test', noBrowserRoundTrip, '96890000000@c.us');
  assert.equal(fastOutcome.handled,true,'self-chat interaction should run with raw message identifiers even if getChat never resolves');
  assert.equal(getChatCalls,0,'raw chat identifiers must avoid a Chromium/browser round-trip');
  assert.ok(Date.now()-fastStart < 500,'self-chat auto reply should not wait on WhatsApp chat metadata');
  assert.equal(selfRig.sent.length,2,'a fresh own-message event should generate exactly one additional reply');

  // When a higher priority rule fails, a lower matching rule can still answer.
  const fallthrough = rig(session({rules:[rule({id:'bad',value:'سعر',priority:20,reply:'will fail'}),rule({id:'backup',value:'سعر',priority:10,reply:'backup reply'})]}));
  fallthrough.engine.whatsapp.replyToMessage=async(_id,_message,text)=>{if(text==='will fail')throw new Error('test send failure');fallthrough.sent.push({kind:'reply',text});return {};};
  const fallbackResult=await fallthrough.engine.onMessage('interaction-test',message({id:'fail-then-backup',body:'السعر',chatId:'someone@c.us'}));
  assert.equal(fallbackResult.ruleId,'backup'); assert.equal(fallthrough.sent.length,1); assert.equal(fallthrough.sent[0].text,'backup reply');

  // Quiet mode: silence, a single custom reply with cooldown, or continuing scheduled rules.
  const now = new Date(), parts=localParts(now), qStart=hhmm(parts.minutes-1), qEnd=hhmm(parts.minutes+1);
  const silence = rig(session({settings:{interactionQuietEnabled:true,interactionQuietStart:qStart,interactionQuietEnd:qEnd,interactionQuietAction:'silence'},rules:[rule({id:'never',match:'any',reply:'no'})]}));
  const quietSilenced=await silence.engine.onMessage('interaction-test',message({id:'quiet-silence',body:'hello',chatId:'quiet@c.us'}));
  assert.equal(quietSilenced.action,'silence'); assert.equal(silence.sent.length,0);

  const custom = rig(session({settings:{interactionQuietEnabled:true,interactionQuietStart:qStart,interactionQuietEnd:qEnd,interactionQuietAction:'reply',interactionQuietReply:'رد الهدوء: {{message}}',interactionQuietCooldownSec:3600}}));
  const first=await custom.engine.onMessage('interaction-test',message({id:'quiet-custom-1',body:'هل أنت هنا؟',chatId:'quiet@c.us'}));
  assert.equal(first.action,'reply'); assert.equal(custom.sent.length,1); assert.equal(custom.sent[0].text,'رد الهدوء: هل أنت هنا؟');
  const second=await custom.engine.onMessage('interaction-test',message({id:'quiet-custom-2',body:'رسالة ثانية',chatId:'quiet@c.us'}));
  assert.equal(second.action,'cooldown'); assert.equal(custom.sent.length,1,'quiet reply cooldown must prevent spam');

  const allowRules=rig(session({settings:{interactionQuietEnabled:true,interactionQuietStart:qStart,interactionQuietEnd:qEnd,interactionQuietAction:'rules'},rules:[rule({id:'quiet-rule',value:'help',reply:'help response'})]}));
  const quietRuleResult=await allowRules.engine.onMessage('interaction-test',message({id:'quiet-rules-1',body:'help me',chatId:'quiet-rules@c.us'}));
  assert.equal(quietRuleResult.ruleId,'quiet-rule'); assert.equal(allowRules.sent[0].text,'help response');

  // Per-rule schedule must skip inactive rules and continue to a rule without a schedule.
  const current = localParts(new Date());
  const alternateDay=(current.day+1)%7;
  const scheduled=rig(session({rules:[rule({id:'closed-window',priority:20,value:'سؤال',reply:'closed',schedule:{enabled:true,start:hhmm(current.minutes-1),end:hhmm(current.minutes+1),days:[alternateDay],timezone:'Asia/Muscat'}}),rule({id:'open-window',priority:10,value:'سؤال',reply:'open'})]}));
  const scheduleResult=await scheduled.engine.onMessage('interaction-test',message({id:'schedule-fallback',body:'سؤال',chatId:'scheduled@c.us'}));
  assert.equal(scheduleResult.ruleId,'open-window'); assert.equal(scheduled.sent[0].text,'open');

  // Default conversational replies cover messages with no explicit rule; cooldown prevents spamming.
  const general = rig(session({settings:{interactionFallbackReply:'أهلًا {{sender}}، استلمت رسالتك: {{message}}'}}));
  const unfamiliar = await general.engine.onMessage('interaction-test', message({id:'generic-1',body:'هل يمكن توضيح ذلك؟',chatId:'generic@c.us'}));
  assert.equal(unfamiliar.action,'fallback'); assert.equal(general.sent.length,1);
  assert.equal(general.sent[0].text,'أهلًا المستخدم، استلمت رسالتك: هل يمكن توضيح ذلك؟');
  const duplicateFallback = await general.engine.onMessage('interaction-test', message({id:'generic-2',body:'رسالة أخرى',chatId:'generic@c.us'}));
  assert.equal(duplicateFallback.action,'fallback-cooldown'); assert.equal(general.sent.length,1,'unknown-message fallback cooldown must avoid noisy repeated messages');
  const greeting = await general.engine.onMessage('interaction-test', message({id:'generic-greeting',body:'السلام عليكم',chatId:'greeting@c.us'}));
  assert.equal(greeting.action,'fallback'); assert.match(general.sent[1].text,/وعليكم السلام/,'common intents must get a natural reply rather than the generic template');
  const selfFallback = rig(session({settings:{interactionFallbackReply:'طلبك يا {{sender}}: {{message}}'}}));
  const selfFallbackResult = await selfFallback.engine.onSelfChatMessage('interaction-test', message({id:'self-generic-1',body:'اعطني شرحًا من فضلك',fromMe:true,chatId:'96890000001@c.us'}), '96890000001@c.us');
  assert.equal(selfFallbackResult.action,'fallback'); assert.equal(selfFallback.sent.length,1);
  assert.equal(selfFallback.sent[0].kind,'sendText','default fallback in self chat should send directly, not reply to the outgoing message');
  assert.equal(selfFallback.sent[0].chatId,'96890000001@c.us');
  assert.match(selfFallback.sent[0].text,/اعطني شرحًا/);
  const disabled = rig(session({settings:{interactionFallbackEnabled:false}}));
  const noFallback = await disabled.engine.onMessage('interaction-test',message({id:'fallback-off',body:'رسالة لا تطابق قاعدة',chatId:'off@c.us'}));
  assert.equal(noFallback.reason,'no-rule-matched'); assert.equal(disabled.sent.length,0,'user must be able to disable the default reply');

  console.log('self-chat-autoreply: ok (typed event matching, raw fromMe self-chat routing, duplicate guard, failed-rule fallback, quiet modes/cooldown, per-rule schedules)');
})().catch(error=>{console.error(error);process.exitCode=1;});
