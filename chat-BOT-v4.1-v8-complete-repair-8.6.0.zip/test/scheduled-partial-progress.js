'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { DeliveryService } = require('../src/delivery');
const { ReliableScheduler, parts } = require('../src/scheduler');

(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-scheduled-partial-'));
  const pdf = path.join(dir, 'notice.pdf');
  fs.writeFileSync(pdf, '%PDF-1.4\n% simulated fixture for routing test\n');
  const local = parts(new Date(), 'Asia/Muscat');
  const date = `${local.year}-${String(local.month).padStart(2,'0')}-${String(local.day).padStart(2,'0')}`;
  const time = `${String(local.hour).padStart(2,'0')}:${String(local.minute).padStart(2,'0')}`;
  let session = {
    id:'partial-scheduled-test',
    settings:{ timezone:'Asia/Muscat', maxImageSizeMB:20, retryAttempts:1, retryDelayMs:1, sendDelayMs:0, sendTimeoutMs:100, preText:'', postText:'', automationEnabled:true },
    recipients:[{id:'owner', name:'Test target', digits:'96890000000', enabled:true}], groups:[],
    stats:{sentMessages:0,sentImages:0,sentFiles:0,confirmedAcks:0,createdSends:0,uncertainSends:0,failedSends:0,successfulRuns:0,failedRuns:0},
    cycle:{round:1,imageOrder:[],currentIndex:0,delivery:{},manualGuard:{}}, scheduleState:{lastRunKey:''},
    automation:{enabled:true,tasks:[{id:'once-pdf',name:'PDF reminder',enabled:true,mode:'once',date,time,timezone:'Asia/Muscat',graceMinutes:30,lastRunKey:'',targetKeys:['r:owner'],mediaIds:['notice.pdf'],mediaMode:'selected',text:'Reminder before PDF',textMode:'before',captionMode:false,sendAsDocument:false,sendDelayMs:0,preText:'',postText:'',sendOrder:'target-first',scheduledGroupsEnabled:true}],recent:[]}
  };
  const store = {
    safeSessionId:id=>id,
    getPaths:()=>({images:dir}),
    listSessionIds:()=>[session.id],
    loadSession:()=>structuredClone(session),
    saveSession:value=>{ session=structuredClone(value); return session; }
  };
  let textCalls=0, mediaCalls=0;
  const whatsapp = {
    ensureReady:async()=>({ready:true}),
    resolveChatId:async(_id,target)=>`chat:${target.targetId}`,
    sendText:async()=>{textCalls++;return {__chatBotAck:{status:'confirmed'}};},
    sendMedia:async()=>{mediaCalls++;throw new Error('simulated PDF transport rejection after text delivered');}
  };
  const delivery = new DeliveryService({store,whatsapp,log:()=>{}});
  const scheduler = new ReliableScheduler({store,run:async()=>({ok:true}),runTask:(id,task)=>delivery.scheduledTaskRun(id,task),log:()=>{}});
  scheduler.stop();
  try {
    await scheduler.tickSession(session.id);
    assert.equal(textCalls,1,'the main text should have been sent exactly once before the simulated PDF failure');
    assert.equal(mediaCalls,1,'the PDF delivery should be attempted once');
    assert.equal(session.automation.tasks[0].enabled,false,'a once task with a completed prior stage must be consumed, not automatically replayed');
    assert.ok(session.automation.tasks[0].lastRunKey,'partially executed occurrence should be recorded');
    assert.equal(session.automation.tasks[0].lastResult.partial,true,'the history should identify partial delivery');
    assert.ok(session.automation.tasks[0].lastResult.failed[0].partialDelivery,'the failed item should include stage progress');
    await scheduler.tickSession(session.id);
    assert.equal(textCalls,1,'next tick must not duplicate the text already sent');
    assert.equal(mediaCalls,1,'next tick must not silently resend the failed attachment');
    console.log('scheduled-partial-progress: ok (text delivered + attachment failed, history marks partial and no duplicate retry)');
  } finally {
    scheduler.stop();
    fs.rmSync(dir,{recursive:true,force:true});
  }
})().catch(error=>{ console.error(error); process.exitCode=1; });
