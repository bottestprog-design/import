'use strict';
const assert = require('node:assert/strict');
const { DeliveryService } = require('../src/delivery');
const { normalizeAutomationTask } = require('../src/store');

const persisted = normalizeAutomationTask({
  id:'saved-task', name:'Daily announcement', mode:'weekly', time:'09:15', day:1,
  targetKeys:['r:person1','g:group1'], mediaIds:['report.pdf'], mediaMode:'selected',
  text:'Important announcement', textMode:'after', captionMode:false, sendAsDocument:true,
  sendDelayMs:1250, preText:'Before the attachment', postText:'After the attachment', sendOrder:'image-first',
  scheduledGroupsEnabled:true, graceMinutes:60
});
assert.equal(persisted.text,'Important announcement');
assert.equal(persisted.textMode,'after');
assert.equal(persisted.sendAsDocument,true);
assert.equal(persisted.sendDelayMs,1250);
assert.equal(persisted.graceMinutes,60);

const session = {
  id:'schedule-delivery-test', settings:{ timezone:'Asia/Muscat', sendDelayMs:700, preText:'GLOBAL PRE', postText:'GLOBAL POST', sendTimeoutMs:30000 },
  recipients:[{id:'person1',name:'Person',enabled:true}], groups:[{id:'group1',gid:'123@g.us',name:'Group',enabled:true}],
  stats:{ sentMessages:0,sentImages:0,sentFiles:0,confirmedAcks:0,createdSends:0,uncertainSends:0,failedSends:0 },
  cycle:{round:1,imageOrder:[],currentIndex:0,delivery:{},manualGuard:{}}, automation:{tasks:[]}
};
const store = { safeSessionId:id=>id, loadSession:()=>session, saveSession:()=>session };
const whatsapp = { ensureReady:async()=>({ready:true}) };
const service = new DeliveryService({store,whatsapp,log:()=>{}});
let captured;
service.sendNow = async (id, options) => { captured={id, ...options}; return {ok:true,sent:[{target:'Person',status:'confirmed'}],failed:[],images:[],captions:0}; };
service.files=()=>[{id:'report.pdf',filename:'report.pdf',isImage:false,size:400},{id:'img.1.png',filename:'img.1.png',isImage:true,size:200}];
(async()=>{
 const outcome=await service.scheduledTaskRun(session.id,persisted);
 assert.equal(outcome.ok,true);
 assert.equal(captured.id,session.id);
 assert.deepEqual(captured.targetKeys,['r:person1','g:group1']);
 assert.deepEqual(captured.mediaIds,['report.pdf']);
 assert.equal(captured.text,'Important announcement');
 assert.equal(captured.textMode,'after');
 assert.equal(captured.captionMode,false);
 assert.equal(captured.sendAsDocument,true);
 assert.equal(captured.sendDelayMs,1250);
 assert.equal(captured.preText,'Before the attachment');
 assert.equal(captured.postText,'After the attachment');
 assert.equal(captured.sendOrder,'image-first');
 // A saved caption must not disappear when the selected item is a PDF or a document.
 service.files=()=>[{id:'report.pdf',filename:'report.pdf',isImage:false,size:400}];
 await service.scheduledTaskRun(session.id,{...persisted,mediaMode:'selected',mediaIds:['report.pdf'],text:'PDF message',textMode:'caption',captionMode:true,sendAsDocument:false});
 assert.equal(captured.textMode,'before','caption placement must fall back to a message for PDF/document attachments');
 // The legacy caption toggle must also force a separate message even if a task was saved as auto.
 service.files=()=>[{id:'img.1.png',filename:'img.1.png',isImage:true,size:200}];
 await service.scheduledTaskRun(session.id,{...persisted,mediaMode:'selected',mediaIds:['img.1.png'],text:'image message',textMode:'auto',captionMode:false,sendAsDocument:false});
 assert.equal(captured.textMode,'before','disabled caption option must keep text in a separate message');
 const cycle={...persisted,mediaIds:['report.pdf'],mediaMode:'cycle',text:'cycle text'};
 service.currentImage=()=>({id:'img.1.png',filename:'img.1.png',isImage:true});
 service.images=()=>[{id:'img.1.png',filename:'img.1.png',isImage:true}];
 await service.scheduledTaskRun(session.id,cycle);
 assert.deepEqual(captured.mediaIds,['img.1.png'],'cycle mode should choose the current image, not reuse selected-media IDs');
 console.log('scheduled-delivery: ok (saved content, target/media snapshot, placement, document flag, delay and cycle mode)');
})().catch(error=>{console.error(error);process.exitCode=1;});
