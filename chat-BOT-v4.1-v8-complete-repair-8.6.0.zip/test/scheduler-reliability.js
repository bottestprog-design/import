'use strict';
const assert = require('node:assert/strict');
const { ReliableScheduler, parts, dueForItem, nextRunForItem, zonedDateToUtc } = require('../src/scheduler');

const timezone = 'Asia/Muscat';
const now = new Date();
const local = parts(now, timezone);
const localDate = `${local.year}-${String(local.month).padStart(2,'0')}-${String(local.day).padStart(2,'0')}`;
const occurrence = zonedDateToUtc(localDate, `${String(local.hour).padStart(2,'0')}:${String(local.minute).padStart(2,'0')}`, timezone);
assert.ok(occurrence, 'timezone conversion should return a scheduled instant');

const once = { id:'once-test', enabled:true, mode:'once', date:localDate, time:`${String(local.hour).padStart(2,'0')}:${String(local.minute).padStart(2,'0')}`, timezone, graceMinutes:30, lastRunKey:'' };
assert.equal(dueForItem(new Date(occurrence.getTime() + 20 * 60000), once).due, true, 'a task should be caught up within its saved grace period');
assert.equal(dueForItem(new Date(occurrence.getTime() + 31 * 60000), once).due, false, 'a task should not be unexpectedly sent after its grace period');
assert.equal(nextRunForItem(once, new Date(occurrence.getTime() + 20 * 60000)), occurrence.toISOString(), 'the UI should show the pending catch-up occurrence');
assert.equal(dueForItem(new Date(occurrence.getTime() + 20 * 60000), { ...once, graceMinutes:5 }).due, false, 'a custom shorter grace period must be honored');

(async () => {
  let session = {
    id:'scheduler-test',
    settings:{ timezone, automationEnabled:true },
    automation:{ enabled:true, tasks:[{ ...once, id:'partial-once', name:'Partially delivered task', time:`${String(local.hour).padStart(2,'0')}:${String(local.minute).padStart(2,'0')}`, date:localDate, graceMinutes:30, targetKeys:['r:one','r:two'], mediaIds:[], text:'hello', textMode:'before', enabled:true, lastRunKey:'' }], recent:[] },
    groups:[], recipients:[], scheduleState:{lastRunKey:''}
  };
  const saved = [];
  const store = {
    listSessionIds:()=>[session.id],
    loadSession:()=>structuredClone(session),
    saveSession:value=>{session=structuredClone(value); saved.push(session); return session;}
  };
  let calls = 0;
  const scheduler = new ReliableScheduler({
    store,
    run:async()=>({ok:true,complete:true}),
    runTask:async(_id, task)=>{ calls++; assert.ok(task._scheduledOccurrenceKey, 'scheduler passes stable occurrence identity'); return {ok:false,complete:false,sent:[{target:'one',status:'confirmed'}],failed:[{target:'two',error:'test failure'}]}; },
    log:()=>{}
  });
  scheduler.stop();
  await scheduler.tickSession(session.id);
  assert.equal(calls,1);
  assert.equal(scheduler.status().lastAttempt.taskId,'partial-once','scheduler health must expose which task was attempted');
  assert.equal(scheduler.status().lastResult.ok,false,'scheduler health must expose the actual failed/partial result');
  assert.equal(session.automation.tasks[0].enabled,false,'a one-time partial send must not retry already-successful targets automatically');
  assert.ok(session.automation.tasks[0].lastRunKey,'the scheduled occurrence must be consumed after any sent operation');
  assert.equal(session.automation.tasks[0].lastResult.partial,true);
  assert.equal(session.automation.recent.at(-1).partial,true);
  await scheduler.tickSession(session.id);
  assert.equal(calls,1,'the same one-time schedule must not duplicate successful messages on the next tick');

  const legacySession = {
    id:'legacy-scheduler-test',
    settings:{ timezone, scheduleEnabled:true, scheduleMode:'once', scheduleDate:localDate, scheduleTime:`${String(local.hour).padStart(2,'0')}:${String(local.minute).padStart(2,'0')}`, scheduleGraceMinutes:30, automationEnabled:false },
    scheduleState:{ lastRunKey:'' }, automation:{ enabled:false, tasks:[], recent:[] }, groups:[], recipients:[]
  };
  let legacyRuns = 0, legacySaves = 0;
  const legacyStore = {
    listSessionIds:()=>[legacySession.id],
    loadSession:()=>structuredClone(legacySession),
    saveSession:value=>{ Object.assign(legacySession,structuredClone(value)); legacySaves++; return legacySession; }
  };
  const legacyScheduler = new ReliableScheduler({
    store:legacyStore, run:async()=>{legacyRuns++;return {ok:false,sent:[{target:'one'}],failed:[{target:'two',error:'test fail'}]};},
    runTask:async()=>{throw new Error('automation should be disabled in legacy test');}, log:()=>{}
  });
  legacyScheduler.stop();
  await legacyScheduler.tickSession(legacySession.id);
  assert.equal(legacyRuns,1);
  assert.ok(legacySession.scheduleState.lastRunKey,'legacy recurring scheduler must consume a partially delivered occurrence');
  await legacyScheduler.tickSession(legacySession.id);
  assert.equal(legacyRuns,1,'legacy schedule must not resend the already delivered target on the next tick');
  assert.ok(legacySaves>0);
  await legacyScheduler.tick();
  assert.ok(legacyScheduler.status().tickCount > 0, 'scheduler monitor should expose that periodic checks are running');
  assert.ok(legacyScheduler.status().lastSuccessfulTickAt, 'successful monitor ticks should have a timestamp');
  console.log('scheduler-reliability: ok (timezone, grace, catch-up, partial task + legacy scheduling without duplicate)');
})().catch(error=>{ console.error(error); process.exitCode=1; });
