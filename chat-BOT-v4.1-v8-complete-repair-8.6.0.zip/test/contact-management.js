'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const store = require('../src/store');
let session;
try {
  session = store.createSessionInactive('Contact profile unit test');
  session.recipients = [{
    id: 'recipient-a1b2c3', name: 'اسم واتساب', phone: '96890000000', digits: '96890000000', e164: '+96890000000', international: '+96890000000', enabled: true,
    whatsappName: 'اسم WhatsApp الأصلي', whatsappAvatarUrl: 'https://pps.whatsapp.net/v/t61/profile.jpg?token=example',
    localName: 'اسم مخصص داخل المشروع', localAvatarFile: 'recipient-a1b2c3.png', waChatId: '96890000000@c.us', profileCheckedAt: '2026-10-16T00:00:00.000Z', profileError: ''
  }];
  store.saveSession(session);
  let saved = store.loadSession(session.id).recipients[0];
  assert.equal(saved.whatsappName, 'اسم WhatsApp الأصلي', 'WhatsApp name must persist independently');
  assert.equal(saved.localName, 'اسم مخصص داخل المشروع', 'project-local name override must persist independently');
  assert.equal(saved.localAvatarFile, 'recipient-a1b2c3.png', 'only a valid local avatar filename should persist');
  assert.equal(saved.waChatId, '96890000000@c.us');
  assert.equal(saved.profileError, '');
  assert.equal(saved.whatsappAvatarUrl, 'https://pps.whatsapp.net/v/t61/profile.jpg?token=example');
  session.recipients[0].whatsappAvatarUrl = 'javascript:alert(1)';
  session.recipients[0].localAvatarFile = '../../danger.svg';
  session.recipients[0].profileError = 'x'.repeat(800);
  store.saveSession(session);
  saved = store.loadSession(session.id).recipients[0];
  assert.equal(saved.whatsappAvatarUrl, '', 'non-HTTPS and non-WhatsApp avatar URLs must be rejected');
  assert.equal(saved.localAvatarFile, '', 'path traversal must never survive recipient avatar normalization');
  assert.equal(saved.localName, 'اسم مخصص داخل المشروع', 'bad profile metadata must not remove local name overrides');
  assert.equal(saved.profileError.length, 600, 'profile error text must be bounded');
  console.log('contact-management: ok (WhatsApp/local names, avatar URL allow-list, safe local file names, profile error persistence)');
} finally {
  if (session?.id) { try { fs.rmSync(store.getPaths(session.id).dir, { recursive:true, force:true }); } catch {} }
}
