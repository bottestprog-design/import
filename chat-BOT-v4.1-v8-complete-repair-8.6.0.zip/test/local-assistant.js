'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '..', 'public', 'local-assistant.js'), 'utf8');
const backing = new Map();
const storage = {
  getItem(key) { return backing.has(key) ? JSON.stringify(backing.get(key)) : null; },
  setItem(key, value) { backing.set(key, JSON.parse(value)); },
  removeItem(key) { backing.delete(key); },
};
const context = vm.createContext({ window: {}, localStorage: storage, Date, Math, Intl, JSON, String, Set, Map, Object, Array, Error, Number, RegExp });
new vm.Script(source, { filename: 'public/local-assistant.js' }).runInContext(context);
const engine = context.window.LocalAssistantEngine;
assert.ok(engine, 'Browser local assistant engine must register');
assert.ok(engine.BUILTIN_COMMANDS.length >= 25, 'Starter command library should be useful at first run');
assert.ok(engine.MAX_COMMANDS >= 1000, 'Large local command capacity must be explicit');
assert.equal(engine.normalize('  إفتح   الإِرسال! '), 'افتح الارسال');
assert.equal(engine.classify('افتح الإرسال').type, 'command');
assert.equal(engine.classify('افتح الإرسال').command.page, 'send');
assert.equal(engine.classify('حالة الاتصال').command?.action, 'status');
assert.deepEqual(JSON.parse(JSON.stringify(engine.classify('جهّز رسالة: مرحبًا يا جماعة'))), { type: 'draft', text: 'مرحبًا يا جماعة' });
assert.deepEqual(JSON.parse(JSON.stringify(engine.classify('ابحث عن المجموعة'))), { type: 'search', query: 'المجموعة' });
assert.equal(engine.classify('افتح شيء غير موجود').type, 'unknown');
const custom = engine.validateCustomCommand({ name: 'رسالة الدوام', triggers: 'دوام | رسالة الدوام', action: 'draft', response: 'يبدأ الدوام الساعة الثامنة.', page: 'send' });
assert.equal(custom.name, 'رسالة الدوام');
assert.ok(custom.triggers.includes('دوام'));
assert.equal(engine.findCommand('من فضلك نفذ رسالة الدوام الآن', [custom]).id, custom.id, 'Custom commands should be prioritized when trigger is present');
assert.throws(() => engine.validateCustomCommand({ name:'Unsafe', triggers:'unsafe', action:'javascript', response:'alert(1)' }), /غير مدعوم/);
assert.throws(() => engine.validateCustomCommand({ name:'Blank', triggers:'blank', action:'reply', response:'' }), /أدخل النص/);
const many = Array.from({ length: 90 }, (_, i) => engine.validateCustomCommand({ id:`cmd-${i}`, name:`أمر ${i}`, triggers:`تشغيل أمر ${i}`, action:'navigate', page:'dashboard' }));
engine.saveCommands(many);
assert.equal(engine.loadCommands().length, 90, 'Saved commands must persist locally');
const history = Array.from({ length: 280 }, (_, i) => ({ role: i % 2 ? 'assistant' : 'user', text:`message ${i}`, at: i + 1 }));
engine.saveMessages(history);
assert.equal(engine.loadMessages().length, engine.MAX_MESSAGES, 'Local chat history must remain bounded');
assert.equal(engine.loadMessages()[0].text, 'message 30', 'The oldest messages should be trimmed first');
const noExternalCalls = !/\bfetch\s*\(|XMLHttpRequest|WebSocket|\beval\s*\(|new\s+Function\s*\(/.test(source);
assert.ok(noExternalCalls, 'Local command engine must not call network providers or execute dynamic code');
console.log(`local assistant: ok (${engine.BUILTIN_COMMANDS.length} built-in commands, 90-command persistence, routing, draft parsing, import-safe validation, local history)`);
