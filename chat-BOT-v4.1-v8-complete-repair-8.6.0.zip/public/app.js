(() => {
  'use strict';

  const state = {
    data: null,
    countries: null,
    page: location.hash.slice(1) || 'dashboard',
    bgEngine: null,
    selectedGroup: null,
    selectedGroupIds: new Set(),
    selectedRecipientIds: new Set(),
    groupStatusFilter: 'all',
    groupMemberFilter: '',
    groupMemberLimit: 100,
    selectedMedia: null,
    pendingTargets: [],
    peopleFilter: '',
    whatsappContacts: null,
    whatsappContactFilter: '',
    whatsappProfileHydrating: false,
    whatsappProfileHydrationSession: '',
    whatsappProfileHydrationProgress: { done: 0, total: 0, failed: 0 },
    contactSyncPreview: null,
    contactSyncAutoScannedSession: '',
    profileRefreshIds: new Set(),
    groupFilter: '',
    settingsView: 'appearance',
    editingTaskId: null,
    scheduleOpen: false,
    loadPromise: null,
    loadController: null,
    bgLivePending: 0,
    uiMode: (() => { try { return localStorage.getItem('chatbot-ui-mode') === 'light' ? 'light' : 'dark'; } catch { return 'dark'; } })(),
    assistantCommands: (() => { try { return window.LocalAssistantEngine?.loadCommands?.() || []; } catch { return []; } })(),
    assistantMessages: (() => { try { return window.LocalAssistantEngine?.loadMessages?.() || []; } catch { return []; } })(),
    assistantBusy: false,
    assistantDraft: '',
    assistantLibraryFilter: '',
    companionNotice: null,
    activityPosting: new Set(),
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  function robotSvgMarkup(className = 'robot-svg') {
    return `<svg class="${className}" viewBox="0 0 96 104" role="img" aria-label="روبوت مساعد chat BOT" focusable="false">
      <ellipse cx="48" cy="96" rx="29" ry="5" fill="#06101e" opacity=".24"/>
      <path d="M29 70 Q21 73 20 84 L20 91 Q20 95 25 95 H71 Q76 95 76 91 L76 84 Q75 73 67 70Z" fill="#172b46" stroke="#70e8de" stroke-width="2"/>
      <path d="M36 71 L34 86 Q48 92 62 86 L60 71Z" fill="#26496c"/>
      <path d="M48 8 V17" stroke="#7ff6df" stroke-width="3.5" stroke-linecap="round"/>
      <circle cx="48" cy="6" r="5" fill="#72f6dc" stroke="#d7fff7" stroke-width="1.5"/>
      <path d="M22 30 Q22 20 33 20 H63 Q74 20 74 30 V57 Q74 68 63 68 H33 Q22 68 22 57Z" fill="#14243b" stroke="#78e8e0" stroke-width="2.4"/>
      <path d="M28 31 Q28 25 36 25 H60 Q68 25 68 31 V53 Q68 60 60 60 H36 Q28 60 28 53Z" fill="#1d3955" stroke="#375e7d" stroke-width="1.2"/>
      <path d="M30 30 Q34 26 41 26 H57" stroke="#c8fff4" stroke-width="2" opacity=".38" fill="none" stroke-linecap="round"/>
      <rect x="34" y="36" width="10" height="12" rx="4" fill="#68f4dc"/><rect x="52" y="36" width="10" height="12" rx="4" fill="#68f4dc"/>
      <circle cx="37" cy="39" r="2" fill="#effffb"/><circle cx="55" cy="39" r="2" fill="#effffb"/>
      <path d="M40 54 Q48 60 56 54" stroke="#b4fff0" stroke-width="2.8" fill="none" stroke-linecap="round"/>
      <path d="M18 39 Q12 44 18 50" stroke="#84eddf" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M78 39 Q84 44 78 50" stroke="#84eddf" stroke-width="3" fill="none" stroke-linecap="round"/>
      <path d="M33 80 L40 76 H56 L63 80 L60 91 H36Z" fill="#32718a" stroke="#83f4dc" stroke-width="1.3"/>
      <circle cx="48" cy="83" r="4" fill="#8c8aff" stroke="#d7d0ff" stroke-width="1.2"/>
      <path d="M26 76 L21 82 M70 76 L75 82" stroke="#a3fff0" stroke-width="4" stroke-linecap="round"/>
    </svg>`;
  }
  const sid = () => $('#sessionSelect')?.value || state.data?.session?.id || '';

  function activeTargets(data) {
    return [
      ...(data.recipients || []).map((x) => ({ ...x, key: `r:${x.id}`, type: 'recipient' })),
      ...(data.groups || []).map((x) => ({ ...x, key: `g:${x.id}`, type: 'group' })),
    ];
  }

  function chatIdForTarget(target) {
    if (!target) return '';
    if (target.type === 'group') return String(target.gid || '').toLowerCase();
    const digits = String(target.digits || target.phone || '').replace(/\D/g, '');
    return digits ? `${digits}@c.us` : String(target.chatId || '').toLowerCase();
  }

  function typeLabel(target) {
    return target?.type === 'group' ? 'مجموعة' : 'شخص';
  }

  async function api(url, options = {}) {
    const isForm = options.body instanceof FormData;
    const requestUrl = new URL(url, location.origin);
    const isApi = requestUrl.pathname.startsWith('/api/');
    const currentSessionId = sid();
    let requestBody = options.body;
    const method = String(options.method || 'GET').toUpperCase();
    if (isApi && currentSessionId) {
      if (!requestUrl.searchParams.has('sessionId')) requestUrl.searchParams.set('sessionId', currentSessionId);
      if (isForm) {
        if (!requestBody.has('sessionId')) requestBody.append('sessionId', currentSessionId);
      } else if (requestBody !== undefined && requestBody !== null && method !== 'GET' && method !== 'HEAD') {
        try {
          const parsed = typeof requestBody === 'string' ? JSON.parse(requestBody || '{}') : requestBody;
          if (parsed && typeof parsed === 'object' && !Array.isArray(parsed) && !parsed.sessionId) requestBody = JSON.stringify({ ...parsed, sessionId: currentSessionId });
        } catch { /* Leave non-JSON bodies untouched; the server still validates their session scope. */ }
      } else if (requestBody == null && method !== 'GET' && method !== 'HEAD') {
        requestBody = JSON.stringify({ sessionId: currentSessionId });
      }
    }
    const headers = { ...(isForm ? {} : { 'Content-Type': 'application/json' }), ...(options.headers || {}) };
    const response = await fetch(requestUrl.pathname + requestUrl.search, { ...options, body: requestBody, headers });
    const raw = await response.text();
    let body = {};
    try { body = raw ? JSON.parse(raw) : {}; } catch { body = { raw }; }
    if (!response.ok || body.ok === false) throw new Error(body.error || body.raw || `HTTP ${response.status}`);
    return body;
  }

  function activityType(type) {
    if (type === 'success') return 'success';
    if (type === 'error' || type === 'danger') return 'error';
    if (type === 'warning') return 'warning';
    return 'info';
  }

  function renderActivityItems(items) {
    const list = $('#ownerActivityList');
    if (!list) return;
    const count = $('.owner-activity-count'); if (count) count.textContent = String((items || []).length);
    const entries = [...(items || [])].reverse().slice(0, 35);
    list.innerHTML = entries.length ? entries.map(item => {
      const kind = activityType(item.type);
      const symbol = kind === 'success' ? '✓' : kind === 'error' ? '!' : kind === 'warning' ? '⚠' : 'i';
      return `<article class="owner-activity-row activity-${kind}"><span class="owner-activity-symbol" aria-hidden="true">${symbol}</span><div class="owner-activity-copy"><div class="owner-activity-meta"><b>${kind === 'success' ? 'نجاح' : kind === 'error' ? 'فشل' : kind === 'warning' ? 'تنبيه' : 'إشعار'}</b><time>${esc(new Date(item.lastSeenAt || item.at || Date.now()).toLocaleString('ar-OM'))}${Number(item.count) > 1 ? ` · ${Number(item.count)} مرات` : ''}</time></div><p>${esc(item.message || '')}</p><div class="owner-activity-actions"><button class="btn small" data-activity-open="1" data-activity-page="${esc(item.page || 'dashboard')}" data-activity-issue="${esc(item.issueId || '')}">${item.issueId ? 'فتح المشكلة' : 'فتح القسم'} ↗</button></div></div></article>`;
    }).join('') : '<div class="empty">ستُحفظ هنا كل رسائل النجاح والفشل التي يعرضها الروبوت. هذا السجل منفصل عن الشات.</div>';
  }

  function clearCompanionNotice(restoreFocus = false) {
    state.companionNotice = null;
    const bubble = $('#assistantSpeech'); if (bubble) bubble.hidden = true;
    const toast = $('#toast'); if (toast) toast.hidden = true;
    clearTimeout(notify.timer);
    if (restoreFocus) $('#assistantRobotButton')?.focus({ preventScroll: true });
  }

  function logAssistantActivity(message, type, page) {
    const sessionId = sid();
    if (!sessionId) return;
    const key = `${sessionId}|${type}|${page}|${message}`;
    if (state.activityPosting.has(key)) return;
    state.activityPosting.add(key);
    const pendingId = `pending-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    const localEntry = { id: pendingId, message: String(message).slice(0, 1200), type, page, at: new Date().toISOString(), lastSeenAt: new Date().toISOString(), count: 1, source: 'ui-pending' };
    if (state.data) {
      const support = state.data.ownerAssistant || (state.data.ownerAssistant = {});
      const activities = Array.isArray(support.activity) ? support.activity : (support.activity = []);
      activities.push(localEntry); support.activity = activities.slice(-150); renderActivityItems(support.activity);
    }
    api('/api/assistant/activity', { method: 'POST', body: JSON.stringify({ sessionId, message: String(message).slice(0, 1200), type, page, source: 'ui-notification' }) })
      .then(result => {
        if (!state.data) return;
        const support = state.data.ownerAssistant || (state.data.ownerAssistant = {});
        let activities = Array.isArray(support.activity) ? support.activity : [];
        activities = activities.filter(item => item.id !== pendingId);
        if (result.activity) {
          const index = activities.findIndex(item => item.id === result.activity.id);
          if (index >= 0) activities[index] = result.activity; else activities.push(result.activity);
        }
        support.activity = activities.slice(-150);
        renderActivityItems(support.activity);
      })
      .catch(() => {
        localEntry.id = `local-${Date.now()}-${Math.random().toString(16).slice(2)}`;
        localEntry.source = 'local-fallback';
        try {
          const fallbackKey = `chatbot-activity-fallback:${sessionId}`;
          const saved = JSON.parse(localStorage.getItem(fallbackKey) || '[]');
          saved.push(localEntry); localStorage.setItem(fallbackKey, JSON.stringify(saved.slice(-100)));
        } catch { /* Local storage may be disabled; keep this entry visible for the current page session. */ }
        if (state.data?.ownerAssistant?.activity) {
          state.data.ownerAssistant.activity = state.data.ownerAssistant.activity.map(item => item.id === pendingId ? localEntry : item);
          renderActivityItems(state.data.ownerAssistant.activity);
        }
      })
      .finally(() => state.activityPosting.delete(key));
  }

  function notify(message, type = 'info', options = {}) {
    const text = String(message ?? '').trim();
    if (!text) return;
    const kind = activityType(type);
    const page = options.page || state.page || 'dashboard';
    const duration = Math.max(10000, Math.min(15000, Number(options.duration) || (kind === 'error' || kind === 'warning' ? 15000 : 12000)));
    state.companionNotice = { message: text, type: kind, page, issueId: options.issueId || null, at: Date.now(), expiresAt: Date.now() + duration };
    const toast = $('#toast');
    if (toast) { toast.className = `toast ${kind} sr-only`; toast.textContent = text; toast.hidden = false; }
    const bubble = $('#assistantSpeech');
    const bubbleText = $('#assistantSpeechText');
    if (bubble) { bubble.className = `assistant-speech activity-${kind}`; bubble.hidden = false; bubble.setAttribute('aria-label', kind === 'error' ? 'رسالة خطأ من المساعد' : kind === 'success' ? 'رسالة نجاح من المساعد' : 'إشعار من المساعد'); }
    if (bubbleText) bubbleText.textContent = text;
    const robot = $('#assistantRobotButton');
    if (robot) { robot.dataset.mood = kind; robot.classList.remove('robot-talk'); void robot.offsetWidth; robot.classList.add('robot-talk'); }
    clearTimeout(notify.timer);
    notify.timer = setTimeout(() => {
      if (state.companionNotice && state.companionNotice.expiresAt <= Date.now()) clearCompanionNotice();
    }, duration);
    logAssistantActivity(text, kind, page);
  }

  async function replayLocalActivityFallback(sessionId) {
    if (!sessionId) return;
    const fallbackKey = `chatbot-activity-fallback:${sessionId}`;
    let entries;
    try { entries = JSON.parse(localStorage.getItem(fallbackKey) || '[]'); } catch { return; }
    if (!Array.isArray(entries) || !entries.length) return;
    const remaining = [];
    for (const item of entries.slice(-100)) {
      try {
        await api('/api/assistant/activity', { method: 'POST', body: JSON.stringify({ sessionId, message: String(item.message || '').slice(0, 1200), type: activityType(item.type), page: item.page || 'dashboard', source: 'local-fallback-replay' }) });
      } catch { remaining.push(item); }
    }
    try { if (remaining.length) localStorage.setItem(fallbackKey, JSON.stringify(remaining)); else localStorage.removeItem(fallbackKey); } catch { /* best effort */ }
  }

  async function load(force = false) {
    if (state.loadPromise && !force) return state.loadPromise;
    if (state.loadController) state.loadController.abort();
    const controller = new AbortController(); state.loadController = controller;
    const current = sid();
    const query = current ? `?sessionId=${encodeURIComponent(current)}${force ? '&fresh=1' : ''}` : '';
    const promise = (async () => {
      try {
        const loaded = await api(`/api/state${query}`, { signal: controller.signal });
        if (!controller.signal.aborted) {
          const fallbackKey = `chatbot-activity-fallback:${current || loaded.session?.id || 'main'}`;
          try {
            const fallback = JSON.parse(localStorage.getItem(fallbackKey) || '[]');
            if (fallback.length) {
              loaded.ownerAssistant = loaded.ownerAssistant || {};
              const activity = Array.isArray(loaded.ownerAssistant.activity) ? loaded.ownerAssistant.activity : [];
              const known = new Set(activity.map(item => item.id));
              for (const item of fallback) if (!known.has(item.id)) { activity.push(item); known.add(item.id); }
              loaded.ownerAssistant.activity = activity.slice(-150);
            }
          } catch { /* Ignore corrupt or unavailable browser-local fallback data. */ }
          state.data = loaded; render();
          replayLocalActivityFallback(current || loaded.session?.id || 'main').catch(() => {});
        }
      } finally { if (state.loadController === controller) state.loadController = null; }
    })();
    state.loadPromise = promise;
    try { await promise; return state.data; }
    finally { if (state.loadPromise === promise) state.loadPromise = null; }
  }

  async function loadCountries() {
    if (!state.countries) state.countries = await api('/api/countries');
    return state.countries;
  }

  function countryOptions(selected = 'OM') {
    return (state.countries?.countries || []).map((country) => `<option value="${esc(country.code)}" ${country.code === selected ? 'selected' : ''}>+${esc(country.callingCode)} · ${esc(country.code)}</option>`).join('');
  }

  function nav() {
    const groups = [
      { title: 'مساحة العمل', items: [['dashboard', '⌂', 'الرئيسية'], ['send', '➜', 'الإرسال'], ['owner-center', '◉', 'مركز المساعد'], ['assistant', '✧', 'المساعد المحلي']] },
      { title: 'جهات الإرسال', items: [['people', '●', 'الأشخاص'], ['groups', '◆', 'المجموعات']] },
      { title: 'التحكم', items: [['interaction', '✦', 'التفاعل'], ['session', '◉', 'الجلسة'], ['settings', '⚙', 'الإعدادات']] },
    ];
    return groups.map((group) => `<div class="nav-group"><span class="nav-group-label">${group.title}</span>${group.items.map(([id, icon, label]) => `<button class="navbtn ${state.page === id ? 'active' : ''}" data-page="${id}" aria-current="${state.page === id ? 'page' : 'false'}"><span class="nav-icon" aria-hidden="true">${icon}</span><span>${label}</span>${state.page === id ? '<span class="nav-active-mark" aria-hidden="true"></span>' : ''}</button>`).join('')}</div>`).join('');
  }

  function shell(content) {
    const data = state.data || { session: {}, sessions: [], whatsapp: {} };
    const ready = !!data.whatsapp?.ready;
    const connectionText = ready ? 'متصل' : (data.whatsapp?.status === 'qr' ? 'بانتظار QR' : 'غير متصل');
    return `<div class="app-shell">
      <header class="topbar">
        <div class="brand">
          <span class="brand-mark" aria-hidden="true">${robotSvgMarkup('brand-robot-svg')}</span>
          <div><strong>chat BOT</strong><small>مركز إدارة الرسائل</small></div>
        </div>
        <div class="top-actions">
          <label class="session-picker"><span>الجلسة الحالية</span><select id="sessionSelect" aria-label="اختر الجلسة">${(data.sessions || []).map((session) => `<option value="${esc(session.id)}" ${session.id === data.session.id ? 'selected' : ''}>${esc(session.name || session.id)}</option>`).join('')}</select></label>
          <span class="status-pill ${ready ? 'ready' : ''}" title="حالة اتصال WhatsApp"><span class="status-dot"></span><span>${connectionText}</span></span>
          <button class="mode-btn" id="modeToggleBtn" type="button" aria-label="${state.uiMode === 'dark' ? 'التبديل إلى الوضع الفاتح' : 'التبديل إلى الوضع الداكن'}"><span class="mode-icon" aria-hidden="true">${state.uiMode === 'dark' ? '☼' : '☾'}</span><span>${state.uiMode === 'dark' ? 'الوضع الفاتح' : 'الوضع الداكن'}</span></button>
          <button class="icon-btn" id="refreshBtn" title="تحديث البيانات" aria-label="تحديث البيانات">↻</button>
        </div>
      </header>
      <div class="workspace-layout">
        <aside class="sidebar" aria-label="التنقل الرئيسي">
          <div class="sidebar-heading"><span>القائمة الرئيسية</span><small>تنقّل واضح وسريع</small></div>
          <nav class="navrow">${nav()}</nav>
          <div class="sidebar-foot"><span class="sidebar-foot-icon" aria-hidden="true">✓</span><div><b>إدارة محلية</b><small>البيانات محفوظة على جهازك</small></div></div>
        </aside>
        <main class="main" id="mainContent" tabindex="-1">${content}</main>
      </div>
      <div class="assistant-companion" id="assistantCompanion" aria-label="مساعد chat BOT">
        <section id="assistantSpeech" class="assistant-speech ${state.companionNotice ? `activity-${esc(state.companionNotice.type)}` : ''}" ${!state.companionNotice || state.companionNotice.expiresAt <= Date.now() ? 'hidden' : ''} role="status" aria-live="polite">
          <div class="assistant-speech-top"><span class="assistant-speech-origin">${robotSvgMarkup('speech-mini-robot')}<span>مساعد chat BOT</span></span><button id="assistantSpeechClose" class="assistant-speech-close" type="button" aria-label="إغلاق الرسالة" title="إغلاق الرسالة">×</button></div>
          <p id="assistantSpeechText">${esc(state.companionNotice?.message || '')}</p>
          <button id="assistantSpeechOpen" class="assistant-speech-link" type="button">${state.companionNotice?.type === 'error' || state.companionNotice?.type === 'warning' ? 'عرض التفاصيل والحل' : 'فتح سجل المساعد'} ↗</button>
          <span class="assistant-speech-tail" aria-hidden="true"></span>
        </section>
        <button id="assistantRobotButton" class="assistant-robot-button" type="button" aria-label="افتح مركز مساعد chat BOT" title="افتح مركز المساعد" data-mood="${esc(state.companionNotice?.type || 'neutral')}">${robotSvgMarkup('assistant-robot-svg')}<span class="assistant-robot-status" aria-hidden="true"></span></button>
        <div class="assistant-robot-caption" aria-hidden="true">مساعدك</div>
      </div>
      <div id="toast" class="toast sr-only" hidden role="status" aria-live="polite"></div>
    </div>`;
  }

  function pageDashboard(data) {
    const targets = activeTargets(data);
    const stats = data.stats || {};
    const logs = (data.logs || []).slice(0, 12);
    const runtime = data.whatsapp || {};
    return `<section class="hero-card">
      <div><p class="eyebrow">لوحة الجلسة الحالية</p><h1>${esc(data.session?.name || 'الجلسة الرئيسية')}</h1><p>كل شيء واضح من هنا: الإرسال، الأشخاص، المجموعات، التفاعل والسجل.</p></div>
      <div class="hero-actions"><button class="btn primary" data-go="send">إرسال الآن</button><button class="btn" data-go="interaction">التفاعل</button></div>
    </section>
    <section class="stats-grid">
      <article class="stat-card"><span>الحالة</span><b>${runtime.ready ? 'جاهز' : 'غير متصل'}</b><small>${runtime.info?.wid?.user ? '+' + esc(runtime.info.wid.user) : 'اربط الحساب من الجلسة'}</small></article>
      <article class="stat-card"><span>الأشخاص</span><b>${(data.recipients || []).length}</b><small>هذه الجلسة</small></article>
      <article class="stat-card"><span>المجموعات</span><b>${(data.groups || []).length}</b><small>هذه الجلسة</small></article>
      <article class="stat-card"><span>الإرسال</span><b>${Number(stats.sentMessages || 0) + Number(stats.sentImages || 0) + Number(stats.sentFiles || 0)}</b><small>عمليات تم تسجيلها</small></article>
    </section>
    <section class="content-grid two-col">
      <article class="panel"><div class="panel-head"><div><h2>الوصول السريع</h2><p>اختصر الطريق إلى المهمة التي تريدها.</p></div></div>
        <div class="quick-list">
          <button class="quick-item" data-go="send"><span class="quick-icon">➜</span><span><b>رسالة جديدة</b><small>حدد الأهداف والملفات ثم أرسل.</small></span></button>
          <button class="quick-item" data-go="owner-center"><span class="quick-icon">◉</span><span><b>مركز المساعد والتنبيهات</b><small>تشخيص المشكلات، خطوات الحل، والتنبيه إلى محادثة نفسك.</small></span></button>
          <button class="quick-item" data-go="assistant"><span class="quick-icon">✧</span><span><b>المساعد المحلي</b><small>نفّذ أوامرك واحفظ اختصاراتك بدون API خارجي.</small></span></button>
          <button class="quick-item" data-go="people"><span class="quick-icon">＋</span><span><b>إضافة أشخاص</b><small>أرقام دولية وقوائم متعددة.</small></span></button>
          <button class="quick-item" data-go="groups"><span class="quick-icon">◆</span><span><b>المجموعات</b><small>اكتشاف، ربط، تحليل وحفظ.</small></span></button>
          <button class="quick-item" data-go="settings"><span class="quick-icon">⚙</span><span><b>الإعدادات</b><small>المظهر والخلفيات والتشغيل.</small></span></button>
        </div>
      </article>
      <article class="panel"><div class="panel-head"><div><h2>آخر نشاط</h2><p>السجل محفوظ لهذه الجلسة فقط.</p></div><button class="btn small" id="dashboardRefresh">تحديث</button></div>
        <div class="log-list">${logs.length ? logs.map(logRow).join('') : '<div class="empty">لا يوجد نشاط بعد.</div>'}</div>
      </article>
    </section>`;
  }

  function logRow(log) {
    const at = log.at || log.time || log.timestamp || '';
    const date = at ? new Date(at) : null;
    const when = date && !Number.isNaN(date.getTime()) ? date.toLocaleString('ar-OM') : '';
    const level = String(log.level || 'INFO').toLowerCase();
    return `<div class="log-row"><span class="log-time">${esc(when)}</span><span class="log-level ${esc(level)}">${esc(log.level || 'INFO')}</span><span class="log-message">${esc(log.message || '')}</span></div>`;
  }

  function targetList(data, selected = state.pendingTargets) {
    const useAll = !Array.isArray(selected);
    const chosen = new Set(useAll ? [] : selected.map(String));
    const targets = activeTargets(data);
    return targets.length ? targets.map((target) => `<label class="target-row">
      <input type="checkbox" class="target" value="${esc(target.key)}" ${target.enabled === false ? 'disabled' : ''} ${target.enabled !== false && (useAll || chosen.has(target.key)) ? 'checked' : ''}>
      <span class="target-mark ${target.type}">${target.type === 'group' ? '◆' : '●'}</span>
      <span class="target-main"><b>${esc(target.name || target.phone || target.gid || 'بدون اسم')}</b><small>${typeLabel(target)}${target.type === 'group' ? ` · ${esc(target.gid || '')}` : ` · ${esc(target.international || target.e164 || '')}`}</small></span>
      <span class="target-state ${target.enabled === false ? 'off' : ''}">${target.enabled === false ? 'متوقف' : 'جاهز'}</span>
    </label>`).join('') : '<div class="empty">لا توجد أهداف. أضف شخصًا أو اربط مجموعة أولًا.</div>';
  }

  function activityMarkup(items = []) {
    const entries = [...items].reverse().slice(0, 35);
    if (!entries.length) return '<div class="empty">ستُحفظ هنا كل رسائل النجاح والفشل التي يعرضها الروبوت. هذا السجل منفصل عن الشات.</div>';
    return entries.map(item => {
      const kind = activityType(item.type);
      const symbol = kind === 'success' ? '✓' : kind === 'error' ? '!' : kind === 'warning' ? '⚠' : 'i';
      return `<article class="owner-activity-row activity-${kind}"><span class="owner-activity-symbol" aria-hidden="true">${symbol}</span><div class="owner-activity-copy"><div class="owner-activity-meta"><b>${kind === 'success' ? 'نجاح' : kind === 'error' ? 'فشل' : kind === 'warning' ? 'تنبيه' : 'إشعار'}</b><time>${esc(new Date(item.lastSeenAt || item.at || Date.now()).toLocaleString('ar-OM'))}${Number(item.count) > 1 ? ` · ${Number(item.count)} مرات` : ''}</time></div><p>${esc(item.message || '')}</p><div class="owner-activity-actions"><button class="btn small" data-activity-open="1" data-activity-page="${esc(item.page || 'dashboard')}" data-activity-issue="${esc(item.issueId || '')}">${item.issueId ? 'فتح المشكلة' : 'فتح القسم'} ↗</button></div></div></article>`;
    }).join('');
  }

  function pageOwnerCenter(data) {
    const support = data.ownerAssistant || { messages: [], issues: [], notificationsEnabled: true, notificationMode: 'self' };
    const messages = (support.messages || []).slice(-100);
    const issues = [...(support.issues || [])].reverse();
    const activities = support.activity || [];
    const diagnostics = data.whatsapp || {};
    const messagesHtml = messages.length ? messages.map(m => `<article class="owner-chat-message ${m.role === 'user' ? 'from-user' : 'from-assistant'}"><div class="owner-chat-meta"><b>${m.role === 'user' ? 'أنت' : 'مركز المساعد'}</b><time>${esc(new Date(m.at || Date.now()).toLocaleString('ar-OM'))}</time></div><div class="owner-chat-text">${esc(m.text || '').replace(/\n/g, '<br>')}</div>${m.issueId ? `<button class="btn small" data-owner-open-issue="${esc(m.issueId)}">فتح المشكلة المرتبطة</button>` : ''}</article>`).join('') : '<div class="empty">ستظهر رسالة الترحيب والتنبيهات هنا بعد ربط WhatsApp، ويمكنك تشغيل التشخيص الآن.</div>';
    const issuesHtml = issues.length ? issues.map(issue => `<article class="owner-issue ${issue.severity === 'error' ? 'is-error' : 'is-warning'}"><div class="owner-issue-top"><span class="owner-issue-state ${issue.status === 'resolved' ? 'resolved' : ''}">${issue.status === 'resolved' ? 'محلولة' : (issue.severity === 'error' ? 'تحتاج إصلاحًا' : 'تنبيه')}</span><time>${esc(new Date(issue.lastSeenAt || issue.createdAt || Date.now()).toLocaleString('ar-OM'))}${Number(issue.count) > 1 ? ` · تكرر ${issue.count} مرة` : ''}</time></div><h3>${esc(issue.title)}</h3><p>${esc(issue.details)}</p><div class="owner-issue-place">القسم: <b>${esc(issue.page || 'dashboard')}</b> · المسار: <code>${esc(issue.route || '—')}</code></div><details class="owner-issue-steps" open><summary>خطوات الحل</summary><ol>${(issue.steps || []).map(step => `<li>${esc(step)}</li>`).join('')}</ol></details><div class="owner-issue-actions"><button class="btn primary small" data-owner-open-issue="${esc(issue.id)}" data-owner-page="${esc(issue.page || 'dashboard')}">فتح القسم المرتبط ↗</button>${issue.status !== 'resolved' ? `<button class="btn small" data-owner-resolve-issue="${esc(issue.id)}">تعليم كمحلولة</button>` : ''}${issue.notificationError ? `<small class="owner-notify-error">لم يصل تنبيه WhatsApp: ${esc(issue.notificationError)}</small>` : issue.notifiedAt ? '<small class="owner-notify-ok">أُرسل تنبيه WhatsApp</small>' : ''}</div></article>`).join('') : '<div class="empty">لا توجد مشكلات مسجلة لهذه الجلسة. اضغط «تشخيص الآن» للفحص.</div>';
    const phoneMode = support.notificationMode === 'phone';
    return `<section class="page-title owner-center-title"><p class="eyebrow">مركز خاص بكل جلسة · تشخيص محلي</p><h1>مركز المساعد والتنبيهات</h1><p>مساحة دعم دائمة تحفظ رسالة الترحيب، أخطاء الإرسال والاتصال، وخطوات حل واضحة مع زر ينقلك للقسم المرتبط.</p></section>
      <section class="owner-center-summary"><article class="owner-summary-card"><span class="owner-summary-icon">◉</span><div><b>${esc(data.session?.name || 'الجلسة الحالية')}</b><small>بيانات المركز منفصلة عن بقية الجلسات</small></div></article><article class="owner-summary-card"><span class="owner-summary-icon ${diagnostics.ready ? 'ok' : 'warn'}">${diagnostics.ready ? '✓' : '!'}</span><div><b>${diagnostics.ready ? 'WhatsApp متصل' : `اتصال WhatsApp: ${esc(diagnostics.status || 'غير متصل')}`}</b><small>${(support.issues || []).filter(i => i.status !== 'resolved').length} مشكلة مفتوحة · ${(support.pendingNotifications || []).length} تنبيه معلّق</small></div></article><article class="owner-summary-card"><span class="owner-summary-icon">↗</span><div><b>${support.notificationsEnabled ? 'تنبيهات WhatsApp مفعّلة' : 'التنبيهات الخارجية متوقفة'}</b><small>${phoneMode ? `رقم المالك: ${esc(support.ownerPhone || 'غير مسجل')}` : 'الإشعار إلى محادثة «الرسائل إلى نفسك»'}</small></div></article></section>
      <section class="owner-center-layout"><div class="owner-center-main"><article class="panel owner-chat-panel"><div class="panel-head"><div><h2>الشات الخاص مع المساعد</h2><p>نسخة محلية محفوظة داخل هذه الجلسة. عند ربط WhatsApp يحاول إرسال الترحيب والتنبيهات إلى محادثة نفسك.</p></div><button class="btn small" id="ownerRefresh">تحديث</button></div><div id="ownerChatMessages" class="owner-chat-messages" role="log" aria-live="polite">${messagesHtml}</div><form id="ownerChatForm" class="owner-chat-composer"><label class="sr-only" for="ownerChatInput">اكتب سؤالًا لمركز المساعد</label><textarea id="ownerChatInput" rows="2" maxlength="1000" placeholder="اكتب: افحص، حالة الاتصال، مشكلة الإرسال، أو الجلسات…"></textarea><button class="btn primary" id="ownerChatSend" type="submit">إرسال</button></form><p class="owner-chat-note">يعمل دون API خارجي. التشخيصات مبنية على بيانات التطبيق والأخطاء المسجلة؛ ليست وعودًا عامة أو ردودًا مولدة من نموذج.</p></article>
      <article class="panel owner-issues-panel"><div class="panel-head"><div><h2>المشكلات والحلول</h2><p>كل بطاقة تعرض التفاصيل وخطوات الحل والقسم الذي يجب فتحه.</p></div><button class="btn primary" id="ownerDiagnose">تشخيص الآن</button></div><div class="owner-issue-list">${issuesHtml}</div></article></div>
      <aside class="owner-center-side"><article class="panel"><div class="panel-head"><div><h2>إعداد التنبيهات</h2><p>اختر وجهة الإشعار لهذه الجلسة.</p></div></div><form id="ownerConfigForm"><label class="owner-toggle"><input type="checkbox" id="ownerNotificationsEnabled" ${support.notificationsEnabled !== false ? 'checked' : ''}><span>إرسال تنبيهات WhatsApp</span></label><label>وجهة الإشعار<select id="ownerNotificationMode"><option value="self" ${!phoneMode ? 'selected' : ''}>محادثة الرسائل إلى نفسك</option><option value="phone" ${phoneMode ? 'selected' : ''}>رقم المالك المسجّل</option></select></label><label>رقم المالك الدولي<input id="ownerPhone" value="${esc(support.ownerPhone || '')}" placeholder="+968…" inputmode="tel" autocomplete="tel"></label><label class="owner-toggle"><input type="checkbox" id="ownerPhoneConfirmed" ${support.ownerPhoneConfirmed ? 'checked' : ''}><span>أؤكد أن الرقم ملكي أو لدي إذن باستقبال التنبيهات عليه</span></label><p class="owner-chat-note">لن يرسل التطبيق إلى رقم خارجي إلا عند اختياره وتأكيده صراحة. إشعارات محادثة نفسك تستخدم حساب WhatsApp المرتبط بهذه الجلسة.</p><div class="owner-config-actions"><button class="btn primary" id="ownerSaveConfig" type="submit">حفظ الإعدادات</button><button class="btn" id="ownerTestNotification" type="button">اختبار الإشعار</button></div><div id="ownerConfigStatus" class="owner-status" aria-live="polite"></div></form></article>
      <article class="panel owner-activity-panel"><div class="panel-head"><div><h2>سجل رسائل الروبوت</h2><p>نجاح وفشل وتنبيهات محفوظة مستقلًا عن الشات، ضمن الجلسة الحالية.</p></div><span class="owner-activity-count">${activities.length}</span></div><div class="owner-activity-list" id="ownerActivityList">${activityMarkup(activities)}</div><div class="owner-activity-footer"><button class="btn small" id="ownerActivityRefresh">تحديث السجل</button><span>آخر 150 رسالة محفوظة</span></div></article>
      <article class="panel"><div class="panel-head"><div><h2>فحص سريع</h2><p>ملخص لحالة المكونات المهمة.</p></div></div><div class="owner-diagnostic-mini">${(data.ownerAssistant?.issues || []).filter(i => i.status === 'open').slice(-4).map(i => `<button class="owner-mini-issue" data-owner-open-issue="${esc(i.id)}" data-owner-page="${esc(i.page || 'dashboard')}"><span>⚠</span><span><b>${esc(i.title)}</b><small>${esc(i.details)}</small></span></button>`).join('') || '<div class="empty">لا توجد مشكلات مفتوحة.</div>'}</div></article></aside></section>`;
  }

  function pageAssistant(data) {
    const recent = state.assistantMessages.slice(-80);
    const starters = [
      ['حالة الاتصال', 'اعرض حالة الاتصال'], ['افتح الإرسال', 'افتح الإرسال'], ['افتح الأشخاص', 'افتح الأشخاص'],
      ['الوضع الفاتح', 'فعّل الوضع الفاتح'], ['تحديث البيانات', 'حدّث البيانات'], ['جهّز رسالة', 'جهّز رسالة: اكتب نص رسالتك هنا']
    ];
    const messageMarkup = recent.length ? recent.map((message) => `<article class="assistant-message ${message.role === 'user' ? 'from-user' : 'from-assistant'}"><div class="assistant-message-avatar" aria-hidden="true">${message.role === 'user' ? 'أنت' : '✧'}</div><div class="assistant-message-content"><div class="assistant-message-meta"><b>${message.role === 'user' ? 'أنت' : 'المساعد المحلي'}</b><time>${new Date(message.at || Date.now()).toLocaleTimeString('ar-OM', { hour:'2-digit', minute:'2-digit' })}</time></div><div class="assistant-message-text">${esc(message.text).replace(/\n/g, '<br>')}</div></div></article>`).join('') : '<div class="assistant-welcome"><div class="assistant-orb" aria-hidden="true">✧</div><p class="eyebrow">مساعد يعمل محليًا</p><h2>أهلًا، جاهز لتنفيذ أوامرك</h2><p>أقدر أفتح صفحات المشروع، أراجع حالة الجلسة، أغيّر المظهر، أجهّز مسودة رسالة، وأشغّل الأوامر التي تحفظها بنفسك.</p><div class="assistant-local-notice"><span aria-hidden="true">●</span> لا يوجد اتصال بمزود ذكاء اصطناعي. الأوامر والحفظ يعملان داخل المتصفح، والعمليات تستعمل خدمات مشروعك المحلية عند الحاجة.</div></div>';
    const savedCount = state.assistantCommands.length;
    return `<section class="page-title assistant-page-title"><p class="eyebrow">مساحة أوامر شخصية · بلا API خارجي</p><h1>المساعد المحلي</h1><p>محادثة داخل التطبيق، مع مكتبة أوامر تحفظها وتستخدمها مرارًا. لا ينفّذ كودًا حرًا ولا يرسل رسالة WhatsApp دون المرور بصفحة الإرسال.</p></section>
      <section class="assistant-workspace">
        <article class="panel assistant-chat-panel">
          <div class="panel-head assistant-chat-head"><div class="assistant-heading"><span class="assistant-orb mini" aria-hidden="true">✧</span><div><h2>شات الأوامر</h2><p>يستجيب للأوامر المحفوظة وللأوامر المحلية المعروفة.</p></div></div><div class="assistant-toolbar"><button class="btn small" id="assistantCopyLast" type="button">نسخ آخر رد</button><button class="btn small" id="assistantExportChat" type="button">تصدير المحادثة</button><button class="btn small danger" id="assistantClearChat" type="button">مسح الشات</button></div></div>
          <div id="assistantMessages" class="assistant-messages" role="log" aria-live="polite" aria-relevant="additions text">${messageMarkup}</div>
          <div class="assistant-suggestions" aria-label="أوامر مقترحة">${starters.map(([label, text]) => `<button type="button" class="assistant-suggestion" data-assistant-suggestion="${esc(text)}">${esc(label)}</button>`).join('')}</div>
          <form id="assistantChatForm" class="assistant-composer"><label class="sr-only" for="assistantChatInput">اكتب أمرك للمساعد المحلي</label><textarea id="assistantChatInput" rows="2" maxlength="4000" placeholder="اكتب أمرًا مثل: افتح الإرسال أو حالة الاتصال…" autocomplete="off"></textarea><div class="assistant-composer-bottom"><span>Enter للإرسال · Shift+Enter لسطر جديد</span><button type="submit" class="btn primary" id="assistantSubmit">إرسال الأمر <span aria-hidden="true">↵</span></button></div></form>
        </article>
        <aside class="assistant-library panel" id="assistantLibraryPanel">
          <div class="panel-head"><div><h2>مكتبة الأوامر</h2><p>أساسي ومخصص — محفوظ على هذا المتصفح.</p></div><span class="assistant-count" id="assistantCommandCount">${savedCount + window.LocalAssistantEngine.BUILTIN_COMMANDS.length}</span></div>
          <div class="assistant-library-actions"><button class="btn primary" id="assistantNewCommand" type="button">＋ أمر محفوظ</button><button class="btn" id="assistantTeachLast" type="button">حفظ آخر رسالة كأمر</button><button class="btn" id="assistantExportCommands" type="button">تصدير</button><button class="btn" id="assistantImportCommands" type="button">استيراد</button><input id="assistantImportFile" type="file" accept="application/json,.json" hidden></div>
          <label class="assistant-search-label" for="assistantCommandSearch">ابحث في الأوامر</label><input class="input" id="assistantCommandSearch" value="${esc(state.assistantLibraryFilter)}" placeholder="اسم الأمر أو كلمة تشغيل…" autocomplete="off">
          <div class="assistant-library-legend"><span><i class="dot built-in"></i> أوامر أساسية</span><span><i class="dot custom"></i> أوامرك الخاصة</span></div>
          <div id="assistantCommandList" class="assistant-command-list"></div>
          <details id="assistantCommandEditor" class="assistant-command-editor"><summary><span id="assistantEditorSummary">إضافة أمر محفوظ جديد</span></summary><form id="assistantCommandForm"><input id="assistantCommandId" type="hidden"><div class="form-grid"><label>اسم الأمر<input id="assistantCommandName" maxlength="90" required placeholder="مثال: تجهيز رسالة المدرسة"></label><label>عبارات تشغيل الأمر<input id="assistantCommandTriggers" maxlength="1000" required placeholder="رسالة المدرسة | اعلان المدرسة"><small>افصل بين العبارات بعلامة |</small></label><label>ماذا ينفذ الأمر؟<select id="assistantCommandAction"><option value="navigate">فتح صفحة</option><option value="reply">إظهار رد محفوظ</option><option value="draft">تجهيز مسودة رسالة</option><option value="status">عرض حالة الجلسة</option><option value="refresh">تحديث بيانات المشروع</option><option value="theme">تغيير المظهر</option></select></label><label id="assistantCommandPageWrap">الصفحة المستهدفة<select id="assistantCommandPage"><option value="dashboard">الرئيسية</option><option value="send">الإرسال</option><option value="people">الأشخاص</option><option value="groups">المجموعات</option><option value="interaction">التفاعل</option><option value="session">الجلسة</option><option value="settings">الإعدادات</option><option value="appearance">المظهر</option><option value="operation">التشغيل المتقدم</option><option value="assistant">المساعد المحلي</option></select></label><label id="assistantCommandThemeWrap">المظهر<select id="assistantCommandTheme"><option value="toggle">تبديل الحالي</option><option value="light">فاتح</option><option value="dark">داكن</option></select></label><label id="assistantCommandResponseWrap">النص المحفوظ<textarea id="assistantCommandResponse" rows="4" maxlength="4000" placeholder="اكتب الرد أو نص الرسالة الذي سيستخدمه الأمر"></textarea><small id="assistantCommandResponseHelp">للردود المحفوظة أو مسودات الرسائل.</small></label><label class="full-field">وصف اختياري<input id="assistantCommandDescription" maxlength="300" placeholder="متى تستخدم هذا الأمر؟"></label></div><div class="assistant-editor-actions"><button class="btn primary" type="submit" id="assistantSaveCommand">حفظ الأمر</button><button class="btn" type="button" id="assistantCancelEdit">إلغاء</button></div><p class="assistant-editor-note">الأوامر بيانات آمنة من أنواع محددة؛ لا يمكنها تشغيل JavaScript أو تنفيذ أوامر نظام عشوائية.</p></form></details>
        </aside>
      </section>`;
  }

  function pageSend(data) {
    const media = data.media || [];
    const tasks = data.automation?.tasks || [];
    const selectedTargets = state.pendingTargets;
    const groupsCount = (data.groups || []).length;
    return `<section class="page-title"><p class="eyebrow">إرسال</p><h1>أرسل بسهولة</h1><p>حدد الأهداف، اكتب الرسالة، ارفع الملفات، ثم نفّذ الآن أو احفظ موعدًا مستقلًا.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>من سيرسل إليه؟</h2><p>كل الاختيارات تخص الجلسة الحالية.</p></div><div class="panel-actions"><button class="btn small" id="selectAllTargets">الكل</button><button class="btn small" id="clearTargets">مسح</button></div></div>
          <div class="target-summary"><b>${selectedTargets === null ? 'الكل' : selectedTargets.length}</b><span>${selectedTargets === null ? 'كل الأهداف' : 'أهداف محددة'}</span><span>· ${groupsCount} مجموعة محفوظة</span></div>
          <div class="target-list">${targetList(data, selectedTargets)}</div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الرسالة والملفات</h2><p>ارفع مرة واحدة واختر ما يدخل في الإرسال.</p></div></div>
          <label>نص الرسالة<textarea id="sendText" rows="5" placeholder="اكتب نص الرسالة أو تعليق الصورة…">${esc(state.assistantDraft || '')}</textarea></label>
          <div class="form-grid two"><label>رسالة قبل الملفات<input id="sendPreText" placeholder="اختياري — ترسل كرسالة مستقلة"></label><label>رسالة بعد الملفات<input id="sendPostText" placeholder="اختياري — ترسل بعد آخر ملف"></label></div>
          <div class="send-quick-options"><label class="toggle-box"><input id="captionMode" type="checkbox" checked><span>السماح بإرفاق النص كتعليق عندما تكون الملفات صورًا</span></label><label class="toggle-box"><input id="sendAsDocument" type="checkbox"><span>إرسال الصور كمرفقات بدل عرضها كصور</span></label></div><label class="send-text-placement">مكان النص الرئيسي<select id="sendTextPlacement"><option value="auto">تلقائي: تعليق للصورة أو رسالة قبل الملفات</option><option value="before">رسالة منفصلة مرة واحدة قبل الملفات</option><option value="after">رسالة منفصلة بعد الملفات</option><option value="none">عدم إرسال النص الرئيسي مع الملفات</option></select><small>الرسالة الرئيسية تُرسل مرة واحدة لكل هدف عند اختيار قبل/بعد؛ ورسائل «قبل الملفات» و«بعد الملفات» تبقى مستقلة لكل ملف.</small></label>
          <div class="upload-box" id="mediaDropZone" tabindex="0" role="button" aria-label="اسحب الملفات هنا أو اضغط لاختيارها"><input id="mediaFiles" type="file" multiple accept="image/*,.pdf,.txt,.md,.log,.csv,.json,.xml,.html,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.7z,.rar,.tar,.gz,.mp4,.webm,.mkv,.avi,.mov,.mp3,.m4a,.ogg,.wav,.aac,.flac,.opus"><label for="mediaFiles"><span>＋</span> اسحب الملفات إلى هنا أو اضغط للاختيار</label><small>معاينة الصور والملفات قبل الإرسال · الحد الحالي ${Number(data.settings?.maxImageSizeMB || 100)} MB لكل ملف؛ يدعم حتى 250 MB عند ضبط الإعداد.</small><label class="upload-option"><input id="replaceDuplicates" type="checkbox"><span>استبدال الملف المكرر تلقائيًا</span></label><div id="uploadStatus" class="muted" aria-live="polite"></div></div>
          <div class="media-library-toolbar"><b>الوسائط المحفوظة (${media.length})</b><div class="panel-actions"><button type="button" class="btn small" id="selectAllMedia">تحديد الكل</button><button type="button" class="btn small" id="clearMediaSelection">إلغاء التحديد</button><button type="button" class="btn small" id="clearSendText">مسح النصوص</button></div></div>
          <div class="file-list media-card-grid">${media.length ? media.map(mediaChip).join('') : '<div class="empty">لا توجد ملفات مرفوعة.</div>'}</div>
          <details class="advanced-panel"><summary>خيارات الإرسال الإضافية</summary><div class="form-grid three"><label>الترتيب<select id="sendOrder"><option value="target-first" ${data.settings?.sendOrder === 'target-first' ? 'selected' : ''}>كل هدف ثم ملفاته</option><option value="image-first" ${data.settings?.sendOrder === 'image-first' ? 'selected' : ''}>كل ملف ثم جميع الأهداف</option></select></label><label>منع الإرسال المكرر<select id="repeatGuard"><option value="on">مفعّل لمدة 90 ثانية</option><option value="off">السماح بالتكرار</option></select></label><label>تأخير بين الرسائل (مللي ثانية)<input id="sendDelayOverride" type="number" min="0" max="60000" value="${Number(data.settings?.sendDelayMs ?? 700)}"></label><label class="toggle-box"><input id="includeDefaultText" type="checkbox"><span>إضافة النص الافتراضي قبل الملفات</span></label><label>النص الافتراضي<input id="defaultPreText" value="${esc(data.settings?.preText || '')}" placeholder="اختياري"></label><label>الحد الأقصى للملف MB<input id="sendMaxFileSize" type="number" min="1" max="250" value="${Number(data.settings?.maxImageSizeMB || 100)}" disabled><small>غيّره من إعدادات التشغيل.</small></label></div></details>
          <div class="action-bar"><button class="btn primary large" id="sendNowBtn">إرسال الآن</button></div>
        </article>
      </section>
      <details class="task-workspace" ${(state.scheduleOpen || tasks.length > 0) ? 'open' : ''}><summary><span class="task-disclosure-icon" aria-hidden="true">◷</span><span class="task-disclosure-copy"><b>الإرسال التلقائي والمواعيد</b><small>افتح هذا القسم لإعداد موعد أو إدارة المهام المحفوظة.</small></span><span class="summary-cta">عرض المواعيد <span aria-hidden="true">＋</span></span></summary><div class="task-workspace-body"><section class="panel"><div class="panel-head"><div><h2>إنشاء موعد</h2><p>الإرسال المجدول يعمل مستقلًا عن الإرسال المباشر.</p></div></div>
        <div class="form-grid four"><label>اسم الموعد<input id="scheduleName" placeholder="موعد جديد"></label><label>الوقت<input id="scheduleTime" type="time" value="17:30"></label><label>التكرار<select id="scheduleMode"><option value="once">مرة واحدة</option><option value="weekly">أسبوعيًا</option><option value="monthly">شهريًا</option><option value="yearly">سنويًا</option></select></label><label class="schedule-date">التاريخ<input id="scheduleDate" type="date"></label></div>
        <div class="form-grid four"><label class="schedule-day" hidden>اليوم<select id="scheduleDay"><option value="0">الأحد</option><option value="1">الاثنين</option><option value="2">الثلاثاء</option><option value="3">الأربعاء</option><option value="4">الخميس</option><option value="5">الجمعة</option><option value="6">السبت</option></select></label><label class="schedule-dom" hidden>يوم الشهر<input id="scheduleDayOfMonth" type="number" min="1" max="31" value="1"></label><label class="schedule-month" hidden>الشهر<select id="scheduleMonth">${Array.from({ length: 12 }, (_, index) => `<option value="${index + 1}">${index + 1}</option>`).join('')}</select></label><label>نوع الملفات<select id="scheduleMediaMode"><option value="selected">الملفات المحددة فقط</option><option value="cycle">صورة الدورة تلقائيًا</option></select></label><label>سماح التأخير<select id="scheduleGraceMinutes"><option value="5">5 دقائق</option><option value="15">15 دقيقة</option><option value="30" selected>30 دقيقة</option><option value="60">ساعة</option><option value="180">3 ساعات</option></select><small>إذا انشغل الإرسال عند موعد المهمة، يحاول تنفيذها خلال هذه المهلة.</small></label><label class="toggle-box"><input id="scheduleGroupsEnabled" type="checkbox" checked><span>تشغيل على المجموعات</span></label></div>
        <div class="form-grid two"><label>الرسالة الرئيسية<textarea id="scheduleText" rows="3" maxlength="60000" placeholder="إن تركته فارغًا يستخدم نص الرسالة أعلى الصفحة"></textarea></label><label>رسالة قبل الملفات<textarea id="schedulePreText" rows="3" maxlength="60000" placeholder="اختياري — رسالة مستقلة قبل الملفات"></textarea></label><label>رسالة بعد الملفات<textarea id="schedulePostText" rows="3" maxlength="60000" placeholder="اختياري — رسالة مستقلة بعد الملفات"></textarea></label><label>موضع الرسالة الرئيسية<select id="scheduleTextPlacement"><option value="auto">تلقائي: تعليق للصورة أو رسالة قبل الملفات</option><option value="caption">تعليق للصورة (يتحول إلى رسالة مع المستندات)</option><option value="before">رسالة مستقلة قبل الملفات</option><option value="after">رسالة مستقلة بعد الملفات</option><option value="none">عدم إرسال الرسالة الرئيسية</option></select></label></div>
        <div class="form-grid three"><label class="toggle-box"><input id="scheduleCaptionMode" type="checkbox" checked><span>السماح بالتعليق على الصور</span></label><label class="toggle-box"><input id="scheduleSendAsDocument" type="checkbox"><span>إرسال الصور كمستندات</span></label><label>تأخير بين الرسائل (مللي ثانية)<input id="scheduleSendDelay" type="number" min="0" max="60000" value="${Number(data.settings?.sendDelayMs ?? 700)}"></label></div>
        <p class="muted schedule-help-note">يحفظ الموعد نسخة ثابتة من الأهداف والملفات والرسالة المحددة لحظة الضغط على «حفظ الموعد». تعديل التحديد في الإرسال المباشر لاحقًا لا يغيّر الموعد المحفوظ.</p>
        <div class="action-bar"><button class="btn primary" id="scheduleBtn">حفظ الموعد</button><button class="btn" id="scheduleResetBtn" type="button">موعد جديد / إلغاء التعديل</button></div>
        ${schedulerHealthMarkup(data.scheduler, data.settings, data.automation)}
        <div class="schedule-list">${tasks.length ? tasks.map(taskRow).join('') : '<div class="empty">لا توجد مواعيد محفوظة.</div>'}</div>
      </section></div></details>`;
  }

  function mediaChip(media) {
    const id = media.id || media.filename;
    const selected = state.selectedMedia === null ? true : state.selectedMedia.has(id);
    const url = media.url || `/media/${encodeURIComponent(media.filename || id)}?sessionId=${encodeURIComponent(sid())}`;
    const ext = String(media.ext || '').toLowerCase();
    let preview = `<div class="media-file-preview"><span>${mediaIcon(ext)}</span><b>${esc(ext.replace('.', '').toUpperCase() || 'FILE')}</b></div>`;
    if (media.isImage) preview = `<a class="media-preview-frame image-preview" href="${esc(url)}" target="_blank" rel="noopener" title="فتح الصورة بالحجم الكامل"><img src="${esc(url)}" loading="lazy" alt="معاينة ${esc(media.filename)}"></a>`;
    else if (ext === '.pdf') preview = `<div class="media-preview-frame pdf-preview"><iframe src="${esc(url)}#page=1&toolbar=0&navpanes=0" loading="lazy" title="معاينة PDF ${esc(media.filename)}"></iframe><a href="${esc(url)}" target="_blank" rel="noopener">فتح الملف ↗</a></div>`;
    else if (ext === '.txt') preview = `<div class="media-preview-frame text-preview"><pre data-text-preview="${esc(id)}">جارٍ تحميل معاينة النص…</pre></div>`;
    else if (ext === '.mp4') preview = `<div class="media-preview-frame video-preview"><video src="${esc(url)}#t=0.1" muted controls preload="metadata" playsinline></video></div>`;
    else if (['.mp3','.m4a','.ogg','.wav'].includes(ext)) preview = `<div class="media-preview-frame audio-preview"><span>♫</span><audio src="${esc(url)}" controls preload="none"></audio></div>`;
    return `<article class="media-card"><div class="media-preview-wrap">${preview}</div><div class="media-card-details"><label class="media-card-select"><input class="send-media" type="checkbox" value="${esc(id)}" ${selected ? 'checked' : ''}><span>اختيار للإرسال</span></label><b class="media-card-name" title="${esc(media.filename || id)}">${esc(media.filename || id)}</b><small>${esc(ext.replace('.', '').toUpperCase() || 'FILE')} · ${formatBytes(media.size)}</small><div class="media-card-actions"><button type="button" class="btn small" data-deselect-media="${esc(id)}">إزالة من الإرسال</button><button type="button" class="btn danger small" data-delete-media="${esc(id)}">حذف من المكتبة</button></div></div></article>`;
  }

  function mediaIcon(ext) {
    if (ext === '.pdf') return '📕'; if (['.doc','.docx','.txt'].includes(ext)) return '📝'; if (['.xls','.xlsx'].includes(ext)) return '📊'; if (['.ppt','.pptx'].includes(ext)) return '📽️'; if (ext === '.zip') return '🗜️'; if (ext === '.mp4') return '🎬'; if (['.mp3','.m4a','.ogg','.wav'].includes(ext)) return '🎵'; return '📄';
  }
  function formatBytes(value) { const bytes = Number(value) || 0; return bytes < 1024 ? `${bytes} B` : bytes < 1024*1024 ? `${(bytes/1024).toFixed(1)} KB` : `${(bytes/1024/1024).toFixed(2)} MB`; }

  function schedulerHealthMarkup(health = {}, settings = {}, automation = {}) {
    const error = String(health.lastError || ''), result = health.lastResult || null, attempt = health.lastAttempt || null;
    const disabled = settings.automationEnabled === false || automation.enabled === false;
    const dateLabel = value => { if (!value) return 'لم يحدث بعد'; const parsed = new Date(value); return Number.isNaN(parsed.getTime()) ? 'وقت غير متاح' : parsed.toLocaleString('ar-OM'); };
    const status = disabled ? 'الإرسال المجدول متوقف من الإعدادات' : error ? 'هناك خطأ في مراقب المواعيد' : result && result.ok === false ? 'المراقب يعمل، لكن آخر تنفيذ فشل' : Number(health.tickCount || 0) > 0 ? 'المراقب يعمل' : 'لم يبدأ الفحص بعد';
    const failed = Boolean(disabled || error || (result && result.ok === false));
    return `<div class="scheduler-health ${failed ? 'has-error' : ''}"><b>حالة الإرسال المجدول: ${esc(status)}</b>${disabled ? '<small class="schedule-error">فعّل «التشغيل التلقائي» في إعدادات التشغيل، وتأكد أن «أتمتة الجلسة» مفعّلة.</small>' : ''}<small>آخر فحص: ${esc(dateLabel(health.lastTickAt))} · عدد الفحوص: ${Number(health.tickCount || 0)} · مهام قيد التنفيذ: ${Number(health.busyTasks || 0)}</small><small>آخر محاولة: ${esc(attempt ? `${attempt.name || attempt.taskId} · ${dateLabel(attempt.at)}` : 'لا توجد محاولة مسجلة بعد')}</small><small>آخر نتيجة: ${esc(result ? `${result.name || result.taskId} · ${result.ok ? 'نجاح' : result.partial ? 'نجاح جزئي' : 'فشل'} · ${dateLabel(result.at)}` : 'لا توجد نتيجة تنفيذ مسجلة بعد')}</small>${error ? `<small class="schedule-error">خطأ مراقب المواعيد: ${esc(error)}</small>` : ''}${result?.error ? `<small class="schedule-error">سبب آخر فشل: ${esc(result.error)}</small>` : ''}</div>`;
  }

  function taskRow(task) {
    const next = task.nextRun ? `التالي: ${new Date(task.nextRun).toLocaleString('ar-OM')}` : (task.enabled === false ? 'متوقف / تم تنفيذ الموعد' : 'لا يوجد موعد قادم ضمن مهلة التنفيذ');
    const last = task.lastResult;
    const lastLabel = last ? `${last.ok ? 'آخر تنفيذ: نجح' : (last.partial ? 'آخر تنفيذ: نجح جزئيًا — راجع الفشل' : 'آخر تنفيذ: فشل')} · ${new Date(last.attemptedAt || task.lastAttemptAt || task.updatedAt || Date.now()).toLocaleString('ar-OM')}` : 'لم يُنفّذ بعد';
    const error = last && (last.error || last.failed?.[0]?.error) ? `<small class="schedule-error">${esc(last.error || last.failed?.[0]?.error)}</small>` : '';
    return `<div class="schedule-row"><div><b>${esc(task.name || 'موعد')} ${task.enabled === false ? '<span class="mini-state off">متوقف</span>' : '<span class="mini-state">مفعّل</span>'}</b><small>${esc(scheduleLabel(task))} · ${esc(next)}</small><small>${esc(lastLabel)} · أهداف: ${task.targetKeys?.length || 0} · ملفات: ${task.mediaMode === 'cycle' ? 'دورة الصور' : (task.mediaIds?.length || 0)}</small>${error}</div><div class="row-actions"><button class="btn small" data-run-task="${esc(task.id)}">تشغيل الآن</button><button class="btn small" data-edit-task="${esc(task.id)}">تعديل</button><button class="btn small" data-toggle-task="${esc(task.id)}">${task.enabled === false ? 'تفعيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-task="${esc(task.id)}">حذف</button></div></div>`;
  }

  function scheduleLabel(task) {
    const days = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
    const months = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
    let repeat = ({ once: 'مرة واحدة', weekly: 'أسبوعيًا', monthly: 'شهريًا', yearly: 'سنويًا' }[task.mode] || task.mode);
    if (task.mode === 'once') repeat += ` · ${task.date || 'لا يوجد تاريخ'}`;
    else if (task.mode === 'weekly') repeat += ` · ${days[Number(task.day) || 0]}`;
    else if (task.mode === 'monthly') repeat += ` · يوم ${Number(task.dayOfMonth) || 1}`;
    else if (task.mode === 'yearly') repeat += ` · ${Number(task.dayOfMonth) || 1} ${months[Math.max(0,Math.min(11,(Number(task.month)||1)-1))]}`;
    return repeat + ` · ${task.time || ''}`;
  }

  function pagePeople(data) {
    const filter = state.peopleFilter.trim().toLocaleLowerCase('ar');
    const recipients = (data.recipients || []).filter((item) => `${item.displayName || item.name || ''} ${item.international || ''} ${item.e164 || ''} ${item.whatsappName || ''}`.toLocaleLowerCase('ar').includes(filter));
    const runtimeReady = data.whatsapp?.ready === true;
    return `<section class="page-title"><p class="eyebrow">الأشخاص</p><h1>جهات الإرسال</h1><p>الاسم والصورة المحليان منفصلان عن WhatsApp. مزامنة WhatsApp لا تغيّر أي تخصيص محلي أجريته هنا.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>إضافة شخص</h2><p>أضف يدويًا أو اختر اسمًا مباشرةً من جهات اتصال WhatsApp.</p></div></div>
          <div class="form-grid three"><label>الاسم الأولي<input id="recipientName" placeholder="اسم الشخص"></label><label>الدولة<select id="recipientCountry">${countryOptions('OM')}</select></label><label>رقم الهاتف<input id="recipientPhone" inputmode="tel" placeholder="7345 xxxx"></label></div>
          <div id="phonePreview" class="inline-status">اكتب الرقم لمراجعته.</div>
          <div class="action-bar"><button class="btn primary" id="addRecipientBtn">إضافة الشخص</button><button class="btn" id="loadWhatsappContacts" ${runtimeReady ? '' : 'disabled'}>اختيار من WhatsApp</button></div>
          <p class="muted">يتم حفظ الشخص أولًا، ثم محاولة قراءة الاسم والصورة الحالية من WhatsApp في الخلفية. لا تُرسل له رسالة تلقائيًا لمجرد إضافته.</p>
          <details class="advanced-panel"><summary>إضافة قائمة أرقام</summary><p>سطر لكل رقم: الاسم|الرقم</p><textarea id="bulkRecipients" rows="7" placeholder="أحمد|7345 xxxx
Sara|7345 xxxx"></textarea><button class="btn" id="bulkAddBtn">إضافة القائمة</button></details>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الأشخاص المحفوظون</h2><p>${recipients.length} من ${(data.recipients || []).length} شخص · المحدد ${state.selectedRecipientIds.size}.</p></div><div class="panel-actions"><button class="btn small" id="selectVisiblePeople">تحديد الظاهر</button><button class="btn small" id="clearSelectedPeople">إلغاء التحديد</button><button class="btn danger small" id="deleteSelectedPeople" ${state.selectedRecipientIds.size ? '' : 'disabled'}>حذف المحدد (${state.selectedRecipientIds.size})</button></div></div>
          <input id="peopleSearch" value="${esc(state.peopleFilter)}" placeholder="بحث بالاسم أو الرقم..."><div class="people-list">${recipients.length ? recipients.map(personRow).join('') : '<div class="empty">لا توجد نتائج.</div>'}</div>
        </article>
      </section>
      <section class="panel contact-management-panel"><div class="panel-head"><div><h2>مزامنة الاسماء والصور</h2><p>افحص الاختلافات الحالية، راجع الشكل قبل وبعد، ثم اختر جهات بعينها أو مزامن الجميع.</p></div><div class="panel-actions"><button class="btn" id="scanContactSync" ${runtimeReady && recipients.length ? '' : 'disabled'}>فحص التغييرات</button><button class="btn" id="clearContactSync">إخفاء المعاينة</button></div></div>
        <p class="muted">تظل «الاسم المحلي» و«الصورة المحلية» محفوظين داخل المشروع فقط. استعادة القيم الافتراضية تتم بمسح التخصيص المحلي من صف الشخص.</p>
        <div id="contactSyncPreview">${contactSyncPreviewMarkup()}</div>
        <div id="whatsappContactsPanel">${whatsappContactsMarkup()}</div>
      </section>`;
  }

  function avatarMarkup(url, name, className = 'person-avatar') {
    const safeName = String(name || '?').trim() || '?';
    return url
      ? `<span class="${className}"><img src="${esc(url)}" alt="صورة ${esc(safeName)}" loading="lazy" referrerpolicy="no-referrer" onerror="this.style.display='none';this.parentElement.classList.add('avatar-image-failed')"><span class="avatar-fallback">${esc(safeName.slice(0, 1))}</span></span>`
      : `<span class="${className} avatar-no-image" aria-label="لا توجد صورة">${esc(safeName.slice(0, 1))}</span>`;
  }

  function personRow(person) {
    const shownName = person.displayName || person.name || 'بدون اسم';
    const phone = person.international || person.e164 || person.phone || '';
    const profileHint = person.profileError ? `تعذر تحديث ملف WhatsApp: ${person.profileError}` : person.profileCheckedAt ? `آخر مزامنة: ${new Date(person.profileCheckedAt).toLocaleString('ar-OM')}` : 'لم تكتمل قراءة ملف WhatsApp بعد';
    const personal = person.autoReply || { mode: 'inherit', rules: [], fallbackReply: '', conversationEnabled: false, fallbackToGlobal: true, cooldownSec: 0 };
    const personalRulesText = (personal.rules || []).map(rule => `${rule.match || 'contains'} :: ${rule.value || ''} :: ${String(rule.reply || '').replace(/[\r\n]+/g, ' ')}`).join('\n');
    return `<div class="person-row contact-person-row" title="${esc(profileHint)}"><label class="person-select" title="تحديد الشخص للحذف الجماعي"><input type="checkbox" data-select-person="${esc(person.id)}" ${state.selectedRecipientIds.has(person.id) ? 'checked' : ''} aria-label="تحديد ${esc(shownName)}"></label>${avatarMarkup(person.avatarUrl || person.whatsappAvatarUrl, shownName)}<div class="person-main"><b>${esc(shownName)}</b><small dir="ltr">${esc(phone)}</small>${person.profileError ? '<small class="profile-issue" aria-label="مشكلة في المزامنة">تعذّر التحديث</small>' : ''}</div><span class="mini-state ${person.enabled === false ? 'off' : ''}">${person.enabled === false ? 'متوقف' : 'مفعّل'}</span><div class="row-actions person-tools"><button class="btn small" title="تعديل الاسم المحلي" data-edit-person="${esc(person.id)}" data-current-local-name="${esc(person.localName || '')}">اسم</button><button class="btn small" title="تغيير الصورة داخل المشروع" data-avatar-open="${esc(person.id)}">صورة</button><input type="file" accept="image/jpeg,image/png,image/webp" data-avatar-file="${esc(person.id)}" hidden><button class="btn small" title="استعادة صورة WhatsApp الحالية" data-reset-avatar="${esc(person.id)}" ${person.localAvatarFile ? '' : 'disabled'}>WA</button><button class="btn small" title="${person.enabled === false ? 'تفعيل المستلم' : 'إيقاف المستلم'}" data-toggle-person="${esc(person.id)}">${person.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" title="حذف من قائمة الإرسال" data-delete-person="${esc(person.id)}">حذف</button></div><details class="person-interaction-editor"><summary>تخصيص الرد والمحادثة لهذا الشخص</summary><div class="form-grid two"><label>وضع الرد<select data-person-auto-mode="${esc(person.id)}"><option value="inherit" ${personal.mode === 'inherit' ? 'selected' : ''}>استخدام قواعد البوت العامة</option><option value="custom" ${personal.mode === 'custom' ? 'selected' : ''}>ردود وقواعد خاصة بهذا الشخص</option><option value="off" ${personal.mode === 'off' ? 'selected' : ''}>إيقاف الرد لهذا الشخص</option></select></label><label>فاصل الرد بالثواني<input type="number" min="0" max="86400" value="${Number(personal.cooldownSec || 0)}" data-person-auto-cooldown="${esc(person.id)}"></label><label class="span-two">قواعد الرد الخاصة (قاعدة بكل سطر)<textarea rows="4" data-person-auto-rules="${esc(person.id)}" placeholder="contains :: مرحبا :: أهلًا {{sender}}\nexact :: كيف حالك :: أنا بخير">${esc(personalRulesText)}</textarea><small>الصيغة: contains أو exact أو starts أو ends أو any :: الكلمة :: الرد. الرد الافتراضي يدعم عدة أسطر والمتغيرات أدناه.</small></label><label class="span-two">الرد الافتراضي لهذا الشخص<textarea rows="3" maxlength="60000" data-person-auto-fallback="${esc(person.id)}" placeholder="اكتب ردًا خاصًا أو اتركه فارغًا">${esc(personal.fallbackReply || '')}</textarea></label><label class="toggle-box"><input type="checkbox" data-person-auto-conversation="${esc(person.id)}" ${personal.conversationEnabled ? 'checked' : ''}><span>تفعيل رد محادثي بسيط لهذا الشخص</span></label><label class="toggle-box"><input type="checkbox" data-person-auto-global="${esc(person.id)}" ${personal.fallbackToGlobal !== false ? 'checked' : ''}><span>الرجوع إلى القواعد العامة عند عدم التطابق</span></label><p class="muted span-two">المتغيرات: {{sender}} و{{message}} و{{chat}} و{{time}}.</p></div><div class="action-bar"><button class="btn primary" data-save-person-auto="${esc(person.id)}">حفظ تخصيص الرد</button></div></details></div>`;
  }

  function whatsappContactsMarkup() {
    if (!Array.isArray(state.whatsappContacts)) return '<div class="empty contact-panel-placeholder">لم يتم تحميل جهات اتصال WhatsApp بعد. اتصل بالحساب ثم اضغط «اختيار من WhatsApp».</div>';
    const contacts = state.whatsappContacts;
    if (!contacts.length) return '<div class="empty">لم يعرض WhatsApp جهات اتصال قابلة للإضافة.</div>';
    const filter = String(state.whatsappContactFilter || '').toLocaleLowerCase('ar');
    const matching = contacts.filter(c => `${c.name || ''} ${c.whatsappName || ''} ${c.addressBookName || ''} ${c.phone || ''}`.toLocaleLowerCase('ar').includes(filter));
    const visible = matching.slice(0, 250);
    const progress = state.whatsappProfileHydrating ? `جارٍ جلب الاسم والصورة من WhatsApp: ${state.whatsappProfileHydrationProgress.done}/${state.whatsappProfileHydrationProgress.total} · أخطاء ${state.whatsappProfileHydrationProgress.failed}` : (contacts.some(c => c.profileStatus === 'not-read' || !c.profileHydrated) ? 'يمكن جلب الاسم الذي يظهر في WhatsApp وصورة الملف الشخصي من زر المزامنة.' : 'اكتمل فحص بيانات جهات WhatsApp المعروضة.');
    return `<details class="whatsapp-contact-browser" open><summary>جهات اتصال WhatsApp (${contacts.length}) · نتائج البحث ${matching.length}</summary><div class="action-bar"><button class="btn small" id="refreshWhatsAppContactProfiles" ${state.whatsappProfileHydrating ? 'disabled' : ''}>${state.whatsappProfileHydrating ? 'جارٍ المزامنة…' : 'جلب الأسماء والصور من WhatsApp'}</button><span class="muted">${esc(progress)}</span></div><input id="whatsappContactSearch" value="${esc(state.whatsappContactFilter || '')}" placeholder="ابحث في جهات WhatsApp..."><div class="whatsapp-contact-list">${visible.map(contact => `<div class="whatsapp-contact-row">${avatarMarkup(contact.avatarUrl, contact.name, 'person-avatar small-avatar')}<div class="person-main"><b>${esc(contact.name || contact.phone || 'جهة اتصال')}</b><small dir="ltr">${contact.phone ? `+${esc(contact.phone)}` : 'رقم الهاتف غير متاح من WhatsApp'}</small>${contact.profileStatus === 'error' && contact.profileError ? `<small title="${esc(contact.profileError)}">تعذر جلب الملف الشخصي</small>` : ''}</div><button class="btn small ${contact.exists || contact.canAdd === false ? '' : 'primary'}" data-add-wa-contact="${esc(contact.id)}" ${contact.exists || contact.canAdd === false ? 'disabled' : ''}>${contact.exists ? 'مضاف' : contact.canAdd === false ? 'رقم غير متاح' : 'إضافة'}</button></div>`).join('') || '<div class="empty">لا توجد نتائج مطابقة.</div>'}</div>${matching.length > visible.length ? `<p class="muted">تُعرض أول ${visible.length} نتيجة فقط لتحسين الأداء؛ ضيّق البحث للوصول إلى جهة محددة.</p>` : ''}</details>`;
  }

  function contactSyncPreviewMarkup() {
    const preview = state.contactSyncPreview;
    if (!preview) return '<div class="empty">لم يتم فحص الأسماء والصور بعد.</div>';
    const changes = Array.isArray(preview.changes) ? preview.changes : [];
    const selectable = changes.some(item => item.changed && !item.error);
    return `<div class="sync-summary">تم فحص ${Number(preview.scanned || changes.length)} · اختلافات ${Number(preview.changed || 0)} · أخطاء قراءة ${Number(preview.failed || 0)}</div>${selectable ? `<div class="action-bar"><button class="btn small" id="syncSelectChanged">تحديد كل المختلف</button><button class="btn small" id="syncClearSelection">إلغاء التحديد</button><button class="btn primary" id="syncApplySelected">مزامنة المحدد</button><button class="btn" id="syncApplyAll">مزامنة الكل المختلف</button></div>` : ''}<div class="contact-sync-list">${changes.map(item => {
      const before = item.before || {}, after = item.after || {}, selected = item.selected === true;
      const status = item.error ? `تعذر الفحص: ${item.error}` : item.changed ? [item.changedName ? 'الاسم تغيّر' : '', item.changedAvatar ? 'الصورة تغيّرت' : ''].filter(Boolean).join(' · ') : 'لا يوجد اختلاف في بيانات WhatsApp';
      return `<article class="contact-sync-row ${item.error ? 'sync-error' : item.changed ? 'sync-changed' : ''}"><label class="sync-select">${item.changed && !item.error ? `<input type="checkbox" data-sync-select="${esc(item.id)}" ${selected ? 'checked' : ''}>` : '<span class="sync-no-select">—</span>'}<span>${esc(item.phone || '')}</span></label><div class="sync-before-after"><div class="sync-profile">${avatarMarkup(before.avatarUrl, before.name, 'person-avatar sync-avatar')}<div><small>قبل المزامنة</small><b>${esc(before.name || 'بدون اسم')}</b></div></div><span class="sync-arrow" aria-hidden="true">←</span><div class="sync-profile">${avatarMarkup(after.avatarUrl, after.name, 'person-avatar sync-avatar')}<div><small>بعد المزامنة</small><b>${esc(after.name || 'بدون اسم')}</b></div></div></div><div class="sync-item-status">${esc(status)}${item.localName ? '<small>اسم محلي مخصص محفوظ ولن يتغير.</small>' : ''}${item.localAvatarFile ? '<small>صورة محلية مخصصة محفوظة ولن تتغير.</small>' : ''}</div></article>`;
    }).join('')}</div>`;
  }

  function filteredGroups(data) {
    const filter = state.groupFilter.trim().toLocaleLowerCase('ar');
    return (data.groups || []).filter((group) => {
      const matchesSearch = `${group.name || ''} ${group.gid || ''}`.toLocaleLowerCase('ar').includes(filter);
      const matchesStatus = state.groupStatusFilter === 'all' || (state.groupStatusFilter === 'active' ? group.enabled !== false : group.enabled === false);
      return matchesSearch && matchesStatus;
    });
  }

  function pageGroups(data) {
    const groups = filteredGroups(data);
    const current = state.selectedGroup && (data.groups || []).find((group) => group.gid === state.selectedGroup);
    return `<section class="page-title"><p class="eyebrow">المجموعات</p><h1>المجموعات هذه الجلسة</h1><p>اكتشاف وربط وتحليل وحفظ المجموعة في الجلسة الحالية، ثم استخدامها كهدف مستقل في الإرسال والتفاعل.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>ربط أو اكتشاف</h2><p>ضع GID أو رابط دعوة وسيُحلل تلقائيًا.</p></div></div>
          <label>GID أو رابط الدعوة<input id="groupValue" placeholder="120363...@g.us أو chat.whatsapp.com/..." value=""></label>
          <div class="action-bar"><button class="btn primary" id="connectGroupBtn">ربط وتحليل</button><button class="btn" id="discoverGroupsBtn">اكتشاف</button><button class="btn" id="refreshGroupsBtn">تحديث الكل</button></div>
          <div id="groupResult" class="result-box">سيتم عرض نتيجة التحليل هنا.</div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>المجموعات المحفوظة</h2><p>${groups.length} مجموعة في هذه الجلسة.</p></div><div class="panel-actions"><button class="btn small" id="exportGroupsJson">تصدير JSON</button><button class="btn small" id="exportGroupsCsv">تصدير CSV</button></div></div>
          <input id="groupSearch" value="${esc(state.groupFilter)}" placeholder="ابحث باسم المجموعة أو GID...">
          <div class="group-tools"><label>عرض<select id="groupStatusFilter"><option value="all" ${state.groupStatusFilter === 'all' ? 'selected' : ''}>كل المجموعات</option><option value="active" ${state.groupStatusFilter === 'active' ? 'selected' : ''}>المفعّلة فقط</option><option value="disabled" ${state.groupStatusFilter === 'disabled' ? 'selected' : ''}>المتوقفة فقط</option></select></label><button class="btn small" id="groupSelectVisible">تحديد الظاهر</button><button class="btn small" id="groupClearSelection">إلغاء التحديد</button><span class="muted" id="groupSelectionCount">${state.selectedGroupIds.size} محددة</span></div>
          <div class="group-bulk-toolbar"><button class="btn small" data-group-bulk-action="enable">تفعيل المحدد</button><button class="btn small" data-group-bulk-action="disable">إيقاف المحدد</button><button class="btn small danger" data-group-bulk-action="delete">حذف المحدد</button></div>
          <div class="group-list">${groups.length ? groups.map((group) => groupRow(group, current?.gid === group.gid)).join('') : '<div class="empty">لا توجد مجموعات مطابقة للفلاتر الحالية.</div>'}</div></article>
      </section>
      <section class="panel"><div class="panel-head"><div><h2>تفاصيل المجموعة</h2><p>اعرض البيانات الكاملة المتاحة، ثم استخدم المجموعة مباشرة في الإرسال.</p></div></div><div id="groupDetail">${groupDetails(current)}</div></section>`;
  }

  function groupRow(group, selected) {
    return `<article class="group-row ${selected ? 'selected' : ''}"><label class="group-select"><input type="checkbox" data-select-group="${esc(group.id)}" ${state.selectedGroupIds.has(group.id) ? 'checked' : ''} aria-label="تحديد مجموعة ${esc(group.name || group.gid)}"></label><div class="group-main"><b>${esc(group.name || group.gid)}</b><small>${esc(group.gid || '')}</small></div><div class="group-meta"><span>${Number(group.participantsCount || group.participants?.length || 0)} عضو</span><span>${Number(group.admins?.length || 0)} مشرف</span><span class="mini-state ${group.enabled === false ? 'off' : ''}">${group.enabled === false ? 'متوقفة' : 'مفعّلة'}</span></div><div class="row-actions"><button class="btn small" data-show-group="${esc(group.gid)}">عرض</button><button class="btn small" data-send-group="${esc(group.id)}">إرسال</button><button class="btn small" data-copy-group="${esc(group.gid)}">نسخ GID</button><button class="btn small" data-toggle-group="${esc(group.id)}">${group.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-group="${esc(group.id)}">حذف</button></div></article>`;
  }

  function groupDetails(group) {
    if (!group) return '<div class="empty">اختر مجموعة من القائمة.</div>';
    const members = Array.isArray(group.participants) ? group.participants : [];
    const admins = Array.isArray(group.admins) ? group.admins : members.filter((item) => item.admin);
    const matchingMembers = filterGroupMembers(members);
    const visibleMembers = matchingMembers.slice(0, state.groupMemberLimit);
    const rows = visibleMembers.map((member, index) => `<tr><td>${index + 1}</td><td>${esc(member.name || 'بدون اسم')}</td><td class="mono">${esc(member.id || '')}</td><td>${member.admin ? 'مشرف' : 'عضو'}</td><td><button type="button" class="btn small" data-copy-member="${esc(member.id || '')}">نسخ</button></td></tr>`).join('');
    return `<div class="info-grid six"><div><span>الاسم</span><b>${esc(group.name || '')}</b></div><div><span>GID</span><b class="mono">${esc(group.gid || '')}</b></div><div><span>الأعضاء</span><b>${Number(group.participantsCount || members.length || 0)}</b></div><div><span>المشرفون</span><b>${admins.length}</b></div><div><span>المالك</span><b class="mono">${esc(group.owner || 'غير متاح')}</b></div><div><span>رمز الدعوة</span><b>${esc(group.inviteCode || 'غير متاح')}</b></div></div><div class="detail-line"><strong>الوصف:</strong> ${esc(group.description || 'لا يوجد وصف')}</div><details class="member-details"><summary>الأعضاء والمشرفون (${members.length})</summary>${members.length ? `<div class="member-search-tools"><input id="groupMemberSearch" value="${esc(state.groupMemberFilter)}" placeholder="بحث باسم العضو أو المعرف…"><span id="groupMemberCount">عرض ${visibleMembers.length} من ${matchingMembers.length}</span></div><div class="table-wrap" id="groupMembersHost"><table><thead><tr><th>#</th><th>الاسم</th><th>المعرف</th><th>الدور</th><th>أداة</th></tr></thead><tbody>${rows}</tbody></table></div><div id="groupMembersMoreWrap">${matchingMembers.length > visibleMembers.length ? '<button type="button" class="btn small" id="groupMembersMore">عرض 100 عضو إضافي</button>' : ''}</div>` : '<div class="empty">لم يوفر WhatsApp قائمة الأعضاء.</div>'}</details>`;
  }

  function filterGroupMembers(members) {
    const filter = state.groupMemberFilter.trim().toLocaleLowerCase('ar');
    return members.filter(member => `${member.name || ''} ${member.id || ''}`.toLocaleLowerCase('ar').includes(filter));
  }

  function renderGroupMembers() {
    const group = (state.data?.groups || []).find(item => item.gid === state.selectedGroup);
    if (!group) return;
    const members = Array.isArray(group.participants) ? group.participants : [];
    const matching = filterGroupMembers(members), visible = matching.slice(0, state.groupMemberLimit);
    const host = $('#groupMembersHost');
    if (host) host.innerHTML = `<table><thead><tr><th>#</th><th>الاسم</th><th>المعرف</th><th>الدور</th><th>أداة</th></tr></thead><tbody>${visible.map((member,index) => `<tr><td>${index+1}</td><td>${esc(member.name || 'بدون اسم')}</td><td class="mono">${esc(member.id || '')}</td><td>${member.admin ? 'مشرف' : 'عضو'}</td><td><button type="button" class="btn small" data-copy-member="${esc(member.id || '')}">نسخ</button></td></tr>`).join('')}</tbody></table>`;
    const count = $('#groupMemberCount'); if (count) count.textContent = `عرض ${visible.length} من ${matching.length}`;
    const more = $('#groupMembersMoreWrap'); if (more) more.innerHTML = matching.length > visible.length ? '<button type="button" class="btn small" id="groupMembersMore">عرض 100 عضو إضافي</button>' : '';
    bindGroupMemberCopy();
    $('#groupMembersMore')?.addEventListener('click', () => { state.groupMemberLimit += 100; renderGroupMembers(); });
  }

  function pageInteraction(data) {
    const interaction = data.interaction || {};
    const rules = interaction.rules || [];
    const recent = interaction.recent || [];
    const health = interaction.health || {};
    const selected = new Set((data.settings?.interactionChatIds || []).map(String));
    const candidates = activeTargets(data);
    const stamp = health.lastMessageAt ? new Date(health.lastMessageAt).toLocaleString('ar-OM') : 'لم تصل رسالة بعد';
    return `<section class="page-title"><p class="eyebrow">التفاعل</p><h1>التفاعل التلقائي</h1><p>قواعد حقيقية تعمل على الرسائل وReactions داخل الجلسة.</p></section>
      <section class="panel interaction-health-panel"><div class="panel-head"><div><h2>مراقبة التفاعل</h2><p>تعرض هذه اللوحة ما استلمه البوت وما حاول تنفيذه وآخر سبب للفشل.</p></div><span class="mini-state ${data.whatsapp?.ready ? '' : 'off'}">${data.whatsapp?.ready ? 'WhatsApp متصل' : 'WhatsApp غير متصل'}</span></div>
        <div class="interaction-health-metrics"><div><b>${Number(health.receivedCount || 0)}</b><small>رسائل تمت معالجتها</small></div><div><b>${Number(health.handledCount || 0)}</b><small>رسائل طابقت إجراءً</small></div><div><b>${Number(health.replyCount || 0)}</b><small>ردود ناجحة</small></div><div><b>${Number(health.errorCount || 0)}</b><small>أخطاء</small></div></div>
        <div class="interaction-health-detail"><span>آخر رسالة: ${esc(stamp)}</span><span>المحادثة: <code>${esc(health.lastChatId || '—')}</code></span><span>النتيجة: <b>${esc(health.lastOutcome || 'لا توجد نتيجة بعد')}</b></span></div>
        ${health.lastText ? `<p class="interaction-last-message"><b>آخر نص:</b> ${esc(health.lastText)}</p>` : ''}${health.lastError ? `<div class="interaction-error"><b>سبب الفشل الأخير</b><p>${esc(health.lastError)}</p></div>` : '<p class="muted">إذا لم يظهر أي عداد بعد، أرسل رسالة اختبار جديدة بعد التأكد من اتصال WhatsApp وتفعيل التفاعل والقاعدة.</p>'}
      </section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>التشغيل</h2><p>التحكم الأساسي واضح، والخيارات المتقدمة اختيارية.</p></div></div>
          <div class="toggle-list"><label class="toggle-row"><input id="interactionEnabled" type="checkbox" ${data.settings?.interactionEnabled !== false ? 'checked' : ''}><span><b>التفاعل</b><small>شغّل أو أوقف كل القواعد.</small></span></label><label class="toggle-row"><input id="groupAssistantEnabled" type="checkbox" ${data.settings?.groupAssistantEnabled !== false ? 'checked' : ''}><span><b>مساعد المجموعات</b><small>أوامر GID والتحليل داخل المجموعات.</small></span></label><label class="toggle-row"><input id="interactionIgnoreOwn" type="checkbox" ${data.settings?.interactionIgnoreOwn !== false ? 'checked' : ''}><span><b>تجاهل رسائل الحساب</b><small>يمنع حلقات الرد على النفس.</small></span></label><label class="toggle-row"><input id="interactionUseRecipientNames" type="checkbox" ${data.settings?.interactionUseRecipientNames !== false ? 'checked' : ''}><span><b>استخدم الاسم المسجل في المشروع</b><small>يعرض الاسم المحلي المحفوظ للمستلم في الردود بدل اسم WhatsApp؛ يمكنك إيقافه.</small></span></label><label class="toggle-row"><input id="interactionFallbackEnabled" type="checkbox" ${data.settings?.interactionFallbackEnabled !== false ? 'checked' : ''}><span><b>رد افتراضي عند عدم تطابق قاعدة</b><small>حتى لا تبقى الرسالة بلا رد؛ يراعي فترة تهدئة لكل محادثة.</small></span></label></div>
          <div class="action-bar"><button class="btn primary" id="saveInteractionSettings">حفظ</button></div>
          <details class="advanced-panel"><summary>نطاق التشغيل ووقت الهدوء</summary><div class="form-grid two"><label>النطاق العام<select id="interactionScope"><option value="all" ${data.settings?.interactionScope === 'all' ? 'selected' : ''}>كل المحادثات</option><option value="groups" ${data.settings?.interactionScope === 'groups' ? 'selected' : ''}>المجموعات</option><option value="private" ${data.settings?.interactionScope === 'private' ? 'selected' : ''}>الخاص</option><option value="selected" ${data.settings?.interactionScope === 'selected' ? 'selected' : ''}>أهداف محددة</option></select></label><label>الحد الأقصى للأفعال/الدقيقة<input id="maxActionsPerMinute" type="number" min="1" max="1000" value="${Number(data.settings?.maxActionsPerMinute || 20)}"></label><label class="toggle-box"><input id="interactionQuietEnabled" type="checkbox" ${data.settings?.interactionQuietEnabled ? 'checked' : ''}><span>فترة هدوء</span></label><label>من<input id="interactionQuietStart" type="time" value="${esc(data.settings?.interactionQuietStart || '23:00')}"></label><label>إلى<input id="interactionQuietEnd" type="time" value="${esc(data.settings?.interactionQuietEnd || '07:00')}"></label><label>السلوك في فترة الهدوء<select id="interactionQuietAction"><option value="silence" ${(data.settings?.interactionQuietAction || 'silence') === 'silence' ? 'selected' : ''}>لا يرد</option><option value="reply" ${data.settings?.interactionQuietAction === 'reply' ? 'selected' : ''}>يرسل ردًا محددًا</option><option value="rules" ${data.settings?.interactionQuietAction === 'rules' ? 'selected' : ''}>يستمر في تطبيق القواعد</option></select></label><label>نص رد الهدوء<textarea id="interactionQuietReply" rows="3" maxlength="60000">${esc(data.settings?.interactionQuietReply || 'أنا في فترة الهدوء الآن، سأرد عليك لاحقًا.')}</textarea></label><label>الفاصل بين الردود (ثانية)<input id="interactionQuietCooldownSec" type="number" min="30" max="86400" value="${Number(data.settings?.interactionQuietCooldownSec || 300)}"></label><label>فاصل الرد الافتراضي (ثانية)<input id="interactionFallbackCooldownSec" type="number" min="30" max="86400" value="${Number(data.settings?.interactionFallbackCooldownSec || 300)}"></label><label class="span-two">نص الرد الافتراضي<textarea id="interactionFallbackReply" rows="4" maxlength="60000">${esc(data.settings?.interactionFallbackReply || 'أهلًا {{sender}} 👋 وصلتني رسالتك: «{{message}}». سأتابع معك حسب الردود التلقائية المتاحة.')}</textarea><small>المتغيرات: {{sender}} اسم المستخدم، {{message}} نص الرسالة، {{chat}} المحادثة، {{time}} الوقت.</small></label></div><p class="muted">وضع «القواعد» يتبع أوقات التشغيل الخاصة بكل قاعدة. وضع «لا يرد» يعطّل الردود أثناء الفترة.</p><div class="target-picker"><b>الأهداف المحددة</b>${candidates.length ? candidates.map((target) => `<label><input type="checkbox" class="rule-target" value="${esc(chatIdForTarget(target))}" ${selected.has(chatIdForTarget(target)) ? 'checked' : ''}><span>${esc(target.name || target.gid || target.phone || '')}</span><small>${typeLabel(target)}</small></label>`).join('') : '<div class="empty">لا توجد أهداف في الجلسة.</div>'}</div></details>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>قاعدة جديدة</h2><p>اختَر الحدث ثم المطابقة ثم الإجراء.</p></div></div>
          <div class="form-grid two"><label>اسم القاعدة<input id="ruleName" placeholder="ترحيب"></label><label>الحدث<select id="ruleEvent"><option value="message">رسالة</option><option value="reaction">Reaction</option></select></label><label>المطابقة<select id="ruleMatch"><option value="contains">يحتوي</option><option value="exact">مطابق</option><option value="starts">يبدأ بـ</option><option value="ends">ينتهي بـ</option><option value="regex">Regex</option><option value="any">أي</option></select></label><label>النص أو الإيموجي<input id="ruleValue" placeholder="السلام عليكم"></label><label>النطاق<select id="ruleScope"><option value="all">الكل</option><option value="groups">المجموعات</option><option value="private">الخاص</option><option value="selected">أهداف محددة</option></select></label><label>الإجراء<select id="ruleAction"><option value="reply">رد نصي</option><option value="reaction">Reaction</option><option value="both">رد + Reaction</option></select></label></div>
          <div class="form-grid two"><label id="ruleReplyWrap" class="span-two">الرد النصي<textarea id="ruleReply" rows="5" maxlength="60000" placeholder="يمكنك كتابة رد طويل متعدد الأسطر. المتغيرات: {{sender}} و{{message}} و{{chat}} و{{time}}."></textarea></label><label id="ruleEmojiWrap">Reaction<input id="ruleEmoji" placeholder="👍"></label></div>
          <div class="preset-row"><span>قوالب جاهزة:</span><button class="btn small" data-rule-preset="welcome">ترحيب</button><button class="btn small" data-rule-preset="help">مساعدة</button><button class="btn small" data-rule-preset="reaction">Reaction</button></div>
          <details class="advanced-panel"><summary>تفاصيل القاعدة ووقت التشغيل</summary><div class="form-grid three"><label>الأولوية<input id="rulePriority" type="number" value="10"></label><label>منع التكرار (ثانية)<input id="ruleCooldown" type="number" min="0" max="86400" value="45"></label><label class="toggle-box"><input id="ruleStop" type="checkbox" checked><span>أوقف القواعد التالية بعد نجاح التنفيذ</span></label><label class="toggle-box"><input id="ruleScheduleEnabled" type="checkbox"><span>تشغيل القاعدة في أوقات محددة فقط</span></label><label>من الساعة<input id="ruleScheduleStart" type="time" value="09:00"></label><label>إلى الساعة<input id="ruleScheduleEnd" type="time" value="17:00"></label></div><label>أيام تشغيل القاعدة<select id="ruleScheduleDays" multiple size="4"><option value="0" selected>الأحد</option><option value="1" selected>الاثنين</option><option value="2" selected>الثلاثاء</option><option value="3" selected>الأربعاء</option><option value="4" selected>الخميس</option><option value="5" selected>الجمعة</option><option value="6" selected>السبت</option></select></label><p class="muted">إذا ألغيت تشغيل الوقت، ستعمل القاعدة دائمًا عندما يتطابق الشرط. المنطقة الزمنية هي منطقة الجلسة.</p><label class="test-field">رسالة الاختبار<textarea id="ruleTestMessage" rows="3" placeholder="اكتب هنا الرسالة التي تريد اختبارها"></textarea></label><label class="test-field">إيموجي الاختبار<input id="ruleTestEmoji" placeholder="👍"></label><div class="action-bar"><button class="btn" id="testRuleBtn">اختبار القاعدة</button></div></details>
          <div class="action-bar"><button class="btn primary" id="addRuleBtn">حفظ القاعدة</button></div>
        </article>
      </section>
      <section class="content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>القواعد الحالية</h2><p>${rules.length} قاعدة محفوظة لهذه الجلسة.</p></div></div><div class="rule-list">${rules.length ? rules.map(ruleRow).join('') : '<div class="empty">لا توجد قواعد بعد.</div>'}</div></article><article class="panel"><div class="panel-head"><div><h2>آخر التفاعلات</h2><p>نتيجة التنفيذ الفعلية.</p></div></div><div class="interaction-list">${recent.length ? recent.slice().reverse().map(interactionRow).join('') : '<div class="empty">لا يوجد تفاعل حتى الآن.</div>'}</div></article></section>`;
  }

  function ruleRow(rule) {
    const action = [rule.then?.reply || '', rule.then?.reaction || ''].filter(Boolean).join(' · ');
    const dayNames = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
    const schedule = rule.schedule?.enabled ? `وقت ${rule.schedule.start || '09:00'}–${rule.schedule.end || '17:00'} · ${(Array.isArray(rule.schedule.days) && rule.schedule.days.length ? rule.schedule.days.map(Number).map(day => dayNames[day]).filter(Boolean).join('، ') : 'لا توجد أيام')}` : 'دائمًا';
    return `<div class="rule-row"><div><b>${esc(rule.name || 'قاعدة')}</b><small>${esc(rule.when?.type || 'message')} · ${esc(rule.when?.match || '')} · ${esc(rule.when?.value || 'أي')} · ${esc(schedule)}</small><span>${esc(action || 'بدون إجراء')}</span></div><div class="row-actions"><button class="btn small" data-toggle-rule="${esc(rule.id)}">${rule.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-rule="${esc(rule.id)}">حذف</button></div></div>`;
  }

  function interactionRow(item) {
    const when = item.at ? new Date(item.at) : null;
    return `<div class="interaction-row"><div><b>${esc(item.ruleName || item.ruleId || 'قاعدة')}</b><span>${esc(item.status || '')}</span></div><small>${esc(item.chatId || '')} · ${when && !Number.isNaN(when.getTime()) ? esc(when.toLocaleString('ar-OM')) : ''}</small></div>`;
  }

  function pageSession(data) {
    const runtime = data.whatsapp || {};
    const status = runtime.ready ? 'متصل' : ({ qr:'بانتظار QR', recovering:'جارٍ إصلاح الاتصال وإعادة المحاولة', starting:'جارٍ الاتصال', authenticated:'تم التوثيق، جارٍ الإعداد', auth_failure:'فشل التوثيق', disconnected:'منقطع', error:'خطأ في الاتصال', stopped:'متوقف', stopping:'جارٍ الإيقاف' }[runtime.status] || runtime.status || 'غير متصل');
    return `<section class="page-title"><p class="eyebrow">الجلسة</p><h1>اتصال وإدارة الحساب</h1><p>كل جلسة مستقلة بحسابها وأهدافها وسجلها.</p></section><section class="content-grid two-col">
      <article class="panel"><div class="panel-head"><div><h2>اتصال WhatsApp</h2><p>اربط الحساب أو أوقفه في أي وقت.</p></div></div><div class="status-panel"><span>الحالة</span><b>${esc(status)}</b>${runtime.info?.wid?.user ? `<small>+${esc(runtime.info.wid.user)}</small>` : ''}${runtime.lastError ? `<small class="session-error-detail">آخر تفاصيل: ${esc(runtime.lastError)}</small>` : ''}${runtime.status === 'recovering' ? `<small class="session-recovery-detail">محاولة الاستعادة ${Number(runtime.navigationRetries || 0)} من 3. اترك الجلسة تعمل ولا تضغط الاتصال مرارًا.</small>` : ''}</div>${runtime.qr ? `<div class="qr-box"><p>امسح الرمز من WhatsApp.</p><img src="${esc(runtime.qr)}" class="session-qr" alt="QR"></div>` : ''}<div class="action-bar"><button class="btn primary" id="connectSessionBtn">ربط / تشغيل</button><button class="btn" id="stopSessionBtn">إيقاف</button><button class="btn danger" id="unlinkSessionBtn">فصل الحساب</button></div></article>
      <article class="panel"><div class="panel-head"><div><h2>إعداد الجلسة</h2><p>الاسم يتغير فقط في الجلسة الحالية.</p></div></div><label>اسم الجلسة<input id="sessionName" value="${esc(data.session?.name || '')}" placeholder="الجلسة الرئيسية"></label><div class="action-bar"><button class="btn primary" id="saveSessionBtn">حفظ الاسم</button><button class="btn" id="newSessionBtn">جلسة جديدة</button><button class="btn danger" id="deleteSessionBtn">حذف الجلسة</button></div><div class="info-grid"><div><span>الحساب</span><b>${esc(runtime.info?.wid?.user || 'غير معروف')}</b></div><div><span>الاسم</span><b>${esc(runtime.info?.pushname || 'غير معروف')}</b></div><div><span>المجموعات</span><b>${(data.groups || []).length}</b></div><div><span>الأشخاص</span><b>${(data.recipients || []).length}</b></div></div></article>
    </section><section class="panel"><div class="panel-head"><div><h2>سجل الجلسة</h2><p>هذا السجل يخص هذه الجلسة وحدها.</p></div><button class="btn small" id="sessionRefreshLog">تحديث</button></div><div class="log-list tall">${(data.logs || []).map(logRow).join('') || '<div class="empty">السجل فارغ.</div>'}</div></section>`;
  }

  const bgNames = { aurora: 'الشفق', nebula: 'السديم', meteor: 'النيزك', matrix: 'المصفوفة', 'cyber-grid': 'الشبكة', plasma: 'البلازما', starfield: 'النجوم', vortex: 'الدوامة', galaxy: 'المجرة', ocean: 'الموجة' };
  function pageAppearance(data) {
    const background = data.background || {};
    const cfg = background.settings || {};
    const a = data.settings?.appearance || {};
    const visiblePresets = [['mint','نعناعي'],['ocean','بحري'],['violet','بنفسجي'],['sunset','غروب']];
    return `<section class="page-title"><p class="eyebrow">المظهر</p><h1>المظهر والخلفيات</h1><p>غيّر اللون والخلفية بسهولة، والتخصيص الكامل موجود داخل الخيارات المتقدمة.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>لون الواجهة</h2><p>اختر لونًا جاهزًا أو لونك الخاص.</p></div></div>
          <div class="theme-preview"><span class="theme-dot" id="themeDot1"></span><div><b>chat BOT</b><small>لون واحد واضح للواجهة</small></div></div>
          <div class="preset-row">${visiblePresets.map(([id,label]) => `<button class="btn small" data-ui-preset="${id}">${label}</button>`).join('')}</div>
          <label>اللون الأساسي<input id="uiAccent" type="color" value="${esc(a.accent || '#5ed6c1')}"></label>
          <details class="advanced-panel"><summary>تفاصيل الواجهة</summary><div class="form-grid two"><label>لون مساعد<input id="uiAccent2" type="color" value="${esc(a.accent2 || '#8b7cf6')}"></label>${rangeControl('uiPanelOpacity','وضوح البطاقات',a.panelOpacity ?? .94,.78,.97,.01)}${rangeControl('uiPanelBlur','نعومة البطاقات',a.panelBlur ?? 0,0,12,1)}${rangeControl('uiRadius','استدارة العناصر',a.radius ?? 13,10,24,1)}${rangeControl('uiGlow','وهج اللون',a.glow ?? .28,0,.8,.05)}</div></details>
          <div class="action-bar"><button class="btn primary" id="saveUiThemeBtn">حفظ اللون</button><button class="btn" id="resetUiThemeBtn">إعادة الافتراضي</button></div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الخلفية</h2><p>خلفيات جميلة وخفيفة على الجهاز.</p></div></div>
          <div class="bg-picker">${Object.entries(bgNames).map(([id,name]) => `<button class="bg-choice ${background.mode === id ? 'selected' : ''}" data-bg-mode="${id}"><span class="bg-swatch bg-${id}"></span><b>${name}</b></button>`).join('')}</div>
          <div class="upload-box"><input id="customBackground" type="file" accept="image/png,image/jpeg,image/webp"><label for="customBackground"><span>＋</span> اختيار صورة</label><small>الصورة تحفظ لهذه الجلسة فقط.</small></div>
          ${background.imageUrl ? `<div class="custom-current"><img src="${esc(background.imageUrl)}" alt="الخلفية الحالية"><span>الخلفية الحالية</span></div><div class="action-bar"><button class="btn danger" id="removeCustomBackgroundBtn">إزالة الصورة</button></div>` : ''}
          <details class="advanced-panel"><summary>تخصيص الخلفية بالتفصيل</summary><div class="range-grid">${rangeControl('bgSpeed','السرعة',cfg.speed, .1,2,.05)}${rangeControl('bgDensity','الكثافة',cfg.density,.2,1.6,.05)}${rangeControl('bgGlow','التوهج',cfg.glow,0,1,.05)}${rangeControl('bgIntensity','القوة',cfg.intensity,.2,1.5,.05)}${rangeControl('bgMouse','تأثير المؤشر',cfg.mouseStrength,0,1.5,.05)}${rangeControl('bgBrightness','السطوع',cfg.brightness,.6,1.4,.05)}${rangeControl('bgContrast','التباين',cfg.contrast,.7,1.4,.05)}${rangeControl('bgSaturation','التشبع',cfg.saturation,.5,1.6,.05)}${rangeControl('bgHue','تغيير اللون',cfg.hueRotate,0,360,1)}${rangeControl('bgBlur','التمويه',cfg.blur,0,6,.25)}${rangeControl('bgOpacity','الشفافية',background.opacity ?? .22,.08,.60,.01)}</div><div class="toggle-list"><label class="toggle-row"><input id="bgInteractive" type="checkbox" ${cfg.interactive !== false ? 'checked' : ''}><span><b>التفاعل</b><small>استجابة بسيطة للمؤشر والنقر.</small></span></label><label class="toggle-row"><input id="bgTrail" type="checkbox" ${cfg.trail !== false ? 'checked' : ''}><span><b>أثر الحركة</b><small>يعطي نعومة إضافية.</small></span></label></div></details>
          <div class="action-bar"><button class="btn primary" id="saveBackgroundBtn">حفظ الخلفية</button><button class="btn" id="resetBackgroundBtn">إعادة الافتراضي</button></div>
        </article>
      </section>`;
  }

  function pageSettings(data) {
    const active = state.settingsView === 'operation' ? 'operation' : 'appearance';
    return `<section class="settings-shell">
      <div class="settings-switch" role="tablist" aria-label="أقسام الإعدادات">
        <button class="settings-tab ${active === 'appearance' ? 'active' : ''}" data-settings-view="appearance" role="tab" aria-selected="${active === 'appearance'}">المظهر والخلفيات</button>
        <button class="settings-tab ${active === 'operation' ? 'active' : ''}" data-settings-view="operation" role="tab" aria-selected="${active === 'operation'}">التشغيل المتقدم</button>
      </div>
      <div class="settings-content">${active === 'appearance' ? pageAppearance(data) : pageOperation(data)}</div>
    </section>`;
  }

  function rangeControl(id, label, value, min, max, step) {
    const safe = Number.isFinite(Number(value)) ? Number(value) : Number(min);
    return `<label class="range-item"><span>${esc(label)} <output id="${id}Out">${safe.toFixed(step < 1 ? 2 : 0)}</output></span><input id="${id}" type="range" min="${min}" max="${max}" step="${step}" value="${safe}"></label>`;
  }

  function pageOperation(data) {
    const settings = data.settings || {};
    return `<section class="page-title"><p class="eyebrow">التشغيل</p><h1>إعدادات التشغيل</h1><p>الإعدادات الأساسية ظاهرة، والتفاصيل الإضافية داخل أقسام واضحة.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>الأساسيات</h2><p>هذه أهم الخيارات للاستخدام اليومي.</p></div></div>
          <div class="form-grid two"><label>المنطقة الزمنية<input id="opTimezone" value="${esc(settings.timezone || 'Asia/Muscat')}" placeholder="Asia/Muscat"></label><label>ترتيب الإرسال<select id="opSendOrder"><option value="target-first" ${settings.sendOrder === 'target-first' ? 'selected' : ''}>هدف ثم ملفاته</option><option value="image-first" ${settings.sendOrder === 'image-first' ? 'selected' : ''}>ملف ثم الأهداف</option></select></label></div>
          <div class="toggle-list"><label class="toggle-row"><input id="opAutoStart" type="checkbox" ${settings.autoStartSession !== false ? 'checked' : ''}><span><b>تشغيل الجلسة تلقائيًا</b><small>استعادة الحساب المحفوظ عند بدء البوت.</small></span></label><label class="toggle-row"><input id="opAutomation" type="checkbox" ${settings.automationEnabled !== false ? 'checked' : ''}><span><b>التشغيل التلقائي</b><small>تشغيل المواعيد المحفوظة لهذه الجلسة.</small></span></label></div>
          <div class="action-bar"><button class="btn primary" id="saveOperationMain">حفظ</button></div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الخصوصية والتشغيل</h2><p>المعلومات التي تحتاجها فقط.</p></div></div><div class="privacy-box"><p>المشروع يعمل محليًا وتبقى بيانات الجلسات والوسائط والسجل على الجهاز.</p><p>التشغيل المعتاد عبر <code>run.py</code> والمنفذ 7005.</p></div><div class="action-bar"><button class="btn" data-go="session">إدارة الجلسة</button><button class="btn" data-go="dashboard">الرئيسية</button></div></article>
      </section>
      <section class="content-grid two-col"><article class="panel command-trigger-panel"><div class="panel-head"><div><h2>أوامر المحادثة</h2><p>تحكّم في كلمات تشغيل الأوامر وصيغها المرنة.</p></div></div><div class="toggle-list"><label class="toggle-row"><input id="opCommandTriggerEnabled" type="checkbox" ${settings.commandTriggerEnabled !== false ? 'checked' : ''}><span><b>تفعيل كلمات التشغيل</b><small>أزل الكلمة من بداية الأمر قبل تفسيره.</small></span></label><label class="toggle-row"><input id="opCommandTriggerRequired" type="checkbox" ${settings.commandTriggerRequired === true ? 'checked' : ''}><span><b>اشتراط كلمة التشغيل</b><small>عند التفعيل، لن ينفذ الأمر إلا إذا احتوى إحدى الكلمات أدناه.</small></span></label></div><label>كلمات التشغيل (افصل بينها بفاصلة)<textarea id="opCommandTriggerWords" rows="2" maxlength="650" placeholder="يا بوت، شات بوت، chat bot">${esc((Array.isArray(settings.commandTriggerWords) ? settings.commandTriggerWords : ['يا بوت','شات بوت','chat bot']).join('، '))}</textarea></label><p class="muted">يمكنك كتابة: «يا بوت ورّيني الأشخاص»، «ممكن تعرضلي المواعيد»، أو «ابعت رسالة لأحمد: أهلًا». الوضع الافتراضي لا يشترط كلمة التشغيل، ويمكنك تشغيل الاشتراط من هنا.</p><div class="action-bar"><button class="btn primary" id="saveCommandTriggers">حفظ إعدادات الأوامر</button></div></article><article class="panel"><div class="panel-head"><div><h2>الموثوقية</h2><p>خيارات متقدمة، لا تحتاج تغييرها غالبًا.</p></div></div><details class="advanced-panel"><summary>فتح إعدادات الموثوقية</summary><div class="form-grid two"><label>التأخير بين الإرسال (مللي ثانية)<input id="opDelay" type="number" min="0" max="60000" value="${Number(settings.sendDelayMs || 700)}"></label><label>مهلة الإرسال (مللي ثانية)<input id="opTimeout" type="number" min="5000" max="180000" value="${Number(settings.sendTimeoutMs || 30000)}"></label><label>عدد المحاولات<input id="opRetryAttempts" type="number" min="1" max="4" value="${Number(settings.retryAttempts || 2)}"></label><label>التأخير بين المحاولات (مللي ثانية)<input id="opRetryDelay" type="number" min="250" max="120000" value="${Number(settings.retryDelayMs || 1600)}"></label><label>أقصى حجم للملف MB<input id="opMaxSize" type="number" min="1" max="250" value="${Number(settings.maxImageSizeMB || 20)}"></label></div><div class="action-bar"><button class="btn primary" id="saveOperationReliability">حفظ</button></div></details></article>
        <article class="panel"><div class="panel-head"><div><h2>فترة هدوء التفاعل</h2><p>أوقف الردود التلقائية خلال وقت تحدده.</p></div></div><details class="advanced-panel"><summary>إعداد وقت الهدوء</summary><div class="form-grid three"><label class="toggle-box"><input id="opQuietEnabled" type="checkbox" ${settings.interactionQuietEnabled ? 'checked' : ''}><span>تفعيل</span></label><label>من<input id="opQuietStart" type="time" value="${esc(settings.interactionQuietStart || '23:00')}"></label><label>إلى<input id="opQuietEnd" type="time" value="${esc(settings.interactionQuietEnd || '07:00')}"></label><label>السلوك<select id="opQuietAction"><option value="silence" ${(settings.interactionQuietAction || 'silence') === 'silence' ? 'selected' : ''}>لا يرد</option><option value="reply" ${settings.interactionQuietAction === 'reply' ? 'selected' : ''}>رد مخصص</option><option value="rules" ${settings.interactionQuietAction === 'rules' ? 'selected' : ''}>تطبيق القواعد</option></select></label><label>نص الرد<textarea id="opQuietReply" rows="3" maxlength="60000">${esc(settings.interactionQuietReply || 'أنا في فترة الهدوء الآن، سأرد عليك لاحقًا.')}</textarea></label><label>فاصل الرد (ثانية)<input id="opQuietCooldownSec" type="number" min="30" max="86400" value="${Number(settings.interactionQuietCooldownSec || 300)}"></label></div><div class="action-bar"><button class="btn primary" id="saveOperationQuiet">حفظ</button></div></details></article></section>`;
  }

  function render() {
    const data = state.data || { session: {}, sessions: [], whatsapp: {} };
    let content = pageDashboard(data);
    if (state.page === 'send') content = pageSend(data);
    else if (state.page === 'assistant') content = pageAssistant(data);
    else if (state.page === 'owner-center') content = pageOwnerCenter(data);
    else if (state.page === 'people') content = pagePeople(data);
    else if (state.page === 'groups') content = pageGroups(data);
    else if (state.page === 'interaction') content = pageInteraction(data);
    else if (state.page === 'session') content = pageSession(data);
    else if (state.page === 'settings') content = pageSettings(data);
    else if (state.page === 'appearance') { state.page = 'settings'; state.settingsView = 'appearance'; content = pageSettings(data); }
    else if (state.page === 'operation') { state.page = 'settings'; state.settingsView = 'operation'; content = pageSettings(data); }
    applyInterfaceTheme(data);
    $('#app').innerHTML = shell(content);
    setupBackground();
    bindCommon();
    bindPage();
  }

  function bindCommon() {
    $$('.navbtn').forEach((button) => { button.onclick = () => go(button.dataset.page); });
    $$('[data-go]').forEach((button) => { button.onclick = () => go(button.dataset.go); });
    $('#refreshBtn')?.addEventListener('click', () => load(true).catch((e) => notify(e.message, 'error')));
    $('#modeToggleBtn')?.addEventListener('click', () => setLocalUiMode('toggle'));
    $('#assistantRobotButton')?.addEventListener('click', () => go('owner-center'));
    $('#assistantSpeechClose')?.addEventListener('click', () => clearCompanionNotice(true));
    $('#assistantSpeechOpen')?.addEventListener('click', () => {
      const notice = state.companionNotice;
      if (notice?.type === 'error' || notice?.type === 'warning') go('owner-center');
      else go('owner-center');
    });
    $('#ownerActivityRefresh')?.addEventListener('click', async () => { try { await load(true); notify('تم تحديث سجل المساعد.', 'success'); } catch (error) { notify(error.message, 'error'); } });
    $('#ownerActivityList')?.addEventListener('click', event => {
      const button = event.target.closest('[data-activity-open]'); if (!button) return;
      const issueId = button.dataset.activityIssue; const page = button.dataset.activityPage || 'dashboard';
      if (issueId) { go('owner-center'); setTimeout(() => document.querySelector(`[data-owner-open-issue="${CSS.escape(issueId)}"]`)?.closest('.owner-issue')?.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'center' }), 80); }
      else go(page);
    });
    $('#dashboardRefresh')?.addEventListener('click', () => load(true).catch((e) => notify(e.message, 'error')));
    $('#sessionRefreshLog')?.addEventListener('click', () => load(true).catch((e) => notify(e.message, 'error')));
    $('#sessionSelect')?.addEventListener('change', async (event) => {
      try {
        await api('/api/sessions/switch', { method: 'POST', body: JSON.stringify({ sessionId: event.target.value }) });
        state.pendingTargets = [];
        state.selectedGroup = null;
        state.selectedGroupIds.clear();
        state.selectedMedia = null;
        state.groupMemberFilter = '';
        state.groupMemberLimit = 100;
        await load(true);
      } catch (error) { notify(error.message, 'error'); }
    });
  }

  async function bindPage() {
    if (state.page === 'assistant') bindLocalAssistant();
    if (state.page === 'owner-center') bindOwnerCenter();
    if (state.page === 'send') bindSend();
    if (state.page === 'people') bindPeople();
    if (state.page === 'groups') bindGroups();
    if (state.page === 'interaction') bindInteraction();
    if (state.page === 'session') bindSession();
    if (state.page === 'appearance') bindAppearance();
    if (state.page === 'settings') {
      bindSettings();
      if (state.settingsView === 'operation') bindOperation(); else bindAppearance();
    }
  }

  function currentTargetKeys() {
    return $$('.target:checked').map((input) => input.value);
  }

  function selectedMediaIds() {
    return $$('.send-media:checked').map((input) => input.value);
  }

  async function bindSend() {
    await loadCountries().then(() => {
      const country = $('#recipientCountry');
      if (country) country.innerHTML = countryOptions(country.value || 'OM');
    }).catch(() => {});
    $$('.target').forEach((checkbox) => checkbox.addEventListener('change', () => { state.pendingTargets = currentTargetKeys(); }));
    $('#selectAllTargets')?.addEventListener('click', () => { $$('.target').forEach((input) => { input.checked = !input.disabled; }); state.pendingTargets = currentTargetKeys(); });
    $('#clearTargets')?.addEventListener('click', () => { $$('.target').forEach((input) => { input.checked = false; }); state.pendingTargets = []; });
    $('#sendText')?.addEventListener('input', (event) => { state.assistantDraft = event.target.value; });
    $('#mediaFiles')?.addEventListener('change', uploadMediaFiles);
    const dropZone = $('#mediaDropZone');
    for (const name of ['dragenter','dragover']) dropZone?.addEventListener(name, event => { event.preventDefault(); event.stopPropagation(); dropZone.classList.add('drag-active'); });
    for (const name of ['dragleave','dragend']) dropZone?.addEventListener(name, event => { event.preventDefault(); event.stopPropagation(); if (!dropZone.contains(event.relatedTarget)) dropZone.classList.remove('drag-active'); });
    dropZone?.addEventListener('drop', event => { event.preventDefault(); event.stopPropagation(); dropZone.classList.remove('drag-active'); uploadFiles([...event.dataTransfer.files]); });
    dropZone?.addEventListener('keydown', event => { if (event.target === dropZone && ['Enter',' '].includes(event.key)) { event.preventDefault(); $('#mediaFiles')?.click(); } });
    $$('.send-media').forEach(input => input.addEventListener('change', () => {
      if (state.selectedMedia === null) state.selectedMedia = new Set(selectedMediaIds());
      if (input.checked) state.selectedMedia.add(input.value); else state.selectedMedia.delete(input.value);
      updateMediaCount();
    }));
    $$('[data-deselect-media]').forEach(button => button.addEventListener('click', () => {
      const id = button.dataset.deselectMedia;
      if (state.selectedMedia === null) state.selectedMedia = new Set(selectedMediaIds());
      state.selectedMedia.delete(id);
      const input = $$('.send-media').find(item => item.value === id); if (input) input.checked = false;
      updateMediaCount(); notify('تمت إزالة الملف من قائمة الإرسال فقط؛ ما زال محفوظًا في المكتبة.', 'success');
    }));
    $$('[data-delete-media]').forEach((button) => button.addEventListener('click', async (event) => {
      event.preventDefault();
      if (!confirm('سيُحذف الملف من مكتبة هذه الجلسة، وقد يُزال من المواعيد التي تستخدمه. هل تريد المتابعة؟')) return;
      try { await api(`/api/media/${encodeURIComponent(button.dataset.deleteMedia)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); state.selectedMedia?.delete(button.dataset.deleteMedia); await load(true); } catch (error) { notify(error.message, 'error'); }
    }));
    $('#selectAllMedia')?.addEventListener('click', () => { state.selectedMedia = new Set((state.data?.media || []).map(x => x.id || x.filename)); $$('.send-media').forEach(input => { input.checked = true; }); updateMediaCount(); });
    $('#clearMediaSelection')?.addEventListener('click', () => { state.selectedMedia = new Set(); $$('.send-media').forEach(input => { input.checked = false; }); updateMediaCount(); });
    $('#clearSendText')?.addEventListener('click', () => { ['sendText','sendPreText','sendPostText'].forEach(id => { if ($('#'+id)) $('#'+id).value = ''; }); state.assistantDraft = ''; notify('تم مسح نصوص الإرسال.', 'success'); });
    $('#sendNowBtn')?.addEventListener('click', sendNow);
    loadTextPreviews(); updateMediaCount(); bindSchedule();
  }

  function updateMediaCount() {
    const count = selectedMediaIds().length, selected = $('#sendMediaCount');
    if (selected) selected.textContent = `${count} محدد للإرسال`;
  }

  async function uploadMediaFiles(event) { await uploadFiles([...(event.target.files || [])]); event.target.value = ''; }

  async function uploadFiles(files) {
    if (!files.length) return;
    const form = new FormData(); files.forEach(file => form.append('files', file, file.name));
    form.append('sessionId', sid()); form.append('replaceDuplicates', $('#replaceDuplicates')?.checked ? 'true' : 'false');
    const status = $('#uploadStatus'); if (status) status.textContent = `جارٍ رفع ${files.length} ملف…`;
    const input = $('#mediaFiles'); if (input) input.disabled = true;
    try {
      const result = await api('/api/media', { method:'POST', body:form });
      if (state.selectedMedia === null) state.selectedMedia = new Set(selectedMediaIds());
      for (const id of result.saved || []) state.selectedMedia.add(id);
      const messages = [result.message || `تم رفع ${result.saved?.length || 0} ملف`, result.rejected?.length ? `مرفوض: ${result.rejected.map(x => `${x.filename}: ${x.error}`).join('؛ ')}` : '', result.duplicates?.length ? `مكرر: ${result.duplicates.map(x => x.incoming).join('، ')}` : ''].filter(Boolean);
      if (status) status.textContent = messages.join(' · '); notify(result.message || `تم رفع ${result.saved?.length || 0} ملف`, result.rejected?.length ? 'info' : 'success'); await load(true);
    } catch (error) { if (status) status.textContent = error.message; notify(error.message, 'error'); }
    finally { if (input) input.disabled = false; }
  }

  async function loadTextPreviews() {
    for (const host of $$('[data-text-preview]')) {
      const id = host.dataset.textPreview;
      try { const data = await api(`/api/media/${encodeURIComponent(id)}/preview?sessionId=${encodeURIComponent(sid())}`); host.textContent = data.preview || 'لا يوجد نص للمعاينة.'; }
      catch { host.textContent = 'تعذرت معاينة النص.'; }
    }
  }

  async function sendNow() {
    const targets = currentTargetKeys(), mediaIds = selectedMediaIds(), text = $('#sendText')?.value || '';
    const selectedFiles = (state.data?.media || []).filter(file => mediaIds.includes(String(file.id || file.filename)));
    const sendAsDocument = Boolean($('#sendAsDocument')?.checked);
    const captionAllowed = Boolean($('#captionMode')?.checked && selectedFiles.length && selectedFiles.every(file => file.isImage) && !sendAsDocument);
    const chosenPlacement = $('#sendTextPlacement')?.value || 'auto';
    let textMode = chosenPlacement === 'auto' ? (captionAllowed ? 'caption' : 'before') : chosenPlacement;
    if (!mediaIds.length && textMode === 'caption') textMode = 'before';
    const explicitPre = $('#sendPreText')?.value?.trim() || '', explicitPost = $('#sendPostText')?.value?.trim() || '';
    const includeDefault = Boolean($('#includeDefaultText')?.checked), defaultText = includeDefault ? ($('#defaultPreText')?.value?.trim() || '') : '';
    const preText = [explicitPre, defaultText].filter(Boolean).join('\n\n');
    const postText = explicitPost;
    if (!targets.length) return notify('حدد شخصًا أو مجموعة واحدة على الأقل.', 'error');
    if (!text.trim() && !preText.trim() && !postText.trim() && !mediaIds.length) return notify('اكتب رسالة أو اختر ملفًا.', 'error');
    const placementLabel = textMode === 'caption' ? 'تعليق للصورة' : textMode === 'before' ? 'رسالة مستقلة قبل الملفات' : textMode === 'after' ? 'رسالة مستقلة بعد الملفات' : 'النص الرئيسي لن يُرسل';
    if (!confirm(`الأهداف: ${targets.length}\nالملفات: ${mediaIds.length}\nطريقة النص الرئيسي: ${placementLabel}\n${sendAsDocument ? 'سيتم إرسال الصور كمرفقات.' : ''}\nهل تريد المتابعة؟`)) return;
    const sendButton = $('#sendNowBtn'); if (sendButton) { sendButton.disabled = true; sendButton.textContent = 'جارٍ الإرسال…'; }
    try {
      const result = await api('/api/send', { method:'POST', body: JSON.stringify({
        sessionId:sid(), targetKeys:targets, text, preText, postText,
        caption: textMode === 'caption' ? text.trim() : '', captionMode:textMode === 'caption', textMode, sendAsDocument,
        sendDelayMs:Math.max(0,Math.min(60000,Number($('#sendDelayOverride')?.value ?? 700))),
        mediaIds, sendOrder:$('#sendOrder')?.value || 'target-first', repeatGuard:$('#repeatGuard')?.value !== 'off'
      }) });
      const failed = Array.isArray(result.failed) ? result.failed : [], sent = Array.isArray(result.sent) ? result.sent : [];
      const confirmed = sent.filter(item => item.status === 'confirmed').length;
      const created = sent.length - confirmed;
      if (failed.length) {
        const details = failed.slice(0,5).map(item => `${item.target || 'هدف'}${item.image ? ` / ${item.image}` : ''}: ${item.error || 'تعذر الإرسال'}`).join('؛ ');
        notify(`مؤكد من WhatsApp: ${confirmed}، أُنشئ دون تأكيد تسليم نهائي: ${created}، تعذر: ${failed.length}. ${details}`, 'info');
      } else if (created) notify(`تم بدء ${created} عملية دون وصول تأكيد تسليم نهائي حتى الآن، وتأكد ${confirmed}.`, 'info');
      else notify(`أكد WhatsApp إرسال ${confirmed} عملية بنجاح${result.captions ? `، مع ${result.captions} تعليق صورة` : ''}.`, 'success');
      state.pendingTargets = []; await load(true);
    } catch (error) { notify(error.message, 'error'); }
    finally { if (sendButton) { sendButton.disabled = false; sendButton.textContent = 'إرسال الآن'; } }
  }

  function bindSchedule() {
    const workspace = $('.task-workspace');
    workspace?.addEventListener('toggle', () => { state.scheduleOpen = workspace.open; });
    const updateScheduleModeFields = () => {
      const value = $('#scheduleMode')?.value || 'once';
      $('.schedule-date')?.toggleAttribute('hidden', value !== 'once');
      $('.schedule-day')?.toggleAttribute('hidden', value !== 'weekly');
      $('.schedule-dom')?.toggleAttribute('hidden', !['monthly', 'yearly'].includes(value));
      $('.schedule-month')?.toggleAttribute('hidden', value !== 'yearly');
    };
    $('#scheduleMode')?.addEventListener('change', updateScheduleModeFields);
    updateScheduleModeFields();
    $$('[data-delete-task]').forEach((button) => button.addEventListener('click', async () => {
      try { await api(`/api/automation/task/${encodeURIComponent(button.dataset.deleteTask)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); }
    }));
    $$('[data-toggle-task]').forEach((button) => button.addEventListener('click', async () => {
      try { await api(`/api/automation/task/${encodeURIComponent(button.dataset.toggleTask)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); }
    }));
    $$('[data-run-task]').forEach((button) => button.addEventListener('click', async () => {
      try { const result = await api(`/api/automation/task/${encodeURIComponent(button.dataset.runTask)}/run`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم التشغيل.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    }));
    $$('[data-edit-task]').forEach((button) => button.addEventListener('click', () => loadTaskIntoEditor(button.dataset.editTask)));
    $('#scheduleBtn')?.addEventListener('click', createOrUpdateTask);
    $('#scheduleResetBtn')?.addEventListener('click', resetScheduleEditor);
  }

  async function loadTaskIntoEditor(taskId) {
    const task = (state.data?.automation?.tasks || []).find((item) => item.id === taskId);
    if (!task) return notify('الموعد غير موجود.', 'error');
    $('#scheduleName').value = task.name || '';
    $('#scheduleTime').value = task.time || '17:30';
    $('#scheduleMode').value = task.mode || 'weekly';
    $('#scheduleDate').value = task.date || '';
    $('#scheduleDay').value = String(task.day ?? 5);
    $('#scheduleDayOfMonth').value = String(task.dayOfMonth ?? 1);
    $('#scheduleMonth').value = String(task.month || 1);
    $('#scheduleText').value = task.text ?? '';
    $('#schedulePreText').value = task.preText || '';
    $('#schedulePostText').value = task.postText || '';
    $('#scheduleTextPlacement').value = task.textMode || (task.text ? 'auto' : 'before');
    $('#scheduleCaptionMode').checked = task.captionMode !== false;
    $('#scheduleSendAsDocument').checked = task.sendAsDocument === true;
    $('#scheduleSendDelay').value = String(task.sendDelayMs ?? 700);
    $('#scheduleGraceMinutes').value = String(task.graceMinutes || 30);
    $('#scheduleMediaMode').value = task.mediaMode || 'selected';
    $('#scheduleGroupsEnabled').checked = task.scheduledGroupsEnabled !== false;
    state.editingTaskId = task.id;
    state.scheduleOpen = true;
    state.pendingTargets = Array.isArray(task.targetKeys) ? [...task.targetKeys] : [];
    $$('.target').forEach((input) => { input.checked = state.pendingTargets.includes(input.value); });
    $$('.send-media').forEach((input) => { input.checked = (task.mediaIds || []).includes(input.value); });
    notify('تم تحميل الموعد للتعديل. عدّل ثم اضغط حفظ.', 'info');
  }

  async function createOrUpdateTask() {
    const targets = currentTargetKeys();
    const mode = $('#scheduleMode').value;
    const mediaMode = $('#scheduleMediaMode').value;
    const mediaIds = mediaMode === 'cycle' ? [] : selectedMediaIds();
    const mainText = $('#scheduleText').value.trim() || (state.editingTaskId ? '' : ($('#sendText')?.value.trim() || ''));
    const textMode = $('#scheduleTextPlacement').value || 'auto';
    const preText = $('#schedulePreText').value.trim();
    const postText = $('#schedulePostText').value.trim();
    const usableMainText = mainText && textMode !== 'none';
    if (!targets.length) return notify('حدد أهداف الموعد من قائمة الأشخاص والمجموعات أعلى الصفحة.', 'error');
    if (!usableMainText && !preText && !postText && !mediaIds.length && mediaMode !== 'cycle') return notify('أضف رسالة فعّالة أو ملفًا للموعد.', 'error');
    if (mode === 'once' && !$('#scheduleDate').value) return notify('حدد تاريخ تنفيذ الموعد.', 'error');
    if (mediaMode === 'cycle' && !(state.data?.media || []).some(file => file.isImage)) return notify('دورة الصور تحتاج صورة واحدة على الأقل في المكتبة.', 'error');
    const captionMode = $('#scheduleCaptionMode').checked;
    const effectiveTextMode = !captionMode && ['auto', 'caption'].includes(textMode) ? 'before' : textMode;
    const payload = {
      sessionId: sid(), name: $('#scheduleName').value.trim() || 'موعد جديد', mode, time: $('#scheduleTime').value,
      date: $('#scheduleDate').value, day: Number($('#scheduleDay').value), dayOfMonth: Number($('#scheduleDayOfMonth').value), month: Number($('#scheduleMonth').value),
      targetKeys: [...new Set(targets)], mediaIds, mediaMode, text: mainText, textMode: effectiveTextMode,
      captionMode, sendAsDocument: $('#scheduleSendAsDocument').checked,
      sendDelayMs: Math.max(0, Math.min(60000, Number($('#scheduleSendDelay').value || 0))),
      graceMinutes: Number($('#scheduleGraceMinutes').value || 30), preText, postText,
      sendOrder: $('#sendOrder')?.value || 'target-first', scheduledGroupsEnabled: $('#scheduleGroupsEnabled').checked
    };
    const button = $('#scheduleBtn'); if (button) { button.disabled = true; button.dataset.label = button.textContent; button.textContent = 'جارٍ حفظ الموعد…'; }
    try {
      const url = state.editingTaskId ? `/api/automation/task/${encodeURIComponent(state.editingTaskId)}` : '/api/automation/task';
      const method = state.editingTaskId ? 'PUT' : 'POST';
      const result = await api(url, { method, body: JSON.stringify(payload) });
      state.editingTaskId = null;
      state.scheduleOpen = true;
      resetScheduleEditor();
      notify(result.message || 'تم حفظ الموعد والرسالة والأهداف والملفات المحددة.', 'success');
      await load(true);
    } catch (error) { notify(error.message, 'error'); }
    finally { if (button) { button.disabled = false; button.textContent = button.dataset.label || 'حفظ الموعد'; delete button.dataset.label; } }
  }

  function resetScheduleEditor() {
    state.editingTaskId = null;
    ['scheduleName','scheduleDate','scheduleText','schedulePreText','schedulePostText'].forEach(id => { const el = $('#' + id); if (el) el.value = ''; });
    if ($('#scheduleTime')) $('#scheduleTime').value = '17:30';
    if ($('#scheduleMode')) $('#scheduleMode').value = 'once';
    if ($('#scheduleDay')) $('#scheduleDay').value = '5';
    if ($('#scheduleDayOfMonth')) $('#scheduleDayOfMonth').value = '1';
    if ($('#scheduleMonth')) $('#scheduleMonth').value = '1';
    if ($('#scheduleMediaMode')) $('#scheduleMediaMode').value = 'selected';
    if ($('#scheduleGraceMinutes')) $('#scheduleGraceMinutes').value = '30';
    if ($('#scheduleTextPlacement')) $('#scheduleTextPlacement').value = 'auto';
    if ($('#scheduleCaptionMode')) $('#scheduleCaptionMode').checked = true;
    if ($('#scheduleSendAsDocument')) $('#scheduleSendAsDocument').checked = false;
    if ($('#scheduleSendDelay')) $('#scheduleSendDelay').value = String(state.data?.settings?.sendDelayMs ?? 700);
    if ($('#scheduleGroupsEnabled')) $('#scheduleGroupsEnabled').checked = true;
    const button = $('#scheduleBtn'); if (button) button.textContent = 'حفظ الموعد';
    $('.schedule-date')?.toggleAttribute('hidden', false);
    $('.schedule-day')?.toggleAttribute('hidden', true);
    $('.schedule-dom')?.toggleAttribute('hidden', true);
    $('.schedule-month')?.toggleAttribute('hidden', true);
  }

  function bindPeopleSearch() {}
  function bindGroupSearch() {}

  function watchRecipientProfile(recipientId, sessionId = sid(), attempt = 0) {
    const key = `${sessionId}|${recipientId}`;
    if (!state.profileRefreshIds || !(state.profileRefreshIds instanceof Set)) state.profileRefreshIds = new Set();
    if (state.profileRefreshIds.has(key)) return;
    state.profileRefreshIds.add(key);
    const poll = async currentAttempt => {
      if (currentAttempt > 45 || sid() !== sessionId) { state.profileRefreshIds.delete(key); return; }
      try {
        const status = await api(`/api/recipient/${encodeURIComponent(recipientId)}/profile-status?sessionId=${encodeURIComponent(sessionId)}`);
        if (!status.busy && status.profileCheckedAt) {
          const fresh = await api(`/api/state?sessionId=${encodeURIComponent(sessionId)}`);
          state.data = fresh;
          if (state.page === 'people' && sid() === sessionId) render();
          if (status.profileError) notify(`تعذر جلب بيانات WhatsApp لهذا الشخص: ${status.profileError}`, 'info');
          state.profileRefreshIds.delete(key);
          return;
        }
      } catch {}
      setTimeout(() => poll(currentAttempt + 1), 1200);
    };
    setTimeout(() => poll(attempt + 1), 700);
  }

  async function applyContactSync(syncAll = false) {
    const preview = state.contactSyncPreview;
    if (!preview?.changes?.length) return notify('افحص بيانات WhatsApp أولًا.', 'error');
    const selected = preview.changes.filter(item => item.changed && !item.error && (syncAll || item.selected));
    if (!selected.length) return notify('حدد اختلافًا واحدًا على الأقل للمزامنة.', 'error');
    const message = syncAll ? `ستتم مزامنة ${selected.length} جهة اتصال مختلفة.` : `ستتم مزامنة ${selected.length} جهة الاتصال محددة.`;
    if (!confirm(`${message} لن تتغير الأسماء والصور المحلية المخصصة داخل المشروع. متابعة؟`)) return;
    try {
      const result = await api('/api/recipients/sync-apply', { method: 'POST', body: JSON.stringify({ updates: selected.map(item => ({ id: item.id, profile: item.profile })) }) });
      state.contactSyncPreview = null;
      await load(true);
      notify(result.message || `تمت مزامنة ${result.applied?.length || 0} جهة اتصال.`, 'success');
    } catch (error) { notify(error.message, 'error'); }
  }

  function bindPeople() {
    $('#selectVisiblePeople')?.addEventListener('click', () => {
      const filter = state.peopleFilter.trim().toLocaleLowerCase('ar');
      (state.data?.recipients || []).filter(item => `${item.displayName || item.name || ''} ${item.international || ''} ${item.e164 || ''} ${item.whatsappName || ''}`.toLocaleLowerCase('ar').includes(filter)).forEach(item => state.selectedRecipientIds.add(item.id));
      render();
    });
    $('#clearSelectedPeople')?.addEventListener('click', () => { state.selectedRecipientIds.clear(); render(); });
    $('#deleteSelectedPeople')?.addEventListener('click', async () => {
      const ids = [...state.selectedRecipientIds]; if (!ids.length) return notify('حدد أشخاصًا للحذف أولًا.', 'info');
      if (!confirm(`حذف ${ids.length} شخص من قائمة الإرسال؟ سيؤثر ذلك أيضًا على أهداف الجداول المرتبطة بهم.`)) return;
      const button = $('#deleteSelectedPeople'); if (button) button.disabled = true;
      try { const result = await api('/api/recipients/bulk-delete', { method: 'POST', body: JSON.stringify({ sessionId: sid(), ids }) }); state.selectedRecipientIds.clear(); notify(result.message || `تم حذف ${result.removed || ids.length} شخص.`, 'success'); await load(true); }
      catch (error) { notify(error.message, 'error'); if (button) button.disabled = false; }
    });
    loadCountries().then(() => {
      const country = $('#recipientCountry');
      if (country) country.innerHTML = countryOptions(country.value || 'OM');
    }).catch(() => {});
    $('#recipientPhone')?.addEventListener('blur', async () => {
      const value = $('#recipientPhone').value.trim();
      if (!value) return;
      try { const result = await api('/api/phone/validate', { method: 'POST', body: JSON.stringify({ phone: value, country: $('#recipientCountry').value }) }); $('#phonePreview').textContent = `سيُحفظ كـ ${result.phone?.international || result.phone?.e164 || 'رقم صالح'}`; } catch (error) { $('#phonePreview').textContent = error.message; }
    });
    $('#addRecipientBtn')?.addEventListener('click', async () => {
      try {
        const result = await api('/api/recipient', { method: 'POST', body: JSON.stringify({ sessionId: sid(), name: $('#recipientName').value.trim(), phone: $('#recipientPhone').value, country: $('#recipientCountry').value }) });
        notify(`تمت إضافة ${result.recipient?.displayName || result.recipient?.name || 'الشخص'} إلى القائمة.`, 'success');
        await load(true);
        if (state.data?.whatsapp?.ready) watchRecipientProfile(result.recipient.id);
      } catch (error) { notify(error.message, 'error'); }
    });
    $('#bulkAddBtn')?.addEventListener('click', async () => {
      try {
        const result = await api('/api/recipients/bulk', { method: 'POST', body: JSON.stringify({ sessionId: sid(), lines: $('#bulkRecipients').value, country: $('#recipientCountry').value }) });
        notify(`أضيف ${result.added?.length || 0} رقم${result.failed?.length ? `، وتعذر ${result.failed.length}` : ''}`, result.failed?.length ? 'info' : 'success');
        await load(true);
        if (state.data?.whatsapp?.ready) (result.added || []).slice(0, 100).forEach(person => watchRecipientProfile(person.id));
      } catch (error) { notify(error.message, 'error'); }
    });
    $('#peopleSearch')?.addEventListener('input', (event) => {
      state.peopleFilter = event.target.value;
      clearTimeout(bindPeopleSearch.timer);
      bindPeopleSearch.timer = setTimeout(() => {
        const list = $('.people-list');
        if (list) {
          const filter = state.peopleFilter.trim().toLocaleLowerCase('ar');
          const rows = (state.data?.recipients || []).filter(item => `${item.displayName || item.name || ''} ${item.international || ''} ${item.e164 || ''} ${item.whatsappName || ''}`.toLocaleLowerCase('ar').includes(filter));
          list.innerHTML = rows.length ? rows.map(personRow).join('') : '<div class="empty">لا توجد نتائج.</div>';
          bindPeopleRows();
        }
      }, 120);
    });
    $('#loadWhatsappContacts')?.addEventListener('click', async buttonEvent => {
      const button = buttonEvent.currentTarget; button.disabled = true; button.textContent = 'جاري التحميل…';
      try {
        const result = await api('/api/whatsapp/contacts');
        state.whatsappContacts = (result.contacts || []).map(contact => ({ ...contact, profileHydrated: Boolean(contact.whatsappName || contact.profileStatus === 'available' || contact.profileStatus === 'none') }));
        state.whatsappContactFilter = '';
        state.whatsappProfileHydrationProgress = { done: 0, total: Math.min(250, state.whatsappContacts.length), failed: 0 };
        render();
        notify(`تم استلام ${state.whatsappContacts.length} جهة من WhatsApp. جارٍ التحقق من الاسم والصورة على دفعات.`, 'success');
        hydrateWhatsAppContactProfiles(sid(), { force: false, limit: 250 }).catch(error => notify(`تعذر إكمال جلب صور WhatsApp: ${error.message}`, 'error'));
      } catch (error) { notify(error.message, 'error'); }
      finally { const next = $('#loadWhatsappContacts'); if (next) { next.disabled = !state.data?.whatsapp?.ready; next.textContent = 'اختيار من WhatsApp'; } }
    });
    $('#scanContactSync')?.addEventListener('click', async event => {
      const button = event.currentTarget; button.disabled = true; button.textContent = 'جارٍ فحص الأسماء والصور…';
      try {
        const result = await api('/api/recipients/sync-preview', { method: 'POST', body: JSON.stringify({ ids: [] }) });
        state.contactSyncPreview = { ...result, changes: (result.changes || []).map(item => ({ ...item, selected: item.changed && !item.error })) };
        render();
        notify(result.changed ? `تم العثور على ${result.changed} اختلاف يحتاج المراجعة.` : result.failed ? `انتهى الفحص؛ تعذّر فحص ${result.failed} جهة.` : 'الأسماء والصور متزامنة بالفعل.', result.failed ? 'info' : 'success');
      } catch (error) { notify(error.message, 'error'); }
      finally { const next = $('#scanContactSync'); if (next) { next.disabled = !state.data?.whatsapp?.ready || !(state.data?.recipients || []).length; next.textContent = 'فحص التغييرات'; } }
    });
    $('#clearContactSync')?.addEventListener('click', () => { state.contactSyncPreview = null; render(); });
    $('#whatsappContactSearch')?.addEventListener('input', event => { state.whatsappContactFilter = event.target.value; const panel = $('#whatsappContactsPanel'); if (panel) panel.innerHTML = whatsappContactsMarkup(); bindWhatsAppContactRows(); bindWhatsAppProfileSync(); });
    bindWhatsAppProfileSync();
    $$('[data-sync-select]').forEach(input => input.addEventListener('change', () => {
      const item = state.contactSyncPreview?.changes?.find(change => change.id === input.dataset.syncSelect);
      if (item) item.selected = input.checked;
      const button = $('#syncApplySelected'); if (button) button.textContent = `مزامنة المحدد (${state.contactSyncPreview.changes.filter(change => change.changed && !change.error && change.selected).length})`;
    }));
    $('#syncSelectChanged')?.addEventListener('click', () => { state.contactSyncPreview.changes.forEach(item => { item.selected = item.changed && !item.error; }); render(); });
    $('#syncClearSelection')?.addEventListener('click', () => { state.contactSyncPreview.changes.forEach(item => { item.selected = false; }); render(); });
    $('#syncApplySelected')?.addEventListener('click', () => applyContactSync(false));
    $('#syncApplyAll')?.addEventListener('click', () => applyContactSync(true));
    bindPeopleRows(); bindWhatsAppContactRows();
    // First visit to the people page in a session automatically checks for
    // renamed contacts or changed avatars. The user can still re-scan manually;
    // avoid polling WhatsApp continually because profile lookups may be expensive.
    const syncSessionId = sid();
    if (state.data?.whatsapp?.ready && recipients.length && syncSessionId && state.contactSyncAutoScannedSession !== syncSessionId) {
      state.contactSyncAutoScannedSession = syncSessionId;
      setTimeout(() => {
        if (sid() === syncSessionId && state.page === 'people') $('#scanContactSync')?.click();
      }, 250);
    }
  }

  function bindWhatsAppProfileSync() {
    $('#refreshWhatsAppContactProfiles')?.addEventListener('click', async event => {
      const button = event.currentTarget;
      if (state.whatsappProfileHydrating) return;
      button.disabled = true;
      try {
        await hydrateWhatsAppContactProfiles(sid(), { force: true, limit: 250 });
        notify('انتهى فحص الاسم والصورة لجهات WhatsApp الظاهرة. إذا بقيت صورة فارغة فقد لا يتيح WhatsApp صورة عامة لهذا الحساب.', 'success');
      } catch (error) { notify(`تعذر جلب ملفات WhatsApp: ${error.message}`, 'error'); }
    });
  }

  async function hydrateWhatsAppContactProfiles(sessionId, { force = false, limit = 250 } = {}) {
    if (!sessionId || !Array.isArray(state.whatsappContacts) || state.whatsappProfileHydrating) return;
    const contacts = state.whatsappContacts;
    const candidates = contacts.filter(contact => contact.canAdd !== false && contact.phone && (force || !contact.profileHydrated));
    const targets = candidates.slice(0, Math.max(1, Math.min(500, Number(limit) || 250)));
    if (!targets.length) {
      state.whatsappProfileHydrationProgress = { done: 0, total: 0, failed: 0 };
      const panel = $('#whatsappContactsPanel'); if (panel) { panel.innerHTML = whatsappContactsMarkup(); bindWhatsAppContactRows(); bindWhatsAppProfileSync(); }
      return;
    }
    state.whatsappProfileHydrating = true;
    state.whatsappProfileHydrationSession = sessionId;
    state.whatsappProfileHydrationProgress = { done: 0, total: targets.length, failed: 0 };
    const refreshPanel = () => {
      if (sid() !== sessionId || state.page !== 'people') return;
      const panel = $('#whatsappContactsPanel');
      if (panel) { panel.innerHTML = whatsappContactsMarkup(); bindWhatsAppContactRows(); bindWhatsAppProfileSync(); }
    };
    refreshPanel();
    try {
      for (let offset = 0; offset < targets.length; offset += 24) {
        if (sid() !== sessionId) break;
        const batch = targets.slice(offset, offset + 24);
        const result = await api('/api/whatsapp/contacts/profile-batch', {
          method: 'POST', body: JSON.stringify({ sessionId, contacts: batch.map(item => ({ id: item.id, phone: item.phone })) }),
        });
        const profiles = new Map((result.profiles || []).map(profile => [profile.id, profile]));
        let failed = 0;
        state.whatsappContacts = state.whatsappContacts.map(contact => {
          const profile = profiles.get(contact.id);
          if (!profile) return contact;
          const ok = profile.avatarStatus !== 'error';
          if (!ok) failed++;
          const whatsappName = String(profile.whatsappName || contact.whatsappName || '').trim();
          return {
            ...contact,
            whatsappName,
            name: whatsappName || contact.addressBookName || contact.name || (contact.phone ? `+${contact.phone}` : 'جهة اتصال'),
            nameSource: whatsappName ? 'whatsapp-profile' : contact.nameSource,
            avatarUrl: profile.avatarUrl || (profile.avatarStatus === 'none' ? '' : contact.avatarUrl || ''),
            profileStatus: profile.avatarStatus || 'error',
            profileError: profile.avatarError || '',
            profileCheckedAt: profile.profileCheckedAt || new Date().toISOString(),
            profileHydrated: ok,
          };
        });
        state.whatsappProfileHydrationProgress.done = Math.min(offset + batch.length, targets.length);
        state.whatsappProfileHydrationProgress.failed += failed;
        refreshPanel();
      }
    } finally {
      state.whatsappProfileHydrating = false;
      refreshPanel();
    }
  }

  function bindWhatsAppContactRows() {
    $$('[data-add-wa-contact]').forEach(button => button.addEventListener('click', async () => {
      const contactId = button.dataset.addWaContact; button.disabled = true; button.textContent = 'جارٍ الإضافة…';
      try {
        const result = await api('/api/recipient/from-whatsapp', { method: 'POST', body: JSON.stringify({ contactId }) });
        if (state.whatsappContacts) state.whatsappContacts = state.whatsappContacts.map(contact => contact.id === contactId ? { ...contact, exists: true } : contact);
        await load(true);
        if (state.data?.whatsapp?.ready && result.recipient?.id) watchRecipientProfile(result.recipient.id);
        notify(result.message || `تمت إضافة ${result.recipient?.displayName || result.recipient?.name || 'جهة الاتصال'}.`, 'success');
      } catch (error) { notify(error.message, 'error'); button.disabled = false; button.textContent = 'إضافة'; }
    }));
  }

  function bindPeopleRows() {
    $$('[data-select-person]').forEach(input => input.addEventListener('change', () => {
      if (input.checked) state.selectedRecipientIds.add(input.dataset.selectPerson); else state.selectedRecipientIds.delete(input.dataset.selectPerson);
      const button = $('#deleteSelectedPeople'); if (button) { button.disabled = !state.selectedRecipientIds.size; button.textContent = `حذف المحدد (${state.selectedRecipientIds.size})`; }
    }));
    $$('[data-save-person-auto]').forEach(button => button.addEventListener('click', async () => {
      const id = button.dataset.savePersonAuto;
      const row = button.closest('.person-row'); if (!row) return;
      const mode = row.querySelector(`[data-person-auto-mode="${CSS.escape(id)}"]`)?.value || 'inherit';
      const rawRules = row.querySelector(`[data-person-auto-rules="${CSS.escape(id)}"]`)?.value || '';
      const rules = rawRules.split(/\r?\n/).map(line => line.trim()).filter(Boolean).map((line, index) => {
        const parts = line.split('::');
        if (parts.length < 3) throw new Error(`السطر ${index + 1}: استخدم match :: كلمة :: رد`);
        const match = parts.shift().trim().toLowerCase(); const value = parts.shift().trim(); const reply = parts.join('::').trim();
        if (!['any','contains','exact','starts','ends'].includes(match)) throw new Error(`نوع المطابقة غير صالح في السطر ${index + 1}.`);
        if (match !== 'any' && !value) throw new Error(`أدخل كلمة المطابقة في السطر ${index + 1}.`);
        if (!reply) throw new Error(`أدخل الرد في السطر ${index + 1}.`);
        return { name: `قاعدة ${index + 1}`, match, value, reply, enabled: true };
      });
      button.disabled = true;
      try {
        await api(`/api/recipient/${encodeURIComponent(id)}/auto-reply`, { method: 'PATCH', body: JSON.stringify({ mode, rules, fallbackReply: row.querySelector(`[data-person-auto-fallback="${CSS.escape(id)}"]`)?.value || '', conversationEnabled: row.querySelector(`[data-person-auto-conversation="${CSS.escape(id)}"]`)?.checked === true, fallbackToGlobal: row.querySelector(`[data-person-auto-global="${CSS.escape(id)}"]`)?.checked !== false, cooldownSec: Number(row.querySelector(`[data-person-auto-cooldown="${CSS.escape(id)}"]`)?.value || 0) }) });
        notify('تم حفظ تخصيص الرد لهذا الشخص.', 'success'); await load(true);
      } catch (error) { notify(error.message, 'error'); }
      finally { button.disabled = false; }
    }));
    $$('[data-edit-person]').forEach(button => button.addEventListener('click', async () => {
      const personId = button.dataset.editPerson;
      const person = (state.data?.recipients || []).find(item => item.id === personId);
      if (!person) return;
      const oldValue = String(person.localName || person.displayName || person.name || '');
      const value = prompt('الاسم المحلي لهذا الشخص. اتركه فارغًا للرجوع إلى اسم WhatsApp تلقائيًا:', oldValue);
      if (value === null) return;
      try { await api(`/api/recipient/${encodeURIComponent(personId)}`, { method: 'PATCH', body: JSON.stringify({ localName: value.trim() }) }); await load(true); notify(value.trim() ? 'تم حفظ الاسم المحلي دون تغيير WhatsApp.' : 'سيُستخدم اسم WhatsApp تلقائيًا.', 'success'); }
      catch (error) { notify(error.message, 'error'); }
    }));
    $$('[data-avatar-open]').forEach(button => button.addEventListener('click', () => button.closest('.person-row')?.querySelector('[data-avatar-file]')?.click()));
    $$('[data-avatar-file]').forEach(input => input.addEventListener('change', async () => {
      const file = input.files?.[0]; if (!file) return;
      if (file.size > 5 * 1024 * 1024) { notify('حجم الصورة يجب ألا يتجاوز 5 ميجابايت.', 'error'); input.value = ''; return; }
      const form = new FormData(); form.append('file', file, file.name);
      try { await api(`/api/recipient/${encodeURIComponent(input.dataset.avatarFile)}/avatar`, { method: 'POST', body: form }); await load(true); notify('تم حفظ الصورة المحلية. لن يتغير ملف WhatsApp.', 'success'); }
      catch (error) { notify(error.message, 'error'); }
      finally { input.value = ''; }
    }));
    $$('[data-reset-avatar]').forEach(button => button.addEventListener('click', async () => {
      if (button.disabled) return;
      if (!confirm('إزالة الصورة المحلية والعودة إلى صورة WhatsApp إذا كانت متاحة؟')) return;
      try { await api(`/api/recipient/${encodeURIComponent(button.dataset.resetAvatar)}/avatar`, { method: 'DELETE', body: JSON.stringify({}) }); await load(true); notify('تمت إزالة تخصيص الصورة المحلية.', 'success'); }
      catch (error) { notify(error.message, 'error'); }
    }));
    $$('[data-toggle-person]').forEach(button => button.addEventListener('click', async () => { try { await api(`/api/recipient/${encodeURIComponent(button.dataset.togglePerson)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-person]').forEach(button => button.addEventListener('click', async () => { if (!confirm('حذف الشخص من هذه الجلسة؟ سيُزال تخصيص صورته المحلية أيضًا.')) return; try { await api(`/api/recipient/${encodeURIComponent(button.dataset.deletePerson)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); state.selectedRecipientIds.delete(button.dataset.deletePerson); await load(true); } catch (e) { notify(e.message, 'error'); } }));
  }

  function bindGroups() {
    $('#connectGroupBtn')?.addEventListener('click', async () => {
      const value = $('#groupValue').value.trim();
      if (!value) return notify('أدخل GID أو رابط دعوة.', 'error');
      $('#groupResult').textContent = 'جاري الربط والتحليل…';
      try { const result = await api('/api/groups/connect', { method: 'POST', body: JSON.stringify({ sessionId: sid(), value }) }); state.selectedGroup = result.group?.gid || null; notify(result.message || 'تم الربط.', 'success'); await load(true); } catch (error) { $('#groupResult').textContent = error.message; notify(error.message, 'error'); }
    });
    $('#discoverGroupsBtn')?.addEventListener('click', async () => {
      try { const result = await api('/api/groups/discover', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم الاكتشاف.', 'success'); await load(true); } catch (error) { notify(error.message, 'error'); }
    });
    $('#refreshGroupsBtn')?.addEventListener('click', async () => {
      try { const result = await api('/api/groups/refresh-all', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم التحديث.', result.failed?.length ? 'info' : 'success'); await load(true); } catch (error) { notify(error.message, 'error'); }
    });
    $('#groupSearch')?.addEventListener('input', (event) => { state.groupFilter = event.target.value; clearTimeout(bindGroupSearch.timer); bindGroupSearch.timer = setTimeout(renderGroupRows, 120); });
    $('#groupStatusFilter')?.addEventListener('change', event => { state.groupStatusFilter = event.target.value; renderGroupRows(); });
    $('#groupSelectVisible')?.addEventListener('click', () => { filteredGroups(state.data || {}).forEach(group => state.selectedGroupIds.add(group.id)); renderGroupRows(); });
    $('#groupClearSelection')?.addEventListener('click', () => { state.selectedGroupIds.clear(); renderGroupRows(); });
    $('#exportGroupsJson')?.addEventListener('click', () => exportGroups('json'));
    $('#exportGroupsCsv')?.addEventListener('click', () => exportGroups('csv'));
    $$('[data-group-bulk-action]').forEach(button => button.addEventListener('click', () => bulkGroups(button.dataset.groupBulkAction)));
    bindGroupRows();
    bindGroupMemberControls();
  }

  function bindGroupMemberControls() {
    $('#groupMemberSearch')?.addEventListener('input', event => { state.groupMemberFilter = event.target.value; state.groupMemberLimit = 100; clearTimeout(bindGroupMemberControls.timer); bindGroupMemberControls.timer = setTimeout(renderGroupMembers, 120); });
    $('#groupMembersMore')?.addEventListener('click', () => { state.groupMemberLimit += 100; renderGroupMembers(); });
    bindGroupMemberCopy();
  }

  function bindGroupMemberCopy() {
    $$('[data-copy-member]').forEach(button => { if (button.dataset.boundCopy) return; button.dataset.boundCopy = '1'; button.addEventListener('click', async () => { const value = button.dataset.copyMember || ''; if (!value) return; try { await navigator.clipboard.writeText(value); notify('تم نسخ معرف العضو.', 'success'); } catch { notify(value, 'info'); } }); });
  }

  function renderGroupRows() {
    const list = $('.group-list'); if (!list) return;
    const groups = filteredGroups(state.data || {}), current = state.selectedGroup && (state.data?.groups || []).find(group => group.gid === state.selectedGroup);
    list.innerHTML = groups.length ? groups.map(group => groupRow(group, current?.gid === group.gid)).join('') : '<div class="empty">لا توجد نتائج مطابقة.</div>';
    const count = $('#groupSelectionCount'); if (count) count.textContent = `${state.selectedGroupIds.size} محددة`;
    bindGroupRows();
  }

  function exportGroups(kind) {
    const all = state.data?.groups || [], selected = all.filter(group => state.selectedGroupIds.has(group.id)), list = selected.length ? selected : all;
    if (!list.length) return notify('لا توجد مجموعات للتصدير.', 'error');
    let content, mime, filename;
    if (kind === 'csv') {
      const quote = value => `"${String(value ?? '').replace(/"/g, '""')}"`;
      const headers = ['name','gid','enabled','participantsCount','adminsCount','owner','description','inviteCode'];
      const rows = list.map(group => [group.name,group.gid,group.enabled !== false,group.participantsCount ?? group.participants?.length ?? '',group.admins?.length || 0,group.owner,group.description,group.inviteCode]);
      content = '\ufeff' + [headers.map(quote).join(','), ...rows.map(row => row.map(quote).join(','))].join('\r\n'); mime = 'text/csv;charset=utf-8'; filename = 'chatbot-groups.csv';
    } else { content = JSON.stringify({ exportedAt:new Date().toISOString(), sessionId:sid(), groups:list }, null, 2); mime = 'application/json;charset=utf-8'; filename = 'chatbot-groups.json'; }
    const url = URL.createObjectURL(new Blob([content], { type:mime })), a = document.createElement('a'); a.href=url; a.download=filename; a.click(); URL.revokeObjectURL(url); notify(`تم تصدير ${list.length} مجموعة.`, 'success');
  }

  async function bulkGroups(action) {
    const ids = [...state.selectedGroupIds];
    if (!ids.length) return notify('حدد المجموعات أولًا.', 'error');
    if (action === 'delete' && !confirm(`سيتم حذف ${ids.length} مجموعة من المكتبة المحلية وإزالتها من أهداف المواعيد. لن تُحذف المجموعات من WhatsApp. هل تريد المتابعة؟`)) return;
    try {
      const result = await api('/api/groups/bulk', { method:'POST', body:JSON.stringify({ sessionId:sid(), ids, action }) });
      state.selectedGroupIds.clear(); await load(true); notify(result.message || 'اكتمل تحديث المجموعات.', 'success');
    } catch (error) { notify(error.message, 'error'); }
  }

  function bindGroupRows() {
    $$('[data-select-group]').forEach(input => input.addEventListener('change', () => { if (input.checked) state.selectedGroupIds.add(input.dataset.selectGroup); else state.selectedGroupIds.delete(input.dataset.selectGroup); const count = $('#groupSelectionCount'); if (count) count.textContent = `${state.selectedGroupIds.size} محددة`; }));
    $$('[data-show-group]').forEach((button) => button.addEventListener('click', () => { state.selectedGroup = button.dataset.showGroup; state.groupMemberFilter = ''; state.groupMemberLimit = 100; render(); }));
    $$('[data-send-group]').forEach((button) => button.addEventListener('click', () => { state.pendingTargets = [`g:${button.dataset.sendGroup}`]; go('send'); }));
    $$('[data-copy-group]').forEach((button) => button.addEventListener('click', async () => { try { await navigator.clipboard.writeText(button.dataset.copyGroup); notify('تم نسخ GID.', 'success'); } catch { notify('تعذر النسخ من المتصفح.', 'error'); } }));
    $$('[data-toggle-group]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/groups/${encodeURIComponent(button.dataset.toggleGroup)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-group]').forEach((button) => button.addEventListener('click', async () => { if (!confirm('حذف المجموعة من هذه الجلسة؟')) return; try { await api(`/api/groups/${encodeURIComponent(button.dataset.deleteGroup)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); state.selectedGroup = null; await load(true); } catch (e) { notify(e.message, 'error'); } }));
  }

  function applyRulePreset(name) {
    const presets = {
      welcome: { name:'ترحيب جديد', event:'message', match:'contains', value:'السلام عليكم', action:'reply', reply:'وعليكم السلام {{sender}} 👋', emoji:'' },
      help: { name:'مساعدة', event:'message', match:'contains', value:'مساعدة', action:'reply', reply:'اكتب كلمة أو أمرًا وسأرد حسب القواعد التي أنشأتها.', emoji:'' },
      reaction: { name:'تفاعل بالإعجاب', event:'reaction', match:'any', value:'', action:'reaction', reply:'', emoji:'👍' },
    };
    const p = presets[name]; if (!p) return;
    if ($('#ruleName')) $('#ruleName').value=p.name; if ($('#ruleEvent')) $('#ruleEvent').value=p.event; if ($('#ruleMatch')) $('#ruleMatch').value=p.match; if ($('#ruleValue')) $('#ruleValue').value=p.value; if ($('#ruleAction')) $('#ruleAction').value=p.action; if ($('#ruleReply')) $('#ruleReply').value=p.reply; if ($('#ruleEmoji')) $('#ruleEmoji').value=p.emoji;
    $('#ruleAction')?.dispatchEvent(new Event('change')); $('#ruleEvent')?.dispatchEvent(new Event('change'));
    notify('تم تحميل القالب ويمكنك تعديله قبل الحفظ.', 'info');
  }

  function bindInteraction() {
    $$('[data-rule-preset]').forEach((button) => button.addEventListener('click', () => applyRulePreset(button.dataset.rulePreset)));
    $('#saveInteractionSettings')?.addEventListener('click', saveInteractionSettings);
    const refreshActionFields = () => {
      const action = $('#ruleAction')?.value || 'reply';
      $('#ruleReplyWrap')?.toggleAttribute('hidden', action === 'reaction');
      $('#ruleEmojiWrap')?.toggleAttribute('hidden', action === 'reply');
    };
    $('#ruleAction')?.addEventListener('change', refreshActionFields);
    refreshActionFields();
    $('#addRuleBtn')?.addEventListener('click', async () => {
      try {
        const action = $('#ruleAction').value;
        const scope = $('#ruleScope').value;
        const body = {
          sessionId: sid(), name: $('#ruleName').value.trim() || 'قاعدة',
          when: { type: $('#ruleEvent').value, match: $('#ruleMatch').value, value: $('#ruleValue').value },
          then: { reply: action === 'reaction' ? '' : $('#ruleReply').value, reaction: action === 'reply' ? '' : $('#ruleEmoji').value, stopAfter: $('#ruleStop').checked },
          scope, chatIds: scope === 'selected' ? $$('.rule-target:checked').map((input) => input.value) : [],
          priority: Number($('#rulePriority').value) || 0, cooldownSec: Number($('#ruleCooldown').value) || 0,
          schedule: { enabled: $('#ruleScheduleEnabled').checked, start: $('#ruleScheduleStart').value || '09:00', end: $('#ruleScheduleEnd').value || '17:00', days: Array.from($('#ruleScheduleDays').selectedOptions).map(option => Number(option.value)) }
        };
        await api('/api/interaction/rules', { method: 'POST', body: JSON.stringify(body) });
        notify('تم حفظ القاعدة.', 'success');
        await load(true);
      } catch (error) { notify(error.message, 'error'); }
    });
    $('#testRuleBtn')?.addEventListener('click', async () => {
      try {
        const type = $('#ruleEvent').value;
        const rule = { when: { type, match: $('#ruleMatch').value, value: $('#ruleValue').value }, then: { reply: $('#ruleReply').value, reaction: $('#ruleEmoji').value }, schedule: { enabled: $('#ruleScheduleEnabled').checked, start: $('#ruleScheduleStart').value || '09:00', end: $('#ruleScheduleEnd').value || '17:00', days: Array.from($('#ruleScheduleDays').selectedOptions).map(option => Number(option.value)) } };
        const result = await api('/api/interaction/test', { method: 'POST', body: JSON.stringify({ sessionId: sid(), message: $('#ruleTestMessage').value, emoji: $('#ruleTestEmoji').value, sender: 'مستخدم الاختبار', rule }) });
        notify(result.matched ? (result.rendered ? `مطابقة ناجحة: ${result.rendered}` : 'مطابقة ناجحة') : 'لا توجد مطابقة.', result.matched ? 'success' : 'info');
      } catch (error) { notify(error.message, 'error'); }
    });
    $$('[data-toggle-rule]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/interaction/rules/${encodeURIComponent(button.dataset.toggleRule)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-rule]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/interaction/rules/${encodeURIComponent(button.dataset.deleteRule)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
  }

  async function saveInteractionSettings() {
    try {
      await api('/api/settings', { method: 'POST', body: JSON.stringify({
        sessionId: sid(), interactionEnabled: $('#interactionEnabled').checked, groupAssistantEnabled: $('#groupAssistantEnabled').checked, interactionIgnoreOwn: $('#interactionIgnoreOwn').checked, interactionUseRecipientNames: $('#interactionUseRecipientNames').checked, interactionFallbackEnabled: $('#interactionFallbackEnabled').checked, interactionFallbackReply: $('#interactionFallbackReply').value, interactionFallbackCooldownSec: Number($('#interactionFallbackCooldownSec').value || 300),
        interactionScope: $('#interactionScope').value, interactionChatIds: $$('.rule-target:checked').map((input) => input.value), interactionQuietEnabled: $('#interactionQuietEnabled').checked,
        interactionQuietStart: $('#interactionQuietStart').value, interactionQuietEnd: $('#interactionQuietEnd').value, interactionQuietAction: $('#interactionQuietAction').value, interactionQuietReply: $('#interactionQuietReply').value, interactionQuietCooldownSec: Number($('#interactionQuietCooldownSec').value || 300), maxActionsPerMinute: Number($('#maxActionsPerMinute').value || 20)
      }) });
      notify('تم حفظ إعدادات التفاعل.', 'success');
      await load(true);
    } catch (error) { notify(error.message, 'error'); }
  }

  function bindOwnerCenter() {
    const apiSupport = async (url, options = {}) => api(url, { ...options, body: options.body === undefined ? JSON.stringify({ sessionId: sid() }) : options.body });
    $('#ownerRefresh')?.addEventListener('click', () => load(true).catch(e => notify(e.message, 'error')));
    $('#ownerDiagnose')?.addEventListener('click', async () => { const button=$('#ownerDiagnose'); if(button) {button.disabled=true;button.textContent='جارٍ الفحص…';} try { const r=await apiSupport('/api/assistant/diagnostics',{method:'POST'}); state.data=await api(`/api/state?sessionId=${encodeURIComponent(sid())}`); render(); notify(r.message || 'اكتمل الفحص.','success'); } catch(e){notify(e.message,'error');} finally { if(button){button.disabled=false;button.textContent='تشخيص الآن';} } });
    $('#ownerConfigForm')?.addEventListener('submit', async event => { event.preventDefault(); const button=$('#ownerSaveConfig'); if(button){button.disabled=true;button.textContent='جارٍ الحفظ…';} try {
      const result=await apiSupport('/api/assistant/config',{method:'POST',body:JSON.stringify({sessionId:sid(),notificationsEnabled:$('#ownerNotificationsEnabled').checked,notificationMode:$('#ownerNotificationMode').value,ownerPhone:$('#ownerPhone').value.trim(),ownerPhoneConfirmed:$('#ownerPhoneConfirmed').checked,country:'OM'})});
      $('#ownerConfigStatus').textContent=result.message || 'تم الحفظ.'; await load(true); notify('تم حفظ إعدادات تنبيهات المساعد.','success');
    } catch(e){$('#ownerConfigStatus').textContent=e.message;notify(e.message,'error');} finally {if(button){button.disabled=false;button.textContent='حفظ الإعدادات';}} });
    $('#ownerTestNotification')?.addEventListener('click', async () => { const button=$('#ownerTestNotification'); if(button){button.disabled=true;button.textContent='جارٍ الاختبار…';} try { const result=await apiSupport('/api/assistant/test-notification',{method:'POST',body:JSON.stringify({sessionId:sid()})}); $('#ownerConfigStatus').textContent=result.message || 'تم إرسال الاختبار.'; await load(true); notify(result.message || 'تم الإرسال.','success'); } catch(e){$('#ownerConfigStatus').textContent=e.message;notify(e.message,'error');} finally {if(button){button.disabled=false;button.textContent='اختبار الإشعار';}} });
    $('#ownerChatForm')?.addEventListener('submit', async event => { event.preventDefault(); const input=$('#ownerChatInput'), button=$('#ownerChatSend'), text=String(input?.value||'').trim(); if(!text)return; if(button){button.disabled=true;button.textContent='جارٍ الرد…';} try { await api('/api/assistant/chat',{method:'POST',body:JSON.stringify({sessionId:sid(),text})}); state.data=await api(`/api/state?sessionId=${encodeURIComponent(sid())}`); render(); const next=$('#ownerChatInput'); next?.focus(); } catch(e){notify(e.message,'error');} finally {const btn=$('#ownerChatSend');if(btn){btn.disabled=false;btn.textContent='إرسال';}} });
    $$('[data-owner-open-issue]').forEach(button => button.addEventListener('click', async () => { const page=button.dataset.ownerPage || (state.data?.ownerAssistant?.issues||[]).find(i=>i.id===button.dataset.ownerOpenIssue)?.page || 'dashboard'; go(page); }));
    $$('[data-owner-resolve-issue]').forEach(button => button.addEventListener('click', async () => { try { await api(`/api/assistant/issues/${encodeURIComponent(button.dataset.ownerResolveIssue)}/resolve`,{method:'POST',body:JSON.stringify({sessionId:sid()})}); await load(true); notify('تم تعليم المشكلة كمحلولة.','success'); } catch(e){notify(e.message,'error');} }));
    $('#ownerNotificationMode')?.addEventListener('change', () => { const phoneMode=$('#ownerNotificationMode').value==='phone'; $('#ownerPhone')?.toggleAttribute('required', phoneMode && $('#ownerNotificationsEnabled').checked); $('#ownerPhoneConfirmed')?.toggleAttribute('required', phoneMode && $('#ownerNotificationsEnabled').checked); });
  }

  function bindSession() {
    $('#connectSessionBtn')?.addEventListener('click', async () => { try { const result = await api('/api/session/connect', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم بدء الاتصال.', result.runtime?.status === 'recovering' ? 'warning' : result.runtime?.ready || result.runtime?.status === 'qr' ? 'success' : 'info'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#stopSessionBtn')?.addEventListener('click', async () => { try { await api('/api/session/stop', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify('تم إيقاف الجلسة.', 'info'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#unlinkSessionBtn')?.addEventListener('click', async () => { if (!confirm('فصل الحساب من هذه الجلسة؟')) return; try { await api('/api/session/unlink', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify('تم فصل الحساب.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#saveSessionBtn')?.addEventListener('click', async () => { try { await api(`/api/sessions/${encodeURIComponent(sid())}`, { method: 'PUT', body: JSON.stringify({ name: $('#sessionName').value.trim() }) }); notify('تم حفظ الاسم.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#newSessionBtn')?.addEventListener('click', async () => { try {
      const created = await api('/api/sessions', { method: 'POST', body: JSON.stringify({ name: 'جلسة جديدة' }) });
      const newId = created.session?.id; if (!newId) throw new Error('تم إنشاء الجلسة لكن لم يرجع معرّفها.');
      await api('/api/sessions/switch', { method:'POST', body:JSON.stringify({ sessionId:newId }) });
      state.pendingTargets = []; state.selectedGroup = null; state.selectedGroupIds.clear(); state.selectedMedia = null; state.page = 'session'; location.hash = state.page;
      state.data = await api(`/api/state?sessionId=${encodeURIComponent(newId)}`); render(); notify('تم إنشاء الجلسة والتبديل إليها. اربط حساب WhatsApp مستقلًا لهذه الجلسة.', 'success');
    } catch (e) { notify(e.message, 'error'); } });
    $('#deleteSessionBtn')?.addEventListener('click', async () => { if (!confirm('حذف هذه الجلسة نهائيًا؟ سيتم حذف مصادقتها وبياناتها المحلية.')) return; try {
      const deletedId = sid(); const result = await api(`/api/sessions/${encodeURIComponent(deletedId)}`, { method: 'DELETE' });
      const nextId = result.activeSessionId; if (!nextId) throw new Error('حُذفت الجلسة لكن لم يُرجع الخادم الجلسة البديلة.');
      await api('/api/sessions/switch', { method:'POST', body:JSON.stringify({ sessionId:nextId }) });
      state.page = 'dashboard'; location.hash = state.page; state.pendingTargets = []; state.selectedGroup = null; state.selectedGroupIds.clear(); state.selectedMedia = null;
      state.data = await api(`/api/state?sessionId=${encodeURIComponent(nextId)}`); render(); notify('تم حذف الجلسة والتبديل إلى جلسة موجودة. لم تُنشأ الجلسة المحذوفة من جديد.', 'success');
    } catch (e) { notify(e.message, 'error'); } });
  }

  function saveAssistantMessages() {
    try { state.assistantMessages = window.LocalAssistantEngine.saveMessages(state.assistantMessages); }
    catch { notify('تعذر حفظ سجل المحادثة محليًا؛ قد تكون مساحة المتصفح ممتلئة.', 'error'); }
  }

  function appendAssistantMessage(role, text) {
    state.assistantMessages.push({ role, text: String(text ?? '').slice(0, 8000), at: Date.now() });
    state.assistantMessages = state.assistantMessages.slice(-window.LocalAssistantEngine.MAX_MESSAGES);
    saveAssistantMessages();
    renderAssistantMessages();
  }

  function renderAssistantMessages() {
    const host = $('#assistantMessages'); if (!host) return;
    const recent = state.assistantMessages.slice(-80);
    host.innerHTML = recent.length ? recent.map((message) => `<article class="assistant-message ${message.role === 'user' ? 'from-user' : 'from-assistant'}"><div class="assistant-message-avatar" aria-hidden="true">${message.role === 'user' ? 'أنت' : '✧'}</div><div class="assistant-message-content"><div class="assistant-message-meta"><b>${message.role === 'user' ? 'أنت' : 'المساعد المحلي'}</b><time>${new Date(message.at || Date.now()).toLocaleTimeString('ar-OM', { hour:'2-digit', minute:'2-digit' })}</time></div><div class="assistant-message-text">${esc(message.text).replace(/\n/g, '<br>')}</div></div></article>`).join('') : '<div class="assistant-welcome"><div class="assistant-orb" aria-hidden="true">✧</div><p class="eyebrow">مساعد يعمل محليًا</p><h2>أهلًا، جاهز لتنفيذ أوامرك</h2><p>أقدر أفتح صفحات المشروع، أراجع حالة الجلسة، أغيّر المظهر، أجهّز مسودة رسالة، وأشغّل الأوامر التي تحفظها بنفسك.</p><div class="assistant-local-notice"><span aria-hidden="true">●</span> لا يوجد اتصال بمزود ذكاء اصطناعي. الأوامر والحفظ يعملان داخل المتصفح.</div></div>';
    host.scrollTop = host.scrollHeight;
  }

  function assistantTargetStatus() {
    const d = state.data || {};
    const ready = !!d.whatsapp?.ready;
    const connection = ready ? 'متصل وجاهز' : (d.whatsapp?.status === 'qr' ? 'بانتظار مسح رمز QR' : 'غير متصل');
    const session = d.session?.name || d.session?.id || 'غير محددة';
    return `حالة الجلسة الحالية: ${session}\nاتصال WhatsApp: ${connection}\nالأشخاص المحفوظون: ${(d.recipients || []).length}\nالمجموعات المحفوظة: ${(d.groups || []).length}\nالرسائل والملفات المسجلة: ${Number(d.stats?.sentMessages || 0) + Number(d.stats?.sentImages || 0) + Number(d.stats?.sentFiles || 0)}\nالمساعد المحلي: يعمل دون مزود ذكاء اصطناعي.`;
  }

  function assistantSummary() {
    const d = state.data || {};
    const stats = d.stats || {};
    const tasks = d.automation?.tasks || [];
    const activeTasks = tasks.filter((x) => x.enabled !== false).length;
    const activeTargets = [...(d.recipients || []), ...(d.groups || [])].filter((x) => x.enabled !== false).length;
    return `${assistantTargetStatus()}\nالأهداف المفعّلة: ${activeTargets}\nالمواعيد المحفوظة: ${tasks.length} (المفعّل: ${activeTasks})\nقواعد التفاعل: ${(d.interaction?.rules || []).length}\nعمليات الإرسال المسجلة: ${Number(stats.sentMessages || 0) + Number(stats.sentImages || 0) + Number(stats.sentFiles || 0)}.`;
  }

  function setLocalUiMode(theme) {
    state.uiMode = theme === 'toggle' ? (state.uiMode === 'dark' ? 'light' : 'dark') : (theme === 'light' ? 'light' : 'dark');
    document.documentElement.dataset.uiMode = state.uiMode;
    try { localStorage.setItem('chatbot-ui-mode', state.uiMode); } catch {}
    const button = $('#modeToggleBtn');
    if (button) {
      button.innerHTML = `<span class="mode-icon" aria-hidden="true">${state.uiMode === 'dark' ? '☼' : '☾'}</span><span>${state.uiMode === 'dark' ? 'الوضع الفاتح' : 'الوضع الداكن'}</span>`;
      button.setAttribute('aria-label', state.uiMode === 'dark' ? 'التبديل إلى الوضع الفاتح' : 'التبديل إلى الوضع الداكن');
    }
  }

  function renderAssistantCommandLibrary() {
    const host = $('#assistantCommandList'); if (!host) return;
    const engine = window.LocalAssistantEngine;
    const query = engine.normalize(state.assistantLibraryFilter || '');
    const rows = [
      ...engine.BUILTIN_COMMANDS.map((command) => ({ ...command, builtIn: true })),
      ...state.assistantCommands.map((command) => ({ ...command, builtIn: false })),
    ].filter((command) => !query || engine.normalize(`${command.name} ${command.description || ''} ${(command.triggers || []).join(' ')}`).includes(query));
    const count = $('#assistantCommandCount'); if (count) count.textContent = String(engine.BUILTIN_COMMANDS.length + state.assistantCommands.length);
    host.innerHTML = rows.length ? rows.map((command) => `<article class="assistant-command-card ${command.builtIn ? 'is-builtin' : 'is-custom'}"><div class="assistant-command-card-top"><span class="assistant-command-type">${command.builtIn ? 'أساسي' : 'محفوظ'}</span>${!command.builtIn ? `<button type="button" class="assistant-command-delete" data-assistant-delete="${esc(command.id)}" aria-label="حذف الأمر ${esc(command.name)}">×</button>` : ''}</div><b>${esc(command.name)}</b><p>${esc(command.description || 'أمر محلي محفوظ')}</p><div class="assistant-triggers">${(command.triggers || []).slice(0,4).map((trigger) => `<span>${esc(trigger)}</span>`).join('')}</div><div class="assistant-command-card-actions"><button type="button" class="btn small" data-assistant-run="${esc(command.id)}">جرّب الأمر</button>${!command.builtIn ? `<button type="button" class="btn small" data-assistant-edit="${esc(command.id)}">تعديل</button>` : ''}</div></article>`).join('') : '<div class="empty">لا توجد أوامر مطابقة. أضف أمرًا جديدًا أو غيّر البحث.</div>';
  }

  function syncAssistantCommandFields() {
    const action = $('#assistantCommandAction')?.value || 'navigate';
    const pageWrap = $('#assistantCommandPageWrap'); const themeWrap = $('#assistantCommandThemeWrap'); const responseWrap = $('#assistantCommandResponseWrap'); const responseHelp = $('#assistantCommandResponseHelp');
    if (pageWrap) pageWrap.hidden = action !== 'navigate';
    if (themeWrap) themeWrap.hidden = action !== 'theme';
    if (responseWrap) responseWrap.hidden = !['reply','draft'].includes(action);
    if (responseHelp) responseHelp.textContent = action === 'draft' ? 'سيُنقل هذا النص إلى نموذج الإرسال كمسودة ولن يُرسل تلقائيًا.' : 'هذا النص سيظهر عندما يطابق المستخدم عبارة التشغيل.';
  }

  function resetAssistantCommandForm() {
    const form = $('#assistantCommandForm'); if (!form) return;
    form.reset(); $('#assistantCommandId').value = ''; $('#assistantCommandAction').value = 'navigate'; $('#assistantCommandPage').value = 'dashboard'; $('#assistantCommandTheme').value = 'toggle';
    $('#assistantEditorSummary').textContent = 'إضافة أمر محفوظ جديد'; $('#assistantSaveCommand').textContent = 'حفظ الأمر';
    syncAssistantCommandFields();
  }

  function prepareAssistantCommandEdit(id) {
    const item = state.assistantCommands.find((command) => command.id === id); if (!item) return;
    $('#assistantCommandId').value = item.id; $('#assistantCommandName').value = item.name;
    $('#assistantCommandTriggers').value = item.triggers.join(' | '); $('#assistantCommandAction').value = item.action;
    $('#assistantCommandPage').value = item.page || 'dashboard'; $('#assistantCommandTheme').value = item.theme || 'toggle';
    $('#assistantCommandResponse').value = item.response || ''; $('#assistantCommandDescription').value = item.description || '';
    $('#assistantEditorSummary').textContent = `تعديل الأمر: ${item.name}`; $('#assistantSaveCommand').textContent = 'حفظ التعديلات';
    syncAssistantCommandFields(); const details = $('#assistantCommandEditor'); if (details) details.open = true;
    $('#assistantCommandName').focus();
  }

  function exportAssistantJson(filename, payload) {
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function scrollAssistantLibrary() {
    $('#assistantLibraryPanel')?.scrollIntoView({ behavior: 'auto', block: 'start' });
    const details = $('#assistantCommandEditor'); if (details) details.open = true;
    $('#assistantCommandName')?.focus();
  }

  async function runAssistantAction(command) {
    switch (command.action) {
      case 'navigate':
        go(command.page || 'dashboard');
        return `تم فتح صفحة «${({ dashboard:'الرئيسية', send:'الإرسال', people:'الأشخاص', groups:'المجموعات', interaction:'التفاعل', session:'الجلسة', settings:'الإعدادات', appearance:'المظهر', operation:'التشغيل المتقدم', assistant:'المساعد المحلي' })[command.page] || command.page}».`;
      case 'reply': return command.response || 'لا يوجد رد محفوظ لهذا الأمر.';
      case 'draft':
        state.assistantDraft = command.response || '';
        state.pendingTargets = Array.isArray(state.pendingTargets) ? state.pendingTargets : [];
        go('send');
        return 'جهّزت نص الرسالة في نموذج الإرسال. راجعه واختر المستلمين قبل الإرسال؛ لم أرسل أي شيء تلقائيًا.';
      case 'status': return assistantTargetStatus();
      case 'refresh':
        try { await load(true); return `تم تحديث بيانات المشروع المحلي.\n${assistantTargetStatus()}`; }
        catch (error) { return `تعذر تحديث البيانات: ${error.message}`; }
      case 'theme':
        setLocalUiMode(command.theme || 'toggle');
        return `تم تفعيل ${state.uiMode === 'light' ? 'الوضع الفاتح' : 'الوضع الداكن'}.`;
      default: return 'هذا النوع من الأوامر غير مدعوم.';
    }
  }

  async function assistantHandleText(text) {
    const input = String(text || '').trim(); if (!input || state.assistantBusy) return;
    appendAssistantMessage('user', input);
    const field = $('#assistantChatInput'); if (field) field.value = '';
    state.assistantBusy = true; const sendButton = $('#assistantSubmit'); if (sendButton) { sendButton.disabled = true; sendButton.textContent = 'جارٍ التنفيذ…'; }
    const engine = window.LocalAssistantEngine;
    try {
      const parsed = engine.classify(input, state.assistantCommands);
      let response = '';
      if (parsed.type === 'empty') return;
      if (parsed.type === 'draft') {
        state.assistantDraft = parsed.text; go('send');
        response = 'جهّزت مسودة الرسالة داخل صفحة الإرسال. راجعها وحدد الأهداف بنفسك؛ لن يتم الإرسال إلا عندما تضغط زر الإرسال.';
      } else if (parsed.type === 'search') {
        state.assistantLibraryFilter = parsed.query; go('assistant');
        if ($('#assistantCommandSearch')) $('#assistantCommandSearch').value = parsed.query;
        renderAssistantCommandLibrary(); response = `بحثت محليًا عن «${parsed.query}». راجع النتائج في مكتبة الأوامر؛ لم يتم إرسال طلب لخدمة خارجية.`;
      } else if (parsed.type === 'navigate') {
        const cmd = { action:'navigate', page:parsed.page }; response = await runAssistantAction(cmd);
      } else if (parsed.type === 'status') {
        response = assistantTargetStatus();
      } else if (parsed.type === 'refresh') {
        response = await runAssistantAction({ action:'refresh' });
      } else if (parsed.type === 'unknown') {
        response = `لم أجد أمرًا محفوظًا يطابق «${input}».\nأنا مساعد أوامر محلي ولست نموذج ذكاء اصطناعي؛ لا أخمّن تنفيذ أشياء غير معرّفة. افتح «＋ أمر محفوظ» في مكتبة الأوامر، وحدد عبارة تشغيل وما الذي يجب أن ينفذه الأمر. يمكنك حفظ ما يصل إلى ${engine.MAX_COMMANDS.toLocaleString('ar')} أمرًا مخصصًا.`;
      } else if (parsed.type === 'command') {
        const command = parsed.command;
        if (command.action === 'help') response = `أنا مساعد محلي لا يحتاج API ذكاء اصطناعي. أستطيع فتح صفحات المشروع، قراءة حالة الجلسة، تحديث البيانات، تغيير المظهر، تجهيز مسودة، وتشغيل أوامرك المخصصة.\nعدد أوامرك المحفوظة: ${state.assistantCommands.length}. احفظ أوامر جديدة من مكتبة الأوامر. لا أرسل رسالة تلقائيًا.`;
        else if (command.action === 'list' || command.action === 'library') { go('assistant'); setTimeout(scrollAssistantLibrary, 0); response = `مكتبة الأوامر مفتوحة. لديك ${engine.BUILTIN_COMMANDS.length} أمرًا أساسيًا و${state.assistantCommands.length} أمرًا مخصصًا محفوظًا في هذا المتصفح.`; }
        else if (command.action === 'new-command') { go('assistant'); setTimeout(() => { const details=$('#assistantCommandEditor'); if(details)details.open=true; $('#assistantCommandName')?.focus(); },0); response = 'فتحت نموذج إضافة أمر. أدخل الاسم وعبارات التشغيل وحدد نوع الإجراء، ثم اضغط «حفظ الأمر».'; }
        else if (command.action === 'clear-chat') { if (confirm('مسح سجل محادثة المساعد فقط؟ لن تُحذف مكتبة الأوامر.')) { state.assistantMessages=[]; saveAssistantMessages(); renderAssistantMessages(); response = 'تم مسح سجل المحادثة. الأوامر المحفوظة لم تتغير.'; } else response = 'أُلغيت العملية؛ لم يتم مسح المحادثة أو الأوامر.'; }
        else if (command.action === 'privacy') response = `المساعد والأوامر المحفوظة يعملان محليًا ولا يستدعيان أي API ذكاء اصطناعي.\nحفظ الأوامر وسجل المحادثة في تخزين هذا المتصفح.\nعند تحديث حالة المشروع، أستخدم API المحلي الخاص بالتطبيق على جهازك فقط.\nإرسال WhatsApp الحقيقي يتطلب جلسة مرتبطة، ولا يتم من رسالة المساعد؛ أمر «جهّز رسالة» يضع مسودة فقط.`;
        else if (command.action === 'summary') response = assistantSummary();
        else if (command.action === 'schedule') { go('send'); setTimeout(() => { const d=$('.task-workspace'); if(d){d.open=true;d.scrollIntoView({behavior:'auto',block:'start'});} },0); response = 'فتحت صفحة الإرسال وقسم المواعيد. راجع إعدادات الموعد قبل الحفظ.'; }
        else if (command.action === 'send-help') { go('send'); response = 'فتحت صفحة الإرسال. اختر الأشخاص أو المجموعات، اكتب النص وأرفق الملفات عند الحاجة، ثم راجع كل شيء واضغط «إرسال الآن» بنفسك.'; }
        else response = await runAssistantAction(command);
      }
      if (response) appendAssistantMessage('assistant', response);
    } catch (error) {
      appendAssistantMessage('assistant', `حدث خطأ أثناء تنفيذ الأمر: ${error.message}`);
    } finally {
      state.assistantBusy = false; const button=$('#assistantSubmit'); if(button){button.disabled=false;button.innerHTML='إرسال الأمر <span aria-hidden="true">↵</span>';}
      $('#assistantChatInput')?.focus();
    }
  }

  function bindLocalAssistant() {
    renderAssistantCommandLibrary(); renderAssistantMessages(); syncAssistantCommandFields();
    $('#assistantChatForm')?.addEventListener('submit', (event) => { event.preventDefault(); assistantHandleText($('#assistantChatInput')?.value || ''); });
    $('#assistantChatInput')?.addEventListener('keydown', (event) => { if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); $('#assistantChatForm')?.requestSubmit(); } });
    $$('[data-assistant-suggestion]').forEach((button) => button.addEventListener('click', () => assistantHandleText(button.dataset.assistantSuggestion || '')));
    $('#assistantClearChat')?.addEventListener('click', () => { if (!confirm('مسح سجل محادثة المساعد؟ ستبقى الأوامر المحفوظة كما هي.')) return; state.assistantMessages=[]; saveAssistantMessages(); renderAssistantMessages(); });
    $('#assistantCopyLast')?.addEventListener('click', async () => { const last=[...state.assistantMessages].reverse().find((m)=>m.role==='assistant'); if(!last){notify('لا يوجد رد لنسخه.','info');return;} try { await navigator.clipboard.writeText(last.text); notify('تم نسخ آخر رد.','success'); } catch { const box=document.createElement('textarea');box.value=last.text;document.body.appendChild(box);box.select();const ok=document.execCommand('copy');box.remove();notify(ok?'تم نسخ آخر رد.':'تعذر النسخ من المتصفح. تفقد إعدادات الأذونات. ',ok?'success':'error');} });
    $('#assistantExportChat')?.addEventListener('click', () => exportAssistantJson('chat-bot-local-chat.json', { exportedAt:new Date().toISOString(), messages:state.assistantMessages }));
    $('#assistantExportCommands')?.addEventListener('click', () => exportAssistantJson('chat-bot-saved-commands.json', { schema:'chat-bot-local-commands/v1', exportedAt:new Date().toISOString(), commands:state.assistantCommands }));
    $('#assistantImportCommands')?.addEventListener('click', () => $('#assistantImportFile')?.click());
    $('#assistantImportFile')?.addEventListener('change', async (event) => {
      const file=event.target.files?.[0]; if(!file)return;
      try {
        const parsed=JSON.parse(await file.text()); const incoming=Array.isArray(parsed)?parsed:parsed.commands;
        if(!Array.isArray(incoming))throw new Error('ملف JSON لا يحتوي على قائمة أوامر.');
        const engine=window.LocalAssistantEngine; const merged=[...state.assistantCommands]; const ids=new Set(merged.map((x)=>x.id));
        for(const row of incoming){ const candidate=engine.validateCustomCommand({...row,builtIn:false}); if(ids.has(candidate.id))candidate.id=`${candidate.id}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,6)}`;ids.add(candidate.id);merged.push(candidate); }
        state.assistantCommands=engine.saveCommands(merged);renderAssistantCommandLibrary();notify(`تم استيراد ${incoming.length} أمرًا.`, 'success');
      } catch(error){notify(`تعذر استيراد الأوامر: ${error.message}`,'error');}
      finally{event.target.value='';}
    });
    $('#assistantCommandSearch')?.addEventListener('input', (event) => { state.assistantLibraryFilter=event.target.value;renderAssistantCommandLibrary(); });
    $('#assistantCommandAction')?.addEventListener('change', syncAssistantCommandFields);
    $('#assistantNewCommand')?.addEventListener('click', () => { resetAssistantCommandForm();const details=$('#assistantCommandEditor');if(details)details.open=true;$('#assistantCommandName')?.focus(); });
    $('#assistantTeachLast')?.addEventListener('click', () => {
      const lastUser=[...state.assistantMessages].reverse().find((message)=>message.role==='user');
      if(!lastUser){notify('أرسل العبارة التي تريد تعليمها أولًا.','info');return;}
      resetAssistantCommandForm();
      $('#assistantCommandName').value=`أمر: ${lastUser.text.slice(0,65)}`;
      $('#assistantCommandTriggers').value=lastUser.text.slice(0,120);
      const details=$('#assistantCommandEditor');if(details)details.open=true;
      $('#assistantCommandAction').value='navigate';syncAssistantCommandFields();
      $('#assistantCommandName').focus();
      notify('أضفت آخر رسالة كعبارة تشغيل. اختر نوع التنفيذ وباقي الإعدادات ثم احفظ الأمر.','info');
    });
    $('#assistantCancelEdit')?.addEventListener('click', resetAssistantCommandForm);
    $('#assistantCommandForm')?.addEventListener('submit', (event) => {
      event.preventDefault();
      try {
        const engine=window.LocalAssistantEngine;const id=$('#assistantCommandId').value || undefined;
        const candidate=engine.validateCustomCommand({id,name:$('#assistantCommandName').value,triggers:$('#assistantCommandTriggers').value,action:$('#assistantCommandAction').value,page:$('#assistantCommandPage').value,theme:$('#assistantCommandTheme').value,response:$('#assistantCommandResponse').value,description:$('#assistantCommandDescription').value,builtIn:false});
        const nextCommands=[...state.assistantCommands];const existing=nextCommands.findIndex((row)=>row.id===candidate.id);
        if(existing>=0)nextCommands[existing]=candidate;else nextCommands.push(candidate);
        if(nextCommands.length>engine.MAX_COMMANDS)throw new Error(`الحد الأقصى ${engine.MAX_COMMANDS.toLocaleString('ar')} أمرًا.`);
        state.assistantCommands=engine.saveCommands(nextCommands);state.assistantLibraryFilter='';$('#assistantCommandSearch').value='';renderAssistantCommandLibrary();resetAssistantCommandForm();notify(existing>=0?'تم تحديث الأمر المحفوظ.':'تم حفظ الأمر في هذا المتصفح.','success');
      } catch(error){notify(`تعذر حفظ الأمر: ${error.message}`,'error');}
    });
    $('#assistantCommandList')?.addEventListener('click', async (event) => {
      const edit=event.target.closest('[data-assistant-edit]');const del=event.target.closest('[data-assistant-delete]');const run=event.target.closest('[data-assistant-run]');
      if(edit){prepareAssistantCommandEdit(edit.dataset.assistantEdit);return;}
      if(del){const id=del.dataset.assistantDelete;const item=state.assistantCommands.find((row)=>row.id===id);if(!item||!confirm(`حذف الأمر «${item.name}» من هذا المتصفح؟`))return;try{const nextCommands=state.assistantCommands.filter((row)=>row.id!==id);state.assistantCommands=window.LocalAssistantEngine.saveCommands(nextCommands);renderAssistantCommandLibrary();notify('تم حذف الأمر.','success');}catch(error){notify(error.message,'error');}return;}
      if(run){const id=run.dataset.assistantRun;const command=[...window.LocalAssistantEngine.BUILTIN_COMMANDS,...state.assistantCommands].find((row)=>row.id===id);if(command){appendAssistantMessage('user',command.name);state.assistantBusy=false;try{let response;if(command.action==='summary')response=assistantSummary();else if(command.action==='privacy')response='المساعد والأوامر المحفوظة يعملان محليًا، ولا يوجد مزود ذكاء اصطناعي خارجي.';else if(command.action==='help')response='اختر أمرًا من المكتبة أو اكتب عبارة التشغيل في الشات. يمكنك إضافة ما يصل إلى 1000 أمر محلي.';else if(command.action==='list'||command.action==='library'){scrollAssistantLibrary();response=`تحتوي المكتبة على ${state.assistantCommands.length} أمرًا مخصصًا محفوظًا.`;}else if(command.action==='clear-chat'){response='اكتب «امسح المحادثة» في الشات لتأكيد مسح السجل مع بقاء الأوامر.';}else if(command.action==='schedule'){go('send');setTimeout(()=>{const d=$('.task-workspace');if(d){d.open=true;d.scrollIntoView({behavior:'auto',block:'start'});}},0);response='فتحت قسم المواعيد.';}else if(command.action==='send-help'){go('send');response='اختر الأهداف واكتب الرسالة ثم راجعها قبل الإرسال.';}else response=await runAssistantAction(command);appendAssistantMessage('assistant',response||'تم تنفيذ الأمر.');}catch(error){appendAssistantMessage('assistant',`تعذر التنفيذ: ${error.message}`);}}}
    });
  }

  function applyUiPreset(name) {
    const presets = {
      mint: { accent: '#5ed6c1', accent2: '#8b7cf6', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .28 },
      ocean: { accent: '#56c9ff', accent2: '#57e5cf', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .25 },
      violet: { accent: '#9b86ff', accent2: '#e18aff', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .27 },
      sunset: { accent: '#ff9a6a', accent2: '#ff6fb1', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .24 },
    };
    const p = presets[name]; if (!p) return;
    if ($('#uiAccent')) $('#uiAccent').value = p.accent;
    if ($('#uiAccent2')) $('#uiAccent2').value = p.accent2;
    if ($('#uiPanelOpacity')) $('#uiPanelOpacity').value = p.panelOpacity;
    if ($('#uiPanelBlur')) $('#uiPanelBlur').value = p.panelBlur;
    if ($('#uiRadius')) $('#uiRadius').value = p.radius;
    if ($('#uiGlow')) $('#uiGlow').value = p.glow;
    ['uiPanelOpacity','uiPanelBlur','uiRadius','uiGlow'].forEach(updateRangeOutput);
    applyInterfaceLive();
    notify('تم تطبيق المظهر الجاهز. اضغط حفظ الواجهة لتثبيته.', 'info');
  }

  function bindAppearance() {
    const uiControls = ['uiPanelOpacity', 'uiPanelBlur', 'uiRadius', 'uiGlow'];
    uiControls.forEach((id) => $(`#${id}`)?.addEventListener('input', () => { updateRangeOutput(id); applyInterfaceLive(); }));
    $('#uiAccent')?.addEventListener('input', applyInterfaceLive);
    $('#uiAccent2')?.addEventListener('input', applyInterfaceLive);
    const syncThemeDots = () => { const a = readInterfaceForm(); if ($('#themeDot1')) $('#themeDot1').style.background = a.accent; if ($('#themeDot2')) $('#themeDot2').style.background = a.accent2; };
    syncThemeDots();
    $$('[data-ui-preset]').forEach((button) => button.addEventListener('click', () => applyUiPreset(button.dataset.uiPreset)));
    ['uiAccent','uiAccent2','uiPanelOpacity','uiPanelBlur','uiRadius','uiGlow'].forEach((id) => $(`#${id}`)?.addEventListener('input', syncThemeDots));
    $('#saveUiThemeBtn')?.addEventListener('click', async () => {
      try { await api('/api/settings', { method: 'POST', body: JSON.stringify({ sessionId: sid(), appearance: readInterfaceForm() }) }); notify('تم حفظ هوية الواجهة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#resetUiThemeBtn')?.addEventListener('click', async () => {
      const defaults = { accent: '#5ed6c1', accent2: '#8b7cf6', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .28 };
      try { await api('/api/settings', { method: 'POST', body: JSON.stringify({ sessionId: sid(), appearance: defaults }) }); notify('تمت استعادة هوية الواجهة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    const controls = ['bgSpeed', 'bgDensity', 'bgGlow', 'bgIntensity', 'bgMouse', 'bgBrightness', 'bgContrast', 'bgSaturation', 'bgHue', 'bgBlur', 'bgOpacity'];
    controls.forEach((id) => $(`#${id}`)?.addEventListener('input', () => { updateRangeOutput(id); applyBackgroundLive(); }));
    $$('[data-bg-mode]').forEach((button) => button.addEventListener('click', () => { $$('[data-bg-mode]').forEach((item) => item.classList.remove('selected')); button.classList.add('selected'); applyBackgroundLive(); }));
    $('#bgInteractive')?.addEventListener('change', applyBackgroundLive);
    $('#bgTrail')?.addEventListener('change', applyBackgroundLive);
    $('#saveBackgroundBtn')?.addEventListener('click', async () => {
      try { const payload = readBackgroundForm(); await api('/api/settings/background', { method: 'POST', body: JSON.stringify({ sessionId: sid(), ...payload }) }); notify('تم حفظ وتطبيق المظهر.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#resetBackgroundBtn')?.addEventListener('click', async () => {
      try { await api('/api/settings/background', { method: 'POST', body: JSON.stringify({ sessionId: sid(), mode: 'aurora', settings: { speed: 1, density: 1, glow: .6, intensity: 1, mouseStrength: 1, brightness: 1, contrast: 1, saturation: 1, hueRotate: 0, blur: 0, interactive: true, trail: true }, opacity: .22, removeImage: true }) }); notify('تمت استعادة المظهر الافتراضي.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#removeCustomBackgroundBtn')?.addEventListener('click', async () => {
      if (!confirm('إزالة صورة الخلفية المخصصة؟')) return;
      try { await api('/api/settings/background', { method: 'POST', body: JSON.stringify({ sessionId: sid(), mode: state.data?.background?.mode || 'aurora', settings: state.data?.background?.settings || {}, opacity: state.data?.background?.opacity ?? .22, removeImage: true }) }); notify('تمت إزالة الصورة المخصصة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#customBackground')?.addEventListener('change', async (event) => {
      const file = event.target.files?.[0]; if (!file) return;
      const form = new FormData(); form.append('file', file); form.append('sessionId', sid());
      try { const result = await api('/api/background', { method: 'POST', body: form }); notify(result.message || 'تم تطبيق الخلفية.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
      finally { event.target.value = ''; }
    });
  }

  function updateRangeOutput(id) {
    const input = $(`#${id}`), output = $(`#${id}Out`); if (!input || !output) return;
    const step = Number(input.step || 1);
    output.value = Number(input.value).toFixed(step < 1 ? 2 : 0);
  }

  function readBackgroundForm() {
    return {
      mode: $('.bg-choice.selected')?.dataset.bgMode || state.data?.background?.mode || 'aurora',
      opacity: Number($('#bgOpacity').value),
      settings: {
        speed: Number($('#bgSpeed').value), density: Number($('#bgDensity').value), glow: Number($('#bgGlow').value), intensity: Number($('#bgIntensity').value), mouseStrength: Number($('#bgMouse').value),
        brightness: Number($('#bgBrightness').value), contrast: Number($('#bgContrast').value), saturation: Number($('#bgSaturation').value), hueRotate: Number($('#bgHue').value), blur: Number($('#bgBlur').value),
        interactive: $('#bgInteractive').checked, trail: $('#bgTrail').checked
      }
    };
  }

  function applyBackgroundLive() {
    if (state.bgLivePending) return;
    state.bgLivePending = requestAnimationFrame(() => {
      state.bgLivePending = 0;
      const data = readBackgroundForm();
      if (state.bgEngine) state.bgEngine.set(data);
    });
  }

  function bindSettings() {
    $$('[data-settings-view]').forEach((button) => button.addEventListener('click', () => {
      state.settingsView = button.dataset.settingsView === 'operation' ? 'operation' : 'appearance';
      render();
    }));
  }

  function bindOperation() {
    const save = async (payload) => {
      try { await api('/api/settings', { method: 'POST', body: JSON.stringify({ sessionId: sid(), ...payload }) }); notify('تم حفظ الإعدادات.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    };
    $('#saveOperationMain')?.addEventListener('click', () => save({ timezone: $('#opTimezone').value.trim(), sendOrder: $('#opSendOrder').value, autoStartSession: $('#opAutoStart').checked, automationEnabled: $('#opAutomation').checked }));
    $('#saveOperationReliability')?.addEventListener('click', () => save({ sendTimeoutMs: Number($('#opTimeout').value || 30000), retryAttempts: Number($('#opRetryAttempts').value || 2), retryDelayMs: Number($('#opRetryDelay').value || 1600), maxImageSizeMB: Number($('#opMaxSize').value || 100) }));
    $('#saveOperationQuiet')?.addEventListener('click', () => save({ interactionQuietEnabled: $('#opQuietEnabled').checked, interactionQuietStart: $('#opQuietStart').value, interactionQuietEnd: $('#opQuietEnd').value, interactionQuietAction: $('#opQuietAction').value, interactionQuietReply: $('#opQuietReply').value, interactionQuietCooldownSec: Number($('#opQuietCooldownSec').value || 300) }));
    $('#saveCommandTriggers')?.addEventListener('click', () => { const words = $('#opCommandTriggerWords').value.split(/[،,;|\n]/).map(x => x.trim()).filter(Boolean); if (!words.length) { notify('اكتب كلمة تشغيل واحدة على الأقل.', 'error'); return; } if ($('#opCommandTriggerRequired').checked && !$('#opCommandTriggerEnabled').checked) { notify('فعّل كلمات التشغيل أولًا قبل اشتراطها.', 'error'); return; } save({ commandTriggerEnabled: $('#opCommandTriggerEnabled').checked, commandTriggerRequired: $('#opCommandTriggerRequired').checked, commandTriggerWords: words.slice(0,12) }); });
  }

  function go(page) {
    const next = ['appearance', 'operation'].includes(page) ? 'settings' : page;
    if (page === 'appearance') state.settingsView = 'appearance';
    if (page === 'operation') state.settingsView = 'operation';
    state.page = next || 'dashboard';
    location.hash = state.page;
    render();
    const active = $$(`.navbtn[data-page=\"${String(state.page).replace(/[^a-z-]/g, '')}\"]`)[0];
    try { active?.scrollIntoView({ behavior: 'auto', inline: 'center', block: 'nearest' }); } catch {}
    if (state.page === 'people' || state.page === 'send') loadCountries().catch(() => {});
  }

  class BackgroundEngine {
    constructor(canvas) {
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d');
      this.mode = 'aurora';
      this.cfg = { speed: 1, density: 1, glow: .6, intensity: 1, mouseStrength: 1, brightness: 1, contrast: 1, saturation: 1, hueRotate: 0, blur: 0, interactive: true, trail: true };
      this.pointer = { x: .5, y: .5, down: false };
      this.reducedMotion = matchMedia?.('(prefers-reduced-motion: reduce)')?.matches || false;
      if (this.reducedMotion) this.cfg.interactive = false;
      this.t = 0; this.last = 0; this.lastDrawAt = 0; this.frameInterval = 100;
      this.resize = this.resize.bind(this); this.frame = this.frame.bind(this);
      addEventListener('resize', this.resize);
      this.pointerMovePending = false;
      addEventListener('pointermove', (event) => {
        if (this.pointerMovePending || !this.cfg.interactive) return;
        this.pointerMovePending = true;
        requestAnimationFrame(() => { this.pointerMovePending = false; this.pointer.x = event.clientX / innerWidth; this.pointer.y = event.clientY / innerHeight; });
      }, { passive: true });
      addEventListener('pointerdown', () => { this.pointer.down = true; });
      addEventListener('pointerup', () => { this.pointer.down = false; });
      this.resize(); requestAnimationFrame(this.frame);
    }
    resize() { const scale = 1; const w = innerWidth, h = innerHeight; if (w === this.w && h === this.h) return; this.w = w; this.h = h; this.canvas.width = Math.max(1, Math.floor(this.w * scale)); this.canvas.height = Math.max(1, Math.floor(this.h * scale)); this.ctx.setTransform(scale, 0, 0, scale, 0, 0); }
    set(data) {
      if (!data) return;
      this.mode = data.mode || this.mode;
      const scene = $('#bgScene'); if (scene) scene.dataset.mode = this.mode;
      this.cfg = { ...this.cfg, ...(data.settings || {}) };
      const filter = `brightness(${this.cfg.brightness ?? 1}) contrast(${this.cfg.contrast ?? 1}) saturate(${this.cfg.saturation ?? 1}) hue-rotate(${this.cfg.hueRotate ?? 0}deg) blur(${this.cfg.blur ?? 0}px)`;
      this.canvas.style.filter = filter;
      const image = $('#bgImageLayer');
      if (image) {
        image.style.opacity = String(data.opacity ?? .22);
        image.style.filter = filter;
        if (Object.prototype.hasOwnProperty.call(data, 'imageUrl')) image.style.backgroundImage = data.imageUrl ? `url("${String(data.imageUrl).replace(/"/g, '%22')}")` : '';
      }
    }
    frame(ms) { if (document.hidden) { requestAnimationFrame(this.frame); return; } if (ms - this.lastDrawAt >= this.frameInterval) { const dt = Math.min(50, ms - (this.last || ms)); this.last = ms; this.lastDrawAt = ms; this.t += dt * .001 * Number(this.cfg.speed || 1); this.draw(); } requestAnimationFrame(this.frame); }
    clear() { this.ctx.fillStyle = `rgba(4,8,18,${this.cfg.trail ? .13 : .25})`; this.ctx.fillRect(0, 0, this.w, this.h); }
    draw() {
      const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, px = .5 + (this.pointer.x - .5) * Number(c.mouseStrength ?? 1), py = .5 + (this.pointer.y - .5) * Number(c.mouseStrength ?? 1);
      x.save(); this.clear(); x.globalCompositeOperation = 'source-over';
      if (this.mode === 'aurora') this.aurora(px, py); else if (this.mode === 'nebula') this.nebula(px, py); else if (this.mode === 'meteor') this.meteor(px, py); else if (this.mode === 'matrix') this.matrix(px, py); else if (this.mode === 'cyber-grid') this.grid(px, py); else if (this.mode === 'plasma') this.plasma(px, py); else if (this.mode === 'starfield') this.stars(px, py); else if (this.mode === 'vortex') this.vortex(px, py); else if (this.mode === 'galaxy') this.galaxy(px, py); else this.ocean(px, py);
      if (c.interactive) { x.beginPath(); x.arc(px * w, py * h, 18 + Math.sin(t * 4) * 5, 0, Math.PI * 2); x.strokeStyle = `rgba(170,235,255,${.08 * c.intensity})`; x.lineWidth = 1.2 + c.glow * 1.4; x.stroke(); if (this.pointer.down) { x.beginPath(); x.arc(px * w, py * h, 42 + Math.sin(t * 9) * 8, 0, Math.PI * 2); x.strokeStyle = `rgba(210,160,255,${.16 * c.intensity})`; x.stroke(); } } x.restore();
    }
    aurora(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, shift = (px - .5) * 80; for (let k = 0; k < Math.max(2, Math.round(2 + c.density * 2)); k++) { x.beginPath(); for (let i = 0; i <= w; i += 12) x.lineTo(i, h * (.22 + k * .16) + (py - .5) * 45 + Math.sin(i * .008 + t * (.7 + k * .2) + shift * .003) * 35 + Math.sin(i * .002 - t * .35) * 24); x.strokeStyle = `hsla(${165 + k * 45},90%,65%,${.055 * c.intensity})`; x.lineWidth = 55; x.shadowBlur = 24 * c.glow; x.stroke(); } }
    nebula(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(34 * c.density); for (let i = 0; i < n; i++) { const a = (i * 12.9898) % 6.283, r = ((i * 37.13) % 1) * Math.min(w, h) * .48, q = t * (.2 + (i % 7) / 35), cx = w * (.5 + (px - .5) * .08), cy = h * (.5 + (py - .5) * .08), vx = cx + Math.cos(a + q) * r, vy = cy + Math.sin(a + q * .8) * r * .65, z = 2 + ((i * 17) % 8); x.fillStyle = `hsla(${205 + (i % 4) * 32},90%,70%,${.12 * c.intensity})`; x.beginPath(); x.arc(vx, vy, z, 0, Math.PI * 2); x.fill(); } }
    meteor(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(18 * c.density), bias = (px - .5) * 80; for (let i = 0; i < n; i++) { const speed = 70 + (i % 9) * 18, vx = (i * 97 + t * speed * 1.8 + bias) % (w + 300) - 150, vy = (i * 43 + t * speed * .7 + (py - .5) * 50) % (h + 120) - 60; x.beginPath(); x.moveTo(vx, vy); x.lineTo(vx - speed * .28, vy - speed * .11); x.strokeStyle = `hsla(${185 + (i % 5) * 25},95%,70%,${.18 * c.intensity})`; x.lineWidth = 1 + (i % 3); x.stroke(); } }
    matrix(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, cols = Math.floor(58 * c.density), step = Math.max(13, w / Math.max(cols, 1)); x.font = '15px monospace'; for (let i = 0; i < cols; i++) { const y = (i * 79 + t * (55 + (i % 7) * 6) + (py - .5) * 100) % (h + 220) - 220; x.fillStyle = `rgba(110,231,249,${.2 * c.intensity})`; x.fillText(String.fromCharCode(0x30a0 + (i * 13) % 90), i * step, y); } }
    grid(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, step = Math.max(38, 112 - c.density * 45), oy = (t * 35 + (py - .5) * 50) % step, ox = (t * 18 + (px - .5) * 50) % step; x.strokeStyle = `rgba(110,231,249,${.09 * c.intensity})`; for (let y = -step + oy; y < h + step; y += step) { x.beginPath(); x.moveTo(0, y); x.lineTo(w, y); x.stroke(); } for (let xx = -step + ox; xx < w + step; xx += step) { x.beginPath(); x.moveTo(xx, 0); x.lineTo(xx, h); x.stroke(); } }
    plasma(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg; for (let k = 0; k < Math.max(3, Math.round(4 + c.density * 4)); k++) { x.beginPath(); for (let i = 0; i <= w; i += 10) x.lineTo(i, h * (.15 + k * .12) + (py - .5) * 35 + Math.sin(i * .012 + t * (1 + k * .07) + (px - .5)) * 26 + Math.sin(i * .004 - t * .6) * 22); x.strokeStyle = `hsla(${190 + k * 24},85%,62%,${.07 * c.intensity})`; x.lineWidth = 18; x.stroke(); } }
    stars(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(56 * c.density); for (let i = 0; i < n; i++) { const z = ((i * 31 + t * 14) % 100) / 100, r = .3 + z * 2.5, vx = (i * 97.31 + (px - .5) * 40) % w, vy = (i * 47.21 + (py - .5) * 40) % h; x.fillStyle = `rgba(220,240,255,${.15 + z * .6})`; x.beginPath(); x.arc(vx, vy, r, 0, Math.PI * 2); x.fill(); } }
    vortex(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(52 * c.density), cx = w * (.5 + (px - .5) * .18), cy = h * (.5 + (py - .5) * .12); for (let i = 0; i < n; i++) { const p = i / n, a = p * Math.PI * 10 + t * (.3 + p), r = p * Math.min(w, h) * .42, vx = cx + Math.cos(a) * r, vy = cy + Math.sin(a) * r * .62; x.fillStyle = `hsla(${190 + p * 130},95%,68%,${.11 * c.intensity})`; x.beginPath(); x.arc(vx, vy, 1 + p * 2.5, 0, Math.PI * 2); x.fill(); } }
    galaxy(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(72 * c.density), cx = w * (.5 + (px - .5) * .14), cy = h * (.5 + (py - .5) * .1); for (let i = 0; i < n; i++) { const p = i / n, a = i * .55 + t * (.45 + p), r = p * Math.min(w, h) * .46 + Math.sin(i * 2.7) * 4, vx = cx + Math.cos(a) * r, vy = cy + Math.sin(a) * r * .42; x.fillStyle = `hsla(${190 + (i % 6) * 22},90%,72%,${.08 + c.intensity * .08})`; x.beginPath(); x.arc(vx, vy, .5 + p * 2.2, 0, Math.PI * 2); x.fill(); } }
    ocean(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg; for (let k = 0; k < 3; k++) { x.beginPath(); for (let i = 0; i <= w; i += 10) x.lineTo(i, h * (.52 + k * .07) + (py - .5) * 40 + Math.sin(i * .009 + t * (.65 + k * .05) + px * 2) * 18 + Math.sin(i * .003 - t * .45) * 10); x.strokeStyle = `hsla(${180 + k * 8},85%,65%,${.055 * c.intensity})`; x.lineWidth = 10 + c.glow * 10; x.stroke(); } }
  }

  function applyInterfaceTheme(data = state.data) {
    const a = data?.settings?.appearance || {};
    const root = document.documentElement;
    root.dataset.uiMode = state.uiMode || 'dark';
    root.style.setProperty('--accent', a.accent || '#5ed6c1');
    root.style.setProperty('--accent-2', a.accent2 || '#8b7cf6');
    root.style.setProperty('--panel-opacity', String(a.panelOpacity ?? .88));
    root.style.setProperty('--panel-blur', `${Number(a.panelBlur ?? 14)}px`);
    root.style.setProperty('--radius', `${Number(a.radius ?? 18)}px`);
    root.style.setProperty('--ui-glow', String(Number(a.glow ?? .55)));
  }

  function readInterfaceForm() {
    return {
      accent: $('#uiAccent')?.value || '#5ed6c1',
      accent2: $('#uiAccent2')?.value || '#8b7cf6',
      panelOpacity: Number($('#uiPanelOpacity')?.value || .88),
      panelBlur: Number($('#uiPanelBlur')?.value || 14),
      radius: Number($('#uiRadius')?.value || 18),
      glow: Number($('#uiGlow')?.value || .55),
    };
  }

  function applyInterfaceLive() { applyInterfaceTheme({ settings: { appearance: readInterfaceForm() } }); }

  function setupBackground() {
    const canvas = $('#bgCanvas'); if (!canvas) return;
    if (!state.bgEngine) state.bgEngine = new BackgroundEngine(canvas);
    if (state.data?.background) state.bgEngine.set(state.data.background);
  }

  async function boot() {
    try {
      await loadCountries().catch(() => null);
      await load();
      addEventListener('hashchange', () => { state.page = location.hash.slice(1) || 'dashboard'; render(); });
    } catch (error) {
      document.body.innerHTML = `<div class="fatal"><h1>تعذر تشغيل الواجهة</h1><p>${esc(error.message)}</p><button class="btn primary" onclick="location.reload()">إعادة المحاولة</button></div>`;
    }
  }

  boot();
})();
