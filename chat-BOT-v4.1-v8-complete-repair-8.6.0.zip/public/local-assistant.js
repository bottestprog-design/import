/*
 * Local command assistant — runs entirely in the browser.
 * No AI provider, API key, remote model or eval/Function execution is used here.
 * Commands are declarative, validated data; app actions are allow-listed in app.js.
 */
(() => {
  'use strict';
  const COMMANDS_KEY = 'chatbot-local-assistant-commands-v1';
  const MESSAGES_KEY = 'chatbot-local-assistant-messages-v1';
  const MAX_MESSAGES = 250;
  const memoryStorage = new Map();
  const MAX_COMMANDS = 1000;

  const normalize = (value) => String(value ?? '')
    .normalize('NFKC')
    .toLocaleLowerCase('ar')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/[؟?!.,،؛:：؛()[\]{}"'`]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const BUILTIN_COMMANDS = [
    { id:'builtin-help', name:'المساعدة', triggers:['مساعدة','ساعدني','الاوامر المتاحة','كيف استخدمك','help','/help'], description:'عرض ما يستطيع المساعد المحلي فعله.', action:'help', builtIn:true },
    { id:'builtin-list', name:'عرض الأوامر', triggers:['اعرض الاوامر','قائمة الاوامر','كل الاوامر','show commands','/commands'], description:'فتح مكتبة الأوامر المحفوظة.', action:'list', builtIn:true },
    { id:'builtin-dashboard', name:'افتح الرئيسية', triggers:['الرئيسية','افتح الرئيسية','افتح لوحة التحكم','لوحة التحكم','dashboard','/dashboard'], description:'الانتقال إلى الصفحة الرئيسية.', action:'navigate', page:'dashboard', builtIn:true },
    { id:'builtin-send', name:'افتح الإرسال', triggers:['الارسال','افتح الارسال','رسالة جديدة','اذهب للارسال','send','/send'], description:'فتح نموذج الرسالة والإرسال.', action:'navigate', page:'send', builtIn:true },
    { id:'builtin-people', name:'افتح الأشخاص', triggers:['الاشخاص','افتح الاشخاص','جهات الاتصال','المستلمين','اضافة شخص','people'], description:'إدارة جهات الإرسال والأرقام.', action:'navigate', page:'people', builtIn:true },
    { id:'builtin-groups', name:'افتح المجموعات', triggers:['المجموعات','افتح المجموعات','whatsapp groups','groups'], description:'اكتشاف وإدارة مجموعات WhatsApp.', action:'navigate', page:'groups', builtIn:true },
    { id:'builtin-interaction', name:'افتح التفاعل', triggers:['التفاعل','افتح التفاعل','الرد التلقائي','قواعد الرد','interaction'], description:'إدارة قواعد الرسائل والـ Reactions.', action:'navigate', page:'interaction', builtIn:true },
    { id:'builtin-session', name:'افتح الجلسة', triggers:['الجلسة','افتح الجلسة','اتصال واتساب','صفحة الاتصال','session','qr','كيو ار'], description:'فتح صفحة اتصال WhatsApp.', action:'navigate', page:'session', builtIn:true },
    { id:'builtin-settings', name:'افتح الإعدادات', triggers:['الاعدادات','افتح الاعدادات','settings'], description:'فتح إعدادات المشروع.', action:'navigate', page:'settings', builtIn:true },
    { id:'builtin-appearance', name:'افتح المظهر', triggers:['المظهر','افتح المظهر','الخلفيات','الوان الواجهة','appearance'], description:'فتح تخصيص المظهر والخلفية.', action:'navigate', page:'appearance', builtIn:true },
    { id:'builtin-operation', name:'افتح التشغيل المتقدم', triggers:['التشغيل المتقدم','اعدادات التشغيل','الموثوقية','operation'], description:'فتح خيارات التشغيل والموثوقية.', action:'navigate', page:'operation', builtIn:true },
    { id:'builtin-status', name:'حالة الاتصال', triggers:['حالة الاتصال','هل واتساب متصل','هل انا متصل','حالة واتساب','connection status','/status'], description:'قراءة حالة الجلسة المحلية الحالية.', action:'status', builtIn:true },
    { id:'builtin-summary', name:'ملخص الجلسة', triggers:['ملخص الجلسة','ملخص الحالة','ملخص سريع','اعطني ملخص','session summary'], description:'عرض ملخص المستلمين والمجموعات والعمليات المسجلة.', action:'summary', builtIn:true },
    { id:'builtin-refresh', name:'تحديث البيانات', triggers:['تحديث البيانات','حدث البيانات','اعادة تحميل البيانات','حدّث','refresh','/refresh'], description:'قراءة أحدث البيانات من المشروع المحلي.', action:'refresh', builtIn:true },
    { id:'builtin-light', name:'الوضع الفاتح', triggers:['الوضع الفاتح','فعل الوضع الفاتح','خلي الواجهة فاتحة','light mode'], description:'تشغيل المظهر الفاتح.', action:'theme', theme:'light', builtIn:true },
    { id:'builtin-dark', name:'الوضع الداكن', triggers:['الوضع الداكن','فعل الوضع الداكن','خلي الواجهة داكنة','dark mode'], description:'تشغيل المظهر الداكن.', action:'theme', theme:'dark', builtIn:true },
    { id:'builtin-theme-toggle', name:'بدّل المظهر', triggers:['بدل المظهر','غير المظهر','تبديل الوضع','toggle theme'], description:'التبديل بين المظهر الفاتح والداكن.', action:'theme', theme:'toggle', builtIn:true },
    { id:'builtin-files', name:'افتح الملفات', triggers:['الملفات','الوسائط','ادارة الملفات','افتح الملفات'], description:'فتح مكتبة الوسائط داخل صفحة الإرسال.', action:'navigate', page:'send', builtIn:true },
    { id:'builtin-schedule', name:'افتح المواعيد', triggers:['المواعيد','الجدولة','المهام المجدولة','افتح المواعيد','schedule'], description:'فتح الإرسال ثم قسم المواعيد المحفوظة.', action:'schedule', builtIn:true },
    { id:'builtin-logs', name:'افتح السجل', triggers:['السجل','سجل النشاط','الاحداث','logs'], description:'فتح صفحة الجلسة لمراجعة حالة الاتصال والنشاط.', action:'navigate', page:'session', builtIn:true },
    { id:'builtin-privacy', name:'شرح الخصوصية', triggers:['الخصوصية','هل تحتاج api','هل تحتاج ذكاء اصطناعي','هل تعمل بدون api','بدون api'], description:'شرح ما يعمل محليًا وما يحتاج اتصال WhatsApp.', action:'privacy', builtIn:true },
    { id:'builtin-new-command', name:'حفظ أمر جديد', triggers:['حفظ امر جديد','اضافة امر محفوظ','علمني امر','علمني امر جديد','create command'], description:'فتح نموذج إنشاء أمر محلي محفوظ.', action:'new-command', builtIn:true },
    { id:'builtin-clear-chat', name:'مسح سجل هذه المحادثة', triggers:['امسح المحادثة','مسح المحادثة','امسح سجل الشات','clear chat'], description:'مسح سجل محادثة المساعد فقط دون حذف الأوامر.', action:'clear-chat', builtIn:true },
    { id:'builtin-send-help', name:'كيف أرسل رسالة؟', triggers:['كيف ارسل رسالة','علمني الارسال','طريقة الارسال','كيف استخدم الارسال'], description:'فتح نموذج الإرسال وإظهار شرح مختصر.', action:'send-help', builtIn:true },
    { id:'builtin-add-person-help', name:'كيف أضيف شخصًا؟', triggers:['كيف اضيف شخص','طريقة اضافة مستلم','اضافة رقم','كيف اضيف رقم'], description:'فتح صفحة الأشخاص.', action:'navigate', page:'people', builtIn:true },
    { id:'builtin-connect-help', name:'كيف أربط WhatsApp؟', triggers:['كيف اربط واتساب','ربط الحساب','طريقة الاتصال','وصل واتساب'], description:'فتح صفحة الجلسة والاتصال.', action:'navigate', page:'session', builtIn:true },
    { id:'builtin-show-library', name:'افتح مكتبة الأوامر', triggers:['مكتبة الاوامر','ادارة الاوامر','ادارة المكتبة','command library'], description:'الانتقال إلى مكتبة الأوامر وإدارتها.', action:'library', builtIn:true },
    { id:'builtin-new-chat', name:'ابدأ محادثة جديدة', triggers:['محادثة جديدة','شات جديد','ابدأ من جديد','new chat'], description:'مسح سجل محادثة المساعد الحالي فقط.', action:'clear-chat', builtIn:true },
    { id:'builtin-home', name:'العودة للرئيسية', triggers:['ارجع للرئيسية','عوده للرئيسية','رجوع للرئيسية','home'], description:'الرجوع إلى لوحة التحكم.', action:'navigate', page:'dashboard', builtIn:true },
    { id:'builtin-toggle-details', name:'فتح إعدادات التشغيل', triggers:['خيارات متقدمة','اعدادات متقدمة','التفاصيل المتقدمة'], description:'فتح الإعدادات المتقدمة.', action:'navigate', page:'operation', builtIn:true },
  ];

  const isSafeText = (v, max = 4000) => typeof v === 'string' && v.length <= max;
  function validateCustomCommand(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('بيانات الأمر غير صالحة.');
    const name = String(raw.name || '').trim().slice(0, 90);
    const triggerSource = Array.isArray(raw.triggers) ? raw.triggers.join('|') : String(raw.triggers || '');
    const triggers = [...new Set(triggerSource.split('|').map(normalize).filter(Boolean))].slice(0, 30);
    const action = String(raw.action || 'reply');
    const validActions = new Set(['navigate','reply','draft','status','refresh','theme']);
    const validPages = new Set(['dashboard','send','people','groups','interaction','session','settings','appearance','operation','assistant']);
    if (!name) throw new Error('اكتب اسمًا للأمر.');
    if (!triggers.length) throw new Error('أدخل كلمة أو عبارة لتشغيل الأمر.');
    if (triggers.some((x) => x.length > 120)) throw new Error('كل عبارة تشغيل يجب أن تكون أقل من 120 حرفًا.');
    if (!validActions.has(action)) throw new Error('نوع تنفيذ الأمر غير مدعوم.');
    const command = { id: String(raw.id || `cmd-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`).slice(0, 100), name, triggers, action, description: String(raw.description || '').trim().slice(0, 300), response: String(raw.response || '').slice(0, 4000), page: validPages.has(raw.page) ? raw.page : 'dashboard', theme: ['light','dark','toggle'].includes(raw.theme) ? raw.theme : 'toggle', builtIn: false, createdAt: raw.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString() };
    if ((action === 'reply' || action === 'draft') && !command.response.trim()) throw new Error('أدخل النص الذي سيستخدمه هذا الأمر.');
    return command;
  }
  function safeRead(key, fallback) { try { const value = JSON.parse(localStorage.getItem(key) || 'null'); return value == null ? (memoryStorage.has(key) ? memoryStorage.get(key) : fallback) : value; } catch { return memoryStorage.has(key) ? memoryStorage.get(key) : fallback; } }
  function safeWrite(key, value) { const serialized = JSON.stringify(value); try { localStorage.setItem(key, serialized); } catch { memoryStorage.set(key, JSON.parse(serialized)); } }
  function loadCommands() {
    const rows = safeRead(COMMANDS_KEY, []);
    if (!Array.isArray(rows)) return [];
    return rows.filter((row) => row && typeof row === 'object' && typeof row.name === 'string' && Array.isArray(row.triggers) && ['navigate','reply','draft','status','refresh','theme'].includes(row.action)).slice(0, MAX_COMMANDS).map((row) => {
      try { return validateCustomCommand({ ...row, triggers: row.triggers.join(' | ') }); } catch { return null; }
    }).filter(Boolean);
  }
  function saveCommands(rows) {
    if (!Array.isArray(rows) || rows.length > MAX_COMMANDS) throw new Error(`الحد الأقصى ${MAX_COMMANDS} أمرًا محفوظًا.`);
    const checked = rows.map((row) => validateCustomCommand(row));
    safeWrite(COMMANDS_KEY, checked);
    return checked;
  }
  function loadMessages() {
    const rows = safeRead(MESSAGES_KEY, []);
    return Array.isArray(rows) ? rows.filter((m) => m && ['user','assistant','system'].includes(m.role) && typeof m.text === 'string').slice(-MAX_MESSAGES).map((m) => ({ role:m.role, text:m.text.slice(0,8000), at:Number(m.at)||Date.now() })) : [];
  }
  function saveMessages(rows) {
    const bounded = rows.slice(-MAX_MESSAGES).map((m) => ({ role: ['user','assistant','system'].includes(m.role) ? m.role : 'assistant', text:String(m.text ?? '').slice(0,8000), at:Number(m.at)||Date.now() }));
    safeWrite(MESSAGES_KEY, bounded);
    return bounded;
  }
  function findCommand(text, customCommands = []) {
    const input = normalize(text);
    if (!input) return null;
    const candidates = [...customCommands, ...BUILTIN_COMMANDS];
    let best = null;
    for (const command of candidates) {
      const triggers = Array.isArray(command.triggers) ? command.triggers : [];
      for (const raw of triggers) {
        const trigger = normalize(raw);
        if (!trigger) continue;
        const match = input === trigger || (trigger.length >= 4 && (` ${input} `).includes(` ${trigger} `));
        if (match && (!best || trigger.length > best.trigger.length || (trigger.length === best.trigger.length && !command.builtIn && best.command.builtIn))) best = { command, trigger };
      }
    }
    return best?.command || null;
  }
  function classify(text, customCommands = []) {
    const raw = String(text ?? '').trim();
    const input = normalize(raw);
    if (!input) return { type:'empty' };
    const draft = raw.match(/^(?:جهز|جهّز|حضّر|حضر|اكتب|اكتبلي|جهزلي)\s+(?:رسالة|مسودة)(?:\s*[:：-]\s*|\s+)(.+)$/i);
    if (draft && draft[1].trim()) return { type:'draft', text:draft[1].trim() };
    const search = raw.match(/^(?:ابحث|بحث|دور)\s+(?:عن\s+)?(.+)$/i);
    if (search && normalize(search[1])) return { type:'search', query:search[1].trim() };
    const found = findCommand(input, customCommands);
    if (found) return { type:'command', command:found };
    const navigation = [
      {page:'dashboard',words:['الرئيسية','لوحة التحكم']},{page:'send',words:['الارسال','رسالة جديدة']},{page:'people',words:['الاشخاص','المستلمين','جهات الاتصال']},
      {page:'groups',words:['المجموعات']},{page:'interaction',words:['التفاعل','الرد التلقائي']},{page:'session',words:['الجلسة','الاتصال','qr']},
      {page:'settings',words:['الاعدادات']},{page:'appearance',words:['المظهر','الخلفية']},{page:'operation',words:['التشغيل المتقدم','الموثوقية']},{page:'assistant',words:['المساعد المحلي','شات الاوامر']},
    ];
    if (/^(افتح|روح|اذهب|انتقل|اعرض|وريني|وديني)(?:\s|$)/.test(input)) {
      const match = navigation.find((item) => item.words.some((word) => input.includes(normalize(word))));
      if (match) return { type:'navigate', page:match.page };
    }
    if (/(?:حالة|متصل|الاتصال).*(?:واتساب|الجلسة|اتصال)|(?:واتساب|الجلسة).*(?:متصل|حالة)/.test(input)) return { type:'status' };
    if (input === 'تحديث' || input === 'حدث' || input === 'اعادة تحميل') return { type:'refresh' };
    return { type:'unknown', text:raw };
  }
  window.LocalAssistantEngine = Object.freeze({ COMMANDS_KEY, MESSAGES_KEY, BUILTIN_COMMANDS, normalize, validateCustomCommand, loadCommands, saveCommands, loadMessages, saveMessages, findCommand, classify, MAX_COMMANDS, MAX_MESSAGES });
})();
