# Changelog — media, sending, and groups (8.3.0)

- Added drag-and-drop and multi-file selection to the media drop zone.
- Preserved image aspect ratios in library previews; added inline PDF, TXT excerpt, video, and audio previews; full-size image link remains available.
- Added file selection removal distinct from deleting the source file from the library. Added selection counters and clear controls.
- Added main-text placement modes: automatic, before files, after files, or none; image captions are used only where valid.
- Fixed recipient target resolution for legacy contacts and corrected outgoing ACK/chat matching to use the recipient chat.
- Added upload enforcement for the session-configured maximum file size and clear UI labeling of the actual limit.
- Improved group/member detail navigation, search, pagination, copy-ID tools, status filters and bulk management.
- Sending requires explicit targets; an empty selection never means “send to everybody.”
- Added regression tests for representative send cases and message identifier routing.
