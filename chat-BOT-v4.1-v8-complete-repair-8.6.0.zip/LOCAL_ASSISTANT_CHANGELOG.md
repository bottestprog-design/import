# Local Assistant — change log

## 8.2.0 — 2026-10-15

- Added a dedicated Arabic RTL command-chat page within the application.
- Added 30 built-in local commands for navigation, status, summaries, refresh, theme switching, draft preparation, privacy guidance and command-library management.
- Added a local command library for up to 1,000 custom commands with multiple trigger phrases, search, create, edit and delete.
- Added import/export for custom command JSON and export for the conversation history.
- Added browser-local conversation history capped at 250 messages.
- Added safe allow-listed command actions (navigate, saved reply, draft preparation, status, local refresh, theme). No arbitrary script, shell command or external AI provider is invoked by the command engine.
- Draft preparation opens the existing send page and fills the text field; it never sends a WhatsApp message automatically.
- Added tests for Arabic normalization, command routing, draft parsing, command persistence, history trimming and rejection of unsupported actions.
