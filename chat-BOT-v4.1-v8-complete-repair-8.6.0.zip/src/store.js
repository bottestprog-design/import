"use strict";
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ROOT = path.resolve(__dirname, '..');
const DATA_DIR = path.join(ROOT, 'data');
const SESSIONS_DIR = path.join(DATA_DIR, 'sessions');
const APP_VERSION = '8.6.0';
fs.mkdirSync(SESSIONS_DIR, { recursive: true });
const DEFAULT_SETTINGS = {
  timezone: 'Asia/Muscat', scheduleEnabled: false, scheduleMode: 'weekly', scheduleDay: 5, scheduleMonthDay: 1, scheduleTime: '17:30', scheduleDate: '', scheduleGraceMinutes: 30, scheduleTargetKeys: [], scheduleMediaId: '', schedulePreText: '', schedulePostText: '', scheduledGroupsEnabled: true,
  preText: 'chat BOT', postText: '', sendOrder: 'target-first', sendTimeoutMs: 30000, sendDelayMs: 700, retryAttempts: 2, retryDelayMs: 1600, maxImageSizeMB: 100,
  autoStartSession: true, automationEnabled: true, interactionEnabled: true, groupAssistantEnabled: true, interactionIgnoreOwn: true, interactionUseRecipientNames: true, interactionScope: 'all', interactionChatIds: [], maxActionsPerMinute: 20,
  commandTriggerEnabled: true, commandTriggerWords: ['يا بوت', 'شات بوت', 'chat bot'], commandTriggerRequired: false,
  interactionCooldownCapSec: 86400, interactionQuietEnabled: false, interactionQuietStart: '23:00', interactionQuietEnd: '07:00', interactionQuietAction: 'silence', interactionQuietReply: 'أنا في فترة الهدوء الآن، سأرد عليك لاحقًا.', interactionQuietCooldownSec: 300, interactionFallbackEnabled: true, interactionFallbackCooldownSec: 300, interactionFallbackReply: 'أهلًا {{sender}} 👋 وصلتني رسالتك: «{{message}}». سأتابع معك حسب الردود التلقائية المتاحة.',
  backgroundMode: 'aurora', backgroundImage: '', backgroundOpacity: .22,
  appearance: { accent: '#5ed6c1', accent2: '#8b7cf6', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .28 },
  backgroundSettings: { speed: 1, density: 1, glow: .6, intensity: 1, mouseStrength: 1, brightness: 1, contrast: 1, saturation: 1, hueRotate: 0, blur: 0, interactive: true, trail: true }
};
function clone(x) { return JSON.parse(JSON.stringify(x)); }
function normalizeRecipientAutoReply(value) {
  const x = value && typeof value === 'object' ? value : {};
  const mode = ['inherit', 'off', 'custom'].includes(String(x.mode || '')) ? String(x.mode) : 'inherit';
  const allowedMatches = new Set(['any', 'contains', 'exact', 'starts', 'ends']);
  const rules = (Array.isArray(x.rules) ? x.rules : []).slice(0, 30).map((rule, index) => {
    const item = rule && typeof rule === 'object' ? rule : {};
    const match = allowedMatches.has(String(item.match || 'contains')) ? String(item.match || 'contains') : 'contains';
    return { id: String(item.id || crypto.randomUUID()), enabled: item.enabled !== false, name: String(item.name || `قاعدة ${index + 1}`).trim().slice(0, 80), match, value: String(item.value || '').slice(0, 500), reply: String(item.reply || '').slice(0, 60000), cooldownSec: toInt(item.cooldownSec, 0, 0, 86400) };
  }).filter(rule => rule.reply.trim() && (rule.match === 'any' || rule.value.trim()));
  return { mode, rules, fallbackReply: String(x.fallbackReply || '').slice(0, 60000), conversationEnabled: x.conversationEnabled === true, fallbackToGlobal: x.fallbackToGlobal !== false, cooldownSec: toInt(x.cooldownSec, 0, 0, 86400) };
}
function safeSessionId(id) { return String(id || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 80) || 'main'; }
function getPaths(id) { const sid = safeSessionId(id), dir = path.join(SESSIONS_DIR, sid); return { id: sid, dir, json: path.join(dir, 'session.json'), auth: path.join(dir, 'auth'), media: path.join(dir, 'media'), images: path.join(dir, 'media'), backgrounds: path.join(dir, 'backgrounds'), avatars: path.join(dir, 'avatars'), logFile: path.join(dir, 'activity.log') }; }
function defaults(id, name) { return { schemaVersion: 7, id: safeSessionId(id), name: String(name || 'جلسة جديدة').slice(0, 80), setupComplete: false, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), settings: clone(DEFAULT_SETTINGS), ownerAssistant: { ownerPhone: '', ownerPhoneConfirmed: false, notificationsEnabled: true, notificationMode: 'self', welcomeCreatedAt: '', welcomeSentAt: '', welcomeAttemptedAt: '', conversation: null, replySessionId: '', replySessionEnabled: false, replySessionConfirmedAt: '', linkedProcessedMessageIds: [], messages: [], issues: [], activity: [], pendingNotifications: [] }, recipients: [], groups: [], cycle: { round: 1, roundStartedAt: new Date().toISOString(), imageOrder: [], currentIndex: 0, delivery: {}, manualGuard: {} }, interaction: { enabled: true, rules: seedRules(), recent: [] }, stats: { sentMessages: 0, sentImages: 0, sentFiles: 0, confirmedAcks: 0, createdSends: 0, uncertainSends: 0, failedSends: 0, successfulRuns: 0, failedRuns: 0, interactionActions: 0, interactionErrors: 0 }, automation: { enabled: true, tasks: [], recent: [] }, logs: [], lastRun: null, lastBackup: null, scheduleState: { lastRunKey: '' } }; }
function seedRules() { return [
  { id: crypto.randomUUID(), name: 'ترحيب', enabled: true, priority: 30, when: { type: 'message', match: 'contains', value: 'السلام عليكم' }, then: { reply: 'وعليكم السلام {{sender}} 👋' }, scope: 'all', chatIds: [], cooldownSec: 45 },
  { id: crypto.randomUUID(), name: 'تحية', enabled: true, priority: 25, when: { type: 'message', match: 'contains', value: 'مرحبا' }, then: { reply: 'أهلًا {{sender}} ✨' }, scope: 'all', chatIds: [], cooldownSec: 45 },
  { id: crypto.randomUUID(), name: 'مساعدة البوت', enabled: true, priority: 20, when: { type: 'message', match: 'exact', value: '!help' }, then: { reply: 'الأوامر: !help — !gid — !group id\nيمكنك أيضًا استخدام قواعد التفاعل من لوحة التحكم.' }, scope: 'all', chatIds: [], cooldownSec: 30 }
]; }
function ensureDir(id) { const p = getPaths(id); for (const k of ['dir', 'media', 'backgrounds', 'avatars', 'auth']) fs.mkdirSync(p[k], { recursive: true }); return p; }
function saveSession(s) { const id = safeSessionId(s.id), p = ensureDir(id); const out = { ...s, schemaVersion: 7, id, updatedAt: new Date().toISOString() }; const tmp = p.json + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(out, null, 2), 'utf8'); fs.renameSync(tmp, p.json); return out; }
function loadSession(id) { const sid = safeSessionId(id), p = ensureDir(sid); if (!fs.existsSync(p.json)) return saveSession(defaults(sid, sid === 'main' ? 'الجلسة الرئيسية' : 'جلسة جديدة')); try { const s = JSON.parse(fs.readFileSync(p.json, 'utf8')); return normalizeSession(s, sid); } catch { const bad = p.json + '.broken-' + Date.now(); try { fs.renameSync(p.json, bad); } catch {} return saveSession(defaults(sid, 'جلسة مستعادة')); } }

function validWhatsAppAvatar(value) {
  try {
    if (!value) return '';
    const url = new URL(String(value));
    if (url.protocol !== 'https:' || !/(?:\.|^)(?:whatsapp\.net|fbcdn\.net)$/i.test(url.hostname)) return '';
    return url.toString().slice(0, 2000);
  } catch { return ''; }
}

function normalizeAutomationTask(t) {
  const x = t || {}, mode = ['weekly', 'monthly', 'yearly', 'once'].includes(String(x.mode || '')) ? String(x.mode) : 'weekly';
  const time = /^\d{2}:\d{2}$/.test(String(x.time || '')) ? String(x.time) : '17:30';
  return {
    id: String(x.id || crypto.randomUUID()), name: String(x.name || 'موعد جديد').trim().slice(0, 100) || 'موعد جديد', enabled: x.enabled !== false,
    mode, time, date: String(x.date || ''), day: toInt(x.day, 5, 0, 6), dayOfMonth: toInt(x.dayOfMonth, 1, 1, 31), month: x.month === '' || x.month == null ? '' : toInt(x.month, 1, 1, 12), year: x.year === '' || x.year == null ? '' : toInt(x.year, new Date().getFullYear(), 2020, 2100),
    targetKeys: Array.isArray(x.targetKeys) ? [...new Set(x.targetKeys.map(String).filter(Boolean))].slice(0, 2000) : [], mediaIds: Array.isArray(x.mediaIds) ? [...new Set(x.mediaIds.map(String).filter(Boolean))].slice(0, 2000) : [],
    mediaMode: x.mediaMode === 'cycle' ? 'cycle' : 'selected', text: String(x.text ?? ''), textMode: ['auto', 'caption', 'before', 'after', 'none'].includes(x.textMode) ? x.textMode : (x.text ? 'auto' : 'before'), captionMode: x.captionMode !== false, sendAsDocument: x.sendAsDocument === true, sendDelayMs: toInt(x.sendDelayMs, 700, 0, 60000), preText: String(x.preText || ''), postText: String(x.postText || ''), sendOrder: ['target-first', 'image-first'].includes(x.sendOrder) ? x.sendOrder : 'target-first', scheduledGroupsEnabled: x.scheduledGroupsEnabled !== false, graceMinutes: toInt(x.graceMinutes, 30, 1, 180),
    lastRunKey: String(x.lastRunKey || ''), lastFailureKey: String(x.lastFailureKey || ''), lastAttemptAt: String(x.lastAttemptAt || ''), createdAt: x.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString(), lastResult: x.lastResult || null,
  };
}
function normalizeSession(s, sid) {
  const d = defaults(sid, s.name); s.id = sid; s.name = String(s.name || d.name).slice(0, 80);
  s.settings = { ...clone(DEFAULT_SETTINGS), ...(s.settings || {}), appearance: { ...clone(DEFAULT_SETTINGS.appearance), ...(s.settings?.appearance || {}) }, backgroundSettings: { ...clone(DEFAULT_SETTINGS.backgroundSettings), ...(s.settings?.backgroundSettings || {}) } };
  s.settings.timezone = String(s.settings.timezone || 'Asia/Muscat').trim();
  try { new Intl.DateTimeFormat('en-US', { timeZone: s.settings.timezone }).format(new Date()); } catch { s.settings.timezone = 'Asia/Muscat'; }
  s.settings.scheduleDay = toInt(s.settings.scheduleDay, 5, 0, 6); s.settings.scheduleMonthDay = toInt(s.settings.scheduleMonthDay, 1, 1, 31); s.settings.scheduleGraceMinutes = toInt(s.settings.scheduleGraceMinutes, 30, 1, 180); s.settings.scheduleTargetKeys = Array.isArray(s.settings.scheduleTargetKeys) ? [...new Set(s.settings.scheduleTargetKeys.map(String).filter(Boolean))] : []; s.settings.scheduleMediaId = String(s.settings.scheduleMediaId || ''); s.settings.schedulePreText = String(s.settings.schedulePreText || ''); s.settings.schedulePostText = String(s.settings.schedulePostText || '');
  const appearance = s.settings.appearance || {};
  appearance.accent = /^#[0-9a-f]{6}$/i.test(String(appearance.accent || '')) ? String(appearance.accent) : DEFAULT_SETTINGS.appearance.accent;
  appearance.accent2 = /^#[0-9a-f]{6}$/i.test(String(appearance.accent2 || '')) ? String(appearance.accent2) : DEFAULT_SETTINGS.appearance.accent2;
  appearance.panelOpacity = Math.max(.72, Math.min(.97, Number(appearance.panelOpacity) || DEFAULT_SETTINGS.appearance.panelOpacity));
  appearance.panelBlur = Math.max(4, Math.min(28, Number(appearance.panelBlur) || DEFAULT_SETTINGS.appearance.panelBlur));
  appearance.radius = Math.max(12, Math.min(28, Number(appearance.radius) || DEFAULT_SETTINGS.appearance.radius));
  appearance.glow = Math.max(0, Math.min(1, Number(appearance.glow) || DEFAULT_SETTINGS.appearance.glow));
  s.settings.appearance = appearance;
  s.settings.sendTimeoutMs = toInt(s.settings.sendTimeoutMs, 30000, 5000, 180000); s.settings.sendDelayMs = toInt(s.settings.sendDelayMs, 700, 0, 60000); s.settings.retryAttempts = toInt(s.settings.retryAttempts, 2, 1, 4); s.settings.retryDelayMs = toInt(s.settings.retryDelayMs, 1600, 250, 120000); s.settings.maxImageSizeMB = toInt(s.settings.maxImageSizeMB, 100, 1, 250); s.settings.maxActionsPerMinute = toInt(s.settings.maxActionsPerMinute, 20, 1, 1000); s.settings.interactionQuietStart = /^([01]\d|2[0-3]):[0-5]\d$/.test(String(s.settings.interactionQuietStart || '')) ? String(s.settings.interactionQuietStart) : '23:00'; s.settings.interactionQuietEnd = /^([01]\d|2[0-3]):[0-5]\d$/.test(String(s.settings.interactionQuietEnd || '')) ? String(s.settings.interactionQuietEnd) : '07:00'; s.settings.interactionQuietAction = ['silence','reply','rules'].includes(s.settings.interactionQuietAction) ? s.settings.interactionQuietAction : 'silence'; s.settings.interactionQuietReply = String(s.settings.interactionQuietReply || '').slice(0, 60000); s.settings.interactionQuietCooldownSec = toInt(s.settings.interactionQuietCooldownSec, 300, 30, 86400); s.settings.interactionFallbackEnabled = s.settings.interactionFallbackEnabled !== false; s.settings.interactionFallbackCooldownSec = toInt(s.settings.interactionFallbackCooldownSec, 300, 30, 86400); s.settings.interactionFallbackReply = String(s.settings.interactionFallbackReply || 'أهلًا {{sender}} 👋 وصلتني رسالتك: «{{message}}». سأتابع معك حسب الردود التلقائية المتاحة.').slice(0, 60000);
  s.settings.autoStartSession = s.settings.autoStartSession !== false; s.settings.automationEnabled = s.settings.automationEnabled !== false; s.settings.interactionEnabled = s.settings.interactionEnabled !== false; s.settings.groupAssistantEnabled = s.settings.groupAssistantEnabled !== false; s.settings.interactionIgnoreOwn = s.settings.interactionIgnoreOwn !== false; s.settings.interactionUseRecipientNames = s.settings.interactionUseRecipientNames !== false; s.settings.commandTriggerEnabled = s.settings.commandTriggerEnabled !== false; s.settings.commandTriggerRequired = s.settings.commandTriggerRequired === true; s.settings.commandTriggerWords = (Array.isArray(s.settings.commandTriggerWords) ? s.settings.commandTriggerWords : String(s.settings.commandTriggerWords || '').split(/[،,;|\n]/)).map(v => String(v || '').trim().slice(0, 50)).filter(Boolean).slice(0, 12); if (!s.settings.commandTriggerWords.length) s.settings.commandTriggerWords = ['يا بوت', 'شات بوت', 'chat bot']; s.settings.scheduledGroupsEnabled = s.settings.scheduledGroupsEnabled !== false;
  s.recipients = Array.isArray(s.recipients) ? s.recipients.map(r => ({
    ...r, id: String(r.id || crypto.randomUUID()), name: String(r.name || '').slice(0, 120),
    whatsappName: String(r.whatsappName || '').slice(0, 120), whatsappAvatarUrl: validWhatsAppAvatar(r.whatsappAvatarUrl),
    whatsappAvatarFile: /^recipient-[a-f0-9-]+\.(?:jpg|jpeg|png|webp)$/i.test(String(r.whatsappAvatarFile || '')) ? String(r.whatsappAvatarFile) : '',
    localName: String(r.localName || '').slice(0, 120), autoReply: normalizeRecipientAutoReply(r.autoReply), localAvatarFile: /^recipient-[a-f0-9-]+\.(?:jpg|jpeg|png|webp)$/i.test(String(r.localAvatarFile || '')) ? String(r.localAvatarFile) : '',
    waChatId: String(r.waChatId || '').slice(0, 120), profileCheckedAt: String(r.profileCheckedAt || ''), profileError: String(r.profileError || '').slice(0, 600), enabled: r.enabled !== false
  })) : [];
  s.groups = Array.isArray(s.groups) ? s.groups.map(normalizeGroup).filter(g => /^\d+(?:-\d+)*@g\.us$/.test(g.gid)) : [];
  s.cycle = { ...d.cycle, ...(s.cycle || {}), delivery: s.cycle?.delivery || {}, manualGuard: s.cycle?.manualGuard || {} };
  s.interaction = { ...d.interaction, ...(s.interaction || {}), rules: Array.isArray(s.interaction?.rules) ? s.interaction.rules : seedRules(), recent: Array.isArray(s.interaction?.recent) ? s.interaction.recent : [], health: { receivedCount: 0, handledCount: 0, replyCount: 0, errorCount: 0, lastMessageAt: '', lastChatId: '', lastText: '', lastOutcome: '', lastError: '', ...(s.interaction?.health || {}) } };
  s.stats = { ...d.stats, ...(s.stats || {}) };
  s.automation = { ...d.automation, ...(s.automation || {}) }; s.automation.tasks = Array.isArray(s.automation.tasks) ? s.automation.tasks.map(normalizeAutomationTask) : []; s.automation.recent = Array.isArray(s.automation.recent) ? s.automation.recent.slice(-100) : [];
  s.ownerAssistant = { ...clone(d.ownerAssistant), ...(s.ownerAssistant || {}) };
  s.ownerAssistant.ownerPhone = String(s.ownerAssistant.ownerPhone || '').slice(0, 40);
  s.ownerAssistant.ownerPhoneConfirmed = s.ownerAssistant.ownerPhoneConfirmed === true;
  s.ownerAssistant.notificationsEnabled = s.ownerAssistant.notificationsEnabled !== false;
  s.ownerAssistant.notificationMode = s.ownerAssistant.notificationMode === 'phone' ? 'phone' : 'self';
  s.ownerAssistant.conversation = s.ownerAssistant.conversation && typeof s.ownerAssistant.conversation === 'object' ? s.ownerAssistant.conversation : null;
  s.ownerAssistant.replySessionId = String(s.ownerAssistant.replySessionId || '').slice(0, 80);
  s.ownerAssistant.replySessionEnabled = s.ownerAssistant.replySessionEnabled === true;
  s.ownerAssistant.replySessionConfirmedAt = String(s.ownerAssistant.replySessionConfirmedAt || '');
  s.ownerAssistant.linkedProcessedMessageIds = Array.isArray(s.ownerAssistant.linkedProcessedMessageIds) ? [...new Set(s.ownerAssistant.linkedProcessedMessageIds.map(String))].slice(-150) : [];
  s.ownerAssistant.welcomeCreatedAt = String(s.ownerAssistant.welcomeCreatedAt || ''); s.ownerAssistant.welcomeSentAt = String(s.ownerAssistant.welcomeSentAt || ''); s.ownerAssistant.welcomeAttemptedAt = String(s.ownerAssistant.welcomeAttemptedAt || '');
  s.ownerAssistant.messages = Array.isArray(s.ownerAssistant.messages) ? s.ownerAssistant.messages.slice(-250) : [];
  s.ownerAssistant.issues = Array.isArray(s.ownerAssistant.issues) ? s.ownerAssistant.issues.slice(-200) : [];
  s.ownerAssistant.activity = Array.isArray(s.ownerAssistant.activity) ? s.ownerAssistant.activity.slice(-300) : [];
  s.ownerAssistant.pendingNotifications = Array.isArray(s.ownerAssistant.pendingNotifications) ? [...new Set(s.ownerAssistant.pendingNotifications.map(String))].slice(-100) : [];
  s.logs = Array.isArray(s.logs) ? s.logs.slice(-400) : []; s.scheduleState = { ...d.scheduleState, ...(s.scheduleState || {}) }; s.schemaVersion = 7; return s;
}
function listSessionIds() { const ids = fs.readdirSync(SESSIONS_DIR, { withFileTypes: true }).filter(x => x.isDirectory()).map(x => x.name).filter(Boolean); if (!ids.length) { saveSession(defaults('main', 'الجلسة الرئيسية')); ids.push('main'); } return ids.sort(); }
function activeSessionId() { const f = path.join(DATA_DIR, 'active-session'); try { const candidate = safeSessionId(fs.readFileSync(f, 'utf8').trim()); return listSessionIds().includes(candidate) ? candidate : listSessionIds()[0]; } catch { return listSessionIds()[0]; } }
function setActiveSession(id) { const sid = safeSessionId(id); if (!listSessionIds().includes(sid)) throw new Error('الجلسة غير موجودة.'); fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(path.join(DATA_DIR, 'active-session'), sid, 'utf8'); return loadSession(sid); }
function createSessionInactive(name) { const id = 's-' + crypto.randomUUID(); saveSession(defaults(id, name)); return loadSession(id); }
function createSession(name) { const s = createSessionInactive(name); setActiveSession(s.id); return loadSession(s.id); }
function renameSession(id, name) { if (!listSessionIds().includes(safeSessionId(id))) throw new Error('الجلسة غير موجودة أو حُذفت بالفعل.'); const s = loadSession(id); s.name = String(name || '').trim().slice(0, 80) || s.name; return saveSession(s); }
function deleteSession(id) { const sid = safeSessionId(id); if (!listSessionIds().includes(sid)) throw new Error('الجلسة غير موجودة أو حُذفت بالفعل.'); if (listSessionIds().length <= 1) throw new Error('لا يمكن حذف آخر جلسة.'); const was = activeSessionId() === sid; fs.rmSync(getPaths(sid).dir, { recursive: true, force: true }); const remaining = listSessionIds(); if (was) setActiveSession(remaining[0]); return { activeSessionId: activeSessionId(), deletedSessionId: sid, sessions: remaining }; }
function toInt(v, d, min = -Infinity, max = Infinity) { const n = Number(v); return Number.isFinite(n) ? Math.max(min, Math.min(max, Math.trunc(n))) : d; }
function normalizeGroup(g) { return { id: g.id || crypto.randomUUID(), name: String(g.name || 'مجموعة').slice(0, 120), gid: String(g.gid || '').trim().toLowerCase(), inviteCode: String(g.inviteCode || ''), description: String(g.description || '').slice(0, 1000), owner: String(g.owner || '').slice(0, 150), participantsCount: Number.isFinite(Number(g.participantsCount)) ? Number(g.participantsCount) : null, participants: Array.isArray(g.participants) ? g.participants.slice(0, 2000) : [], admins: Array.isArray(g.admins) ? g.admins.slice(0, 500) : [], discoveredAt: g.discoveredAt || new Date().toISOString(), updatedAt: new Date().toISOString(), enabled: g.enabled !== false }; }
module.exports = { ROOT, DATA_DIR, SESSIONS_DIR, APP_VERSION, DEFAULT_SETTINGS, clone, normalizeRecipientAutoReply, safeSessionId, getPaths, saveSession, loadSession, listSessionIds, activeSessionId, setActiveSession, createSession, createSessionInactive, renameSession, deleteSession, toInt, normalizeGroup, normalizeAutomationTask, ensureDir };
