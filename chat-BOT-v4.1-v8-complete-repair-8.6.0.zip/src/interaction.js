"use strict";

function norm(v) { return String(v ?? '').normalize('NFKC').replace(/[ـ]/g,'').replace(/[ًٌٍَُِّْ]/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').trim().toLocaleLowerCase('ar'); }
function minutes(v) {
  const m = String(v ?? '').match(/^(\d{2}):(\d{2})$/); if (!m) return null;
  const h = Number(m[1]), n = Number(m[2]); return h > 23 || n > 59 ? null : h * 60 + n;
}
function quiet(s, now = new Date()) {
  if (!s.interactionQuietEnabled) return false;
  const a = minutes(s.interactionQuietStart), b = minutes(s.interactionQuietEnd); if (a == null || b == null || a === b) return false;
  let p;
  try { p = new Intl.DateTimeFormat('en-GB', { timeZone: s.timezone || s.settings?.timezone || 'Asia/Muscat', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(now); } catch { return false; }
  const current = Number(p.find(x => x.type === 'hour')?.value || 0) * 60 + Number(p.find(x => x.type === 'minute')?.value || 0);
  return a < b ? current >= a && current < b : current >= a || current < b;
}
function ruleActiveNow(rule, timezone = 'Asia/Muscat', now = new Date()) {
  const schedule = rule?.schedule;
  if (!schedule?.enabled) return true;
  const start = minutes(schedule.start), end = minutes(schedule.end);
  if (start == null || end == null || start === end) return false;
  let parts;
  try { parts = new Intl.DateTimeFormat('en-US', { timeZone: schedule.timezone || timezone, weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(now); }
  catch { return false; }
  const weekday = { Sun:0, Mon:1, Tue:2, Wed:3, Thu:4, Fri:5, Sat:6 };
  const day = weekday[parts.find(x => x.type === 'weekday')?.value];
  const hour = Number(parts.find(x => x.type === 'hour')?.value || 0), minute = Number(parts.find(x => x.type === 'minute')?.value || 0);
  const current = hour * 60 + minute;
  const days = Array.isArray(schedule.days) ? schedule.days.map(Number).filter(x => Number.isInteger(x) && x >= 0 && x <= 6) : [0,1,2,3,4,5,6];
  const crossesMidnight = start > end;
  const windowStartDay = crossesMidnight && current < end ? (day + 6) % 7 : day;
  if (!days.includes(windowStartDay)) return false;
  return crossesMidnight ? current >= start || current < end : current >= start && current < end;
}
function quietAction(settings = {}) { return ['silence','reply','rules'].includes(settings.interactionQuietAction) ? settings.interactionQuietAction : 'silence'; }
function scopeOk(scope, chatId, selected = [], aliases = []) {
  const id = String(chatId || '').toLowerCase(), isGroup = id.endsWith('@g.us');
  if (scope === 'groups') return isGroup;
  if (scope === 'private') return !isGroup;
  if (scope === 'selected') {
    const candidates = new Set([id, ...(Array.isArray(aliases) ? aliases : [])].map(x => norm(x)).filter(Boolean));
    return selected.some(value => candidates.has(norm(value)));
  }
  return true;
}
function match(rule, event, text, emoji) {
  if (rule?.when?.type && rule.when.type !== event) return false;
  const input = norm(event === 'reaction' ? emoji : text), value = norm(rule.when?.value);
  switch (rule.when?.match) {
    case 'any': return Boolean(input);
    case 'exact': return Boolean(value) && input === value;
    case 'contains': return Boolean(value) && input.includes(value);
    case 'starts': return Boolean(value) && input.startsWith(value);
    case 'ends': return Boolean(value) && input.endsWith(value);
    case 'regex': try { return new RegExp(rule.when.value, rule.when.ignoreCase === false ? 'u' : 'iu').test(event === 'reaction' ? emoji : text); } catch { return false; }
    default: return false;
  }
}
function render(text, ctx, tz = 'Asia/Muscat') {
  const time = new Intl.DateTimeFormat('ar-OM', { timeZone: tz, hour: '2-digit', minute: '2-digit' }).format(new Date());
  return String(text || '').replace(/\{\{message\}\}/gi, ctx.message || '').replace(/\{\{sender\}\}/gi, ctx.sender || 'صديق').replace(/\{\{chat\}\}/gi, ctx.chat || '').replace(/\{\{time\}\}/gi, time).replace(/\{\{type\}\}/gi, ctx.type || '').replace(/\{\{emoji\}\}/gi, ctx.emoji || '').trim();
}

function rawId(value) {
  if (!value) return '';
  if (typeof value === 'string') return value.trim().toLowerCase();
  return String(value._serialized || value.$1 || value.remote?._serialized || value.remote?.$1 || value.id?._serialized || value.id?.$1 || '').trim().toLowerCase();
}
function phoneDigits(value) {
  const raw = String(value || '').trim().toLowerCase();
  const jid = raw.match(/^(\d{6,20})@c\.us$/);
  if (jid) return jid[1];
  if (/^\d{6,20}$/.test(raw)) return raw;
  return '';
}
function externalSenderName(raw, chat) {
  return String(raw?.notifyName || raw?._data?.notifyName || raw?.pushname || raw?._data?.pushname || raw?.authorName || raw?._data?.authorName || chat?.name || 'صديق').trim() || 'صديق';
}
function recipientForMessage(session, raw, chat = null, resolvedAliases = []) {
  const ids = [
    raw?.author, raw?._data?.author, raw?.id?.participant, raw?._data?.id?.participant,
    raw?.from, raw?._data?.from, raw?.id?.remote, raw?._data?.id?.remote,
    raw?.chatId, raw?._data?.chatId,
  ].map(rawId).filter(id => /@(?:c\.us|lid)$/.test(id));
  const uniqueIds = [...new Set([...ids, ...(Array.isArray(resolvedAliases) ? resolvedAliases.map(rawId).filter(id => /@(?:c\.us|lid)$/.test(id)) : [])])];
  const digits = new Set(uniqueIds.map(phoneDigits).filter(Boolean));
  const recipients = Array.isArray(session?.recipients) ? session.recipients : [];
  return recipients.find(item => {
    const known = [item?.waChatId, item?.jid, item?.chatId, ...(Array.isArray(item?.waChatIds) ? item.waChatIds : [])].map(rawId).filter(Boolean);
    if (known.some(id => uniqueIds.includes(id))) return true;
    const knownDigits = String(item?.e164 || item?.international || item?.digits || item?.phone || '').replace(/\D/g, '');
    return /^\d{6,15}$/.test(knownDigits) && digits.has(knownDigits);
  }) || null;
}
function resolveSenderName(session, raw, chat = null, resolvedAliases = []) {
  const fallback = externalSenderName(raw, chat);
  if (session?.settings?.interactionUseRecipientNames === false) return fallback;
  const person = recipientForMessage(session, raw, chat, resolvedAliases);
  if (!person) return fallback;
  return String(person.localName || person.name || person.whatsappName || person.phone || fallback).trim().slice(0, 120) || fallback;
}

function valid(rule) {
  if (!['message', 'reaction'].includes(rule.when?.type)) throw new Error('نوع الحدث غير مدعوم.');
  if (!['any', 'contains', 'exact', 'starts', 'ends', 'regex'].includes(rule.when?.match)) throw new Error('نوع المطابقة غير مدعوم.');
  if (rule.when.match !== 'any' && !String(rule.when.value || '').trim()) throw new Error('اكتب قيمة المطابقة.');
  if (rule.when.match === 'regex') new RegExp(rule.when.value);
  if (!['all', 'groups', 'private', 'selected'].includes(rule.scope || 'all')) throw new Error('نطاق غير مدعوم.');
  if (!rule.then?.reply && !rule.then?.reaction) throw new Error('اختر ردًا أو Reaction.');
  if (rule.schedule?.enabled) {
    if (minutes(rule.schedule.start) == null || minutes(rule.schedule.end) == null || rule.schedule.start === rule.schedule.end) throw new Error('وقت تشغيل القاعدة غير صالح؛ حدّد وقت بداية ونهاية مختلفين.');
    if (rule.schedule.days !== undefined && (!Array.isArray(rule.schedule.days) || rule.schedule.days.some(day => !Number.isInteger(Number(day)) || Number(day) < 0 || Number(day) > 6))) throw new Error('أيام تشغيل القاعدة غير صالحة.');
    if (Array.isArray(rule.schedule.days) && rule.schedule.days.length === 0) throw new Error('اختر يومًا واحدًا على الأقل لتشغيل القاعدة.');
    try { new Intl.DateTimeFormat('en-US', { timeZone: rule.schedule.timezone || 'Asia/Muscat' }).format(new Date()); } catch { throw new Error('المنطقة الزمنية لقاعدة التفاعل غير صالحة.'); }
  }
}

function fallbackIntentReply(text, sender) {
  const input = norm(text);
  const name = String(sender || 'صديق').trim() || 'صديق';
  if (/^(?:السلام عليكم|سلام عليكم|السلام|salam|assalamu ?alaikum)(?:\s|$|[!؟.])/u.test(input)) return `وعليكم السلام يا ${name} 🌷 أهلاً بك!`;
  if (/^(?:مرحبا|مرحباً|اهلا|أهلا|هلا|يا هلا|صباح الخير|مساء الخير|hi|hello|hey)(?:\s|$|[!؟.])/u.test(input)) return `أهلاً يا ${name} 👋 كيف أقدر أساعدك؟`;
  if (/(?:شكرا|شكرًا|متشكر|مشكور|thanks|thank you)/u.test(input) && input.length < 100) return `العفو يا ${name} 😊 تحت أمرك.`;
  if (/(?:كيف حالك|عامل ايه|عامل إيه|ازيك|إزيك|كيفك|اخبارك|أخبارك|how are you)/u.test(input)) return `بخير، شكرًا لسؤالك يا ${name} 😊 كيف أقدر أساعدك؟`;
  if (/(?:مين انت|من انت|انت مين|من حضرتك|who are you)/u.test(input)) return `أنا مساعد المحادثة الخاص بهذا الحساب يا ${name} 🤖 أستطيع الترحيب والرد وفق قواعد التفاعل المحفوظة.`;
  if (/(?:مساعدة|ساعدني|help|ماذا تستطيع|تقدر تعمل ايه|بتعمل ايه)/u.test(input) && input.length < 120) return `أهلًا ${name} 👋 أستطيع الرد على التحيات والأسئلة الشائعة، وتطبيق قواعد الرد التلقائي التي يحددها صاحب الحساب. اكتب رسالتك بوضوح وسأرد وفق الإعدادات المتاحة.`;
  return '';
}

class InteractionEngine {
  constructor({ store, whatsapp, log }) { this.store = store; this.whatsapp = whatsapp; this.log = log; this.seen = new Map(); this.cool = new Map(); this.rate = new Map(); this.inFlight = new Set(); }
  rateOk(key, limit) {
    const now = Date.now(); let bucket = this.rate.get(key);
    if (!bucket || now - bucket.start >= 60000) { bucket = { start: now, count: 0 }; this.rate.set(key, bucket); }
    if (bucket.count >= limit) return false; bucket.count++; return true;
  }
  async onMessage(id, msg) { return this.handle(id, 'message', msg); }
  async onSelfChatMessage(id, msg, selfChatId = '') { return this.handle(id, 'message', msg, { selfInput:true, chatIdOverride:selfChatId }); }
  async onReaction(id, reaction) { if (reaction?.fromMe || reaction?._data?.id?.fromMe || reaction?.id?.fromMe) return; return this.handle(id, 'reaction', reaction); }

  async chatContext(raw, event, options = {}) {
    // Message.getChat() performs a browser round-trip. Never await it before using
    // the chat IDs already supplied by whatsapp-web.js: that round-trip can stall
    // after navigation/context loss and silently stop every auto-reply.
    const serialized = value => {
      if (!value) return '';
      if (typeof value === 'string') return value;
      return String(value._serialized || value.$1 || value.remote?._serialized || value.remote?.$1 || '');
    };
    if (options.chatIdOverride) return { chat: null, chatId:String(options.chatIdOverride).trim().toLowerCase() };
    const selfInput = options.selfInput === true || raw?.__chatBotSelfInput === true;
    let chat = raw?.chat || raw?._data?.chat || null;
    const candidates = event === 'message'
      ? (selfInput ? [raw?.chatId, raw?.id?.remote, raw?._data?.id?.remote, raw?.to, raw?._data?.to, raw?.from] : [raw?.from, raw?.chatId, raw?.id?.remote, raw?._data?.id?.remote, raw?.to])
      : [raw?.chatId, raw?.msgId?.remote, raw?.messageId?.remote, raw?.id?.remote];
    let chatId = candidates.map(serialized).find(x => x) || '';
    // Only use the costly browser lookup as a bounded fallback when the event has
    // no usable ID. A hung Puppeteer promise must never block the rule engine.
    if (!chatId && typeof raw?.getChat === 'function') {
      let timer;
      try {
        chat = await Promise.race([
          Promise.resolve().then(() => raw.getChat()),
          new Promise(resolve => { timer = setTimeout(() => resolve(null), 1800); }),
        ]);
        chatId = serialized(chat?.id);
      } catch {} finally { if (timer) clearTimeout(timer); }
    }
    return { chat, chatId: chatId.toLowerCase() };
  }

  async handle(id, event, raw, options = {}) {
    const beganAt = new Date().toISOString();
    const chatHint = String(options.chatIdOverride || raw?.from || raw?.chatId || raw?.id?.remote || raw?._data?.id?.remote || raw?.to || '');
    try {
      const result = await this.handleCore(id, event, raw, options);
      this.updateHealth(id, { beganAt, chatId: result?.chatId || chatHint, text: event === 'message' ? raw?.body : raw?.reaction || raw?.emoji || '', outcome: result, error: null });
      return result;
    } catch (error) {
      this.updateHealth(id, { beganAt, chatId: chatHint, text: event === 'message' ? raw?.body : raw?.reaction || raw?.emoji || '', outcome: null, error });
      throw error;
    }
  }
  updateHealth(id, { beganAt, chatId, text, outcome, error }) {
    const s = this.store.loadSession(id), previous = s.interaction.health || {};
    const result = outcome || {};
    const isFailure = Boolean(error || result.action === 'error' || result.reason === 'rule-action-error');
    const isReply = result.action === 'rule' || result.action === 'reply' || result.action === 'quiet-reply' || result.action === 'fallback';
    s.interaction.health = {
      receivedCount: (Number(previous.receivedCount) || 0) + 1,
      handledCount: (Number(previous.handledCount) || 0) + (result.handled || isReply ? 1 : 0),
      replyCount: (Number(previous.replyCount) || 0) + (isReply && !isFailure ? 1 : 0),
      errorCount: (Number(previous.errorCount) || 0) + (isFailure ? 1 : 0),
      lastMessageAt: beganAt,
      lastChatId: String(chatId || '').slice(0, 120),
      lastText: String(text || '').slice(0, 180),
      lastOutcome: String(error ? 'exception' : result.reason || result.action || (result.handled ? 'handled' : 'no-match')).slice(0, 80),
      lastError: String(error?.message || result.error || '').slice(0, 600),
    };
    this.store.saveSession(s);
  }
  async senderName(id, session, raw, chat, chatId) {
    if (session?.settings?.interactionUseRecipientNames === false || typeof this.whatsapp.chatIdAliases !== 'function') return resolveSenderName(session, raw, chat);
    const candidates = [raw?.author, raw?._data?.author, raw?.id?.participant, raw?._data?.id?.participant, chatId, raw?.from, raw?._data?.from]
      .map(rawId).filter(value => /@(?:c\.us|lid)$/.test(value));
    const unique = [...new Set(candidates)].slice(0, 3);
    if (!unique.length) return resolveSenderName(session, raw, chat);
    const results = await Promise.all(unique.map(async value => {
      try { return await this.whatsapp.chatIdAliases(id, value); } catch { return [value]; }
    }));
    return resolveSenderName(session, raw, chat, results.flat());
  }
  async sendDefaultFallback(id, session, raw, chatId, text, senderName, selfInput = false) {
    if (session.settings.interactionFallbackEnabled === false || !text.trim()) return { handled:false, reason:'no-rule-matched', event:'message', chatId };
    const cooldownMs = Math.max(30, Number(session.settings.interactionFallbackCooldownSec) || 300) * 1000;
    const coolKey = `fallback|${id}|${chatId}`;
    if (Date.now() - (this.cool.get(coolKey) || 0) < cooldownMs) return { handled:true, action:'fallback-cooldown', reason:'fallback-cooldown', chatId };
    if (!this.rateOk(`${id}|${chatId}`, Number(session.settings.maxActionsPerMinute) || 20)) return { handled:true, action:'fallback-rate-limit', reason:'rate-limited', chatId };
    const quick = fallbackIntentReply(text, senderName);
    const template = String(session.settings.interactionFallbackReply || '').trim();
    const content = quick || render(template, { message:String(text).slice(0, 60000), sender:senderName, chat:chatId, type:'message', emoji:'' }, session.settings.timezone || 'Asia/Muscat');
    if (!content) return { handled:false, reason:'no-rule-matched', event:'message', chatId };
    try {
      if (selfInput) await this.whatsapp.sendText(id, chatId, content);
      else await this.whatsapp.replyToMessage(id, raw, content);
      this.cool.set(coolKey, Date.now());
      this.recordFallback(id, chatId, text, content, 'success');
      return { handled:true, action:'fallback', reason:'default-fallback', response:content, chatId };
    } catch (error) {
      this.recordFallback(id, chatId, text, content, 'error', error);
      this.log(id, 'ERROR', `فشل الرد الافتراضي على ${chatId}: ${error.message || error}`);
      return { handled:true, action:'error', reason:'default-fallback-error', error:error.message || String(error), chatId };
    }
  }
  recordFallback(id, chatId, text, response, status, error = null) {
    const s = this.store.loadSession(id);
    s.interaction.recent = [...(s.interaction.recent || []), { at:new Date().toISOString(), ruleName:'الرد الافتراضي', event:'message', ruleId:'default-fallback', status, chatId, text:String(text || '').slice(0,250), response:String(response || '').slice(0,250), detail:error ? String(error.message || error) : undefined }].slice(-200);
    if (status === 'success') s.stats.interactionActions++; else s.stats.interactionErrors++;
    this.store.saveSession(s);
    if (status === 'success') this.log(id, 'INFO', `الرد الافتراضي → ${chatId}`);
  }
  async handleCore(id, event, raw, options = {}) {
    const s = this.store.loadSession(id);
    if (!s.settings.interactionEnabled || !s.interaction.enabled) return { handled:false, reason:'disabled' };
    const selfInput = options.selfInput === true || raw?.__chatBotSelfInput === true;
    const fromMe = raw?.fromMe === true || raw?._data?.id?.fromMe === true || raw?.id?.fromMe === true;
    if (event === 'message' && fromMe && !selfInput && s.settings.interactionIgnoreOwn !== false) return { handled:false, reason:'own-message' };
    const { chat, chatId } = await this.chatContext(raw, event, options);
    if (!chatId) return { handled:false, reason:'scope', detail:'missing-chat-id' };
    const text = event === 'message' ? String(raw?.body || '') : '';
    let aliases = [chatId];
    const selectedScope = s.settings.interactionScope === 'selected' || (s.interaction.rules || []).some(rule => rule.enabled !== false && rule.scope === 'selected');
    if (selectedScope && typeof this.whatsapp.chatIdAliases === 'function') {
      try { aliases = await this.whatsapp.chatIdAliases(id, chatId); if (!aliases.includes(chatId)) aliases.push(chatId); } catch {}
    }
    const senderAliases = [];
    if (event === 'message' && typeof this.whatsapp.chatIdAliases === 'function') {
      const ids = [raw?.author, raw?._data?.author, raw?.id?.participant, raw?._data?.id?.participant, raw?.from, raw?._data?.from]
        .map(rawId).filter(value => /@(?:c\.us|lid)$/.test(value) && value !== chatId);
      for (const sourceId of [...new Set(ids)].slice(0, 3)) {
        try { senderAliases.push(...await this.whatsapp.chatIdAliases(id, sourceId)); } catch { senderAliases.push(sourceId); }
      }
    }
    const person = event === 'message' ? recipientForMessage(s, raw, chat, senderAliases) : null;
    const senderName = event === 'message'
      ? (person && s.settings.interactionUseRecipientNames !== false ? String(person.localName || person.name || person.whatsappName || person.phone || 'صديق').trim() : resolveSenderName(s, raw, chat, senderAliases))
      : externalSenderName(raw, chat);
    if (!scopeOk(s.settings.interactionScope || 'all', chatId, s.settings.interactionChatIds || [], aliases)) return { handled:false, reason:'scope', chatId };
    const isQuiet = event === 'message' && quiet(s.settings);
    const qMode = quietAction(s.settings);
    if (isQuiet && qMode === 'silence') return { handled:true, quiet:true, action:'silence' };
    if (isQuiet && qMode === 'reply') {
      const stable = String(raw?.id?._serialized || raw?.id?.id || raw?.timestamp || `${chatId}|${text}`);
      const seenKey = `quiet|${id}|${chatId}|${stable}`;
      if (this.seen.has(seenKey)) return { handled:true, quiet:true, action:'duplicate' };
      const content = render(s.settings.interactionQuietReply || '', { message:text, sender:senderName, chat:chatId, type:event, emoji:'' }, s.settings.timezone || 'Asia/Muscat');
      const coolKey = `quiet|${id}|${chatId}`, cooldownMs = Math.max(30, Number(s.settings.interactionQuietCooldownSec) || 300) * 1000;
      if (!content) return { handled:true, quiet:true, action:'silence-empty' };
      if (Date.now() - (this.cool.get(coolKey) || 0) < cooldownMs) return { handled:true, quiet:true, action:'cooldown' };
      if (!this.rateOk(`${id}|${chatId}`, Number(s.settings.maxActionsPerMinute) || 20)) return { handled:true, quiet:true, action:'rate-limited' };
      try {
        if (selfInput) await this.whatsapp.sendText(id, chatId, content);
        else await this.whatsapp.replyToMessage(id, raw, content);
        this.seen.set(seenKey, Date.now());
        if (this.seen.size > 5000) for (const [key, stamp] of this.seen) if (Date.now() - stamp > 600000) this.seen.delete(key);
        this.cool.set(coolKey, Date.now());
        this.recordQuiet(id, chatId, text, 'success', content);
        return { handled:true, quiet:true, action:'reply', response:content };
      } catch (error) { this.recordQuiet(id, chatId, text, 'error', content, error); this.log(id, 'ERROR', `تعذر إرسال رد فترة الهدوء: ${error.message || error}`); return { handled:true, quiet:true, action:'error', error:error.message || String(error) }; }
    }
    const emoji = event === 'reaction' ? String(raw?.reaction || raw?.emoji || raw?.value || '') : '';
    const stable = String(raw?.id?._serialized || raw?.id?.$1 || raw?.msgId?._serialized || raw?.msgId?.$1 || raw?.messageId?._serialized || raw?.messageId?.$1 || raw?.id || raw?.timestamp || `${chatId}|${text}|${emoji}`);
    const seenKey = `${event}|${chatId}|${stable}|${text}|${emoji}`;
    if (this.seen.has(seenKey)) return { handled:false, reason:'duplicate' };
    this.seen.set(seenKey, Date.now());
    if (this.seen.size > 5000) for (const [k, t] of this.seen) if (Date.now() - t > 600000) this.seen.delete(k);

    const personal = person?.autoReply || { mode:'inherit', rules:[], fallbackToGlobal:true };
    if (event === 'message' && personal.mode === 'off') return { handled:true, action:'personal-disabled', reason:'personal-disabled', chatId, recipientId:person.id };
    if (event === 'message' && personal.mode === 'custom') {
      const personalRules = (Array.isArray(personal.rules) ? personal.rules : []).filter(rule => rule.enabled !== false);
      for (const rule of personalRules) {
        if (!match({ when:{ type:'message', match:rule.match || 'contains', value:rule.value || '' } }, 'message', text, '')) continue;
        const actionKey = `${id}|person|${person.id}|${rule.id || rule.value}|${chatId}`;
        const cooldown = Math.max(0, Math.min(Number(rule.cooldownSec ?? personal.cooldownSec) || 0, 86400));
        if (this.inFlight.has(actionKey) || (cooldown > 0 && Date.now() - (this.cool.get(actionKey) || 0) < cooldown * 1000)) return { handled:true, action:'personal-cooldown', reason:'personal-cooldown', chatId, recipientId:person.id };
        const response = render(rule.reply || '', { message:text, sender:senderName, chat:chatId, type:event, emoji:'' }, s.settings.timezone || 'Asia/Muscat');
        if (!response) continue;
        return await this.sendPersonalReply(id, s, raw, chatId, text, senderName, response, person, rule, selfInput, actionKey);
      }
      let personalFallback = String(personal.fallbackReply || '').trim();
      if (personal.conversationEnabled) personalFallback = fallbackIntentReply(text, senderName) || personalFallback || (String(s.settings.interactionFallbackReply || '').trim() ? render(s.settings.interactionFallbackReply, { message:text, sender:senderName, chat:chatId, type:event, emoji:'' }, s.settings.timezone || 'Asia/Muscat') : '');
      if (personalFallback) {
        const actionKey = `${id}|person|${person.id}|fallback|${chatId}`;
        const cooldown = Math.max(0, Math.min(Number(personal.cooldownSec) || 0, 86400));
        if (this.inFlight.has(actionKey)) return { handled:true, action:'personal-cooldown', reason:'personal-in-flight', chatId, recipientId:person.id };
        if (cooldown > 0 && Date.now() - (this.cool.get(actionKey) || 0) < cooldown * 1000) return { handled:true, action:'personal-cooldown', reason:'personal-cooldown', chatId, recipientId:person.id };
        const response = render(personalFallback, { message:text, sender:senderName, chat:chatId, type:event, emoji:'' }, s.settings.timezone || 'Asia/Muscat');
        if (response) return await this.sendPersonalReply(id, s, raw, chatId, text, senderName, response, person, { id:'personal-fallback', name:'رد شخصي افتراضي' }, selfInput, actionKey);
      }
      if (personal.fallbackToGlobal === false) return { handled:false, reason:'personal-no-match', chatId, recipientId:person.id };
    }

    const rules = [...s.interaction.rules].filter(r => r.enabled !== false).sort((a, b) => (b.priority || 0) - (a.priority || 0));
    let matchedRule = null, lastActionError = null;
    for (const rule of rules) {
      if (!scopeOk(rule.scope || 'all', chatId, rule.chatIds || [], aliases)) continue;
      if (!ruleActiveNow(rule, s.settings.timezone || 'Asia/Muscat')) continue;
      if (!match(rule, event, text, emoji)) continue;
      try { valid(rule); } catch (e) { this.record(id, event, rule, 'error', chatId, text, emoji, e); continue; }
      const actionKey = `${id}|${rule.id}|${chatId}`;
      if (this.inFlight.has(actionKey)) continue;
      const cooldown = Math.min(Number(rule.cooldownSec) || 0, Number(s.settings.interactionCooldownCapSec) || 86400);
      if (Date.now() - (this.cool.get(actionKey) || 0) < cooldown * 1000) continue;
      if (!this.rateOk(`${id}|${chatId}`, Number(s.settings.maxActionsPerMinute) || 20)) return { handled:true, reason:'rate-limited', chatId };
      this.inFlight.add(actionKey);
      let actionSucceeded = false;
      try {
        const ctx = {
          message: text,
          sender: senderName,
          chat: chatId,
          type: event,
          emoji,
        };
        const reply = render(rule.then.reply, ctx, s.settings.timezone);
        if (reply) {
          if (event === 'message') { if (selfInput) await this.whatsapp.sendText(id, chatId, reply); else await this.whatsapp.replyToMessage(id, raw, reply); }
          else await this.whatsapp.sendText(id, chatId, reply);
        }
        if (rule.then.reaction) {
          const messageId = raw?.id || raw?.msgId || raw?.messageId;
          if (messageId) await this.whatsapp.reactToMessage(id, messageId, rule.then.reaction);
        }
        this.cool.set(actionKey, Date.now());
        this.record(id, event, rule, 'success', chatId, text, emoji);
        actionSucceeded = true;
        matchedRule = { handled:true, action:'rule', ruleId:rule.id, ruleName:rule.name || rule.id };
      } catch (e) {
        lastActionError = { handled:true, reason:'rule-action-error', action:'error', error:e.message || String(e), ruleId:rule.id, ruleName:rule.name || rule.id, chatId };
        this.record(id, event, rule, e.code === 'SEND_UNCERTAIN' ? 'uncertain' : 'error', chatId, text, emoji, e);
        this.log(id, 'ERROR', `فشل التفاعل ${rule.name}: ${e.message || e}`);
      } finally { this.inFlight.delete(actionKey); }
      if (actionSucceeded && rule.then.stopAfter !== false) break;
    }
    if (matchedRule || lastActionError) return matchedRule || lastActionError;
    if (event === 'message') return this.sendDefaultFallback(id, s, raw, chatId, text, senderName, selfInput);
    return { handled:false, reason:'no-rule-matched', event, chatId };
  }
  async sendPersonalReply(id, session, raw, chatId, text, senderName, response, person, rule, selfInput, actionKey) {
    if (!this.rateOk(`${id}|${chatId}`, Number(session.settings.maxActionsPerMinute) || 20)) return { handled:true, reason:'rate-limited', chatId };
    this.inFlight.add(actionKey);
    try {
      if (selfInput) await this.whatsapp.sendText(id, chatId, response);
      else await this.whatsapp.replyToMessage(id, raw, response);
      this.cool.set(actionKey, Date.now());
      const fresh = this.store.loadSession(id);
      fresh.interaction.recent = [...(fresh.interaction.recent || []), { at:new Date().toISOString(), ruleName:`${person.localName || person.whatsappName || person.name || 'شخص'} · ${rule.name || rule.id || 'رد شخصي'}`, event:'message', ruleId:rule.id || 'personal-reply', recipientId:person.id, status:'success', chatId, text:String(text || '').slice(0,500), response:String(response || '').slice(0,500) }].slice(-200);
      fresh.stats.interactionActions++;
      this.store.saveSession(fresh);
      this.log(id, 'INFO', `رد شخصي إلى ${person.localName || person.whatsappName || person.name || person.id} → ${chatId}`);
      return { handled:true, action:'personal-reply', ruleId:rule.id || 'personal-reply', ruleName:rule.name || 'رد شخصي', recipientId:person.id, response, chatId };
    } catch (error) {
      const fresh = this.store.loadSession(id);
      fresh.interaction.recent = [...(fresh.interaction.recent || []), { at:new Date().toISOString(), ruleName:'رد شخصي', event:'message', ruleId:rule.id || 'personal-reply', recipientId:person.id, status:error.code === 'SEND_UNCERTAIN' ? 'uncertain' : 'error', chatId, text:String(text || '').slice(0,500), response:String(response || '').slice(0,500), detail:String(error.message || error).slice(0,600) }].slice(-200);
      fresh.stats.interactionErrors++;
      this.store.saveSession(fresh);
      this.log(id, 'ERROR', `فشل الرد الشخصي إلى ${person.localName || person.name || person.id}: ${error.message || error}`);
      return { handled:true, action:'error', reason:'personal-reply-error', error:error.message || String(error), chatId, recipientId:person.id };
    } finally { this.inFlight.delete(actionKey); }
  }
  recordQuiet(id, chatId, text, status, response, error) {
    const s = this.store.loadSession(id);
    s.interaction.recent = [...s.interaction.recent, { at:new Date().toISOString(), ruleName:'رد فترة الهدوء', event:'message', ruleId:'quiet-hours', status, chatId, text:String(text || '').slice(0,250), response:String(response || '').slice(0,250), detail:error ? String(error.message || error) : undefined }].slice(-200);
    if (status === 'success') s.stats.interactionActions++; else s.stats.interactionErrors++;
    this.store.saveSession(s);
    if (status === 'success') this.log(id, 'INFO', `رد فترة الهدوء → ${chatId}`);
  }
  record(id, event, rule, status, chatId, text, emoji, error) {
    const s = this.store.loadSession(id);
    s.interaction.recent = [...s.interaction.recent, { at: new Date().toISOString(), ruleName: rule.name || rule.id, event, ruleId: rule.id, status, chatId, text: String(text || '').slice(0, 250), emoji, detail: error ? String(error.message || error) : undefined }].slice(-200);
    status === 'success' ? s.stats.interactionActions++ : s.stats.interactionErrors++;
    this.store.saveSession(s);
    if (status === 'success') this.log(id, 'INFO', `تفاعل: ${rule.name || rule.id} → ${chatId}`);
  }
}
module.exports = { InteractionEngine, match, valid, quiet, quietAction, ruleActiveNow, scopeOk, render, resolveSenderName, externalSenderName, recipientForMessage, fallbackIntentReply };
