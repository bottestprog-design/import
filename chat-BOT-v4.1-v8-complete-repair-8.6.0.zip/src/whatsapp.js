"use strict";
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
function patchUtilsForWhatsApp() {
  // Use one canonical patcher at both npm postinstall and server startup.
  // The previous duplicate patch routine could silently pass while leaving the
  // exact media-ID collision unfixed in whatsapp-web.js 1.34.7.
  const result = require('./compat').patch();
  if (!result.ok) throw new Error((result.notes || []).join(' | ') || 'تعذر إصلاح مكتبة WhatsApp لإرسال المرفقات.');
  const packageRoot = path.dirname(require.resolve('whatsapp-web.js/package.json'));
  const utilsPath = path.join(packageRoot, 'src', 'util', 'Injected', 'Utils.js');
  const source = fs.readFileSync(utilsPath, 'utf8');
  const begin = source.indexOf('window.WWebJS.sendMessage = async');
  const end = source.indexOf('window.WWebJS.editMessage = async', begin);
  const sendFunction = begin >= 0 ? source.slice(begin, end >= 0 ? end : undefined) : '';
  if (begin < 0 || (!/delete\s+message\.__x_id\s*;/.test(sendFunction) && !/delete\s+mediaOptions\.__x_id\s*;/.test(sendFunction))) {
    throw new Error('إصلاح إرسال المرفقات لم يُثبت داخل whatsapp-web.js. أوقف التشغيل بدل ترك الإرسال يفشل بصمت؛ نفّذ npm run repair-whatsapp ثم أعد التشغيل.');
  }
  return result;
}
const patchResult = patchUtilsForWhatsApp();

const browserMarker = path.join(path.resolve(__dirname, '..'), '.browser-path');
function detectSystemBrowser() {
  const candidates = [];
  if (process.env.PUPPETEER_EXECUTABLE_PATH) candidates.push(process.env.PUPPETEER_EXECUTABLE_PATH);
  if (process.env.CHROME_PATH) candidates.push(process.env.CHROME_PATH);
  if (process.platform === 'win32') {
    const roots = [process.env.LOCALAPPDATA, process.env.PROGRAMFILES, process.env['PROGRAMFILES(X86)']].filter(Boolean);
    for (const root of roots) {
      candidates.push(path.join(root, 'Google', 'Chrome', 'Application', 'chrome.exe'));
      candidates.push(path.join(root, 'Microsoft', 'Edge', 'Application', 'msedge.exe'));
      candidates.push(path.join(root, 'Chromium', 'Application', 'chrome.exe'));
    }
  } else if (process.platform === 'linux') {
    candidates.push('/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser');
  } else if (process.platform === 'darwin') {
    candidates.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', '/Applications/Chromium.app/Contents/MacOS/Chromium');
  }
  for (const candidate of candidates) {
    try { if (candidate && fs.existsSync(candidate)) return candidate; } catch {}
  }
  return '';
}
let detectedChrome = '';
try { const marked = fs.readFileSync(browserMarker, 'utf8').trim(); if (marked && fs.existsSync(marked)) detectedChrome = marked; } catch {}
if (!detectedChrome) detectedChrome = detectSystemBrowser();
if (detectedChrome && !fs.existsSync(browserMarker)) { try { fs.writeFileSync(browserMarker, detectedChrome, 'utf8'); } catch {} }
process.env.PUPPETEER_CACHE_DIR = process.env.PUPPETEER_CACHE_DIR || path.join(path.resolve(__dirname, '..'), '.cache', 'puppeteer');
const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const { MIME } = require('./media');
const EventEmitter = require('node:events');

function safeError(e) { return String(e?.message || e || 'خطأ غير معروف'); }
function withTimeout(promise, ms, label) {
  let timer;
  const timeout = new Promise((_, reject) => { timer = setTimeout(() => reject(Object.assign(new Error(`${label || 'العملية'} تجاوزت المهلة.`), { code: 'SEND_TIMEOUT' })), Math.max(1000, Number(ms) || 30000)); });
  return Promise.race([Promise.resolve(promise), timeout]).finally(() => clearTimeout(timer));
}
function idSerialized(id) {
  if (!id) return '';
  if (typeof id === 'string') return id;
  if (id._serialized) return String(id._serialized);
  if (id.$1) return String(id.$1);
  if (id.remote) return idSerialized(id.remote);
  return id.id !== undefined ? String(id.id) : '';
}
function chatIdFromMessage(msg) {
  // For outgoing messages, `from` is our own account; using it first makes
  // ACK tracking look at the wrong chat and can hide delivery confirmations.
  const outgoing = Boolean(msg?.fromMe || msg?._data?.id?.fromMe || msg?.id?.fromMe);
  const candidates = outgoing
    ? [msg?.id?.remote, msg?.msgId?.remote, msg?._data?.id?.remote, msg?.to, msg?._data?.to, msg?.chatId, msg?.from, msg?.id?._serialized, msg?.id?.$1]
    : [msg?.from, msg?.id?.remote, msg?.msgId?.remote, msg?._data?.id?.remote, msg?._data?.chatId, msg?.chatId, msg?.to, msg?.id?._serialized, msg?.id?.$1];
  for (const value of candidates) { const id = idSerialized(value).trim().toLowerCase(); if (id.endsWith('@g.us') || id.endsWith('@c.us') || id.endsWith('@lid')) return id; }
  return '';
}
function groupFromMessage(msg) { const id = chatIdFromMessage(msg); return id.endsWith('@g.us') ? id : null; }
function ackIsDelivered(ack) { return Number(ack) >= 2; }
const MAX_CONTEXT_RECOVERY_ATTEMPTS = 3;
const CONTEXT_RECOVERY_DELAYS_MS = [1800, 4000, 8000];
function isContextNavigationError(error) { return /execution context was destroyed|cannot find context with specified id|context\s+destroyed.*navigation|most likely because of a navigation/i.test(safeError(error)); }
function navigationRecoveryPlan(error, previousAttempts = 0) {
  const attempts = Math.max(0, Math.floor(Number(previousAttempts) || 0));
  if (!isContextNavigationError(error) || attempts >= MAX_CONTEXT_RECOVERY_ATTEMPTS) return null;
  return { attempt: attempts + 1, maxAttempts: MAX_CONTEXT_RECOVERY_ATTEMPTS, delayMs: CONTEXT_RECOVERY_DELAYS_MS[Math.min(attempts, CONTEXT_RECOVERY_DELAYS_MS.length - 1)] };
}
function matchesOutgoingIntent(intent, msg, now = Date.now()) {
  if (!intent || now - Number(intent.at || 0) > 15000) return false;
  const body = String(msg?.body || msg?.caption || '').trim();
  if (intent.text) return body === intent.text;
  const hasMedia = Boolean(msg?.hasMedia || msg?._data?.mimetype || ['image','video','audio','document','sticker'].includes(String(msg?.type || '').toLowerCase()));
  return intent.expectsMedia === true && hasMedia;
}
function matchesOutgoingConfirmation(msg, expectedChatId, expectedText = '', label = '', startedAt = Date.now(), now = Date.now(), options = {}) {
  const actualChatId = String(chatIdFromMessage(msg) || '').toLowerCase();
  const expected = String(expectedChatId || '').toLowerCase();
  const aliases = new Set([expected, ...(Array.isArray(options.chatIdAliases) ? options.chatIdAliases : [])].map(x => String(x || '').toLowerCase()).filter(Boolean));
  // ID aliases are trusted only when resolved through WhatsApp's LID/phone mapping.
  if (actualChatId !== expected && !(options.allowResolvedAlias === true && aliases.has(actualChatId))) return false;
  const expectsMedia = /ملف|وسائط|صورة|مرفق|document/i.test(String(label || ''));
  return matchesOutgoingIntent({ at: startedAt, text: String(expectedText || '').trim(), expectsMedia }, msg, now);
}

class WhatsAppManager extends EventEmitter {
  constructor({ store, log }) { super(); this.store = store; this.log = log; this.clients = new Map(); this.pending = new Map(); }
  entry(id) {
    const sid = this.store.safeSessionId(id);
    if (!this.clients.has(sid)) this.clients.set(sid, { client: null, status: 'idle', ready: false, qr: null, browser: '', info: null, lastAck: null, lastSent: null, starting: null, liveGroups: new Map(), stopping: false, reconnectTimer: null, reconnects: 0, navigationRetries: 0, lastError: '', generation: 0, readyProbe: null, connectedAt: null, outgoingIntents: new Map(), programmaticMessageIds: new Map(), selfChatAliases: new Set(), chatAliasMap: new Map(), chatAliasResolved: new Set(), contactProfileCache: new Map() });
    return this.clients.get(sid);
  }
  hasSavedAuth(id) {
    const dir = this.store.getPaths(id).auth;
    try { return fs.existsSync(dir) && fs.readdirSync(dir, { withFileTypes: true }).some(x => x.isDirectory() || x.isFile()); } catch { return false; }
  }
  emitStatus(id) { this.emit('status', id, this.listRuntime(id)); }
  clearReadyProbe(e) { if (e.readyProbe) { clearInterval(e.readyProbe); e.readyProbe = null; } }
  startReadyProbe(sid, client, generation) {
    const e = this.entry(sid); this.clearReadyProbe(e); let attempts = 0;
    e.readyProbe = setInterval(async () => {
      if (generation !== e.generation || e.stopping || e.ready) return this.clearReadyProbe(e);
      if (++attempts > 120) return this.clearReadyProbe(e);
      try { const state = typeof client.getState === 'function' ? await client.getState() : null; if (state === 'CONNECTED') this.markReady(sid, client, generation, 'state'); } catch {}
    }, 1000);
  }
  markReady(sid, client, generation, source = 'ready') {
    const e = this.entry(sid); if (generation !== e.generation || e.stopping) return;
    if (e.ready && e.client === client) return;
    e.ready = true; e.status = 'ready'; e.qr = null; e.browser = 'Chromium/Puppeteer'; e.info = client.info || e.info; e.reconnects = 0; e.navigationRetries = 0; e.lastError = ''; e.connectedAt ||= new Date().toISOString(); this.clearReadyProbe(e);
    const own = this.selfChatId(sid); if (own) this.rememberChatAliases(sid, [own]);
    this.refreshSelfChatAliases(sid, client, generation).catch(error => this.log(sid, 'WARN', `تعذر تحديث معرّفات محادثة النفس: ${safeError(error)}`));
    this.log(sid, 'INFO', `جلسة WhatsApp جاهزة للإرسال والاستقبال (${source}).`); this.emitStatus(sid);
  }
  normalizeWhatsAppAlias(value) {
    const id = idSerialized(value).trim().toLowerCase();
    return /^(?:\d{6,20}@c\.us|\d{6,30}@lid|\d+(?:-\d+)*@g\.us)$/.test(id) ? id : '';
  }
  rememberChatAliases(sid, values) {
    const e = this.entry(sid), aliases = [...new Set((values || []).map(x => this.normalizeWhatsAppAlias(x)).filter(Boolean))];
    if (!aliases.length) return [];
    for (const id of aliases) e.chatAliasMap.set(id, aliases);
    // Keep memory bounded for long-running sessions.
    while (e.chatAliasMap.size > 3000) e.chatAliasMap.delete(e.chatAliasMap.keys().next().value);
    return aliases;
  }
  cachedChatAliases(sid, chatId) {
    const id = String(chatId || '').trim().toLowerCase();
    return this.entry(sid).chatAliasMap.get(id) || (id ? [id] : []);
  }
  selfChatIds(id) {
    const e = this.entry(id), own = this.selfChatId(id);
    if (own && !e.selfChatAliases.has(own)) e.selfChatAliases.add(own);
    return [...e.selfChatAliases];
  }
  isSelfChatId(id, chatIds) {
    const own = new Set(this.selfChatIds(id));
    return (Array.isArray(chatIds) ? chatIds : [chatIds]).map(x => String(x || '').toLowerCase()).find(x => own.has(x)) || '';
  }
  async refreshSelfChatAliases(sid, client, generation) {
    const e = this.entry(sid), own = this.selfChatId(sid);
    if (own) e.selfChatAliases.add(own);
    if (own && typeof client.getContactLidAndPhone === 'function') {
      const pair = await withTimeout(client.getContactLidAndPhone([own]), 8000, 'ربط معرّفات حساب WhatsApp');
      const item = Array.isArray(pair) ? pair[0] : pair;
      const aliases = this.rememberChatAliases(sid, [own, item?.lid, item?.pn]);
      for (const alias of aliases) { e.selfChatAliases.add(alias); e.chatAliasResolved.add(alias); }
    } else if (own) { this.rememberChatAliases(sid, [own]); e.chatAliasResolved.add(own); }
    if (generation !== e.generation || e.stopping) return;
    if (e.selfChatAliases.size) this.rememberChatAliases(sid, [...e.selfChatAliases]);
  }
  async chatIdAliases(id, chatId) {
    const sid = this.store.safeSessionId(id), e = this.entry(sid), normalized = this.normalizeWhatsAppAlias(chatId);
    if (!normalized) return [];
    const cached = e.chatAliasMap.get(normalized);
    if (e.chatAliasResolved.has(normalized)) return cached?.length ? cached : [normalized];
    const client = e.client;
    if (!client || typeof client.getContactLidAndPhone !== 'function' || normalized.endsWith('@g.us')) {
      const aliases = this.rememberChatAliases(sid, [normalized]); e.chatAliasResolved.add(normalized); return aliases;
    }
    try {
      // A one-item cache is not proof that LID↔phone mapping has been checked.
      // Older code returned that cache immediately and therefore never resolved aliases.
      const result = await withTimeout(client.getContactLidAndPhone([normalized]), 2500, 'مطابقة معرّفات جهة الاتصال');
      const item = Array.isArray(result) ? result[0] : result;
      const aliases = this.rememberChatAliases(sid, [normalized, item?.lid, item?.pn]);
      for (const alias of aliases) e.chatAliasResolved.add(alias);
      return aliases.length ? aliases : [normalized];
    } catch { return this.rememberChatAliases(sid, [normalized]); }
  }
  async lookupRecipientProfile(id, recipient) {
    const sid = this.store.safeSessionId(id), client = await this.ensureReady(sid);
    const digits = String(recipient?.e164 || recipient?.international || recipient?.phone || '').replace(/\D/g, '');
    if (!/^\d{6,15}$/.test(digits)) throw new Error('رقم جهة الاتصال غير صالح لمزامنة WhatsApp.');
    let resolved = recipient?.waChatId ? this.normalizeWhatsAppAlias(recipient.waChatId) : '';
    if (!resolved) {
      const numbered = await withTimeout(client.getNumberId(digits), 20000, 'البحث عن جهة الاتصال في WhatsApp');
      if (!numbered) throw new Error('هذا الرقم غير مسجل في WhatsApp أو لا يمكن الوصول إليه من الحساب الحالي.');
      resolved = this.normalizeWhatsAppAlias(numbered);
    }
    if (!resolved) throw new Error('لم يرجع WhatsApp معرّف جهة اتصال صالحًا.');
    const aliases = await this.chatIdAliases(sid, resolved);
    let contact = null, contactId = resolved;
    const contactCandidates = [...new Set([resolved, ...aliases])];
    for (const candidate of contactCandidates) {
      try {
        const found = await withTimeout(client.getContactById(candidate), 7000, 'قراءة اسم جهة الاتصال');
        if (found) { contact = found; contactId = candidate; break; }
      } catch {}
    }
    const usableName = values => values.map(x => String(x || '').trim()).find(x => x && !/^\+?\d{6,20}$/.test(x) && !['you', 'yourself'].includes(x.toLocaleLowerCase('en'))) || '';
    // pushname/notifyName reflect the WhatsApp profile more closely than the local address-book label.
    const whatsappName = usableName([contact?.pushname, contact?.notifyName, contact?.shortName, contact?.verifiedName]);
    let whatsappAvatarUrl = '', avatarReadOk = false, avatarStatus = 'error', avatarError = '', gotNullPicture = false;
    const avatarCandidates = [...new Set([contactId, ...aliases, resolved].filter(Boolean))];
    for (const candidate of avatarCandidates) {
      try {
        const url = await withTimeout(client.getProfilePicUrl(candidate), 8000, 'قراءة صورة جهة الاتصال');
        if (!url) { gotNullPicture = true; continue; }
        const parsed = new URL(String(url));
        if (parsed.protocol === 'https:' && /(?:^|\.)(?:whatsapp\.net|fbcdn\.net)$/i.test(parsed.hostname)) {
          whatsappAvatarUrl = parsed.toString(); avatarReadOk = true; avatarStatus = 'available'; avatarError = ''; break;
        }
        avatarError = 'أعاد WhatsApp رابط صورة غير مسموح به؛ احتُفظ بالصورة السابقة.';
      } catch (error) { avatarError = safeError(error).slice(0, 240); }
    }
    if (!avatarReadOk && gotNullPicture && !avatarError) { avatarReadOk = true; avatarStatus = 'none'; }
    if (!avatarReadOk && !avatarError && !gotNullPicture) avatarError = 'لم تنجح قراءة صورة الملف الشخصي من أي معرّف WhatsApp مرتبط بهذا الرقم.';
    const profile = { waChatId: resolved, whatsappName, whatsappAvatarUrl, avatarReadOk, avatarStatus, avatarError, profileCheckedAt: new Date().toISOString() };
    for (const alias of aliases) this.entry(sid).contactProfileCache.set(alias, profile);
    this.entry(sid).contactProfileCache.set(resolved, profile);
    return profile;
  }
  async listWhatsAppContacts(id) {
    const sid = this.store.safeSessionId(id), client = await this.ensureReady(sid);
    const contacts = await withTimeout(client.getContacts(), 25000, 'قراءة جهات اتصال WhatsApp');
    const source = (contacts || []).slice(0, 5000).filter(contact => {
      if (!contact || contact.isGroup || contact.isMe) return false;
      const contactId = this.normalizeWhatsAppAlias(contact.id);
      return Boolean(contactId && !contactId.endsWith('@g.us'));
    });
    // WhatsApp may expose a LID in contact.id.user. That numeric value is NOT
    // necessarily a phone number. Resolve LID→phone through the official bulk API
    // rather than accidentally storing a LID as a recipient's phone.
    if (typeof client.getContactLidAndPhone === 'function') {
      const needsMapping = source.filter(contact => {
        const contactId = this.normalizeWhatsAppAlias(contact.id);
        const number = String(contact.number || '').replace(/\D/g, '');
        const idUser = String(contactId.split('@')[0] || '').replace(/\D/g, '');
        const alreadyResolved = (this.cachedChatAliases(sid, contactId) || []).some(alias => alias.endsWith('@c.us'));
        return contactId.endsWith('@lid') && !alreadyResolved;
      });
      let next = 0;
      async function mapWorker() {
        while (next < needsMapping.length) {
          const start = next, batch = needsMapping.slice(start, start + 25); next += batch.length;
          const ids = batch.map(contact => this.normalizeWhatsAppAlias(contact.id));
          try {
            const mapped = await withTimeout(client.getContactLidAndPhone(ids), 12000, 'ربط معرفات جهات اتصال WhatsApp');
            for (let i = 0; i < batch.length; i++) {
              const item = Array.isArray(mapped) ? mapped[i] : null;
              const aliases = this.rememberChatAliases(sid, [ids[i], item?.lid, item?.pn]);
              for (const alias of aliases) this.entry(sid).chatAliasResolved.add(alias);
            }
          } catch (error) {
            this.log(sid, 'DEBUG', `تعذر ربط دفعة من معرّفات جهات الاتصال؛ ستُعرض الأرقام التي أمكن التحقق منها فقط: ${safeError(error)}`);
          }
        }
      }
      const workers = Math.min(3, needsMapping.length);
      await Promise.all(Array.from({ length: workers }, () => mapWorker.call(this)));
    }
    const results = [], seenPhones = new Set(), seenIds = new Set(), cache = this.entry(sid).contactProfileCache;
    for (const contact of source) {
      const initialId = this.normalizeWhatsAppAlias(contact.id);
      if (!initialId || initialId.endsWith('@g.us') || seenIds.has(initialId)) continue;
      seenIds.add(initialId);
      const rawNumber = String(contact.number || '').replace(/\D/g, '');
      const idUser = String(initialId.split('@')[0] || '').replace(/\D/g, '');
      const aliases = this.cachedChatAliases(sid, initialId);
      // A c.us JID is the strongest source of the phone number. Never prefer
      // contact.number over it: some current WA builds expose address-book data
      // that is stale, national-only, or otherwise inconsistent with the JID.
      let phoneDigits = initialId.endsWith('@c.us') ? idUser : '';
      if (!phoneDigits) {
        const canonicalPhone = aliases.find(alias => alias.endsWith('@c.us')) || '';
        phoneDigits = canonicalPhone.replace(/@c\.us$/, '').replace(/\D/g, '');
      }
      // Never infer a phone number from a LID or the address-book `number` field.
      // LIDs become sendable only after WhatsApp's LID↔PN API gives us a c.us alias.
      // For non-LID contact IDs, use the ID first and the validated number as fallback.
      if (!phoneDigits && !initialId.endsWith('@lid') && /^\d{6,15}$/.test(rawNumber)) phoneDigits = rawNumber;
      if (phoneDigits && !/^\d{6,15}$/.test(phoneDigits)) phoneDigits = '';
      if (phoneDigits && seenPhones.has(phoneDigits)) continue;
      if (phoneDigits) seenPhones.add(phoneDigits);
      const cachedProfile = [initialId, ...aliases].map(alias => cache.get(alias)).find(Boolean);
      const profileName = String(contact.pushname || contact.notifyName || contact.shortName || contact.verifiedName || cachedProfile?.whatsappName || '').trim().slice(0, 120);
      const addressBookName = String(contact.name || '').trim().slice(0, 120);
      // contact.name is kept as a separately labelled display fallback because
      // it may be the label that the owner actually sees in the WhatsApp UI;
      // it is never copied into the remote profile field as verified pushname.
      const name = profileName || addressBookName || (phoneDigits ? `+${phoneDigits}` : 'جهة اتصال — رقم غير متاح');
      results.push({
        id: initialId, phone: phoneDigits, name,
        whatsappName: profileName, nameSource: profileName ? 'whatsapp-profile' : addressBookName ? 'whatsapp-address-book' : phoneDigits ? 'phone-fallback' : 'unresolved-lid',
        addressBookName, avatarUrl: cachedProfile?.whatsappAvatarUrl || '',
        profileStatus: cachedProfile?.avatarStatus || 'not-read',
        canAdd: Boolean(phoneDigits), idVerified: Boolean(phoneDigits && (initialId.endsWith('@c.us') || aliases.some(alias => alias.endsWith('@c.us')))),
        aliases,
      });
    }
    return results.sort((a,b) => a.name.localeCompare(b.name, 'ar'));
  }
  outboundKey(sid, chatId) { return `${this.store.safeSessionId(sid)}|${String(chatId || '').trim().toLowerCase()}`; }
  registerOutgoingIntent(sid, chatId, text, label = '') {
    const e = this.entry(sid), keys = [...new Set(this.cachedChatAliases(sid, chatId).map(alias => this.outboundKey(sid, alias)))], now = Date.now();
    const item = { id: `${now}-${Math.random().toString(36).slice(2)}`, at: now, text: String(text || '').trim(), expectsMedia: /ملف|وسائط|صورة|مرفق|document/i.test(String(label || '')) };
    for (const key of keys) { const list = (e.outgoingIntents.get(key) || []).filter(x => now - x.at < 15000); list.push(item); e.outgoingIntents.set(key, list.slice(-20)); }
    return { keys, key: keys[0] || this.outboundKey(sid, chatId), id:item.id };
  }
  removeOutgoingIntent(sid, intent) {
    if (!intent?.id) return;
    const e = this.entry(sid), keys = intent.keys || [intent.key];
    for (const key of keys) { if (!key) continue; const list = (e.outgoingIntents.get(key) || []).filter(x => x.id !== intent.id && Date.now() - x.at < 15000); if (list.length) e.outgoingIntents.set(key, list); else e.outgoingIntents.delete(key); }
  }
  rememberProgrammatic(sid, id) {
    const key = idSerialized(id?.id || id?.messageId || id);
    if (!key) return;
    const e = this.entry(sid), now = Date.now(); e.programmaticMessageIds.set(key, now + 10 * 60 * 1000);
    if (e.programmaticMessageIds.size > 2000) for (const [idKey, expires] of e.programmaticMessageIds) if (expires < now) e.programmaticMessageIds.delete(idKey);
    if (e.programmaticMessageIds.size > 2500) e.programmaticMessageIds.delete(e.programmaticMessageIds.keys().next().value);
  }
  hasPotentialOutgoingIntent(sid, msg) {
    const prefix = `${this.store.safeSessionId(sid)}|`, now = Date.now();
    for (const [key, list] of this.entry(sid).outgoingIntents) {
      if (!key.startsWith(prefix)) continue;
      if ((list || []).some(intent => matchesOutgoingIntent(intent, msg, now))) return true;
    }
    return false;
  }
  markProgrammaticOutgoing(sid, msg) {
    if (!(msg?.fromMe === true || msg?._data?.id?.fromMe === true || msg?.id?.fromMe === true)) return false;
    const e = this.entry(sid), now = Date.now(), mid = idSerialized(msg?.id || msg?._data?.id);
    if (mid && e.programmaticMessageIds.has(mid)) {
      if (e.programmaticMessageIds.get(mid) >= now) { msg.__chatBotProgrammatic = true; return true; }
      e.programmaticMessageIds.delete(mid);
    }
    const chatId = chatIdFromMessage(msg), key = this.outboundKey(sid, chatId);
    if (!chatId) return false;
    let sourceKey = key, list = (e.outgoingIntents.get(key) || []).filter(x => now - x.at < 15000);
    if (!list.length) {
      const aliases = this.cachedChatAliases(sid, chatId);
      const candidateKeys = aliases.map(alias => this.outboundKey(sid, alias));
      for (const candidateKey of candidateKeys) { const candidate = (e.outgoingIntents.get(candidateKey) || []).filter(x => now - x.at < 15000); if (candidate.length) { sourceKey = candidateKey; list = candidate; break; } }
    }
    if (!list.length) { e.outgoingIntents.delete(key); return false; }
    const body = String(msg?.body || msg?.caption || '').trim(), hasMedia = Boolean(msg?.hasMedia || msg?._data?.mimetype || ['image','video','audio','document','sticker'].includes(String(msg?.type || '').toLowerCase()));
    const index = list.findIndex(x => matchesOutgoingIntent(x, msg, now));
    if (index < 0) { e.outgoingIntents.set(sourceKey,list); return false; }
    const [intent] = list.splice(index,1); if (list.length) e.outgoingIntents.set(sourceKey,list); else e.outgoingIntents.delete(sourceKey);
    if (mid) this.rememberProgrammatic(sid, mid);
    try { msg.__chatBotProgrammatic = true; } catch {}
    return true;
  }
  isContextNavigationError(error) { return isContextNavigationError(error); }
  async recoverRuntimeNavigation(sid, client, generation, error) {
    const e = this.entry(sid);
    if (generation !== e.generation || e.stopping || e.status === 'recovering') return;
    const plan = navigationRecoveryPlan(error, e.navigationRetries);
    this.clearReadyProbe(e);
    const recoveryGeneration = ++e.generation; // invalidate listeners belonging to the failed browser instance
    e.client = null; e.ready = false; e.qr = null; e.lastError = safeError(error).slice(0, 600);
    clearTimeout(e.reconnectTimer); e.reconnectTimer = null;
    if (!plan) {
      e.status = 'error'; this.log(sid, 'ERROR', `فشل استرداد سياق Chromium بعد ${e.navigationRetries} محاولات: ${e.lastError}`); this.emitStatus(sid);
      try { await withTimeout(client.destroy(), 10000, 'إيقاف Chromium بعد فشل الاسترداد'); } catch {}
      return;
    }
    e.navigationRetries = plan.attempt; e.status = 'recovering';
    this.log(sid, 'WARN', `تعطل سياق Chromium أثناء جلسة متصلة؛ ستتم إعادة التهيئة (${plan.attempt}/${plan.maxAttempts}) بعد ${plan.delayMs}ms: ${e.lastError}`);
    this.emitStatus(sid);
    try { await withTimeout(client.destroy(), 10000, 'إعادة ضبط Chromium بعد التنقل'); } catch {}
    if (e.generation !== recoveryGeneration || e.stopping) return;
    e.status = 'recovering'; e.ready = false; e.client = null; this.emitStatus(sid);
    e.reconnectTimer = setTimeout(() => {
      if (e.generation !== recoveryGeneration || e.stopping || e.client) return;
      this.start(sid, { recovery:true }).catch(retryError => this.log(sid, 'ERROR', `فشلت إعادة تهيئة WhatsApp بعد تعطل سياق الصفحة: ${safeError(retryError)}`));
    }, plan.delayMs);
  }
  async start(id, { recovery = false } = {}) {
    const sid = this.store.safeSessionId(id), e = this.entry(sid);
    if (e.stopping) throw new Error('يتم إيقاف الجلسة الآن. انتظر انتهاء الإيقاف ثم أعد الاتصال.');
    if (e.ready && e.client) return this.listRuntime(sid);
    if (e.starting) return e.starting;
    if (e.status === 'recovering' && !recovery) return this.listRuntime(sid);
    // A QR/authenticated client remains valid even after initialize() has returned.
    // Repeated clicks on Connect must not destroy the QR session and restart LocalAuth.
    if (e.client && ['starting', 'qr', 'authenticated'].includes(e.status)) return this.listRuntime(sid);
    clearTimeout(e.reconnectTimer); e.reconnectTimer = null;
    if (e.client) { try { await withTimeout(e.client.destroy(), 10000, 'تنظيف جلسة متوقفة'); } catch {} e.client = null; }
    if (e.status === 'error') { e.navigationRetries = 0; e.lastError = ''; }
    const generation = ++e.generation; e.status = 'starting'; e.qr = null; e.ready = false; e.connectedAt = null; this.emitStatus(sid);
    const startPromise = (async () => {
      const p = this.store.getPaths(sid); this.store.ensureDir?.(sid); fs.mkdirSync(p.auth, { recursive: true });
      const client = new Client({
        authStrategy: new LocalAuth({ clientId: sid, dataPath: p.auth }),
        // Avoid extra Chromium flags that can trigger WhatsApp Web page/context reload races.
        // Linux deployments may require --no-sandbox; desktop Windows/macOS retain the browser sandbox.
        puppeteer: { headless: String(process.env.HEADLESS || 'true') !== 'false', executablePath: detectedChrome || undefined, args: process.platform === 'linux' ? ['--no-sandbox'] : [], timeout: 60000 },
        authTimeoutMs: 60000, takeoverOnConflict: false,
      });
      e.client = client;
      // Browser/page failures may be emitted after initialize() resolves. Handle the EventEmitter
      // error channel explicitly so an asynchronous Puppeteer error cannot crash the whole server.
      client.on('error', error => {
        if (generation !== e.generation || e.stopping) return;
        e.lastError = safeError(error).slice(0, 900);
        this.log(sid, 'ERROR', `خطأ من عميل WhatsApp: ${e.lastError}`);
        if (isContextNavigationError(error) && !e.starting) {
          this.recoverRuntimeNavigation(sid, client, generation, error).catch(recoveryError => {
            const current = this.entry(sid);
            if (generation === current.generation && !current.stopping) { current.ready = false; current.status = 'error'; current.lastError = safeError(recoveryError).slice(0, 900); this.emitStatus(sid); }
            this.log(sid, 'ERROR', `تعذّر استرداد خطأ Chromium: ${safeError(recoveryError)}`);
          });
        } else this.emitStatus(sid);
      });
      client.on('qr', async qr => { if (generation !== e.generation) return; e.lastError = ''; e.qr = qr; e.status = 'qr'; try { e.qr = await require('qrcode').toDataURL(qr, { margin: 1, width: 260 }); } catch {} this.emitStatus(sid); });
      client.on('authenticated', () => { if (generation !== e.generation) return; e.lastError = ''; e.status = 'authenticated'; e.qr = null; this.startReadyProbe(sid, client, generation); this.emitStatus(sid); });
      client.on('ready', () => this.markReady(sid, client, generation, 'event'));
      client.on('change_state', state => { if (generation !== e.generation) return; if (state === 'CONNECTED' && !e.ready) this.startReadyProbe(sid, client, generation); });
      client.on('auth_failure', msg => { if (generation !== e.generation) return; e.ready = false; e.status = 'auth_failure'; this.clearReadyProbe(e); this.log(sid, 'ERROR', `فشل توثيق WhatsApp: ${safeError(msg)}`); this.emitStatus(sid); });
      client.on('disconnected', reason => {
        if (generation !== e.generation) return; e.ready = false; e.status = 'disconnected'; e.lastError = safeError(reason).slice(0,600); e.client = null; this.clearReadyProbe(e); this.log(sid, 'WARN', `انفصلت جلسة WhatsApp: ${safeError(reason)}`); this.emitStatus(sid);
        if (!e.stopping && this.hasSavedAuth(sid) && e.reconnects < 4) { const wait = [2500, 5000, 10000, 20000][Math.min(e.reconnects, 3)]; e.reconnects++; clearTimeout(e.reconnectTimer); e.reconnectTimer = setTimeout(() => { if (generation !== e.generation || e.stopping) return; this.start(sid).catch(err => this.log(sid, 'ERROR', `فشل إعادة الاتصال: ${safeError(err)}`)); }, wait); }
      });
      client.on('message', msg => {
        // Dispatch first: never make the real-time auto-reply wait on slow group metadata calls.
        this.emit('message', sid, msg);
        const gid = groupFromMessage(msg);
        if (gid) Promise.resolve().then(async () => {
          const rt = this.entry(sid); let info = { gid, name: gid };
          try { const chat = typeof msg.getChat === 'function' ? await withTimeout(msg.getChat(), 8000, 'قراءة محادثة المجموعة') : null; if (chat) info = await this.groupInfoFromChat(chat); }
          catch (error) { this.log(sid, 'DEBUG', `تأخر تحديث بيانات المجموعة ${gid}: ${safeError(error)}`); }
          if (generation === this.entry(sid).generation) rt.liveGroups.set(gid, info);
        }).catch(error => this.log(sid, 'WARN', `تعذر تحديث بيانات المجموعة: ${safeError(error)}`));
      });
      client.on('message_ack', (msg, ack) => { e.lastAck = { at: new Date().toISOString(), id: idSerialized(msg?.id || msg), chatId: chatIdFromMessage(msg), ack, level: Number(ack) >= 4 ? 'read' : Number(ack) >= 3 ? 'delivered' : Number(ack) >= 2 ? 'server' : Number(ack) === 1 ? 'pending' : 'error' }; this.resolvePending('ack', sid, e.lastAck); this.emit('ack', sid, e.lastAck); });
      client.on('message_create', msg => {
        // whatsapp-web.js exposes own-message state through Message.fromMe and/or its raw ID.
        if (!(msg?.fromMe === true || msg?._data?.id?.fromMe === true || msg?.id?.fromMe === true)) return;
        let marked = false;
        try { marked = this.markProgrammaticOutgoing(sid, msg); } catch (error) { this.log(sid, 'WARN', `تعذر تمييز رسالة صادرة آلية: ${safeError(error)}`); }
        const actualChatId = chatIdFromMessage(msg);
        // Usually a manual message can be dispatched immediately. If its exact content
        // matches an in-flight send but the returned ID differs (@lid vs @c.us), first
        // resolve that mapping so our own generated message is not mistaken for manual input.
        const needsAliasCheck = !marked && this.hasPotentialOutgoingIntent(sid, msg) && actualChatId && !actualChatId.endsWith('@g.us');
        const dispatch = () => this.emit('message_create', sid, msg);
        if (!needsAliasCheck) dispatch();
        Promise.resolve().then(async () => {
          if (needsAliasCheck) {
            try { await this.chatIdAliases(sid, actualChatId); } catch {}
            try { marked = this.markProgrammaticOutgoing(sid, msg) || marked; } catch (error) { this.log(sid, 'WARN', `تعذر تحديث علامة الإرسال الآلي: ${safeError(error)}`); }
            dispatch();
          } else if (actualChatId && !actualChatId.endsWith('@g.us')) {
            try { await this.chatIdAliases(sid, actualChatId); } catch {}
          }
          try { this.resolvePending('message', sid, msg); } catch (error) { this.log(sid, 'WARN', `تعذر تحديث تأكيد الرسالة الصادرة: ${safeError(error)}`); }
        }).catch(error => this.log(sid, 'WARN', `تعذر مطابقة معرّف الرسالة الصادرة: ${safeError(error)}`));
      });
      client.on('message_reaction', reaction => { this.emit('reaction', sid, { ...reaction, chatId: idSerialized(reaction?.chatId || reaction?.msgId?.remote || reaction?.id?.remote || reaction?.messageId?.remote || ''), emoji: String(reaction?.reaction || reaction?.emoji || reaction?.value || ''), msgId: reaction?.msgId || reaction?.messageId || reaction?.id || reaction?.message?.id || null, fromMe: !!reaction?.fromMe }); });
      await withTimeout(client.initialize(), 180000, 'تهيئة WhatsApp');
      return this.listRuntime(sid);
    })().catch(async err => {
      const recovery = generation === e.generation && !e.stopping ? navigationRecoveryPlan(err, e.navigationRetries) : null;
      if (recovery) {
        e.navigationRetries = recovery.attempt;
        e.lastError = safeError(err).slice(0, 600);
        this.log(sid, 'WARN', `انقطع سياق Chromium أثناء انتقال صفحة WhatsApp. سأعيد تهيئة الجلسة تلقائيًا (${recovery.attempt}/${recovery.maxAttempts}) بعد ${recovery.delayMs}ms: ${safeError(err)}`);
        this.clearReadyProbe(e);
        const failedClient = e.client; e.client = null; e.ready = false; e.qr = null; e.status = 'recovering'; this.emitStatus(sid);
        if (failedClient) { try { await withTimeout(failedClient.destroy(), 10000, 'إعادة ضبط Chromium بعد التنقل'); } catch {} }
        // Destroying the failed client may emit 'disconnected' and change the status; restore the recovery state after cleanup.
        if (generation === e.generation && !e.stopping) { e.client = null; e.ready = false; e.qr = null; e.status = 'recovering'; this.emitStatus(sid); }
        const oldGeneration = generation;
        clearTimeout(e.reconnectTimer);
        e.reconnectTimer = setTimeout(async () => {
          try {
            if (e.starting) await e.starting.catch(() => {});
            if (e.generation !== oldGeneration || e.stopping || e.client) return;
            await this.start(sid, { recovery:true });
          } catch (retryError) { this.log(sid, 'ERROR', `فشلت إعادة تهيئة WhatsApp بعد تعطل سياق الصفحة: ${safeError(retryError)}`); }
        }, recovery.delayMs);
        return this.listRuntime(sid);
      }
      if (generation === e.generation) {
        if (e.client) { try { await e.client.destroy(); } catch {} e.client = null; }
        e.status = 'error'; e.ready = false; e.lastError = safeError(err).slice(0, 900); this.clearReadyProbe(e); this.log(sid, 'ERROR', `فشل تشغيل الجلسة: ${safeError(err)}`); this.emitStatus(sid);
      } else { this.log(sid, 'WARN', `انتهت محاولة تشغيل قديمة بعد تبديل حالة الجلسة: ${safeError(err)}`); }
      throw err;
    }).finally(() => { if (e.starting === startPromise) e.starting = null; });
    e.starting = startPromise;
    return startPromise;
  }
  async ensureReady(id) { const sid = this.store.safeSessionId(id), e = this.entry(sid); if (e.ready && e.client) return e.client; await this.start(sid); const after = this.entry(sid); if (!after.ready || !after.client) throw new Error(`جلسة WhatsApp ليست جاهزة. الحالة الحالية: ${after.status}`); return after.client; }
  async stop(id, { clearAuth = false } = {}) {
    const sid = this.store.safeSessionId(id), e = this.entry(sid);
    e.stopping = true; ++e.generation;
    clearTimeout(e.reconnectTimer); e.reconnectTimer = null; this.clearReadyProbe(e);
    // Detach the old start promise immediately so reconnect does not inherit an obsolete initialize().
    const obsoleteStart = e.starting; e.starting = null;
    const oldClient = e.client; e.client = null; e.ready = false; e.qr = null; e.status = 'stopping';
    if (oldClient) { try { await withTimeout(oldClient.destroy(), 10000, 'إيقاف الجلسة'); } catch {} }
    // Give initialize() a brief chance to settle, but don't let an obsolete promise block future sessions.
    if (obsoleteStart) await Promise.race([obsoleteStart.catch(() => {}), new Promise(resolve => setTimeout(resolve, 1200))]);
    if (clearAuth) { try { fs.rmSync(this.store.getPaths(sid).auth, { recursive: true, force: true }); } catch {} }
    e.stopping = false; e.reconnects = 0; e.client = null; e.ready = false; e.qr = null; e.lastError = ''; e.navigationRetries = 0; e.status = 'stopped'; this.emitStatus(sid);
  }
  async stopAll(opts = {}) { for (const sid of this.clients.keys()) await this.stop(sid, opts); }
  listRuntime(id) { const e = this.entry(id); return { status: e.status, ready: e.ready, qr: e.qr, browser: e.browser, info: e.info, lastAck: e.lastAck, lastSent: e.lastSent, reconnects: e.reconnects || 0, navigationRetries: e.navigationRetries || 0, lastError: e.lastError || '', connectedAt: e.connectedAt, liveGroups: [...e.liveGroups.values()] }; }
  waitForEvent(kind, sid, matcher, timeoutMs) {
    const key = `${sid}|${kind}`, list = this.pending.get(key) || [], match = typeof matcher === 'function' ? matcher : value => { const want = String(matcher || '').toLowerCase(); return !want || String(kind === 'ack' ? value?.chatId : chatIdFromMessage(value)).toLowerCase() === want; };
    this.pending.set(key, list); let done = false, timer, item;
    const promise = new Promise(resolve => { const finish = value => { if (done) return; done = true; clearTimeout(timer); const index = list.indexOf(item); if (index >= 0) list.splice(index, 1); if (!list.length) this.pending.delete(key); resolve(value); }; item = { match, resolve: finish }; timer = setTimeout(() => finish(null), Math.max(500, Number(timeoutMs) || 5000)); list.push(item); });
    promise.cancel = () => item?.resolve(null); return promise;
  }
  resolvePending(kind, sid, value) { const list = this.pending.get(`${sid}|${kind}`) || []; const item = list.find(x => { try { return x.match(value); } catch { return false; } }); if (item) item.resolve(value); }
  async sendConfirmed(sid, chatId, operation, timeoutMs, label, expectedText = '') {
    const normalizedChat = String(chatId || '').toLowerCase(), started = Date.now();
    const chatAliases = await this.chatIdAliases(sid, normalizedChat);
    const acceptedChatIds = new Set([normalizedChat, ...chatAliases].map(x => String(x || '').toLowerCase()).filter(Boolean));
    const outgoingIntent = this.registerOutgoingIntent(sid, normalizedChat, expectedText, label);
    const ackWait = this.waitForEvent('ack', sid, value => acceptedChatIds.has(String(value?.chatId || '').toLowerCase()) && ackIsDelivered(value?.ack), 7000);
    // A matching resolved alias is accepted, but text-only matches from arbitrary chats are not.
    // This matters on WhatsApp accounts that expose the same participant as @c.us and @lid.
    const createdWait = this.waitForEvent('message', sid, msg => {
      const actualChatId = chatIdFromMessage(msg);
      const currentAliases = actualChatId ? this.cachedChatAliases(sid, actualChatId) : [];
      const aliasIsResolved = Boolean(actualChatId && this.entry(sid).chatAliasResolved.has(actualChatId) && currentAliases.some(alias => acceptedChatIds.has(alias)));
      return matchesOutgoingConfirmation(msg, normalizedChat, expectedText, label, started, Date.now(), {
        chatIdAliases: [...acceptedChatIds, ...(aliasIsResolved ? currentAliases : [])],
        allowResolvedAlias: aliasIsResolved,
      });
    }, 7000);
    try {
      const result = await withTimeout(operation(), timeoutMs, label);
      if (!result) { const event = await Promise.race([ackWait, createdWait]); this.removeOutgoingIntent(sid, outgoingIntent); if (event) { const confirmed = event?.ack !== undefined && ackIsDelivered(event.ack); this.rememberProgrammatic(sid, event); ackWait.cancel(); createdWait.cancel(); return { result: event, __chatBotAck: { status: confirmed ? 'confirmed' : 'created', mode: confirmed ? 'ack' : 'message_create', waitedMs: Date.now() - started } }; } throw Object.assign(new Error(`تم طلب ${label || 'الإرسال'} لكن لم يظهر تأكيد.`), { code: 'SEND_UNCERTAIN' }); }
      const id = idSerialized(result?.id || result?.messageId || result);
      this.removeOutgoingIntent(sid, outgoingIntent); if (id) this.rememberProgrammatic(sid, id);
      const earlyAck = await Promise.race([ackWait, createdWait, new Promise(resolve => setTimeout(() => resolve(null), 700))]);
      if (earlyAck?.ack !== undefined && ackIsDelivered(earlyAck.ack)) { ackWait.cancel(); createdWait.cancel(); return { result, __chatBotAck: { status: 'confirmed', mode: 'ack', id, waitedMs: Date.now() - started } }; }
      if (earlyAck?.body !== undefined || idSerialized(earlyAck?.id)) { ackWait.cancel(); createdWait.cancel(); return { result, __chatBotAck: { status: 'created', mode: 'message_create', id, waitedMs: Date.now() - started } }; }
      // The library returned a Message object, which means the operation created a send.
      // Mark it as created, not falsely as delivered, and never retry it automatically.
      ackWait.cancel(); createdWait.cancel();
      return { result, __chatBotAck: { status: 'created', mode: 'return', id, waitedMs: Date.now() - started } };
    } catch (e) {
      if (e.code === 'SEND_TIMEOUT') { const event = await Promise.race([ackWait, createdWait]); this.removeOutgoingIntent(sid, outgoingIntent); if (event) { const confirmed = event?.ack !== undefined && ackIsDelivered(event.ack); this.rememberProgrammatic(sid, event); ackWait.cancel(); createdWait.cancel(); return { result: event, __chatBotAck: { status: confirmed ? 'confirmed' : 'created', mode: confirmed ? 'ack' : 'message_create', waitedMs: Date.now() - started } }; } throw Object.assign(new Error(`لم نتأكد من نتيجة ${label || 'الإرسال'}؛ لم تتم إعادة الإرسال لمنع التكرار.`), { code: 'SEND_UNCERTAIN' }); }
      this.removeOutgoingIntent(sid, outgoingIntent); ackWait.cancel(); createdWait.cancel(); throw e;
    }
  }
  async resolveChatId(id, target) {
    const sid = this.store.safeSessionId(id), client = await this.ensureReady(sid);
    if (target.kind === 'group' || String(target.gid || '').toLowerCase().endsWith('@g.us')) { const gid = String(target.gid || '').trim().toLowerCase(); if (!/^\d+(?:-\d+)*@g\.us$/.test(gid)) throw new Error('معرف المجموعة غير صالح.'); try { const chat = await client.getChatById(gid); return idSerialized(chat?.id) || gid; } catch { return gid; } }
    const canonical = String(target.e164 || '').trim(), international = String(target.international || target.formatted || '').trim();
    let digits = canonical ? canonical.replace(/\D/g, '') : (/^\+|^00/.test(international) ? international.replace(/\D/g, '') : '');
    if (!digits && target.digits) digits = String(target.digits).replace(/\D/g, '');
    if (!digits && target.phone && target.country) {
      try { digits = require('./phones').parse(target.phone, target.country).digits; }
      catch { digits = String(target.phone).replace(/\D/g, ''); }
    }
    if (!digits && international) digits = international.replace(/\D/g, '');
    if (!digits || !/^\d{6,15}$/.test(digits)) throw new Error('رقم المستلم مفقود أو غير صالح؛ راجع رمز الدولة ورقم الهاتف.');
    const n = await withTimeout(client.getNumberId(digits), 20000, 'فحص رقم WhatsApp'); if (!n) throw new Error(`الرقم ${digits} غير مسجل على WhatsApp.`); return idSerialized(n);
  }
  async sendText(id, chatId, text, { timeoutMs = 30000 } = {}) { const content = String(text || '').trim(); if (!content) throw new Error('النص فارغ.'); if (content.length > 60000) throw new Error(`الرسالة طويلة جدًا (${content.length} حرف). الحد الحالي 60000 حرف؛ قسّمها إلى رسائل أو أرسلها كملف نصي.`); const client = await this.ensureReady(id); const r = await this.sendConfirmed(this.store.safeSessionId(id), chatId, () => client.sendMessage(chatId, content), timeoutMs, 'إرسال النص', content); this.entry(id).lastSent = { at: new Date().toISOString(), chatId, kind: 'text' }; return r; }
  selfChatId(id) {
    const e = this.entry(id), wid = e.info?.wid || e.client?.info?.wid || null;
    const serialized = idSerialized(wid).trim().toLowerCase();
    if (/^\d{6,20}@c\.us$/.test(serialized)) return serialized;
    const user = String(wid?.user || wid?.id || '').replace(/\D/g, '');
    if (/^\d{6,20}$/.test(user)) return `${user}@c.us`;
    if (/^\d{6,20}@lid$/.test(serialized)) return serialized;
    return '';
  }
  async sendOwnerNotification(id, text, { mode = 'self', phone = '' } = {}) {
    const sid = this.store.safeSessionId(id); let chatId = '';
    if (mode === 'phone') {
      const raw = String(phone || '').trim(); if (!raw) throw new Error('لم يُسجّل رقم المالك للإشعارات.');
      const parsed = require('./phones').parse(raw, 'OM');
      chatId = await this.resolveChatId(sid, { kind: 'person', ...parsed });
      const own = this.selfChatId(sid); if (own && chatId.toLowerCase() === own.toLowerCase()) mode = 'self';
    } else { chatId = this.selfChatId(sid); }
    if (!chatId) throw new Error('تعذر تحديد محادثة «الرسائل إلى نفسك» في حساب WhatsApp المرتبط. استخدم رقم المالك بعد تأكيده من مركز المساعد.');
    const result = await this.sendText(sid, chatId, String(text || '').slice(0, 3500));
    return { ok: true, mode, chatId, ack: result?.__chatBotAck?.status || result?.result?.__chatBotAck?.status || 'created' };
  }
  async sendMedia(id, chatId, file, { timeoutMs = 30000, asDocument = false, caption = '' } = {}) {
    const client = await this.ensureReady(id), sid = this.store.safeSessionId(id), absolute = path.resolve(String(file || ''));
    if (!fs.existsSync(absolute) || !fs.statSync(absolute).isFile()) throw new Error('ملف الوسائط غير موجود على الجهاز.');
    const stat = fs.statSync(absolute); if (!stat.size) throw new Error('ملف الوسائط فارغ.');
    const ext = path.extname(absolute).toLowerCase(), mimeType = MIME[ext] || 'application/octet-stream';
    const media = new MessageMedia(mimeType, fs.readFileSync(absolute).toString('base64'), path.basename(absolute));
    const options = { sendMediaAsDocument: Boolean(asDocument) };
    if (String(caption || '').trim() && !asDocument) options.caption = String(caption).slice(0, 4000);
    const r = await this.sendConfirmed(sid, chatId, () => client.sendMessage(chatId, media, options), timeoutMs, asDocument ? 'إرسال الملف كمرفق' : 'إرسال الصورة/الوسائط', options.caption || '');
    this.entry(id).lastSent = { at: new Date().toISOString(), chatId, kind: asDocument ? 'document' : (String(mimeType).startsWith('image/') ? 'image' : 'media'), filename: path.basename(absolute) }; return r;
  }
  async replyToMessage(id, message, text) {
    const content = String(text || '').trim();
    if (!content) return null;
    let chatId = chatIdFromMessage(message);
    if (!chatId) throw new Error('تعذر تحديد المحادثة للرد.');
    // Phone JIDs are the most widely accepted destination form for private chats.
    // When the inbound event exposes only an LID, resolve its verified WhatsApp
    // alias before sending; groups keep their @g.us ID unchanged.
    if (chatId.endsWith('@lid')) {
      try {
        const aliases = await this.chatIdAliases(id, chatId);
        chatId = aliases.find(alias => String(alias).toLowerCase().endsWith('@c.us')) || chatId;
      } catch {}
    }
    // Avoid Message.reply()'s internal message-key serialization, which can change
    // across WhatsApp Web releases, and send to the actual conversation explicitly.
    return this.sendText(id, chatId, content);
  }
  async reactToMessage(id, messageId, emoji) { const client = await this.ensureReady(id), mid = idSerialized(messageId); if (!mid) throw new Error('معرف الرسالة غير متاح.'); const m = await withTimeout(client.getMessageById(mid), 15000, 'البحث عن الرسالة'); if (!m) throw new Error('لم أجد الرسالة المطلوبة للـReaction.'); await withTimeout(m.react(String(emoji || '👍')), 15000, 'إرسال Reaction'); return { __chatBotAck: { status: 'confirmed', mode: 'reaction' } }; }
  async listGroups(id) {
    const client = await this.ensureReady(id), e = this.entry(id), out = [], seen = new Set();
    let chats = [];
    try { chats = await withTimeout(client.getChats(), 30000, 'قراءة محادثات WhatsApp'); }
    catch (e2) { this.log(id, 'WARN', `تعذر قراءة محادثات WhatsApp: ${safeError(e2)}`); }
    for (const chat of chats || []) {
      const gid = idSerialized(chat?.id).toLowerCase();
      if (!gid.endsWith('@g.us') && !chat?.isGroup) continue;
      try {
        const info = await this.groupInfoFromChat(chat);
        if (!/^\d+(?:-\d+)*@g\.us$/.test(info.gid) || seen.has(info.gid)) continue;
        seen.add(info.gid); e.liveGroups.set(info.gid, info); out.push(info);
      } catch (err) {
        if (gid.endsWith('@g.us')) e.liveGroups.set(gid, { gid, name: String(chat?.name || chat?.subject || gid), description:'', owner:'', participantsCount:null, participants:[], admins:[], inviteCode:'' });
        this.log(id, 'WARN', `تعذر تحليل مجموعة ${gid || 'غير معروفة'}: ${safeError(err)}`);
      }
    }
    for (const [gid, info] of e.liveGroups) if (!seen.has(gid) && /@g\.us$/.test(gid)) out.push(info);
    const unique = new Map(out.filter(x => x?.gid).map(x => [x.gid, x]));
    return [...unique.values()];
  }
  async groupInfoFromChat(chat) { let inviteCode = ''; try { if (typeof chat.getInviteCode === 'function') inviteCode = await chat.getInviteCode(); } catch {} const gid = idSerialized(chat?.id).toLowerCase(); const raw = Array.isArray(chat?.participants) ? chat.participants : (Array.isArray(chat?.groupMetadata?.participants) ? chat.groupMetadata.participants : []); const participants = raw.map(p => ({ id: idSerialized(p?.id || p).toLowerCase(), name: String(p?.name || p?.pushname || p?.notifyName || '').slice(0,120), admin: Boolean(p?.isAdmin || p?.isSuperAdmin || p?.admin) })).filter(p => p.id).slice(0,2000); const admins = participants.filter(p => p.admin).slice(0,500); return { gid, name: String(chat?.name || chat?.subject || 'مجموعة').slice(0, 120), description: String(chat?.description || '').slice(0, 1000), owner: idSerialized(chat?.groupMetadata?.owner), participantsCount: participants.length || (Array.isArray(raw) ? raw.length : null), participants, admins, inviteCode }; }
  async getGroupInfo(id, gid) { const client = await this.ensureReady(id), want = String(gid || '').trim().toLowerCase(); if (!/^\d+(?:-\d+)*@g\.us$/.test(want)) throw new Error('GID غير صالح.'); try { const chat = await client.getChatById(want); if (chat) return this.groupInfoFromChat(chat); } catch {} try { const chats = await client.getChats(); const chat = (chats || []).find(c => idSerialized(c?.id).toLowerCase() === want); if (chat) return this.groupInfoFromChat(chat); } catch {} const live = this.entry(id).liveGroups.get(want); if (live) return live; throw new Error('لم أستطع الوصول إلى هذه المجموعة داخل الجلسة الحالية. افتح المجموعة أو نفّذ اكتشاف المجموعات ثم أعد المحاولة.'); }
  async analyzeGroupInvite(id, code) { const client = await this.ensureReady(id), c = String(code || '').trim(); if (!c) throw new Error('رابط الدعوة غير صالح.'); if (typeof client.getInviteInfo !== 'function') throw new Error('إصدار المكتبة الحالي لا يوفر تحليل رابط الدعوة من دون فتح المجموعة.'); const info = await withTimeout(client.getInviteInfo(c), 20000, 'تحليل الدعوة'); return { gid: idSerialized(info?.id), name: String(info?.subject || info?.name || 'مجموعة عبر دعوة'), description: String(info?.description || ''), participantsCount: Number.isFinite(Number(info?.size)) ? Number(info.size) : null, inviteCode: c }; }
  async getGroupInfoFromMessage(id, msg) { let chat = null; try { if (typeof msg?.getChat === 'function') chat = await msg.getChat(); } catch {} if (chat) return this.groupInfoFromChat(chat); const gid = groupFromMessage(msg); if (!gid) throw new Error('الرسالة الحالية ليست من مجموعة.'); return this.getGroupInfo(id, gid); }
}
module.exports = { WhatsAppManager, safeError, idSerialized, groupFromMessage, chatIdFromMessage, matchesOutgoingIntent, matchesOutgoingConfirmation, isContextNavigationError, navigationRecoveryPlan, patchResult };
