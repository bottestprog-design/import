"use strict";
const crypto = require('node:crypto');
const { scanImages, safePath } = require('./media');
const sleep = ms => new Promise(resolve => setTimeout(resolve, Math.max(0, Number(ms) || 0)));
const safeError = e => String(e?.message || e || 'خطأ غير معروف');
function renderTemplate(text, v) {
  return String(text || '')
    .replace(/\{\{recipient\}\}/gi, v.recipient || '')
    .replace(/\{\{sender\}\}/gi, v.recipient || '')
    .replace(/\{\{phone\}\}/gi, v.phone || '')
    .replace(/\{\{number\}\}/gi, v.phone || '')
    .replace(/\{\{image\}\}/gi, v.image || '')
    .replace(/\{\{date\}\}/gi, v.date || '')
    .replace(/\{\{time\}\}/gi, v.time || '')
    .trim();
}
function hashText(v) { return crypto.createHash('sha1').update(String(v || ''), 'utf8').digest('hex').slice(0, 16); }
function nowVars(target, image, tz) { return { recipient: target.name || '', phone: target.phone || '', image: image?.filename || '', date: new Intl.DateTimeFormat('ar-OM', { timeZone: tz, dateStyle: 'short' }).format(new Date()), time: new Intl.DateTimeFormat('ar-OM', { timeZone: tz, hour: '2-digit', minute: '2-digit' }).format(new Date()) }; }
function key(stage, text, image) { return stage === 'image' ? `image:${image.id}:${image.size || 0}` : `${stage}:${hashText(text)}`; }
function assertUsable(result, label) {
  const status = result?.__chatBotAck?.status;
  if (status === 'uncertain') throw Object.assign(new Error(`${label}: لم يتم تأكيد النتيجة، لذلك لم تتم إعادة المحاولة لمنع التكرار.`), { code: 'SEND_UNCERTAIN' });
  return result;
}
class DeliveryService {
  constructor({ store, whatsapp, log }) { this.store = store; this.whatsapp = whatsapp; this.log = log; this.busy = new Set(); }
  session(id) { return this.store.loadSession(id); }
  files(id) { const s = this.session(id); return scanImages(this.store.getPaths(id).images, s.settings.maxImageSizeMB).files; }
  images(id) { return this.files(id).filter(x => x.isImage); }
  syncCycle(id) { const s = this.session(id), imgs = this.images(id), ids = imgs.map(x => x.id), old = s.cycle.imageOrder || [], current = old[s.cycle.currentIndex]; s.cycle.imageOrder = ids; const map = {}; for (const iid of ids) map[iid] = s.cycle.delivery?.[iid] || {}; s.cycle.delivery = map; if (!ids.length) s.cycle.currentIndex = 0; else if (current && ids.includes(current)) s.cycle.currentIndex = ids.indexOf(current); else s.cycle.currentIndex = Math.min(Number(s.cycle.currentIndex) || 0, ids.length - 1); this.store.saveSession(s); return s; }
  targets(s, scheduled = false, selected = null) { const recipients = s.recipients.filter(x => x.enabled !== false).map(x => ({ ...x, kind: 'recipient', targetId: x.id })); const explicitGroupSelection = Array.isArray(selected) && selected.some(k => String(k).startsWith('g:')); const groups = (!scheduled || s.settings.scheduledGroupsEnabled || explicitGroupSelection) ? s.groups.filter(x => x.enabled !== false).map(x => ({ ...x, kind: 'group', targetId: x.id, phone: '' })) : []; const all = [...recipients, ...groups]; if (!Array.isArray(selected) || !selected.length) return all; const set = new Set(selected.map(String)); return all.filter(x => set.has(`${x.kind === 'group' ? 'g' : 'r'}:${x.id}`) || set.has(x.id)); }
  state(s, image, target) { s.cycle.delivery = s.cycle.delivery || {}; s.cycle.delivery[image.id] = s.cycle.delivery[image.id] || {}; const m = s.cycle.delivery[image.id]; m[target.targetId] = m[target.targetId] || { pre: false, image: false, post: false, preKey: null, imageKey: null, postKey: null, lastError: null, round: s.cycle.round }; return m[target.targetId]; }
  done(st, flag, k) { return st[flag] === true && (!st[`${flag}Key`] || st[`${flag}Key`] === k); }
  async retry(fn, label, s, id) { let last; for (let i = 0; i < Math.max(1, s.settings.retryAttempts); i++) { try { return await fn(); } catch (e) { last = e; if (e.code === 'SEND_UNCERTAIN') throw e; if (i + 1 < Math.max(1, s.settings.retryAttempts)) { this.log(id, 'WARN', `${label}: إعادة المحاولة ${i + 1}`); await sleep(Number(s.settings.retryDelayMs) || 800); } } } throw last; }
  async sequence(id, target, image, { scheduled = true, preText, postText, caption = '', standaloneText = '', standalonePosition = 'before', sendAsDocument = false, delayMs = null, countTowardCycle = true } = {}) {
    const s = this.session(id), sendDelay = delayMs == null ? Number(s.settings.sendDelayMs) || 0 : Math.max(0, Math.min(60000, Number(delayMs) || 0)), vars = nowVars(target, image, s.settings.timezone), pre = renderTemplate(preText ?? s.settings.preText, vars), post = renderTemplate(postText ?? s.settings.postText, vars), captionText = renderTemplate(caption, vars), standalone = renderTemplate(standaloneText, vars), standaloneAfter = String(standalonePosition || 'before') === 'after', p = this.store.getPaths(id), chatId = await this.whatsapp.resolveChatId(id, target), file = image ? safePath(p.images, image.filename) : null, st = countTowardCycle && image ? this.state(s, image, target) : { pre: false, image: false, post: false, standaloneBefore: false, standaloneAfter: false }, transport = [];
    if (!image && !pre && !post && !standalone) throw new Error('اكتب رسالة أو اختر ملفًا واحدًا على الأقل.');
    const preK = image ? key('pre', preText ?? s.settings.preText, image) : `text:${hashText(preText ?? s.settings.preText)}`, imgK = image ? `${key('image', '', image)}:${hashText(captionText)}:${sendAsDocument ? 'document' : 'media'}` : '', postK = image ? key('post', postText ?? s.settings.postText, image) : '';
    try {
      if (pre && !this.done(st, 'pre', preK)) { const r = assertUsable(await this.retry(() => this.whatsapp.sendText(id, chatId, pre, { timeoutMs: s.settings.sendTimeoutMs }), 'الرسالة قبل الملف', s, id), 'قبل الملف'); transport.push(r.__chatBotAck?.status || 'created'); st.pre = true; st.preKey = preK; s.stats.sentMessages++; if (r.__chatBotAck?.status === 'confirmed') s.stats.confirmedAcks++; if (r.__chatBotAck?.status === 'created') s.stats.createdSends++; this.store.saveSession(s); await sleep(sendDelay); }
      const sendStandalone = async (flag) => { if (!standalone || st[flag]) return; const r = assertUsable(await this.retry(() => this.whatsapp.sendText(id, chatId, standalone, { timeoutMs: s.settings.sendTimeoutMs }), 'النص الرئيسي', s, id), 'النص الرئيسي'); transport.push(r.__chatBotAck?.status || 'created'); st[flag] = true; s.stats.sentMessages++; if (r.__chatBotAck?.status === 'confirmed') s.stats.confirmedAcks++; if (r.__chatBotAck?.status === 'created') s.stats.createdSends++; this.store.saveSession(s); await sleep(sendDelay); };
      if (standalone && !standaloneAfter) await sendStandalone('standaloneBefore');
      if (image && !this.done(st, 'image', imgK)) { const r = assertUsable(await this.retry(() => this.whatsapp.sendMedia(id, chatId, file, { timeoutMs: s.settings.sendTimeoutMs, asDocument: Boolean(sendAsDocument || !image.isImage), caption: captionText }), 'الوسائط', s, id), 'الوسائط'); transport.push(r.__chatBotAck?.status || 'created'); st.image = true; st.imageKey = imgK; (image.isImage && !sendAsDocument) ? s.stats.sentImages++ : s.stats.sentFiles++; if (r.__chatBotAck?.status === 'confirmed') s.stats.confirmedAcks++; if (r.__chatBotAck?.status === 'created') s.stats.createdSends++; this.store.saveSession(s); await sleep(sendDelay); }
      if (standalone && standaloneAfter) await sendStandalone('standaloneAfter');
      if (post && !this.done(st, 'post', postK)) { const r = assertUsable(await this.retry(() => this.whatsapp.sendText(id, chatId, post, { timeoutMs: s.settings.sendTimeoutMs }), 'الرسالة بعد الملف', s, id), 'بعد الملف'); transport.push(r.__chatBotAck?.status || 'created'); st.post = true; st.postKey = postK; s.stats.sentMessages++; if (r.__chatBotAck?.status === 'confirmed') s.stats.confirmedAcks++; if (r.__chatBotAck?.status === 'created') s.stats.createdSends++; this.store.saveSession(s); }
      return { ...st, transport };
    } catch (caught) {
      const e = caught instanceof Error ? caught : new Error(safeError(caught));
      if (e.code === 'SEND_UNCERTAIN') s.stats.uncertainSends++;
      st.lastError = safeError(e); this.store.saveSession(s);
      e.chatBotProgress = { pre: st.pre === true, image: st.image === true, post: st.post === true, standaloneBefore: st.standaloneBefore === true, standaloneAfter: st.standaloneAfter === true, transport: [...transport], persisted: Boolean(countTowardCycle && image) };
      throw e;
    }
  }
  allComplete(s, image, targets, { preText = s.settings.preText, postText = s.settings.postText } = {}) { return targets.every(t => { const st = s.cycle.delivery?.[image.id]?.[t.targetId] || {}, vars = nowVars(t, image, s.settings.timezone), pre = renderTemplate(preText, vars), post = renderTemplate(postText, vars); return this.done(st, 'image', `${key('image', '', image)}:${hashText('')}:media`) && (!pre || this.done(st, 'pre', key('pre', preText, image))) && (!post || this.done(st, 'post', key('post', postText, image))); }); }
  advance(id, { preText, postText, selectedTargets = null } = {}) { const s = this.syncCycle(id), imgs = this.images(id), cur = imgs[s.cycle.currentIndex]; if (!cur) return false; const targets = this.targets(s, true, Array.isArray(selectedTargets) ? selectedTargets : s.settings.scheduleTargetKeys); if (!targets.length || !this.allComplete(s, cur, targets, { preText: preText ?? s.settings.preText, postText: postText ?? s.settings.postText })) return false; if (s.cycle.currentIndex >= imgs.length - 1) { s.cycle.round++; s.cycle.roundStartedAt = new Date().toISOString(); s.cycle.currentIndex = 0; s.cycle.delivery = {}; s.cycle.manualGuard = {}; this.store.saveSession(s); this.log(id, 'INFO', `اكتملت دورة الملفات وبدأت الجولة ${s.cycle.round}.`); } else { s.cycle.currentIndex++; this.store.saveSession(s); } return true; }
  scheduleImage(id) { const s = this.syncCycle(id), files = this.files(id); if (s.settings.scheduleMediaId) { const fixed = files.find(x => x.id === s.settings.scheduleMediaId); if (fixed) return { image: fixed, fixed: true }; } const imgs = this.images(id); return { image: imgs[s.cycle.currentIndex] || imgs[0] || null, fixed: false }; }
  async scheduledRun(id) { const sid = this.store.safeSessionId(id); if (this.busy.has(sid)) return { ok: false, message: 'يوجد إرسال قيد التنفيذ.' }; this.busy.add(sid); try { const s0 = this.session(sid), { image, fixed } = this.scheduleImage(sid), targets = this.targets(s0, true, s0.settings.scheduleTargetKeys), preText = s0.settings.schedulePreText !== '' ? s0.settings.schedulePreText : s0.settings.preText, postText = s0.settings.schedulePostText !== '' ? s0.settings.schedulePostText : s0.settings.postText; if (!image && !String(preText || '').trim() && !String(postText || '').trim()) return { ok: false, retry: false, message: 'أضف ملفًا أو نصًا للجدولة.' }; if (!targets.length) return { ok: false, retry: false, message: 'لا توجد أهداف مفعلة للجدولة.' }; await this.whatsapp.ensureReady(sid); const sent = [], failed = []; for (const target of targets) { try { await this.sequence(sid, target, image, { scheduled: true, preText, postText, countTowardCycle: !fixed }); sent.push({ target: target.name, kind: target.kind, image: image?.filename || null }); } catch (e) {
        const progress = e.chatBotProgress || {};
        const completedSteps = Object.entries(progress).filter(([key, value]) => ['pre','image','post','standaloneBefore','standaloneAfter'].includes(key) && value === true).map(([key]) => key);
        failed.push({ target: target.name, kind: target.kind, image: image?.filename || null, error: safeError(e), code: e.code || null, partialDelivery: completedSteps.length > 0, progressPersisted: progress.persisted === true, completedSteps, transport: progress.transport || [] });
        const fresh = this.session(sid); fresh.stats.failedSends++; this.store.saveSession(fresh);
      } } const s = this.session(sid); const complete = fixed ? failed.length === 0 : (image ? this.allComplete(s, image, targets, { preText, postText }) : failed.length === 0); if (complete && !fixed && image) this.advance(sid, { preText, postText, selectedTargets: s.settings.scheduleTargetKeys }); const fresh = this.session(sid); fresh.lastRun = { at: new Date().toISOString(), type: 'scheduled', image: image?.filename || null, round: fresh.cycle.round, sent, failed, complete }; complete ? fresh.stats.successfulRuns++ : fresh.stats.failedRuns++; this.store.saveSession(fresh); return { ok: failed.length === 0, retry: failed.length > 0, sent, failed, complete, image: image?.filename || null, round: fresh.cycle.round }; } finally { this.busy.delete(sid); } }
  cleanupManualGuard(s, windowMs) { const guard = s.cycle.manualGuard || {}, now = Date.now(); for (const [k, v] of Object.entries(guard)) { const at = typeof v === 'number' ? v : Number(v?.at || 0); if (!at || now - at > windowMs) delete guard[k]; } s.cycle.manualGuard = guard; }
  async sendNow(id, { targetKeys = [], targets = [], recipientIds = [], groupIds = [], mediaId, filename, mediaIds = [], text = '', caption = '', captionMode = false, textMode = null, sendAsDocument = false, sendDelayMs = null, beforeText, afterText, preText, postText, sendOrder = 'target-first', countTowardCycle = false, repeatGuard = true, replaceDuplicate = false } = {}) {
    const sid = this.store.safeSessionId(id); if (this.busy.has(sid)) throw new Error('يوجد إرسال آخر قيد التنفيذ.'); this.busy.add(sid);
    try {
      let s = this.session(sid), files = this.files(sid), requested = [...(Array.isArray(mediaIds) ? mediaIds : []), mediaId, filename].filter(Boolean).map(String); requested = [...new Set(requested)];
      const mediaList = requested.map(x => files.find(f => f.id === x)).filter(Boolean); if (requested.length !== mediaList.length) throw new Error('بعض الملفات المحددة غير موجودة.');
      const selectedKeys = Array.isArray(targetKeys) && targetKeys.length ? targetKeys : (Array.isArray(targets) && targets.length ? targets : [...recipientIds.map(x => `r:${x}`), ...groupIds.map(x => `g:${x}`)]);
      if (!selectedKeys.length) throw new Error('حدد مستلمًا أو مجموعة واحدة على الأقل.');
      const targetList = this.targets(s, false, selectedKeys); if (!targetList.length) throw new Error('لا توجد أهداف مفعّلة ضمن الاختيار.');
      const mainText = String(text || caption || '').trim();
      let placement = String(textMode || ((captionMode || caption) ? 'auto' : 'before')).toLowerCase();
      if (!['auto','caption','before','after','none'].includes(placement)) placement = 'before';
      if (placement === 'auto') placement = mediaList.length && mediaList.every(f => f.isImage) && !sendAsDocument ? 'caption' : 'before';
      if (!mediaList.length && placement === 'caption') placement = 'before';
      if (placement === 'caption' && (mediaList.some(f => !f.isImage) || sendAsDocument)) placement = 'before';
      // WhatsApp captions are smaller than standalone text messages. Preserve long text by sending it as a separate message instead of silently truncating it.
      if (placement === 'caption' && mainText.length > 4000) placement = 'before';
      const basePreText = preText ?? beforeText;
      const basePostText = postText ?? afterText;
      const deliverMainText = placement === 'none' ? '' : mainText;
      if (!mediaList.length && !deliverMainText && !String(basePreText ?? s.settings.preText ?? '').trim() && !String(basePostText ?? s.settings.postText ?? '').trim()) throw new Error('اكتب رسالة أو اختر ملفًا واحدًا على الأقل.');
      if (mediaList.length && placement !== 'none' && !mainText && !String(basePreText ?? s.settings.preText ?? '').trim() && !String(basePostText ?? s.settings.postText ?? '').trim()) {
        // Sending attachments without a caption or surrounding text is valid; don't block it.
      }
      const jobs = [];
      if (mediaList.length && sendOrder === 'image-first') { for (const image of mediaList) for (const target of targetList) jobs.push({ image, target }); }
      else { for (const target of targetList) { if (mediaList.length) for (const image of mediaList) jobs.push({ image, target }); else jobs.push({ image: null, target }); } }
      const seenByTarget = new Map(), countsByTarget = new Map();
      for (const job of jobs) countsByTarget.set(job.target.targetId, (countsByTarget.get(job.target.targetId) || 0) + 1);
      for (const job of jobs) { const index = seenByTarget.get(job.target.targetId) || 0; job.targetJobIndex = index; job.targetJobCount = countsByTarget.get(job.target.targetId) || 1; seenByTarget.set(job.target.targetId, index + 1); }
      this.cleanupManualGuard(s, 90000); this.store.saveSession(s);
      const sent = [], failed = [], captions = [];
      for (const job of jobs) {
        const { image, target } = job;
        let jobPreText = basePreText, jobPostText = basePostText, jobCaption = '', jobStandalone = '', standalonePosition = 'before';
        const isFirstForTarget = job.targetJobIndex === 0, isLastForTarget = job.targetJobIndex === job.targetJobCount - 1;
        if (deliverMainText && placement === 'before' && isFirstForTarget) jobStandalone = deliverMainText;
        else if (deliverMainText && placement === 'after' && isLastForTarget) { jobStandalone = deliverMainText; standalonePosition = 'after'; }
        else if (deliverMainText && placement === 'caption' && image?.isImage && !sendAsDocument) jobCaption = deliverMainText;
        const effectivePre = jobPreText ?? s.settings.preText, effectivePost = jobPostText ?? s.settings.postText;
        const fingerprint = crypto.createHash('sha1').update(JSON.stringify([target.targetId, image?.id || 'text', effectivePre, effectivePost, jobCaption, jobStandalone, standalonePosition, Boolean(sendAsDocument), placement]), 'utf8').digest('hex');
        if (repeatGuard && s.cycle.manualGuard?.[fingerprint] && !replaceDuplicate) { failed.push({ target: target.name, kind: target.kind, image: image?.filename || null, error: 'تم منع إرسال مطابق خلال آخر 90 ثانية.', code: 'DUPLICATE_GUARD' }); continue; }
        try {
          const delivery = await this.sequence(sid, target, image, { scheduled: false, preText: jobPreText, postText: jobPostText, caption: jobCaption, standaloneText: jobStandalone, standalonePosition, sendAsDocument, delayMs: sendDelayMs, countTowardCycle });
          const transport = Array.isArray(delivery.transport) ? delivery.transport : [];
          const status = transport.length && transport.every(item => item === 'confirmed') ? 'confirmed' : 'created';
          sent.push({ target: target.name, kind: target.kind, image: image?.filename || null, captioned: Boolean(jobCaption), status, transport });
          if (jobCaption) captions.push({ target: target.name, image: image.filename });
          s = this.session(sid); s.cycle.manualGuard = s.cycle.manualGuard || {}; s.cycle.manualGuard[fingerprint] = { at: Date.now(), target: target.name, image: image?.filename || null }; this.store.saveSession(s);
        } catch (e) {
          const progress = e.chatBotProgress || {};
          const completedSteps = Object.entries(progress).filter(([key, value]) => ['pre','image','post','standaloneBefore','standaloneAfter'].includes(key) && value === true).map(([key]) => key);
          failed.push({ target: target.name, kind: target.kind, image: image?.filename || null, error: safeError(e), code: e.code || null, partialDelivery: completedSteps.length > 0, progressPersisted: progress.persisted === true, completedSteps, transport: progress.transport || [] });
          const fresh = this.session(sid); fresh.stats.failedSends++; this.store.saveSession(fresh);
        }
      }
      return { ok: failed.length === 0, sent, failed, images: mediaList.map(x => x.filename), captions: captions.length };
    } finally { this.busy.delete(sid); }
  }
  async scheduledTaskRun(id, task) {
    const targets = Array.isArray(task.targetKeys) ? task.targetKeys.filter(Boolean) : [];
    if (task.scheduledGroupsEnabled === false) {
      const groupKeys = new Set((this.session(id).groups || []).map(group => `g:${group.id}`));
      const filtered = targets.filter(key => !groupKeys.has(String(key)));
      targets.splice(0, targets.length, ...filtered);
    }
    if (!targets.length) throw new Error(`الموعد «${task.name || 'بدون اسم'}» لا يحتوي أهدافًا مفعّلة.`);
    const session = this.session(id);
    let mediaIds = task.mediaMode === 'cycle' ? [] : (Array.isArray(task.mediaIds) ? task.mediaIds.filter(Boolean) : []);
    if (task.mediaMode === 'cycle') {
      const current = this.currentImage(id);
      if (current) mediaIds = [current.id];
    }
    const mainText = String(task.text ?? '');
    const preText = String(task.preText ?? '');
    const postText = String(task.postText ?? '');
    let textMode = ['auto', 'caption', 'before', 'after', 'none'].includes(task.textMode)
      ? task.textMode
      : (mainText ? 'auto' : 'before');
    // If captions are disabled or any selected attachment cannot carry a WhatsApp
    // image caption, retain the main text as a separate message instead of dropping it.
    const selectedFiles = mediaIds.length ? this.files(id).filter(file => mediaIds.includes(String(file.id))) : [];
    const captionUnsupported = Boolean(task.sendAsDocument === true) || !selectedFiles.length || selectedFiles.some(file => file.isImage !== true);
    if (['auto', 'caption'].includes(textMode) && (task.captionMode === false || captionUnsupported)) textMode = 'before';
    if (!mediaIds.length && !mainText.trim() && !preText.trim() && !postText.trim()) {
      throw new Error(`الموعد «${task.name || 'بدون اسم'}» لا يحتوي رسالة أو ملفات.`);
    }
    if (textMode === 'none' && !preText.trim() && !postText.trim() && !mediaIds.length) {
      throw new Error(`الموعد «${task.name || 'بدون اسم'}»: تم تعطيل النص الرئيسي ولم تختر ملفات أو رسائل إضافية.`);
    }
    await this.whatsapp.ensureReady(id);
    const result = await this.sendNow(id, {
      targetKeys: targets,
      mediaIds,
      text: mainText,
      textMode,
      captionMode: task.captionMode !== false,
      sendAsDocument: task.sendAsDocument === true,
      sendDelayMs: task.sendDelayMs,
      preText,
      postText,
      sendOrder: task.sendOrder || 'target-first',
      repeatGuard: false,
      replaceDuplicate: false,
      countTowardCycle: false,
    });
    if (task.mediaMode === 'cycle' && result.ok && mediaIds.length) {
      const fresh = this.session(id), images = this.images(id), index = images.findIndex(item => item.id === mediaIds[0]);
      if (index >= 0) {
        fresh.cycle.imageOrder = images.map(item => item.id);
        fresh.cycle.currentIndex = (index + 1) % Math.max(1, images.length);
        if (index === images.length - 1) { fresh.cycle.round++; fresh.cycle.delivery = {}; }
        this.store.saveSession(fresh);
      }
    }
    return { ...result, complete: result.ok, taskId: task.id, taskName: task.name || 'موعد', scheduled: true };
  }
  currentImage(id) { const s = this.syncCycle(id), imgs = this.images(id); return imgs[s.cycle.currentIndex] || imgs[0] || null; }
}
module.exports = { DeliveryService, renderTemplate, hashText, safeError };
