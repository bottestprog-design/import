"use strict";
function clean(v){return String(v||'').normalize('NFKC').trim().toLowerCase()}
function jidOf(v){ if(!v)return ''; if(typeof v==='string')return v; const x=v||{}; const id=x.id||null; const remote=x.remote||null; const candidate=x._serialized||x.$1||id?._serialized||id?.$1||remote?._serialized||remote?.$1||''; return String(candidate); }
function person(v){ const rawId = typeof v === 'string' ? v : (v?.id || v); return { id: jidOf(rawId).toLowerCase(), name:String(v?.name||v?.pushname||v?.notifyName||v?.formattedName||'').slice(0,120), admin:Boolean(v?.isAdmin||v?.isSuperAdmin||v?.admin) }; }
function normalizeGid(v){
  let s=clean(v).replace(/^jid[:=]\s*/,'').replace(/^whatsapp:\/\//,'');
  s=s.replace(/^(?:https?:\/\/)?[^/]+\/jid\//,'');
  if(/^\d+(?:-\d+)*$/.test(s))s+='@g.us';
  if(!/^\d+(?:-\d+)*@g\.us$/i.test(s))throw new Error('GID غير صالح. استخدم صيغة رقم المجموعة الحقيقي متبوعًا بـ @g.us');
  return s;
}
function isGroupId(v){try{normalizeGid(v);return true}catch{return false}}
function extractInviteCode(v){
  const s=String(v||'').trim();
  const m=s.match(/(?:https?:\/\/)?chat\.whatsapp\.com\/([A-Za-z0-9_-]+)/i);
  return m?m[1]:s.replace(/^https?:\/\//i,'').split(/[?#\/\s]/)[0];
}

function parseGroupRequest(body, currentGid = '') {
  const text = String(body || '').trim();
  if (!text) return null;
  const inviteMatch = text.match(/(?:https?:\/\/)?chat\.whatsapp\.com\/([A-Za-z0-9_-]+)/i);
  if (inviteMatch) return { kind: 'invite', code: inviteMatch[1], url: `https://chat.whatsapp.com/${inviteMatch[1]}` };
  const commandText = text.replace(/^(?:(?:يا\s*بوت|شات\s*بوت|chat\s*bot)[\s،,:!؟-]*)+/iu, '').replace(/^(?:(?:ممكن|لو\s*سمحت|من\s*فضلك|عايز|عاوز|عايزة|هات|وريني|اعرض(?:لي)?|جيب|حلل|حلّل|شوف)\s+)+/iu, '').trim();
  const gidMatch = commandText.match(/(?:^|[\s(])((?:\d{5,25})(?:-\d+)*@g\.us)(?=$|[\s)])/i);
  const commandMatch = commandText.match(/^(?:!|\/)?(?:gid|group\s*id|groupid|group\s*info|group\s*analysis|معرف\s*(?:المجموعة|القروب)|تحليل\s*(?:المجموعة|القروب)|معلومات(?:\s+عن)?\s*(?:المجموعة|القروب)|معلومات\s*الجروب)(?:\s*[:：-]?\s*)(.*)$/iu);
  if (gidMatch && (commandMatch || commandText.toLowerCase() === gidMatch[1].toLowerCase())) return { kind: 'gid', gid: normalizeGid(gidMatch[1]), explicit: true };
  if (!commandMatch) return null;
  const target = String(commandMatch[1] || '').trim();
  if (target && isGroupId(target)) return { kind: 'gid', gid: normalizeGid(target), explicit: true };
  if (target) return { kind: 'invalid-target', target, explicit: true };
  if (currentGid && isGroupId(currentGid)) return { kind: 'current', gid: normalizeGid(currentGid), explicit: true };
  return { kind: 'usage', explicit: true };
}

function fromChat(chat){
  const id=chat?.id; const gid=jidOf(id).toLowerCase();
  const rawParticipants = Array.isArray(chat?.participants) ? chat.participants : (Array.isArray(chat?.groupMetadata?.participants) ? chat.groupMetadata.participants : []);
  const participants=rawParticipants.map(person).filter(x=>x.id).slice(0,2000);
  const admins=participants.filter(x=>x.admin);
  return {gid,name:String(chat?.name||chat?.subject||'مجموعة').slice(0,120),description:String(chat?.description||'').slice(0,1000),owner:jidOf(chat?.groupMetadata?.owner),participantsCount:participants.length || (Number.isFinite(Number(chat?.groupMetadata?.size)) ? Number(chat.groupMetadata.size) : null),participants,admins};
}
function normalizeInfo(info,gid=''){const participants=Array.isArray(info?.participants)?info.participants.map(person).filter(x=>x.id).slice(0,2000):[];const admins=Array.isArray(info?.admins)?info.admins.map(person).filter(x=>x.id).slice(0,500):participants.filter(x=>x.admin);return {name:String(info?.name||info?.subject||'مجموعة').slice(0,120),gid:String(info?.gid||gid||'').trim().toLowerCase(),inviteCode:String(info?.inviteCode||''),description:String(info?.description||'').slice(0,1000),owner:String(info?.owner||''),participantsCount:Number.isFinite(Number(info?.participantsCount??info?.size))?Number(info?.participantsCount??info?.size):(participants.length||null),participants,admins}}
function formatGroupAnalysis(info){const x=normalizeInfo(info);const all=x.participants;const listed=all.slice(0,30);const people=listed.map(p=>`- ${p.name||'بدون اسم'} | ${p.id}${p.admin?' | مشرف':''}`).join('\n');const extra=all.length>listed.length?`\n… وأعضاء آخرون (${all.length-listed.length})`:'';return `الاسم: ${x.name}\nGID: ${x.gid||'غير متاح'}\nالأعضاء: ${x.participantsCount??'غير معروف'}\nالمشرفون: ${x.admins.length}\nالمالك: ${x.owner||'غير معروف'}\nالوصف: ${x.description||'—'}\nرمز الدعوة: ${x.inviteCode||'غير متاح'}${people?`\n\nأول ${listed.length} عضوًا:\n${people}${extra}`:''}`.slice(0,58000);}
module.exports={normalizeGid,isGroupId,extractInviteCode,normalizeInfo,formatGroupAnalysis,fromChat,parseGroupRequest};
