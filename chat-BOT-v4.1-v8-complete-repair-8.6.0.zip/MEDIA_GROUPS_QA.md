# QA — media, sending, and groups (8.3.0)

## Automated checks

`npm run verify` and `npm test` passed in the source workspace. Coverage includes JavaScript syntax, API/UI presence checks, visual checks, local command assistant tests, smoke/regression tests, send-flow tests and outgoing/incoming chat-ID association.

`test/send-media.js` uses a fake WhatsApp transport. It verifies: image caption, correct target chat, standalone text once across multiple files, automatic standalone text with PDF, text-after mode, text-only delivery, refusal to send with an empty target set, and refusal of text-only mode when no media remains.

`test/whatsapp-identifiers.js` verifies that an outgoing message's acknowledgement maps to its recipient chat rather than the sender's own account, and that incoming messages map to the sender.

## Scope / limitations

- No live WhatsApp account was linked and no real message was sent during testing. Actual connectivity, account-specific recipient eligibility and end-to-end receipt must be verified on the user's machine with a test recipient.
- The ACK reported by WhatsApp Web is not evidence that a person read the message. The UI avoids marking an unacknowledged operation as confirmed.
- PDF, TXT, image, video and audio previews are supported in the current UI. Office formats that the browser cannot decode (especially legacy DOC/XLS/PPT) use a file-type card, not a fake document screenshot.
- Group member data shown depends on what the connected WhatsApp session exposes. Local deletion removes a group only from this project's saved list and references.
- Upload is capped by the per-session maximum as well as the server's 50 MB request limit.
