# Session reliability and private owner assistant — 8.4.1

## Session isolation
- Request client attaches the selected session ID to API URLs and bodies.
- Unknown/deleted sessions are rejected instead of silently recreated by API entry points and media routes.
- Creating a session explicitly switches to the newly returned ID; deleting a session switches to the valid active ID supplied by the server.
- Store deletion and rename reject missing IDs and remove only the selected session directory.
- WhatsApp `start` returns an existing client for starting/QR/authenticated state. It rejects overlapping starts while stopping, and guards state updates by generation and promise identity to reduce stale-start race conditions.

## Private assistant center
- Persistent session-scoped welcome, messages, issues, diagnostic timestamp and pending notification queue.
- Actionable issue steps point to the affected application page.
- Optional WhatsApp notifications use the owner's self-chat when supported, or a phone the user enters and confirms.
- Failed welcome remains local and is retried on a subsequent ready event; notification failures stay visible in the support center.
- Local self-chat command handling: help, diagnostics, connection status, send/recipient troubleshooting and session guidance.

## Safety and delivery
- No external generative API is used by the local assistant.
- The owner phone route is gated on explicit phone confirmation.
- A live WhatsApp send was not run during build verification; use the test-notification action after linking a real session.
