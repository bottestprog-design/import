# QA — chat BOT 8.4.6

## Passed locally

- `npm test` covers syntax, full-file audit, imports, sessions, media, WhatsApp ID routing, schedules and partial failures, owner assistant, and local command engine.
- The local command tests verify actual mutations in a test store and calls to mocked services, not just a returned success string.
- Test scenarios include adding/renaming/toggling/removing a recipient, group invite analysis and save, group rename duplicate rejection, schedule create/pause/enable/manual run, sending chosen PDF plus text to one recipient, self-send test, media deletion, interaction-rule CRUD and self-chat opt-in, issue resolution, notification settings and safe session deletion.
- The owner assistant tests verify the self-chat command path, welcome and updated command list version.
- Local command help is 2,533 characters; it is sent in the connection message and updated on version change.

## Not live-verified

This environment does not connect to the user's actual WhatsApp account. Link analysis, WhatsApp phone validation, QR login, real message delivery/ACK and scheduled delivery against the user's account are not claimed as live-tested; the integration tests use controlled service mocks. After installing and linking WhatsApp, test a single command in the self-chat and then one known test recipient before using group sends.
