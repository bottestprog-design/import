'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');
const { DeliveryService } = require('../src/delivery');

const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-delivery-'));
const imagesDir = path.join(temp, 'images'); fs.mkdirSync(imagesDir, { recursive: true });
fs.writeFileSync(path.join(imagesDir, '0001__test.jpg'), Buffer.from([0xff,0xd8,0xff,0xd9]));
const session = {
  id:'demo', name:'Demo',
  recipients:[{id:'r1',name:'نور',phone:'96890000000',enabled:true}],
  settings:{maxImageSizeMB:5,timezone:'Asia/Muscat',preText:'chat BOT',postText:'تمت الصورة {{image}}',retryAttempts:1,retryDelayMs:10,sendDelayMs:0},
  cycle:{imageOrder:[],currentIndex:0,delivery:{}},
  stats:{sentImages:0,sentMessages:0,confirmedAcks:0,uncertainSends:0},
  lastRun:null
};
const fakeStore = {
  safeSessionId:x=>x,
  loadSession:()=>JSON.parse(JSON.stringify(session)),
  saveSession:s=>{Object.assign(session, JSON.parse(JSON.stringify(s))); return session;},
  getPaths:()=>({images:imagesDir}),
};
const calls=[];
const ok = kind => ({ __chatBotAck:{status:'confirmed',ack:1}, id:{_serialized:`m-${calls.length+1}`} });
const fakeWhatsapp = {
  resolveChatId: async ()=> '96890000000@c.us',
  sendText: async (_id,chat,text)=>{calls.push(['text',chat,text]);return ok('text');},
  sendMedia: async (_id,chat,file)=>{calls.push(['media',chat,path.basename(file)]);return ok('media');},
};
const delivery = new DeliveryService({store:fakeStore, whatsapp:fakeWhatsapp, log:()=>{}});
(async()=>{
  const image = delivery.currentImage('demo');
  assert.equal(image.filename,'0001__test.jpg');
  const result = await delivery.sequence('demo', session.recipients[0], image, {scheduled:false});
  assert.deepEqual(calls.map(x=>x[0]), ['text','media','text']);
  assert.equal(calls[0][2],'chat BOT');
  assert.match(calls[1][2], /0001__test\.jpg/);
  assert.match(calls[2][2], /تمت الصورة/);
  assert.equal(result.pre, true); assert.equal(result.image, true); assert.equal(result.post, true);
  console.log('PASS  delivery sequence end-to-end');
})().catch(e=>{console.error(`FAIL  delivery sequence end-to-end: ${e.message}`);process.exitCode=1;});
