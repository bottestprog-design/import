(() => {
  'use strict';

  const state = {
    data: null,
    countries: null,
    page: location.hash.slice(1) || 'dashboard',
    bgEngine: null,
    selectedGroup: null,
    pendingTargets: null,
    peopleFilter: '',
    groupFilter: '',
    settingsView: 'appearance',
    loadPromise: null,
    loadController: null,
    bgLivePending: 0,
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const sid = () => $('#sessionSelect')?.value || state.data?.session?.id || '';

  function activeTargets(data) {
    return [
      ...(data.recipients || []).map((x) => ({ ...x, key: `r:${x.id}`, type: 'recipient' })),
      ...(data.groups || []).map((x) => ({ ...x, key: `g:${x.id}`, type: 'group' })),
    ];
  }

  function chatIdForTarget(target) {
    if (!target) return '';
    if (target.type === 'group') return String(target.gid || '').toLowerCase();
    const digits = String(target.digits || target.phone || '').replace(/\D/g, '');
    return digits ? `${digits}@c.us` : String(target.chatId || '').toLowerCase();
  }

  function typeLabel(target) {
    return target?.type === 'group' ? 'مجموعة' : 'شخص';
  }

  async function api(url, options = {}) {
    const isForm = options.body instanceof FormData;
    const headers = { ...(isForm ? {} : { 'Content-Type': 'application/json' }), ...(options.headers || {}) };
    const response = await fetch(url, { ...options, headers });
    const raw = await response.text();
    let body = {};
    try { body = raw ? JSON.parse(raw) : {}; } catch { body = { raw }; }
    if (!response.ok || body.ok === false) throw new Error(body.error || body.raw || `HTTP ${response.status}`);
    return body;
  }

  function notify(message, type = 'info') {
    const toast = $('#toast');
    if (!toast) return;
    toast.className = `toast ${type}`;
    toast.textContent = message;
    toast.hidden = false;
    clearTimeout(notify.timer);
    notify.timer = setTimeout(() => { toast.hidden = true; }, 4200);
  }

  async function load(force = false) {
    if (state.loadPromise) return state.loadPromise;
    state.loadPromise = (async () => {
      state.loadController?.abort();
      const controller = new AbortController();
      state.loadController = controller;
      const current = sid();
      const query = current ? `?sessionId=${encodeURIComponent(current)}${force ? '&fresh=1' : ''}` : '';
      try {
        state.data = await api(`/api/state${query}`, { signal: controller.signal });
        if (!controller.signal.aborted) render();
      } finally {
        if (state.loadController === controller) state.loadController = null;
      }
    })();
    try { return await state.loadPromise; }
    finally { state.loadPromise = null; }
  }

  async function loadCountries() {
    if (!state.countries) state.countries = await api('/api/countries');
    return state.countries;
  }

  function countryOptions(selected = 'OM') {
    return (state.countries?.countries || []).map((country) => `<option value="${esc(country.code)}" ${country.code === selected ? 'selected' : ''}>+${esc(country.callingCode)} · ${esc(country.code)}</option>`).join('');
  }

  function nav() {
    const items = [
      ['dashboard', '⌂', 'الرئيسية'],
      ['send', '➜', 'الإرسال'],
      ['people', '●', 'الأشخاص'],
      ['groups', '◆', 'المجموعات'],
      ['interaction', '✦', 'التفاعل'],
      ['session', '◉', 'الجلسة'],
      ['settings', '⚙', 'الإعدادات'],
    ];
    return items.map(([id, icon, label]) => `<button class="navbtn ${state.page === id ? 'active' : ''}" data-page="${id}" aria-current="${state.page === id ? 'page' : 'false'}"><span class="nav-icon">${icon}</span><span>${label}</span></button>`).join('');
  }

  function shell(content) {
    const data = state.data || { session: {}, sessions: [], whatsapp: {} };
    const ready = !!data.whatsapp?.ready;
    return `<div class="app-shell">
      <header class="topbar">
        <div class="brand">
          <span class="brand-mark">✦</span>
          <div><strong>chat BOT</strong><small>مركز تحكم محلي بسيط</small></div>
        </div>
        <div class="top-actions">
          <label class="session-picker"><span>الجلسة</span><select id="sessionSelect">${(data.sessions || []).map((session) => `<option value="${esc(session.id)}" ${session.id === data.session.id ? 'selected' : ''}>${esc(session.name || session.id)}</option>`).join('')}</select></label>
          <span class="status-pill ${ready ? 'ready' : ''}"><span class="status-dot"></span>${ready ? 'متصل' : (data.whatsapp?.status === 'qr' ? 'بانتظار QR' : 'غير متصل')}</span>
          <button class="icon-btn" id="refreshBtn" title="تحديث">↻</button>
        </div>
      </header>
      <nav class="navrow">${nav()}</nav>
      <main class="main">${content}</main>
      <div id="toast" class="toast" hidden></div>
    </div>`;
  }

  function pageDashboard(data) {
    const targets = activeTargets(data);
    const stats = data.stats || {};
    const logs = (data.logs || []).slice(0, 12);
    const runtime = data.whatsapp || {};
    return `<section class="hero-card">
      <div><p class="eyebrow">لوحة الجلسة الحالية</p><h1>${esc(data.session?.name || 'الجلسة الرئيسية')}</h1><p>كل شيء واضح من هنا: الإرسال، الأشخاص، المجموعات، التفاعل والسجل.</p></div>
      <div class="hero-actions"><button class="btn primary" data-go="send">إرسال الآن</button><button class="btn" data-go="interaction">التفاعل</button></div>
    </section>
    <section class="stats-grid">
      <article class="stat-card"><span>الحالة</span><b>${runtime.ready ? 'جاهز' : 'غير متصل'}</b><small>${runtime.info?.wid?.user ? '+' + esc(runtime.info.wid.user) : 'اربط الحساب من الجلسة'}</small></article>
      <article class="stat-card"><span>الأشخاص</span><b>${(data.recipients || []).length}</b><small>هذه الجلسة</small></article>
      <article class="stat-card"><span>المجموعات</span><b>${(data.groups || []).length}</b><small>هذه الجلسة</small></article>
      <article class="stat-card"><span>الإرسال</span><b>${Number(stats.sentMessages || 0) + Number(stats.sentImages || 0) + Number(stats.sentFiles || 0)}</b><small>عمليات تم تسجيلها</small></article>
    </section>
    <section class="content-grid two-col">
      <article class="panel"><div class="panel-head"><div><h2>الوصول السريع</h2><p>اختصر الطريق إلى المهمة التي تريدها.</p></div></div>
        <div class="quick-list">
          <button class="quick-item" data-go="send"><span class="quick-icon">➜</span><span><b>رسالة جديدة</b><small>حدد الأهداف والملفات ثم أرسل.</small></span></button>
          <button class="quick-item" data-go="people"><span class="quick-icon">＋</span><span><b>إضافة أشخاص</b><small>أرقام دولية وقوائم متعددة.</small></span></button>
          <button class="quick-item" data-go="groups"><span class="quick-icon">◆</span><span><b>المجموعات</b><small>اكتشاف، ربط، تحليل وحفظ.</small></span></button>
          <button class="quick-item" data-go="settings"><span class="quick-icon">⚙</span><span><b>الإعدادات</b><small>المظهر والخلفيات والتشغيل.</small></span></button>
        </div>
      </article>
      <article class="panel"><div class="panel-head"><div><h2>آخر نشاط</h2><p>السجل محفوظ لهذه الجلسة فقط.</p></div><button class="btn small" id="dashboardRefresh">تحديث</button></div>
        <div class="log-list">${logs.length ? logs.map(logRow).join('') : '<div class="empty">لا يوجد نشاط بعد.</div>'}</div>
      </article>
    </section>`;
  }

  function logRow(log) {
    const at = log.at || log.time || log.timestamp || '';
    const date = at ? new Date(at) : null;
    const when = date && !Number.isNaN(date.getTime()) ? date.toLocaleString('ar-OM') : '';
    const level = String(log.level || 'INFO').toLowerCase();
    return `<div class="log-row"><span class="log-time">${esc(when)}</span><span class="log-level ${esc(level)}">${esc(log.level || 'INFO')}</span><span class="log-message">${esc(log.message || '')}</span></div>`;
  }

  function targetList(data, selected = state.pendingTargets) {
    const useAll = !Array.isArray(selected);
    const chosen = new Set(useAll ? [] : selected.map(String));
    const targets = activeTargets(data);
    return targets.length ? targets.map((target) => `<label class="target-row">
      <input type="checkbox" class="target" value="${esc(target.key)}" ${(useAll || chosen.has(target.key)) ? 'checked' : ''}>
      <span class="target-mark ${target.type}">${target.type === 'group' ? '◆' : '●'}</span>
      <span class="target-main"><b>${esc(target.name || target.phone || target.gid || 'بدون اسم')}</b><small>${typeLabel(target)}${target.type === 'group' ? ` · ${esc(target.gid || '')}` : ` · ${esc(target.international || target.e164 || '')}`}</small></span>
      <span class="target-state ${target.enabled === false ? 'off' : ''}">${target.enabled === false ? 'متوقف' : 'جاهز'}</span>
    </label>`).join('') : '<div class="empty">لا توجد أهداف. أضف شخصًا أو اربط مجموعة أولًا.</div>';
  }

  function pageSend(data) {
    const media = data.media || [];
    const tasks = data.automation?.tasks || [];
    const selectedTargets = state.pendingTargets;
    const groupsCount = (data.groups || []).length;
    return `<section class="page-title"><p class="eyebrow">إرسال</p><h1>أرسل بسهولة</h1><p>حدد الأهداف، اكتب الرسالة، ارفع الملفات، ثم نفّذ الآن أو احفظ موعدًا مستقلًا.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>من سيرسل إليه؟</h2><p>كل الاختيارات تخص الجلسة الحالية.</p></div><div class="panel-actions"><button class="btn small" id="selectAllTargets">الكل</button><button class="btn small" id="clearTargets">مسح</button></div></div>
          <div class="target-summary"><b>${selectedTargets === null ? 'الكل' : selectedTargets.length}</b><span>${selectedTargets === null ? 'كل الأهداف' : 'أهداف محددة'}</span><span>· ${groupsCount} مجموعة محفوظة</span></div>
          <div class="target-list">${targetList(data, selectedTargets)}</div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الرسالة والملفات</h2><p>ارفع مرة واحدة واختر ما يدخل في الإرسال.</p></div></div>
          <label>نص الرسالة<textarea id="sendText" rows="6" placeholder="اكتب الرسالة هنا..."></textarea></label>
          <div class="form-grid two"><label>قبل الملف<input id="sendPreText" placeholder="اختياري"></label><label>بعد الملف<input id="sendPostText" placeholder="اختياري"></label></div>
          <div class="upload-box"><input id="mediaFiles" type="file" multiple><label for="mediaFiles"><span>＋</span> اختر الملفات</label><small>صور، GIF، PDF، مستندات، صوت وفيديو حسب الأنواع المدعومة.</small><label class="upload-option"><input id="replaceDuplicates" type="checkbox"><span>استبدال الملف المكرر تلقائيًا</span></label></div>
          <div class="file-list">${media.length ? media.map(mediaChip).join('') : '<div class="empty">لا توجد ملفات مرفوعة.</div>'}</div>
          <details class="advanced-panel"><summary>خيارات الإرسال</summary><div class="form-grid three"><label>الترتيب<select id="sendOrder"><option value="target-first">كل هدف ثم ملفاته</option><option value="image-first">كل ملف ثم جميع الأهداف</option></select></label><label>منع التكرار<select id="repeatGuard"><option value="on">مفعّل</option><option value="off">متوقف</option></select></label><label>النص الافتراضي<input id="defaultPreText" value="${esc(data.settings?.preText || '')}" placeholder="اختياري"></label></div></details>
          <div class="action-bar"><button class="btn primary large" id="sendNowBtn">إرسال الآن</button></div>
        </article>
      </section>
      <section class="panel"><div class="panel-head"><div><h2>الإرسال التلقائي</h2><p>موعد مستقل داخل الجلسة، ويمكن أن يستخدم أهدافًا وملفات مختلفة.</p></div></div>
        <div class="form-grid four"><label>اسم الموعد<input id="scheduleName" placeholder="موعد جديد"></label><label>الوقت<input id="scheduleTime" type="time" value="17:30"></label><label>التكرار<select id="scheduleMode"><option value="once">مرة واحدة</option><option value="weekly">أسبوعيًا</option><option value="monthly">شهريًا</option><option value="yearly">سنويًا</option></select></label><label class="schedule-date">التاريخ<input id="scheduleDate" type="date"></label></div>
        <div class="form-grid four"><label class="schedule-day" hidden>اليوم<select id="scheduleDay"><option value="0">الأحد</option><option value="1">الاثنين</option><option value="2">الثلاثاء</option><option value="3">الأربعاء</option><option value="4">الخميس</option><option value="5">الجمعة</option><option value="6">السبت</option></select></label><label class="schedule-dom" hidden>يوم الشهر<input id="scheduleDayOfMonth" type="number" min="1" max="31" value="1"></label><label class="schedule-month" hidden>الشهر<select id="scheduleMonth">${Array.from({ length: 12 }, (_, index) => `<option value="${index + 1}">${index + 1}</option>`).join('')}</select></label><label>نوع الملفات<select id="scheduleMediaMode"><option value="selected">الملفات المحددة فقط</option><option value="cycle">دورة الصور تلقائيًا</option></select></label><label class="toggle-box"><input id="scheduleGroupsEnabled" type="checkbox" checked><span>تشغيل على المجموعات</span></label></div>
        <div class="form-grid two"><label>نص الموعد<input id="scheduleText" placeholder="إن كان فارغًا سيستخدم نص الإرسال"></label><label>نص بعد الملف<input id="schedulePostText" placeholder="اختياري"></label></div>
        <div class="action-bar"><button class="btn primary" id="scheduleBtn">حفظ الموعد</button></div>
        <div class="schedule-list">${tasks.length ? tasks.map(taskRow).join('') : '<div class="empty">لا توجد مواعيد محفوظة.</div>'}</div>
      </section>`;
  }

  function mediaChip(media) {
    const id = media.id || media.filename;
    return `<div class="file-chip"><label><input class="send-media" type="checkbox" value="${esc(id)}" checked><span>${esc(media.name || media.filename || 'ملف')}</span></label><button type="button" class="chip-delete" data-delete-media="${esc(id)}" aria-label="حذف الملف">×</button></div>`;
  }

  function taskRow(task) {
    const next = task.nextRun ? `التالي: ${new Date(task.nextRun).toLocaleString('ar-OM')}` : 'لا يوجد موعد قادم';
    return `<div class="schedule-row"><div><b>${esc(task.name || 'موعد')}</b><small>${esc(scheduleLabel(task))} · ${esc(next)}</small></div><div class="row-actions"><button class="btn small" data-run-task="${esc(task.id)}">تشغيل</button><button class="btn small" data-edit-task="${esc(task.id)}">تعديل</button><button class="btn small" data-toggle-task="${esc(task.id)}">${task.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-task="${esc(task.id)}">حذف</button></div></div>`;
  }

  function scheduleLabel(task) {
    return ({ once: 'مرة واحدة', weekly: 'أسبوعيًا', monthly: 'شهريًا', yearly: 'سنويًا' }[task.mode] || task.mode) + ` · ${task.time || ''}`;
  }

  function pagePeople(data) {
    const filter = state.peopleFilter.trim().toLocaleLowerCase('ar');
    const recipients = (data.recipients || []).filter((item) => `${item.name || ''} ${item.international || ''} ${item.e164 || ''}`.toLocaleLowerCase('ar').includes(filter));
    return `<section class="page-title"><p class="eyebrow">الأشخاص</p><h1>جهات الإرسال</h1><p>الأرقام منفصلة حسب الجلسة الحالية، وتدعم رموز الدول تلقائيًا.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>إضافة شخص</h2><p>اختر الدولة أو اكتب الرقم بصيغة دولية مباشرة.</p></div></div>
          <div class="form-grid three"><label>الاسم<input id="recipientName" placeholder="اسم الشخص"></label><label>الدولة<select id="recipientCountry">${countryOptions('OM')}</select></label><label>رقم الهاتف<input id="recipientPhone" inputmode="tel" placeholder="+968 9xxxxxxx"></label></div>
          <div id="phonePreview" class="inline-status">اكتب الرقم لمراجعته.</div>
          <div class="action-bar"><button class="btn primary" id="addRecipientBtn">إضافة الشخص</button></div>
          <details class="advanced-panel"><summary>إضافة قائمة أرقام</summary><p>سطر لكل رقم: الاسم|الرقم</p><textarea id="bulkRecipients" rows="7" placeholder="أحمد|+96890000000\nSara|+966500000000"></textarea><button class="btn" id="bulkAddBtn">إضافة القائمة</button></details>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الأشخاص المحفوظون</h2><p>${recipients.length} من ${(data.recipients || []).length} شخص.</p></div></div>
          <input id="peopleSearch" value="${esc(state.peopleFilter)}" placeholder="بحث بالاسم أو الرقم..."><div class="people-list">${recipients.length ? recipients.map(personRow).join('') : '<div class="empty">لا توجد نتائج.</div>'}</div>
        </article>
      </section>`;
  }

  function personRow(person) {
    return `<div class="person-row"><div class="person-main"><b>${esc(person.name || 'بدون اسم')}</b><small>${esc(person.international || person.e164 || person.phone || '')} · ${esc(person.country || '')}</small></div><span class="mini-state ${person.enabled === false ? 'off' : ''}">${person.enabled === false ? 'متوقف' : 'مفعّل'}</span><div class="row-actions"><button class="btn small" data-toggle-person="${esc(person.id)}">${person.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-person="${esc(person.id)}">حذف</button></div></div>`;
  }

  function pageGroups(data) {
    const filter = state.groupFilter.trim().toLocaleLowerCase('ar');
    const groups = (data.groups || []).filter((group) => `${group.name || ''} ${group.gid || ''}`.toLocaleLowerCase('ar').includes(filter));
    const current = state.selectedGroup && (data.groups || []).find((group) => group.gid === state.selectedGroup);
    return `<section class="page-title"><p class="eyebrow">المجموعات</p><h1>المجموعات هذه الجلسة</h1><p>اكتشاف وربط وتحليل وحفظ المجموعة في الجلسة الحالية، ثم استخدامها كهدف مستقل في الإرسال والتفاعل.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>ربط أو اكتشاف</h2><p>ضع GID أو رابط دعوة وسيُحلل تلقائيًا.</p></div></div>
          <label>GID أو رابط الدعوة<input id="groupValue" placeholder="120363...@g.us أو chat.whatsapp.com/..." value=""></label>
          <div class="action-bar"><button class="btn primary" id="connectGroupBtn">ربط وتحليل</button><button class="btn" id="discoverGroupsBtn">اكتشاف</button><button class="btn" id="refreshGroupsBtn">تحديث الكل</button></div>
          <div id="groupResult" class="result-box">سيتم عرض نتيجة التحليل هنا.</div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>المجموعات المحفوظة</h2><p>${groups.length} مجموعة.</p></div></div><input id="groupSearch" value="${esc(state.groupFilter)}" placeholder="ابحث باسم المجموعة أو GID..."><div class="group-list">${groups.length ? groups.map((group) => groupRow(group, current?.gid === group.gid)).join('') : '<div class="empty">لا توجد مجموعات محفوظة.</div>'}</div></article>
      </section>
      <section class="panel"><div class="panel-head"><div><h2>تفاصيل المجموعة</h2><p>اعرض البيانات الكاملة المتاحة، ثم استخدم المجموعة مباشرة في الإرسال.</p></div></div><div id="groupDetail">${groupDetails(current)}</div></section>`;
  }

  function groupRow(group, selected) {
    return `<article class="group-row ${selected ? 'selected' : ''}"><div class="group-main"><b>${esc(group.name || group.gid)}</b><small>${esc(group.gid || '')}</small></div><div class="group-meta"><span>${Number(group.participantsCount || group.participants?.length || 0)} عضو</span><span>${Number(group.admins?.length || 0)} مشرف</span><span class="mini-state ${group.enabled === false ? 'off' : ''}">${group.enabled === false ? 'متوقفة' : 'مفعّلة'}</span></div><div class="row-actions"><button class="btn small" data-show-group="${esc(group.gid)}">عرض</button><button class="btn small" data-send-group="${esc(group.id)}">إرسال</button><button class="btn small" data-copy-group="${esc(group.gid)}">نسخ GID</button><button class="btn small" data-toggle-group="${esc(group.id)}">${group.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-group="${esc(group.id)}">حذف</button></div></article>`;
  }

  function groupDetails(group) {
    if (!group) return '<div class="empty">اختر مجموعة من القائمة.</div>';
    const members = Array.isArray(group.participants) ? group.participants : [];
    const admins = Array.isArray(group.admins) ? group.admins : members.filter((item) => item.admin);
    return `<div class="info-grid six"><div><span>الاسم</span><b>${esc(group.name || '')}</b></div><div><span>GID</span><b class="mono">${esc(group.gid || '')}</b></div><div><span>الأعضاء</span><b>${Number(group.participantsCount || members.length || 0)}</b></div><div><span>المشرفون</span><b>${admins.length}</b></div><div><span>المالك</span><b class="mono">${esc(group.owner || 'غير متاح')}</b></div><div><span>رمز الدعوة</span><b>${esc(group.inviteCode || 'غير متاح')}</b></div></div><div class="detail-line"><strong>الوصف:</strong> ${esc(group.description || 'لا يوجد وصف')}</div><details class="member-details"><summary>الأعضاء (${members.length})</summary>${members.length ? `<div class="table-wrap"><table><thead><tr><th>#</th><th>الاسم</th><th>المعرف</th><th>الدور</th></tr></thead><tbody>${members.map((member, index) => `<tr><td>${index + 1}</td><td>${esc(member.name || 'بدون اسم')}</td><td class="mono">${esc(member.id || '')}</td><td>${member.admin ? 'مشرف' : 'عضو'}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لم يوفر WhatsApp قائمة الأعضاء.</div>'}</details>`;
  }

  function pageInteraction(data) {
    const interaction = data.interaction || {};
    const rules = interaction.rules || [];
    const recent = interaction.recent || [];
    const selected = new Set((data.settings?.interactionChatIds || []).map(String));
    const candidates = activeTargets(data);
    return `<section class="page-title"><p class="eyebrow">التفاعل</p><h1>التفاعل التلقائي</h1><p>قواعد حقيقية تعمل على الرسائل وReactions داخل الجلسة.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>التشغيل</h2><p>التحكم الأساسي واضح، والخيارات المتقدمة اختيارية.</p></div></div>
          <div class="toggle-list"><label class="toggle-row"><input id="interactionEnabled" type="checkbox" ${data.settings?.interactionEnabled !== false ? 'checked' : ''}><span><b>التفاعل</b><small>شغّل أو أوقف كل القواعد.</small></span></label><label class="toggle-row"><input id="groupAssistantEnabled" type="checkbox" ${data.settings?.groupAssistantEnabled !== false ? 'checked' : ''}><span><b>مساعد المجموعات</b><small>أوامر GID والتحليل داخل المجموعات.</small></span></label><label class="toggle-row"><input id="interactionIgnoreOwn" type="checkbox" ${data.settings?.interactionIgnoreOwn !== false ? 'checked' : ''}><span><b>تجاهل رسائل الحساب</b><small>يمنع حلقات الرد على النفس.</small></span></label></div>
          <div class="action-bar"><button class="btn primary" id="saveInteractionSettings">حفظ</button></div>
          <details class="advanced-panel"><summary>نطاق التشغيل ووقت الهدوء</summary><div class="form-grid two"><label>النطاق العام<select id="interactionScope"><option value="all" ${data.settings?.interactionScope === 'all' ? 'selected' : ''}>كل المحادثات</option><option value="groups" ${data.settings?.interactionScope === 'groups' ? 'selected' : ''}>المجموعات</option><option value="private" ${data.settings?.interactionScope === 'private' ? 'selected' : ''}>الخاص</option><option value="selected" ${data.settings?.interactionScope === 'selected' ? 'selected' : ''}>أهداف محددة</option></select></label><label>الحد الأقصى للأفعال/الدقيقة<input id="maxActionsPerMinute" type="number" min="1" max="1000" value="${Number(data.settings?.maxActionsPerMinute || 20)}"></label><label class="toggle-box"><input id="interactionQuietEnabled" type="checkbox" ${data.settings?.interactionQuietEnabled ? 'checked' : ''}><span>فترة هدوء</span></label><label>من<input id="interactionQuietStart" type="time" value="${esc(data.settings?.interactionQuietStart || '23:00')}"></label><label>إلى<input id="interactionQuietEnd" type="time" value="${esc(data.settings?.interactionQuietEnd || '07:00')}"></label></div><div class="target-picker"><b>الأهداف المحددة</b>${candidates.length ? candidates.map((target) => `<label><input type="checkbox" class="rule-target" value="${esc(chatIdForTarget(target))}" ${selected.has(chatIdForTarget(target)) ? 'checked' : ''}><span>${esc(target.name || target.gid || target.phone || '')}</span><small>${typeLabel(target)}</small></label>`).join('') : '<div class="empty">لا توجد أهداف في الجلسة.</div>'}</div></details>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>قاعدة جديدة</h2><p>اختَر الحدث ثم المطابقة ثم الإجراء.</p></div></div>
          <div class="form-grid two"><label>اسم القاعدة<input id="ruleName" placeholder="ترحيب"></label><label>الحدث<select id="ruleEvent"><option value="message">رسالة</option><option value="reaction">Reaction</option></select></label><label>المطابقة<select id="ruleMatch"><option value="contains">يحتوي</option><option value="exact">مطابق</option><option value="starts">يبدأ بـ</option><option value="ends">ينتهي بـ</option><option value="regex">Regex</option><option value="any">أي</option></select></label><label>النص أو الإيموجي<input id="ruleValue" placeholder="السلام عليكم"></label><label>النطاق<select id="ruleScope"><option value="all">الكل</option><option value="groups">المجموعات</option><option value="private">الخاص</option><option value="selected">أهداف محددة</option></select></label><label>الإجراء<select id="ruleAction"><option value="reply">رد نصي</option><option value="reaction">Reaction</option><option value="both">رد + Reaction</option></select></label></div>
          <div class="form-grid two"><label id="ruleReplyWrap">الرد النصي<input id="ruleReply" placeholder="وعليكم السلام {{sender}} 👋"></label><label id="ruleEmojiWrap">Reaction<input id="ruleEmoji" placeholder="👍"></label></div>
          <div class="preset-row"><span>قوالب جاهزة:</span><button class="btn small" data-rule-preset="welcome">ترحيب</button><button class="btn small" data-rule-preset="help">مساعدة</button><button class="btn small" data-rule-preset="reaction">Reaction</button></div>
          <details class="advanced-panel"><summary>تفاصيل القاعدة</summary><div class="form-grid three"><label>الأولوية<input id="rulePriority" type="number" value="10"></label><label>منع التكرار (ثانية)<input id="ruleCooldown" type="number" min="0" max="86400" value="45"></label><label class="toggle-box"><input id="ruleStop" type="checkbox" checked><span>أوقف القواعد التالية بعد التطابق</span></label></div><label class="test-field">رسالة الاختبار<textarea id="ruleTestMessage" rows="3" placeholder="اكتب هنا الرسالة التي تريد اختبارها"></textarea></label><label class="test-field">إيموجي الاختبار<input id="ruleTestEmoji" placeholder="👍"></label><div class="action-bar"><button class="btn" id="testRuleBtn">اختبار القاعدة</button></div></details>
          <div class="action-bar"><button class="btn primary" id="addRuleBtn">حفظ القاعدة</button></div>
        </article>
      </section>
      <section class="content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>القواعد الحالية</h2><p>${rules.length} قاعدة محفوظة لهذه الجلسة.</p></div></div><div class="rule-list">${rules.length ? rules.map(ruleRow).join('') : '<div class="empty">لا توجد قواعد بعد.</div>'}</div></article><article class="panel"><div class="panel-head"><div><h2>آخر التفاعلات</h2><p>نتيجة التنفيذ الفعلية.</p></div></div><div class="interaction-list">${recent.length ? recent.slice().reverse().map(interactionRow).join('') : '<div class="empty">لا يوجد تفاعل حتى الآن.</div>'}</div></article></section>`;
  }

  function ruleRow(rule) {
    const action = [rule.then?.reply || '', rule.then?.reaction || ''].filter(Boolean).join(' · ');
    return `<div class="rule-row"><div><b>${esc(rule.name || 'قاعدة')}</b><small>${esc(rule.when?.type || 'message')} · ${esc(rule.when?.match || '')} · ${esc(rule.when?.value || 'أي')}</small><span>${esc(action || 'بدون إجراء')}</span></div><div class="row-actions"><button class="btn small" data-toggle-rule="${esc(rule.id)}">${rule.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-rule="${esc(rule.id)}">حذف</button></div></div>`;
  }

  function interactionRow(item) {
    const when = item.at ? new Date(item.at) : null;
    return `<div class="interaction-row"><div><b>${esc(item.ruleName || item.ruleId || 'قاعدة')}</b><span>${esc(item.status || '')}</span></div><small>${esc(item.chatId || '')} · ${when && !Number.isNaN(when.getTime()) ? esc(when.toLocaleString('ar-OM')) : ''}</small></div>`;
  }

  function pageSession(data) {
    const runtime = data.whatsapp || {};
    const status = runtime.ready ? 'متصل' : (runtime.status === 'qr' ? 'بانتظار QR' : runtime.status || 'غير متصل');
    return `<section class="page-title"><p class="eyebrow">الجلسة</p><h1>اتصال وإدارة الحساب</h1><p>كل جلسة مستقلة بحسابها وأهدافها وسجلها.</p></section><section class="content-grid two-col">
      <article class="panel"><div class="panel-head"><div><h2>اتصال WhatsApp</h2><p>اربط الحساب أو أوقفه في أي وقت.</p></div></div><div class="status-panel"><span>الحالة</span><b>${esc(status)}</b>${runtime.info?.wid?.user ? `<small>+${esc(runtime.info.wid.user)}</small>` : ''}</div>${runtime.qr ? `<div class="qr-box"><p>امسح الرمز من WhatsApp.</p><img src="${esc(runtime.qr)}" class="session-qr" alt="QR"></div>` : ''}<div class="action-bar"><button class="btn primary" id="connectSessionBtn">ربط / تشغيل</button><button class="btn" id="stopSessionBtn">إيقاف</button><button class="btn danger" id="unlinkSessionBtn">فصل الحساب</button></div></article>
      <article class="panel"><div class="panel-head"><div><h2>إعداد الجلسة</h2><p>الاسم يتغير فقط في الجلسة الحالية.</p></div></div><label>اسم الجلسة<input id="sessionName" value="${esc(data.session?.name || '')}" placeholder="الجلسة الرئيسية"></label><div class="action-bar"><button class="btn primary" id="saveSessionBtn">حفظ الاسم</button><button class="btn" id="newSessionBtn">جلسة جديدة</button><button class="btn danger" id="deleteSessionBtn">حذف الجلسة</button></div><div class="info-grid"><div><span>الحساب</span><b>${esc(runtime.info?.wid?.user || 'غير معروف')}</b></div><div><span>الاسم</span><b>${esc(runtime.info?.pushname || 'غير معروف')}</b></div><div><span>المجموعات</span><b>${(data.groups || []).length}</b></div><div><span>الأشخاص</span><b>${(data.recipients || []).length}</b></div></div></article>
    </section><section class="panel"><div class="panel-head"><div><h2>سجل الجلسة</h2><p>هذا السجل يخص هذه الجلسة وحدها.</p></div><button class="btn small" id="sessionRefreshLog">تحديث</button></div><div class="log-list tall">${(data.logs || []).map(logRow).join('') || '<div class="empty">السجل فارغ.</div>'}</div></section>`;
  }

  const bgNames = { aurora: 'الشفق', nebula: 'السديم', meteor: 'النيزك', matrix: 'المصفوفة', 'cyber-grid': 'الشبكة', plasma: 'البلازما', starfield: 'النجوم', vortex: 'الدوامة', galaxy: 'المجرة', ocean: 'الموجة' };
  function pageAppearance(data) {
    const background = data.background || {};
    const cfg = background.settings || {};
    const a = data.settings?.appearance || {};
    const visiblePresets = [['mint','نعناعي'],['ocean','بحري'],['violet','بنفسجي'],['sunset','غروب']];
    return `<section class="page-title"><p class="eyebrow">المظهر</p><h1>المظهر والخلفيات</h1><p>غيّر اللون والخلفية بسهولة، والتخصيص الكامل موجود داخل الخيارات المتقدمة.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>لون الواجهة</h2><p>اختر لونًا جاهزًا أو لونك الخاص.</p></div></div>
          <div class="theme-preview"><span class="theme-dot" id="themeDot1"></span><div><b>chat BOT</b><small>لون واحد واضح للواجهة</small></div></div>
          <div class="preset-row">${visiblePresets.map(([id,label]) => `<button class="btn small" data-ui-preset="${id}">${label}</button>`).join('')}</div>
          <label>اللون الأساسي<input id="uiAccent" type="color" value="${esc(a.accent || '#5ed6c1')}"></label>
          <details class="advanced-panel"><summary>تفاصيل الواجهة</summary><div class="form-grid two"><label>لون مساعد<input id="uiAccent2" type="color" value="${esc(a.accent2 || '#8b7cf6')}"></label>${rangeControl('uiPanelOpacity','وضوح البطاقات',a.panelOpacity ?? .94,.78,.97,.01)}${rangeControl('uiPanelBlur','نعومة البطاقات',a.panelBlur ?? 0,0,12,1)}${rangeControl('uiRadius','استدارة العناصر',a.radius ?? 13,10,24,1)}${rangeControl('uiGlow','وهج اللون',a.glow ?? .28,0,.8,.05)}</div></details>
          <div class="action-bar"><button class="btn primary" id="saveUiThemeBtn">حفظ اللون</button><button class="btn" id="resetUiThemeBtn">إعادة الافتراضي</button></div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الخلفية</h2><p>خلفيات جميلة وخفيفة على الجهاز.</p></div></div>
          <div class="bg-picker">${Object.entries(bgNames).map(([id,name]) => `<button class="bg-choice ${background.mode === id ? 'selected' : ''}" data-bg-mode="${id}"><span class="bg-swatch bg-${id}"></span><b>${name}</b></button>`).join('')}</div>
          <div class="upload-box"><input id="customBackground" type="file" accept="image/png,image/jpeg,image/webp"><label for="customBackground"><span>＋</span> اختيار صورة</label><small>الصورة تحفظ لهذه الجلسة فقط.</small></div>
          ${background.imageUrl ? `<div class="custom-current"><img src="${esc(background.imageUrl)}" alt="الخلفية الحالية"><span>الخلفية الحالية</span></div><div class="action-bar"><button class="btn danger" id="removeCustomBackgroundBtn">إزالة الصورة</button></div>` : ''}
          <details class="advanced-panel"><summary>تخصيص الخلفية بالتفصيل</summary><div class="range-grid">${rangeControl('bgSpeed','السرعة',cfg.speed, .1,2,.05)}${rangeControl('bgDensity','الكثافة',cfg.density,.2,1.6,.05)}${rangeControl('bgGlow','التوهج',cfg.glow,0,1,.05)}${rangeControl('bgIntensity','القوة',cfg.intensity,.2,1.5,.05)}${rangeControl('bgMouse','تأثير المؤشر',cfg.mouseStrength,0,1.5,.05)}${rangeControl('bgBrightness','السطوع',cfg.brightness,.6,1.4,.05)}${rangeControl('bgContrast','التباين',cfg.contrast,.7,1.4,.05)}${rangeControl('bgSaturation','التشبع',cfg.saturation,.5,1.6,.05)}${rangeControl('bgHue','تغيير اللون',cfg.hueRotate,0,360,1)}${rangeControl('bgBlur','التمويه',cfg.blur,0,6,.25)}${rangeControl('bgOpacity','الشفافية',background.opacity ?? .22,.08,.60,.01)}</div><div class="toggle-list"><label class="toggle-row"><input id="bgInteractive" type="checkbox" ${cfg.interactive !== false ? 'checked' : ''}><span><b>التفاعل</b><small>استجابة بسيطة للمؤشر والنقر.</small></span></label><label class="toggle-row"><input id="bgTrail" type="checkbox" ${cfg.trail !== false ? 'checked' : ''}><span><b>أثر الحركة</b><small>يعطي نعومة إضافية.</small></span></label></div></details>
          <div class="action-bar"><button class="btn primary" id="saveBackgroundBtn">حفظ الخلفية</button><button class="btn" id="resetBackgroundBtn">إعادة الافتراضي</button></div>
        </article>
      </section>`;
  }

  function pageSettings(data) {
    const active = state.settingsView === 'operation' ? 'operation' : 'appearance';
    return `<section class="settings-shell">
      <div class="settings-switch" role="tablist" aria-label="أقسام الإعدادات">
        <button class="settings-tab ${active === 'appearance' ? 'active' : ''}" data-settings-view="appearance" role="tab" aria-selected="${active === 'appearance'}">المظهر والخلفيات</button>
        <button class="settings-tab ${active === 'operation' ? 'active' : ''}" data-settings-view="operation" role="tab" aria-selected="${active === 'operation'}">التشغيل المتقدم</button>
      </div>
      <div class="settings-content">${active === 'appearance' ? pageAppearance(data) : pageOperation(data)}</div>
    </section>`;
  }

  function rangeControl(id, label, value, min, max, step) {
    const safe = Number.isFinite(Number(value)) ? Number(value) : Number(min);
    return `<label class="range-item"><span>${esc(label)} <output id="${id}Out">${safe.toFixed(step < 1 ? 2 : 0)}</output></span><input id="${id}" type="range" min="${min}" max="${max}" step="${step}" value="${safe}"></label>`;
  }

  function pageOperation(data) {
    const settings = data.settings || {};
    return `<section class="page-title"><p class="eyebrow">التشغيل</p><h1>إعدادات التشغيل</h1><p>الإعدادات الأساسية ظاهرة، والتفاصيل الإضافية داخل أقسام واضحة.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>الأساسيات</h2><p>هذه أهم الخيارات للاستخدام اليومي.</p></div></div>
          <div class="form-grid two"><label>المنطقة الزمنية<input id="opTimezone" value="${esc(settings.timezone || 'Asia/Muscat')}" placeholder="Asia/Muscat"></label><label>ترتيب الإرسال<select id="opSendOrder"><option value="target-first" ${settings.sendOrder === 'target-first' ? 'selected' : ''}>هدف ثم ملفاته</option><option value="image-first" ${settings.sendOrder === 'image-first' ? 'selected' : ''}>ملف ثم الأهداف</option></select></label></div>
          <div class="toggle-list"><label class="toggle-row"><input id="opAutoStart" type="checkbox" ${settings.autoStartSession !== false ? 'checked' : ''}><span><b>تشغيل الجلسة تلقائيًا</b><small>استعادة الحساب المحفوظ عند بدء البوت.</small></span></label><label class="toggle-row"><input id="opAutomation" type="checkbox" ${settings.automationEnabled !== false ? 'checked' : ''}><span><b>التشغيل التلقائي</b><small>تشغيل المواعيد المحفوظة لهذه الجلسة.</small></span></label></div>
          <div class="action-bar"><button class="btn primary" id="saveOperationMain">حفظ</button></div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الخصوصية والتشغيل</h2><p>المعلومات التي تحتاجها فقط.</p></div></div><div class="privacy-box"><p>المشروع يعمل محليًا وتبقى بيانات الجلسات والوسائط والسجل على الجهاز.</p><p>التشغيل المعتاد عبر <code>run.py</code> والمنفذ 7005.</p></div><div class="action-bar"><button class="btn" data-go="session">إدارة الجلسة</button><button class="btn" data-go="dashboard">الرئيسية</button></div></article>
      </section>
      <section class="content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>الموثوقية</h2><p>خيارات متقدمة، لا تحتاج تغييرها غالبًا.</p></div></div><details class="advanced-panel" open><summary>فتح إعدادات الموثوقية</summary><div class="form-grid two"><label>التأخير بين الإرسال (مللي ثانية)<input id="opDelay" type="number" min="0" max="60000" value="${Number(settings.sendDelayMs || 700)}"></label><label>مهلة الإرسال (مللي ثانية)<input id="opTimeout" type="number" min="5000" max="180000" value="${Number(settings.sendTimeoutMs || 30000)}"></label><label>عدد المحاولات<input id="opRetryAttempts" type="number" min="1" max="4" value="${Number(settings.retryAttempts || 2)}"></label><label>التأخير بين المحاولات (مللي ثانية)<input id="opRetryDelay" type="number" min="250" max="120000" value="${Number(settings.retryDelayMs || 1600)}"></label><label>أقصى حجم للملف MB<input id="opMaxSize" type="number" min="1" max="50" value="${Number(settings.maxImageSizeMB || 20)}"></label></div><div class="action-bar"><button class="btn primary" id="saveOperationReliability">حفظ</button></div></details></article>
        <article class="panel"><div class="panel-head"><div><h2>فترة هدوء التفاعل</h2><p>أوقف الردود التلقائية خلال وقت تحدده.</p></div></div><details class="advanced-panel" open><summary>إعداد وقت الهدوء</summary><div class="form-grid three"><label class="toggle-box"><input id="opQuietEnabled" type="checkbox" ${settings.interactionQuietEnabled ? 'checked' : ''}><span>تفعيل</span></label><label>من<input id="opQuietStart" type="time" value="${esc(settings.interactionQuietStart || '23:00')}"></label><label>إلى<input id="opQuietEnd" type="time" value="${esc(settings.interactionQuietEnd || '07:00')}"></label></div><div class="action-bar"><button class="btn primary" id="saveOperationQuiet">حفظ</button></div></details></article></section>`;
  }

  function render() {
    const data = state.data || { session: {}, sessions: [], whatsapp: {} };
    let content = pageDashboard(data);
    if (state.page === 'send') content = pageSend(data);
    else if (state.page === 'people') content = pagePeople(data);
    else if (state.page === 'groups') content = pageGroups(data);
    else if (state.page === 'interaction') content = pageInteraction(data);
    else if (state.page === 'session') content = pageSession(data);
    else if (state.page === 'settings') content = pageSettings(data);
    else if (state.page === 'appearance') { state.page = 'settings'; state.settingsView = 'appearance'; content = pageSettings(data); }
    else if (state.page === 'operation') { state.page = 'settings'; state.settingsView = 'operation'; content = pageSettings(data); }
    applyInterfaceTheme(data);
    $('#app').innerHTML = shell(content);
    setupBackground();
    bindCommon();
    bindPage();
  }

  function bindCommon() {
    $$('.navbtn').forEach((button) => { button.onclick = () => go(button.dataset.page); });
    $$('[data-go]').forEach((button) => { button.onclick = () => go(button.dataset.go); });
    $('#refreshBtn')?.addEventListener('click', () => load(true).catch((e) => notify(e.message, 'error')));
    $('#dashboardRefresh')?.addEventListener('click', () => load(true).catch((e) => notify(e.message, 'error')));
    $('#sessionRefreshLog')?.addEventListener('click', () => load(true).catch((e) => notify(e.message, 'error')));
    $('#sessionSelect')?.addEventListener('change', async (event) => {
      try {
        await api('/api/sessions/switch', { method: 'POST', body: JSON.stringify({ sessionId: event.target.value }) });
        state.pendingTargets = null;
        state.selectedGroup = null;
        await load(true);
      } catch (error) { notify(error.message, 'error'); }
    });
  }

  async function bindPage() {
    if (state.page === 'send') bindSend();
    if (state.page === 'people') bindPeople();
    if (state.page === 'groups') bindGroups();
    if (state.page === 'interaction') bindInteraction();
    if (state.page === 'session') bindSession();
    if (state.page === 'appearance') bindAppearance();
    if (state.page === 'settings') {
      bindSettings();
      if (state.settingsView === 'operation') bindOperation(); else bindAppearance();
    }
  }

  function currentTargetKeys() {
    return $$('.target:checked').map((input) => input.value);
  }

  function selectedMediaIds() {
    return $$('.send-media:checked').map((input) => input.value);
  }

  async function bindSend() {
    await loadCountries().then(() => {
      const country = $('#recipientCountry');
      if (country) country.innerHTML = countryOptions(country.value || 'OM');
    }).catch(() => {});
    $$('.target').forEach((checkbox) => checkbox.addEventListener('change', () => { state.pendingTargets = currentTargetKeys(); }));
    $('#selectAllTargets')?.addEventListener('click', () => { $$('.target').forEach((input) => { input.checked = true; }); state.pendingTargets = currentTargetKeys(); });
    $('#clearTargets')?.addEventListener('click', () => { $$('.target').forEach((input) => { input.checked = false; }); state.pendingTargets = []; });
    $('#mediaFiles')?.addEventListener('change', uploadMediaFiles);
    $$('[data-delete-media]').forEach((button) => button.addEventListener('click', async (event) => {
      event.preventDefault();
      try { await api(`/api/media/${encodeURIComponent(button.dataset.deleteMedia)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (error) { notify(error.message, 'error'); }
    }));
    $('#sendNowBtn')?.addEventListener('click', sendNow);
    bindSchedule();
  }

  async function uploadMediaFiles(event) {
    const files = [...(event.target.files || [])];
    if (!files.length) return;
    const form = new FormData();
    files.forEach((file) => form.append('files', file));
    form.append('sessionId', sid());
    form.append('replaceDuplicates', $('#replaceDuplicates')?.checked ? 'true' : 'false');
    try {
      const result = await api('/api/media', { method: 'POST', body: form });
      notify(result.message || `تم رفع ${result.saved?.length || 0} ملف`, 'success');
      await load(true);
    } catch (error) { notify(error.message, 'error'); }
    finally { event.target.value = ''; }
  }

  async function sendNow() {
    const targets = currentTargetKeys();
    const mediaIds = selectedMediaIds();
    const text = $('#sendText')?.value || '';
    const preText = $('#sendPreText')?.value || $('#defaultPreText')?.value || text;
    const postText = $('#sendPostText')?.value || '';
    if (!targets.length) return notify('حدد شخصًا أو مجموعة واحدة على الأقل.', 'error');
    if (!text.trim() && !preText.trim() && !postText.trim() && !mediaIds.length) return notify('اكتب رسالة أو اختر ملفًا.', 'error');
    try {
      const result = await api('/api/send', { method: 'POST', body: JSON.stringify({
        sessionId: sid(), targetKeys: targets, text, preText, postText, mediaIds,
        sendOrder: $('#sendOrder')?.value || 'target-first', repeatGuard: $('#repeatGuard')?.value !== 'off'
      }) });
      notify(result.message || 'تم الإرسال.', result.failed?.length ? 'info' : 'success');
      state.pendingTargets = null;
      await load(true);
    } catch (error) { notify(error.message, 'error'); }
  }

  function bindSchedule() {
    $('#scheduleMode')?.addEventListener('change', (event) => {
      const value = event.target.value;
      $('.schedule-date')?.toggleAttribute('hidden', value !== 'once');
      $('.schedule-day')?.toggleAttribute('hidden', value !== 'weekly');
      $('.schedule-dom')?.toggleAttribute('hidden', !['monthly', 'yearly'].includes(value));
      $('.schedule-month')?.toggleAttribute('hidden', value !== 'yearly');
    });
    $$('[data-delete-task]').forEach((button) => button.addEventListener('click', async () => {
      try { await api(`/api/automation/task/${encodeURIComponent(button.dataset.deleteTask)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); }
    }));
    $$('[data-toggle-task]').forEach((button) => button.addEventListener('click', async () => {
      try { await api(`/api/automation/task/${encodeURIComponent(button.dataset.toggleTask)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); }
    }));
    $$('[data-run-task]').forEach((button) => button.addEventListener('click', async () => {
      try { const result = await api(`/api/automation/task/${encodeURIComponent(button.dataset.runTask)}/run`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم التشغيل.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    }));
    $$('[data-edit-task]').forEach((button) => button.addEventListener('click', () => loadTaskIntoEditor(button.dataset.editTask)));
    $('#scheduleBtn')?.addEventListener('click', createOrUpdateTask);
  }

  async function loadTaskIntoEditor(taskId) {
    const task = (state.data?.automation?.tasks || []).find((item) => item.id === taskId);
    if (!task) return notify('الموعد غير موجود.', 'error');
    $('#scheduleName').value = task.name || '';
    $('#scheduleTime').value = task.time || '17:30';
    $('#scheduleMode').value = task.mode || 'weekly';
    $('#scheduleDate').value = task.date || '';
    $('#scheduleDay').value = String(task.day ?? 5);
    $('#scheduleDayOfMonth').value = String(task.dayOfMonth ?? 1);
    $('#scheduleMonth').value = String(task.month || 1);
    $('#scheduleText').value = task.preText || '';
    $('#schedulePostText').value = task.postText || '';
    $('#scheduleMediaMode').value = task.mediaMode || 'selected';
    $('#scheduleGroupsEnabled').checked = task.scheduledGroupsEnabled !== false;
    state.editingTaskId = task.id;
    state.pendingTargets = Array.isArray(task.targetKeys) ? [...task.targetKeys] : [];
    $$('.target').forEach((input) => { input.checked = state.pendingTargets.includes(input.value); });
    $$('.send-media').forEach((input) => { input.checked = (task.mediaIds || []).includes(input.value); });
    notify('تم تحميل الموعد للتعديل. عدّل ثم اضغط حفظ.', 'info');
  }

  async function createOrUpdateTask() {
    const targets = currentTargetKeys();
    const mediaIds = selectedMediaIds();
    const mode = $('#scheduleMode').value;
    const text = $('#scheduleText').value.trim() || $('#sendText')?.value.trim() || '';
    if (!targets.length) return notify('حدد أهداف الموعد.', 'error');
    if (!text && !mediaIds.length && $('#scheduleMediaMode').value !== 'cycle') return notify('أضف نصًا أو ملفًا للموعد.', 'error');
    const payload = {
      sessionId: sid(), name: $('#scheduleName').value.trim() || 'موعد جديد', mode, time: $('#scheduleTime').value,
      date: $('#scheduleDate').value, day: Number($('#scheduleDay').value), dayOfMonth: Number($('#scheduleDayOfMonth').value), month: Number($('#scheduleMonth').value),
      targetKeys: targets, mediaIds, mediaMode: $('#scheduleMediaMode').value, preText: text, postText: $('#schedulePostText').value.trim(), sendOrder: $('#sendOrder')?.value || 'target-first',
      scheduledGroupsEnabled: $('#scheduleGroupsEnabled').checked
    };
    try {
      const url = state.editingTaskId ? `/api/automation/task/${encodeURIComponent(state.editingTaskId)}` : '/api/automation/task';
      const method = state.editingTaskId ? 'PUT' : 'POST';
      const result = await api(url, { method, body: JSON.stringify(payload) });
      notify(result.message || 'تم حفظ الموعد.', 'success');
      state.editingTaskId = null;
      await load(true);
    } catch (error) { notify(error.message, 'error'); }
  }

  function bindPeopleSearch() {}
  function bindGroupSearch() {}

  function bindPeople() {
    loadCountries().then(() => {
      const country = $('#recipientCountry');
      if (country) country.innerHTML = countryOptions(country.value || 'OM');
    }).catch(() => {});
    $('#recipientPhone')?.addEventListener('blur', async () => {
      const value = $('#recipientPhone').value.trim();
      if (!value) return;
      try { const result = await api('/api/phone/validate', { method: 'POST', body: JSON.stringify({ phone: value, country: $('#recipientCountry').value }) }); $('#phonePreview').textContent = `سيُحفظ كـ ${result.phone?.international || result.phone?.e164 || 'رقم صالح'}`; } catch (error) { $('#phonePreview').textContent = error.message; }
    });
    $('#addRecipientBtn')?.addEventListener('click', async () => {
      try { const result = await api('/api/recipient', { method: 'POST', body: JSON.stringify({ sessionId: sid(), name: $('#recipientName').value.trim(), phone: $('#recipientPhone').value, country: $('#recipientCountry').value }) }); notify(`تمت إضافة ${result.recipient?.name || 'الشخص'}`, 'success'); await load(true); } catch (error) { notify(error.message, 'error'); }
    });
    $('#bulkAddBtn')?.addEventListener('click', async () => {
      try { const result = await api('/api/recipients/bulk', { method: 'POST', body: JSON.stringify({ sessionId: sid(), lines: $('#bulkRecipients').value, country: $('#recipientCountry').value }) }); notify(`أضيف ${result.added?.length || 0} رقم${result.failed?.length ? `، وتعذر ${result.failed.length}` : ''}`, result.failed?.length ? 'info' : 'success'); await load(true); } catch (error) { notify(error.message, 'error'); }
    });
    $('#peopleSearch')?.addEventListener('input', (event) => { state.peopleFilter = event.target.value; clearTimeout(bindPeopleSearch.timer); bindPeopleSearch.timer = setTimeout(() => { const list = $('.people-list'); if (list) { const filter = state.peopleFilter.trim().toLocaleLowerCase('ar'); const rows = (state.data?.recipients || []).filter((item) => `${item.name || ''} ${item.international || ''} ${item.e164 || ''}`.toLocaleLowerCase('ar').includes(filter)); list.innerHTML = rows.length ? rows.map(personRow).join('') : '<div class="empty">لا توجد نتائج.</div>'; bindPeopleRows(); } }, 120); });
    bindPeopleRows();
  }

  function bindPeopleRows() {
    $$('[data-toggle-person]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/recipient/${encodeURIComponent(button.dataset.togglePerson)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-person]').forEach((button) => button.addEventListener('click', async () => { if (!confirm('حذف الشخص من هذه الجلسة؟')) return; try { await api(`/api/recipient/${encodeURIComponent(button.dataset.deletePerson)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
  }

  function bindGroups() {
    $('#connectGroupBtn')?.addEventListener('click', async () => {
      const value = $('#groupValue').value.trim();
      if (!value) return notify('أدخل GID أو رابط دعوة.', 'error');
      $('#groupResult').textContent = 'جاري الربط والتحليل…';
      try { const result = await api('/api/groups/connect', { method: 'POST', body: JSON.stringify({ sessionId: sid(), value }) }); state.selectedGroup = result.group?.gid || null; notify(result.message || 'تم الربط.', 'success'); await load(true); } catch (error) { $('#groupResult').textContent = error.message; notify(error.message, 'error'); }
    });
    $('#discoverGroupsBtn')?.addEventListener('click', async () => {
      try { const result = await api('/api/groups/discover', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم الاكتشاف.', 'success'); await load(true); } catch (error) { notify(error.message, 'error'); }
    });
    $('#refreshGroupsBtn')?.addEventListener('click', async () => {
      try { const result = await api('/api/groups/refresh-all', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم التحديث.', result.failed?.length ? 'info' : 'success'); await load(true); } catch (error) { notify(error.message, 'error'); }
    });
    $('#groupSearch')?.addEventListener('input', (event) => { state.groupFilter = event.target.value; clearTimeout(bindGroupSearch.timer); bindGroupSearch.timer = setTimeout(() => { const list = $('.group-list'); if (list) { const filter = state.groupFilter.trim().toLocaleLowerCase('ar'); const groups = (state.data?.groups || []).filter((group) => `${group.name || ''} ${group.gid || ''}`.toLocaleLowerCase('ar').includes(filter)); const current = state.selectedGroup && (state.data?.groups || []).find((group) => group.gid === state.selectedGroup); list.innerHTML = groups.length ? groups.map((group) => groupRow(group, current?.gid === group.gid)).join('') : '<div class="empty">لا توجد نتائج.</div>'; bindGroupRows(); } }, 120); });
    bindGroupRows();
  }

  function bindGroupRows() {
    $$('[data-show-group]').forEach((button) => button.addEventListener('click', () => { state.selectedGroup = button.dataset.showGroup; render(); }));
    $$('[data-send-group]').forEach((button) => button.addEventListener('click', () => { state.pendingTargets = [`g:${button.dataset.sendGroup}`]; go('send'); }));
    $$('[data-copy-group]').forEach((button) => button.addEventListener('click', async () => { try { await navigator.clipboard.writeText(button.dataset.copyGroup); notify('تم نسخ GID.', 'success'); } catch { notify('تعذر النسخ من المتصفح.', 'error'); } }));
    $$('[data-toggle-group]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/groups/${encodeURIComponent(button.dataset.toggleGroup)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-group]').forEach((button) => button.addEventListener('click', async () => { if (!confirm('حذف المجموعة من هذه الجلسة؟')) return; try { await api(`/api/groups/${encodeURIComponent(button.dataset.deleteGroup)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); state.selectedGroup = null; await load(true); } catch (e) { notify(e.message, 'error'); } }));
  }

  function applyRulePreset(name) {
    const presets = {
      welcome: { name:'ترحيب جديد', event:'message', match:'contains', value:'السلام عليكم', action:'reply', reply:'وعليكم السلام {{sender}} 👋', emoji:'' },
      help: { name:'مساعدة', event:'message', match:'contains', value:'مساعدة', action:'reply', reply:'اكتب كلمة أو أمرًا وسأرد حسب القواعد التي أنشأتها.', emoji:'' },
      reaction: { name:'تفاعل بالإعجاب', event:'reaction', match:'any', value:'', action:'reaction', reply:'', emoji:'👍' },
    };
    const p = presets[name]; if (!p) return;
    if ($('#ruleName')) $('#ruleName').value=p.name; if ($('#ruleEvent')) $('#ruleEvent').value=p.event; if ($('#ruleMatch')) $('#ruleMatch').value=p.match; if ($('#ruleValue')) $('#ruleValue').value=p.value; if ($('#ruleAction')) $('#ruleAction').value=p.action; if ($('#ruleReply')) $('#ruleReply').value=p.reply; if ($('#ruleEmoji')) $('#ruleEmoji').value=p.emoji;
    $('#ruleAction')?.dispatchEvent(new Event('change')); $('#ruleEvent')?.dispatchEvent(new Event('change'));
    notify('تم تحميل القالب ويمكنك تعديله قبل الحفظ.', 'info');
  }

  function bindInteraction() {
    $$('[data-rule-preset]').forEach((button) => button.addEventListener('click', () => applyRulePreset(button.dataset.rulePreset)));
    $('#saveInteractionSettings')?.addEventListener('click', saveInteractionSettings);
    const refreshActionFields = () => {
      const action = $('#ruleAction')?.value || 'reply';
      $('#ruleReplyWrap')?.toggleAttribute('hidden', action === 'reaction');
      $('#ruleEmojiWrap')?.toggleAttribute('hidden', action === 'reply');
    };
    $('#ruleAction')?.addEventListener('change', refreshActionFields);
    refreshActionFields();
    $('#addRuleBtn')?.addEventListener('click', async () => {
      try {
        const action = $('#ruleAction').value;
        const scope = $('#ruleScope').value;
        const body = {
          sessionId: sid(), name: $('#ruleName').value.trim() || 'قاعدة',
          when: { type: $('#ruleEvent').value, match: $('#ruleMatch').value, value: $('#ruleValue').value },
          then: { reply: action === 'reaction' ? '' : $('#ruleReply').value, reaction: action === 'reply' ? '' : $('#ruleEmoji').value, stopAfter: $('#ruleStop').checked },
          scope, chatIds: scope === 'selected' ? $$('.rule-target:checked').map((input) => input.value) : [],
          priority: Number($('#rulePriority').value) || 0, cooldownSec: Number($('#ruleCooldown').value) || 0
        };
        await api('/api/interaction/rules', { method: 'POST', body: JSON.stringify(body) });
        notify('تم حفظ القاعدة.', 'success');
        await load(true);
      } catch (error) { notify(error.message, 'error'); }
    });
    $('#testRuleBtn')?.addEventListener('click', async () => {
      try {
        const type = $('#ruleEvent').value;
        const rule = { when: { type, match: $('#ruleMatch').value, value: $('#ruleValue').value }, then: { reply: $('#ruleReply').value, reaction: $('#ruleEmoji').value } };
        const result = await api('/api/interaction/test', { method: 'POST', body: JSON.stringify({ sessionId: sid(), message: $('#ruleTestMessage').value, emoji: $('#ruleTestEmoji').value, sender: 'مستخدم الاختبار', rule }) });
        notify(result.matched ? (result.rendered ? `مطابقة ناجحة: ${result.rendered}` : 'مطابقة ناجحة') : 'لا توجد مطابقة.', result.matched ? 'success' : 'info');
      } catch (error) { notify(error.message, 'error'); }
    });
    $$('[data-toggle-rule]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/interaction/rules/${encodeURIComponent(button.dataset.toggleRule)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-rule]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/interaction/rules/${encodeURIComponent(button.dataset.deleteRule)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
  }

  async function saveInteractionSettings() {
    try {
      await api('/api/settings', { method: 'POST', body: JSON.stringify({
        sessionId: sid(), interactionEnabled: $('#interactionEnabled').checked, groupAssistantEnabled: $('#groupAssistantEnabled').checked, interactionIgnoreOwn: $('#interactionIgnoreOwn').checked,
        interactionScope: $('#interactionScope').value, interactionChatIds: $$('.rule-target:checked').map((input) => input.value), interactionQuietEnabled: $('#interactionQuietEnabled').checked,
        interactionQuietStart: $('#interactionQuietStart').value, interactionQuietEnd: $('#interactionQuietEnd').value, maxActionsPerMinute: Number($('#maxActionsPerMinute').value || 20)
      }) });
      notify('تم حفظ إعدادات التفاعل.', 'success');
      await load(true);
    } catch (error) { notify(error.message, 'error'); }
  }

  function bindSession() {
    $('#connectSessionBtn')?.addEventListener('click', async () => { try { const result = await api('/api/session/connect', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم بدء الاتصال.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#stopSessionBtn')?.addEventListener('click', async () => { try { await api('/api/session/stop', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify('تم إيقاف الجلسة.', 'info'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#unlinkSessionBtn')?.addEventListener('click', async () => { if (!confirm('فصل الحساب من هذه الجلسة؟')) return; try { await api('/api/session/unlink', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify('تم فصل الحساب.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#saveSessionBtn')?.addEventListener('click', async () => { try { await api(`/api/sessions/${encodeURIComponent(sid())}`, { method: 'PUT', body: JSON.stringify({ name: $('#sessionName').value.trim() }) }); notify('تم حفظ الاسم.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#newSessionBtn')?.addEventListener('click', async () => { try { await api('/api/sessions', { method: 'POST', body: JSON.stringify({ name: 'جلسة جديدة' }) }); notify('تم إنشاء الجلسة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#deleteSessionBtn')?.addEventListener('click', async () => { if (!confirm('حذف هذه الجلسة نهائيًا؟')) return; try { await api(`/api/sessions/${encodeURIComponent(sid())}`, { method: 'DELETE' }); state.page = 'dashboard'; state.pendingTargets = null; notify('تم حذف الجلسة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
  }

  function applyUiPreset(name) {
    const presets = {
      mint: { accent: '#5ed6c1', accent2: '#8b7cf6', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .28 },
      ocean: { accent: '#56c9ff', accent2: '#57e5cf', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .25 },
      violet: { accent: '#9b86ff', accent2: '#e18aff', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .27 },
      sunset: { accent: '#ff9a6a', accent2: '#ff6fb1', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .24 },
    };
    const p = presets[name]; if (!p) return;
    if ($('#uiAccent')) $('#uiAccent').value = p.accent;
    if ($('#uiAccent2')) $('#uiAccent2').value = p.accent2;
    if ($('#uiPanelOpacity')) $('#uiPanelOpacity').value = p.panelOpacity;
    if ($('#uiPanelBlur')) $('#uiPanelBlur').value = p.panelBlur;
    if ($('#uiRadius')) $('#uiRadius').value = p.radius;
    if ($('#uiGlow')) $('#uiGlow').value = p.glow;
    ['uiPanelOpacity','uiPanelBlur','uiRadius','uiGlow'].forEach(updateRangeOutput);
    applyInterfaceLive();
    notify('تم تطبيق المظهر الجاهز. اضغط حفظ الواجهة لتثبيته.', 'info');
  }

  function bindAppearance() {
    const uiControls = ['uiPanelOpacity', 'uiPanelBlur', 'uiRadius', 'uiGlow'];
    uiControls.forEach((id) => $(`#${id}`)?.addEventListener('input', () => { updateRangeOutput(id); applyInterfaceLive(); }));
    $('#uiAccent')?.addEventListener('input', applyInterfaceLive);
    $('#uiAccent2')?.addEventListener('input', applyInterfaceLive);
    const syncThemeDots = () => { const a = readInterfaceForm(); if ($('#themeDot1')) $('#themeDot1').style.background = a.accent; if ($('#themeDot2')) $('#themeDot2').style.background = a.accent2; };
    syncThemeDots();
    $$('[data-ui-preset]').forEach((button) => button.addEventListener('click', () => applyUiPreset(button.dataset.uiPreset)));
    ['uiAccent','uiAccent2','uiPanelOpacity','uiPanelBlur','uiRadius','uiGlow'].forEach((id) => $(`#${id}`)?.addEventListener('input', syncThemeDots));
    $('#saveUiThemeBtn')?.addEventListener('click', async () => {
      try { await api('/api/settings', { method: 'POST', body: JSON.stringify({ sessionId: sid(), appearance: readInterfaceForm() }) }); notify('تم حفظ هوية الواجهة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#resetUiThemeBtn')?.addEventListener('click', async () => {
      const defaults = { accent: '#5ed6c1', accent2: '#8b7cf6', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .28 };
      try { await api('/api/settings', { method: 'POST', body: JSON.stringify({ sessionId: sid(), appearance: defaults }) }); notify('تمت استعادة هوية الواجهة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    const controls = ['bgSpeed', 'bgDensity', 'bgGlow', 'bgIntensity', 'bgMouse', 'bgBrightness', 'bgContrast', 'bgSaturation', 'bgHue', 'bgBlur', 'bgOpacity'];
    controls.forEach((id) => $(`#${id}`)?.addEventListener('input', () => { updateRangeOutput(id); applyBackgroundLive(); }));
    $$('[data-bg-mode]').forEach((button) => button.addEventListener('click', () => { $$('[data-bg-mode]').forEach((item) => item.classList.remove('selected')); button.classList.add('selected'); applyBackgroundLive(); }));
    $('#bgInteractive')?.addEventListener('change', applyBackgroundLive);
    $('#bgTrail')?.addEventListener('change', applyBackgroundLive);
    $('#saveBackgroundBtn')?.addEventListener('click', async () => {
      try { const payload = readBackgroundForm(); await api('/api/settings/background', { method: 'POST', body: JSON.stringify({ sessionId: sid(), ...payload }) }); notify('تم حفظ وتطبيق المظهر.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#resetBackgroundBtn')?.addEventListener('click', async () => {
      try { await api('/api/settings/background', { method: 'POST', body: JSON.stringify({ sessionId: sid(), mode: 'aurora', settings: { speed: 1, density: 1, glow: .6, intensity: 1, mouseStrength: 1, brightness: 1, contrast: 1, saturation: 1, hueRotate: 0, blur: 0, interactive: true, trail: true }, opacity: .22, removeImage: true }) }); notify('تمت استعادة المظهر الافتراضي.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#removeCustomBackgroundBtn')?.addEventListener('click', async () => {
      if (!confirm('إزالة صورة الخلفية المخصصة؟')) return;
      try { await api('/api/settings/background', { method: 'POST', body: JSON.stringify({ sessionId: sid(), mode: state.data?.background?.mode || 'aurora', settings: state.data?.background?.settings || {}, opacity: state.data?.background?.opacity ?? .22, removeImage: true }) }); notify('تمت إزالة الصورة المخصصة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#customBackground')?.addEventListener('change', async (event) => {
      const file = event.target.files?.[0]; if (!file) return;
      const form = new FormData(); form.append('file', file); form.append('sessionId', sid());
      try { const result = await api('/api/background', { method: 'POST', body: form }); notify(result.message || 'تم تطبيق الخلفية.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
      finally { event.target.value = ''; }
    });
  }

  function updateRangeOutput(id) {
    const input = $(`#${id}`), output = $(`#${id}Out`); if (!input || !output) return;
    const step = Number(input.step || 1);
    output.value = Number(input.value).toFixed(step < 1 ? 2 : 0);
  }

  function readBackgroundForm() {
    return {
      mode: $('.bg-choice.selected')?.dataset.bgMode || state.data?.background?.mode || 'aurora',
      opacity: Number($('#bgOpacity').value),
      settings: {
        speed: Number($('#bgSpeed').value), density: Number($('#bgDensity').value), glow: Number($('#bgGlow').value), intensity: Number($('#bgIntensity').value), mouseStrength: Number($('#bgMouse').value),
        brightness: Number($('#bgBrightness').value), contrast: Number($('#bgContrast').value), saturation: Number($('#bgSaturation').value), hueRotate: Number($('#bgHue').value), blur: Number($('#bgBlur').value),
        interactive: $('#bgInteractive').checked, trail: $('#bgTrail').checked
      }
    };
  }

  function applyBackgroundLive() {
    if (state.bgLivePending) return;
    state.bgLivePending = requestAnimationFrame(() => {
      state.bgLivePending = 0;
      const data = readBackgroundForm();
      if (state.bgEngine) state.bgEngine.set(data);
    });
  }

  function bindSettings() {
    $$('[data-settings-view]').forEach((button) => button.addEventListener('click', () => {
      state.settingsView = button.dataset.settingsView === 'operation' ? 'operation' : 'appearance';
      render();
    }));
  }

  function bindOperation() {
    const save = async (payload) => {
      try { await api('/api/settings', { method: 'POST', body: JSON.stringify({ sessionId: sid(), ...payload }) }); notify('تم حفظ الإعدادات.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    };
    $('#saveOperationMain')?.addEventListener('click', () => save({ timezone: $('#opTimezone').value.trim(), sendOrder: $('#opSendOrder').value, autoStartSession: $('#opAutoStart').checked, automationEnabled: $('#opAutomation').checked }));
    $('#saveOperationReliability')?.addEventListener('click', () => save({ sendTimeoutMs: Number($('#opTimeout').value || 30000), retryAttempts: Number($('#opRetryAttempts').value || 2), retryDelayMs: Number($('#opRetryDelay').value || 1600), maxImageSizeMB: Number($('#opMaxSize').value || 20) }));
    $('#saveOperationQuiet')?.addEventListener('click', () => save({ interactionQuietEnabled: $('#opQuietEnabled').checked, interactionQuietStart: $('#opQuietStart').value, interactionQuietEnd: $('#opQuietEnd').value }));
  }

  function go(page) {
    const next = ['appearance', 'operation'].includes(page) ? 'settings' : page;
    if (page === 'appearance') state.settingsView = 'appearance';
    if (page === 'operation') state.settingsView = 'operation';
    state.page = next || 'dashboard';
    location.hash = state.page;
    render();
    const active = $$(`.navbtn[data-page=\"${String(state.page).replace(/[^a-z-]/g, '')}\"]`)[0];
    try { active?.scrollIntoView({ behavior: 'auto', inline: 'center', block: 'nearest' }); } catch {}
    if (state.page === 'people' || state.page === 'send') loadCountries().catch(() => {});
  }

  class BackgroundEngine {
    constructor(canvas) {
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d');
      this.mode = 'aurora';
      this.cfg = { speed: 1, density: 1, glow: .6, intensity: 1, mouseStrength: 1, brightness: 1, contrast: 1, saturation: 1, hueRotate: 0, blur: 0, interactive: true, trail: true };
      this.pointer = { x: .5, y: .5, down: false };
      this.reducedMotion = matchMedia?.('(prefers-reduced-motion: reduce)')?.matches || false;
      if (this.reducedMotion) this.cfg.interactive = false;
      this.t = 0; this.last = 0; this.lastDrawAt = 0; this.frameInterval = 100;
      this.resize = this.resize.bind(this); this.frame = this.frame.bind(this);
      addEventListener('resize', this.resize);
      this.pointerMovePending = false;
      addEventListener('pointermove', (event) => {
        if (this.pointerMovePending || !this.cfg.interactive) return;
        this.pointerMovePending = true;
        requestAnimationFrame(() => { this.pointerMovePending = false; this.pointer.x = event.clientX / innerWidth; this.pointer.y = event.clientY / innerHeight; });
      }, { passive: true });
      addEventListener('pointerdown', () => { this.pointer.down = true; });
      addEventListener('pointerup', () => { this.pointer.down = false; });
      this.resize(); requestAnimationFrame(this.frame);
    }
    resize() { const scale = 1; const w = innerWidth, h = innerHeight; if (w === this.w && h === this.h) return; this.w = w; this.h = h; this.canvas.width = Math.max(1, Math.floor(this.w * scale)); this.canvas.height = Math.max(1, Math.floor(this.h * scale)); this.ctx.setTransform(scale, 0, 0, scale, 0, 0); }
    set(data) {
      if (!data) return;
      this.mode = data.mode || this.mode;
      const scene = $('#bgScene'); if (scene) scene.dataset.mode = this.mode;
      this.cfg = { ...this.cfg, ...(data.settings || {}) };
      const filter = `brightness(${this.cfg.brightness ?? 1}) contrast(${this.cfg.contrast ?? 1}) saturate(${this.cfg.saturation ?? 1}) hue-rotate(${this.cfg.hueRotate ?? 0}deg) blur(${this.cfg.blur ?? 0}px)`;
      this.canvas.style.filter = filter;
      const image = $('#bgImageLayer');
      if (image) {
        image.style.opacity = String(data.opacity ?? .22);
        image.style.filter = filter;
        if (Object.prototype.hasOwnProperty.call(data, 'imageUrl')) image.style.backgroundImage = data.imageUrl ? `url("${String(data.imageUrl).replace(/"/g, '%22')}")` : '';
      }
    }
    frame(ms) { if (document.hidden) { requestAnimationFrame(this.frame); return; } if (ms - this.lastDrawAt >= this.frameInterval) { const dt = Math.min(50, ms - (this.last || ms)); this.last = ms; this.lastDrawAt = ms; this.t += dt * .001 * Number(this.cfg.speed || 1); this.draw(); } requestAnimationFrame(this.frame); }
    clear() { this.ctx.fillStyle = `rgba(4,8,18,${this.cfg.trail ? .13 : .25})`; this.ctx.fillRect(0, 0, this.w, this.h); }
    draw() {
      const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, px = .5 + (this.pointer.x - .5) * Number(c.mouseStrength ?? 1), py = .5 + (this.pointer.y - .5) * Number(c.mouseStrength ?? 1);
      x.save(); this.clear(); x.globalCompositeOperation = 'source-over';
      if (this.mode === 'aurora') this.aurora(px, py); else if (this.mode === 'nebula') this.nebula(px, py); else if (this.mode === 'meteor') this.meteor(px, py); else if (this.mode === 'matrix') this.matrix(px, py); else if (this.mode === 'cyber-grid') this.grid(px, py); else if (this.mode === 'plasma') this.plasma(px, py); else if (this.mode === 'starfield') this.stars(px, py); else if (this.mode === 'vortex') this.vortex(px, py); else if (this.mode === 'galaxy') this.galaxy(px, py); else this.ocean(px, py);
      if (c.interactive) { x.beginPath(); x.arc(px * w, py * h, 18 + Math.sin(t * 4) * 5, 0, Math.PI * 2); x.strokeStyle = `rgba(170,235,255,${.08 * c.intensity})`; x.lineWidth = 1.2 + c.glow * 1.4; x.stroke(); if (this.pointer.down) { x.beginPath(); x.arc(px * w, py * h, 42 + Math.sin(t * 9) * 8, 0, Math.PI * 2); x.strokeStyle = `rgba(210,160,255,${.16 * c.intensity})`; x.stroke(); } } x.restore();
    }
    aurora(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, shift = (px - .5) * 80; for (let k = 0; k < Math.max(2, Math.round(2 + c.density * 2)); k++) { x.beginPath(); for (let i = 0; i <= w; i += 12) x.lineTo(i, h * (.22 + k * .16) + (py - .5) * 45 + Math.sin(i * .008 + t * (.7 + k * .2) + shift * .003) * 35 + Math.sin(i * .002 - t * .35) * 24); x.strokeStyle = `hsla(${165 + k * 45},90%,65%,${.055 * c.intensity})`; x.lineWidth = 55; x.shadowBlur = 24 * c.glow; x.stroke(); } }
    nebula(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(34 * c.density); for (let i = 0; i < n; i++) { const a = (i * 12.9898) % 6.283, r = ((i * 37.13) % 1) * Math.min(w, h) * .48, q = t * (.2 + (i % 7) / 35), cx = w * (.5 + (px - .5) * .08), cy = h * (.5 + (py - .5) * .08), vx = cx + Math.cos(a + q) * r, vy = cy + Math.sin(a + q * .8) * r * .65, z = 2 + ((i * 17) % 8); x.fillStyle = `hsla(${205 + (i % 4) * 32},90%,70%,${.12 * c.intensity})`; x.beginPath(); x.arc(vx, vy, z, 0, Math.PI * 2); x.fill(); } }
    meteor(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(18 * c.density), bias = (px - .5) * 80; for (let i = 0; i < n; i++) { const speed = 70 + (i % 9) * 18, vx = (i * 97 + t * speed * 1.8 + bias) % (w + 300) - 150, vy = (i * 43 + t * speed * .7 + (py - .5) * 50) % (h + 120) - 60; x.beginPath(); x.moveTo(vx, vy); x.lineTo(vx - speed * .28, vy - speed * .11); x.strokeStyle = `hsla(${185 + (i % 5) * 25},95%,70%,${.18 * c.intensity})`; x.lineWidth = 1 + (i % 3); x.stroke(); } }
    matrix(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, cols = Math.floor(58 * c.density), step = Math.max(13, w / Math.max(cols, 1)); x.font = '15px monospace'; for (let i = 0; i < cols; i++) { const y = (i * 79 + t * (55 + (i % 7) * 6) + (py - .5) * 100) % (h + 220) - 220; x.fillStyle = `rgba(110,231,249,${.2 * c.intensity})`; x.fillText(String.fromCharCode(0x30a0 + (i * 13) % 90), i * step, y); } }
    grid(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, step = Math.max(38, 112 - c.density * 45), oy = (t * 35 + (py - .5) * 50) % step, ox = (t * 18 + (px - .5) * 50) % step; x.strokeStyle = `rgba(110,231,249,${.09 * c.intensity})`; for (let y = -step + oy; y < h + step; y += step) { x.beginPath(); x.moveTo(0, y); x.lineTo(w, y); x.stroke(); } for (let xx = -step + ox; xx < w + step; xx += step) { x.beginPath(); x.moveTo(xx, 0); x.lineTo(xx, h); x.stroke(); } }
    plasma(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg; for (let k = 0; k < Math.max(3, Math.round(4 + c.density * 4)); k++) { x.beginPath(); for (let i = 0; i <= w; i += 10) x.lineTo(i, h * (.15 + k * .12) + (py - .5) * 35 + Math.sin(i * .012 + t * (1 + k * .07) + (px - .5)) * 26 + Math.sin(i * .004 - t * .6) * 22); x.strokeStyle = `hsla(${190 + k * 24},85%,62%,${.07 * c.intensity})`; x.lineWidth = 18; x.stroke(); } }
    stars(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(56 * c.density); for (let i = 0; i < n; i++) { const z = ((i * 31 + t * 14) % 100) / 100, r = .3 + z * 2.5, vx = (i * 97.31 + (px - .5) * 40) % w, vy = (i * 47.21 + (py - .5) * 40) % h; x.fillStyle = `rgba(220,240,255,${.15 + z * .6})`; x.beginPath(); x.arc(vx, vy, r, 0, Math.PI * 2); x.fill(); } }
    vortex(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(52 * c.density), cx = w * (.5 + (px - .5) * .18), cy = h * (.5 + (py - .5) * .12); for (let i = 0; i < n; i++) { const p = i / n, a = p * Math.PI * 10 + t * (.3 + p), r = p * Math.min(w, h) * .42, vx = cx + Math.cos(a) * r, vy = cy + Math.sin(a) * r * .62; x.fillStyle = `hsla(${190 + p * 130},95%,68%,${.11 * c.intensity})`; x.beginPath(); x.arc(vx, vy, 1 + p * 2.5, 0, Math.PI * 2); x.fill(); } }
    galaxy(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(72 * c.density), cx = w * (.5 + (px - .5) * .14), cy = h * (.5 + (py - .5) * .1); for (let i = 0; i < n; i++) { const p = i / n, a = i * .55 + t * (.45 + p), r = p * Math.min(w, h) * .46 + Math.sin(i * 2.7) * 4, vx = cx + Math.cos(a) * r, vy = cy + Math.sin(a) * r * .42; x.fillStyle = `hsla(${190 + (i % 6) * 22},90%,72%,${.08 + c.intensity * .08})`; x.beginPath(); x.arc(vx, vy, .5 + p * 2.2, 0, Math.PI * 2); x.fill(); } }
    ocean(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg; for (let k = 0; k < 3; k++) { x.beginPath(); for (let i = 0; i <= w; i += 10) x.lineTo(i, h * (.52 + k * .07) + (py - .5) * 40 + Math.sin(i * .009 + t * (.65 + k * .05) + px * 2) * 18 + Math.sin(i * .003 - t * .45) * 10); x.strokeStyle = `hsla(${180 + k * 8},85%,65%,${.055 * c.intensity})`; x.lineWidth = 10 + c.glow * 10; x.stroke(); } }
  }

  function applyInterfaceTheme(data = state.data) {
    const a = data?.settings?.appearance || {};
    const root = document.documentElement;
    root.style.setProperty('--accent', a.accent || '#5ed6c1');
    root.style.setProperty('--accent-2', a.accent2 || '#8b7cf6');
    root.style.setProperty('--panel-opacity', String(a.panelOpacity ?? .88));
    root.style.setProperty('--panel-blur', `${Number(a.panelBlur ?? 14)}px`);
    root.style.setProperty('--radius', `${Number(a.radius ?? 18)}px`);
    root.style.setProperty('--ui-glow', String(Number(a.glow ?? .55)));
  }

  function readInterfaceForm() {
    return {
      accent: $('#uiAccent')?.value || '#5ed6c1',
      accent2: $('#uiAccent2')?.value || '#8b7cf6',
      panelOpacity: Number($('#uiPanelOpacity')?.value || .88),
      panelBlur: Number($('#uiPanelBlur')?.value || 14),
      radius: Number($('#uiRadius')?.value || 18),
      glow: Number($('#uiGlow')?.value || .55),
    };
  }

  function applyInterfaceLive() { applyInterfaceTheme({ settings: { appearance: readInterfaceForm() } }); }

  function setupBackground() {
    const canvas = $('#bgCanvas'); if (!canvas) return;
    if (!state.bgEngine) state.bgEngine = new BackgroundEngine(canvas);
    if (state.data?.background) state.bgEngine.set(state.data.background);
  }

  async function boot() {
    try {
      await loadCountries().catch(() => null);
      await load();
      addEventListener('hashchange', () => { state.page = location.hash.slice(1) || 'dashboard'; render(); });
    } catch (error) {
      document.body.innerHTML = `<div class="fatal"><h1>تعذر تشغيل الواجهة</h1><p>${esc(error.message)}</p><button class="btn primary" onclick="location.reload()">إعادة المحاولة</button></div>`;
    }
  }

  boot();
})();
