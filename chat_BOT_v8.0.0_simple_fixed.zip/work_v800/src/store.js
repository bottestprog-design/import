"use strict";
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ROOT = path.resolve(__dirname, '..');
const DATA_DIR = path.join(ROOT, 'data');
const SESSIONS_DIR = path.join(DATA_DIR, 'sessions');
const APP_VERSION = '8.0.0';
fs.mkdirSync(SESSIONS_DIR, { recursive: true });
const DEFAULT_SETTINGS = {
  timezone: 'Asia/Muscat', scheduleEnabled: false, scheduleMode: 'weekly', scheduleDay: 5, scheduleMonthDay: 1, scheduleTime: '17:30', scheduleDate: '', scheduleTargetKeys: [], scheduleMediaId: '', schedulePreText: '', schedulePostText: '', scheduledGroupsEnabled: true,
  preText: 'chat BOT', postText: '', sendOrder: 'target-first', sendTimeoutMs: 30000, sendDelayMs: 700, retryAttempts: 2, retryDelayMs: 1600, maxImageSizeMB: 20,
  autoStartSession: true, automationEnabled: true, interactionEnabled: true, groupAssistantEnabled: true, interactionIgnoreOwn: true, interactionScope: 'all', interactionChatIds: [], maxActionsPerMinute: 20,
  interactionCooldownCapSec: 86400, interactionQuietEnabled: false, interactionQuietStart: '23:00', interactionQuietEnd: '07:00',
  backgroundMode: 'aurora', backgroundImage: '', backgroundOpacity: .22,
  appearance: { accent: '#5ed6c1', accent2: '#8b7cf6', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .28 },
  backgroundSettings: { speed: 1, density: 1, glow: .6, intensity: 1, mouseStrength: 1, brightness: 1, contrast: 1, saturation: 1, hueRotate: 0, blur: 0, interactive: true, trail: true }
};
function clone(x) { return JSON.parse(JSON.stringify(x)); }
function safeSessionId(id) { return String(id || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 80) || 'main'; }
function getPaths(id) { const sid = safeSessionId(id), dir = path.join(SESSIONS_DIR, sid); return { id: sid, dir, json: path.join(dir, 'session.json'), auth: path.join(dir, 'auth'), media: path.join(dir, 'media'), images: path.join(dir, 'media'), backgrounds: path.join(dir, 'backgrounds'), logFile: path.join(dir, 'activity.log') }; }
function defaults(id, name) { return { schemaVersion: 6, id: safeSessionId(id), name: String(name || 'جلسة جديدة').slice(0, 80), setupComplete: false, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), settings: clone(DEFAULT_SETTINGS), recipients: [], groups: [], cycle: { round: 1, roundStartedAt: new Date().toISOString(), imageOrder: [], currentIndex: 0, delivery: {}, manualGuard: {} }, interaction: { enabled: true, rules: seedRules(), recent: [] }, stats: { sentMessages: 0, sentImages: 0, sentFiles: 0, confirmedAcks: 0, createdSends: 0, uncertainSends: 0, failedSends: 0, successfulRuns: 0, failedRuns: 0, interactionActions: 0, interactionErrors: 0 }, automation: { enabled: true, tasks: [], recent: [] }, logs: [], lastRun: null, lastBackup: null, scheduleState: { lastRunKey: '' } }; }
function seedRules() { return [
  { id: crypto.randomUUID(), name: 'ترحيب', enabled: true, priority: 30, when: { type: 'message', match: 'contains', value: 'السلام عليكم' }, then: { reply: 'وعليكم السلام {{sender}} 👋' }, scope: 'all', chatIds: [], cooldownSec: 45 },
  { id: crypto.randomUUID(), name: 'تحية', enabled: true, priority: 25, when: { type: 'message', match: 'contains', value: 'مرحبا' }, then: { reply: 'أهلًا {{sender}} ✨' }, scope: 'all', chatIds: [], cooldownSec: 45 },
  { id: crypto.randomUUID(), name: 'مساعدة البوت', enabled: true, priority: 20, when: { type: 'message', match: 'exact', value: '!help' }, then: { reply: 'الأوامر: !help — !gid — !group id\nيمكنك أيضًا استخدام قواعد التفاعل من لوحة التحكم.' }, scope: 'all', chatIds: [], cooldownSec: 30 }
]; }
function ensureDir(id) { const p = getPaths(id); for (const k of ['dir', 'media', 'backgrounds', 'auth']) fs.mkdirSync(p[k], { recursive: true }); return p; }
function saveSession(s) { const id = safeSessionId(s.id), p = ensureDir(id); const out = { ...s, schemaVersion: 6, id, updatedAt: new Date().toISOString() }; const tmp = p.json + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(out, null, 2), 'utf8'); fs.renameSync(tmp, p.json); return out; }
function loadSession(id) { const sid = safeSessionId(id), p = ensureDir(sid); if (!fs.existsSync(p.json)) return saveSession(defaults(sid, sid === 'main' ? 'الجلسة الرئيسية' : 'جلسة جديدة')); try { const s = JSON.parse(fs.readFileSync(p.json, 'utf8')); return normalizeSession(s, sid); } catch { const bad = p.json + '.broken-' + Date.now(); try { fs.renameSync(p.json, bad); } catch {} return saveSession(defaults(sid, 'جلسة مستعادة')); } }
function normalizeAutomationTask(t) {
  const x = t || {}, mode = ['weekly', 'monthly', 'yearly', 'once'].includes(String(x.mode || '')) ? String(x.mode) : 'weekly';
  const time = /^\d{2}:\d{2}$/.test(String(x.time || '')) ? String(x.time) : '17:30';
  return {
    id: String(x.id || crypto.randomUUID()), name: String(x.name || 'موعد جديد').trim().slice(0, 100) || 'موعد جديد', enabled: x.enabled !== false,
    mode, time, date: String(x.date || ''), day: toInt(x.day, 5, 0, 6), dayOfMonth: toInt(x.dayOfMonth, 1, 1, 31), month: x.month === '' || x.month == null ? '' : toInt(x.month, 1, 1, 12), year: x.year === '' || x.year == null ? '' : toInt(x.year, new Date().getFullYear(), 2020, 2100),
    targetKeys: Array.isArray(x.targetKeys) ? [...new Set(x.targetKeys.map(String).filter(Boolean))].slice(0, 2000) : [], mediaIds: Array.isArray(x.mediaIds) ? [...new Set(x.mediaIds.map(String).filter(Boolean))].slice(0, 2000) : [],
    mediaMode: x.mediaMode === 'cycle' ? 'cycle' : 'selected', preText: String(x.preText || ''), postText: String(x.postText || ''), sendOrder: ['target-first', 'image-first'].includes(x.sendOrder) ? x.sendOrder : 'target-first', scheduledGroupsEnabled: x.scheduledGroupsEnabled !== false,
    lastRunKey: String(x.lastRunKey || ''), createdAt: x.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString(), lastResult: x.lastResult || null,
  };
}
function normalizeSession(s, sid) {
  const d = defaults(sid, s.name); s.id = sid; s.name = String(s.name || d.name).slice(0, 80);
  s.settings = { ...clone(DEFAULT_SETTINGS), ...(s.settings || {}), appearance: { ...clone(DEFAULT_SETTINGS.appearance), ...(s.settings?.appearance || {}) }, backgroundSettings: { ...clone(DEFAULT_SETTINGS.backgroundSettings), ...(s.settings?.backgroundSettings || {}) } };
  s.settings.scheduleDay = toInt(s.settings.scheduleDay, 5, 0, 6); s.settings.scheduleMonthDay = toInt(s.settings.scheduleMonthDay, 1, 1, 31); s.settings.scheduleTargetKeys = Array.isArray(s.settings.scheduleTargetKeys) ? [...new Set(s.settings.scheduleTargetKeys.map(String).filter(Boolean))] : []; s.settings.scheduleMediaId = String(s.settings.scheduleMediaId || ''); s.settings.schedulePreText = String(s.settings.schedulePreText || ''); s.settings.schedulePostText = String(s.settings.schedulePostText || '');
  const appearance = s.settings.appearance || {};
  appearance.accent = /^#[0-9a-f]{6}$/i.test(String(appearance.accent || '')) ? String(appearance.accent) : DEFAULT_SETTINGS.appearance.accent;
  appearance.accent2 = /^#[0-9a-f]{6}$/i.test(String(appearance.accent2 || '')) ? String(appearance.accent2) : DEFAULT_SETTINGS.appearance.accent2;
  appearance.panelOpacity = Math.max(.72, Math.min(.97, Number(appearance.panelOpacity) || DEFAULT_SETTINGS.appearance.panelOpacity));
  appearance.panelBlur = Math.max(4, Math.min(28, Number(appearance.panelBlur) || DEFAULT_SETTINGS.appearance.panelBlur));
  appearance.radius = Math.max(12, Math.min(28, Number(appearance.radius) || DEFAULT_SETTINGS.appearance.radius));
  appearance.glow = Math.max(0, Math.min(1, Number(appearance.glow) || DEFAULT_SETTINGS.appearance.glow));
  s.settings.appearance = appearance;
  s.settings.sendTimeoutMs = toInt(s.settings.sendTimeoutMs, 30000, 5000, 180000); s.settings.sendDelayMs = toInt(s.settings.sendDelayMs, 700, 0, 60000); s.settings.retryAttempts = toInt(s.settings.retryAttempts, 2, 1, 4); s.settings.retryDelayMs = toInt(s.settings.retryDelayMs, 1600, 250, 120000); s.settings.maxImageSizeMB = toInt(s.settings.maxImageSizeMB, 20, 1, 50); s.settings.maxActionsPerMinute = toInt(s.settings.maxActionsPerMinute, 20, 1, 1000);
  s.settings.autoStartSession = s.settings.autoStartSession !== false; s.settings.automationEnabled = s.settings.automationEnabled !== false; s.settings.interactionEnabled = s.settings.interactionEnabled !== false; s.settings.groupAssistantEnabled = s.settings.groupAssistantEnabled !== false; s.settings.interactionIgnoreOwn = s.settings.interactionIgnoreOwn !== false; s.settings.scheduledGroupsEnabled = s.settings.scheduledGroupsEnabled !== false;
  s.recipients = Array.isArray(s.recipients) ? s.recipients.map(r => ({ ...r, id: String(r.id || crypto.randomUUID()), enabled: r.enabled !== false })) : [];
  s.groups = Array.isArray(s.groups) ? s.groups.map(normalizeGroup).filter(g => /^\d+(?:-\d+)*@g\.us$/.test(g.gid)) : [];
  s.cycle = { ...d.cycle, ...(s.cycle || {}), delivery: s.cycle?.delivery || {}, manualGuard: s.cycle?.manualGuard || {} };
  s.interaction = { ...d.interaction, ...(s.interaction || {}), rules: Array.isArray(s.interaction?.rules) ? s.interaction.rules : seedRules(), recent: Array.isArray(s.interaction?.recent) ? s.interaction.recent : [] };
  s.stats = { ...d.stats, ...(s.stats || {}) };
  s.automation = { ...d.automation, ...(s.automation || {}) }; s.automation.tasks = Array.isArray(s.automation.tasks) ? s.automation.tasks.map(normalizeAutomationTask) : []; s.automation.recent = Array.isArray(s.automation.recent) ? s.automation.recent.slice(-100) : [];
  s.logs = Array.isArray(s.logs) ? s.logs.slice(-400) : []; s.scheduleState = { ...d.scheduleState, ...(s.scheduleState || {}) }; s.schemaVersion = 6; return s;
}
function listSessionIds() { const ids = fs.readdirSync(SESSIONS_DIR, { withFileTypes: true }).filter(x => x.isDirectory()).map(x => x.name).filter(Boolean); if (!ids.length) { saveSession(defaults('main', 'الجلسة الرئيسية')); ids.push('main'); } return ids.sort(); }
function activeSessionId() { const f = path.join(DATA_DIR, 'active-session'); try { return safeSessionId(fs.readFileSync(f, 'utf8').trim()) || listSessionIds()[0]; } catch { return listSessionIds()[0]; } }
function setActiveSession(id) { const sid = safeSessionId(id); if (!listSessionIds().includes(sid)) throw new Error('الجلسة غير موجودة.'); fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(path.join(DATA_DIR, 'active-session'), sid, 'utf8'); return loadSession(sid); }
function createSession(name) { const id = 's-' + crypto.randomUUID(); saveSession(defaults(id, name)); setActiveSession(id); return loadSession(id); }
function renameSession(id, name) { const s = loadSession(id); s.name = String(name || '').trim().slice(0, 80) || s.name; return saveSession(s); }
function deleteSession(id) { const sid = safeSessionId(id); if (listSessionIds().length <= 1) throw new Error('لا يمكن حذف آخر جلسة.'); const was = activeSessionId() === sid; fs.rmSync(getPaths(sid).dir, { recursive: true, force: true }); if (was) setActiveSession(listSessionIds()[0]); return { activeSessionId: activeSessionId() }; }
function toInt(v, d, min = -Infinity, max = Infinity) { const n = Number(v); return Number.isFinite(n) ? Math.max(min, Math.min(max, Math.trunc(n))) : d; }
function normalizeGroup(g) { return { id: g.id || crypto.randomUUID(), name: String(g.name || 'مجموعة').slice(0, 120), gid: String(g.gid || '').trim().toLowerCase(), inviteCode: String(g.inviteCode || ''), description: String(g.description || '').slice(0, 1000), owner: String(g.owner || '').slice(0, 150), participantsCount: Number.isFinite(Number(g.participantsCount)) ? Number(g.participantsCount) : null, participants: Array.isArray(g.participants) ? g.participants.slice(0, 2000) : [], admins: Array.isArray(g.admins) ? g.admins.slice(0, 500) : [], discoveredAt: g.discoveredAt || new Date().toISOString(), updatedAt: new Date().toISOString(), enabled: g.enabled !== false }; }
module.exports = { ROOT, DATA_DIR, SESSIONS_DIR, APP_VERSION, DEFAULT_SETTINGS, clone, safeSessionId, getPaths, saveSession, loadSession, listSessionIds, activeSessionId, setActiveSession, createSession, renameSession, deleteSession, toInt, normalizeGroup, normalizeAutomationTask, ensureDir };
