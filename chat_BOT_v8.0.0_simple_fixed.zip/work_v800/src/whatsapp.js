"use strict";
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
function patchUtilsForWhatsApp(){
  const out = { ok:true, changed:false, notes:[] };
  try {
    const pkgRoot = path.dirname(require.resolve('whatsapp-web.js/package.json'));
    const utils = path.join(pkgRoot,'src','util','Injected','Utils.js');
    if (!fs.existsSync(utils)) return out;
    const before = fs.readFileSync(utils,'utf8');
    let text = before.replace(/(^|\r?\n)\s*(?:if\s*\(message\s*&&\s*message\.__x_id\)\s*delete\s+message\.__x_id\s*;?|message\.__x_id\s*=.*?;)(?=\r?\n|$)/g,'\n');
    text = text.replace(/(^|\r?\n)\s*\/\*\s*CHAT_BOT_[^*]*COMPAT[^*]*\*\/\s*/g,'\n');
    for (const [a,b] of [
      ['window.Store.Msg.get(newMsgKey._serialized)','window.Store.Msg.get(newMsgKey._serialized || newMsgKey.$1)'],
      ['window.Store.Msg.get(msg.id._serialized)','window.Store.Msg.get(msg.id._serialized || msg.id.$1)'],
      ['window.Store.Msg.get(chat.lastReceivedKey._serialized)','window.Store.Msg.get(chat.lastReceivedKey._serialized || chat.lastReceivedKey.$1)'],
      ['window.Store.WidFactory.createWid(chat.id._serialized)','window.Store.WidFactory.createWid(chat.id._serialized || chat.id.$1)'],
    ]) text = text.replaceAll(a,b);
    try { new vm.Script(text,{filename:utils}); } catch(e) { throw new Error('إصلاح Utils.js أنتج صياغة غير صالحة: '+e.message); }
    if (text!==before) { const tmp=utils+'.chatbot.tmp'; fs.writeFileSync(tmp,text,'utf8'); fs.renameSync(tmp,utils); out.changed=true; out.notes.push('تم تنظيف patch قديم وإصلاح توافق IDs بأمان.'); }
    return out;
  } catch(e) { out.ok=false; out.notes.push(e.message||String(e)); return out; }
}
const patchResult = patchUtilsForWhatsApp();
if (!patchResult.ok) throw new Error(patchResult.notes.join(' | '));
const browserMarker = path.join(path.resolve(__dirname, '..'), '.browser-path');
function detectSystemBrowser() {
  const candidates = [];
  if (process.env.PUPPETEER_EXECUTABLE_PATH) candidates.push(process.env.PUPPETEER_EXECUTABLE_PATH);
  if (process.env.CHROME_PATH) candidates.push(process.env.CHROME_PATH);
  if (process.platform === 'win32') {
    const roots = [process.env.LOCALAPPDATA, process.env.PROGRAMFILES, process.env['PROGRAMFILES(X86)']].filter(Boolean);
    for (const root of roots) {
      candidates.push(path.join(root, 'Google', 'Chrome', 'Application', 'chrome.exe'));
      candidates.push(path.join(root, 'Microsoft', 'Edge', 'Application', 'msedge.exe'));
      candidates.push(path.join(root, 'Chromium', 'Application', 'chrome.exe'));
    }
  } else if (process.platform === 'linux') {
    candidates.push('/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser');
  } else if (process.platform === 'darwin') {
    candidates.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', '/Applications/Chromium.app/Contents/MacOS/Chromium');
  }
  for (const candidate of candidates) {
    try { if (candidate && fs.existsSync(candidate)) return candidate; } catch {}
  }
  return '';
}
let detectedChrome = '';
try { const marked = fs.readFileSync(browserMarker, 'utf8').trim(); if (marked && fs.existsSync(marked)) detectedChrome = marked; } catch {}
if (!detectedChrome) detectedChrome = detectSystemBrowser();
if (detectedChrome && !fs.existsSync(browserMarker)) { try { fs.writeFileSync(browserMarker, detectedChrome, 'utf8'); } catch {} }
process.env.PUPPETEER_CACHE_DIR = process.env.PUPPETEER_CACHE_DIR || path.join(path.resolve(__dirname, '..'), '.cache', 'puppeteer');
const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const EventEmitter = require('node:events');

function safeError(e) { return String(e?.message || e || 'خطأ غير معروف'); }
function withTimeout(promise, ms, label) {
  let timer;
  const timeout = new Promise((_, reject) => { timer = setTimeout(() => reject(Object.assign(new Error(`${label || 'العملية'} تجاوزت المهلة.`), { code: 'SEND_TIMEOUT' })), Math.max(1000, Number(ms) || 30000)); });
  return Promise.race([Promise.resolve(promise), timeout]).finally(() => clearTimeout(timer));
}
function idSerialized(id) {
  if (!id) return '';
  if (typeof id === 'string') return id;
  if (id._serialized) return String(id._serialized);
  if (id.$1) return String(id.$1);
  if (id.remote) return idSerialized(id.remote);
  return id.id !== undefined ? String(id.id) : '';
}
function chatIdFromMessage(msg) {
  const candidates = [msg?.from, msg?.to, msg?.chatId, msg?.id?.remote, msg?.msgId?.remote, msg?._data?.id?.remote, msg?._data?.chatId, msg?.id?._serialized, msg?.id?.$1];
  for (const value of candidates) { const id = idSerialized(value).trim().toLowerCase(); if (id.endsWith('@g.us') || id.endsWith('@c.us') || id.endsWith('@lid')) return id; }
  return '';
}
function groupFromMessage(msg) { const id = chatIdFromMessage(msg); return id.endsWith('@g.us') ? id : null; }
function ackIsDelivered(ack) { return Number(ack) >= 2; }

class WhatsAppManager extends EventEmitter {
  constructor({ store, log }) { super(); this.store = store; this.log = log; this.clients = new Map(); this.pending = new Map(); }
  entry(id) {
    const sid = this.store.safeSessionId(id);
    if (!this.clients.has(sid)) this.clients.set(sid, { client: null, status: 'idle', ready: false, qr: null, browser: '', info: null, lastAck: null, lastSent: null, starting: null, liveGroups: new Map(), stopping: false, reconnectTimer: null, reconnects: 0, generation: 0, readyProbe: null, connectedAt: null });
    return this.clients.get(sid);
  }
  hasSavedAuth(id) {
    const dir = this.store.getPaths(id).auth;
    try { return fs.existsSync(dir) && fs.readdirSync(dir, { withFileTypes: true }).some(x => x.isDirectory() || x.isFile()); } catch { return false; }
  }
  emitStatus(id) { this.emit('status', id, this.listRuntime(id)); }
  clearReadyProbe(e) { if (e.readyProbe) { clearInterval(e.readyProbe); e.readyProbe = null; } }
  startReadyProbe(sid, client, generation) {
    const e = this.entry(sid); this.clearReadyProbe(e); let attempts = 0;
    e.readyProbe = setInterval(async () => {
      if (generation !== e.generation || e.stopping || e.ready) return this.clearReadyProbe(e);
      if (++attempts > 120) return this.clearReadyProbe(e);
      try { const state = typeof client.getState === 'function' ? await client.getState() : null; if (state === 'CONNECTED') this.markReady(sid, client, generation, 'state'); } catch {}
    }, 1000);
  }
  markReady(sid, client, generation, source = 'ready') {
    const e = this.entry(sid); if (generation !== e.generation || e.stopping) return;
    e.ready = true; e.status = 'ready'; e.qr = null; e.browser = 'Chromium/Puppeteer'; e.info = client.info || e.info; e.reconnects = 0; e.connectedAt ||= new Date().toISOString(); this.clearReadyProbe(e);
    this.log(sid, 'INFO', `جلسة WhatsApp جاهزة للإرسال والاستقبال (${source}).`); this.emitStatus(sid);
  }
  async start(id) {
    const sid = this.store.safeSessionId(id), e = this.entry(sid); e.stopping = false;
    if (e.ready && e.client) return this.listRuntime(sid);
    if (e.starting) return e.starting;
    if (e.client) { try { await e.client.destroy(); } catch {} e.client = null; }
    const generation = ++e.generation; e.status = 'starting'; e.qr = null; e.ready = false; e.connectedAt = null;
    e.starting = (async () => {
      const p = this.store.getPaths(sid); this.store.ensureDir?.(sid); fs.mkdirSync(p.auth, { recursive: true });
      const client = new Client({
        authStrategy: new LocalAuth({ clientId: sid, dataPath: p.auth }),
        puppeteer: { headless: String(process.env.HEADLESS || 'true') !== 'false', executablePath: detectedChrome || undefined, args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-background-networking', '--disable-background-timer-throttling', '--disable-renderer-backgrounding'], timeout: 60000 },
        authTimeoutMs: 60000, takeoverOnConflict: false,
      });
      e.client = client;
      client.on('qr', async qr => { if (generation !== e.generation) return; e.qr = qr; e.status = 'qr'; try { e.qr = await require('qrcode').toDataURL(qr, { margin: 1, width: 260 }); } catch {} this.emitStatus(sid); });
      client.on('authenticated', () => { if (generation !== e.generation) return; e.status = 'authenticated'; e.qr = null; this.startReadyProbe(sid, client, generation); this.emitStatus(sid); });
      client.on('ready', () => this.markReady(sid, client, generation, 'event'));
      client.on('change_state', state => { if (generation !== e.generation) return; if (state === 'CONNECTED' && !e.ready) this.startReadyProbe(sid, client, generation); });
      client.on('auth_failure', msg => { if (generation !== e.generation) return; e.ready = false; e.status = 'auth_failure'; this.clearReadyProbe(e); this.log(sid, 'ERROR', `فشل توثيق WhatsApp: ${safeError(msg)}`); this.emitStatus(sid); });
      client.on('disconnected', reason => {
        if (generation !== e.generation) return; e.ready = false; e.status = 'disconnected'; e.client = null; this.clearReadyProbe(e); this.log(sid, 'WARN', `انفصلت جلسة WhatsApp: ${safeError(reason)}`); this.emitStatus(sid);
        if (!e.stopping && this.hasSavedAuth(sid) && e.reconnects < 4) { const wait = [2500, 5000, 10000, 20000][Math.min(e.reconnects, 3)]; e.reconnects++; clearTimeout(e.reconnectTimer); e.reconnectTimer = setTimeout(() => { if (generation !== e.generation || e.stopping) return; this.start(sid).catch(err => this.log(sid, 'ERROR', `فشل إعادة الاتصال: ${safeError(err)}`)); }, wait); }
      });
      client.on('message', async msg => {
        const gid = groupFromMessage(msg); if (gid) { const rt = this.entry(sid); let info = { gid, name: gid }; try { const chat = typeof msg.getChat === 'function' ? await msg.getChat() : null; if (chat) info = await this.groupInfoFromChat(chat); } catch {} rt.liveGroups.set(gid, info); }
        this.emit('message', sid, msg);
      });
      client.on('message_ack', (msg, ack) => { e.lastAck = { at: new Date().toISOString(), id: idSerialized(msg?.id || msg), chatId: chatIdFromMessage(msg), ack, level: Number(ack) >= 4 ? 'read' : Number(ack) >= 3 ? 'delivered' : Number(ack) >= 2 ? 'server' : Number(ack) === 1 ? 'pending' : 'error' }; this.resolvePending('ack', sid, e.lastAck); this.emit('ack', sid, e.lastAck); });
      client.on('message_create', msg => { if (msg?.fromMe) { this.resolvePending('message', sid, msg); this.emit('message_create', sid, msg); } });
      client.on('message_reaction', reaction => { this.emit('reaction', sid, { ...reaction, chatId: idSerialized(reaction?.chatId || reaction?.msgId?.remote || reaction?.id?.remote || reaction?.messageId?.remote || ''), emoji: String(reaction?.reaction || reaction?.emoji || reaction?.value || ''), msgId: reaction?.msgId || reaction?.messageId || reaction?.id || reaction?.message?.id || null, fromMe: !!reaction?.fromMe }); });
      await withTimeout(client.initialize(), 180000, 'تهيئة WhatsApp');
      return this.listRuntime(sid);
    })().catch(async err => { if (generation === e.generation && e.client) { try { await e.client.destroy(); } catch {} e.client = null; } e.status = 'error'; e.ready = false; this.clearReadyProbe(e); this.log(sid, 'ERROR', `فشل تشغيل الجلسة: ${safeError(err)}`); throw err; }).finally(() => { e.starting = null; });
    return e.starting;
  }
  async ensureReady(id) { const sid = this.store.safeSessionId(id), e = this.entry(sid); if (e.ready && e.client) return e.client; await this.start(sid); const after = this.entry(sid); if (!after.ready || !after.client) throw new Error(`جلسة WhatsApp ليست جاهزة. الحالة الحالية: ${after.status}`); return after.client; }
  async stop(id, { clearAuth = false } = {}) { const sid = this.store.safeSessionId(id), e = this.entry(sid); e.stopping = true; ++e.generation; clearTimeout(e.reconnectTimer); this.clearReadyProbe(e); if (e.client) { try { await withTimeout(e.client.destroy(), 10000, 'إيقاف الجلسة'); } catch {} } e.client = null; e.ready = false; e.qr = null; e.status = 'stopped'; if (clearAuth) { try { fs.rmSync(this.store.getPaths(sid).auth, { recursive: true, force: true }); } catch {} } e.stopping = false; e.reconnects = 0; this.emitStatus(sid); }
  async stopAll(opts = {}) { for (const sid of this.clients.keys()) await this.stop(sid, opts); }
  listRuntime(id) { const e = this.entry(id); return { status: e.status, ready: e.ready, qr: e.qr, browser: e.browser, info: e.info, lastAck: e.lastAck, lastSent: e.lastSent, reconnects: e.reconnects || 0, connectedAt: e.connectedAt, liveGroups: [...e.liveGroups.values()] }; }
  waitForEvent(kind, sid, matcher, timeoutMs) {
    const key = `${sid}|${kind}`, list = this.pending.get(key) || [], match = typeof matcher === 'function' ? matcher : value => { const want = String(matcher || '').toLowerCase(); return !want || String(kind === 'ack' ? value?.chatId : chatIdFromMessage(value)).toLowerCase() === want; };
    this.pending.set(key, list); let done = false, timer, item;
    const promise = new Promise(resolve => { const finish = value => { if (done) return; done = true; clearTimeout(timer); const index = list.indexOf(item); if (index >= 0) list.splice(index, 1); if (!list.length) this.pending.delete(key); resolve(value); }; item = { match, resolve: finish }; timer = setTimeout(() => finish(null), Math.max(500, Number(timeoutMs) || 5000)); list.push(item); });
    promise.cancel = () => item?.resolve(null); return promise;
  }
  resolvePending(kind, sid, value) { const list = this.pending.get(`${sid}|${kind}`) || []; const item = list.find(x => { try { return x.match(value); } catch { return false; } }); if (item) item.resolve(value); }
  async sendConfirmed(sid, chatId, operation, timeoutMs, label, expectedText = '') {
    const normalizedChat = String(chatId || '').toLowerCase(), started = Date.now();
    const ackWait = this.waitForEvent('ack', sid, value => String(value?.chatId || '').toLowerCase() === normalizedChat && ackIsDelivered(value?.ack), 5000);
    const createdWait = this.waitForEvent('message', sid, msg => { if (String(chatIdFromMessage(msg)).toLowerCase() !== normalizedChat) return false; const body = String(msg?.body || '').trim(); return !expectedText || body === expectedText || body.includes(expectedText.slice(0, Math.min(30, expectedText.length))); }, 5000);
    try {
      const result = await withTimeout(operation(), timeoutMs, label);
      if (!result) { const event = await Promise.race([ackWait, createdWait]); if (event) { const confirmed = event?.ack !== undefined && ackIsDelivered(event.ack); return { result: event, __chatBotAck: { status: confirmed ? 'confirmed' : 'created', mode: confirmed ? 'ack' : 'message_create', waitedMs: Date.now() - started } }; } throw Object.assign(new Error(`تم طلب ${label || 'الإرسال'} لكن لم يظهر تأكيد.`), { code: 'SEND_UNCERTAIN' }); }
      const id = idSerialized(result?.id || result?.messageId || result), earlyAck = await Promise.race([ackWait, createdWait, new Promise(resolve => setTimeout(() => resolve(null), 700))]);
      if (earlyAck?.ack !== undefined && ackIsDelivered(earlyAck.ack)) return { result, __chatBotAck: { status: 'confirmed', mode: 'ack', id, waitedMs: Date.now() - started } };
      if (earlyAck?.body !== undefined || idSerialized(earlyAck?.id)) return { result, __chatBotAck: { status: 'created', mode: 'message_create', id, waitedMs: Date.now() - started } };
      // The library returned a Message object, which means the operation created a send.
      // Mark it as created, not falsely as delivered, and never retry it automatically.
      return { result, __chatBotAck: { status: 'created', mode: 'return', id, waitedMs: Date.now() - started } };
    } catch (e) {
      if (e.code === 'SEND_TIMEOUT') { const event = await Promise.race([ackWait, createdWait]); if (event) { const confirmed = event?.ack !== undefined && ackIsDelivered(event.ack); return { result: event, __chatBotAck: { status: confirmed ? 'confirmed' : 'created', mode: confirmed ? 'ack' : 'message_create', waitedMs: Date.now() - started } }; } throw Object.assign(new Error(`لم نتأكد من نتيجة ${label || 'الإرسال'}؛ لم تتم إعادة الإرسال لمنع التكرار.`), { code: 'SEND_UNCERTAIN' }); }
      ackWait.cancel(); createdWait.cancel(); throw e;
    }
  }
  async resolveChatId(id, target) {
    const sid = this.store.safeSessionId(id), client = await this.ensureReady(sid);
    if (target.kind === 'group' || String(target.gid || '').toLowerCase().endsWith('@g.us')) { const gid = String(target.gid || '').trim().toLowerCase(); if (!/^\d+(?:-\d+)*@g\.us$/.test(gid)) throw new Error('معرف المجموعة غير صالح.'); try { const chat = await client.getChatById(gid); return idSerialized(chat?.id) || gid; } catch { return gid; } }
    const digits = String(target.e164 || target.phone || '').replace(/\D/g, ''); if (!digits) throw new Error('رقم المستلم مفقود.'); const n = await withTimeout(client.getNumberId(digits), 20000, 'فحص رقم WhatsApp'); if (!n) throw new Error(`الرقم ${digits} غير مسجل على WhatsApp.`); return idSerialized(n);
  }
  async sendText(id, chatId, text, { timeoutMs = 30000 } = {}) { const client = await this.ensureReady(id), content = String(text || '').trim(); if (!content) throw new Error('النص فارغ.'); const r = await this.sendConfirmed(this.store.safeSessionId(id), chatId, () => client.sendMessage(chatId, content), timeoutMs, 'إرسال النص', content); this.entry(id).lastSent = { at: new Date().toISOString(), chatId, kind: 'text' }; return r; }
  async sendMedia(id, chatId, file, { timeoutMs = 30000, asDocument = false } = {}) { const client = await this.ensureReady(id), media = MessageMedia.fromFilePath(file), sid = this.store.safeSessionId(id); const r = await this.sendConfirmed(sid, chatId, () => client.sendMessage(chatId, media, { sendMediaAsDocument: Boolean(asDocument) }), timeoutMs, 'إرسال الوسائط'); this.entry(id).lastSent = { at: new Date().toISOString(), chatId, kind: asDocument ? 'document' : 'media' }; return r; }
  async replyToMessage(id, message, text) { await this.ensureReady(id); const content = String(text || '').trim(); if (!content) return null; const chatId = chatIdFromMessage(message); try { if (typeof message?.reply === 'function') return await this.sendConfirmed(this.store.safeSessionId(id), chatId, () => message.reply(content), 30000, 'الرد', content); } catch (e) { if (e.code === 'SEND_UNCERTAIN') throw e; } if (!chatId) throw new Error('تعذر تحديد المحادثة للرد.'); return this.sendText(id, chatId, content); }
  async reactToMessage(id, messageId, emoji) { const client = await this.ensureReady(id), mid = idSerialized(messageId); if (!mid) throw new Error('معرف الرسالة غير متاح.'); const m = await withTimeout(client.getMessageById(mid), 15000, 'البحث عن الرسالة'); if (!m) throw new Error('لم أجد الرسالة المطلوبة للـReaction.'); await withTimeout(m.react(String(emoji || '👍')), 15000, 'إرسال Reaction'); return { __chatBotAck: { status: 'confirmed', mode: 'reaction' } }; }
  async listGroups(id) {
    const client = await this.ensureReady(id), e = this.entry(id), out = [], seen = new Set();
    let chats = [];
    try { chats = await withTimeout(client.getChats(), 30000, 'قراءة محادثات WhatsApp'); }
    catch (e2) { this.log(id, 'WARN', `تعذر قراءة محادثات WhatsApp: ${safeError(e2)}`); }
    for (const chat of chats || []) {
      const gid = idSerialized(chat?.id).toLowerCase();
      if (!gid.endsWith('@g.us') && !chat?.isGroup) continue;
      try {
        const info = await this.groupInfoFromChat(chat);
        if (!/^\d+(?:-\d+)*@g\.us$/.test(info.gid) || seen.has(info.gid)) continue;
        seen.add(info.gid); e.liveGroups.set(info.gid, info); out.push(info);
      } catch (err) {
        if (gid.endsWith('@g.us')) e.liveGroups.set(gid, { gid, name: String(chat?.name || chat?.subject || gid), description:'', owner:'', participantsCount:null, participants:[], admins:[], inviteCode:'' });
        this.log(id, 'WARN', `تعذر تحليل مجموعة ${gid || 'غير معروفة'}: ${safeError(err)}`);
      }
    }
    for (const [gid, info] of e.liveGroups) if (!seen.has(gid) && /@g\.us$/.test(gid)) out.push(info);
    const unique = new Map(out.filter(x => x?.gid).map(x => [x.gid, x]));
    return [...unique.values()];
  }
  async groupInfoFromChat(chat) { let inviteCode = ''; try { if (typeof chat.getInviteCode === 'function') inviteCode = await chat.getInviteCode(); } catch {} const gid = idSerialized(chat?.id).toLowerCase(); const raw = Array.isArray(chat?.participants) ? chat.participants : (Array.isArray(chat?.groupMetadata?.participants) ? chat.groupMetadata.participants : []); const participants = raw.map(p => ({ id: idSerialized(p?.id || p).toLowerCase(), name: String(p?.name || p?.pushname || p?.notifyName || '').slice(0,120), admin: Boolean(p?.isAdmin || p?.isSuperAdmin || p?.admin) })).filter(p => p.id).slice(0,2000); const admins = participants.filter(p => p.admin).slice(0,500); return { gid, name: String(chat?.name || chat?.subject || 'مجموعة').slice(0, 120), description: String(chat?.description || '').slice(0, 1000), owner: idSerialized(chat?.groupMetadata?.owner), participantsCount: participants.length || (Array.isArray(raw) ? raw.length : null), participants, admins, inviteCode }; }
  async getGroupInfo(id, gid) { const client = await this.ensureReady(id), want = String(gid || '').trim().toLowerCase(); if (!/^\d+(?:-\d+)*@g\.us$/.test(want)) throw new Error('GID غير صالح.'); try { const chat = await client.getChatById(want); if (chat) return this.groupInfoFromChat(chat); } catch {} try { const chats = await client.getChats(); const chat = (chats || []).find(c => idSerialized(c?.id).toLowerCase() === want); if (chat) return this.groupInfoFromChat(chat); } catch {} const live = this.entry(id).liveGroups.get(want); if (live) return live; throw new Error('لم أستطع الوصول إلى هذه المجموعة داخل الجلسة الحالية. افتح المجموعة أو نفّذ اكتشاف المجموعات ثم أعد المحاولة.'); }
  async analyzeGroupInvite(id, code) { const client = await this.ensureReady(id), c = String(code || '').trim(); if (!c) throw new Error('رابط الدعوة غير صالح.'); if (typeof client.getInviteInfo !== 'function') throw new Error('إصدار المكتبة الحالي لا يوفر تحليل رابط الدعوة من دون فتح المجموعة.'); const info = await withTimeout(client.getInviteInfo(c), 20000, 'تحليل الدعوة'); return { gid: idSerialized(info?.id), name: String(info?.subject || info?.name || 'مجموعة عبر دعوة'), description: String(info?.description || ''), participantsCount: Number.isFinite(Number(info?.size)) ? Number(info.size) : null, inviteCode: c }; }
  async getGroupInfoFromMessage(id, msg) { let chat = null; try { if (typeof msg?.getChat === 'function') chat = await msg.getChat(); } catch {} if (chat) return this.groupInfoFromChat(chat); const gid = groupFromMessage(msg); if (!gid) throw new Error('الرسالة الحالية ليست من مجموعة.'); return this.getGroupInfo(id, gid); }
}
module.exports = { WhatsAppManager, safeError, idSerialized, groupFromMessage, chatIdFromMessage, patchResult };
