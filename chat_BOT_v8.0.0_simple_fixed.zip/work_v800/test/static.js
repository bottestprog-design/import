"use strict";
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '..');
const js = ['server.js','scripts/ensure-browser.js','public/app.js','src/compat.js','src/whatsapp.js','src/delivery.js','src/interaction.js','src/scheduler.js','src/store.js','src/phones.js','src/groups.js','src/media.js','src/backgrounds.js','src/serverlib.js'];
let failed = 0;
for (const f of js) {
  try { new vm.Script(fs.readFileSync(path.join(root,f),'utf8'), {filename:f}); console.log('OK JS', f); }
  catch (e) { failed++; console.error('BAD JS', f, e.message); }
}
const app = fs.readFileSync(path.join(root,'public/app.js'),'utf8');
for (const token of ['function pageSend(', 'function pagePeople(', 'function pageGroups(', 'function pageInteraction(', 'function pageSession(', 'function pageAppearance(', 'function pageOperation(', 'function loadCountries(', 'function setupBackground(', 'function rangeControl(']) {
  if (!app.includes(token)) { failed++; console.error('MISSING', token); }
}
for (const banned of ['/api/session/select','/api/session/create','/api/session/update','/api/session/delete','/api/media/upload','/api/schedule/delete','/api/interaction/rules/delete']) {
  if (app.includes(banned)) { failed++; console.error('STALE_ENDPOINT', banned); }
}
if ((app.match(/function loadCountries\(/g)||[]).length !== 1) { failed++; console.error('DUPLICATE loadCountries'); }
const whatsapp = fs.readFileSync(path.join(root,'src/whatsapp.js'),'utf8');
if (!whatsapp.includes('function ackIsDelivered(ack) { return Number(ack) >= 2; }')) { failed++; console.error('ACK_SEMANTICS_NOT_SAFE'); }
const server = fs.readFileSync(path.join(root,'server.js'),'utf8');
for (const token of ['/api/send','/api/recipient','/api/groups/connect','/api/groups/discover','/api/automation/task','/api/interaction/rules','/api/interaction/test','/api/settings/background','/api/countries']) if (!server.includes(token)) { failed++; console.error('MISSING SERVER ROUTE', token); }
const html = fs.readFileSync(path.join(root,'public/index.html'),'utf8');
for (const token of ['id="app"','id="bgCanvas"','id="bgImageLayer"']) if (!html.includes(token)) { failed++; console.error('MISSING HTML', token); }
process.exitCode = failed ? 1 : 0;

const pkg = JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8')); if (pkg.version !== '8.0.0') { failed++; console.error('BAD VERSION'); } if (pkg.dependencies?.puppeteer !== '24.38.0') { failed++; console.error('PUPPETEER PIN MISSING'); }
