'use strict';

const { scanImages, safeImagePath, ensureNamedImages } = require('./media');
function sleep(ms) { return new Promise(resolve => setTimeout(resolve, Math.max(0, Number(ms) || 0))); }
function safeError(error) { return String(error?.message || error || 'خطأ غير معروف'); }

function renderTemplate(text, values) {
  return String(text || '')
    .replace(/\{\{recipient\}\}/gi, String(values.recipient || ''))
    .replace(/\{\{phone\}\}/gi, String(values.phone || ''))
    .replace(/\{\{image\}\}/gi, String(values.image || ''))
    .replace(/\{\{date\}\}/gi, String(values.date || ''))
    .replace(/\{\{time\}\}/gi, String(values.time || ''))
    .trim();
}

function isPermanentDeliveryError(message) {
  const text = String(message || '').toLowerCase();
  return /الرقم .* غير مسجل|رقم .* غير صالح|المستلم غير موجود|الصورة غير موجودة|الصورة غير صالحة|لا توجد صور|نوع الملف غير مدعوم|حجم الملف أكبر|اختر|حدد مستلم|حدد مجموعة|حدد صورة|معرف مجموعة|not registered|invalid (?:phone|number|recipient)|file (?:not found|invalid)|unsupported|too large/.test(text);
}
function isUncertainDeliveryError(error) {
  return String(error?.code || '') === 'SEND_UNCERTAIN';
}
function assertConfirmed(result, label, requireAck = false) {
  const ack = result?.__chatBotAck;
  if (ack?.status === 'error') throw Object.assign(new Error(`${label}: رفض WhatsApp الإرسال.`), { code: 'SEND_ACK_ERROR' });
  if (requireAck && ack?.status === 'pending') throw Object.assign(new Error(`${label}: تم إنشاء الرسالة لكن لم تصل حالة تأكيد من WhatsApp ضمن المهلة.`), { code: 'SEND_UNCERTAIN' });
  return result;
}
function nowVars(recipient, image, timezone = 'Asia/Muscat') {
  return {
    recipient: recipient.name,
    phone: recipient.phone,
    image: image.filename,
    date: new Intl.DateTimeFormat('ar-OM', { timeZone: timezone, dateStyle: 'short' }).format(new Date()),
    time: new Intl.DateTimeFormat('ar-OM', { timeZone: timezone, hour: '2-digit', minute: '2-digit' }).format(new Date())
  };
}

class DeliveryService {
  constructor({ store, whatsapp, log }) {
    this.store = store;
    this.whatsapp = whatsapp;
    this.log = log;
    this.busy = new Set();
  }
  session(id) { return this.store.loadSession(id); }
  paths(id) { return this.store.getPaths(id); }
  save(s) { return this.store.saveSession(s); }
  images(id) {
    const s = this.session(id);
    return scanImages(this.paths(id).images, s.settings.maxImageSizeMB);
  }
  syncCycle(id) {
    const s = this.session(id);
    ensureNamedImages(this.paths(id).images);
    const scan = this.images(id);
    const ids = scan.images.map(x => x.id);
    const old = Array.isArray(s.cycle.imageOrder) ? s.cycle.imageOrder : [];
    const current = old[s.cycle.currentIndex] || null;
    if (JSON.stringify(ids) === JSON.stringify(old)) return s;
    s.cycle.imageOrder = ids;
    if (!ids.length) {
      s.cycle.currentIndex = 0;
      s.cycle.delivery = {};
    } else if (current && ids.includes(current)) {
      s.cycle.currentIndex = ids.indexOf(current);
    } else {
      s.cycle.currentIndex = Math.min(Number(s.cycle.currentIndex) || 0, ids.length - 1);
      s.cycle.delivery = {};
    }
    return this.save(s);
  }
  currentImage(id) {
    const s = this.syncCycle(id);
    const scan = this.images(id);
    if (!scan.images.length) return null;
    const currentId = s.cycle.imageOrder[s.cycle.currentIndex];
    return scan.images.find(x => x.id === currentId) || scan.images[0];
  }
  deliveryState(s, imageId, recipientId) {
    s.cycle.delivery = s.cycle.delivery || {};
    s.cycle.delivery[imageId] = s.cycle.delivery[imageId] || {};
    s.cycle.delivery[imageId][recipientId] = {
      pre: false,
      image: false,
      post: false,
      lastError: null,
      ...(s.cycle.delivery[imageId][recipientId] || {})
    };
    return s.cycle.delivery[imageId][recipientId];
  }
  async retry(task, attempts, delay, label = 'العملية') {
    let last;
    for (let i = 0; i < attempts; i += 1) {
      try { return await task(); }
      catch (error) {
        last = error;
        if (isPermanentDeliveryError(error?.message) || isUncertainDeliveryError(error) || error?.code === 'SEND_ACK_ERROR') throw error;
        if (i + 1 < attempts) {
          this.log?.(null, 'WARN', `${label}: المحاولة ${i + 1} فشلت، ستتم إعادة المحاولة.`);
          await sleep(delay * (i + 1));
        }
      }
    }
    throw last || new Error(`فشلت ${label}.`);
  }
  async sequence(id, recipient, image, { scheduled = true, preText, postText } = {}) {
    const s = this.session(id);
    const vars = nowVars(recipient, image, s.settings.timezone);
    const pre = renderTemplate(preText ?? s.settings.preText, vars);
    const post = renderTemplate(postText ?? s.settings.postText, vars);
    const state = scheduled ? this.deliveryState(s, image.id, recipient.id) : { pre: false, image: false, post: false, lastError: null };
    const chatId = await this.whatsapp.resolveChatId(id, recipient);
    const file = safeImagePath(this.paths(id).images, image.filename);
    const delay = Number(s.settings.sendDelayMs) || 0;

    if (pre && !state.pre) {
      const sentPre = await this.retry(() => this.whatsapp.sendText(id, chatId, pre), s.settings.retryAttempts, s.settings.retryDelayMs, 'الرسالة قبل الصورة');
      assertConfirmed(sentPre, 'الرسالة قبل الصورة', s.settings.requireAck);
      state.pre = true;
      if (sentPre?.__chatBotAck?.status === 'confirmed') s.stats.confirmedAcks += 1;
      if (sentPre?.__chatBotAck?.status === 'pending') s.stats.uncertainSends += 1;
      s.stats.sentMessages += 1;
      if (scheduled) this.save(s);
      if (delay) await sleep(delay);
    }
    if (!state.image) {
      const sentImage = await this.retry(() => this.whatsapp.sendMedia(id, chatId, file), s.settings.retryAttempts, s.settings.retryDelayMs, 'الصورة');
      assertConfirmed(sentImage, 'الصورة', s.settings.requireAck);
      state.image = true;
      if (sentImage?.__chatBotAck?.status === 'confirmed') s.stats.confirmedAcks += 1;
      if (sentImage?.__chatBotAck?.status === 'pending') s.stats.uncertainSends += 1;
      s.stats.sentImages += 1;
      if (scheduled) this.save(s);
      if (delay) await sleep(delay);
    }
    if (post && !state.post) {
      const sentPost = await this.retry(() => this.whatsapp.sendText(id, chatId, post), s.settings.retryAttempts, s.settings.retryDelayMs, 'الرسالة بعد الصورة');
      assertConfirmed(sentPost, 'الرسالة بعد الصورة', s.settings.requireAck);
      state.post = true;
      if (sentPost?.__chatBotAck?.status === 'confirmed') s.stats.confirmedAcks += 1;
      if (sentPost?.__chatBotAck?.status === 'pending') s.stats.uncertainSends += 1;
      s.stats.sentMessages += 1;
      if (scheduled) this.save(s);
    }
    return state;
  }
  allComplete(s, image) {
    const enabled = s.recipients.filter(r => r.enabled !== false);
    if (!enabled.length) return false;
    return enabled.every(r => {
      const d = s.cycle.delivery?.[image.id]?.[r.id] || {};
      return (!s.settings.preText || d.pre === true) && d.image === true && (!s.settings.postText || d.post === true);
    });
  }
  advanceIfComplete(id) {
    const s = this.syncCycle(id);
    const image = this.currentImage(id);
    if (!image || !this.allComplete(s, image)) return false;
    const count = s.cycle.imageOrder.length;
    s.cycle.currentIndex = (s.cycle.currentIndex + 1) % count;
    this.save(s);
    this.log(id, 'INFO', 'اكتملت الصورة الحالية وانتقل البوت للصورة التالية.');
    return true;
  }
  async scheduledRun(id) {
    const safe = this.store.safeSessionId(id);
    if (this.busy.has(`send:${safe}`)) return { ok: false, message: 'يوجد إرسال آخر قيد التنفيذ لهذه الجلسة.' };
    this.busy.add(`send:${safe}`);
    try {
      let s = this.syncCycle(safe);
      if (this.advanceIfComplete(safe)) s = this.session(safe);
      const image = this.currentImage(safe);
      const recipients = s.recipients.filter(r => r.enabled !== false);
      if (!recipients.length) return { ok: false, retry: false, message: 'لا يوجد مستلمون مفعّلون.' };
      if (!image) return { ok: false, retry: false, message: 'لا توجد صور في هذه الجلسة.' };
      try {
        await this.whatsapp.ensureReady(safe);
      } catch (error) {
        const runtime = this.whatsapp.listRuntime(safe);
        const canRetry = this.whatsapp.hasSavedAuth(safe) && !['logged_out','auth_failure','qr'].includes(runtime.status);
        return { ok: false, retry: canRetry, message: safeError(error) };
      }
      const sent = [];
      const failed = [];
      for (const recipient of recipients) {
        try {
          await this.sequence(safe, recipient, image, { scheduled: true });
          sent.push(recipient.name);
        } catch (error) {
          const cur = this.session(safe);
          const d = this.deliveryState(cur, image.id, recipient.id);
          d.lastError = safeError(error).slice(0, 500);
          cur.stats.failedSends += 1;
          this.save(cur);
          failed.push({ name: recipient.name, error: safeError(error), code: String(error?.code || '') || null });
          this.log(safe, 'ERROR', `فشل إرسال ${image.filename} إلى ${recipient.name}: ${safeError(error)}`);
        }
      }
      const cur = this.session(safe);
      cur.lastRun = { at: new Date().toISOString(), type: 'scheduled', image: image.filename, sent, failed };
      cur.schedule.lastError = failed.length ? 'تعذر إكمال بعض المستلمين.' : null;
      const retryNeeded = failed.some(item => item.code !== 'SEND_UNCERTAIN' && item.code !== 'SEND_ACK_ERROR' && !isPermanentDeliveryError(item.error));
      if (!failed.length) {
        cur.stats.successfulRuns += 1;
        this.save(cur);
        this.advanceIfComplete(safe);
        return { ok: true, sent, failed };
      }
      cur.stats.failedRuns += 1;
      this.save(cur);
      return { ok: false, retry: retryNeeded, sent, failed, message: retryNeeded ? 'تم الإرسال لبعض المستلمين فقط؛ سيُستكمل الناقص.' : 'تعذر الإرسال لبعض المستلمين. راجع أرقامهم ثم أعد المحاولة عند الموعد القادم.' };
    } finally {
      this.busy.delete(`send:${safe}`);
    }
  }
  jobDeliveryState(job, recipientId) {
    job.delivery = job.delivery || {};
    job.delivery[recipientId] = {
      pre:false,
      image:false,
      post:false,
      lastError:null,
      ...(job.delivery[recipientId] || {})
    };
    return job.delivery[recipientId];
  }
  async scheduledJobRun(id, jobId) {
    const safe = this.store.safeSessionId(id);
    if (this.busy.has(`send:${safe}`)) return { ok:false, retry:true, message:'يوجد إرسال آخر قيد التنفيذ لهذه الجلسة.' };
    this.busy.add(`send:${safe}`);
    try {
      const s = this.session(safe);
      const job = s.scheduledJobs.find(x => x.id === String(jobId));
      if (!job) return { ok:false, retry:false, message:'الموعد المحدد غير موجود.' };
      const image = this.images(safe).images.find(x => x.id === job.imageId);
      if (!image) return { ok:false, retry:false, message:'الصورة المرتبطة بالموعد المحدد غير موجودة.' };
      const ids = new Set((job.recipientIds || []).map(String));
      const recipients = s.recipients.filter(r => r.enabled !== false && ids.has(String(r.id)));
      if (!recipients.length) return { ok:false, retry:false, message:'لا يوجد مستلم مفعّل مرتبط بهذا الموعد.' };
      try { await this.whatsapp.ensureReady(safe); }
      catch (error) {
        const runtime = this.whatsapp.listRuntime(safe);
        const canRetry = this.whatsapp.hasSavedAuth(safe) && !['logged_out','auth_failure','qr'].includes(runtime.status);
        return { ok:false, retry:canRetry, message:safeError(error) };
      }
      const sent=[]; const failed=[];
      for(const recipient of recipients){
        try{
          const vars=nowVars(recipient,image,s.settings.timezone);
          const pre=renderTemplate(job.preText,vars);
          const post=renderTemplate(job.postText,vars);
          const d=this.jobDeliveryState(job,recipient.id);
          const chatId=await this.whatsapp.resolveChatId(safe,recipient);
          const file=safeImagePath(this.paths(safe).images,image.filename);
          const delay=Number(s.settings.sendDelayMs)||0;
          if(pre && !d.pre){ const m=await this.retry(()=>this.whatsapp.sendText(safe,chatId,pre),s.settings.retryAttempts,s.settings.retryDelayMs,'الرسالة قبل الموعد'); assertConfirmed(m,'الرسالة قبل الموعد',s.settings.requireAck); d.pre=true; if(m?.__chatBotAck?.status==='confirmed')s.stats.confirmedAcks+=1; s.stats.sentMessages+=1; this.save(s); if(delay)await sleep(delay); }
          if(!d.image){ const m=await this.retry(()=>this.whatsapp.sendMedia(safe,chatId,file),s.settings.retryAttempts,s.settings.retryDelayMs,'الصورة المجدولة'); assertConfirmed(m,'الصورة المجدولة',s.settings.requireAck); d.image=true; if(m?.__chatBotAck?.status==='confirmed')s.stats.confirmedAcks+=1; s.stats.sentImages+=1; this.save(s); if(delay)await sleep(delay); }
          if(post && !d.post){ const m=await this.retry(()=>this.whatsapp.sendText(safe,chatId,post),s.settings.retryAttempts,s.settings.retryDelayMs,'الرسالة بعد الموعد'); assertConfirmed(m,'الرسالة بعد الموعد',s.settings.requireAck); d.post=true; if(m?.__chatBotAck?.status==='confirmed')s.stats.confirmedAcks+=1; s.stats.sentMessages+=1; this.save(s); }
          d.lastError=null; sent.push(recipient.name); this.save(s);
        } catch(error){ const cur=this.session(safe); const d=this.jobDeliveryState(job,recipient.id); d.lastError=safeError(error).slice(0,500); this.save(cur); failed.push({name:recipient.name,error:safeError(error),code:String(error?.code||'')||null}); this.log(safe,'ERROR',`فشل الموعد الخاص ${job.name} مع ${recipient.name}: ${safeError(error)}`); }
      }
      const cur=this.session(safe);
      cur.lastRun={at:new Date().toISOString(),type:'scheduled-job',jobId:job.id,image:image.filename,sent,failed};
      this.save(cur);
      const retryNeeded=failed.some(x=>x.code!=='SEND_UNCERTAIN'&&x.code!=='SEND_ACK_ERROR'&&!isPermanentDeliveryError(x.error));
      return failed.length?{ok:false,retry:retryNeeded,sent,failed,message:retryNeeded?'تعذر إكمال بعض المستلمين؛ ستتم إعادة المحاولة.':'تعذر الإرسال لبعض المستلمين.'}:{ok:true,sent,failed};
    } finally { this.busy.delete(`send:${safe}`); }
  }
  async preflightRecipients(id, recipients) {
    const checked = [];
    const failed = [];
    for (const recipient of recipients) {
      try {
        const chatId = await this.whatsapp.resolveChatId(id, recipient);
        checked.push({ recipient, chatId });
      } catch (error) {
        failed.push({ recipient: recipient.name, error: safeError(error) });
      }
    }
    return { checked, failed };
  }
  async instantSend(id, { recipientIds, imageIds, preText, postText }) {
    const safe = this.store.safeSessionId(id);
    if (this.busy.has(`send:${safe}`)) throw new Error('يوجد إرسال آخر قيد التنفيذ لهذه الجلسة.');
    this.busy.add(`send:${safe}`);
    try {
      const s = this.syncCycle(safe);
      if (!this.whatsapp.isReady(safe)) throw new Error('الجلسة غير متصلة.');
      const allowedRecipients = new Set((recipientIds || []).map(String));
      const allowedImages = new Set((imageIds || []).map(String));
      const recipients = s.recipients.filter(r => r.enabled !== false && allowedRecipients.has(r.id));
      const images = this.images(safe).images.filter(x => allowedImages.has(x.id));
      if (!recipients.length) throw new Error('حدد مستلمًا واحدًا على الأقل.');
      if (!images.length) throw new Error('حدد صورة واحدة على الأقل.');
      if (recipients.length * images.length > s.settings.maxInstantPairs) {
        throw new Error(`عدد عمليات الإرسال كبير جدًا. الحد الحالي ${s.settings.maxInstantPairs} عملية في الدفعة.`);
      }
      const preflight = await this.preflightRecipients(safe, recipients);
      if (preflight.failed.length) {
        throw new Error(`تعذر التحقق من ${preflight.failed.length} مستلم قبل بدء الإرسال: ${preflight.failed.map(x => `${x.recipient}: ${x.error}`).join(' | ')}`);
      }
      const sent = [];
      const failed = [];
      for (const recipient of recipients) {
        for (const image of images) {
          try {
            await this.sequence(safe, recipient, image, { scheduled: false, preText, postText });
            const curStats = this.session(safe);
            this.save(curStats);
            sent.push({ recipient: recipient.name, image: image.filename });
          } catch (error) {
            failed.push({ recipient: recipient.name, image: image.filename, error: safeError(error), code: String(error?.code || '') || null });
            this.log(safe, 'ERROR', `فشل الإرسال الفوري ${image.filename} إلى ${recipient.name}: ${safeError(error)}`);
          }
        }
      }
      const cur = this.session(safe);
      cur.lastRun = { at: new Date().toISOString(), type: 'instant', sent, failed };
      this.save(cur);
      return { ok: failed.length === 0, sent, failed };
    } finally {
      this.busy.delete(`send:${safe}`);
    }
  }
  async testRecipient(id, recipientId) {
    const safe = this.store.safeSessionId(id);
    if (this.busy.has(`send:${safe}`)) throw new Error('يوجد إرسال آخر قيد التنفيذ لهذه الجلسة.');
    this.busy.add(`send:${safe}`);
    try {
      const s = this.session(safe);
      const recipient = s.recipients.find(x => x.id === recipientId);
      const image = this.currentImage(safe);
      if (!recipient) throw new Error('المستلم غير موجود.');
      if (!image) throw new Error('لا توجد صورة للاختبار.');
      if (!this.whatsapp.isReady(safe)) throw new Error('الجلسة غير متصلة.');
      await this.sequence(safe, recipient, image, { scheduled: false, preText: 'chat BOT — اختبار', postText: '' });
      return { ok: true, recipient: recipient.name, image: image.filename };
    } finally {
      this.busy.delete(`send:${safe}`);
    }
  }
  skip(id) {
    const s = this.syncCycle(id);
    const count = s.cycle.imageOrder.length;
    if (!count) throw new Error('لا توجد صور.');
    s.cycle.currentIndex = (s.cycle.currentIndex + 1) % count;
    // Keep delivery history so skipped/older images do not get re-sent on the next cycle.
    // Never clear s.cycle.delivery here.
    
    this.save(s);
    return this.currentImage(id);
  }
  reset(id) {
    const s = this.session(id);
    s.cycle.currentIndex = 0;
    // Reset the visible position only; delivery history remains the source of truth for no-duplicates.
    this.save(s);
    return this.currentImage(id);
  }
}

module.exports = { DeliveryService, renderTemplate };
