'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = path.resolve(__dirname, '..');
const DATA_DIR = path.resolve(process.env.BOT_DATA_ROOT || path.join(ROOT, 'data'));
const SESSIONS_DIR = path.join(DATA_DIR, 'sessions');
const GLOBAL_FILE = path.join(DATA_DIR, 'global.json');
const APP_VERSION = '4.0.1';
const WEEKDAYS = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

const DEFAULTS = {
  scheduleEnabled: true,
  timezone: 'Asia/Muscat',
  dayOfWeek: 5,
  hour: 17,
  minute: 30,
  catchUpMinutes: 60,
  retryAttempts: 3,
  retryDelayMs: 2000,
  sendDelayMs: 1000,
  preText: 'chat BOT',
  postText: '',
  maxImageSizeMB: 50,
  browserHeadless: false,
  autoReconnect: true,
  autoStartSession: true,
  interactionEnabled: false,
  interactionScope: 'all',
  maxActionsPerMinute: 12,
  interactionQuietEnabled: false,
  interactionQuietStart: '22:00',
  interactionQuietEnd: '07:00',
  backgroundMode: 'aurora',
  backgroundImage: null,
  backgroundOpacity: 0.34,
  backgroundGlass: false,
  ackObservationMs: 7000,
  uiActionTimeoutMs: 120000,
  interactionCooldownCapSec: 86400,
  sendTimeoutMs: 60000,
  maxInstantPairs: 250,
  requireAck: false
};

function ensureDir(dir) { fs.mkdirSync(dir, { recursive: true }); }
function clone(value) { return JSON.parse(JSON.stringify(value)); }
function normalize(value) { return String(value ?? '').normalize('NFKC').trim(); }
function toInt(value, fallback, min, max) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, Math.trunc(n))) : fallback;
}
function toBool(value, fallback) {
  if (typeof value === 'boolean') return value;
  const s = String(value ?? '').trim().toLowerCase();
  if (['1', 'true', 'yes', 'on'].includes(s)) return true;
  if (['0', 'false', 'no', 'off'].includes(s)) return false;
  return fallback;
}
function safeSessionId(value) {
  const original = normalize(value).toLowerCase();
  const base = original.replace(/[^a-z0-9_-]+/gi, '-').replace(/^-+|-+$/g, '').slice(0, 40);
  if (base) return base;
  if (!original) return 'default';
  const digest = crypto.createHash('sha1').update(original, 'utf8').digest('hex').slice(0, 10);
  return `session-${digest}`;
}
function validTimezone(value) {
  try { new Intl.DateTimeFormat('en-US', { timeZone: value }).format(); return true; } catch { return false; }
}
function atomicWrite(file, value) {
  ensureDir(path.dirname(file));
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2), 'utf8');
  try {
    fs.renameSync(tmp, file);
  } catch (error) {
    try { fs.rmSync(file, { force: true }); } catch {}
    fs.renameSync(tmp, file);
  }
}
function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return clone(fallback); }
}

function defaultRule(id, name) {
  return {
    id: id || crypto.randomUUID(),
    name: normalize(name || 'قاعدة جديدة').slice(0, 80),
    enabled: true,
    when: { type: 'message', match: 'contains', value: 'سلام' },
    then: { reply: 'وعليكم السلام 👋', reaction: '' },
    cooldownSec: 30,
    createdAt: new Date().toISOString()
  };
}
function normalizeRule(item) {
  const base = defaultRule(item?.id, item?.name);
  const when = item?.when || item?.trigger || {};
  const then = item?.then || item?.action || {};
  return {
    ...base,
    name: normalize(item?.name || base.name).slice(0, 80),
    enabled: item?.enabled !== false,
    when: {
      type: when.type === 'reaction' ? 'reaction' : 'message',
      match: ['any', 'contains', 'exact', 'starts', 'ends'].includes(when.match) ? when.match : 'contains',
      value: String(when.value || '').slice(0, 200)
    },
    then: {
      reply: String(then.reply ?? then.replyText ?? '').slice(0, 1500),
      reaction: String(then.reaction ?? '').slice(0, 12)
    },
    cooldownSec: toInt(item?.cooldownSec, 30, 0, 86400),
    priority: toInt(item?.priority, 0, -100, 1000),
    createdAt: item?.createdAt || base.createdAt
  };
}
function normalizeRecipient(item) {
  const kind = item?.kind === 'group' ? 'group' : 'person';
  return {
    id: String(item?.id || crypto.randomUUID()),
    name: normalize(item?.name || '').slice(0, 80),
    kind,
    phone: kind === 'group' ? '' : normalize(item?.phone || '').replace(/^\+/, '').slice(0, 32),
    country: kind === 'group' ? null : (normalize(item?.country || '').slice(0, 4).toUpperCase() || null),
    callingCode: kind === 'group' ? null : (normalize(item?.callingCode || '').slice(0, 8) || null),
    formatted: kind === 'group' ? null : (normalize(item?.formatted || '').slice(0, 64) || null),
    national: kind === 'group' ? null : (normalize(item?.national || '').slice(0, 64) || null),
    chatId: kind === 'group' ? normalize(item?.chatId || '').slice(0, 160) : null,
    enabled: item?.enabled !== false,
    createdAt: item?.createdAt || new Date().toISOString()
  };
}
function normalizeScheduledJob(item) {
  const id = String(item?.id || crypto.randomUUID());
  const status = ['pending','running','done','failed','cancelled'].includes(item?.status) ? item.status : 'pending';
  return {
    id,
    name: normalize(item?.name || 'إرسال مجدول').slice(0, 100),
    enabled: item?.enabled !== false,
    status,
    sendAt: String(item?.sendAt || ''),
    timezone: validTimezone(item?.timezone || 'Asia/Muscat') ? String(item.timezone || 'Asia/Muscat') : 'Asia/Muscat',
    imageId: String(item?.imageId || ''),
    recipientIds: Array.isArray(item?.recipientIds) ? [...new Set(item.recipientIds.map(String))].slice(0, 200) : [],
    preText: String(item?.preText ?? '').trim().slice(0, 1500),
    postText: String(item?.postText ?? '').trim().slice(0, 1500),
    attempts: toInt(item?.attempts, 0, 0, 10),
    maxAttempts: toInt(item?.maxAttempts, 3, 1, 10),
    nextRetryAt: item?.nextRetryAt ? String(item.nextRetryAt) : null,
    lastRunAt: item?.lastRunAt ? String(item.lastRunAt) : null,
    lastError: item?.lastError ? String(item.lastError).slice(0, 500) : null,
    delivery: item?.delivery && typeof item.delivery === 'object' ? item.delivery : {},
    createdAt: item?.createdAt || new Date().toISOString()
  };
}
function defaultSession(id, name) {
  const now = new Date().toISOString();
  return {
    id,
    name: normalize(name || id).slice(0, 80) || id,
    createdAt: now,
    updatedAt: now,
    setupComplete: false,
    recipients: [],
    scheduledJobs: [],
    settings: clone(DEFAULTS),
    interaction: { enabled: false, scope: 'all', rules: [], recent: [] },
    cycle: { imageOrder: [], currentIndex: 0, delivery: {} },
    schedule: { lastSuccessKey: null, lastAttemptKey: null, lastAttemptAt: null, nextRetryAt: null, lastError: null },
    stats: { sentImages: 0, sentMessages: 0, failedSends: 0, successfulRuns: 0, failedRuns: 0, interactionActions: 0, interactionErrors: 0, confirmedAcks: 0, uncertainSends: 0 },
    lastRun: null,
    lastBackup: null,
    logs: []
  };
}
function normalizeSession(input, id) {
  const base = defaultSession(id, id);
  const src = input && typeof input === 'object' ? input : {};
  const out = { ...base, ...src };
  out.id = id;
  out.name = normalize(src.name || id).slice(0, 80) || id;
  out.settings = { ...base.settings, ...(src.settings || {}) };
  out.settings.timezone = validTimezone(out.settings.timezone) ? out.settings.timezone : 'Asia/Muscat';
  out.settings.scheduleEnabled = toBool(out.settings.scheduleEnabled, true);
  out.settings.dayOfWeek = toInt(out.settings.dayOfWeek, 5, 0, 6);
  out.settings.hour = toInt(out.settings.hour, 17, 0, 23);
  out.settings.minute = toInt(out.settings.minute, 30, 0, 59);
  out.settings.catchUpMinutes = toInt(out.settings.catchUpMinutes, 60, 0, 360);
  out.settings.retryAttempts = toInt(out.settings.retryAttempts, 3, 1, 5);
  out.settings.retryDelayMs = toInt(out.settings.retryDelayMs, 2000, 250, 20000);
  out.settings.sendDelayMs = toInt(out.settings.sendDelayMs, 1000, 0, 15000);
  out.settings.maxImageSizeMB = toInt(out.settings.maxImageSizeMB, 50, 1, 100);
  out.settings.browserHeadless = toBool(out.settings.browserHeadless, false);
  out.settings.autoReconnect = toBool(out.settings.autoReconnect, true);
  out.settings.autoStartSession = toBool(out.settings.autoStartSession, true);
  out.settings.interactionEnabled = toBool(out.settings.interactionEnabled, false);
  out.settings.interactionScope = ['all', 'private', 'groups'].includes(out.settings.interactionScope) ? out.settings.interactionScope : 'all';
  out.settings.maxActionsPerMinute = toInt(out.settings.maxActionsPerMinute, 12, 1, 120);
  out.settings.interactionQuietEnabled = toBool(out.settings.interactionQuietEnabled, false);
  out.settings.interactionQuietStart = /^([01]\d|2[0-3]):[0-5]\d$/.test(String(out.settings.interactionQuietStart || '')) ? String(out.settings.interactionQuietStart) : '22:00';
  out.settings.interactionQuietEnd = /^([01]\d|2[0-3]):[0-5]\d$/.test(String(out.settings.interactionQuietEnd || '')) ? String(out.settings.interactionQuietEnd) : '07:00';
  out.settings.backgroundMode = ['aurora','grid','stars','particles','orbits','waves','matrix'].includes(out.settings.backgroundMode) ? out.settings.backgroundMode : 'aurora';
  out.settings.backgroundImage = out.settings.backgroundImage && typeof out.settings.backgroundImage === 'string' ? out.settings.backgroundImage : null;
  out.settings.backgroundOpacity = Math.max(0.05, Math.min(0.8, Number.isFinite(Number(out.settings.backgroundOpacity)) ? Number(out.settings.backgroundOpacity) : 0.34));
  out.settings.backgroundGlass = toBool(out.settings.backgroundGlass, false);
  out.settings.ackObservationMs = toInt(out.settings.ackObservationMs, 7000, 500, 15000);
  out.settings.uiActionTimeoutMs = toInt(out.settings.uiActionTimeoutMs, 120000, 30000, 300000);
  out.settings.interactionCooldownCapSec = toInt(out.settings.interactionCooldownCapSec, 86400, 60, 604800);
  out.settings.sendTimeoutMs = toInt(out.settings.sendTimeoutMs, 60000, 15000, 120000);
  out.settings.maxInstantPairs = toInt(out.settings.maxInstantPairs, 250, 1, 1000);
  out.settings.requireAck = toBool(out.settings.requireAck, false);
  out.settings.preText = String(out.settings.preText ?? 'chat BOT').trim();
  out.settings.postText = String(out.settings.postText ?? '').trim();
  out.recipients = Array.isArray(src.recipients) ? src.recipients.map(normalizeRecipient).filter(r => r.name) : [];
  out.scheduledJobs = Array.isArray(src.scheduledJobs) ? src.scheduledJobs.map(normalizeScheduledJob).slice(-200) : [];
  out.interaction = { ...base.interaction, ...(src.interaction || {}) };
  out.interaction.enabled = toBool(out.interaction.enabled, out.settings.interactionEnabled);
  out.interaction.scope = ['all', 'private', 'groups'].includes(out.interaction.scope) ? out.interaction.scope : out.settings.interactionScope;
  out.interaction.rules = Array.isArray(out.interaction.rules) ? out.interaction.rules.map(normalizeRule).slice(0, 100) : [];
  out.interaction.recent = Array.isArray(out.interaction.recent) ? out.interaction.recent.slice(-200) : [];
  out.cycle = { ...base.cycle, ...(src.cycle || {}) };
  out.cycle.imageOrder = Array.isArray(out.cycle.imageOrder) ? out.cycle.imageOrder.map(String) : [];
  out.cycle.currentIndex = toInt(out.cycle.currentIndex, 0, 0, 1000000);
  out.cycle.delivery = out.cycle.delivery && typeof out.cycle.delivery === 'object' ? out.cycle.delivery : {};
  out.schedule = { ...base.schedule, ...(src.schedule || {}) };
  out.stats = { ...base.stats, ...(src.stats || {}) };
  for (const key of Object.keys(base.stats)) out.stats[key] = Math.max(0, Number.isFinite(Number(out.stats[key])) ? Number(out.stats[key]) : 0);
  out.logs = Array.isArray(out.logs) ? out.logs.slice(-400) : [];
  return out;
}
function sessionDir(id) { return path.join(SESSIONS_DIR, safeSessionId(id)); }
function sessionFile(id) { return path.join(sessionDir(id), 'session.json'); }
function getPaths(id) {
  const dir = sessionDir(id);
  return { dir, file: sessionFile(id), images: path.join(dir, 'images'), uploads: path.join(dir, '_uploads'), backgrounds: path.join(dir, 'backgrounds'), authRoot: path.join(dir, 'auth'), logs: path.join(dir, 'logs'), logFile: path.join(dir, 'logs', 'bot.log'), backups: path.join(dir, 'backups') };
}
function prepareSessionDirs(id) {
  const p = getPaths(id);
  for (const d of [p.dir, p.images, p.uploads, p.backgrounds, p.authRoot, p.logs, p.backups]) ensureDir(d);
  if (!fs.existsSync(p.logFile)) fs.writeFileSync(p.logFile, '', 'utf8');
}
function globalDefault() { return { sessions: [], activeSessionId: null, createdAt: new Date().toISOString() }; }
function loadGlobal() { ensureDir(DATA_DIR); return readJson(GLOBAL_FILE, globalDefault()); }
function saveGlobal(value) { return atomicWrite(GLOBAL_FILE, value); }
function ensureDefault() {
  const global = loadGlobal();
  if (!Array.isArray(global.sessions)) global.sessions = [];
  global.sessions = [...new Set(global.sessions.map(safeSessionId))];
  if (!global.sessions.length) {
    const session = defaultSession('default', 'الجلسة الرئيسية');
    prepareSessionDirs('default');
    atomicWrite(sessionFile('default'), session);
    global.sessions = ['default'];
    global.activeSessionId = 'default';
    saveGlobal(global);
  } else {
    for (const id of global.sessions) {
      prepareSessionDirs(id);
      if (!fs.existsSync(sessionFile(id))) atomicWrite(sessionFile(id), defaultSession(id, id));
    }
    if (!global.activeSessionId || !global.sessions.includes(global.activeSessionId)) {
      global.activeSessionId = global.sessions[0];
      saveGlobal(global);
    }
  }
  return global;
}
function listSessionIds() { return ensureDefault().sessions.slice(); }
function activeSessionId() { return ensureDefault().activeSessionId; }
function assertSession(id) {
  const safe = safeSessionId(id);
  if (!listSessionIds().includes(safe)) throw new Error('الجلسة غير موجودة.');
  return safe;
}
function setActiveSession(id) {
  const safe = assertSession(id);
  const global = ensureDefault();
  global.activeSessionId = safe;
  saveGlobal(global);
  return loadSession(safe);
}
function loadSession(id) {
  const safe = safeSessionId(id);
  prepareSessionDirs(safe);
  return normalizeSession(readJson(sessionFile(safe), defaultSession(safe, safe)), safe);
}
function saveSession(session) {
  const safe = safeSessionId(session.id);
  const normalized = normalizeSession(session, safe);
  normalized.updatedAt = new Date().toISOString();
  atomicWrite(sessionFile(safe), normalized);
  return normalized;
}
function createSession(name) {
  const global = ensureDefault();
  const requestedName = normalize(name || 'جلسة جديدة');
  const base = safeSessionId(requestedName);
  let id = base; let n = 2;
  while (global.sessions.includes(id)) id = `${base}-${n++}`;
  const session = defaultSession(id, requestedName || id);
  prepareSessionDirs(id);
  atomicWrite(sessionFile(id), session);
  global.sessions.push(id);
  global.activeSessionId = id;
  saveGlobal(global);
  return session;
}
function renameSession(id, name) {
  const session = loadSession(assertSession(id));
  session.name = normalize(name).slice(0, 80) || session.id;
  return saveSession(session);
}
function deleteSession(id) {
  const global = ensureDefault();
  const safe = assertSession(id);
  if (global.sessions.length === 1) throw new Error('لا يمكن حذف آخر جلسة.');
  global.sessions = global.sessions.filter(x => x !== safe);
  if (global.activeSessionId === safe) global.activeSessionId = global.sessions[0];
  saveGlobal(global);
  try { fs.rmSync(sessionDir(safe), { recursive: true, force: true }); } catch {}
  return global;
}

ensureDefault();

module.exports = { APP_VERSION, ROOT, DATA_DIR, SESSIONS_DIR, WEEKDAYS, DEFAULTS, clone, normalize, toInt, toBool, safeSessionId, validTimezone, getPaths, defaultRule, normalizeRule, normalizeRecipient, normalizeScheduledJob, prepareSessionDirs, listSessionIds, activeSessionId, assertSession, setActiveSession, loadSession, saveSession, createSession, renameSession, deleteSession };
