'use strict';

function normalize(v) {
  return String(v || '').normalize('NFKC').trim().toLocaleLowerCase('ar');
}
function idText(v) {
  if (!v) return '';
  if (typeof v === 'string') return v;
  if (v._serialized) return String(v._serialized);
  if (v.$1) return String(v.$1);
  if (v.fromMe !== undefined && v.remote && v.id) return `${Boolean(v.fromMe)}_${v.remote}_${v.id}`;
  return String(v.serialized || v.id || '').trim();
}
function chatIdFromReaction(reaction) {
  const key = reaction?.msgId || reaction?.id || {};
  return String(
    reaction?.chatId ||
    key.remote ||
    key.$2 ||
    key._serialized?.split?.('_')?.slice?.(1, -1)?.join?.('_') ||
    ''
  ).trim();
}

function minutesOf(time) {
  const m = String(time || '').match(/^(\d{2}):(\d{2})$/);
  if (!m) return null;
  const h = Number(m[1]); const min = Number(m[2]);
  if (h > 23 || min > 59) return null;
  return h * 60 + min;
}
function quietHoursActive(settings, now = new Date()) {
  if (!settings?.interactionQuietEnabled) return false;
  const start = minutesOf(settings.interactionQuietStart);
  const end = minutesOf(settings.interactionQuietEnd);
  if (start == null || end == null || start === end) return false;
  const parts = new Intl.DateTimeFormat('en-GB', { timeZone: settings.timezone || 'Asia/Muscat', hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(now);
  const hour = Number(parts.find(x => x.type === 'hour')?.value || 0);
  const minute = Number(parts.find(x => x.type === 'minute')?.value || 0);
  const current = hour * 60 + minute;
  return start < end ? current >= start && current < end : current >= start || current < end;
}

function scopeAllowed(scope, chatId) {
  const group = String(chatId).endsWith('@g.us');
  if (scope === 'groups') return group;
  if (scope === 'private') return !group;
  return true;
}
function matchRule(rule, event, text, emoji) {
  if (rule.when.type !== event) return false;
  const input = normalize(event === 'reaction' ? emoji : text);
  const value = normalize(rule.when.value);
  switch (rule.when.match) {
    case 'any': return Boolean(input);
    case 'exact': return Boolean(value) && input === value;
    case 'contains': return Boolean(value) && input.includes(value);
    case 'starts': return Boolean(value) && input.startsWith(value);
    case 'ends': return Boolean(value) && input.endsWith(value);
    default: return false;
  }
}
function validateRule(rule) {
  if (!['message', 'reaction'].includes(rule.when.type)) throw new Error('نوع الحدث غير مدعوم.');
  if (!['any', 'contains', 'exact', 'starts', 'ends'].includes(rule.when.match)) throw new Error('نوع المطابقة غير مدعوم.');
  if (rule.when.match !== 'any' && !String(rule.when.value || '').trim()) throw new Error('اكتب الكلمة التي سيبحث عنها البوت.');
  if (!rule.then.reply && !rule.then.reaction) throw new Error('اختر ردًا أو Reaction.');
  return true;
}
function render(text, ctx, timezone = 'Asia/Muscat') {
  const now = new Date();
  const time = new Intl.DateTimeFormat('ar-OM', { timeZone: timezone, hour: '2-digit', minute: '2-digit' }).format(now);
  return String(text || '')
    .replace(/\{\{message\}\}/gi, String(ctx.message || ''))
    .replace(/\{\{sender\}\}/gi, String(ctx.sender || 'صديق'))
    .replace(/\{\{time\}\}/gi, time)
    .trim();
}

class InteractionEngine {
  constructor({ store, whatsapp, log }) {
    this.store = store;
    this.whatsapp = whatsapp;
    this.log = log;
    this.cooldowns = new Map();
    this.rate = new Map();
    this.seen = new Map();
  }
  rateOk(id, limit) {
    const now = Date.now();
    let bucket = this.rate.get(id);
    if (!bucket || now - bucket.start >= 60000) {
      bucket = { start: now, count: 0 };
      this.rate.set(id, bucket);
    }
    if (bucket.count >= limit) return false;
    bucket.count += 1;
    return true;
  }
  remember(key) {
    this.seen.set(key, Date.now());
    if (this.seen.size <= 5000) return;
    const cutoff = Date.now() - 10 * 60 * 1000;
    for (const [k, t] of this.seen) if (t < cutoff) this.seen.delete(k);
  }
  cleanup() {
    const cutoff = Date.now() - 10 * 60 * 1000;
    for (const [k, t] of this.seen) if (t < cutoff) this.seen.delete(k);
    const coolCutoff = Date.now() - 24 * 60 * 60 * 1000;
    for (const [k, t] of this.cooldowns) if (t < coolCutoff) this.cooldowns.delete(k);
  }
  async handle(id, event, raw) {
    const s = this.store.loadSession(id);
    if (!s.interaction.enabled || !s.settings.interactionEnabled) return;
    if (quietHoursActive(s.settings)) return;

    const chatId = event === 'message' ? String(raw?.from || raw?.chatId || '') : chatIdFromReaction(raw);
    if (!chatId || !scopeAllowed(s.interaction.scope, chatId)) return;
    if (event === 'message' && s.interaction.ignoreOwnMessages !== false && raw?.fromMe) return;

    const text = event === 'message' ? String(raw?.body || '') : '';
    const emoji = event === 'reaction' ? String(raw?.reaction || '') : '';
    const msgId = event === 'message' ? idText(raw?.id) : idText(raw?.msgId || raw?.id);
    const stableId = msgId || `${event}|${chatId}|${String(raw?.timestamp || '')}|${text}|${emoji}`;
    const seenKey = `${event}|${stableId}|${chatId}|${text}|${emoji}`;
    if (this.seen.has(seenKey)) return;
    this.remember(seenKey);

    const rules = [...s.interaction.rules]
      .filter(rule => rule.enabled !== false)
      .sort((a, b) => Number(b.priority || 0) - Number(a.priority || 0));

    for (const rule of rules) {
      if (!matchRule(rule, event, text, emoji)) continue;
      const cooldownKey = `${id}|${rule.id}|${chatId}`;
      const previous = this.cooldowns.get(cooldownKey) || 0;
      if (Date.now() - previous < rule.cooldownSec * 1000) continue;
      if (!this.rateOk(id, s.settings.maxActionsPerMinute)) return;

      try {
        validateRule(rule);
        const sender = String(raw?.notifyName || raw?._data?.notifyName || 'صديق');
        const reply = render(rule.then.reply, { message: text, sender }, s.settings.timezone);
        if (reply) {
          if (event === 'message' && raw && typeof this.whatsapp.replyToMessage === 'function') {
            await this.whatsapp.replyToMessage(id, raw, reply);
          } else {
            await this.whatsapp.sendText(id, chatId, reply, event === 'message' ? { quotedMessageId: raw?.id } : {});
          }
        }
        if (rule.then.reaction && msgId) {
          if (event === 'message' && raw && typeof this.whatsapp.reactToMessage === 'function') await this.whatsapp.reactToMessage(id, raw, rule.then.reaction);
          else await this.whatsapp.sendReaction(id, msgId, rule.then.reaction);
        }
        this.cooldowns.set(cooldownKey, Date.now());
        const current = this.store.loadSession(id);
        current.interaction.recent = [...current.interaction.recent, {
          at: new Date().toISOString(), event, ruleId: rule.id, status: 'success', chatId,
          text: text.slice(0, 250), emoji
        }].slice(-200);
        current.stats.interactionActions += 1;
        this.store.saveSession(current);
      } catch (error) {
        const current = this.store.loadSession(id);
        current.interaction.recent = [...current.interaction.recent, {
          at: new Date().toISOString(), event, ruleId: rule.id, status: 'error', chatId,
          detail: String(error.message || error)
        }].slice(-200);
        current.stats.interactionErrors += 1;
        this.store.saveSession(current);
        this.log(id, 'ERROR', `فشل التفاعل «${rule.name}»: ${error.message || error}`);
      }
      break;
    }
    this.cleanup();
  }
  onMessage(id, message) { return this.handle(id, 'message', message); }
  onReaction(id, reaction) { return this.handle(id, 'reaction', reaction); }
}

module.exports = { InteractionEngine, matchRule, validateRule, idText, chatIdFromReaction, quietHoursActive, minutesOf };
