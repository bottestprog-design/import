'use strict';

function localParts(date, timezone) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: timezone,
    weekday: 'short', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  }).formatToParts(date);
  const get = type => parts.find(p => p.type === type)?.value;
  const weekdayMap = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  let hour = Number(get('hour'));
  if (hour === 24) hour = 0;
  return { year:Number(get('year')), month:Number(get('month')), day:Number(get('day')), weekday:weekdayMap[get('weekday')], hour, minute:Number(get('minute')), second:Number(get('second')) };
}

function keyFor(date, session) {
  const p = localParts(date, session.settings.timezone);
  return `${p.year}-${String(p.month).padStart(2,'0')}-${String(p.day).padStart(2,'0')} ${String(session.settings.hour).padStart(2,'0')}:${String(session.settings.minute).padStart(2,'0')}`;
}

function due(date, session) {
  if (!session?.settings?.scheduleEnabled) return { due:false, key:null, late:0 };
  const p = localParts(date, session.settings.timezone);
  if (p.weekday !== Number(session.settings.dayOfWeek)) return { due:false, key:null, late:0 };
  const nowMinutes = p.hour * 60 + p.minute + p.second / 60;
  const targetMinutes = Number(session.settings.hour) * 60 + Number(session.settings.minute);
  const late = nowMinutes - targetMinutes;
  const grace = Math.max(0, Number(session.settings.catchUpMinutes) || 0);
  const withinWindow = late >= 0 && late <= grace;
  return { due:withinWindow, key:withinWindow ? keyFor(date,session) : null, late:Math.max(0,late) };
}

function nextRun(session, from = new Date()) {
  if (!session?.settings?.scheduleEnabled) return null;
  const start = new Date(Math.floor(from.getTime()/60000)*60000 + 60000);
  const horizon = 15 * 24 * 60;
  for (let i=0;i<horizon;i++) {
    const d = new Date(start.getTime() + i*60000);
    const p = localParts(d, session.settings.timezone);
    if (p.weekday === Number(session.settings.dayOfWeek) && p.hour === Number(session.settings.hour) && p.minute === Number(session.settings.minute)) return d.toISOString();
  }
  return null;
}

function nextScheduledJob(session, from = new Date()) {
  const jobs = Array.isArray(session?.scheduledJobs) ? session.scheduledJobs : [];
  let best = null;
  for (const job of jobs) {
    if (!job?.enabled || ['done','cancelled'].includes(job.status)) continue;
    const retryMs = job.nextRetryAt ? Date.parse(job.nextRetryAt) : NaN;
    const runMs = Number.isFinite(retryMs) && retryMs > from.getTime() ? retryMs : Date.parse(job.sendAt);
    if (!Number.isFinite(runMs)) continue;
    if (runMs <= from.getTime()) continue;
    if (!best || runMs < best.ms) best = { ...job, ms:runMs };
  }
  return best ? { ...best, at:new Date(best.ms).toISOString() } : null;
}

class ReliableScheduler {
  constructor({store, ids, run, log}) {
    this.store=store; this.ids=ids; this.run=run; this.log=log;
    this.watchdog=null; this.timers=new Map(); this.busy=new Set(); this.started=false; this.lastTick=null;
  }
  start() {
    if (this.started) return;
    this.started=true;
    this.watchdog=setInterval(()=>this.tick().catch(e=>this.log(null,'ERROR',`خطأ في مراقبة الجدولة: ${e.message||e}`)),1000);
    this.armAll();
    this.tick().catch(e=>this.log(null,'ERROR',`فحص الجدولة الأولي: ${e.message||e}`));
  }
  stop() {
    if (this.watchdog) clearInterval(this.watchdog);
    this.watchdog=null;
    for (const t of this.timers.values()) clearTimeout(t);
    this.timers.clear(); this.started=false;
  }
  armAll(){ for (const id of this.ids()) this.arm(id); }
  nextEvent(session, now = new Date()) {
    const weekly=nextRun(session, now);
    const job=nextScheduledJob(session, now);
    if (!weekly && !job) return null;
    if (!weekly) return {kind:'job', at:job.at, jobId:job.id};
    if (!job) return {kind:'weekly', at:weekly};
    return Date.parse(job.at) < Date.parse(weekly) ? {kind:'job',at:job.at,jobId:job.id} : {kind:'weekly',at:weekly};
  }
  arm(id) {
    if (!this.started) return;
    const safe=this.store.safeSessionId(id);
    const old=this.timers.get(safe); if(old) clearTimeout(old);
    const session=this.store.loadSession(safe);
    const event=this.nextEvent(session,new Date());
    if (!event) return;
    const delay=Math.max(250,Math.min(Date.parse(event.at)-Date.now(),2147483647));
    const timer=setTimeout(async()=>{
      this.timers.delete(safe);
      try { await this.tick(new Date()); } catch(e) { this.log(safe,'ERROR',`خطأ تشغيل الموعد: ${e.message||e}`); }
      finally { this.arm(safe); }
    },delay);
    this.timers.set(safe,timer);
  }
  wake(id){ this.arm(id); this.tick(new Date()).catch(e=>this.log(null,'ERROR',`فحص فوري للجدولة: ${e.message||e}`)); }
  wakeAll(){ this.armAll(); this.tick(new Date()).catch(e=>this.log(null,'ERROR',`فحص فوري شامل للجدولة: ${e.message||e}`)); }
  cancel(id){const safe=this.store.safeSessionId(id);const t=this.timers.get(safe);if(t)clearTimeout(t);this.timers.delete(safe);this.busy.delete(safe);}

  async tick(now=new Date()) {
    if(!this.started) return;
    this.lastTick=now.toISOString();
    for(const id of this.ids()) {
      const safe=this.store.safeSessionId(id);
      if(this.busy.has(safe)) continue;
      const s=this.store.loadSession(safe);

      const exact = Array.isArray(s.scheduledJobs) ? s.scheduledJobs.find(job => {
        if (!job?.enabled || ['done','cancelled'].includes(job.status)) return false;
        const retryAt=job.nextRetryAt?Date.parse(job.nextRetryAt):NaN;
        if(Number.isFinite(retryAt) && now.getTime() >= retryAt) return true;
        const sendAt=Date.parse(job.sendAt);
        return Number.isFinite(sendAt) && now.getTime() >= sendAt;
      }) : null;
      if(exact) {
        await this.runExact(safe, exact.id, now);
        continue;
      }

      if(!s.settings.scheduleEnabled) continue;
      const d=due(now,s);
      const retryKey=s.schedule.lastAttemptKey && s.schedule.lastSuccessKey!==s.schedule.lastAttemptKey ? s.schedule.lastAttemptKey : null;
      const retryAt=s.schedule.nextRetryAt?Date.parse(s.schedule.nextRetryAt):NaN;
      const retryAge=s.schedule.lastAttemptAt?now.getTime()-Date.parse(s.schedule.lastAttemptAt):Infinity;
      const retryDue=Boolean(retryKey)&&Number.isFinite(retryAt)&&now.getTime()>=retryAt&&retryAge>=0&&retryAge<=24*60*60*1000;
      const runKey=d.due&&d.key?d.key:(retryDue?retryKey:null);
      if(!runKey) continue;
      if(s.schedule.lastSuccessKey===runKey) continue;
      if(s.schedule.lastAttemptKey===runKey && s.schedule.nextRetryAt && now.getTime()<retryAt) continue;
      await this.runWeekly(safe,runKey,retryDue,now);
    }
  }

  async runWeekly(safeId,runKey,retryDue,now) {
    this.busy.add(safeId);
    const current=this.store.loadSession(safeId);
    current.schedule.lastAttemptKey=runKey; current.schedule.lastAttemptAt=now.toISOString(); current.schedule.nextRetryAt=null; this.store.saveSession(current);
    this.log(safeId,'INFO',`${retryDue?'إعادة محاولة':'وصل موعد'} الجدولة ${runKey}. بدأ الإرسال تلقائيًا.`);
    try {
      const result=await this.run(safeId,{kind:'weekly',key:runKey});
      const after=this.store.loadSession(safeId);
      if(result?.ok){after.schedule.lastSuccessKey=runKey;after.schedule.lastError=null;after.schedule.nextRetryAt=null;this.log(safeId,'INFO',`اكتمل الإرسال المجدول للموعد ${runKey}.`);}
      else if(result?.retry===false){after.schedule.lastError=String(result?.message||'لم يكتمل الإرسال.').slice(0,500);after.schedule.nextRetryAt=null;this.log(safeId,'WARN',`لن تتم إعادة المحاولة الآن: ${after.schedule.lastError}`);}
      else {after.schedule.lastError=String(result?.message||'لم يكتمل الإرسال.').slice(0,500);after.schedule.nextRetryAt=new Date(Date.now()+Math.max(5000,Number(after.settings.retryDelayMs)||5000)).toISOString();this.log(safeId,'WARN',`لم يكتمل الإرسال المجدول: ${after.schedule.lastError}`);}
      this.store.saveSession(after);
    } catch(e){const after=this.store.loadSession(safeId);after.schedule.lastError=String(e?.message||e).slice(0,500);after.schedule.nextRetryAt=new Date(Date.now()+Math.max(5000,Number(after.settings.retryDelayMs)||5000)).toISOString();this.store.saveSession(after);this.log(safeId,'ERROR',`فشل الإرسال المجدول: ${after.schedule.lastError}`);}
    finally{this.busy.delete(safeId);this.arm(safeId);}
  }

  async runExact(safeId,jobId,now) {
    this.busy.add(safeId);
    let job=this.store.loadSession(safeId).scheduledJobs.find(x=>x.id===jobId);
    if(!job){this.busy.delete(safeId);return;}
    if(job.status==='done'||job.status==='cancelled'){this.busy.delete(safeId);return;}
    const s=this.store.loadSession(safeId);
    job={...job,status:'running',attempts:Number(job.attempts||0)+1,lastRunAt:now.toISOString(),nextRetryAt:null};
    s.scheduledJobs=s.scheduledJobs.map(x=>x.id===job.id?job:x); this.store.saveSession(s);
    this.log(safeId,'INFO',`حان موعد الإرسال الخاص «${job.name}».`);
    try{
      const result=await this.run(safeId,{kind:'job',jobId:job.id});
      const after=this.store.loadSession(safeId);
      const latest=after.scheduledJobs.find(x=>x.id===job.id);
      if(!latest){this.busy.delete(safeId);return;}
      if(result?.ok){latest.status='done';latest.lastError=null;latest.nextRetryAt=null;this.log(safeId,'INFO',`اكتمل الإرسال الخاص «${latest.name}».`);}
      else if(latest.attempts>=latest.maxAttempts || result?.retry===false){latest.status='failed';latest.lastError=String(result?.message||'تعذر الإرسال.').slice(0,500);latest.nextRetryAt=null;this.log(safeId,'ERROR',`فشل الإرسال الخاص «${latest.name}»: ${latest.lastError}`);}
      else {latest.status='pending';latest.lastError=String(result?.message||'سيعاد الإرسال.').slice(0,500);latest.nextRetryAt=new Date(Date.now()+Math.max(5000,Number(after.settings.retryDelayMs)||5000)).toISOString();this.log(safeId,'WARN',`إعادة محاولة الإرسال الخاص «${latest.name}».`);}
      this.store.saveSession(after);
    } catch(e){
      const after=this.store.loadSession(safeId); const latest=after.scheduledJobs.find(x=>x.id===job.id);
      if(latest){latest.lastError=String(e?.message||e).slice(0,500);if(latest.attempts>=latest.maxAttempts){latest.status='failed';latest.nextRetryAt=null;}else{latest.status='pending';latest.nextRetryAt=new Date(Date.now()+Math.max(5000,Number(after.settings.retryDelayMs)||5000)).toISOString();}this.store.saveSession(after);}
      this.log(safeId,'ERROR',`فشل الإرسال الخاص: ${e?.message||e}`);
    } finally { this.busy.delete(safeId); this.arm(safeId); }
  }

  status(session){return {alive:this.started,nextRun:nextRun(session),nextJob:nextScheduledJob(session),lastTick:this.lastTick,lastAttempt:session.schedule.lastAttemptAt,lastSuccess:session.schedule.lastSuccessKey,lastError:session.schedule.lastError||null,nextRetryAt:session.schedule.nextRetryAt||null,armed:Boolean(this.timers.get(session.id))};}
}

module.exports={ReliableScheduler,localParts,due,nextRun,keyFor,nextScheduledJob};
