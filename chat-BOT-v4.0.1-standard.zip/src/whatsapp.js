'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { EventEmitter } = require('node:events');
const { applyPatch } = require('../scripts/patch-whatsapp');
const phones = require('./phones');
const patchResult = applyPatch();
if (!patchResult.ok) throw new Error(`WhatsApp compatibility patch failed: ${patchResult.errors.join('; ')}`);

const QRCode = require('qrcode');
const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');

function sleep(ms) { return new Promise(resolve => setTimeout(resolve, Math.max(0, Number(ms) || 0))); }
function withTimeout(promise, timeoutMs, label = 'العملية') {
  const ms = Math.max(1000, Number(timeoutMs) || 60000);
  let timer;
  return Promise.race([
    promise,
    new Promise((_, reject) => { timer = setTimeout(() => reject(Object.assign(new Error(`${label} تجاوز مهلة ${Math.round(ms / 1000)} ثانية.`), { code: 'SEND_TIMEOUT' })), ms); })
  ]).finally(() => clearTimeout(timer));
}
function safeError(error) { return String(error?.message || error || 'خطأ غير معروف'); }
function normalizeDigits(value) {
  return String(value || '')
    .replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
}
function normalizePhone(value, country = 'OM') {
  try { return phones.parse(value, country || 'OM').digits; }
  catch { return normalizeDigits(value).replace(/\D/g, ''); }
}
function serializedId(value) {
  if (!value) return '';
  if (typeof value === 'string') return value;
  const direct = value._serialized || value.$1 || value.serialized || value.id;
  if (direct) return String(direct).trim();
  if (value.fromMe !== undefined && value.remote && value.id) {
    return `${Boolean(value.fromMe)}_${value.remote}_${value.id}`;
  }
  return '';
}
function normalizeMessageObject(message) {
  try {
    if (message?.id && !message.id._serialized && message.id.$1) message.id._serialized = message.id.$1;
    if (message?._data?.id && !message._data.id._serialized && message._data.id.$1) message._data.id._serialized = message._data.id.$1;
  } catch {}
  return message;
}
function normalizeReactionObject(reaction) {
  try {
    const ids = [reaction?.id, reaction?.msgId];
    for (const obj of ids) {
      if (obj && !obj._serialized && obj.$1) obj._serialized = obj.$1;
      if (obj && !obj._serialized && obj.fromMe !== undefined && obj.remote && obj.id) obj._serialized = `${Boolean(obj.fromMe)}_${obj.remote}_${obj.id}`;
    }
  } catch {}
  return reaction;
}
function browserCandidates() {
  if (process.platform === 'win32') {
    const local = process.env.LOCALAPPDATA || '';
    const pf = process.env.PROGRAMFILES || 'C:\\Program Files';
    const pfx = process.env['PROGRAMFILES(X86)'] || 'C:\\Program Files (x86)';
    return [
      path.join(local, 'Google', 'Chrome', 'Application', 'chrome.exe'),
      path.join(pf, 'Google', 'Chrome', 'Application', 'chrome.exe'),
      path.join(pfx, 'Google', 'Chrome', 'Application', 'chrome.exe'),
      path.join(local, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
      path.join(pf, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
      path.join(pfx, 'Microsoft', 'Edge', 'Application', 'msedge.exe')
    ];
  }
  if (process.platform === 'darwin') return ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge'];
  return ['/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge'];
}
function browserExecutable() {
  const explicit = String(process.env.PUPPETEER_EXECUTABLE_PATH || '').trim();
  if (explicit && fs.existsSync(explicit)) return explicit;
  return browserCandidates().find(x => fs.existsSync(x)) || null;
}

class WhatsAppManager extends EventEmitter {
  constructor({ store, log }) {
    super();
    this.store = store;
    this.log = log;
    this.items = new Map();
    this.shuttingDown = false;
  }
  runtime(id) {
    const safe = this.store.safeSessionId(id);
    if (!this.items.has(safe)) this.items.set(safe, {
      client: null, qr: null, status: 'stopped', browser: null,
      reconnectTimer: null, reconnectAttempts: 0, generation: 0,
      startPromise: null, stopPromise: null, intentionalStop: false,
      queue: Promise.resolve(), lastEvent: null, lastReadyAt: null,
      lastDisconnect: null, messageEvents: 0, reactionEvents: 0,
      ackEvents: 0, pendingAcks: new Map(), lastAck: null, ackHistory: [], lastSent: null,
      chatCache: new Map()
    });
    return this.items.get(safe);
  }
  listRuntime(id) {
    const r = this.runtime(id);
    return {
      status: r.status,
      ready: Boolean(r.client && r.status === 'ready'),
      qr: r.qr,
      browser: r.browser,
      reconnectAttempts: r.reconnectAttempts,
      lastEvent: r.lastEvent,
      lastReadyAt: r.lastReadyAt,
      lastDisconnect: r.lastDisconnect,
      messageEvents: r.messageEvents,
      reactionEvents: r.reactionEvents,
      ackEvents: r.ackEvents,
      lastAck: r.lastAck,
      ackHistory: r.ackHistory.slice(-12),
      lastSent: r.lastSent
    };
  }
  isReady(id) { return this.listRuntime(id).ready; }
  hasSavedAuth(id) {
    const p = this.store.getPaths(id).authRoot;
    try { return fs.existsSync(p) && fs.readdirSync(p).some(x => x.startsWith('session-')); } catch { return false; }
  }
  async start(id) {
    const safe = this.store.safeSessionId(id);
    const r = this.runtime(safe);
    if (r.startPromise) return r.startPromise;
    if (r.stopPromise) await r.stopPromise;
    if (r.client) return this.listRuntime(safe);
    if (this.shuttingDown) throw new Error('البوت في وضع الإيقاف.');

    r.startPromise = (async () => {
      const session = this.store.loadSession(safe);
      const browser = browserExecutable();
      if (!browser) throw new Error('لم يتم العثور على Google Chrome أو Microsoft Edge المثبت على الجهاز.');
      r.intentionalStop = false;
      r.chatCache.clear();
      r.status = 'starting';
      r.qr = null;
      r.browser = browser;
      r.generation += 1;
      const generation = r.generation;
      const auth = new LocalAuth({
        dataPath: this.store.getPaths(safe).authRoot,
        clientId: this.store.safeSessionId(safe),
        rmMaxRetries: 12
      });
      const client = new Client({
        authStrategy: auth,
        takeoverOnConflict: false,
        takeoverTimeoutMs: 5000,
        authTimeoutMs: 120000,
        qrMaxRetries: 6,
        webVersionCache: { type: 'none' },
        puppeteer: {
          headless: session.settings.browserHeadless,
          executablePath: browser,
          protocolTimeout: 120000,
          args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-background-networking',
            '--disable-renderer-backgrounding'
          ]
        }
      });
      r.client = client;
      const current = () => r.client === client && r.generation === generation;
      const event = (name, data = null) => { if (current()) r.lastEvent = { name, data, at: new Date().toISOString() }; };

      client.on('qr', qr => {
        if (!current()) return;
        r.status = 'qr';
        r.qr = null;
        QRCode.toDataURL(qr, { width: 320, margin: 1 }).then(data => {
          if (current()) r.qr = data;
        }).catch(error => this.log(safe, 'WARN', `تعذر إنشاء QR: ${safeError(error)}`));
        event('qr');
        this.log(safe, 'INFO', 'QR جاهز. افتح الجلسة وامسح الرمز من WhatsApp > الأجهزة المرتبطة.');
      });
      client.on('authenticated', () => {
        if (!current()) return;
        r.status = 'authenticated';
        r.qr = null;
        r.reconnectAttempts = 0;
        event('authenticated');
        this.log(safe, 'INFO', 'تمت مصادقة جلسة WhatsApp.');
      });
      client.on('ready', () => {
        if (!current()) return;
        r.status = 'ready';
        r.qr = null;
        r.reconnectAttempts = 0;
        r.lastReadyAt = new Date().toISOString();
        event('ready');
        this.log(safe, 'INFO', 'جلسة WhatsApp جاهزة للإرسال والاستقبال.');
      });
      client.on('auth_failure', message => {
        if (!current()) return;
        r.status = 'auth_failure';
        r.client = null;
        Promise.resolve(client.destroy()).catch(error => this.log(safe, 'WARN', `تعذر تنظيف جلسة المصادقة الفاشلة: ${safeError(error)}`));
        event('auth_failure', String(message));
        this.log(safe, 'ERROR', `فشل المصادقة: ${message}`);
      });
      client.on('disconnected', reason => {
        if (!current()) return;
        const why = String(reason || 'UNKNOWN');
        r.status = why === 'LOGOUT' ? 'logged_out' : 'disconnected';
        r.qr = null;
        r.lastDisconnect = { reason: why, at: new Date().toISOString() };
        r.chatCache.clear();
        r.client = null;
        event('disconnected', why);
        this.log(safe, 'WARN', `انفصلت الجلسة: ${why}`);
        if (!r.intentionalStop && why !== 'LOGOUT' && this.store.loadSession(safe).settings.autoReconnect) this.scheduleReconnect(safe);
      });
      client.on('change_state', state => {
        if (current()) event('state', String(state));
      });
      client.on('message_ack', (message, ack) => {
        if (!current()) return;
        r.ackEvents += 1;
        const id = serializedId(message?.id);
        r.lastAck = { id, ack: Number(ack), at: new Date().toISOString() };
        r.ackHistory.push(r.lastAck);
        r.ackHistory = r.ackHistory.slice(-50);
        const waiter = id ? r.pendingAcks.get(id) : null;
        if (waiter) {
          r.pendingAcks.delete(id);
          waiter(Number(ack));
        }
      });
      client.on('message', message => {
        if (!current()) return;
        r.messageEvents += 1;
        this.emit('message', safe, normalizeMessageObject(message));
      });
      client.on('message_create', message => {
        if (!current() || message?.fromMe) return;
        // Some WhatsApp Web builds surface inbound messages through message_create.
        // InteractionEngine de-duplicates using the message id before replying.
        r.messageEvents += 1;
        this.emit('message', safe, normalizeMessageObject(message));
      });
      client.on('message_reaction', reaction => {
        if (!current()) return;
        r.reactionEvents += 1;
        this.emit('reaction', safe, normalizeReactionObject(reaction));
      });
      await client.initialize();
      return this.listRuntime(safe);
    })().catch(error => {
      r.status = 'error';
      r.client = null;
      this.log(safe, 'ERROR', `فشل تشغيل WhatsApp: ${safeError(error)}`);
      throw error;
    }).finally(() => {
      r.startPromise = null;
    });
    return r.startPromise;
  }
  scheduleReconnect(id) {
    const safe = this.store.safeSessionId(id);
    const r = this.runtime(safe);
    if (r.reconnectTimer || r.intentionalStop || this.shuttingDown) return;
    r.reconnectAttempts = Math.min(r.reconnectAttempts + 1, 8);
    const delay = Math.min(5000 * Math.pow(2, Math.max(0, r.reconnectAttempts - 1)), 120000);
    this.log(safe, 'WARN', `ستتم محاولة إعادة الاتصال بعد ${Math.ceil(delay / 1000)} ثانية.`);
    r.reconnectTimer = setTimeout(async () => {
      r.reconnectTimer = null;
      if (r.intentionalStop || this.shuttingDown) return;
      try {
        await this.stop(safe);
        await sleep(1500);
        await this.start(safe);
      } catch (error) {
        this.log(safe, 'ERROR', `فشلت إعادة الاتصال: ${safeError(error)}`);
        this.scheduleReconnect(safe);
      }
    }, delay);
  }
  async stop(id, { clearAuth = false } = {}) {
    const safe = this.store.safeSessionId(id);
    const r = this.runtime(safe);
    if (r.stopPromise) return r.stopPromise;
    r.stopPromise = (async () => {
      r.intentionalStop = true;
      if (r.reconnectTimer) clearTimeout(r.reconnectTimer);
      r.reconnectTimer = null;
      const client = r.client;
      for (const done of r.pendingAcks.values()) { try { done(-1); } catch {} }
      r.pendingAcks.clear();
      r.chatCache.clear();
      r.client = null;
      r.qr = null;
      r.status = 'stopping';
      r.generation += 1;
      if (client) {
        try { await client.destroy(); }
        catch (error) { this.log(safe, 'WARN', `تعذر إغلاق متصفح WhatsApp بصورة فورية: ${safeError(error)}`); }
      }
      if (clearAuth) {
        const authRoot = this.store.getPaths(safe).authRoot;
        let removed = false;
        let lastError = null;
        for (let attempt = 0; attempt < 3 && !removed; attempt += 1) {
          try {
            await fs.promises.rm(authRoot, { recursive: true, force: true, maxRetries: 12, retryDelay: 750 });
            removed = !fs.existsSync(authRoot);
            if (!removed) await sleep(750);
          } catch (error) {
            lastError = error;
            await sleep(750);
          }
        }
        if (!removed) {
          const detail = lastError ? `: ${safeError(lastError)}` : '';
          this.log(safe, 'WARN', `تعذر حذف ربط الجلسة الآن${detail}`);
        }
      }
      r.status = 'stopped';
      this.log(safe, 'INFO', clearAuth ? 'تم حذف ربط الجلسة المحلي.' : 'تم إيقاف جلسة WhatsApp.');
    })().finally(() => { r.stopPromise = null; });
    return r.stopPromise;
  }
  async ensureReady(id) {
    const safe = this.store.safeSessionId(id);
    if (this.isReady(safe)) return true;
    if (!this.hasSavedAuth(safe)) throw new Error('الجلسة غير مرتبطة بواتساب. افتح صفحة الجلسات واضغط «ربط الجلسة».');
    await this.start(safe);
    const started = Date.now();
    while (Date.now() - started < 60000) {
      if (this.isReady(safe)) return true;
      const status = this.runtime(safe).status;
      if (status === 'error' || status === 'logged_out' || status === 'auth_failure') break;
      await sleep(250);
    }
    throw new Error('لم تصبح جلسة WhatsApp جاهزة خلال المهلة. تحقق من المتصفح وحالة الجلسة.');
  }
  enqueue(id, task, label) {
    const safe = this.store.safeSessionId(id);
    const r = this.runtime(safe);
    const next = r.queue.then(task);
    r.queue = next.catch(() => undefined);
    return next.catch(error => {
      this.log(safe, 'ERROR', `${label}: ${safeError(error)}`);
      throw error;
    });
  }
  async resolveChatId(id, recipient) {
    const safe = this.store.safeSessionId(id);
    await this.ensureReady(safe);
    const r = this.runtime(safe);
    const client = r.client;
    if (!client) throw new Error('جلسة WhatsApp غير جاهزة.');

    if (recipient?.kind === 'group' || String(recipient?.chatId || '').endsWith('@g.us')) {
      const groupId = String(recipient?.chatId || '').trim();
      if (!/^\d[\d-]+@g\.us$/i.test(groupId)) throw Object.assign(new Error('معرف المجموعة غير صالح. استخدم مثل 120363012345678901@g.us'), { code:'INVALID_GROUP_ID' });
      try {
        const chat = await withTimeout(client.getChatById(groupId), 12000, 'التحقق من المجموعة');
        if (chat && chat.isGroup === false) throw new Error('المعرف لا يشير إلى مجموعة WhatsApp.');
      } catch (error) {
        if (String(error?.message || '').includes('لا يشير')) throw error;
        this.log(safe, 'WARN', `تعذر قراءة المجموعة مباشرة، سيتم استخدام المعرف كما هو: ${safeError(error)}`);
      }
      return groupId;
    }

    const stored = String(recipient?.phone || '').trim();
    let parsed;
    try { parsed = phones.parse(stored, recipient?.country || 'OM'); }
    catch { parsed = phones.parse(normalizeDigits(stored), recipient?.country || 'OM'); }
    const phone = parsed.digits;
    if (phone.length < 8) throw Object.assign(new Error(`رقم المستلم «${recipient?.name || ''}» غير صالح.`), { code:'INVALID_PHONE' });

    const cached = r.chatCache.get(phone);
    if (cached?.expiresAt > Date.now()) return cached.chatId;
    if (cached) r.chatCache.delete(phone);

    try {
      const numberId = await withTimeout(client.getNumberId(phone), 15000, 'التحقق من الرقم');
      const resolved = serializedId(numberId);
      if (resolved) {
        r.chatCache.set(phone,{chatId:resolved,expiresAt:Date.now()+6*60*60*1000});
        return resolved;
      }
    } catch {}

    try {
      const registered = await withTimeout(client.isRegisteredUser(phone), 15000, 'فحص الرقم');
      if (registered === false) throw Object.assign(new Error(`الرقم ${recipient.phone} غير مسجل على WhatsApp.`), { code:'NOT_REGISTERED' });
    } catch (error) {
      if (error?.code === 'NOT_REGISTERED') throw error;
      this.log(safe,'WARN',`تعذر التحقق الكامل من ${recipient?.name || phone}: ${safeError(error)}`);
    }

    const fallback = `${phone}@c.us`;
    r.chatCache.set(phone,{chatId:fallback,expiresAt:Date.now()+15*60*1000});
    return fallback;
  }

  async observeAck(id, message, ms) {
    const safe = this.store.safeSessionId(id);
    const r = this.runtime(safe);
    const mid = serializedId(message?.id || message);
    const requested = Math.max(500, Number(ms) || 7000);
    if (!mid) return { status: 'not_observed', ack: null };
    const initialAck = Number(message?.ack);
    if (Number.isFinite(initialAck) && initialAck >= 1) return { status: 'confirmed', ack: initialAck };
    if (Number.isFinite(initialAck) && initialAck < 0) return { status: 'error', ack: initialAck };
    const cached = r.ackHistory.findLast?.(item => item.id === mid && Number(item.ack) >= 1);
    if (cached) return { status: 'confirmed', ack: Number(cached.ack) };

    const wait = new Promise(resolve => {
      let timer;
      const done = ack => {
        clearTimeout(timer);
        r.pendingAcks.delete(mid);
        const value = Number(ack);
        resolve({ status: value >= 1 ? 'confirmed' : 'error', ack: value });
      };
      r.pendingAcks.set(mid, done);
      timer = setTimeout(() => {
        r.pendingAcks.delete(mid);
        resolve({ status: 'pending', ack: null });
      }, requested);
    });
    const observed = await wait;
    if (observed.status !== 'pending') return observed;

    const client = this.runtime(safe).client;
    if (client?.getMessageById) {
      for (let i = 0; i < 3; i += 1) {
        await sleep(350);
        try {
          const latest = await withTimeout(client.getMessageById(mid), 7000, 'التحقق من حالة الرسالة');
          const latestAck = Number(latest?.ack);
          if (Number.isFinite(latestAck) && latestAck >= 1) return { status: 'confirmed', ack: latestAck };
          if (Number.isFinite(latestAck) && latestAck < 0) return { status: 'error', ack: latestAck };
        } catch {}
      }
    }
    return { status: 'pending', ack: null };
  }
  async sendText(id, chatId, text, { quotedMessageId = null } = {}) {
    const safe = this.store.safeSessionId(id);
    const body = String(text || '').trim();
    if (!body) return null;
    await this.ensureReady(safe);
    return this.enqueue(safe, async () => {
      const session = this.store.loadSession(safe);
      const client = this.runtime(safe).client;
      if (!client || !this.isReady(safe)) throw Object.assign(new Error('جلسة WhatsApp غير جاهزة أثناء الإرسال.'), { code: 'SEND_NOT_READY' });
      const timeout = session.settings.sendTimeoutMs;
      const options = { sendSeen: false, waitUntilMsgSent: false, ignoreQuoteErrors: true };
      const quote = serializedId(quotedMessageId);
      if (quote) options.quotedMessageId = quote;
      let result;
      try {
        result = await withTimeout(client.sendMessage(chatId, body, options), timeout, 'إرسال الرسالة');
      } catch (error) {
        if (quote && this.isReady(safe)) {
          this.log(safe, 'WARN', `تعذر إرسال الرد المقتبس؛ سيتم إرسال الرد بدون اقتباس: ${safeError(error)}`);
          const fallback = { sendSeen: false, waitUntilMsgSent: false, ignoreQuoteErrors: true };
          result = await withTimeout(client.sendMessage(chatId, body, fallback), timeout, 'إرسال الرسالة');
        } else {
          throw error;
        }
      }
      if (!result) throw new Error('WhatsApp لم ينشئ الرسالة.');
      const mid = serializedId(result.id);
      const ack = await this.observeAck(safe, result, session.settings.ackObservationMs);
      Object.defineProperty(result, '__chatBotAck', { value: ack, enumerable: false, configurable: true });
      if (ack.status === 'error') throw Object.assign(new Error('تم إنشاء الرسالة لكن WhatsApp أعلن فشل الإرسال.'), { code: 'SEND_ACK_ERROR' });
      this.runtime(safe).lastSent = { id: mid, kind: 'text', ack, at: new Date().toISOString() };
      return result;
    }, 'الرسالة');
  }
  async sendMedia(id, chatId, filePath) {
    const safe = this.store.safeSessionId(id);
    await this.ensureReady(safe);
    const session = this.store.loadSession(safe);
    const stat = fs.statSync(filePath);
    if (!stat.isFile() || stat.size <= 0) throw new Error('الملف غير صالح.');
    if (stat.size > session.settings.maxImageSizeMB * 1024 * 1024) throw new Error(`حجم الملف أكبر من ${session.settings.maxImageSizeMB} MB.`);
    const ext = path.extname(filePath).toLowerCase();
    const mime = {
      '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp', '.gif': 'image/gif',
      '.pdf': 'application/pdf', '.txt': 'text/plain', '.zip': 'application/zip', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    }[ext];
    if (!mime) throw new Error('نوع الملف غير مدعوم.');
    return this.enqueue(safe, async () => {
      const client = this.runtime(safe).client;
      if (!client || !this.isReady(safe)) throw Object.assign(new Error('جلسة WhatsApp غير جاهزة أثناء إرسال الوسائط.'), { code: 'SEND_NOT_READY' });
      const data = fs.readFileSync(filePath).toString('base64');
      if (!data) throw new Error('تعذر قراءة بيانات الملف.');
      const media = new MessageMedia(mime, data, path.basename(filePath), stat.size);
      const isImage = mime.startsWith('image/');
      const result = await withTimeout(client.sendMessage(chatId, media, {
        sendMediaAsDocument: !isImage,
        sendMediaAsHd: false,
        sendSeen: false,
        waitUntilMsgSent: false,
        ignoreQuoteErrors: true
      }), session.settings.sendTimeoutMs, 'إرسال الوسائط');
      if (!result) throw new Error('WhatsApp لم ينشئ رسالة الوسائط.');
      const mid = serializedId(result.id);
      const ack = await this.observeAck(safe, result, session.settings.ackObservationMs);
      Object.defineProperty(result, '__chatBotAck', { value: ack, enumerable: false, configurable: true });
      if (ack.status === 'error') throw Object.assign(new Error('تم إنشاء الوسائط لكن WhatsApp أعلن فشل الإرسال.'), { code: 'SEND_ACK_ERROR' });
      this.runtime(safe).lastSent = { id: mid, kind: isImage ? 'image' : 'file', ack, at: new Date().toISOString() };
      return result;
    }, 'الوسائط');
  }
  async listGroups(id) {
    const safe=this.store.safeSessionId(id);
    if(!this.isReady(safe)) return [];
    const client=this.runtime(safe).client;
    if(!client) return [];
    const chats=await withTimeout(client.getChats(),30000,'قراءة المجموعات');
    return chats.filter(chat=>chat?.isGroup&&serializedId(chat?.id)).map(chat=>({
      id:serializedId(chat.id),
      name:String(chat.name||chat.formattedTitle||'مجموعة بدون اسم').slice(0,120),
      isGroup:true
    })).sort((a,b)=>a.name.localeCompare(b.name,'ar'));
  }

  async replyToMessage(id, message, text) {
    const safe = this.store.safeSessionId(id);
    const body = String(text || '').trim();
    if (!body) return null;
    await this.ensureReady(safe);
    const mid = serializedId(message?.id || message);
    const chatId = String(message?.from || message?.chatId || '').trim();
    if (!chatId) throw new Error('تعذر تحديد محادثة الرسالة للرد.');

    return this.enqueue(safe, async () => {
      const session = this.store.loadSession(safe);
      const client = this.runtime(safe).client;
      if (!client || !this.isReady(safe)) throw Object.assign(new Error('جلسة WhatsApp غير جاهزة أثناء الرد.'), { code:'SEND_NOT_READY' });

      let result = null;
      if (message && typeof message.reply === 'function') {
        try {
          result = await withTimeout(
            message.reply(body, undefined, { sendSeen:false, waitUntilMsgSent:false, ignoreQuoteErrors:true }),
            session.settings.sendTimeoutMs,
            'الرد على الرسالة'
          );
        } catch (error) {
          this.log(safe,'WARN',`تعذر الرد المباشر؛ سيتم استخدام مسار quotedMessageId: ${safeError(error)}`);
        }
      }

      if (!result) {
        const options = { sendSeen:false, waitUntilMsgSent:false, ignoreQuoteErrors:true };
        if (mid) options.quotedMessageId = mid;
        try {
          result = await withTimeout(client.sendMessage(chatId, body, options), session.settings.sendTimeoutMs, 'الرد على الرسالة');
        } catch (error) {
          if (mid) {
            this.log(safe,'WARN',`تعذر الرد المقتبس؛ سيتم إرسال الرد العادي: ${safeError(error)}`);
            result = await withTimeout(client.sendMessage(chatId, body, { sendSeen:false, waitUntilMsgSent:false, ignoreQuoteErrors:true }), session.settings.sendTimeoutMs, 'إرسال الرد');
          } else {
            throw error;
          }
        }
      }

      if (!result) throw new Error('WhatsApp لم ينشئ الرد.');
      const ack = await this.observeAck(safe, result, session.settings.ackObservationMs);
      Object.defineProperty(result,'__chatBotAck',{value:ack,enumerable:false,configurable:true});
      if (ack.status === 'error') throw Object.assign(new Error('تم إنشاء الرد لكن WhatsApp أعلن فشل الإرسال.'), {code:'SEND_ACK_ERROR'});
      return result;
    }, 'الرد');
  }
  async reactToMessage(id, message, emoji) {
    const safe = this.store.safeSessionId(id);
    await this.ensureReady(safe);
    const mid = serializedId(message?.id || message);
    if (!mid) throw Object.assign(new Error('تعذر تحديد الرسالة للتفاعل.'), { code:'INVALID_MESSAGE_ID' });
    return this.enqueue(safe, async () => {
      const client = this.runtime(safe).client;
      if (!client || !this.isReady(safe)) throw Object.assign(new Error('جلسة WhatsApp غير جاهزة أثناء التفاعل.'), { code:'SEND_NOT_READY' });
      const value=emoji || '👍';
      if (message && typeof message.react === 'function') {
        try {
          const result=await withTimeout(message.react(value),20000,'Reaction');
          return result ?? true;
        } catch (error) {
          this.log(safe,'WARN',`تعذر تنفيذ Message.react، سيتم استخدام sendReaction: ${safeError(error)}`);
        }
      }
      const result=await withTimeout(client.sendReaction(mid,value),20000,'Reaction');
      if (result === false) throw new Error('WhatsApp رفض التفاعل على الرسالة.');
      return result ?? true;
    }, 'Reaction');
  }

  async sendReaction(id, messageId, emoji) {
    const safe=this.store.safeSessionId(id);
    await this.ensureReady(safe);
    const mid=serializedId(messageId);
    if(!mid) throw new Error('تعذر تحديد الرسالة للتفاعل.');
    return this.enqueue(safe,async()=>{
      const client=this.runtime(safe).client;
      if(!client||!this.isReady(safe)) throw Object.assign(new Error('جلسة WhatsApp غير جاهزة أثناء التفاعل.'),{code:'SEND_NOT_READY'});
      const value=emoji||'👍';
      try{
        const result=await withTimeout(client.sendReaction(mid,value),20000,'Reaction');
        if(result===false) throw new Error('WhatsApp رفض التفاعل على الرسالة.');
        return result??true;
      }catch(error){
        if(client.getMessageById){
          const message=await withTimeout(client.getMessageById(mid),12000,'قراءة الرسالة للتفاعل');
          if(message?.react){return (await withTimeout(message.react(value),20000,'Reaction'))??true;}
        }
        throw error;
      }
    },'Reaction');
  }
  async stopAll() {
    this.shuttingDown = true;
    return Promise.all([...this.items.keys()].map(id => this.stop(id).catch(() => undefined)));
  }
}

module.exports = { WhatsAppManager, normalizePhone, serializedId, safeError, browserExecutable, sleep, normalizeMessageObject, normalizeReactionObject };
