# chat BOT v4.0.1

Local WhatsApp Web automation with isolated sessions, international phone validation, scheduled Friday delivery, instant sending, deterministic local interaction rules, visual backgrounds, backups and local-only assistant.

## Standard

Run:

```bash
python run.py
```

For a clean dependency reinstall while keeping WhatsApp session data:

```bash
python run.py --reset
```

Do not open `public/index.html` directly. The launcher starts the local server first and opens `http://127.0.0.1:7005` only after `/control/ping` responds.

## Compact

The compact archive contains exactly three files: `index.html`, `server.js`, `package.json`.

```bash
npm install --no-audit --no-fund
npm start
```

Then open `http://127.0.0.1:7005`.

The compact `server.js` bootstraps missing npm dependencies and applies the WhatsApp compatibility patch automatically.

## WhatsApp media compatibility

The project pins `whatsapp-web.js` 1.34.7 and applies a local compatibility patch for the current WhatsApp Web media regression. The patch is verified before the WhatsApp client is created.
