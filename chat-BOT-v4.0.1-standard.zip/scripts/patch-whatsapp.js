'use strict';

const fs = require('node:fs');
const path = require('node:path');

const MARKERS = {
  media: '/* CHAT_BOT_MEDIA_COMPAT_400 */',
  messageId: '/* CHAT_BOT_MESSAGE_ID_COMPAT_400 */',
};

function patchUtils(source) {
  const marker = MARKERS.media;
  if (source.includes(marker)) return { source, changed: false };

  const mediaLine = /\n\s*\.\.\.\(mediaOptions\.toJSON\s*\?\s*mediaOptions\.toJSON\(\)\s*:\s*\{\}\),\n/;
  const match = source.match(mediaLine);
  if (!match) {
    throw new Error('Utils.js mediaOptions anchor was not found; compatibility patch was not applied.');
  }

  // Critical: __x_id must be removed AFTER the outgoing message object is closed.
  const messageStart = source.indexOf('const message = {');
  if (messageStart < 0) throw new Error('Utils.js outgoing message object start was not found.');
  const closeMatch = /\n[ \t]*};/.exec(source.slice(messageStart));
  const closeIndex = closeMatch ? messageStart + closeMatch.index : -1;
  const closeText = closeMatch ? closeMatch[0] : '';
  if (closeIndex < 0) throw new Error('Utils.js outgoing message object boundary was not found.');
  const insertAt = closeIndex + closeText.length;
  const compatibilityBlock = `
        ${marker}
        // WhatsApp Web can leak MediaData.__x_id into the outgoing Msg model.
        // It collides with the message key and breaks media sending.
        if (message && message.__x_id) delete message.__x_id;`;
  let out = source.slice(0, insertAt) + compatibilityBlock + source.slice(insertAt);

  // Keep compatibility with message-key objects that expose $1 instead of _serialized.
  const currentReturn = /\.Msg\.get\(newMsgKey\._serialized\);/;
  if (currentReturn.test(out)) {
    out = out.replace(currentReturn, '.Msg.get(newMsgKey._serialized || newMsgKey.$1);');
  }

  return { source: out, changed: true };
}

function patchMessageId(source) {
  const marker = MARKERS.messageId;
  if (source.includes(marker)) return { source, changed: false };

  const patterns = [
    /this\.id\s*=\s*data\.id;/,
    /this\.id\s*=\s*data\.id\s*;\s*$/m
  ];
  const match = patterns.find(rx => rx.test(source));
  if (!match) {
    throw new Error('Message.js id assignment anchor was not found; compatibility patch was not applied.');
  }
  const replacement = `this.id = (data.id && data.id._serialized == null && data.id.$1 != null) ? Object.assign({}, data.id, { _serialized: data.id.$1 }) : data.id;\n        ${marker}\n        // WhatsApp Web may expose Message.id.$1 instead of id._serialized.`;
  return { source: source.replace(match, replacement), changed: true };
}

function applyPatch() {
  const result = { ok: true, changed: [], errors: [] };
  try {
    const root = path.dirname(require.resolve('whatsapp-web.js/package.json'));
    const utilsFile = path.join(root, 'src', 'util', 'Injected', 'Utils.js');
    const messageFile = path.join(root, 'src', 'structures', 'Message.js');
    if (!fs.existsSync(utilsFile)) throw new Error('whatsapp-web.js Utils.js not found.');
    if (!fs.existsSync(messageFile)) throw new Error('whatsapp-web.js Message.js not found.');

    const utils = patchUtils(fs.readFileSync(utilsFile, 'utf8'));
    if (utils.changed) {
      const temp = `${utilsFile}.${process.pid}.tmp`;
      fs.writeFileSync(temp, utils.source, 'utf8');
      fs.renameSync(temp, utilsFile);
      result.changed.push(path.basename(utilsFile));
    }

    const message = patchMessageId(fs.readFileSync(messageFile, 'utf8'));
    if (message.changed) {
      const temp = `${messageFile}.${process.pid}.tmp`;
      fs.writeFileSync(temp, message.source, 'utf8');
      fs.renameSync(temp, messageFile);
      result.changed.push(path.basename(messageFile));
    }

    verifyPatched();
  } catch (error) {
    result.ok = false;
    result.errors.push(error.message || String(error));
  }
  return result;
}
function verifyPatched() {
  const root = path.dirname(require.resolve('whatsapp-web.js/package.json'));
  const utilsFile = path.join(root, 'src', 'util', 'Injected', 'Utils.js');
  const messageFile = path.join(root, 'src', 'structures', 'Message.js');
  if (!fs.existsSync(utilsFile)) throw new Error('Utils.js not found during verification.');
  if (!fs.existsSync(messageFile)) throw new Error('Message.js not found during verification.');

  const utils = fs.readFileSync(utilsFile, 'utf8');
  if (!utils.includes(MARKERS.media)) throw new Error('Media compatibility patch marker is missing.');
  const markerPos = utils.indexOf(MARKERS.media);
  const objectClosePos = utils.lastIndexOf('};', markerPos);
  const objectOpenPos = utils.lastIndexOf('const message = {', markerPos);
  if (objectOpenPos !== -1 && objectClosePos < objectOpenPos) throw new Error('Compatibility patch was inserted inside the message object.');
  if (!/if \(message && message\.__x_id\) delete message\.__x_id;/.test(utils)) throw new Error('The __x_id removal statement is missing.');

  const message = fs.readFileSync(messageFile, 'utf8');
  if (!message.includes(MARKERS.messageId)) throw new Error('Message id compatibility patch marker is missing.');
  if (!/data\.id\.\$1 != null/.test(message) || !/\{ _serialized: data\.id\.\$1 \}/.test(message)) throw new Error('Message $1/_serialized compatibility statement is missing.');
  return true;
}
if (require.main === module) {
  const result = applyPatch();
  if (!result.ok) {
    console.error(`WhatsApp compatibility patch: ERROR — ${result.errors.join('; ')}`);
    process.exitCode = 1;
  } else {
    console.log(`WhatsApp compatibility patch: READY${result.changed.length ? ` — changed: ${result.changed.join(', ')}` : ''}`);
  }
}

module.exports = { applyPatch, patchUtils, verifyPatched, MARKERS };
