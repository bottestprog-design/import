# chat BOT v4.0.1

- Reliability pass: verified UI event wiring, group selector interaction, local helper answers, scheduler/job paths, and background controls.

- Fixed the WhatsApp media compatibility patch so `delete message.__x_id` is inserted after the outgoing message object is created, not inside it.
- Kept whatsapp-web.js 1.34.7 and applied the current media compatibility workaround at install/runtime.
- Added `run.py` as the single Windows-friendly launcher for dependency installation, browser detection, server startup, readiness check, and opening the local panel on port 7005.
- Added international phone validation using libphonenumber-js.
- Kept session isolation, scheduled delivery, instant delivery, interaction rules, local assistant, animated backgrounds, backups, logs, and manual UI refresh.
- Removed dependency on START_WINDOWS*.bat for the standard build.
