#!/usr/bin/env python3
"""Local/online voice worker for chat BOT.

Commands:
  status
  prepare [tiny|base|small|medium|large-v3]
  transcribe INPUT LANGUAGE MODEL_DIR
  edge-tts OUTPUT VOICE RATE_PCT PITCH_HZ VOLUME_PCT  (text via stdin)
  ffmpeg-path
  voice-smoke-test PIPER_BIN PIPER_MODEL FFMPEG_BIN WHISPER_MODEL_DIR

All machine-readable results are emitted as one JSON object on stdout. Details go to stderr.
"""
from __future__ import annotations
import asyncio
import importlib.util
import json
import os
import sys
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MODELS = ROOT / "models"
DEFAULT_MODEL_DIR = MODELS / "faster-whisper-small"
ALLOWED_WHISPER_MODELS = {"tiny", "base", "small", "medium", "large-v3", "large-v3-turbo"}
ALLOWED_EDGE_VOICES = set({'ar-SY-LaithNeural', 'ar-MA-JamalNeural', 'ar-DZ-IsmaelNeural', 'ar-YE-MaryamNeural', 'ar-LY-ImanNeural', 'ar-SA-HamedNeural', 'ar-BH-LailaNeural', 'ar-EG-SalmaNeural', 'ar-SA-ZariyahNeural', 'ar-MA-MounaNeural', 'ar-LB-RamiNeural', 'ar-SY-AmanyNeural', 'ar-JO-SanaNeural', 'ar-TN-HediNeural', 'ar-TN-ReemNeural', 'ar-YE-SalehNeural', 'ar-BH-AliNeural', 'ar-QA-MoazNeural', 'ar-EG-ShakirNeural', 'ar-IQ-RanaNeural', 'ar-AE-FatimaNeural', 'ar-IQ-BasselNeural', 'ar-KW-FahedNeural', 'ar-JO-TaimNeural', 'ar-OM-AyshaNeural', 'ar-DZ-AminaNeural', 'ar-OM-AbdullahNeural', 'ar-KW-NouraNeural', 'ar-QA-AmalNeural', 'ar-AE-HamdanNeural', 'ar-LY-OmarNeural', 'ar-LB-LaylaNeural', 'en-US-JennyNeural', 'en-US-GuyNeural', 'en-US-AriaNeural', 'fr-FR-DeniseNeural', 'fr-FR-HenriNeural', 'de-DE-KatjaNeural', 'de-DE-ConradNeural', 'es-ES-ElviraNeural', 'es-ES-AlvaroNeural'})


def emit(value: dict) -> None:
    print(json.dumps(value, ensure_ascii=False, separators=(",", ":")))


def module_available(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ValueError, ModuleNotFoundError):
        return False


def ffmpeg_path() -> str:
    try:
        import imageio_ffmpeg
        candidate = imageio_ffmpeg.get_ffmpeg_exe()
        if candidate and Path(candidate).is_file():
            return str(Path(candidate).resolve())
    except Exception:
        pass
    return ""


def model_dir_from_arg(arg: str | None = None) -> Path:
    return Path(arg).expanduser().resolve() if arg else Path(os.environ.get("WHISPER_PY_MODEL_PATH", str(DEFAULT_MODEL_DIR))).expanduser().resolve()


def whisper_model_available(directory: Path) -> bool:
    return directory.is_dir() and (directory / "model.bin").is_file() and (directory / "config.json").is_file()


def do_status() -> None:
    target = model_dir_from_arg()
    emit({
        "ok": True,
        "python": sys.version.split()[0],
        "fasterWhisperAvailable": module_available("faster_whisper"),
        "piperAvailable": module_available("piper"),
        "edgeTtsAvailable": module_available("edge_tts"),
        "imageioFfmpegAvailable": module_available("imageio_ffmpeg"),
        "ffmpegPath": ffmpeg_path(),
        "whisperModelAvailable": whisper_model_available(target),
        "whisperModelPath": str(target),
    })


def do_prepare(model_size: str) -> None:
    size = (model_size or "small").strip().lower()
    if size not in ALLOWED_WHISPER_MODELS:
        raise ValueError("حجم نموذج Whisper غير مدعوم.")
    from huggingface_hub import snapshot_download
    from faster_whisper import WhisperModel
    target = MODELS / f"faster-whisper-{size}"
    target.mkdir(parents=True, exist_ok=True)
    repo = f"Systran/faster-whisper-{size}"
    # A local directory makes subsequent transcription independent of network access.
    snapshot_download(repo_id=repo, local_dir=str(target))
    model = WhisperModel(str(target), device="cpu", compute_type="int8")
    del model
    if not whisper_model_available(target):
        raise RuntimeError("تم التنزيل لكن ملفات نموذج Faster-Whisper لم تجتز فحص الجاهزية.")
    emit({"ok": True, "model": size, "modelPath": str(target), "message": "تم تنزيل نموذج Faster-Whisper والتحقق من ملفات النموذج محليًا."})


def do_transcribe(input_file: str, language: str, model_dir: str) -> None:
    source = Path(input_file).expanduser().resolve()
    target = model_dir_from_arg(model_dir)
    if not source.is_file() or source.stat().st_size <= 0:
        raise ValueError("ملف الصوت فارغ أو غير موجود.")
    if not whisper_model_available(target):
        raise RuntimeError(f"نموذج Faster-Whisper المحلي غير مكتمل: {target}. شغّل أداة إعداد الصوت ثم أعد المحاولة.")
    from faster_whisper import WhisperModel
    model = WhisperModel(str(target), device=os.environ.get("WHISPER_PY_DEVICE", "cpu"), compute_type=os.environ.get("WHISPER_PY_COMPUTE_TYPE", "int8"))
    selected_language = None if str(language).lower() in {"auto", "detect", ""} else str(language).lower()
    segments, info = model.transcribe(
        str(source), language=selected_language, task="transcribe", beam_size=5,
        vad_filter=True, condition_on_previous_text=False,
        vad_parameters={"min_silence_duration_ms": 450},
    )
    text_parts = []
    avg_logprobs = []
    for segment in segments:
        chunk = str(getattr(segment, "text", "") or "").strip()
        if chunk:
            text_parts.append(chunk)
            try:
                avg_logprobs.append(float(segment.avg_logprob))
            except (AttributeError, TypeError, ValueError):
                pass
    transcript = " ".join(text_parts).replace("\u0000", "").strip()
    if not transcript:
        raise RuntimeError("لم يتمكن Faster-Whisper من استخراج كلمات واضحة من التسجيل. جرّب تسجيلًا أوضح.")
    emit({
        "ok": True, "transcript": transcript[:12000], "text": transcript[:12000],
        "language": str(getattr(info, "language", selected_language or "unknown")),
        "languageProbability": round(float(getattr(info, "language_probability", 0.0) or 0.0), 4),
        "segments": len(text_parts),
        "avgLogProbability": round(sum(avg_logprobs) / len(avg_logprobs), 4) if avg_logprobs else None,
        "backend": "python-faster-whisper",
    })


async def do_edge_tts(output_file: str, voice: str, rate_pct: str, pitch_hz: str, volume_pct: str) -> None:
    target = Path(output_file).expanduser().resolve()
    text = sys.stdin.read().strip()
    if not text:
        raise ValueError("لا يوجد نص صالح للنطق.")
    if len(text) > 1800:
        raise ValueError("النص أطول من الحد المسموح للنطق (1800 حرف).")
    if voice not in ALLOWED_EDGE_VOICES:
        raise ValueError("الصوت العربي المحدد غير موجود في القائمة الآمنة.")
    def signed_number(raw: str, minimum: int, maximum: int, suffix: str) -> str:
        value = int(float(raw))
        value = max(minimum, min(maximum, value))
        return f"{value:+d}{suffix}"
    rate = signed_number(rate_pct, -40, 40, "%")
    pitch = signed_number(pitch_hz, -30, 30, "Hz")
    volume = signed_number(volume_pct, -30, 30, "%")
    target.parent.mkdir(parents=True, exist_ok=True)
    import edge_tts
    await edge_tts.Communicate(text=text, voice=voice, rate=rate, volume=volume, pitch=pitch).save(str(target))
    if not target.is_file() or target.stat().st_size < 100:
        raise RuntimeError("خدمة النطق لم تنتج ملف صوت صالحًا.")
    emit({"ok": True, "path": str(target), "bytes": target.stat().st_size, "voice": voice, "rate": rate, "pitch": pitch, "volume": volume, "backend": "edge-tts"})



def do_voice_smoke_test(piper_bin: str, piper_model: str, ffmpeg_bin: str, whisper_model_dir: str) -> None:
    """Exercise local speech generation, WhatsApp Opus packaging and transcription."""
    piper = Path(piper_bin).expanduser().resolve()
    model = Path(piper_model).expanduser().resolve()
    ffmpeg = Path(ffmpeg_bin).expanduser().resolve()
    whisper_dir = Path(whisper_model_dir).expanduser().resolve()
    model_cfg = Path(str(model) + ".json")
    if not piper.is_file():
        raise RuntimeError(f"Piper executable not found: {piper}")
    if not model.is_file() or model.stat().st_size < 10_000_000 or not model_cfg.is_file():
        raise RuntimeError("Piper Arabic model/config is missing or incomplete.")
    if not ffmpeg.is_file():
        raise RuntimeError(f"FFmpeg executable not found: {ffmpeg}")
    if not whisper_model_available(whisper_dir):
        raise RuntimeError("Faster-Whisper model is missing or incomplete.")
    sample = "مرحبًا، هذا اختبار صوتي عربي للتأكد من أن النطق والتفريغ يعملان."
    with tempfile.TemporaryDirectory(prefix="chatbot-voice-smoke-") as temp_dir:
        temp = Path(temp_dir)
        wav = temp / "sample.wav"
        ogg = temp / "sample.ogg"
        tts = subprocess.run(
            [str(piper), "--model", str(model), "--output_file", str(wav), "--length_scale", "1.0", "--noise_scale", "0.667", "--noise_w", "0.8"],
            input=(sample + "\n").encode("utf-8"), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            timeout=120, check=False,
        )
        if tts.returncode != 0 or not wav.is_file() or wav.stat().st_size < 128:
            detail = (tts.stderr or b"").decode("utf-8", errors="replace")[-500:]
            raise RuntimeError(f"Piper smoke test failed ({tts.returncode}): {detail}")
        conversion = subprocess.run(
            [str(ffmpeg), "-y", "-v", "error", "-i", str(wav), "-vn", "-ac", "1", "-ar", "48000", "-c:a", "libopus", "-b:a", "32k", "-f", "ogg", str(ogg)],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=90, check=False,
        )
        if conversion.returncode != 0 or not ogg.is_file() or ogg.stat().st_size < 100:
            detail = (conversion.stderr or b"").decode("utf-8", errors="replace")[-500:]
            raise RuntimeError(f"FFmpeg OGG/Opus smoke test failed ({conversion.returncode}): {detail}")
        from faster_whisper import WhisperModel
        whisper = WhisperModel(str(whisper_dir), device="cpu", compute_type="int8")
        segments, info = whisper.transcribe(str(ogg), language="ar", task="transcribe", beam_size=1, vad_filter=True, condition_on_previous_text=False)
        transcript = " ".join(str(getattr(segment, "text", "") or "").strip() for segment in segments).strip()
        del whisper
        if not transcript:
            raise RuntimeError("Faster-Whisper smoke test produced no transcript from the generated Arabic audio.")
        emit({"ok": True, "piper": True, "ffmpegOpus": True, "fasterWhisper": True, "transcript": transcript[:500], "detectedLanguage": str(getattr(info, "language", "unknown")), "oggBytes": ogg.stat().st_size, "message": "Local Arabic speech generation, OGG/Opus conversion, and transcription smoke test passed."})

def main() -> int:
    if len(sys.argv) < 2:
        emit({"ok": False, "error": "لم يُحدد أمر لمحرك الصوت."})
        return 2
    action = sys.argv[1].strip().lower()
    try:
        if action == "status":
            do_status()
        elif action == "prepare":
            do_prepare(sys.argv[2] if len(sys.argv) > 2 else "small")
        elif action == "transcribe":
            if len(sys.argv) < 5:
                raise ValueError("بيانات التفريغ غير مكتملة.")
            do_transcribe(sys.argv[2], sys.argv[3], sys.argv[4])
        elif action == "edge-tts":
            if len(sys.argv) < 7:
                raise ValueError("إعدادات النطق العصبي غير مكتملة.")
            asyncio.run(do_edge_tts(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6]))
        elif action == "ffmpeg-path":
            path = ffmpeg_path()
            if not path:
                raise RuntimeError("لم تُثبت حزمة imageio-ffmpeg ولم يُعثر على FFmpeg محلي.")
            emit({"ok": True, "path": path})
        elif action == "voice-smoke-test":
            if len(sys.argv) < 6:
                raise ValueError("مسارات اختبار الصوت غير مكتملة.")
            do_voice_smoke_test(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
        else:
            raise ValueError("أمر محرك الصوت غير معروف.")
        return 0
    except Exception as exc:
        # Keep diagnostics concise and never print environment variables or keys.
        print(f"voice-worker: {type(exc).__name__}: {str(exc)[:700]}", file=sys.stderr)
        emit({"ok": False, "error": str(exc)[:700], "errorType": type(exc).__name__})
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
