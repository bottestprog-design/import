'use strict';

// Discover JavaScript files dynamically so a newly added module or test cannot
// silently miss the release verification list. Skips are reported explicitly.
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const ROOT = path.resolve(__dirname, '..');
const STRICT = process.argv.includes('--strict');
const EXCLUDED = new Set(['node_modules', 'data', '.runtime', '.cache', '.git']);

function walk(directory, out = []) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
    if (entry.isDirectory() && EXCLUDED.has(entry.name)) continue;
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) walk(full, out);
    else if (entry.isFile() && entry.name.endsWith('.js')) out.push(full);
  }
  return out;
}

function runNode(args, { timeout = 120000 } = {}) {
  return spawnSync(process.execPath, args, {
    cwd: ROOT,
    env: process.env,
    encoding: 'utf8',
    timeout,
    maxBuffer: 8 * 1024 * 1024,
  });
}

function main() {
  const jsFiles = walk(ROOT);
  let syntaxFailures = 0;
  for (const file of jsFiles) {
    const result = runNode(['--check', file], { timeout: 15000 });
    if (result.status !== 0) {
      syntaxFailures++;
      process.stderr.write(`SYNTAX FAIL ${path.relative(ROOT, file)}\n${result.stderr || result.stdout || result.error || ''}`);
    }
  }
  if (syntaxFailures === 0) console.log(`Syntax check: ${jsFiles.length} JavaScript files, 0 failures.`);

  const testDir = path.join(ROOT, 'test');
  const tests = fs.readdirSync(testDir).filter(name => name.endsWith('.js')).sort();
  let passed = 0;
  let failed = 0;
  let skipped = 0;
  const skipDetails = [];
  for (const file of tests) {
    const full = path.join(testDir, file);
    console.log(`RUN ${file}`);
    const result = runNode([full]);
    const output = `${result.stdout || ''}${result.stderr || ''}`;
    if (output) process.stdout.write(output.endsWith('\n') ? output : `${output}\n`);
    const skipLines = output.split(/\r?\n/).filter(line => /^\s*SKIP\b/i.test(line));
    if (result.status !== 0 || result.error) {
      failed++;
      console.error(`FAIL ${file} (exit=${result.status}; error=${result.error?.message || 'none'})`);
    } else if (skipLines.length) {
      skipped++;
      skipDetails.push(`${file}: ${skipLines.join(' | ')}`);
      console.log(`SKIP ${file} (${skipLines.length} explicit skip)`);
    } else {
      passed++;
      console.log(`PASS ${file}`);
    }
  }

  let pythonStatus = 'not-run';
  const python = process.platform === 'win32' ? 'python' : 'python3';
  const pythonTest = path.join(ROOT, 'test_launcher_dependencies.py');
  if (fs.existsSync(pythonTest)) {
    const py = spawnSync(python, [pythonTest], { cwd: ROOT, env: process.env, encoding: 'utf8', timeout: 15000, maxBuffer: 1024 * 1024 });
    if (py.stdout) process.stdout.write(py.stdout);
    if (py.stderr) process.stderr.write(py.stderr);
    pythonStatus = py.status === 0 ? 'PASS' : 'FAIL';
    if (py.status !== 0) failed++;
  }

  console.log('\n=== Verification summary ===');
  console.log(`JavaScript syntax: ${jsFiles.length - syntaxFailures}/${jsFiles.length}`);
  console.log(`Test files: ${passed} passed, ${skipped} skipped, ${failed} failed (${tests.length} total).`);
  if (pythonStatus !== 'not-run') console.log(`Launcher dependency check: ${pythonStatus}`);
  for (const item of skipDetails) console.log(`SKIP DETAIL: ${item}`);
  if (syntaxFailures || failed || (STRICT && skipped)) process.exitCode = 1;
  else if (skipped) console.log('RESULT: PASS WITH LIMITATIONS (use npm run test:strict to require every integration test).');
  else console.log('RESULT: PASS (all collected local tests ran without skips).');
}

main();
