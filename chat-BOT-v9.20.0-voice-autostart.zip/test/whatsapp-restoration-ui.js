'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const server = read('server.js');
const app = read('public/app.js');
const css = read('public/styles.css');
const whatsapp = read('src/whatsapp.js');
const assistant = read('src/owner-assistant.js');
const pkg = JSON.parse(read('package.json'));
const checks = [
  ['version', pkg.version === '9.20.0'],
  ['selected send targets survive a browser refresh within the same session', /pendingTargetStorageKey/.test(app) && /restorePendingTargets\(\)/.test(app) && /persistPendingTargets\(\)/.test(app) && /sessionStorage/.test(app)],
  ['contact import saves recipients before profile picture hydration', /syncContacts\(\{ store, whatsapp, phones, sessionId: id, jids: \[jid\], importMissing: true, updateNames: false, updatePictures: false \}\)/.test(server) && /refreshContactPictures/.test(server)],
  ['trusted remote avatar is used only as a verified fallback', /picture\?\.remoteUrl && whatsappContacts\.isAllowedProfileUrl\(picture\.remoteUrl\)/.test(server) && /Referrer-Policy/.test(server)],
  ['self-chat assistant is instantiated', /new OwnerAssistant\(\{\s*store,\s*whatsapp,\s*phones,\s*log,\s*audioTranscriber,\s*localLlm,\s*delivery,\s*speechSynthesizer:\s*textToSpeech(?:,\s*conversationArchive)?\s*\}\)/.test(server)],
  ['welcome guide on WhatsApp connection', /ownerAssistant\.maybeSendWelcome\(id\)/.test(server)],
  ['self chat messages routed to conversation engine', /await ownerAssistant\.handleSelfChatMessage\(id, assistantMessage\)/.test(server)],
  ['self-chat command guide exists', /WELCOME_GUIDE/.test(assistant) && /استدعاء جهات واتساب/.test(assistant)],
  ['WhatsApp live contacts API exists', /app\.get\('\/api\/whatsapp\/contacts'/.test(server)],
  ['WhatsApp contact synchronization API exists', /app\.post\('\/api\/whatsapp\/contacts\/sync'/.test(server)],
  ['WhatsApp contact listing uses real client API', /client\.getContacts\(\)/.test(whatsapp)],
  ['profile picture endpoint validates local file name', /app\.get\('\/profile\/:filename'/.test(server)],
  ['live WhatsApp profile-photo endpoint is wired', /app\.get\('\/api\/whatsapp\/contact-picture'/.test(server) && /ensureContactPicture/.test(server)],
  ['saved AVIF profile photos are served without being rejected by the filename allowlist', /(?:jpg\|jpeg\|png\|webp\|gif\|avif)/.test(server)],
  ['WhatsApp contacts display a lazy real profile photo', /wa-contact-photo/.test(app) && /contact-picture\?sessionId/.test(app)],
  ['personal contact rows use verified WhatsApp JID photos and show current name', /person\.whatsappJid/.test(app) && /اسم ملف WhatsApp/.test(app) && /اسم دفتر العناوين/.test(app)],
  ['send API returns numeric counts and errors, not NaN', /sentCount/.test(server) && /failedDetails/.test(server) && /result\.sent\.length/.test(server)],
  ['self-chat helper section provides real usage instructions', /افتح «الرسائل إلى نفسك»/.test(app) && /حوار إرسال رسالة/.test(assistant)],
  ['contact retrieval panel is progressive disclosure', /<details class="advanced-panel whatsapp-sync-panel" id="whatsappContactsDisclosure"/.test(app)],
  ['contact selection and sync are wired', /loadWhatsAppContacts\(\)/.test(app) && /api\/whatsapp\/contacts\/sync/.test(app) && /data-wa-contact-select/.test(app)],
  ['each WhatsApp contact has an immediate add-to-send-list action', /data-import-wa-contact/.test(app) && /api\/whatsapp\/contact\/import/.test(app) && /queueRecipientsForSending/.test(app)],
  ['single and bulk imports select new contacts for the send screen', /state\.pendingTargets = \[\.\.\.new Set/.test(app) && /إضافة المحدد إلى قائمة الإرسال/.test(app)],
  ['importing from null selection explicitly selects only added contacts, not every saved target', /const previous = Array\.isArray\(state\.pendingTargets\) \? state\.pendingTargets : \[\]/.test(app) && /state\.pendingTargets = \[\.\.\.new Set\(\[\.\.\.previous, \.\.\.ids\.map\(id => `r:\$\{id\}`\)\]\)\]/.test(app)],
  ['partial send result is processed instead of being thrown away as HTTP error', /deliveryOk: result\.ok === true/.test(server) && /const failed = Array\.isArray\(result\.failed\)/.test(app)],
  ['media replacement checkbox is not reused to bypass send duplicate protection', app.includes("replaceDuplicate: $('#replaceSendDuplicate')?.checked === true") && app.includes('id=\"replaceDuplicates\"')],
  ['uncertain and permission failures are not preselected for blind resend', app.includes("item.retryable === true && item.code !== 'SEND_UNCERTAIN'")],
  ['send response distinguishes operations from unique recipients', /sentRecipientCount/.test(server) && /failedRecipientCount/.test(server)],
  ['contact photo lookup retries with a local refresh request', /u\.searchParams\.set\('refresh','1'\)/.test(app) && /mappedUrl/.test(whatsapp)],
  ['personal response editor collapses by default', /<details class="personal-reply-editor">/.test(app)],
  ['automation editors collapsed by default', /<details class="section-editor" id="automationRuleDisclosure" \$\{edited \? 'open' : ''\}>/.test(app)],
  ['scheduled-send editor collapsed until requested', /<details class="section-editor" id="sendScheduleDisclosure" \$\{state\.editingTaskId \? 'open' : ''\}>/.test(app) && /\$\('#sendScheduleDisclosure'\)\.open = true/.test(app)],
  ['latest release documents the current integrated v9.20.0 voice repair', app.includes("version: 'v9.20.0'") && app.includes('تشخيص المركز بنظرة واحدة') && app.includes('شخّص الرد التلقائي') && app.includes('فحص النطق') && app.includes('هات آخر 10 رسائل') && app.includes('انطق آخر رد') && app.includes('سجل المحادثات')],
  ['contacts API returns the list before asynchronous avatar hydration', /listContacts\(id, \{ limit: 2000, includeProfilePictures: false \}\)/.test(server) && /setImmediate\(\(\) => whatsappContacts\.refreshContactPictures/.test(server)],
  ['photo hydration persists filenames and trusted remote fallback separately', /person\.whatsappProfilePhoto !== photo\.filename/.test(read('src/whatsapp-contacts.js')) && /person\.whatsappAvatarUrl !== photo\.remoteUrl/.test(read('src/whatsapp-contacts.js'))],
  ['session status endpoint avoids caching real QR updates', /app\.get\('\/api\/session\/status'/.test(server) && /Cache-Control', 'no-store/.test(server)],
  ['session panel polls live state without a full-page refresh', /setInterval\(\(\) => \{ if \(state\.page === 'session'\) refreshSessionRuntime\(\); \}, 1400\)/.test(app) && /id=\"sessionQrImage\"/.test(app)],
  ['real QR payload is converted to PNG before publishing', /toDataURL\(qr\.trim\(\)/.test(whatsapp) && /data:image\\\/png;base64,/.test(whatsapp) && /Never expose the raw WhatsApp pairing payload/.test(whatsapp)],
  ['connect API returns immediately and the UI keeps a visible QR placeholder while waiting', /res\.status\(202\)/.test(server) && /sessionQrPlaceholder/.test(app) && /img\.hidden = !goodQr/.test(app) && /return this\.listRuntime\(sid\)/.test(whatsapp)],
  ['connection clicks do not destroy active QR sessions', /e\.client && \['starting', 'qr', 'pairing_code', 'authenticated'\]\.includes\(e\.status\)/.test(whatsapp)],
  ['Chromium client errors have a listener and bounded recovery plan', /client\.on\('error'/.test(whatsapp) && /MAX_CONTEXT_RECOVERY_ATTEMPTS = 3/.test(whatsapp)],
  ['compact progressive editors styled', css.includes('.section-editor>summary') && css.includes('.whatsapp-sync-panel') && css.includes('.self-chat-guide-panel')],
  ['explicit repeat-send option uses a full-width readable row', app.includes('send-repeat-override') && css.includes('.send-repeat-override{grid-column:1/-1')],
  ['profile downloader verifies binary signatures rather than MIME alone', /binary signature below, so MIME alone/.test(read('src/whatsapp-contacts.js'))],
  ['advanced detail editors not forced open', !/<details class="advanced-panel" open>/.test(app)],
  ['transcription UI uses local Whisper and configurable reply fallback controls', app.includes('id="transcribeLatestBtn"') && app.includes('id="interactionFallbackEnabled"') && server.includes('new AudioTranscriber') && read('src/audio-transcriber.js').includes('WHISPER_MODEL_PATH') && read('.env.example').includes('WHISPER_MODEL_PATH')],
];
let failed = false;
for (const [label, ok] of checks) { console.log(`${ok ? 'OK' : 'FAIL'} ${label}`); if (!ok) failed = true; }
if (failed) process.exit(1);
