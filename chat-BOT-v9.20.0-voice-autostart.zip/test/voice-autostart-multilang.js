'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const store = require('../src/store');
const { VoiceBootstrap } = require('../src/voice-bootstrap');
const { TextToSpeech, detectSpeechLanguage, defaultVoiceForText } = require('../src/text-to-speech');
const { AudioTranscriber } = require('../src/audio-transcriber');
const { parseEnv } = require('../src/env-loader');

(async () => {
  const root = path.resolve(__dirname, '..');
  const manifest = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  assert.equal(manifest.version, '9.20.0');
  assert.equal(store.APP_VERSION, '9.20.0');

  // Regression: v9.18/v9.19 stored the old off/local voice defaults at schema 9.
  const legacyId = `voice-migration-${process.pid}-${Date.now()}`;
  const legacyPaths = store.ensureDir(legacyId);
  try {
    const legacy = {
      schemaVersion: 9, id: legacyId, name: 'legacy voice migration',
      settings: { ...store.clone(store.DEFAULT_SETTINGS), ttsBackend: 'local', interactionVoiceRepliesEnabled: false, voiceAutoTranscribeEnabled: true },
      recipients: [], groups: [], interaction: {}, automation: {}, logs: [], stats: {}, cycle: {}, scheduleState: {},
    };
    fs.writeFileSync(legacyPaths.json, JSON.stringify(legacy), 'utf8');
    const migrated = store.loadSession(legacyId);
    assert.equal(migrated.schemaVersion, 10);
    assert.equal(migrated.settings.ttsBackend, 'auto');
    assert.equal(migrated.settings.interactionVoiceRepliesEnabled, true);
    const current = { ...migrated, settings: { ...migrated.settings, interactionVoiceRepliesEnabled: false, ttsBackend: 'local' } };
    store.saveSession(current);
    const userOptOut = store.loadSession(legacyId);
    assert.equal(userOptOut.schemaVersion, 10);
    assert.equal(userOptOut.settings.interactionVoiceRepliesEnabled, false, 'an explicit setting saved to schema 10 must be respected');
    assert.equal(userOptOut.settings.ttsBackend, 'local');
  } finally { fs.rmSync(legacyPaths.dir, { recursive: true, force: true }); }

  // Four independent language mappings for neural voice selection.
  const matrix = [
    ['ar', 'مرحبًا، كيف حالك؟', 'ar-EG-ShakirNeural'],
    ['en', 'Hello, how are you today?', 'en-US-JennyNeural'],
    ['fr', 'Bonjour, comment allez-vous?', 'fr-FR-DeniseNeural'],
    ['de', 'Guten Morgen, wie geht es Ihnen?', 'de-DE-KatjaNeural'],
  ];
  for (const [language, phrase, voice] of matrix) {
    assert.equal(detectSpeechLanguage(phrase), language, `language detection failed for ${language}`);
    assert.equal(defaultVoiceForText(phrase, 'ar-EG-ShakirNeural'), voice, `voice routing failed for ${language}`);
  }

  const voices = JSON.parse(fs.readFileSync(path.join(root, 'scripts/voice-voices.json'), 'utf8'));
  const worker = fs.readFileSync(path.join(root, 'scripts/voice_worker.py'), 'utf8');
  const ui = fs.readFileSync(path.join(root, 'public/app.js'), 'utf8');
  const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
  for (const [, , voice] of matrix) {
    assert.ok(voices.includes(voice), `voice catalog missing ${voice}`);
    assert.ok(worker.includes(voice), `worker allowlist missing ${voice}`);
    assert.ok(ui.includes(voice), `UI voice selector missing ${voice}`);
  }
  assert.ok(server.includes('/api/voice/test-four-languages'));
  assert.ok(server.includes('waitUntilReady'), 'incoming voice should wait through automatic setup rather than immediately failing');
  assert.ok(fs.readFileSync(path.join(root, 'src/voice-bootstrap.js'), 'utf8').includes('async waitUntilReady'));
  assert.ok(ui.includes('testVoiceFourLanguagesBtn'));
  assert.ok(ui.includes("api('/api/voice/runtime-status')"), 'bootstrap progress must be polled without restarting heavy model probes');
  assert.ok(fs.readFileSync(path.join(root, '.env.example'), 'utf8').includes('VOICE_AUTOSTART=true'));

  const tts = new TextToSpeech({ env: {} });
  assert.equal(tts.config().backend, 'auto', 'TTS must default to online neural voice with local Arabic fallback');
  const transcriber = new AudioTranscriber({ env: {} });
  assert.equal(transcriber.config().backend, 'python-faster-whisper', 'transcription must default to a local multilingual engine');

  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-voice-env-test-'));
  try {
    const env = {};
    const bootstrap = new VoiceBootstrap({ root: tempRoot, env });
    bootstrap.writeEnv({ VOICE_PYTHON_BIN: 'C:\\Program Files\\chat BOT\\.voice-venv\\Scripts\\python.exe', TTS_BACKEND: 'auto', WHISPER_BACKEND: 'python-faster-whisper' });
    const parsed = parseEnv(fs.readFileSync(path.join(tempRoot, '.env'), 'utf8'));
    assert.equal(parsed.VOICE_PYTHON_BIN, 'C:\\Program Files\\chat BOT\\.voice-venv\\Scripts\\python.exe');
    assert.equal(parsed.TTS_BACKEND, 'auto');
    assert.equal(env.WHISPER_BACKEND, 'python-faster-whisper');
    assert.deepEqual(bootstrap.publicStatus().languages, ['ar', 'en', 'fr', 'de']);
  } finally { fs.rmSync(tempRoot, { recursive: true, force: true }); }

  // The first incoming voice message can wait for auto-provisioning instead of requiring the user to resend it.
  const waitRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-voice-wait-test-'));
  try {
    const bootstrap = new VoiceBootstrap({ root: waitRoot, env: {} });
    bootstrap.runSetup = async () => { await new Promise(resolve => setTimeout(resolve, 15)); bootstrap.update('ready', 'اختبار', 100, 'جاهز'); };
    const ready = await bootstrap.waitUntilReady({ timeoutMs: 1000, pollMs: 250 });
    assert.equal(ready.ready, true, 'waitUntilReady must wait for setup without user intervention');
  } finally { fs.rmSync(waitRoot, { recursive: true, force: true }); }

  // Retry is scheduled automatically after a failed setup; clear the unref'd timer in this isolated test.
  const retryRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-voice-retry-test-'));
  try {
    const bootstrap = new VoiceBootstrap({ root: retryRoot, env: {} });
    bootstrap.runSetup = async () => { throw new Error('mock temporary network failure'); };
    const result = await bootstrap.start();
    assert.equal(result.state, 'failed');
    assert.equal(result.attempts, 1);
    assert.equal(result.retryScheduled, true);
    clearTimeout(bootstrap.retryTimer); bootstrap.retryTimer = null;
  } finally { fs.rmSync(retryRoot, { recursive: true, force: true }); }

  console.log('voice-autostart-multilang: ok (schema migration, automatic backend defaults, four-language voice routing, project-owned env, automatic retry)');
})().catch(error => { console.error(error); process.exitCode = 1; });
