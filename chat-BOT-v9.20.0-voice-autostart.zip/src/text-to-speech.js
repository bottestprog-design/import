'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawn: nodeSpawn } = require('node:child_process');
const { execFile: nodeExecFile } = require('node:child_process');
const { promisify } = require('node:util');
const execFileDefault = promisify(nodeExecFile);

const MAX_SPEECH_CHARS = 1800;
const EDGE_DEFAULT_VOICE = 'ar-EG-ShakirNeural';
function voiceLanguage(voice) { const tag = String(voice || EDGE_DEFAULT_VOICE).toLowerCase(); if (tag.startsWith('ar-')) return 'ar'; if (tag.startsWith('fr-')) return 'fr'; if (tag.startsWith('de-')) return 'de'; if (tag.startsWith('en-')) return 'en'; if (tag.startsWith('es-')) return 'es'; return 'ar'; }
function detectSpeechLanguage(text) {
  const value = String(text || '').toLowerCase();
  if (/[\u0600-\u06ff]/u.test(value)) return 'ar';
  if (/[àâçéèêëîïôûùüÿœ]/u.test(value) || /\b(bonjour|merci|ceci|avec|pour|français|une|vous|nous|est)\b/u.test(value)) return 'fr';
  if (/[äöüß]/u.test(value) || /\b(hallo|guten|morgen|danke|und|der|die|das|nicht|ist|deutsch|ein|einen|geht|ihnen|bitte|sprechen|guten|abend|tschüss)\b/u.test(value)) return 'de';
  if (/[a-z]/u.test(value)) return 'en';
  return 'ar';
}
function defaultVoiceForText(text, requestedVoice) {
  const requested = String(requestedVoice || '').trim();
  // The historical default voice should follow the language of the actual text.
  // Explicitly selected non-default voices are respected.
  if (requested && requested !== EDGE_DEFAULT_VOICE) return requested;
  const language = detectSpeechLanguage(text);
  return ({ ar: EDGE_DEFAULT_VOICE, en: 'en-US-JennyNeural', fr: 'fr-FR-DeniseNeural', de: 'de-DE-KatjaNeural', es: 'es-ES-ElviraNeural' })[language] || EDGE_DEFAULT_VOICE;
}
const VOICE_STYLE_PRESETS = Object.freeze({
  natural: { rate: 0, pitch: 0, volume: 0, noiseScale: 0, noiseWidth: 0 },
  calm: { rate: -12, pitch: -3, volume: -3, noiseScale: -0.08, noiseWidth: -0.04 },
  warm: { rate: -5, pitch: 2, volume: 3, noiseScale: 0.04, noiseWidth: 0.03 },
  energetic: { rate: 14, pitch: 4, volume: 6, noiseScale: 0.10, noiseWidth: 0.08 },
  formal: { rate: -8, pitch: -2, volume: 0, noiseScale: -0.03, noiseWidth: 0 },
  friendly: { rate: 4, pitch: 2, volume: 3, noiseScale: 0.05, noiseWidth: 0.04 },
});
function resolveVoiceTuning({ style = 'natural', rate = 0, pitch = 0, volume = 0, noiseScale = 0.667, noiseWidth = 0.8 } = {}) {
  const preset = VOICE_STYLE_PRESETS[String(style || 'natural')] || VOICE_STYLE_PRESETS.natural;
  return {
    style: VOICE_STYLE_PRESETS[String(style || 'natural')] ? String(style) : 'natural',
    rate: Math.max(-40, Math.min(40, Math.round((Number(rate) || 0) + preset.rate))),
    pitch: Math.max(-30, Math.min(30, Math.round((Number(pitch) || 0) + preset.pitch))),
    volume: Math.max(-30, Math.min(30, Math.round((Number(volume) || 0) + preset.volume))),
    noiseScale: Math.max(0.1, Math.min(1.5, (Number(noiseScale) || 0.667) + preset.noiseScale)),
    noiseWidth: Math.max(0.1, Math.min(1.5, (Number(noiseWidth) || 0.8) + preset.noiseWidth)),
  };
}
function resolveFromRoot(root, value, fallback = '') {
  const raw = String(value || fallback || '').trim();
  if (!raw) return '';
  if (path.isAbsolute(raw) || /^[A-Za-z]:[\\/]/.test(raw)) return raw;
  // Executable names such as `ffmpeg` and `piper` must remain PATH-resolved;
  // relative paths like tools/piper/piper.exe are resolved against the project.
  return /[\\/]/.test(raw) ? path.resolve(root, raw) : raw;
}
function normalizeSpeechText(value) {
  return String(value || '').normalize('NFC').replace(/\u0000/g, '').replace(/\r\n?/g, '\n')
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/!?\[[^\]]*\]\((https?:\/\/[^)]+)\)/g, 'رابط مرفق')
    .replace(/https?:\/\/\S+/giu, 'رابط')
    .replace(/[*_~>#|]/g, ' ')
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, ' ')
    .replace(/[ \t]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{3,}/g, '\n\n')
    .replace(/\s+([،؛.!؟,:])/g, '$1').replace(/([،؛:])(?=\S)/g, (match, punctuation, offset, source) => punctuation === ':' && /\d/.test(source[offset - 1] || '') && /\d/.test(source[offset + 1] || '') ? punctuation : `${punctuation} `)
    .trim();
}
function textTokensForPreservation(text) {
  return [...String(text || '').matchAll(/(?:\d{1,4}:\d{2}(?::\d{2})?|\d+(?:[.,٫٬]\d+)*|https?:\/\/\S+|[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})/g)].map(m => m[0]);
}
function normalizeGrammarCandidate(candidate, original) {
  const clean = normalizeSpeechText(candidate);
  if (!clean || clean.length > MAX_SPEECH_CHARS) return { text: original, used: false, reason: 'empty-or-too-long' };
  const before = textTokensForPreservation(original), after = textTokensForPreservation(clean);
  if (before.length !== after.length || before.some((token, i) => token !== after[i])) return { text: original, used: false, reason: 'protected-token-changed' };
  if (clean.length < original.length * 0.45 && original.length > 100) return { text: original, used: false, reason: 'content-may-have-been-omitted' };
  return { text: clean, used: true, reason: '' };
}

class TextToSpeech {
  constructor({ env = process.env, root = path.resolve(__dirname, '..'), spawnImpl = nodeSpawn, execFileImpl = execFileDefault, fetchImpl = globalThis.fetch, localLlm = null, tempRoot = os.tmpdir() } = {}) {
    this.env = env; this.root = root; this.spawn = spawnImpl; this.execFile = execFileImpl; this.fetch = fetchImpl; this.localLlm = localLlm; this.tempRoot = tempRoot;
  }
  config(backendOverride = '') {
    const exe = process.platform === 'win32' ? 'piper.exe' : 'piper';
    const rawBackend = String(backendOverride || this.env.TTS_BACKEND || 'auto').trim().toLowerCase();
    const backend = ['auto', 'edge-tts', 'openai-compatible', 'local'].includes(rawBackend) ? rawBackend : 'auto';
    const configuredPython = String(this.env.VOICE_PYTHON_BIN || '').trim();
    const localPython = path.join(this.root, '.voice-venv', process.platform === 'win32' ? path.join('Scripts', 'python.exe') : path.join('bin', 'python'));
    const pythonBinary = resolveFromRoot(this.root, configuredPython, fs.existsSync(localPython) ? localPython : (process.platform === 'win32' ? 'python' : 'python3'));
    const configuredFfmpeg = String(this.env.FFMPEG_BIN || '').trim();
    const localFfmpeg = path.join(this.root, 'tools', 'ffmpeg', 'bin', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');
    const ffmpegBinary = configuredFfmpeg && !['ffmpeg', 'ffmpeg.exe'].includes(configuredFfmpeg.toLowerCase())
      ? resolveFromRoot(this.root, configuredFfmpeg, 'ffmpeg')
      : (fs.existsSync(localFfmpeg) ? localFfmpeg : (configuredFfmpeg || 'ffmpeg'));
    return {
      backend,
      binary: resolveFromRoot(this.root, this.env.PIPER_BIN, path.join('tools', 'piper', exe)),
      modelPath: resolveFromRoot(this.root, this.env.PIPER_MODEL_PATH, path.join('models', 'ar_JO-kareem-medium.onnx')),
      ffmpegBinary, pythonBinary, voiceWorker: path.join(this.root, 'scripts', 'voice_worker.py'), root: this.root,
    };
  }
  async commandExists(command) {
    if (!command) return false;
    if (path.isAbsolute(command) || /[\\/]/.test(command)) return fs.existsSync(command) && fs.statSync(command).isFile();
    try { await this.execFile(process.platform === 'win32' ? 'where.exe' : 'which', [command], { timeout: 2500, windowsHide: true }); return true; } catch { return false; }
  }
  async status({ backend = '', voice = '' } = {}) {
    const cfg = this.config(backend);
    if (cfg.backend === 'auto') {
      const [edge, local] = await Promise.all([this.status({ backend: 'edge-tts', voice }), this.status({ backend: 'local', voice })]);
      const active = edge.ready ? 'edge-tts' : (local.ready ? 'local' : 'edge-tts');
      const selected = active === 'edge-tts' ? edge : local;
      return { ...selected, backend: 'auto', mode: 'auto', activeBackend: active, ready: edge.ready || local.ready, edgeTtsReady: edge.ready, localReady: local.ready, ffmpegReady: edge.ffmpegReady || local.ffmpegReady, language: voiceLanguage(voice), voice: String(voice || EDGE_DEFAULT_VOICE), message: (edge.ready || local.ready) ? `الصوت التلقائي جاهز: ${edge.ready ? 'سيجرب الصوت العصبي عبر الإنترنت أولًا' : 'سيستخدم الصوت المحلي'}. ${local.ready ? 'البديل المحلي العربي جاهز.' : 'البديل المحلي غير جاهز.'}` : `النطق التلقائي غير جاهز. ${edge.message} ${local.message}` };
    }
    const ffmpegReady = await this.commandExists(cfg.ffmpegBinary);
    if (cfg.backend === 'edge-tts') {
      let pythonReady = false, edgeTtsAvailable = false, workerMessage = '';
      try { pythonReady = await this.commandExists(cfg.pythonBinary); } catch {}
      if (pythonReady && fs.existsSync(cfg.voiceWorker)) {
        try {
          const result = await this.execFile(cfg.pythonBinary, [cfg.voiceWorker, 'status'], { timeout: 15000, maxBuffer: 512 * 1024, windowsHide: true });
          const line = String(result.stdout || '').trim().split(/\r?\n/).filter(Boolean).at(-1) || '{}';
          edgeTtsAvailable = JSON.parse(line).edgeTtsAvailable === true;
        } catch (error) { workerMessage = String(error?.message || error).slice(0, 160); }
      }
      const ready = pythonReady && edgeTtsAvailable && ffmpegReady;
      return {
        ready, binaryReady: pythonReady, modelReady: edgeTtsAvailable, ffmpegReady, language: voiceLanguage(voice),
        voice: String(voice || EDGE_DEFAULT_VOICE), mode: 'edge-tts', backend: 'edge-tts',
        edgeTtsAvailable, message: ready
          ? 'صوت عصبي عربي عبر الإنترنت جاهز. هذا الوضع يرسل نص الكلام إلى خدمة Edge TTS؛ اختره صراحةً فقط إذا كنت موافقًا على الإرسال الخارجي.'
          : `النطق العصبي عبر الإنترنت يحتاج Python وحزمة edge-tts وFFmpeg. ${!pythonReady ? 'بيئة Python غير موجودة. ' : ''}${pythonReady && !edgeTtsAvailable ? 'حزمة edge-tts غير مثبتة. ' : ''}${!ffmpegReady ? 'لم يُعثر على FFmpeg أو النسخة المرفقة. ' : ''}${workerMessage}`,
        privacyNotice: 'النص الذي سيتم نطقه يُرسل إلى خدمة Edge TTS عبر الإنترنت عندما تختار هذا الوضع.',
      };
    }
    if (cfg.backend === 'openai-compatible') {
      const endpoint = String(this.env.TTS_API_URL || 'https://api.openai.com/v1/audio/speech').trim();
      const key = String(this.env.TTS_API_KEY || this.env.OPENAI_API_KEY || '').trim();
      let endpointValid = false; try { const u = new URL(endpoint); endpointValid = u.protocol === 'https:' || ['localhost','127.0.0.1','::1'].includes(u.hostname); } catch {}
      const ready = Boolean(key && endpointValid && typeof this.fetch === 'function' && ffmpegReady);
      return { ready, binaryReady: false, modelReady: Boolean(key && endpointValid), ffmpegReady, language: 'ar', voice: String(this.env.TTS_API_VOICE || 'alloy'), mode: 'openai-compatible', message: ready ? 'النطق عبر API خارجي مفعّل صراحةً؛ سيُرسل النص إلى المزود المحدد. FFmpeg جاهز لتحويل الصوت.' : 'وضع النطق الخارجي غير مكتمل: تحقق من TTS_API_KEY/OPENAI_API_KEY ورابط HTTPS أو localhost وتوفر FFmpeg.' };
    }
    const [binaryReady] = await Promise.all([this.commandExists(cfg.binary)]);
    const modelReady = Boolean(cfg.modelPath && fs.existsSync(cfg.modelPath) && fs.statSync(cfg.modelPath).isFile() && fs.statSync(cfg.modelPath).size > 10 * 1024 * 1024);
    return { ready: binaryReady && modelReady && ffmpegReady, binaryReady, modelReady, ffmpegReady, language: 'ar', voice: 'ar_JO-kareem-medium', mode: 'local', backend: 'local',
      message: binaryReady && modelReady && ffmpegReady ? 'النطق العربي المحلي جاهز لإنتاج الصوت وإرساله كرسالة صوتية.' : `محرك Piper: ${binaryReady ? 'موجود' : 'غير موجود'}؛ نموذج العربية: ${modelReady ? 'موجود' : 'غير موجود'}. شغّل SETUP-TTS-WINDOWS.bat لإعدادهما.` };
  }
  async prepareText(text, { proofread = true, model = 'qwen2.5:3b', timeoutMs = 18000 } = {}) {
    const original = normalizeSpeechText(text);
    if (!original) throw new Error('لا يوجد نص صالح لتحويله إلى كلام.');
    if (original.length > MAX_SPEECH_CHARS || String(text || '').length > 10000) throw new Error('النص طويل جدًا؛ اختصر الرد إلى 1800 حرف كحد أقصى للنطق.');
    if (!proofread || !this.localLlm) return { text: original, proofreadUsed: false, proofreadReason: proofread ? 'local-llm-unavailable' : 'disabled' };
    try {
      const language = detectSpeechLanguage(original);
      const prompts = {
        ar: 'أنت مدقق لغوي عربي دقيق. صحح الإملاء والنحو وعلامات الترقيم فقط. لا تترجم النص ولا تلخصه ولا تضف معلومات. حافظ على الأسماء والأرقام والتواريخ والروابط والحقائق والمعنى. أخرج النص المصحح وحده بلا مقدمات أو Markdown.',
        en: 'You are a careful English proofreader. Correct spelling, grammar and punctuation only. Do not translate, summarize or add facts. Preserve names, numbers, dates, URLs and meaning. Return only the corrected text without a preface or Markdown.',
        fr: 'Vous êtes un correcteur français rigoureux. Corrigez uniquement l’orthographe, la grammaire et la ponctuation. Ne traduisez pas, ne résumez pas et n’ajoutez aucune information. Préservez les noms, nombres, dates, URL et le sens. Retournez seulement le texte corrigé.',
        de: 'Du bist ein sorgfältiger deutscher Korrektor. Korrigiere nur Rechtschreibung, Grammatik und Zeichensetzung. Übersetze oder fasse nicht zusammen und füge keine Fakten hinzu. Bewahre Namen, Zahlen, Daten, URLs und Bedeutung. Gib nur den korrigierten Text aus.'
      };
      const candidate = await this.localLlm.generate({ model, timeoutMs, maxTokens: 420,
        system: prompts[language] || prompts.en,
        messages: [{ role: 'user', content: original }] });
      const checked = normalizeGrammarCandidate(candidate, original);
      return { text: checked.text, proofreadUsed: checked.used, proofreadReason: checked.reason };
    } catch (error) {
      return { text: original, proofreadUsed: false, proofreadReason: `local-review-unavailable: ${String(error?.message || error).slice(0, 160)}` };
    }
  }
  async generate(text, { proofread = true, model = 'qwen2.5:3b', timeoutMs = 18000, backend = '', voice = '', style = 'natural', rate = 0, pitch = 0, volume = 0, noiseScale = 0.667, noiseWidth = 0.8 } = {}) {
    const cfg = this.config(backend);
    const tuning = resolveVoiceTuning({ style, rate, pitch, volume, noiseScale, noiseWidth });
    if (cfg.backend === 'auto') {
      const selectedVoice = defaultVoiceForText(text, voice || this.env.TTS_API_VOICE || EDGE_DEFAULT_VOICE);
      const candidates = [];
      const edgeStatus = await this.status({ backend: 'edge-tts', voice: selectedVoice });
      if (edgeStatus.ready) candidates.push('edge-tts');
      // Piper in this distribution has an Arabic voice only, so never use it as
      // a false fallback for English/French/German text.
      if (voiceLanguage(selectedVoice) === 'ar') {
        const localStatus = await this.status({ backend: 'local' });
        if (localStatus.ready) candidates.push('local');
      }
      if (!candidates.length) {
        const detail = edgeStatus.message || 'خدمة النطق العصبي غير متاحة.';
        throw new Error(`تعذر بدء النطق التلقائي. ${detail} ${voiceLanguage(selectedVoice) === 'ar' ? 'ويحتاج البديل المحلي العربي إلى Piper والنموذج وFFmpeg.' : 'لهذه اللغة يلزم اتصال إنترنت بخدمة النطق أو مزود متوافق.'}`);
      }
      let lastError;
      for (const candidate of candidates) {
        try { return await this.generate(text, { proofread, model, timeoutMs, backend: candidate, voice: selectedVoice, style, rate, pitch, volume, noiseScale, noiseWidth }); }
        catch (error) { lastError = error; }
      }
      throw new Error(`فشلت محركات النطق المتاحة. ${String(lastError?.message || 'خطأ غير معروف').slice(0, 360)}`);
    }
    const status = await this.status({ backend: cfg.backend, voice });
    if (!status.ready) throw new Error(status.message || 'محرك النطق غير جاهز.');
    const prepared = await this.prepareText(text, { proofread, model, timeoutMs });
    const dir = fs.mkdtempSync(path.join(this.tempRoot, 'chatbot-tts-'));
    const wavPath = path.join(dir, `speech-${crypto.randomUUID()}.wav`);
    try {
      if (cfg.backend === 'edge-tts') {
        const audioPath = path.join(dir, `speech-${crypto.randomUUID()}.mp3`);
        const selectedVoice = defaultVoiceForText(text, voice || this.env.TTS_API_VOICE || EDGE_DEFAULT_VOICE);
        const args = [cfg.voiceWorker, 'edge-tts', audioPath, selectedVoice, String(tuning.rate), String(tuning.pitch), String(tuning.volume)];
        await this.runPythonWorker(cfg, args, prepared.text, Math.max(15000, Math.min(120000, Number(this.env.TTS_TIMEOUT_MS) || 60000)));
        const stat = fs.statSync(audioPath);
        if (!stat.isFile() || stat.size < 100) throw new Error('لم ينتج محرك Edge TTS ملف MP3 صالحًا.');
        return { ...prepared, wavPath: audioPath, audioPath, directory: dir, bytes: stat.size, voice: selectedVoice, language: voiceLanguage(selectedVoice), mimeType: 'audio/mpeg', backend: 'edge-tts', style: tuning.style, rate: tuning.rate, pitch: tuning.pitch, volume: tuning.volume };
      }
      if (cfg.backend === 'openai-compatible') {
        const endpoint = String(this.env.TTS_API_URL || 'https://api.openai.com/v1/audio/speech').trim();
        const key = String(this.env.TTS_API_KEY || this.env.OPENAI_API_KEY || '').trim();
        let url; try { url = new URL(endpoint); } catch { throw new Error('رابط خدمة النطق غير صالح.'); }
        if (!(url.protocol === 'https:' || ['localhost','127.0.0.1','::1'].includes(url.hostname))) throw new Error('لأمان النصوص، يجب أن يكون رابط النطق HTTPS أو localhost.');
        let response;
        try { response = await this.fetch(url, { method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: String(this.env.TTS_API_MODEL || 'tts-1').slice(0, 100), voice: String(this.env.TTS_API_VOICE || 'alloy').slice(0, 80), input: prepared.text, response_format: 'wav' }), signal: AbortSignal.timeout(Math.max(10000, Math.min(120000, Number(this.env.TTS_TIMEOUT_MS) || 45000))) }); }
        catch (error) { throw new Error(`فشل الاتصال بخدمة النطق الخارجية: ${String(error?.message || error).slice(0, 180)}.`); }
        if (!response.ok) { let detail = ''; try { detail = (await response.text()).slice(0, 240); } catch {} throw new Error(`خدمة النطق أعادت HTTP ${response.status}: ${detail.replace(/Bearer\s+\S+/gi, '[مخفي]').replace(/https?:\/\/\S+/g, '[رابط]')}`); }
        const bytes = Buffer.from(await response.arrayBuffer());
        if (bytes.length < 128 || bytes.length > 50 * 1024 * 1024) throw new Error('حجم الصوت الذي أعادته الخدمة غير صالح.');
        fs.writeFileSync(wavPath, bytes, { flag: 'wx', mode: 0o600 });
        return { ...prepared, wavPath, directory: dir, bytes: bytes.length, voice: String(this.env.TTS_API_VOICE || 'alloy'), language: voiceLanguage(voice), mimeType: 'audio/wav', backend: 'openai-compatible' };
      }
      await new Promise((resolve, reject) => {
        let settled = false;
        let timer = null;
        const finish = error => { if (settled) return; settled = true; if (timer) clearTimeout(timer); error ? reject(error) : resolve(); };
        let child;
        const ratePct = tuning.rate;
        const lengthScale = Math.max(0.714, Math.min(1.667, 1 / (1 + ratePct / 100)));
        const nScale = tuning.noiseScale;
        const nWidth = tuning.noiseWidth;
        try { child = this.spawn(cfg.binary, ['--model', cfg.modelPath, '--output_file', wavPath, '--length_scale', String(lengthScale), '--noise_scale', String(nScale), '--noise_w', String(nWidth)], { cwd: cfg.root, windowsHide: true, stdio: ['pipe', 'ignore', 'pipe'] }); }
        catch (error) { finish(error); return; }
        let stderr = '';
        child.stderr?.on('data', chunk => { stderr = (stderr + String(chunk)).slice(-4000); });
        child.once('error', error => finish(new Error(`تعذر تشغيل Piper: ${String(error?.message || error).slice(0, 200)}`)));
        child.once('close', code => {
          if (code !== 0) return finish(new Error(`فشل توليد الكلام (رمز ${code}): ${stderr.slice(-700)}`));
          try { const stat = fs.statSync(wavPath); if (stat.size < 128 || stat.size > 50 * 1024 * 1024) throw new Error('حجم ملف الصوت الناتج غير صالح.'); }
          catch (error) { return finish(error); }
          finish();
        });
        timer = setTimeout(() => { try { child.kill('SIGTERM'); } catch {} finish(new Error('انتهت مهلة تحويل النص إلى كلام. جرّب ردًا أقصر أو افحص موارد الجهاز.')); }, Math.max(5000, Math.min(120000, Number(this.env.TTS_TIMEOUT_MS) || 45000)));
        child.stdin.on('error', error => finish(new Error(`تعذر تمرير النص إلى محرك النطق: ${String(error?.message || error).slice(0, 150)}`)));
        child.stdin.end(prepared.text + '\n');
      });
      return { ...prepared, wavPath, audioPath: wavPath, directory: dir, bytes: fs.statSync(wavPath).size, voice: 'ar_JO-kareem-medium', language: voiceLanguage(voice), mimeType: 'audio/wav', backend: 'local', style: tuning.style, rate: tuning.rate, pitch: tuning.pitch, volume: tuning.volume, noiseScale: tuning.noiseScale, noiseWidth: tuning.noiseWidth };
    } catch (error) {
      try { fs.rmSync(dir, { recursive: true, force: true }); } catch {}
      throw error;
    }
  }
  async runPythonWorker(cfg, args, inputText = '', timeoutMs = 60000) {
    if (!await this.commandExists(cfg.pythonBinary)) throw new Error('بيئة Python الخاصة بالصوت لم تكتمل بعد. انتظر التهيئة التلقائية عند بدء المشروع، ثم راجع حالة الصوت في لوحة التحكم إذا استمر الخطأ.');
    if (!fs.existsSync(cfg.voiceWorker)) throw new Error('scripts/voice_worker.py غير موجود؛ أعد فك المشروع كاملًا.');
    return new Promise((resolve, reject) => {
      let settled = false, stdout = '', stderr = '', timer;
      const finish = error => { if (settled) return; settled = true; if (timer) clearTimeout(timer); error ? reject(error) : resolve({ stdout, stderr }); };
      let child;
      try { child = this.spawn(cfg.pythonBinary, args, { cwd: cfg.root, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] }); }
      catch (error) { finish(new Error(`تعذر تشغيل مكتبة الصوت Python: ${String(error?.message || error).slice(0, 220)}`)); return; }
      child.stdout?.on('data', chunk => { stdout = (stdout + String(chunk)).slice(-1024 * 1024); });
      child.stderr?.on('data', chunk => { stderr = (stderr + String(chunk)).slice(-8000); });
      child.once('error', error => finish(new Error(`تعذر تشغيل محرك Python الصوتي: ${String(error?.message || error).slice(0, 220)}`)));
      child.once('close', code => {
        const line = stdout.trim().split(/\r?\n/).filter(Boolean).at(-1) || '';
        let payload = null; try { payload = JSON.parse(line); } catch {}
        if (code !== 0 || payload?.ok === false) return finish(new Error(String(payload?.error || stderr || `فشل محرك الصوت (رمز ${code}).`).replace(/https?:\/\/\S+/g, '[رابط خدمة]').slice(0, 500)));
        if (!payload?.ok) return finish(new Error('استجابة غير معروفة من محرك الصوت Python.'));
        finish();
      });
      timer = setTimeout(() => { try { child.kill('SIGTERM'); } catch {} finish(new Error('انتهت مهلة توليد الصوت. تحقق من اتصال الإنترنت أو جرّب نصًا أقصر.')); }, timeoutMs);
      child.stdin?.on('error', error => finish(new Error(`تعذر تمرير النص إلى محرك الصوت: ${String(error?.message || error).slice(0, 150)}`)));
      child.stdin?.end(String(inputText || '') + '\n');
    });
  }
  async toWhatsAppVoice(wavPath, { volume = 0, pitch = 0 } = {}) {
    const cfg = this.config();
    if (!wavPath || !fs.existsSync(wavPath) || !fs.statSync(wavPath).isFile()) throw new Error('ملف الصوت الناتج غير موجود.');
    if (!await this.commandExists(cfg.ffmpegBinary)) throw new Error('يلزم FFmpeg لتحويل WAV إلى OGG/Opus قبل إرساله كرسالة صوتية. شغّل أداة إعداد الصوت وتأكد من FFMPEG_BIN.');
    const output = path.join(path.dirname(wavPath), `voice-${crypto.randomUUID()}.ogg`);
    try {
      const volumePct = Math.max(-30, Math.min(30, Number(volume) || 0));
      const volumeScalar = Math.max(0.1, Math.min(2, 1 + volumePct / 100));
      // Piper has no native pitch argument. For the local WAV, shift pitch slightly
      // and compensate with atempo so the duration does not drift significantly.
      const pitchCents = Math.max(-30, Math.min(30, Number(pitch) || 0)) * 2;
      const pitchFactor = Math.pow(2, pitchCents / 1200);
      const filters = [];
      if (Math.abs(pitchCents) > 0.5) filters.push(`aresample=48000,asetrate=${(48000 * pitchFactor).toFixed(1)},aresample=48000,atempo=${(1 / pitchFactor).toFixed(5)}`);
      filters.push(`volume=${volumeScalar.toFixed(2)}`);
      await this.execFile(cfg.ffmpegBinary, ['-y', '-i', wavPath, '-vn', '-ac', '1', '-ar', '48000', '-af', filters.join(','), '-c:a', 'libopus', '-b:a', '32k', '-vbr', 'on', output], { timeout: 90000, maxBuffer: 1024 * 1024, windowsHide: true });
      const stat = fs.statSync(output);
      if (!stat.isFile() || stat.size < 100) throw new Error('لم ينتج FFmpeg ملف OGG/Opus صالحًا.');
      return output;
    } catch (error) {
      try { fs.rmSync(output, { force: true }); } catch {}
      throw new Error(`تعذر تجهيز الصوت كرسالة WhatsApp صوتية: ${String(error?.message || error).slice(0, 400)}`);
    }
  }
  cleanup(result) { const dir = String(result?.directory || (result?.wavPath ? path.dirname(result.wavPath) : '')); if (dir && path.basename(dir).startsWith('chatbot-tts-')) { try { fs.rmSync(dir, { recursive: true, force: true }); return true; } catch {} } return false; }
}

module.exports = { TextToSpeech, MAX_SPEECH_CHARS, normalizeSpeechText, normalizeGrammarCandidate, textTokensForPreservation, resolveFromRoot, VOICE_STYLE_PRESETS, resolveVoiceTuning, voiceLanguage, detectSpeechLanguage, defaultVoiceForText };
