'use strict';

// Local-first Integration Hub. It never runs arbitrary shell commands or destructive API methods.
// A test is marked PASS only when a local validation or explicit evidence supports that claim.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const execFileAsync = promisify(execFile);
const MAX_SPEC_BYTES = 1024 * 1024;
const MAX_RESPONSE_BYTES = 1024 * 1024;
const HTTP_TIMEOUT_MS = 6500;
const COMMANDS = Object.freeze({
  node: { bin: 'node', args: ['--version'], label: 'Node.js' },
  npm: { bin: 'npm', args: ['--version'], label: 'npm' },
  python: { bin: process.platform === 'win32' ? 'python' : 'python3', args: ['--version'], label: 'Python' },
  git: { bin: 'git', args: ['--version'], label: 'Git' },
  ollama: { bin: 'ollama', args: ['--version'], label: 'Ollama المحلي' },
  curl: { bin: 'curl', args: ['--version'], label: 'curl' },
});
const TYPES = Object.freeze(['http', 'openapi', 'folder', 'command', 'database', 'webhook']);
const FAMILIES = Object.freeze([
  ['health', 'فحص التوفر', 'http.health', 'probe'],
  ['http-status', 'رموز HTTP', 'http.read', 'probe'],
  ['headers', 'ترويسات الاستجابة', 'http.headers', 'probe'],
  ['tls', 'اتصال HTTPS', 'http.tls', 'probe'],
  ['content-type', 'نوع المحتوى', 'http.read', 'probe'],
  ['latency', 'زمن الاستجابة', 'http.read', 'probe'],
  ['redirects', 'التحويلات', 'http.redirects', 'probe'],
  ['response-size', 'حجم الاستجابة', 'http.read', 'probe'],
  ['openapi', 'مواصفات OpenAPI', 'openapi.read', 'evidence'],
  ['get-endpoints', 'مسارات القراءة GET', 'openapi.paths', 'evidence'],
  ['auth', 'حالة المصادقة', 'http.auth', 'evidence'],
  ['rate-limit', 'حدود الطلبات', 'http.rate_limit', 'evidence'],
  ['errors', 'تنسيق الأخطاء', 'http.errors', 'evidence'],
  ['pagination', 'تقسيم النتائج إلى صفحات', 'api.pagination', 'evidence'],
  ['filtering', 'تصفية النتائج', 'api.filtering', 'evidence'],
  ['sorting', 'ترتيب النتائج', 'api.sorting', 'evidence'],
  ['folder', 'قراءة المجلد', 'folder.read', 'adapter'],
  ['command', 'فحص البرامج المحلية', 'command.run', 'adapter'],
  ['database', 'فحص قاعدة البيانات للقراءة فقط', 'database.read', 'adapter'],
  ['safety', 'حواجز الأمان والتكرار', 'hub.safety', 'local'],
]);
const TEST_CATALOG = FAMILIES.flatMap(([family, label, capability, mode], familyIndex) => Array.from({ length: 16 }, (_, caseIndex) => ({
  id: `${String(familyIndex + 1).padStart(2, '0')}-${String(caseIndex + 1).padStart(2, '0')}`,
  family, label, capability, mode, variant: caseIndex + 1,
  title: `${label} — حالة ${String(caseIndex + 1).padStart(2, '0')}`,
  safety: caseIndex < 4 ? 'قراءة فقط' : caseIndex < 10 ? 'تحقق من الدليل' : 'مراجعة يدوية مطلوبة',
  manualReview: caseIndex >= 10,
})));
const RULE_TEMPLATES = Object.freeze([
  { id: 'http-health', name: 'راقب توفر الخدمة', description: 'افحص رمز الاستجابة عند التشغيل اليدوي أو حسب الموعد.', types: ['http','openapi'], capability: 'http.health', action: 'http_health' },
  { id: 'http-latency', name: 'راقب سرعة الاستجابة', description: 'سجّل الوقت المستغرق في قراءة العنوان.', types: ['http','openapi'], capability: 'http.read', action: 'http_latency' },
  { id: 'http-headers', name: 'افحص ترويسات الأمان', description: 'اعرض الترويسات المتاحة مثل HSTS وCSP دون تغيير الخدمة.', types: ['http','openapi'], capability: 'http.headers', action: 'http_security_headers' },
  { id: 'http-content', name: 'تحقق من نوع المحتوى', description: 'نبّهك إذا تغيّر نوع المحتوى الظاهر.', types: ['http','openapi'], capability: 'http.read', action: 'http_content_type' },
  { id: 'http-errors', name: 'راقب أخطاء الخدمة', description: 'يسجّل رموز HTTP غير الناجحة دون إعادة إرسال أي شيء.', types: ['http','openapi'], capability: 'http.read', action: 'http_health' },
  { id: 'http-redirect', name: 'راجع التحويلات', description: 'افحص ما إذا كان العنوان يتحول إلى عنوان آخر.', types: ['http','openapi'], capability: 'http.redirects', action: 'http_redirects' },
  { id: 'http-tls', name: 'تأكد من استخدام HTTPS', description: 'يتحقق من أن العنوان يبدأ بـ HTTPS.', types: ['http','openapi'], capability: 'http.tls', action: 'http_tls' },
  { id: 'openapi-summary', name: 'لخّص مواصفات API', description: 'اعرض المسارات والطرق الموجودة في OpenAPI.', types: ['http','openapi'], capability: 'openapi.read', action: 'openapi_report' },
  { id: 'openapi-get', name: 'راجع مسارات القراءة', description: 'يسرد مسارات GET فقط من المواصفات المكتشفة.', types: ['http','openapi'], capability: 'openapi.paths', action: 'openapi_get_list' },
  { id: 'api-auth', name: 'راقب الحاجة للمصادقة', description: 'يعرض ما إذا كانت الخدمة طلبت تسجيل الدخول في الفحص.', types: ['http','openapi'], capability: 'http.auth', action: 'http_health' },
  { id: 'api-limit', name: 'راجع حدود الطلبات', description: 'يعرض ترويسات Rate Limit إن ظهرت.', types: ['http','openapi'], capability: 'http.rate_limit', action: 'http_security_headers' },
  { id: 'api-schema', name: 'راجع سلامة ملف المواصفات', description: 'تحقق من وجود مسارات قابلة للقراءة داخل المواصفات.', types: ['http','openapi'], capability: 'openapi.read', action: 'openapi_report' },
  { id: 'folder-list', name: 'اعرض الملفات الجديدة', description: 'يعرض أحدث أسماء الملفات فقط، ولا يفتحها أو يحذفها.', types: ['folder'], capability: 'folder.read', action: 'folder_list' },
  { id: 'folder-exists', name: 'تأكد من وجود المجلد', description: 'تحقق من إمكانية الوصول للمجلد المختار.', types: ['folder'], capability: 'folder.read', action: 'folder_list' },
  { id: 'folder-count', name: 'راقب عدد الملفات', description: 'يسجل عدد عناصر المجلد عند كل فحص.', types: ['folder'], capability: 'folder.list', action: 'folder_list' },
  { id: 'command-node', name: 'افحص إصدار Node.js', description: 'يشغّل أمر إصدار ثابتًا دون shell أو معاملات حرة.', types: ['command'], capability: 'command.run', action: 'command_version' },
  { id: 'command-tool', name: 'افحص إصدار البرنامج المختار', description: 'يفحص برنامجًا من قائمة أوامر آمنة محددة.', types: ['command'], capability: 'command.run', action: 'command_version' },
  { id: 'database-read', name: 'افحص بنية قاعدة البيانات', description: 'يقرأ أسماء الجداول أو عينة صفوف JSON/CSV بوضع القراءة فقط.', types: ['database'], capability: 'database.read', action: 'database_inspect' },
  { id: 'webhook-events', name: 'راجع استقبال Webhook', description: 'يعرض عدد آخر إشعارات الواردة لهذا الرابط.', types: ['webhook'], capability: 'webhook.receive', action: 'webhook_report' },
  { id: 'local-audit', name: 'احفظ ملخص الفحص في السجل', description: 'يضيف نتيجة الفحص إلى سجل التكاملات المحلي.', types: TYPES, capability: 'hub.safety', action: 'local_audit' },
]);
const defaultData = () => ({ schemaVersion: 2, connections: [], rules: [], runs: [], inbox: [], devices: [], agentEnrollments: [], agentTasks: [], plugins: [], settings: { whatsappNotificationsEnabled: false, whatsappTarget: '' } });
const isoNow = () => new Date().toISOString();
const id = prefix => `${prefix}_${crypto.randomUUID()}`;
const clamp = (n, min, max, fallback) => Number.isFinite(Number(n)) ? Math.max(min, Math.min(max, Math.floor(Number(n)))) : fallback;
function sanitizeError(error) { return String(error?.message || error || 'تعذر إكمال العملية.').replace(/(authorization|cookie|token|api[_-]?key|password|secret)\s*[:=]\s*[^\s,;]+/ig, '$1=[مخفي]').slice(0, 500); }
function parseOpenApi(source) {
  const text = String(source || '').slice(0, MAX_SPEC_BYTES);
  if (!text.trim()) return null;
  try {
    const json = JSON.parse(text);
    if (!json || typeof json !== 'object' || !json.paths || typeof json.paths !== 'object') return null;
    const paths = [];
    for (const [route, methods] of Object.entries(json.paths)) {
      for (const [method, operation] of Object.entries(methods || {})) if (['get','head','options','post','put','patch','delete'].includes(method.toLowerCase())) paths.push({ path: route, method: method.toUpperCase(), operationId: String(operation?.operationId || '').slice(0, 120), summary: String(operation?.summary || '').slice(0, 240) });
    }
    return { format: 'json', version: String(json.openapi || json.swagger || 'unknown'), title: String(json.info?.title || 'OpenAPI'), paths, security: Boolean(json.security || Object.values(json.paths).some(p => Object.values(p || {}).some(op => op?.security))), servers: Array.isArray(json.servers) ? json.servers.slice(0, 10).map(s => String(s?.url || '').slice(0, 500)) : [] };
  } catch {}
  // A small, dependency-free YAML reader for the common OpenAPI shape. It extracts
  // method/path declarations only; full YAML anchors and advanced syntax need a YAML plugin.
  if (!/^(openapi|swagger)\s*:/m.test(text) || !/^paths\s*:/m.test(text)) return null;
  const paths = []; let inPaths = false; let currentPath = '';
  for (const line of text.split(/\r?\n/)) {
    if (/^paths\s*:/u.test(line)) { inPaths = true; continue; }
    if (inPaths && /^\S/u.test(line) && !/^paths\s*:/u.test(line)) break;
    if (!inPaths) continue;
    const pm = line.match(/^\s{2,}(['"]?\/(?:[^:'"\n]|:(?!\s))[^'"\n]*['"]?)\s*:\s*(?:#.*)?$/u);
    if (pm) { currentPath = pm[1].replace(/^['"]|['"]$/g, ''); continue; }
    const mm = line.match(/^\s{4,}(get|head|options|post|put|patch|delete)\s*:\s*(?:#.*)?$/iu);
    if (mm && currentPath) paths.push({ path: currentPath, method: mm[1].toUpperCase(), operationId: '', summary: '' });
  }
  return { format: 'yaml-partial', version: (text.match(/^(?:openapi|swagger)\s*:\s*([^\s]+)/m) || [])[1] || 'unknown', title: (text.match(/^\s*title\s*:\s*(.+)$/m) || [])[1]?.replace(/^['"]|['"]$/g, '') || 'OpenAPI YAML', paths, security: /^\s*security\s*:/m.test(text), servers: (text.match(/^\s*-\s*url\s*:\s*(.+)$/gm) || []).map(x => x.replace(/^\s*-\s*url\s*:\s*/, '').replace(/^['"]|['"]$/g, '')).slice(0, 10) };
}
function validateHttpUrl(value) {
  const raw = String(value || '').trim();
  if (!raw) throw new Error('أدخل رابط الموقع أو API.');
  let url; try { url = new URL(raw); } catch { throw new Error('الرابط غير صحيح؛ مثال: http://127.0.0.1:3000 أو https://example.com/api'); }
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('المسموح فقط هو HTTP أو HTTPS؛ لا تستخدم file:// أو بروتوكولًا آخر.');
  if (url.username || url.password) throw new Error('لا تضع اسم المستخدم أو كلمة المرور داخل الرابط.');
  if (url.href.length > 2000) throw new Error('الرابط طويل أكثر من الحد المسموح.');
  if (/([?&](?:token|api[_-]?key|secret|password|access_token)=)/i.test(url.search)) throw new Error('احذف مفاتيح السر من الرابط، وأضف المصادقة عبر إضافة آمنة لاحقًا.');
  url.hash = '';
  return url.toString();
}
function allowedByType(type, capability) {
  if (type === 'http') return capability.startsWith('http.') || capability.startsWith('openapi.') || capability.startsWith('api.') || capability === 'hub.safety';
  if (type === 'openapi') return capability.startsWith('http.') || capability.startsWith('openapi.') || capability.startsWith('api.') || capability === 'hub.safety';
  if (type === 'folder') return capability.startsWith('folder.') || capability === 'hub.safety';
  if (type === 'command') return capability.startsWith('command.') || capability === 'hub.safety';
  if (type === 'database') return capability.startsWith('database.') || capability === 'hub.safety';
  if (type === 'webhook') return capability.startsWith('webhook.') || capability === 'hub.safety';
  return false;
}
class IntegrationHub {
  constructor({ store, logger = () => {}, whatsapp = null } = {}) {
    if (!store) throw new Error('مخزن المشروع مطلوب لإنشاء مركز التكاملات.');
    this.store = store; this.logger = logger; this.whatsapp = whatsapp; this.runningRules = new Set(); this.timer = null; this.paused = false; this.scheduledTicks = 0;
  }
  fileFor(sessionId) { return path.join(this.store.getPaths(this.store.safeSessionId(sessionId)).dir, 'integrations.json'); }
  read(sessionId) {
    const file = this.fileFor(sessionId); fs.mkdirSync(path.dirname(file), { recursive: true });
    try { const data = JSON.parse(fs.readFileSync(file, 'utf8')); return { ...defaultData(), ...data, settings: { ...defaultData().settings, ...(data.settings || {}) }, connections: Array.isArray(data.connections) ? data.connections : [], rules: Array.isArray(data.rules) ? data.rules : [], runs: Array.isArray(data.runs) ? data.runs.slice(-500) : [], inbox: Array.isArray(data.inbox) ? data.inbox.slice(-500) : [], devices: Array.isArray(data.devices) ? data.devices.slice(-100) : [], agentEnrollments: Array.isArray(data.agentEnrollments) ? data.agentEnrollments.slice(-100) : [], agentTasks: Array.isArray(data.agentTasks) ? data.agentTasks.slice(-500) : [], plugins: Array.isArray(data.plugins) ? data.plugins.slice(-100) : [] }; }
    catch (error) { if (error.code !== 'ENOENT') { const backup = `${file}.corrupt-${Date.now()}`; try { fs.copyFileSync(file, backup); } catch {} this.logger(sessionId, 'WARN', `ملف التكاملات تالف وتم الاحتفاظ بنسخة للمراجعة: ${path.basename(backup)}`); } const clean = defaultData(); this.write(sessionId, clean); return clean; }
  }
  write(sessionId, data) {
    const file = this.fileFor(sessionId); fs.mkdirSync(path.dirname(file), { recursive: true }); data.updatedAt = isoNow();
    const temp = `${file}.tmp-${process.pid}-${crypto.randomBytes(4).toString('hex')}`; fs.writeFileSync(temp, JSON.stringify(data, null, 2), { mode: 0o600 }); fs.renameSync(temp, file); return data;
  }
  publicConnection(c) { const { hookTokenHash, secretHeadersEncrypted, ...rest } = c; return { ...rest, hasWebhookSecret: Boolean(hookTokenHash), hasCredentials: Boolean(secretHeadersEncrypted?.data) }; }
  vaultKeyFor(sessionId) { return path.join(this.store.getPaths(this.store.safeSessionId(sessionId)).dir, 'integration-vault.key'); }
  vaultKey(sessionId) {
    const file = this.vaultKeyFor(sessionId); fs.mkdirSync(path.dirname(file), { recursive: true });
    try { const key = fs.readFileSync(file); if (key.length === 32) return key; } catch (e) { if (e.code !== 'ENOENT') throw new Error('تعذر قراءة مفتاح خزنة التكاملات المحلية.'); }
    const key = crypto.randomBytes(32); try { fs.writeFileSync(file, key, { mode: 0o600, flag: 'wx' }); return key; } catch (e) { if (e.code === 'EEXIST') { const existing = fs.readFileSync(file); if (existing.length === 32) return existing; } throw new Error('تعذر إنشاء مفتاح خزنة التكاملات المحلية.'); }
  }
  validateHeaders(input = {}) {
    if (input === null || typeof input !== 'object' || Array.isArray(input)) throw new Error('ترويسات الدخول يجب أن تكون كائن JSON مثل {"Authorization":"Bearer ..."}.');
    const entries = Object.entries(input); if (entries.length > 20) throw new Error('الحد الأقصى 20 ترويسة سرية لكل اتصال.');
    const out = {};
    for (const [rawName, rawValue] of entries) {
      const name = String(rawName || '').trim(), value = String(rawValue ?? '');
      if (!/^[!#$%&'*+.^_`|~0-9A-Za-z-]{1,80}$/.test(name)) throw new Error(`اسم الترويسة غير صالح: ${name.slice(0,60)}.`);
      if (/^(host|content-length|connection|transfer-encoding|cookie|set-cookie|proxy-authorization|proxy-connection|upgrade|accept|user-agent)$/i.test(name) || /^(sec-|proxy-)/i.test(name)) throw new Error(`الترويسة ${name} غير مسموحة داخل خزنة الدخول.`);
      if (/[\r\n\u0000-\u001f\u007f]/.test(value) || Buffer.byteLength(value) > 2000) throw new Error(`قيمة الترويسة ${name} تحتوي على محارف غير آمنة أو طويلة جدًا.`);
      if (!value.trim()) continue;
      out[name] = value;
    }
    return out;
  }
  encryptSecrets(sessionId, headers) {
    const safe = this.validateHeaders(headers); if (!Object.keys(safe).length) return null;
    const iv = crypto.randomBytes(12), cipher = crypto.createCipheriv('aes-256-gcm', this.vaultKey(sessionId), iv);
    const data = Buffer.concat([cipher.update(JSON.stringify(safe), 'utf8'), cipher.final()]);
    return { v: 1, iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64'), data: data.toString('base64') };
  }
  decryptSecrets(sessionId, encrypted) {
    if (!encrypted?.data) return {};
    try { const decipher = crypto.createDecipheriv('aes-256-gcm', this.vaultKey(sessionId), Buffer.from(encrypted.iv, 'base64')); decipher.setAuthTag(Buffer.from(encrypted.tag, 'base64')); const raw = Buffer.concat([decipher.update(Buffer.from(encrypted.data, 'base64')), decipher.final()]).toString('utf8'); return this.validateHeaders(JSON.parse(raw)); }
    catch { throw new Error('تعذر فتح بيانات الدخول المحفوظة. قد يكون مفتاح الخزنة مفقودًا أو ملف البيانات تالفًا. لا تُنشئ مفتاحًا جديدًا قبل استعادة المفتاح الأصلي.'); }
  }
  connectionHeaders(sessionId, connection) { return this.decryptSecrets(sessionId, connection?.secretHeadersEncrypted); }
  updateCredentials(sessionId, connectionId, headers) {
    const data = this.read(sessionId), c = data.connections.find(x => x.id === connectionId); if (!c) throw new Error('التكامل غير موجود.');
    if (!['http','openapi'].includes(c.type)) throw new Error('ترويسات المصادقة مخصصة لاتصال موقع أو API.');
    c.secretHeadersEncrypted = this.encryptSecrets(sessionId, headers); c.updatedAt = isoNow(); this.write(sessionId, data);
    return { connection: this.publicConnection(c), message: c.secretHeadersEncrypted ? 'حُفظت بيانات الدخول مشفّرة في ملف التكاملات المحلي.' : 'تم حذف بيانات الدخول المحفوظة لهذا الاتصال.' };
  }
  overview(sessionId) {
    const data = this.read(sessionId);
    return { ok: true, catalog: { total: TEST_CATALOG.length, families: FAMILIES.length, casesPerFamily: 16 }, devices: data.devices.map(d => this.publicDevice(d)), plugins: data.plugins.map(p => this.publicPlugin(p)), agentTasks: data.agentTasks.slice(-30).reverse().map(t => this.publicTask(t)), templates: RULE_TEMPLATES.map(t => ({ ...t })), connections: data.connections.map(c => ({ ...this.publicConnection(c), templates: RULE_TEMPLATES.map(t => ({ ...t, supported: this.templateSupported(c, t), reason: this.templateSupported(c, t) ? 'النوع والدليل يسمحان بهذه القاعدة.' : this.templateReason(c, t) })) })), rules: data.rules.map(r => ({ ...r, supported: this.ruleSupported(data.connections.find(c => c.id === r.connectionId), r) })), runs: data.runs.slice(-20).reverse().map(({ results, ...run }) => ({ ...run, resultCount: Array.isArray(results) ? results.length : 0, preview: Array.isArray(results) ? results.slice(0, 5) : [] })), inbox: data.inbox.slice(-60).reverse(), settings: data.settings };
  }
  health(sessionId) {
    const data = this.read(sessionId);
    const connections = data.connections || [], devices = (data.devices || []).map(device => this.publicDevice(device));
    const rules = data.rules || [], runs = data.runs || [], tasks = data.agentTasks || [];
    const connectionCounts = connections.reduce((out, item) => { const status = String(item.status || 'new'); out[status] = (out[status] || 0) + 1; return out; }, {});
    const now = Date.now(), staleMs = 24 * 60 * 60 * 1000;
    const staleChecks = connections.filter(item => item.status !== 'new' && item.lastCheck && now - (Date.parse(item.lastCheck) || 0) > staleMs).length;
    const neverChecked = connections.filter(item => item.status === 'new' || !item.lastCheck && item.type !== 'webhook').length;
    const onlineDevices = devices.filter(item => item.status === 'online').length;
    const offlineDevices = devices.filter(item => item.status === 'offline').length;
    const revokedDevices = devices.filter(item => item.status === 'revoked').length;
    const enabledRules = rules.filter(item => item.enabled === true);
    const unsupportedEnabledRules = enabledRules.filter(rule => !this.ruleSupported(connections.find(c => c.id === rule.connectionId), rule)).length;
    const recentRuns = runs.slice(-100);
    const failedRuns = recentRuns.filter(run => Number(run.counts?.FAIL || 0) > 0 || run.status === 'failed').length;
    const failedTasks = tasks.filter(task => task.status === 'failed').length;
    const pendingTasks = tasks.filter(task => task.status === 'pending' || task.status === 'running').length;
    const checks = [];
    if (neverChecked) checks.push({ level: 'warning', id: 'never-checked', title: 'اتصالات لم تُفحص', count: neverChecked, detail: 'شغّل «اكتشاف وفحص» للاتصالات الجديدة قبل إنشاء قواعد تعتمد على قدراتها.' });
    if (staleChecks) checks.push({ level: 'warning', id: 'stale-checks', title: 'نتائج فحص قديمة', count: staleChecks, detail: 'مرّ أكثر من 24 ساعة على آخر فحص؛ أعد الفحص للتأكد من الحالة الحالية.' });
    if (unsupportedEnabledRules) checks.push({ level: 'error', id: 'unsupported-rules', title: 'قواعد مفعّلة بلا قدرة مثبتة', count: unsupportedEnabledRules, detail: 'أوقف القواعد أو افحص الاتصال حتى تثبت القدرة المطلوبة؛ لا ينبغي الاعتماد عليها.' });
    if (offlineDevices) checks.push({ level: 'warning', id: 'offline-devices', title: 'أجهزة غير متصلة', count: offlineDevices, detail: 'تحقق من تشغيل وكيل الجهاز والشبكة ورمز الجهاز.' });
    if (failedRuns) checks.push({ level: 'error', id: 'failed-runs', title: 'تشغيلات بها حالات فاشلة', count: failedRuns, detail: 'افتح تقرير التشغيل الأخير وميّز الفشل الفعلي عن الحالات المتخطاة أو غير الحاسمة.' });
    if (failedTasks) checks.push({ level: 'error', id: 'failed-tasks', title: 'مهام أجهزة فاشلة', count: failedTasks, detail: 'افتح سجل مهام الجهاز واقرأ نتيجة التنفيذ قبل إعادة المحاولة.' });
    if (pendingTasks) checks.push({ level: 'info', id: 'pending-tasks', title: 'مهام أجهزة قيد الانتظار/التنفيذ', count: pendingTasks, detail: 'تأكد أن الجهاز متصل، وأن المهمة ضمن صلاحياته.' });
    if (!checks.length) checks.push({ level: 'success', id: 'baseline', title: 'لا توجد مشكلات مسجلة في البيانات المحلية', count: 0, detail: 'هذا تقرير من السجل المحلي فقط؛ لا يرسل طلبات ولا يثبت أن الخدمات الخارجية تعمل الآن.' });
    return {
      ok: true, generatedAt: isoNow(), mode: 'read-only-local-audit',
      summary: {
        connections: connections.length, connectionCounts, neverChecked, staleChecks,
        devices: devices.length, onlineDevices, offlineDevices, revokedDevices,
        rules: rules.length, enabledRules: enabledRules.length, unsupportedEnabledRules,
        recentRuns: recentRuns.length, failedRuns, failedTasks, pendingTasks,
      },
      checks: checks.slice(0, 30),
      notes: ['الفحص لا يتصل بالأهداف ولا ينفذ أي إجراء خارجي.', 'الحالة مبنية على بيانات آخر تشغيل محفوظة؛ لا تعني نجاحًا حيًا للاتصال.', 'لا تظهر بيانات الدخول أو رموز الوكلاء في التقرير.'],
    };
  }
  templateSupported(connection, template) { return Boolean(connection && template.types.includes(connection.type) && Array.isArray(connection.capabilities) && connection.capabilities.includes(template.capability)); }
  templateReason(connection, template) {
    if (!connection) return 'اختر اتصالًا أولًا.';
    if (!template.types.includes(connection.type)) return 'هذه القاعدة مخصصة لنوع اتصال آخر.';
    if (!connection.discoveredAt) return 'اضغط «اكتشاف وفحص» أولًا ليتم التأكد من القدرات.';
    return `لم يظهر دليل كافٍ على القدرة: ${template.capability}. لن يتم تفعيل القاعدة بالتخمين.`;
  }
  ruleSupported(connection, rule) { if (!connection || !allowedByType(connection.type, rule.requiredCapability || 'hub.safety')) return false; if (rule.requiredCapability === 'hub.safety') return true; return Array.isArray(connection.capabilities) && connection.capabilities.includes(rule.requiredCapability); }
  createConnection(sessionId, input = {}) {
    const data = this.read(sessionId); const type = String(input.type || 'http').toLowerCase();
    if (!TYPES.includes(type)) throw new Error('نوع التكامل غير معروف.');
    const name = String(input.name || '').trim().slice(0, 100); if (!name) throw new Error('اكتب اسمًا واضحًا للتكامل.');
    const connection = { id: id('int'), name, type, createdAt: isoNow(), updatedAt: isoNow(), capabilities: [], evidence: [], status: 'new', lastCheck: null, lastRunId: '', url: '', folderPath: '', command: '', filePath: '', specText: String(input.specText || '').slice(0, MAX_SPEC_BYTES), webhookReceived: 0, webhookTokenHash: '', webhookLastReceivedAt: '', secretHeadersEncrypted: null, pluginId: String(input.pluginId || '') };
    if (type === 'http' || type === 'openapi') {
      connection.url = input.url ? validateHttpUrl(input.url) : '';
      if (!connection.url && !(type === 'openapi' && connection.specText.trim())) throw new Error('أدخل رابط HTTP/HTTPS أو الصق مواصفات OpenAPI.');
      if (connection.specText && Buffer.byteLength(connection.specText) > MAX_SPEC_BYTES) throw new Error('ملف المواصفات أكبر من 1 ميجابايت.');
      const spec = parseOpenApi(connection.specText);
      if (type === 'openapi' && !spec) throw new Error('لم أتعرف على مواصفات OpenAPI. أدخل JSON صالحًا أو YAML شائع البنية يحتوي على openapi وpaths.');
      if (!connection.url && spec?.servers?.length) { try { connection.url = validateHttpUrl(spec.servers[0]); } catch {} }
      if (spec) connection.specSummary = { format: spec.format, version: spec.version, title: spec.title, paths: spec.paths.length, getPaths: spec.paths.filter(p => p.method === 'GET').length };
    }
    if (type === 'folder') { connection.folderPath = String(input.folderPath || '').trim(); if (!connection.folderPath || !path.isAbsolute(connection.folderPath)) throw new Error('أدخل مسار مجلد كاملًا من جهاز التشغيل. لن ينشئ النظام ملفات أو يحذفها.'); }
    if (type === 'command') { connection.command = String(input.command || 'node'); if (!COMMANDS[connection.command]) throw new Error('اختر برنامجًا من القائمة الآمنة المتاحة.'); }
    if (type === 'database') { connection.filePath = String(input.filePath || '').trim(); if (!path.isAbsolute(connection.filePath)) throw new Error('أدخل مسار ملف قاعدة بيانات كاملًا. يسمح المركز بالقراءة فقط.'); const ext = path.extname(connection.filePath).toLowerCase(); if (!['.json','.csv','.db','.sqlite','.sqlite3'].includes(ext)) throw new Error('الأنواع المدعومة: JSON وCSV وقواعد SQLite الشائعة (.db/.sqlite/.sqlite3).'); }
    let hookToken = null;
    if (type === 'webhook') { hookToken = crypto.randomBytes(32).toString('base64url'); connection.webhookTokenHash = this.tokenHash(hookToken); connection.capabilities = ['webhook.receive', 'hub.safety']; connection.status = 'ready'; connection.discoveredAt = isoNow(); }
    if (input.headers !== undefined && ['http','openapi'].includes(type)) connection.secretHeadersEncrypted = this.encryptSecrets(sessionId, input.headers);
    data.connections.push(connection); this.write(sessionId, data);
    return { connection: this.publicConnection(connection), hookToken };
  }
  tokenHash(token) { return crypto.createHash('sha256').update(String(token || '')).digest('hex'); }
  safeEqualHash(savedHash, suppliedToken) {
    if (!/^[a-f0-9]{64}$/i.test(String(savedHash || ''))) return false;
    const a = Buffer.from(String(savedHash), 'hex'), b = Buffer.from(this.tokenHash(suppliedToken), 'hex');
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  }
  publicDevice(device) {
    const { tokenHash, ...visible } = device;
    const age = Date.now() - (Date.parse(device.lastSeenAt || '') || 0);
    return { ...visible, status: device.revokedAt ? 'revoked' : age < 90000 ? 'online' : 'offline' };
  }
  publicTask(task) { return { id: task.id, deviceId: task.deviceId, action: task.action, status: task.status, createdAt: task.createdAt, updatedAt: task.updatedAt, attempts: task.attempts || 0, result: task.result || null }; }
  publicPlugin(plugin) { const { createdBy, ...visible } = plugin; return { ...visible }; }
  createAgentEnrollment(sessionId, { name = '' } = {}) {
    const data = this.read(sessionId), token = crypto.randomBytes(32).toString('base64url'), now = Date.now();
    data.agentEnrollments = data.agentEnrollments.filter(x => !x.usedAt && Date.parse(x.expiresAt) > now).slice(-90);
    const enrollment = { id: id('enroll'), name: String(name || 'جهاز جديد').trim().slice(0,100), tokenHash: this.tokenHash(token), createdAt: isoNow(), expiresAt: new Date(now + 10 * 60 * 1000).toISOString(), usedAt: '' };
    data.agentEnrollments.push(enrollment); this.write(sessionId, data);
    return { id: enrollment.id, token, name: enrollment.name, expiresAt: enrollment.expiresAt, commandHint: `node src/integration-agent.js --server http://127.0.0.1:7005 --session ${this.store.safeSessionId(sessionId)} --token ${token}` };
  }
  claimAgent(token, details = {}) {
    const now = Date.now(); let sessionId = '', enrollment = null, data = null;
    for (const sid of this.store.listSessionIds()) {
      const d = this.read(sid);
      const candidate = d.agentEnrollments.find(x => !x.usedAt && Date.parse(x.expiresAt) > now && this.safeEqualHash(x.tokenHash, token));
      if (candidate) { sessionId = sid; enrollment = candidate; data = d; break; }
    }
    if (!enrollment) throw new Error('رمز تسجيل الجهاز غير صحيح أو انتهت صلاحيته أو استُخدم من قبل. أنشئ رمز تسجيل جديدًا من مركز التكاملات.');
    const deviceToken = crypto.randomBytes(32).toString('base64url');
    const device = { id: id('dev'), name: String(details.name || enrollment.name || 'جهاز محلي').trim().slice(0,100), os: String(details.os || 'unknown').slice(0,80), arch: String(details.arch || '').slice(0,40), hostname: String(details.hostname || '').slice(0,120), agentVersion: String(details.agentVersion || '1.0.0').slice(0,40), createdAt: isoNow(), lastSeenAt: isoNow(), tokenHash: this.tokenHash(deviceToken), revokedAt: '', lastError: '' };
    enrollment.usedAt = isoNow(); data.devices.push(device); data.devices = data.devices.slice(-100); this.write(sessionId, data);
    this.notify(sessionId, { level: 'success', title: `تم ربط جهاز: ${device.name}`, message: `انضم الجهاز ${device.os}/${device.arch}. أُصدر له رمز جهاز خاص ولم يُحفظ مكشوفًا.`, });
    return { sessionId, device: this.publicDevice(device), deviceToken, heartbeatSeconds: 20 };
  }
  authorizeAgent(sessionId, deviceId, token) {
    const data = this.read(sessionId), device = data.devices.find(x => x.id === deviceId && !x.revokedAt);
    if (!device || !this.safeEqualHash(device.tokenHash, token)) throw new Error('بيانات اعتماد الجهاز غير صحيحة أو تم إلغاء الجهاز.');
    return { data, device };
  }
  heartbeatAgent(sessionId, deviceId, token, details = {}) {
    const { data, device } = this.authorizeAgent(sessionId, deviceId, token);
    device.lastSeenAt = isoNow(); device.lastError = '';
    if (details.os) device.os = String(details.os).slice(0,80);
    if (details.arch) device.arch = String(details.arch).slice(0,40);
    if (details.hostname) device.hostname = String(details.hostname).slice(0,120);
    if (details.agentVersion) device.agentVersion = String(details.agentVersion).slice(0,40);
    this.write(sessionId, data); return { device: this.publicDevice(device), serverTime: isoNow() };
  }
  removeDevice(sessionId, deviceId) {
    const data = this.read(sessionId), device = data.devices.find(x => x.id === deviceId);
    if (!device) throw new Error('الجهاز غير موجود.'); device.revokedAt = isoNow(); device.lastSeenAt = ''; device.tokenHash = crypto.randomBytes(32).toString('hex');
    for (const task of data.agentTasks) if (task.deviceId === deviceId && ['pending','running'].includes(task.status)) { task.status = 'cancelled'; task.updatedAt = isoNow(); }
    this.write(sessionId, data); return this.publicDevice(device);
  }
  createAgentTask(sessionId, deviceId, input = {}) {
    const data = this.read(sessionId), device = data.devices.find(x => x.id === deviceId && !x.revokedAt); if (!device) throw new Error('الجهاز غير موجود أو ملغى.');
    const action = String(input.action || 'device.info');
    if (!['device.info','command.version','folder.list','database.inspect','http.probe'].includes(action)) throw new Error('الإجراء غير موجود ضمن قائمة إجراءات الجهاز الآمنة.');
    const params = input.params && typeof input.params === 'object' && !Array.isArray(input.params) ? input.params : {};
    if (action === 'command.version' && !COMMANDS[String(params.command || 'node')]) throw new Error('اختر برنامجًا من قائمة الأوامر الآمنة.');
    if (['folder.list','database.inspect'].includes(action) && !path.isAbsolute(String(params.path || ''))) throw new Error('أدخل مسارًا كاملًا على الجهاز البعيد.');
    if (action === 'database.inspect' && !['.json','.csv','.db','.sqlite','.sqlite3'].includes(path.extname(String(params.path || '')).toLowerCase())) throw new Error('نوع قاعدة البيانات غير مدعوم.');
    const task = { id: id('task'), deviceId, action, params: { ...params }, status: 'pending', createdAt: isoNow(), updatedAt: isoNow(), attempts: 0, result: null, error: '' };
    data.agentTasks.push(task); data.agentTasks = data.agentTasks.slice(-500); this.write(sessionId, data); return this.publicTask(task);
  }
  takeAgentTasks(sessionId, deviceId, token) {
    const { data, device } = this.authorizeAgent(sessionId, deviceId, token), now = Date.now();
    const tasks = data.agentTasks.filter(t => t.deviceId === deviceId && (t.status === 'pending' || (t.status === 'running' && Date.now() - (Date.parse(t.updatedAt) || 0) > 90000)) && (t.attempts || 0) < 3).slice(0,5);
    for (const task of tasks) { task.status = 'running'; task.updatedAt = isoNow(); task.attempts = (task.attempts || 0) + 1; }
    device.lastSeenAt = isoNow(); this.write(sessionId, data);
    return { tasks: tasks.map(task => ({ id: task.id, action: task.action, params: task.params, attempts: task.attempts })), serverTime: isoNow() };
  }
  completeAgentTask(sessionId, deviceId, token, taskId, result = {}) {
    const { data } = this.authorizeAgent(sessionId, deviceId, token), task = data.agentTasks.find(t => t.id === taskId && t.deviceId === deviceId);
    if (!task) throw new Error('مهمة الجهاز غير موجودة.');
    if (task.status === 'done' || task.status === 'failed') return this.publicTask(task); // Idempotent: a retried response does not duplicate a result.
    if (task.status !== 'running') throw new Error('المهمة ليست في حالة تسمح باستلام النتيجة.');
    const normalized = result && typeof result === 'object' && !Array.isArray(result) ? result : { value: result };
    const encoded = JSON.stringify(normalized);
    if (Buffer.byteLength(encoded) > 30000) throw new Error('نتيجة الجهاز أكبر من الحد المسموح (30 كيلوبايت).');
    task.result = JSON.parse(encoded); task.status = normalized.ok === false ? 'failed' : 'done'; task.updatedAt = isoNow();
    this.write(sessionId, data); this.notify(sessionId, { level: task.status === 'done' ? 'success' : 'error', title: `نتيجة مهمة من ${data.devices.find(x => x.id === deviceId)?.name || 'جهاز'}`, message: String(normalized.summary || normalized.error || task.action).slice(0,1000) });
    return this.publicTask(task);
  }
  registerPlugin(sessionId, input = {}) {
    const data = this.read(sessionId), source = typeof input === 'string' ? JSON.parse(input) : input;
    if (!source || typeof source !== 'object' || Array.isArray(source)) throw new Error('ملف الإضافة يجب أن يكون كائن JSON.');
    const slug = String(source.id || '').trim().toLowerCase();
    if (!/^[a-z0-9][a-z0-9-]{1,48}$/.test(slug)) throw new Error('معرّف الإضافة يجب أن يكون حروفًا إنجليزية صغيرة وأرقامًا وشرطات.');
    const name = String(source.name || '').trim(); if (!name || name.length > 100) throw new Error('أدخل اسمًا للإضافة بطول لا يتجاوز 100 حرف.');
    const adapter = String(source.adapter || '').toLowerCase(); if (!TYPES.includes(adapter) || adapter === 'webhook' && source.webhook !== true) throw new Error('نوع المحوّل غير مدعوم لهذا النوع من الإضافة.');
    if (data.plugins.some(p => p.id === slug)) throw new Error('يوجد إضافة بهذا المعرّف بالفعل.');
    const preset = {};
    for (const key of ['url','folderPath','filePath','command','specText']) if (source[key] !== undefined) preset[key] = String(source[key]).slice(0,key==='specText'?MAX_SPEC_BYTES:2000);
    const plugin = { id: slug, name: name.slice(0,100), version: String(source.version || '1.0.0').slice(0,40), description: String(source.description || '').slice(0,1000), adapter, preset, createdAt: isoNow(), enabled: true, sourceType: 'declarative-safe' };
    data.plugins.push(plugin); this.write(sessionId, data); return this.publicPlugin(plugin);
  }
  deletePlugin(sessionId, pluginId) { const data=this.read(sessionId), before=data.plugins.length; data.plugins=data.plugins.filter(p=>p.id!==pluginId); if(data.plugins.length===before) throw new Error('الإضافة غير موجودة.'); this.write(sessionId,data); return true; }
  connectionFromPlugin(sessionId, pluginId, overrides = {}) {
    const plugin=this.read(sessionId).plugins.find(p=>p.id===pluginId && p.enabled); if(!plugin) throw new Error('الإضافة غير موجودة أو متوقفة.');
    const input={...plugin.preset,...overrides,name:String(overrides.name||plugin.name),type:plugin.adapter,pluginId:plugin.id};
    return this.createConnection(sessionId,input);
  }
  getConnection(sessionId, connectionId) { const c = this.read(sessionId).connections.find(x => x.id === connectionId); if (!c) throw new Error('التكامل غير موجود.'); return c; }
  updateConnection(sessionId, connectionId, changes = {}) {
    const data = this.read(sessionId); const c = data.connections.find(x => x.id === connectionId); if (!c) throw new Error('التكامل غير موجود.');
    if (changes.name !== undefined) { const name = String(changes.name || '').trim(); if (!name) throw new Error('اسم التكامل لا يمكن أن يكون فارغًا.'); c.name = name.slice(0,100); }
    if (changes.url !== undefined && ['http','openapi'].includes(c.type)) c.url = validateHttpUrl(changes.url);
    if (changes.specText !== undefined) { if (Buffer.byteLength(String(changes.specText)) > MAX_SPEC_BYTES) throw new Error('ملف المواصفات أكبر من 1 ميجابايت.'); c.specText = String(changes.specText); }
    if (changes.folderPath !== undefined && c.type === 'folder') { const p = String(changes.folderPath).trim(); if (!path.isAbsolute(p)) throw new Error('مسار المجلد يجب أن يكون كاملًا.'); c.folderPath = p; }
    if (changes.command !== undefined && c.type === 'command') { if (!COMMANDS[changes.command]) throw new Error('الأمر غير موجود في القائمة الآمنة.'); c.command = changes.command; }
    c.updatedAt = isoNow(); this.write(sessionId, data); return this.publicConnection(c);
  }
  deleteConnection(sessionId, connectionId) {
    const data = this.read(sessionId); data.connections = data.connections.filter(c => c.id !== connectionId); data.rules = data.rules.filter(r => r.connectionId !== connectionId); this.write(sessionId,data); return true;
  }
  async safeFetch(inputUrl, { headers = {} } = {}) {
    let current = validateHttpUrl(inputUrl); const initialOrigin = new URL(current).origin; let redirects = 0; const started = Date.now();
    const safeHeaders = this.validateHeaders(headers);
    const fetchHeaders = { 'Accept': 'application/json, text/html, */*', 'User-Agent': 'chat-BOT-IntegrationHub/9.20.0', ...safeHeaders };
    while (true) {
      const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), HTTP_TIMEOUT_MS); timer.unref?.();
      try {
        const requestOrigin = new URL(current).origin;
        // Never forward stored credentials to another origin after a redirect.
        const headersForOrigin = requestOrigin === initialOrigin ? fetchHeaders : { 'Accept': 'application/json, text/html, */*', 'User-Agent': 'chat-BOT-IntegrationHub/9.20.0' };
        const response = await fetch(current, { method: 'GET', redirect: 'manual', signal: controller.signal, headers: headersForOrigin });
        if ([301,302,303,307,308].includes(response.status) && response.headers.get('location')) {
          if (redirects >= 3) return { url: current, status: response.status, statusText: response.statusText, ok: false, redirects, latencyMs: Date.now()-started, contentType: response.headers.get('content-type') || '', headers: Object.fromEntries([...response.headers.entries()].slice(0,40)), bytes: 0, bodySample: '', error: 'تجاوز الرابط 3 تحويلات.' };
          const next = new URL(response.headers.get('location'), current).toString(); validateHttpUrl(next); await response.body?.cancel(); current = next; redirects++; continue;
        }
        let bytes = 0; let bodySample = ''; const reader = response.body?.getReader();
        if (reader) { const chunks = []; try { while (true) { const { done, value } = await reader.read(); if (done) break; bytes += value.byteLength; if (bytes > MAX_RESPONSE_BYTES) { await reader.cancel(); return { url: current, status: response.status, statusText: response.statusText, ok: response.ok, redirects, latencyMs: Date.now()-started, contentType: response.headers.get('content-type') || '', headers: Object.fromEntries([...response.headers.entries()].slice(0,40)), bytes, bodySample: '', truncated: true, error: 'تجاوزت الاستجابة حد 1 ميجابايت؛ أُوقف التنزيل لحماية الذاكرة.' }; } chunks.push(Buffer.from(value)); } } finally { try { reader.releaseLock(); } catch {} } bodySample = Buffer.concat(chunks).toString('utf8').slice(0, 2000); }
        return { url: current, status: response.status, statusText: response.statusText, ok: response.ok, redirects, latencyMs: Date.now()-started, contentType: response.headers.get('content-type') || '', headers: Object.fromEntries([...response.headers.entries()].slice(0,40)), bytes, bodySample, error: '' };
      } catch (error) { return { url: current, status: 0, statusText: '', ok: false, redirects, latencyMs: Date.now()-started, contentType: '', headers: {}, bytes: 0, bodySample: '', error: error?.name === 'AbortError' ? `تجاوز الطلب ${HTTP_TIMEOUT_MS}ms.` : sanitizeError(error) }; }
      finally { clearTimeout(timer); }
    }
  }
  async inspectFolder(connection) {
    let real; try { real = fs.realpathSync(connection.folderPath); } catch { throw new Error('المجلد غير موجود أو لا يمكن الوصول إليه. تحقق من المسار وصلاحيات المستخدم.'); }
    const stat = fs.statSync(real); if (!stat.isDirectory()) throw new Error('المسار المختار ليس مجلدًا.');
    const entries = fs.readdirSync(real, { withFileTypes: true }).slice(0, 500).map(e => ({ name: e.name.slice(0, 255), type: e.isDirectory() ? 'مجلد' : e.isFile() ? 'ملف' : 'نوع آخر' }));
    return { path: real, count: entries.length, entries: entries.slice(0, 50), truncated: entries.length >= 500 };
  }
  async inspectDatabase(connection) {
    const p = connection.filePath; let st; try { st = fs.statSync(p); } catch { throw new Error('ملف قاعدة البيانات غير موجود أو لا يمكن قراءته.'); }
    if (!st.isFile()) throw new Error('المسار المحدد ليس ملفًا.'); if (st.size > 20 * 1024 * 1024) throw new Error('حجم ملف البيانات أكبر من الحد الآمن البالغ 20 ميجابايت للفحص الأولي.');
    const ext = path.extname(p).toLowerCase();
    if (ext === '.json') { const v = JSON.parse(fs.readFileSync(p,'utf8')); return { format:'JSON', bytes:st.size, rootType:Array.isArray(v)?'array':typeof v, rows:Array.isArray(v)?v.length:undefined, keys:v && typeof v === 'object' && !Array.isArray(v)?Object.keys(v).slice(0,100):[], readOnly:true }; }
    if (ext === '.csv') { const sample = fs.readFileSync(p,'utf8').split(/\r?\n/u).filter(Boolean).slice(0,6); return { format:'CSV', bytes:st.size, columns:(sample[0] || '').split(',').map(x=>x.trim().replace(/^"|"$/g,'')).slice(0,100), sampleRows:Math.max(0,sample.length-1), readOnly:true }; }
    const py = "import sys,sqlite3,json,urllib.parse\np=sys.argv[1]\nuri='file:'+urllib.parse.quote(p.replace('\\\\','/'),safe='/ :')+'?mode=ro'\nc=sqlite3.connect(uri,uri=True,timeout=2)\nt=[r[0] for r in c.execute(\"SELECT name FROM sqlite_master WHERE type='table' ORDER BY name\").fetchall() if not r[0].startswith('sqlite_')]\nout=[]\nfor n in t[:100]:\n q='\\\"'+n.replace('\\\"','\\\"\\\"')+'\\\"'\n try: out.append({'name':n,'rows':c.execute('SELECT COUNT(*) FROM '+q).fetchone()[0]})\n except Exception: out.append({'name':n,'rows':None})\nprint(json.dumps({'tables':out,'readOnly':True}))\nc.close()";
    let result;
    try { result = await execFileAsync(COMMANDS.python.bin, ['-c', py, p], { timeout: 5000, windowsHide: true, maxBuffer: 256 * 1024 }); }
    catch (first) { if (process.platform === 'win32') { try { result = await execFileAsync('py', ['-3','-c',py,p], { timeout:5000, windowsHide:true, maxBuffer:256*1024 }); } catch { throw new Error('تعذر فحص SQLite: ثبّت Python 3 وأعد المحاولة. لم يتم تعديل قاعدة البيانات.'); } } else throw new Error(`تعذر فحص SQLite بواسطة Python: ${sanitizeError(first)}. لم يتم تعديل قاعدة البيانات.`); }
    try { return { format: ext.slice(1).toUpperCase(), bytes: st.size, ...JSON.parse(result.stdout), readOnly: true }; } catch { throw new Error('أعاد محرك SQLite نتيجة غير مفهومة.'); }
  }
  async inspectCommand(connection) {
    const cmd = COMMANDS[connection.command]; if (!cmd) throw new Error('الأمر غير مسموح.');
    try { const result = await execFileAsync(cmd.bin, cmd.args, { timeout: 3500, windowsHide: true, shell: false, maxBuffer: 64 * 1024 }); return { command: connection.command, label: cmd.label, version: String(result.stdout || result.stderr || '').trim().slice(0, 500), readOnly: true }; }
    catch (error) { throw new Error(`${cmd.label} غير جاهز أو تعذر تشغيل فحص الإصدار: ${sanitizeError(error)}. لم يُشغّل أي أمر آخر.`); }
  }
  async discover(sessionId, connectionId) {
    const data = this.read(sessionId), c = data.connections.find(x => x.id === connectionId); if (!c) throw new Error('التكامل غير موجود.');
    let capabilities = ['hub.safety'], evidence = [], probe = null, spec = parseOpenApi(c.specText);
    if (c.type === 'http' || c.type === 'openapi') {
      if (c.url) {
        probe = await this.safeFetch(c.url, { headers: this.connectionHeaders(sessionId, c) }); evidence.push({ source: 'GET المحدد', status: probe.status, ok: probe.ok, latencyMs: probe.latencyMs, contentType: probe.contentType, error: probe.error, url: probe.url, redirects: probe.redirects, bytes: probe.bytes, headers: probe.headers });
        if (probe.status || probe.error) capabilities.push('http.read','http.headers','http.redirects');
        if (probe.status) capabilities.push('http.health');
        if (probe.status === 401 || probe.status === 403) capabilities.push('http.auth');
        if (probe.contentType) capabilities.push('http.read');
        if (new URL(c.url).protocol === 'https:') capabilities.push('http.tls');
        if (probe.redirects) capabilities.push('http.redirects');
        if (Object.keys(probe.headers || {}).some(h => /ratelimit|rate-limit|x-rate/i.test(h))) capabilities.push('http.rate_limit');
        if (probe.status >= 400) capabilities.push('http.errors');
        const origin = new URL(c.url).origin;
        for (const candidate of ['/openapi.json','/swagger.json','/api-docs','/.well-known/openapi.json']) {
          if (spec) break;
          const r = await this.safeFetch(new URL(candidate, origin).toString(), { headers: this.connectionHeaders(sessionId, c) });
          if (r.ok && /json|yaml|text\/plain/i.test(r.contentType)) { const parsed = parseOpenApi(r.bodySample); if (parsed && parsed.paths.length) { spec = parsed; c.specText = r.bodySample; evidence.push({ source: `اكتشاف ${candidate}`, status: r.status, ok: true, paths: parsed.paths.length, url: r.url }); break; } }
          evidence.push({ source: `اكتشاف ${candidate}`, status: r.status, ok: r.ok, error: r.error || '' });
        }
      }
      if (spec) {
        capabilities.push('openapi.read');
        if (spec.paths.length) capabilities.push('openapi.paths');
        if (spec.security) capabilities.push('http.auth');
        if (spec.paths.some(p => /pagination|page|cursor|limit|offset/i.test(p.path))) capabilities.push('api.pagination');
        if (spec.paths.some(p => /search|filter|query/i.test(p.path))) capabilities.push('api.filtering');
        if (spec.paths.some(p => /sort|order/i.test(p.path))) capabilities.push('api.sorting');
        c.specSummary = { format: spec.format, version: spec.version, title: spec.title, paths: spec.paths.length, getPaths: spec.paths.filter(p=>p.method==='GET').length };
        c.specPaths = spec.paths.slice(0, 1000).map(p=>({path:p.path,method:p.method,operationId:p.operationId,summary:p.summary}));
        evidence.push({ source:'مواصفات OpenAPI', title:spec.title, version:spec.version, paths:spec.paths.length, getPaths:spec.paths.filter(p=>p.method==='GET').length, format:spec.format });
      }
      if (!c.url && spec?.servers?.length) { try { c.url = validateHttpUrl(spec.servers[0]); } catch {} }
      c.lastProbe = probe ? { status:probe.status, ok:probe.ok, latencyMs:probe.latencyMs, contentType:probe.contentType, error:probe.error, finalUrl:probe.url } : null;
      c.lastDiscoveryProbeCount = evidence.filter(x => x.source === 'GET المحدد' || String(x.source||'').startsWith('اكتشاف ')).length;
    } else if (c.type === 'folder') {
      const folder = await this.inspectFolder(c); capabilities.push('folder.read','folder.list'); evidence.push({ source:'مجلد محلي', path:folder.path, count:folder.count, preview:folder.entries.slice(0,10) }); c.folderSummary = {path:folder.path,count:folder.count,truncated:folder.truncated};
    } else if (c.type === 'command') {
      const result = await this.inspectCommand(c); capabilities.push('command.run'); evidence.push({source:'أمر إصدار آمن',...result}); c.commandSummary = result;
    } else if (c.type === 'database') {
      const result = await this.inspectDatabase(c); capabilities.push('database.read'); evidence.push({source:'فحص قاعدة قراءة فقط',...result}); c.databaseSummary = result;
    } else if (c.type === 'webhook') { capabilities.push('webhook.receive'); evidence.push({source:'مسار استقبال Webhook',received:c.webhookReceived,lastReceivedAt:c.webhookLastReceivedAt || null}); }
    c.capabilities = [...new Set(capabilities)]; c.evidence = evidence.slice(-30); c.discoveredAt = isoNow(); c.lastCheck = isoNow(); c.status = c.type==='http'||c.type==='openapi' ? (probe?.ok ? 'reachable' : probe?.status ? 'warning' : spec ? 'spec-only' : 'failed') : 'ready'; c.updatedAt = isoNow();
    this.write(sessionId, data); this.notify(sessionId, { level: c.status==='failed' ? 'error' : 'info', title: `اكتشاف التكامل: ${c.name}`, message: `النوع ${c.type}؛ قدرات مؤكدة: ${c.capabilities.length}. لم تُنفذ عمليات كتابة أو حذف.`, connectionId:c.id });
    return { connection: this.publicConnection(c), probe, specSummary:c.specSummary || null, capabilities:c.capabilities, evidence:c.evidence, templates: RULE_TEMPLATES.map(t=>({...t,supported:this.templateSupported(c,t),reason:this.templateSupported(c,t)?'':this.templateReason(c,t)})) };
  }
  async runTests(sessionId, connectionId) {
    let c = this.getConnection(sessionId, connectionId); let discoveryError = '';
    try { await this.discover(sessionId, connectionId); c = this.getConnection(sessionId, connectionId); } catch (e) { discoveryError = sanitizeError(e); c = this.getConnection(sessionId, connectionId); }
    const data = this.read(sessionId); const current = data.connections.find(x=>x.id===connectionId); const probe = current.lastProbe || null; const evidence = current.evidence || []; const results = [];
    const probeCheck = (family) => {
      if (family==='health') return !probe ? {status:'INCONCLUSIVE',detail: discoveryError || 'لم يتمكن الاكتشاف من الحصول على نتيجة HTTP.'} : !probe.status ? {status:'FAIL',detail:probe.error || 'لم تصل استجابة HTTP.'} : probe.status < 500 ? {status: probe.status>=400?'WARN':'PASS',detail:`وصلت استجابة HTTP ${probe.status}; ${probe.latencyMs}ms.`} : {status:'FAIL',detail:`عاد الخادم برمز ${probe.status}.`};
      if (family==='http-status') return !probe?.status ? {status:'SKIPPED',detail:'لا توجد استجابة قابلة للفحص.'} : {status:probe.status < 500 ? 'PASS':'FAIL',detail:`رمز HTTP ${probe.status}.`};
      if (family==='headers') return !probe ? {status:'SKIPPED',detail:'لم تتوفر ترويسات.'} : {status: Object.keys(probe.headers||{}).length?'PASS':'WARN',detail:`تمت قراءة ${Object.keys(probe.headers||{}).length} ترويسة.`};
      if (family==='tls') return current.url?.startsWith('https:') ? {status:'PASS',detail:'الرابط يستخدم HTTPS؛ لم يتم إجراء تدقيق أمني شامل للشهادة.'} : {status:'WARN',detail:'الرابط لا يستخدم HTTPS.'};
      if (family==='content-type') return !probe ? {status:'SKIPPED',detail:'لم تتوفر استجابة.'} : {status:probe.contentType?'PASS':'WARN',detail:`نوع المحتوى: ${probe.contentType||'غير معلن'}.`};
      if (family==='latency') return !probe ? {status:'SKIPPED',detail:'لا توجد مدة استجابة.'} : {status:probe.latencyMs<=2500?'PASS':'WARN',detail:`المدة المسجلة ${probe.latencyMs}ms (قياس واحد فقط).`};
      if (family==='redirects') return !probe ? {status:'SKIPPED',detail:'لم تتوفر نتيجة تحويل.'} : {status:probe.redirects>0?'WARN':'PASS',detail:`عدد التحويلات في الفحص: ${probe.redirects}.`};
      if (family==='response-size') return !probe ? {status:'SKIPPED',detail:'لم تتوفر استجابة.'} : {status:probe.bytes<=MAX_RESPONSE_BYTES?'PASS':'WARN',detail:`عدد البايتات المقروءة: ${probe.bytes}.`};
      if (family==='openapi') return current.specSummary ? {status:'PASS',detail:`تم التعرف على ${current.specSummary.paths} مسارًا من المواصفات.`} : {status:'SKIPPED',detail:'لم يتم العثور على OpenAPI/Swagger.'};
      if (family==='get-endpoints') return current.specSummary ? {status:current.specSummary.getPaths?'PASS':'WARN',detail:`مسارات GET الموثقة: ${current.specSummary.getPaths}. لم تُرسل طلبات لهذه المسارات تلقائيًا.`} : {status:'SKIPPED',detail:'لا توجد مواصفات توثق المسارات.'};
      return null;
    };
    const caps = new Set(current.capabilities || []);
    for (const item of TEST_CATALOG) {
      let outcome;
      if (item.manualReview) outcome = {status:'SKIPPED',detail:'هذه حالة سيناريو تحتاج اختيارًا ومراجعة بشرية قبل أي تنفيذ؛ لم تُنفذ تلقائيًا.'};
      else if (!allowedByType(current.type,item.capability)) outcome = {status:'UNSUPPORTED',detail:`نوع التكامل «${current.type}» لا يقدم هذا النوع من الاختبار.`};
      else if (item.mode==='probe' && item.variant===1) outcome = probeCheck(item.family) || {status:'SKIPPED',detail:'لا يوجد فاحص خاص لهذه الحالة.'};
      else if (item.family==='folder' && item.variant===1 && current.folderSummary) outcome = {status:'PASS',detail:`تم فحص المجلد وقراءة ${current.folderSummary.count} عنصرًا.`};
      else if (item.family==='command' && item.variant===1 && current.commandSummary) outcome = {status:'PASS',detail:`تم تشغيل ${current.commandSummary.label} مع معامل إصدار ثابت.`};
      else if (item.family==='database' && item.variant===1 && current.databaseSummary) outcome = {status:'PASS',detail:`تمت قراءة وصف ${current.databaseSummary.format} بوضع القراءة فقط.`};
      else if (item.family==='safety' && item.variant<=4) outcome = {status:'PASS',detail:'تم التحقق محليًا من أن التنفيذ لا يسمح بـshell أو بطرق HTTP الكتابية افتراضيًا.'};
      else if (caps.has(item.capability)) outcome = {status:'INCONCLUSIVE',detail:`ظهر دليل على القدرة ${item.capability} في الاكتشاف، لكن هذه الحالة لم تنفذ عملية مستقلة؛ لا تُحسب نجاحًا فعليًا.`};
      else outcome = {status:'SKIPPED',detail:`لم يظهر دليل يدعم ${item.capability}; لم يتم التخمين أو إرسال طلب مجهول.`};
      results.push({ id:item.id, family:item.family, label:item.label, title:item.title, capability:item.capability, mode:item.mode, safety:item.safety, status:outcome.status, detail:outcome.detail, executed: ['PASS','WARN','FAIL'].includes(outcome.status) && ((item.mode==='probe' && item.variant===1) || (item.family==='folder' && item.variant===1 && Boolean(current.folderSummary)) || (item.family==='command' && item.variant===1 && Boolean(current.commandSummary)) || (item.family==='database' && item.variant===1 && Boolean(current.databaseSummary)) || (item.family==='safety' && item.variant<=4)), checkedAt:isoNow() });
    }
    const counts = results.reduce((a,r)=>(a[r.status]=(a[r.status]||0)+1,a),{});
    const run = { id:id('test'), sessionId:sessionId, connectionId, connectionName:current.name, kind:'catalog-test', createdAt:isoNow(), total:results.length, catalogScenarios:results.length, executedCases:results.filter(r=>r.executed).length, actualTargetProbes: Number(current.lastDiscoveryProbeCount || (current.lastProbe ? 1 : 0)), counts, results };
    data.runs.push(run); data.runs=data.runs.slice(-500); const cc=data.connections.find(x=>x.id===connectionId); cc.lastRunId=run.id; cc.lastCheck=run.createdAt; this.write(sessionId,data);
    this.notify(sessionId,{level:counts.FAIL?'error':counts.WARN?'warning':'info',title:`اكتمل فحص ${current.name}`,message:`نتيجة ${results.length} حالة: ${counts.PASS||0} نجاح، ${counts.FAIL||0} فشل، ${counts.WARN||0} تحذير، ${counts.SKIPPED||0} متخطاة، ${counts.UNSUPPORTED||0} غير مدعومة. الطلبات الآمنة للهدف: ${run.actualTargetProbes}.`,connectionId});
    return {run,summary:{total:run.total,catalogScenarios:run.catalogScenarios,executedCases:run.executedCases,actualTargetProbes:run.actualTargetProbes,counts:run.counts}};
  }
  createRule(sessionId, input={}) {
    const data=this.read(sessionId), c=data.connections.find(x=>x.id===input.connectionId); if(!c) throw new Error('اختر تكاملًا محفوظًا أولًا.');
    const text=String(input.description||input.naturalLanguage||'').trim().slice(0,1000); let action=String(input.action||''); let capability=String(input.requiredCapability||'');
    if(!action && text){ const n=text.toLowerCase(); if(c.type==='http'||c.type==='openapi'){ if(/سرع|زمن|بطء|latency|response time/u.test(n)){action='http_latency';capability='http.read';} else if(/ترويس|header|أمان|security/u.test(n)){action='http_security_headers';capability='http.headers';} else if(/مواصف|openapi|schema|مسار|endpoint/u.test(n)){action='openapi_report';capability='openapi.read';} else if(/محتوى|content.?type/u.test(n)){action='http_content_type';capability='http.read';} else if(/تحويل|redirect/u.test(n)){action='http_redirects';capability='http.redirects';} else if(/توفر|حالة|اتصال|افحص|راقب|check|health|status/u.test(n)){action='http_health';capability='http.health';} } else if(c.type==='folder' && /ملف|مجلد|folder|file/u.test(n)){action='folder_list';capability='folder.read';} else if(c.type==='command' && /اصدار|إصدار|version|برنامج/u.test(n)){action='command_version';capability='command.run';} else if(c.type==='database' && /قاعد|بيانات|database|sqlite|csv|json/u.test(n)){action='database_inspect';capability='database.read';} else if(c.type==='webhook' && /ويب|webhook|استقبال|حدث/u.test(n)){action='webhook_report';capability='webhook.receive';} }
    const validActions={http_tls:['http','openapi','http.tls'],http_health:['http','openapi','http.health'],http_latency:['http','openapi','http.read'],http_security_headers:['http','openapi','http.headers'],http_content_type:['http','openapi','http.read'],http_redirects:['http','openapi','http.redirects'],openapi_report:['http','openapi','openapi.read'],openapi_get_list:['http','openapi','openapi.paths'],http_get_endpoint:['http','openapi','http.read'],folder_list:['folder','folder','folder.read'],command_version:['command','command','command.run'],database_inspect:['database','database','database.read'],webhook_report:['webhook','webhook','webhook.receive'],local_audit:[c.type,c.type,'hub.safety']};
    const definition=validActions[action]; if(!definition || definition[0]!==c.type && !(definition[0]==='http'&&c.type==='openapi')) throw new Error('لم أفهم القاعدة بأمان. اختر إجراءً من القائمة أو اكتب قاعدة أوضح.');
    capability=capability||definition[2]; if(!allowedByType(c.type,capability)) throw new Error('نوع الاتصال لا يدعم القدرة المطلوبة.');
    const triggerType=['manual','schedule','webhook'].includes(input.triggerType)?input.triggerType:'manual';
    const rule={id:id('rule'),connectionId:c.id,name:String(input.name||text||'قاعدة جديدة').trim().slice(0,100),description:text,action,requiredCapability:capability,triggerType,everyMinutes:clamp(input.everyMinutes,1,1440,15),enabled:false,createdAt:isoNow(),updatedAt:isoNow(),lastRunAt:'',lastResult:null,templateId:String(input.templateId||''),endpoint:String(input.endpoint||'').slice(0,500)};
    if(action==='http_get_endpoint' && !rule.endpoint.startsWith('/')) throw new Error('مسار endpoint يجب أن يبدأ بـ / مثل /api/health.');
    if(rule.triggerType==='webhook' && c.type!=='webhook') throw new Error('اختيار مُشغّل Webhook يتطلب اتصالًا من نوع Webhook.');
    if(rule.triggerType==='webhook' && c.type==='webhook') rule.requiredCapability='webhook.receive';
    const supported=this.ruleSupported(c,rule); if(input.enabled===true && !supported) throw new Error('لا يمكن تشغيل هذه القاعدة قبل إثبات أن التكامل يدعمها. نفذ الاكتشاف أولًا.');
    rule.enabled=input.enabled===true; data.rules.push(rule); this.write(sessionId,data); return { ...rule, supported };
  }
  async runRule(sessionId, ruleId, { source='manual', payload=null }={}) {
    const key=`${sessionId}|${ruleId}`; if(this.runningRules.has(key)) throw new Error('هذه القاعدة تعمل الآن بالفعل.'); this.runningRules.add(key);
    try {
      const data=this.read(sessionId), rule=data.rules.find(r=>r.id===ruleId); if(!rule) throw new Error('القاعدة غير موجودة.'); const c=data.connections.find(x=>x.id===rule.connectionId); if(!c) throw new Error('التكامل المرتبط بالقاعدة غير موجود.');
      if(!this.ruleSupported(c,rule)) throw new Error('القاعدة غير مدعومة حسب آخر اكتشاف. افحص الاتصال ولا تشغلها بالتخمين.');
      const started=Date.now(); let result;
      if(rule.action==='http_tls'){ const isHttps=Boolean(c.url && new URL(c.url).protocol==='https:'); result={ok:isHttps,https:isHttps,url:c.url,summary:isHttps?'العنوان يستخدم HTTPS.':'العنوان لا يستخدم HTTPS؛ لا ترسل بيانات حساسة عبر اتصال غير مشفر.'}; }
      else if(rule.action==='http_health'||rule.action==='http_latency'||rule.action==='http_content_type'||rule.action==='http_redirects'){ if(!c.url) throw new Error('التكامل لا يحتوي على رابط.'); const p=await this.safeFetch(c.url, { headers: this.connectionHeaders(sessionId, c) }); result={ok:Boolean(p.status && p.status<500),status:p.status,latencyMs:p.latencyMs,contentType:p.contentType,redirects:p.redirects,bytes:p.bytes,url:p.url,error:p.error||'',summary:`HTTP ${p.status||'غير متاح'} خلال ${p.latencyMs}ms`}; if(!p.status||p.status>=500) result.ok=false; if(rule.action==='http_content_type') result.summary=`نوع المحتوى: ${p.contentType||'غير معلن'}`; if(rule.action==='http_redirects') result.summary=`التحويلات: ${p.redirects}`; }
      else if(rule.action==='http_security_headers'){ const p=await this.safeFetch(c.url, { headers: this.connectionHeaders(sessionId, c) }); const names=Object.keys(p.headers||{}); const wanted=['strict-transport-security','content-security-policy','x-content-type-options','x-frame-options','referrer-policy']; result={ok:p.status>0,status:p.status,headers:names.filter(n=>wanted.includes(n.toLowerCase())),missing:wanted.filter(n=>!names.includes(n)),summary:`تم العثور على ${names.filter(n=>wanted.includes(n.toLowerCase())).length} من 5 ترويسات أمان شائعة.`}; }
      else if(rule.action==='openapi_report'||rule.action==='openapi_get_list'){ const spec=parseOpenApi(c.specText); if(!spec) throw new Error('لا توجد مواصفات OpenAPI قابلة للقراءة؛ استخدم اكتشافًا جديدًا أو الصق spec صالحًا.'); const paths=rule.action==='openapi_get_list'?spec.paths.filter(x=>x.method==='GET'):spec.paths; result={ok:true,format:spec.format,title:spec.title,version:spec.version,count:paths.length,paths:paths.slice(0,80),summary:`${spec.title}: ${paths.length} مسارًا في التقرير.`}; }
      else if(rule.action==='http_get_endpoint'){ const base=new URL(c.url); const target=new URL(rule.endpoint,base); if(target.origin!==base.origin) throw new Error('يُمنع استخدام القاعدة للوصول إلى نطاق آخر؛ يجب أن يبقى المسار على نفس أصل الموقع.'); const p=await this.safeFetch(target.toString(), { headers: this.connectionHeaders(sessionId, c) }); result={ok:Boolean(p.status&&p.status<400),status:p.status,latencyMs:p.latencyMs,bytes:p.bytes,summary:`GET ${rule.endpoint}: HTTP ${p.status||'غير متاح'} خلال ${p.latencyMs}ms`,error:p.error}; }
      else if(rule.action==='folder_list'){ const f=await this.inspectFolder(c); result={ok:true,count:f.count,entries:f.entries,summary:`المجلد متاح ويحتوي على ${f.count} عنصرًا ضمن الحد المفحوص.`}; }
      else if(rule.action==='command_version'){ const info=await this.inspectCommand(c); result={ok:true,...info,summary:`${COMMANDS[c.command].label}: ${info.version}`}; }
      else if(rule.action==='database_inspect'){ result={ok:true,...await this.inspectDatabase(c),summary:'نجح فحص البيانات بوضع القراءة فقط.'}; }
      else if(rule.action==='webhook_report'){ result={ok:true,received:c.webhookReceived||0,lastReceivedAt:c.webhookLastReceivedAt||null,summary:`استقبل هذا المسار ${c.webhookReceived||0} حدثًا.`}; }
      else if(rule.action==='local_audit'){ result={ok:true,summary:'تم تسجيل تشغيل القاعدة في سجل التكاملات المحلي.'}; }
      else throw new Error('الإجراء غير موجود في محرك التنفيذ الآمن.');
      result.durationMs=Date.now()-started; result.source=source; result.createdAt=isoNow();
      const latest=this.read(sessionId); const liveRule=latest.rules.find(r=>r.id===ruleId); if(liveRule){ liveRule.lastRunAt=result.createdAt; liveRule.lastResult={ok:result.ok===true,summary:result.summary||'',durationMs:result.durationMs,status:result.status||null}; liveRule.updatedAt=isoNow(); }
      const run={id:id('run'),kind:'rule-run',sessionId,connectionId:c.id,connectionName:c.name,ruleId,ruleName:rule.name,source,createdAt:result.createdAt,total:1,counts:{[result.ok?'PASS':'FAIL']:1},result}; latest.runs.push(run); latest.runs=latest.runs.slice(-500); this.write(sessionId,latest);
      this.notify(sessionId,{level:result.ok?'success':'error',title:`${result.ok?'نجح':'فشل'}: ${rule.name}`,message:result.summary||'انتهى تشغيل القاعدة.',connectionId:c.id,runId:run.id});
      return {run,result};
    } catch (error) { const msg=sanitizeError(error); this.notify(sessionId,{level:'error',title:'فشل تشغيل قاعدة تكامل',message:msg}); throw error; }
    finally { this.runningRules.delete(key); }
  }
  toggleRule(sessionId, ruleId, enabled) {
    const data=this.read(sessionId), r=data.rules.find(x=>x.id===ruleId); if(!r) throw new Error('القاعدة غير موجودة.'); const c=data.connections.find(x=>x.id===r.connectionId); if(enabled && !this.ruleSupported(c,r)) throw new Error('لا يمكن تشغيل القاعدة: القدرة المطلوبة غير مؤكدة. اضغط «اكتشاف وفحص» أولًا.'); r.enabled=Boolean(enabled); r.updatedAt=isoNow(); this.write(sessionId,data); return { ...r, supported:this.ruleSupported(c,r) };
  }
  async handleWebhook(token, payload={}) {
    const hash=this.tokenHash(token); let matched=null, sessionId=null;
    for (const session of this.store.listSessionIds()) { const data=this.read(session); const c=data.connections.find(x=>{ if(x.type!=='webhook'||! /^[a-f0-9]{64}$/i.test(String(x.webhookTokenHash||''))) return false; const saved=Buffer.from(x.webhookTokenHash,'hex'), supplied=Buffer.from(hash,'hex'); return saved.length===supplied.length && crypto.timingSafeEqual(saved,supplied); }); if(c){matched=c;sessionId=session;break;} }
    if(!matched) throw new Error('رابط Webhook غير صحيح أو تم تدويره.');
    const d=this.read(sessionId), c=d.connections.find(x=>x.id===matched.id); c.webhookReceived=(c.webhookReceived||0)+1; c.webhookLastReceivedAt=isoNow(); c.updatedAt=isoNow(); this.write(sessionId,d);
    this.notify(sessionId,{level:'info',title:`وصل حدث Webhook: ${c.name}`,message:`تم استقبال الحدث رقم ${c.webhookReceived}. حجم المحتوى التقريبي ${Buffer.byteLength(JSON.stringify(payload||{}))} بايت.`,connectionId:c.id});
    const dueRules=this.read(sessionId).rules.filter(r=>r.connectionId===c.id&&r.enabled&&r.triggerType==='webhook'); const results=[];
    for(const r of dueRules){try{results.push(await this.runRule(sessionId,r.id,{source:'webhook',payload}));}catch(e){results.push({error:sanitizeError(e),ruleId:r.id});}}
    return {sessionId,connectionId:c.id,received:c.webhookReceived,triggered:results.length};
  }
  notify(sessionId, item) {
    const d=this.read(sessionId); const n={id:id('notice'),at:isoNow(),level:item.level||'info',title:String(item.title||'نشاط التكامل').slice(0,180),message:String(item.message||'').slice(0,1200),connectionId:item.connectionId||'',runId:item.runId||''}; d.inbox.push(n); d.inbox=d.inbox.slice(-500); this.write(sessionId,d);
    try { this.logger(sessionId,n.level==='error'?'ERROR':n.level==='warning'?'WARN':'INFO',`[التكاملات] ${n.title}: ${n.message}`); } catch {}
    if(d.settings.whatsappNotificationsEnabled===true && d.settings.whatsappTarget && this.whatsapp && ['error','warning'].includes(n.level)) {
      const s=this.store.loadSession(sessionId); const target=d.settings.whatsappTarget; let chatId='';
      if(target.startsWith('g:')) { const g=s.groups.find(x=>`g:${x.id}`===target); chatId=g?.gid||''; }
      else if(target.startsWith('r:')) { const r=s.recipients.find(x=>`r:${x.id}`===target); chatId=r?.jid||r?.whatsappJid||((r?.digits||r?.e164||r?.phone||'').replace(/\D/g,'')+'@c.us'); }
      if(chatId) this.whatsapp.sendText(sessionId,chatId,`تنبيه من chat BOT\n${n.title}\n${n.message}`).catch(error=>{ try{this.logger(sessionId,'WARN',`تعذر إرسال تنبيه WhatsApp الاختياري: ${sanitizeError(error)}`);}catch{} });
    }
    return n;
  }
  updateSettings(sessionId, input={}) {
    const d=this.read(sessionId); const enabled=input.whatsappNotificationsEnabled===true; const target=String(input.whatsappTarget||'');
    if(enabled && !target) throw new Error('اختر مستلمًا قبل تفعيل تنبيهات WhatsApp.');
    if(enabled && !/^(?:r|g):[A-Za-z0-9_-]+$/.test(target)) throw new Error('اختيار مستلم تنبيهات WhatsApp غير صالح.');
    d.settings.whatsappNotificationsEnabled=enabled; d.settings.whatsappTarget=enabled?target:''; this.write(sessionId,d); return d.settings;
  }
  async runScheduled() {
    if (this.paused) return;
    this.scheduledTicks++;
    try {
    for (const sessionId of this.store.listSessionIds()) {
      const d=this.read(sessionId); const now=Date.now();
      for (const r of d.rules) {
        if (!r.enabled || r.triggerType!=='schedule' || this.runningRules.has(`${sessionId}|${r.id}`)) continue;
        const interval=clamp(r.everyMinutes,1,1440,15)*60000; const last=Date.parse(r.lastRunAt||r.createdAt||0)||0;
        if(now-last<interval) continue;
        // Persist a reservation before starting work to avoid duplicate runs in quick polling loops.
        const fresh=this.read(sessionId), fr=fresh.rules.find(x=>x.id===r.id); if(!fr||!fr.enabled||Date.parse(fr.lastRunAt||fr.createdAt||0)+interval>now) continue;
        fr.lastRunAt=new Date(now).toISOString(); this.write(sessionId,fresh);
        this.runRule(sessionId,r.id,{source:'schedule'}).catch(e=>{ try{this.logger(sessionId,'WARN',`فشلت القاعدة المجدولة: ${sanitizeError(e)}`);}catch{} });
      }
    }
    } finally { this.scheduledTicks--; }
  }
  start() { if(this.timer) return; this.timer=setInterval(()=>{ if(!this.paused) this.runScheduled().catch(()=>{}); },60000); this.timer.unref?.(); }
  async pause() { this.paused = true; this.stop(); for (let i=0; i<300 && (this.scheduledTicks > 0 || this.runningRules.size > 0); i++) await new Promise(resolve=>setTimeout(resolve,50)); if (this.scheduledTicks > 0 || this.runningRules.size > 0) { this.paused = false; this.start(); throw new Error('لا يمكن إيقاف مركز التكاملات الآن لأن قاعدة ما زالت تعمل. أعد المحاولة بعد انتهائها.'); } }
  resume() { this.paused = false; this.start(); }
  stop() { if(this.timer) clearInterval(this.timer); this.timer=null; }
  report(sessionId, runId) { const d=this.read(sessionId); const run=d.runs.find(x=>x.id===runId); if(!run) throw new Error('تقرير الفحص غير موجود.'); return run; }
}
module.exports = { IntegrationHub, TEST_CATALOG, RULE_TEMPLATES, FAMILIES, TYPES, parseOpenApi, validateHttpUrl, COMMANDS, MAX_RESPONSE_BYTES };
