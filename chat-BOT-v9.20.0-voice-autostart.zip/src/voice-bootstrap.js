'use strict';

// One-time, project-owned voice runtime provisioning. It is intentionally
// non-blocking for the HTTP server; the normal bot UI remains available while
// Python packages and local models are prepared.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const { pipeline } = require('node:stream/promises');
const { Readable } = require('node:stream');

const PYTHON_VERSION = '3.13.17';
const PYTHON_INSTALLER_URL = `https://www.python.org/ftp/python/${PYTHON_VERSION}/python-${PYTHON_VERSION}-amd64.exe`;
const PYTHON_INSTALLER_SHA256 = '5da012101ba2e17113a9a1cd901e9ce1441086f2b7ecb5de06ec94163899a190';
const PIPER_MODEL_URL = 'https://huggingface.co/rhasspy/piper-voices/resolve/main/ar/ar_JO/kareem/medium/ar_JO-kareem-medium.onnx';
const PIPER_MODEL_SHA256 = '9e95cab07b679da603bba17c4dec7ab3111320571964ee95c0379603c086491e';
const REQUIRED_PACKAGES = [
  'faster-whisper>=1.1,<2', 'piper-tts>=1.8,<2', 'edge-tts>=7.3,<8',
  'imageio-ffmpeg>=0.5,<1', 'huggingface-hub>=0.25,<2'
];

function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function safeError(error) { return String(error?.message || error || 'فشل إعداد الصوت').replace(/https?:\/\/\S+/g, '[رابط خدمة]').replace(/(?:[A-Za-z]:\\(?:[^\\\s]+\\)*[^\s,;]*)/g, '[مسار محلي]').slice(0, 420); }
function sha256File(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256'); const stream = fs.createReadStream(filePath);
    stream.on('data', chunk => hash.update(chunk)); stream.on('error', reject); stream.on('end', () => resolve(hash.digest('hex')));
  });
}
function run(command, args, { cwd, timeout = 120000, env = process.env, input = undefined, onOutput = () => {}, maxOutput = 1_000_000 } = {}) {
  return new Promise((resolve, reject) => {
    let stdout = ''; let stderr = ''; let done = false; let timer;
    let child;
    try { child = spawn(command, args, { cwd, env, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] }); }
    catch (error) { reject(error); return; }
    const finish = (error, code = 0) => { if (done) return; done = true; clearTimeout(timer); error ? reject(error) : (code === 0 ? resolve({ stdout, stderr, code }) : reject(new Error(`${path.basename(command)} انتهى برمز ${code}: ${safeError(stderr || stdout)}`))); };
    child.stdout.on('data', chunk => { const value = String(chunk); stdout = (stdout + value).slice(-maxOutput); onOutput(value, 'stdout'); });
    child.stderr.on('data', chunk => { const value = String(chunk); stderr = (stderr + value).slice(-maxOutput); onOutput(value, 'stderr'); });
    child.once('error', error => finish(new Error(`تعذر تشغيل ${path.basename(command)}: ${safeError(error)}`)));
    child.once('close', code => finish(null, code ?? 1));
    timer = setTimeout(() => { try { child.kill('SIGTERM'); } catch {} finish(new Error(`انتهت مهلة ${path.basename(command)}.`)); }, timeout);
    timer.unref?.();
    if (input !== undefined) child.stdin.end(input); else child.stdin.end();
  });
}

class VoiceBootstrap {
  constructor({ root = path.resolve(__dirname, '..'), env = process.env, logger = () => {}, fetchImpl = globalThis.fetch } = {}) {
    this.root = path.resolve(root); this.env = env; this.log = logger; this.fetch = fetchImpl;
    this.venvDir = path.join(this.root, '.voice-venv');
    this.modelDir = path.join(this.root, 'models', 'faster-whisper-small');
    this.piperModel = path.join(this.root, 'models', 'ar_JO-kareem-medium.onnx');
    this.state = { state: 'idle', stage: 'لم يبدأ', progress: 0, message: 'سيتم إعداد محركات الصوت تلقائيًا عند تشغيل البوت.', startedAt: null, updatedAt: new Date().toISOString(), attempts: 0 };
    this.promise = null;
    this.retryTimer = null;
    this.maxAttempts = 4;
  }
  update(state, stage, progress, message, error = '') {
    this.state = { ...this.state, state, stage, progress: Math.max(0, Math.min(100, Number(progress) || 0)), message: String(message || '').slice(0, 500), error: String(error || '').slice(0, 500), updatedAt: new Date().toISOString() };
    try { this.log(state === 'failed' ? 'WARN' : 'INFO', `[VOICE_BOOTSTRAP] ${stage}: ${this.state.message}`); } catch {}
  }
  publicStatus() {
    return { ...this.state, startedAt: this.state.startedAt, updatedAt: this.state.updatedAt, ready: this.state.state === 'ready', retryScheduled: Boolean(this.retryTimer), languages: ['ar', 'en', 'fr', 'de'], localTranscription: this.state.state === 'ready', networkSpeech: 'يُختبر الاتصال العصبي عند تشغيل اختبار اللغات الأربع؛ وقد يعمل البديل المحلي حتى إذا تعذر الإنترنت' };
  }
  async waitUntilReady({ timeoutMs = 45 * 60 * 1000, pollMs = 1000 } = {}) {
    const timeout = Math.max(60_000, Math.min(60 * 60 * 1000, Number(timeoutMs) || 45 * 60 * 1000));
    const poll = Math.max(250, Math.min(5000, Number(pollMs) || 1000));
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const status = this.publicStatus();
      if (status.ready) return status;
      if (status.state === 'failed' && !status.retryScheduled && Number(status.attempts || 0) >= this.maxAttempts) return status;
      if (status.state === 'idle' && !this.promise && !this.retryTimer) {
        const autoStart = !['0', 'false', 'off', 'no'].includes(String(this.env.VOICE_AUTOSTART || 'true').trim().toLowerCase());
        if (!autoStart) return status;
        this.start().catch(() => {});
      }
      await delay(Math.min(poll, Math.max(1, deadline - Date.now())));
    }
    return { ...this.publicStatus(), timedOut: true, message: 'انتهت مهلة انتظار تهيئة الصوت؛ لم يتم تفريغ هذه الصوتية بعد.' };
  }
  start() {
    if (this.state.state === 'ready') return Promise.resolve(this.publicStatus());
    if (this.promise) return this.promise;
    if (this.retryTimer) { clearTimeout(this.retryTimer); this.retryTimer = null; }
    this.state.startedAt = this.state.startedAt || new Date().toISOString();
    this.state.attempts = Number(this.state.attempts || 0) + 1;
    this.promise = this.runSetup().then(() => this.publicStatus()).catch(error => {
      const message = safeError(error);
      const retryDelays = [30_000, 120_000, 300_000];
      const attempt = Number(this.state.attempts || 1);
      if (attempt < this.maxAttempts) {
        const retryDelay = retryDelays[Math.min(attempt - 1, retryDelays.length - 1)];
        this.update('failed', `فشلت المحاولة ${attempt} من ${this.maxAttempts} — ستتم إعادة المحاولة تلقائيًا`, this.state.progress, `تعذر إكمال إعداد الصوت: ${message}. سيعيد المشروع المحاولة تلقائيًا بعد ${Math.round(retryDelay / 1000)} ثانية؛ لا تحتاج إلى تشغيل مثبت.`, message);
        this.retryTimer = setTimeout(() => { this.retryTimer = null; this.start(); }, retryDelay);
        this.retryTimer.unref?.();
      } else {
        this.update('failed', 'تعذر إكمال التهيئة التلقائية بعد عدة محاولات', this.state.progress, `ظلّ البوت يعمل، لكن الصوت غير جاهز: ${message}. راجع تقرير الصوت داخل لوحة التحكم.`, message);
      }
      return this.publicStatus();
    }).finally(() => { this.promise = null; });
    return this.promise;
  }
  async download(url, destination, { maxBytes = 1024 * 1024 * 1024, expectedSha256 = '', progressBase = 0, progressSpan = 1 } = {}) {
    if (typeof this.fetch !== 'function') throw new Error('بيئة Node لا تحتوي fetch لتنزيل محركات الصوت.');
    const response = await this.fetch(url, { redirect: 'follow', signal: AbortSignal.timeout(600000) });
    if (!response.ok || !response.body) throw new Error(`فشل تنزيل مكون الصوت (HTTP ${response.status}).`);
    const finalUrl = new URL(response.url || url);
    if (finalUrl.protocol !== 'https:') throw new Error('تم رفض تنزيل مكون صوت من رابط غير مشفر.');
    const length = Number(response.headers.get('content-length') || 0);
    if (length > maxBytes) throw new Error('حجم ملف الصوت أكبر من الحد المسموح.');
    fs.mkdirSync(path.dirname(destination), { recursive: true });
    const temp = `${destination}.download-${process.pid}-${Date.now()}`;
    let received = 0; const hash = crypto.createHash('sha256');
    const source = Readable.fromWeb(response.body);
    const meter = new (require('node:stream').Transform)({ transform: (chunk, _encoding, callback) => {
      received += chunk.length;
      if (received > maxBytes) return callback(new Error('تجاوز تنزيل مكون الصوت الحد المسموح.'));
      hash.update(chunk);
      if (length > 0) this.update('preparing', 'تنزيل مكونات الصوت', progressBase + Math.min(progressSpan, (received / length) * progressSpan), `تم تنزيل ${Math.round(received / 1024 / 1024)} من ${Math.max(1, Math.round(length / 1024 / 1024))} ميجابايت.`);
      callback(null, chunk);
    }});
    try {
      await pipeline(source, meter, fs.createWriteStream(temp, { flags: 'wx', mode: 0o600 }));
      const digest = hash.digest('hex');
      if (expectedSha256 && digest.toLowerCase() !== expectedSha256.toLowerCase()) throw new Error('فشل التحقق من بصمة ملف الصوت؛ حُذف الملف غير المطابق.');
      fs.rmSync(destination, { force: true }); fs.renameSync(temp, destination);
      return { bytes: received, sha256: digest };
    } catch (error) { fs.rmSync(temp, { force: true }); throw error; }
  }
  async commandExists(command) {
    if (!command) return false;
    if (path.isAbsolute(command) || /[\\/]/.test(command)) return fs.existsSync(command) && fs.statSync(command).isFile();
    try { await run(process.platform === 'win32' ? 'where.exe' : 'which', [command], { timeout: 5000, maxOutput: 20000 }); return true; } catch { return false; }
  }
  pythonCommand(exe, prefix = []) { return { exe, prefix }; }
  async pythonWorks(command) {
    try {
      const result = await run(command.exe, [...command.prefix, '-c', 'import sys;print("%d.%d.%d" % sys.version_info[:3]);raise SystemExit(0 if (3,10) <= sys.version_info[:2] < (3,14) else 2)'], { timeout: 10000, maxOutput: 20000 });
      return { ok: true, version: result.stdout.trim().split(/\r?\n/).at(-1) };
    } catch { return { ok: false, version: '' }; }
  }
  async findBasePython() {
    const candidates = [];
    if (process.platform === 'win32') {
      for (const version of ['-3.13', '-3.12', '-3.11', '-3.10']) candidates.push(this.pythonCommand('py.exe', [version]));
      candidates.push(this.pythonCommand('python.exe'), this.pythonCommand('python'));
    } else {
      candidates.push(this.pythonCommand('python3.13'), this.pythonCommand('python3.12'), this.pythonCommand('python3.11'), this.pythonCommand('python3.10'), this.pythonCommand('python3'), this.pythonCommand('python'));
    }
    for (const candidate of candidates) { if ((await this.pythonWorks(candidate)).ok) return candidate; }
    return null;
  }
  async ensurePython() {
    const local = process.platform === 'win32' ? path.join(this.venvDir, 'Scripts', 'python.exe') : path.join(this.venvDir, 'bin', 'python');
    if (fs.existsSync(local) && (await this.pythonWorks(this.pythonCommand(local))).ok) return local;
    this.update('preparing', 'البحث عن Python المتوافق', 3, 'يتم فحص بيئة المشروع وPython المتوافق تلقائيًا.');
    let base = await this.findBasePython();
    if (!base && process.platform === 'win32' && process.arch === 'x64') {
      this.update('preparing', 'تجهيز Python داخل المشروع', 5, 'لا يوجد Python متوافق؛ سيتم تنزيل المثبت الرسمي والتحقق من بصمته وتثبيته داخل مجلد المشروع.');
      const installer = path.join(this.root, '.runtime-downloads', `python-${PYTHON_VERSION}-amd64.exe`);
      if (!fs.existsSync(installer) || await sha256File(installer).catch(() => '') !== PYTHON_INSTALLER_SHA256) {
        await this.download(PYTHON_INSTALLER_URL, installer, { maxBytes: 80 * 1024 * 1024, expectedSha256: PYTHON_INSTALLER_SHA256, progressBase: 5, progressSpan: 4 });
      }
      const installDir = path.join(this.root, '.voice-python');
      const installArgs = ['/quiet', `TargetDir=${installDir}`, 'Include_launcher=0', 'Include_test=0', 'Include_doc=0', 'Include_tcltk=0', 'Include_dev=0', 'Include_pip=1', 'Shortcuts=0', 'PrependPath=0'];
      await run(installer, installArgs, { cwd: this.root, timeout: 240000, maxOutput: 60000 });
      const exe = path.join(installDir, 'python.exe');
      if (!(await this.pythonWorks(this.pythonCommand(exe))).ok) throw new Error('تم تشغيل مثبت Python لكن لم يجتز فحص الإصدار.');
      base = this.pythonCommand(exe);
    }
    if (!base) throw new Error('لم يُعثر على Python 3.10–3.13 متوافق. على Windows x64 سيحاول المشروع تنزيل Python رسميًا تلقائيًا؛ على الأنظمة الأخرى ثبّت Python متوافقًا مرة واحدة ثم أعد تشغيل البوت.');
    this.update('preparing', 'إنشاء بيئة Python خاصة بالمشروع', 10, 'تُعزل مكتبات الصوت داخل .voice-venv ولا تغيّر مكتبات Python العامة.');
    fs.rmSync(this.venvDir, { recursive: true, force: true });
    fs.mkdirSync(path.dirname(this.venvDir), { recursive: true });
    await run(base.exe, [...base.prefix, '-m', 'venv', this.venvDir], { cwd: this.root, timeout: 90000, maxOutput: 100000 });
    if (!(await this.pythonWorks(this.pythonCommand(local))).ok) throw new Error('لم تُنشأ بيئة Python الصوتية بنجاح.');
    return local;
  }
  async packagesAvailable(python) {
    try {
      const result = await run(python, ['-c', 'import importlib.util,json;print(json.dumps({"whisper":bool(importlib.util.find_spec("faster_whisper")),"piper":bool(importlib.util.find_spec("piper")),"edge":bool(importlib.util.find_spec("edge_tts")),"ffmpeg":bool(importlib.util.find_spec("imageio_ffmpeg")),"hub":bool(importlib.util.find_spec("huggingface_hub"))}))'], { cwd: this.root, timeout: 20000, maxOutput: 20000 });
      return JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1));
    } catch { return {}; }
  }
  async ensurePackages(python) {
    const required = await this.packagesAvailable(python);
    const piper = path.join(this.venvDir, process.platform === 'win32' ? 'Scripts/piper.exe' : 'bin/piper');
    if (required.whisper && required.piper && required.edge && required.ffmpeg && required.hub && fs.existsSync(piper)) { this.update('preparing', 'المكتبات الصوتية جاهزة', 30, 'تم العثور على Faster-Whisper وPiper وEdge TTS وFFmpeg.'); return piper; }
    this.update('preparing', 'تثبيت المكتبات الصوتية', 15, 'يتم تثبيت محركات التفريغ والنطق والتحويل تلقائيًا؛ لا يلزم تشغيل مثبت منفصل.');
    let lastError;
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        await run(python, ['-m', 'pip', 'install', '--disable-pip-version-check', '--upgrade', 'pip<27', ...REQUIRED_PACKAGES], {
          cwd: this.root, timeout: 12 * 60 * 1000, maxOutput: 500000,
          onOutput: (chunk) => { if (/Installing collected packages|Successfully installed|Downloading|Collecting/i.test(chunk)) this.update('preparing', 'تثبيت المكتبات الصوتية', 18, 'جارٍ تنزيل وتثبيت مكتبات الصوت اللازمة.'); }
        });
        const after = await this.packagesAvailable(python);
        if (!(after.whisper && after.piper && after.edge && after.ffmpeg && after.hub && fs.existsSync(piper))) throw new Error('اكتمل أمر pip لكن فحص مكتبات الصوت لم ينجح.');
        return piper;
      } catch (error) { lastError = error; if (attempt < 2) await delay(3000); }
    }
    throw new Error(`تعذر تثبيت مكتبات الصوت تلقائيًا: ${safeError(lastError)}`);
  }
  async ensurePiperModel() {
    const target = this.piperModel; const config = `${target}.json`;
    let modelValid = false;
    if (fs.existsSync(target) && fs.statSync(target).size > 10_000_000) modelValid = (await sha256File(target).catch(() => '')) === PIPER_MODEL_SHA256;
    let configValid = false;
    try { const json = JSON.parse(fs.readFileSync(config, 'utf8')); configValid = Boolean(json?.audio && json?.phoneme_type); } catch {}
    if (modelValid && configValid) return;
    this.update('preparing', 'تنزيل الصوت العربي المحلي', 43, 'يتم تنزيل نموذج Piper العربي والتحقق من بصمته.');
    await this.download(PIPER_MODEL_URL, target, { maxBytes: 120 * 1024 * 1024, expectedSha256: PIPER_MODEL_SHA256, progressBase: 43, progressSpan: 12 });
    await this.download(`${PIPER_MODEL_URL}.json`, config, { maxBytes: 4 * 1024 * 1024, progressBase: 55, progressSpan: 2 });
    const parsed = JSON.parse(fs.readFileSync(config, 'utf8'));
    if (!parsed?.audio || !parsed?.phoneme_type) throw new Error('نموذج الصوت العربي نُزّل لكن ملف إعداداته غير صالح.');
  }
  async runWorker(python, action, args = [], timeout = 30000) {
    const worker = path.join(this.root, 'scripts', 'voice_worker.py');
    const result = await run(python, [worker, action, ...args], { cwd: this.root, timeout, maxOutput: 150000, env: { ...process.env, WHISPER_PY_MODEL_PATH: this.modelDir } });
    const line = result.stdout.trim().split(/\r?\n/).filter(Boolean).at(-1) || '{}';
    const payload = JSON.parse(line);
    if (payload.ok !== true) throw new Error(String(payload.error || `فشل عامل الصوت: ${action}`));
    return payload;
  }
  writeEnv(values) {
    const envFile = path.join(this.root, '.env');
    let source = fs.existsSync(envFile) ? fs.readFileSync(envFile, 'utf8') : '';
    const lines = source.split(/\r?\n/);
    for (const [key, value] of Object.entries(values)) {
      this.env[key] = String(value);
      let found = false;
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim().replace(/^export\s+/, '');
        const equalsAt = line.indexOf('=');
        if (equalsAt > 0 && line.slice(0, equalsAt).trim() === key) { lines[i] = `${key}=${JSON.stringify(String(value))}`; found = true; }
      }
      if (!found) lines.push(`${key}=${JSON.stringify(String(value))}`);
    }
    source = lines.join('\n').replace(/\n+$/, '') + '\n';
    const temp = `${envFile}.voice-${process.pid}.tmp`;
    fs.writeFileSync(temp, source, { mode: 0o600 }); fs.renameSync(temp, envFile);
  }
  async runSetup() {
    this.update('preparing', 'بدء التهيئة التلقائية', 1, 'ستُجهز المكتبات والنماذج داخل المشروع. أول تشغيل يحتاج اتصال إنترنت ومساحة تخزين.');
    const python = await this.ensurePython();
    const piper = await this.ensurePackages(python);
    this.update('preparing', 'تجهيز نموذج التفريغ المحلي', 32, 'إذا لم يكن نموذج Faster-Whisper موجودًا فسيتم تنزيله الآن.');
    const whisperReady = fs.existsSync(path.join(this.modelDir, 'model.bin')) && fs.existsSync(path.join(this.modelDir, 'config.json'));
    if (!whisperReady) await this.runWorker(python, 'prepare', ['small'], 30 * 60 * 1000);
    this.update('preparing', 'فحص نموذج التفريغ', 60, 'يتم تحميل النموذج المحلي للتأكد من اكتماله.');
    // Reuse the worker status and FFmpeg bundled by imageio-ffmpeg.
    const status = await this.runWorker(python, 'status', [], 30000);
    const ffmpegPath = status.ffmpegPath;
    if (!ffmpegPath || !fs.existsSync(ffmpegPath)) throw new Error('تعذر العثور على FFmpeg من حزمة imageio-ffmpeg.');
    await this.ensurePiperModel();
    const envValues = {
      VOICE_PYTHON_BIN: python,
      WHISPER_BACKEND: ['openai-compatible'].includes(String(this.env.WHISPER_BACKEND || '').toLowerCase()) ? this.env.WHISPER_BACKEND : 'python-faster-whisper',
      WHISPER_PY_MODEL: 'small',
      WHISPER_PY_MODEL_PATH: this.modelDir,
      TTS_BACKEND: ['openai-compatible'].includes(String(this.env.TTS_BACKEND || '').toLowerCase()) ? this.env.TTS_BACKEND : 'auto',
      PIPER_BIN: piper,
      PIPER_MODEL_PATH: this.piperModel,
      FFMPEG_BIN: ffmpegPath,
    };
    this.writeEnv(envValues);
    this.update('preparing', 'اختبار النطق والتحويل والتفريغ', 72, 'يتم توليد صوت عربي فعلي وتحويله إلى OGG/Opus ثم تفريغه محليًا قبل إعلان الجاهزية.');
    const smoke = await this.runWorker(python, 'voice-smoke-test', [piper, this.piperModel, ffmpegPath, this.modelDir], 7 * 60 * 1000);
    if (smoke.piper !== true || smoke.ffmpegOpus !== true || smoke.fasterWhisper !== true || !String(smoke.transcript || '').trim()) throw new Error('اختبار الصوت الفعلي لم يؤكد نجاح جميع مراحل التوليد والتحويل والتفريغ.');
    this.update('ready', 'اكتمل إعداد الصوت تلقائيًا', 100, 'النطق العربي المحلي وتفريغ الصوت يعملان في الاختبار الفعلي. النطق متعدد اللغات عبر الإنترنت متاح عند توفر الخدمة.');
    return this.publicStatus();
  }
}

module.exports = { VoiceBootstrap, REQUIRED_PACKAGES, PYTHON_VERSION, PYTHON_INSTALLER_SHA256, PIPER_MODEL_SHA256 };
