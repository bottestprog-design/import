'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const pkg = JSON.parse(read('package.json'));
const lock = JSON.parse(read('package-lock.json'));
const store = read('src/store.js');
const server = read('server.js');
const app = read('public/app.js');
const css = read('public/styles.css');
const wa = read('src/whatsapp.js');
const media = require('../src/media');

assert.equal(pkg.version, '9.20.20', 'phase three regression suite must remain integrated without resetting project history');
assert.equal(lock.version, '9.20.20');
assert.match(store, /APP_VERSION = '9\.20\.20'/);
assert.match(server, /app\.post\('\/api\/conversations\/download-media'/);
assert.match(server, /confirmedDownloadMedia !== true/);
const downloadRoute = server.slice(server.indexOf("app.post('/api/conversations/download-media'"));
assert.ok(downloadRoute.indexOf('confirmedDownloadMedia !== true') < downloadRoute.indexOf('whatsapp.getChatSafe(id, target.chatId)'), 'media download must require explicit confirmation before opening target chat');
assert.match(server, /conversationTargets\.targetIsEnabled\(target\)/);
assert.match(server, /allowedConversationTarget\(id, req\.body\?\.targetKey\)/);
assert.match(server, /conversationTargets\.targetKeyForChat\(freshSession, actualChatId, whatsapp\.selfChatId\(id\)\) !== target\.key/);
assert.match(server, /whatsapp\.downloadMediaFromChat\(id, actualChatId/);
assert.match(server, /requestedMessages = Math\.max\(1, Math\.min\(500/);
assert.match(server, /requestedFiles = Math\.max\(1, Math\.min\(100/);
assert.match(server, /asksForMedia && body\.confirmedMediaSend !== true/);
assert.ok(server.indexOf('asksForMedia && body.confirmedMediaSend !== true') < server.indexOf('delivery.sendNow(sid(req), body)'), 'API guard must run before any send call');
assert.match(server, /fileStat\.size > maxFileBytes/);
assert.match(server, /fs\.rmSync\(file\.path, \{ force: true \}\)/);
assert.match(app, /id="conversationDownloadMediaBtn"/);
assert.match(app, /id="conversationMediaType"/);
assert.match(app, /value="sticker"/);
assert.match(app, /تأكيد تنزيل مرفقات المحادثة/);
assert.match(app, /confirmedDownloadMedia: true/);
assert.match(app, /confirmedMediaSend: mediaIds\.length > 0/);
assert.match(app, /تحويل الصور إلى ملصقات WhatsApp/);
assert.match(app, /id=\"mediaSearch\"/);
assert.match(app, /id=\"mediaTypeFilter\"/);
assert.match(app, /id=\"mediaSort\"/);
assert.match(app, /تحديد النتائج الظاهرة/);
assert.match(app, /selectedMedia:\s*new Set\(\)/, 'the media picker must start with no files selected for accidental sending');
assert.match(app, /الملفات الجديدة لم تُحدد للإرسال تلقائيًا/, 'uploading a file must not automatically queue it for sending');
assert.match(app, /confirmedMediaSend: mediaIds\.length > 0/);
assert.match(app, /تأكيد الإرسال/);
assert.match(app, /media-library-filters/);
assert.match(wa, /sendMediaAsSticker: true/);
assert.match(wa, /downloadMediaFromChat\(/);
assert.match(css, /\.conversation-media-tools\{/);

// Verify that the local file library recognizes the supported visual, sticker, audio and document formats.
for (const ext of ['.jpg', '.png', '.webp', '.mp4', '.mov', '.3gp', '.m4v', '.mpeg', '.mpg', '.ogg', '.pdf', '.zip']) assert.ok(media.MEDIA_EXT.has(ext), `${ext} must remain supported`);
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-phase3-media-'));
try {
  fs.writeFileSync(path.join(tmp, 'sample.webp'), Buffer.from('sticker-preview'));
  fs.writeFileSync(path.join(tmp, 'notes.pdf'), Buffer.from('pdf-preview'));
  const scanned = media.scan(tmp, 1);
  assert.equal(scanned.files.length, 2);
  assert.equal(scanned.images.length, 1);
  assert.ok(scanned.files.some(file => file.filename === 'notes.pdf'));
  assert.equal(path.dirname(media.safePath(tmp, '../outside.pdf')), path.resolve(tmp), 'path resolution must keep untrusted names inside the session library');
} finally { fs.rmSync(tmp, { recursive: true, force: true }); }

console.log('phase3-media-workflow: ok (version chain, registered-chat attachment route, local media filters, safe default selection, confirmation guards, image-to-sticker mode and expanded media classification)');
