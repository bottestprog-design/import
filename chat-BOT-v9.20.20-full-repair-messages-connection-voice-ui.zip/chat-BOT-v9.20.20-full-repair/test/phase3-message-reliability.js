'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const pkg = JSON.parse(read('package.json'));
const lock = JSON.parse(read('package-lock.json'));
const store = read('src/store.js');
const server = read('server.js');
const interaction = read('src/interaction.js');
const automation = read('src/automation-engine.js');
const scheduler = read('src/scheduler.js');
const ui = read('public/app.js');
const timePolicy = read('src/time-policy.js');
const envExample = read('.env.example');

assert.equal(pkg.version, '9.20.20');
assert.equal(lock.version, pkg.version);
assert.equal(lock.packages[''].version, pkg.version);
assert.match(store, /APP_VERSION = '9\.20\.20'/);
assert.match(store, /schemaVersion: 12/);
assert.match(store, /maxInboundMessageAgeSec: 300/);
assert.match(store, /maxInboundQueueWaitSec: 60/);
assert.match(store, /maxInboundQueueDepth: 40/);
assert.match(store, /seenEvents: \{\}/);
assert.match(store, /lastAttempt/);
assert.match(server, /VOICE_AUDIO_WAIT_TIMEOUT_MS\) \|\| 90 \* 1000/);
assert.match(envExample, /^VOICE_AUDIO_WAIT_TIMEOUT_MS=90000$/m, 'sample environment must not override the 90-second voice wait default');

assert.match(server, /new InboundMessageQueue\(\{ maxConcurrentSessions: 3/);
assert.match(server, /async function enqueueInboundMessage\(/);
assert.match(server, /async function processSelfChatMessage\(/);
assert.match(server, /claimInboundEvent\(id, chatId, msg, event\)/);
assert.match(server, /status: 'processing'/);
assert.match(server, /finishInboundEvent\(id, ledgerKey, 'processed'\)/);
assert.match(server, /isStaleMessage\(msg, maxAgeSec\)/);
assert.match(server, /maxWaitMs: \(Number\(settings\.maxInboundQueueWaitSec\)/);
assert.match(server, /maxPendingPerSession: Number\(settings\.maxInboundQueueDepth\)/);
assert.match(server, /await inboundQueue\.close\(\{ drain: true, timeoutMs: 15000 \}\)/);
assert.match(server, /isQuietHours\(latestSettings\)/);
assert.match(server, /quietAction\(latestSettings\) === 'rules'/);
const incomingStart = server.indexOf("whatsapp.on('message', async (id, msg) =>");
const incomingEnd = server.indexOf("whatsapp.on('message_create'", incomingStart);
const incomingRoute = server.slice(incomingStart, incomingEnd);
assert.ok(incomingRoute.indexOf('const archivePromise = archiveWhatsAppMessage') < incomingRoute.indexOf("enqueueInboundMessage(id, msg, 'incoming'"), 'archive begins before processing is queued');
assert.ok(incomingRoute.indexOf("enqueueInboundMessage(id, msg, 'incoming'") < incomingRoute.indexOf('await Promise.all([queued, archivePromise])'), 'message is enqueued before awaiting archive completion so event arrival order is preserved');
assert.match(incomingRoute, /await archivePromise;[\s\S]*return processIncomingMessage/);
const selfRouteStart = server.indexOf("whatsapp.on('message_create'");
const selfRouteEnd = server.indexOf("whatsapp.on('reaction'", selfRouteStart);
const selfRoute = server.slice(selfRouteStart, selfRouteEnd);
assert.ok(selfRoute.indexOf("enqueueInboundMessage(id, msg, 'owner-self-chat'") > selfRoute.indexOf('isProgrammaticOutgoing'), 'self-chat events are queued after outbound-programmatic filtering');
assert.match(server.slice(server.indexOf('async function processSelfChatMessage('), selfRouteStart), /isSelfChatMessage/);

assert.match(interaction, /isStaleMessage\(raw, s\.settings\.maxInboundMessageAgeSec \|\| 300\)/);
assert.match(interaction, /persistentSeen\[persistentKey\]/);
assert.match(interaction, /quietMode === 'rules'/);
assert.match(automation, /isStaleMessage\(msg, s\.settings\?\.maxInboundMessageAgeSec \|\| 300\)/);
assert.match(automation, /automationAllowedDuringQuiet\(s\.settings \|\| \{\}\)/);

assert.match(scheduler, /status: 'uncertain'/);
assert.match(scheduler, /\['done','partial','uncertain','blocked'\]/);
assert.match(scheduler, /if \(sent > 0\) return \{ status: 'partial', consume: true \}/);
assert.match(scheduler, /Intl\.DateTimeFormat\('en-US', \{ timeZone: tz, weekday: 'short', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' \}\)/);
assert.match(scheduler, /return null;[\s\S]*Nonexistent local times during a daylight-saving gap/);
assert.match(scheduler, /this\.busy\.has\(id\)/);
assert.match(scheduler, /location\.lastAttempt = \{ key, at: Date\.now\(\), retryAt: 0, status: 'running'/);

assert.match(timePolicy, /function isQuietHours\(/);
assert.match(timePolicy, /start < end \? current >= start && current < end : current >= start \|\| current < end/);
assert.match(ui, /id="opInboundAge"/);
assert.match(ui, /id="opQueueWait"/);
assert.match(ui, /id="opQueueDepth"/);
assert.match(ui, /maxInboundMessageAgeSec:/);
assert.match(ui, /maxInboundQueueWaitSec:/);
assert.match(ui, /maxInboundQueueDepth:/);

// Phase 1 and 2 remain in the release chain and their regression gates are preserved.
for (const file of [
  'CHANGELOG_V9_20_11_PHASE1_AR.md', 'CHANGELOG_V9_20_12_PHASE2_AR.md',
  'PHASE2_REVIEW_AR.md', 'PHASE2_VERIFICATION_AR.md',
  'test/phase2-conversation-authorization.js', 'test/tts-privacy-defaults.js',
  'scripts/voice-requirements.txt', 'src/voice-bootstrap.js',
]) assert.ok(fs.existsSync(path.join(root, file)), `previous phase file missing: ${file}`);
assert.ok(read('README.md').startsWith('# chat BOT v9.20.20'));
assert.ok(read('RELEASES_AR.md').startsWith('## v9.20.20'));
assert.match(read('CHANGELOG_V9_20_13_PHASE3_AR.md'), /طابور وارد/);
console.log('phase3-message-reliability: ok (release chain, durable dedupe, bounded queue, stale-message policy, quiet-hours gate, scheduler retry safety and previous-phase continuity)');
