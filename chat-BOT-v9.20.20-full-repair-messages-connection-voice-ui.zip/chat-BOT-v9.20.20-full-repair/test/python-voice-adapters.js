'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { EventEmitter } = require('node:events');
const { AudioTranscriber } = require('../src/audio-transcriber');
const { TextToSpeech, resolveVoiceTuning, VOICE_STYLE_PRESETS } = require('../src/text-to-speech');

(async () => {
  assert.equal(Object.keys(VOICE_STYLE_PRESETS).length, 6);
  assert.equal(resolveVoiceTuning({ style: 'calm' }).rate, -12);
  assert.equal(resolveVoiceTuning({ style: 'energetic', rate: 10 }).rate, 24);
  assert.equal(resolveVoiceTuning({ style: 'energetic' }).pitch, 4);
  assert.equal(resolveVoiceTuning({ style: 'missing' }).style, 'natural');

  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-python-voice-test-'));
  const voicePython = path.join(root, 'python.exe');
  const ffmpeg = path.join(root, 'ffmpeg.exe');
  const whisperModel = path.join(root, 'model');
  const temp = path.join(root, 'temp');
  fs.mkdirSync(whisperModel); fs.mkdirSync(temp);
  fs.writeFileSync(voicePython, 'mock-python'); fs.writeFileSync(ffmpeg, 'mock-ffmpeg');
  fs.writeFileSync(path.join(whisperModel, 'model.bin'), 'mock-model');
  fs.writeFileSync(path.join(whisperModel, 'config.json'), '{}');
  const workerPath = path.resolve(__dirname, '..', 'scripts', 'voice_worker.py');
  let transcribeInput = '', transcribeCalls = 0, transcribeLanguage = 'ar', spokenText = '', edgeArgs = [], conversionArgs = null, weakTranscript = false;
  try {
    const sttExec = async (binary, args) => {
      assert.equal(binary, voicePython);
      assert.equal(args[0], workerPath);
      if (args[1] === 'status') return { stdout: JSON.stringify({ ok: true, fasterWhisperAvailable: true, avCompatible: true, avVersion: '18.1.0', edgeTtsAvailable: true }) };
      if (args[1] === 'transcribe') {
        transcribeCalls++;
        transcribeInput = args[2];
        assert.ok(fs.existsSync(transcribeInput), 'temporary audio file must exist while the worker runs');
        assert.equal(path.extname(transcribeInput), '.ogg');
        assert.equal(args[3], transcribeLanguage);
        assert.equal(args[4], whisperModel);
        return { stdout: JSON.stringify({ ok: true, transcript: 'اختبار تفريغ صوت عربي', language: transcribeLanguage, languageProbability: weakTranscript ? 0.12 : 0.98, avgLogProbability: weakTranscript ? -1.8 : -0.15, avgNoSpeechProbability: weakTranscript ? 0.9 : 0.02, maxCompressionRatio: weakTranscript ? 3.6 : 1.15, segments: 2, lowConfidenceSegments: weakTranscript ? 2 : 0, duration: 2.4, backend: 'python-faster-whisper' }) };
      }
      throw new Error(`unexpected Python worker command ${args[1]}`);
    };
    const transcriber = new AudioTranscriber({
      env: { VOICE_PYTHON_BIN: voicePython, WHISPER_BACKEND: 'python-faster-whisper', WHISPER_PY_MODEL_PATH: whisperModel },
      execFileImpl: sttExec, tempDir: temp,
    });
    const sttStatus = await transcriber.status();
    assert.equal(sttStatus.ready, true, 'local Faster-Whisper must be ready when Python, module and model exist');
    assert.equal(sttStatus.ffmpegAvailable, false, 'the Python transcription backend must not require an external FFmpeg executable');
    const transcription = await transcriber.transcribeBuffer(Buffer.from('mock-ogg-bytes'), { extension: '.ogg', language: 'ar', source: 'test' });
    assert.equal(transcription.transcript, 'اختبار تفريغ صوت عربي');
    assert.equal(transcription.backend, 'python-faster-whisper');
    assert.equal(transcription.quality.status, 'clear');
    assert.equal(transcription.quality.actionable, true);
    assert.equal(transcription.quality.metadataSufficient, true);
    assert.equal(transcribeCalls, 1);
    assert.equal(fs.existsSync(transcribeInput), false, 'temporary audio must be removed after transcription');

    // Full online TTS adapter exercise with a fake Python worker and fake FFmpeg.
    const ttsRoot = path.join(root, 'tts-root');
    fs.mkdirSync(path.join(ttsRoot, 'scripts'), { recursive: true });
    fs.writeFileSync(path.join(ttsRoot, 'scripts', 'voice_worker.py'), '# test stub\n');
    let childCount = 0;
    const spawnImpl = (binary, args) => {
      assert.equal(binary, voicePython);
      assert.equal(args[0], path.join(ttsRoot, 'scripts', 'voice_worker.py'));
      assert.equal(args[1], 'edge-tts');
      edgeArgs = args.slice();
      const child = new EventEmitter();
      child.stdout = new EventEmitter(); child.stderr = new EventEmitter(); child.stdin = new EventEmitter();
      child.kill = () => {};
      child.stdin.end = value => {
        spokenText = String(value).trim();
        fs.writeFileSync(args[2], Buffer.alloc(256, 7));
        const stdout = JSON.stringify({ ok: true, path: args[2], bytes: 256, voice: args[3] });
        setImmediate(() => { child.stdout.emit('data', stdout); child.emit('close', 0); });
      };
      childCount++;
      return child;
    };
    const ttsExec = async (binary, args) => {
      if (binary === voicePython && args[1] === 'status') return { stdout: JSON.stringify({ ok: true, edgeTtsAvailable: true, piperAvailable: true }) };
      if (binary === ffmpeg) {
        conversionArgs = args.slice();
        const { createOggOpusFixture } = require('./ogg-opus-fixture'); fs.writeFileSync(args.at(-1), createOggOpusFixture(1024));
        return { stdout: '', stderr: '' };
      }
      throw new Error(`unexpected exec ${binary} ${args.join(' ')}`);
    };
    const tts = new TextToSpeech({
      root: ttsRoot, tempRoot: root,
      env: { VOICE_PYTHON_BIN: voicePython, FFMPEG_BIN: ffmpeg, TTS_BACKEND: 'auto', TTS_TIMEOUT_MS: '5000' },
      spawnImpl, execFileImpl: ttsExec,
    });
    const blockedStatus = await tts.status({ backend: 'edge-tts', voice: 'ar-OM-AyshaNeural' });
    assert.equal(blockedStatus.ready, false); assert.equal(blockedStatus.cloudConsentRequired, true);
    const ttsStatus = await tts.status({ backend: 'edge-tts', voice: 'ar-OM-AyshaNeural', allowCloud: true });
    assert.equal(ttsStatus.ready, true, 'online neural TTS must be ready when its Python package and FFmpeg are present');
    assert.equal(ttsStatus.voice, 'ar-OM-AyshaNeural', 'readiness should reflect the voice selected in settings');
    const generated = await tts.generate('أهلًا، هذا اختبار صوت عربي.', { proofread: false, backend: 'auto', allowCloud: true, voice: 'ar-OM-AyshaNeural', style: 'energetic', rate: 10, pitch: 0, volume: 0 });
    assert.equal(spokenText, 'أهلًا، هذا اختبار صوت عربي.');
    assert.equal(generated.voice, 'ar-OM-AyshaNeural');
    assert.equal(generated.style, 'energetic');
    assert.equal(generated.rate, 24);
    assert.equal(generated.pitch, 4);
    assert.equal(generated.volume, 6);
    assert.equal(edgeArgs[3], 'ar-OM-AyshaNeural');
    assert.equal(edgeArgs[4], '24');
    assert.equal(edgeArgs[5], '4');
    assert.equal(edgeArgs[6], '6');
    assert.equal(childCount, 1);
    const voiceNote = await tts.toWhatsAppVoice(generated.wavPath);
    assert.ok(fs.existsSync(voiceNote));
    assert.ok(conversionArgs.includes('libopus'));
    assert.equal(tts.cleanup(generated), true);

    // Auto mode selects a voice matching the language of the text, and each language can complete the TTS adapter path.
    for (const sample of [
      { language: 'en', text: 'Hello, how are you today?', voice: 'en-US-JennyNeural' },
      { language: 'fr', text: 'Bonjour, comment allez-vous?', voice: 'fr-FR-DeniseNeural' },
      { language: 'de', text: 'Guten Morgen, wie geht es Ihnen?', voice: 'de-DE-KatjaNeural' },
    ]) {
      const before = childCount;
      const multilingual = await tts.generate(sample.text, { proofread: false, backend: 'auto', allowCloud: true, voice: 'ar-EG-ShakirNeural', style: 'natural' });
      assert.equal(multilingual.backend, 'edge-tts');
      assert.equal(multilingual.voice, sample.voice);
      assert.equal(edgeArgs[3], sample.voice);
      assert.equal(childCount, before + 1);
      const multilingualOgg = await tts.toWhatsAppVoice(multilingual.wavPath);
      assert.ok(fs.existsSync(multilingualOgg));
      assert.equal(tts.cleanup(multilingual), true);
    }

    for (const language of ['en', 'fr', 'de']) {
      transcribeLanguage = language;
      const result = await transcriber.transcribeBuffer(Buffer.from(`mock-ogg-${language}`), { extension: '.ogg', language, source: 'four-language-adapter-test' });
      assert.equal(result.transcript, 'اختبار تفريغ صوت عربي');
      assert.equal(result.language, language);
      assert.equal(result.quality.status, 'clear', `four-language metadata must be assessed for ${language}`);
    }
    transcribeLanguage = 'ar';
    weakTranscript = true;
    const weak = await transcriber.transcribeBuffer(Buffer.from('low quality voice'), { extension: '.ogg', language: 'ar', source: 'quality-gate-test' });
    assert.equal(weak.quality.status, 'rejected');
    assert.equal(weak.quality.actionable, false, 'low-confidence local transcripts must not be treated as executable speech');
    weakTranscript = false;

    // A missing local model must fail closed with an actionable status.
    const missingModel = new AudioTranscriber({ env: { VOICE_PYTHON_BIN: voicePython, WHISPER_BACKEND: 'python-faster-whisper', WHISPER_PY_MODEL_PATH: path.join(root, 'missing-model') }, execFileImpl: sttExec, tempDir: temp });
    assert.equal((await missingModel.status()).ready, false);
    const incompatiblePyAv = new AudioTranscriber({ env: { VOICE_PYTHON_BIN: voicePython, WHISPER_BACKEND: 'python-faster-whisper', WHISPER_PY_MODEL_PATH: whisperModel }, execFileImpl: async (binary, args) => args[1] === 'status' ? { stdout: JSON.stringify({ ok: true, fasterWhisperAvailable: true, avCompatible: false, avVersion: '19.0.0' }) } : sttExec(binary, args), tempDir: temp });
    assert.equal((await incompatiblePyAv.status()).ready, false, 'PyAV 19 must not be reported ready even if the module files exist');
    await assert.rejects(() => missingModel.transcribeBuffer(Buffer.from('audio'), { extension: '.ogg' }), /نموذج Faster-Whisper غير موجود/);
    console.log('python-voice-adapters: ok (local Faster-Whisper status/transcription/temp cleanup, four-language automatic voice routing, Edge TTS prosody mapping, OGG/Opus conversion, fail-closed model/PyAV readiness and per-transcript metadata sufficiency)');
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
