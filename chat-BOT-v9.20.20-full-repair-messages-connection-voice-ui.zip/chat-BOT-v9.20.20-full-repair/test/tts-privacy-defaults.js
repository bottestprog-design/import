'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { TextToSpeech, defaultVoiceForText } = require('../src/text-to-speech');
const { DEFAULT_SETTINGS } = require('../src/store');

(async () => {
  const projectRoot = path.resolve(__dirname, '..');
  const serverSource = fs.readFileSync(path.join(projectRoot, 'server.js'), 'utf8');
  assert.match(serverSource, /if \(b\.ttsCloudConsent !== undefined\) s\.settings\.ttsCloudConsent = boolValue\(b\.ttsCloudConsent, false\)/, 'per-session cloud consent must be persisted through the settings API');
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-tts-privacy-'));
  try {
    const piper = path.join(root, 'piper.exe');
    const model = path.join(root, 'arabic.onnx');
    const ffmpeg = path.join(root, 'ffmpeg.exe');
    const python = path.join(root, 'python.exe');
    fs.writeFileSync(piper, 'piper'); fs.writeFileSync(ffmpeg, 'ffmpeg'); fs.writeFileSync(python, 'python');
    fs.mkdirSync(path.join(root, 'scripts'), { recursive: true });
    fs.writeFileSync(path.join(root, 'scripts', 'voice_worker.py'), '# worker fixture');
    const fd = fs.openSync(model, 'w'); fs.ftruncateSync(fd, 10 * 1024 * 1024 + 1); fs.closeSync(fd);

    let pythonStatusChecks = 0; let remoteSpawns = 0; let cloudFetches = 0; let localSpawns = 0;
    const tts = new TextToSpeech({
      root, tempRoot: root,
      env: { PIPER_BIN: piper, PIPER_MODEL_PATH: model, FFMPEG_BIN: ffmpeg, VOICE_PYTHON_BIN: python, TTS_BACKEND: 'auto', TTS_REQUIRE_PROOFREAD: 'false' },
      execFileImpl: async (binary, args) => {
        if (binary === 'where.exe' || binary === 'which') return { stdout: args[0] || ffmpeg };
        if (binary === python && args.includes('status')) { pythonStatusChecks++; return { stdout: JSON.stringify({ ok: true, edgeTtsAvailable: true }) }; }
        return { stdout: '' };
      },
      spawnImpl: (binary, args) => {
        if (binary === piper) localSpawns++;
        if (binary === python) remoteSpawns++;
        const { EventEmitter } = require('node:events'); const child = new EventEmitter();
        child.stderr = new EventEmitter(); child.stdin = new EventEmitter(); child.kill = () => {};
        child.stdin.end = value => {
          if (binary === piper) {
            assert.match(String(value), /مرحبا/u);
            const out = args[args.indexOf('--output_file') + 1]; fs.writeFileSync(out, Buffer.alloc(256, 1));
          } else remoteSpawns++;
          setImmediate(() => child.emit('close', 0));
        };
        return child;
      },
      fetchImpl: async () => { cloudFetches++; throw new Error('cloud fetch must be blocked'); },
    });

    assert.equal(DEFAULT_SETTINGS.ttsBackend, 'local');
    assert.equal(DEFAULT_SETTINGS.ttsCloudConsent, false);
    assert.equal(tts.config().backend, 'auto');
    assert.equal(defaultVoiceForText('Hello there', 'ar-OM-AyshaNeural'), 'en-US-JennyNeural', 'an explicitly selected Arabic voice must not be used for English text');
    assert.equal(defaultVoiceForText('مرحبًا بك', 'en-US-JennyNeural'), 'ar-EG-ShakirNeural', 'an English voice must not be used for Arabic text');

    // Arabic auto mode: local Piper is ready and cloud consent is off; it must not probe Edge.
    const arabicStatus = await tts.status({ backend: 'auto', voice: 'ar-OM-AyshaNeural', allowCloud: false });
    assert.equal(arabicStatus.ready, true);
    assert.equal(arabicStatus.activeBackend, 'local');
    assert.equal(arabicStatus.cloudAllowed, false);
    assert.equal(pythonStatusChecks, 1, 'local Piper diagnostics may inspect the project-owned Python worker without contacting a remote TTS provider');
    const local = await tts.generate('مرحبا هذا اختبار', { backend: 'auto', voice: 'ar-OM-AyshaNeural', allowCloud: false, proofread: false });
    assert.equal(local.backend, 'local');
    assert.equal(localSpawns, 1);
    assert.equal(remoteSpawns, 0);
    assert.equal(cloudFetches, 0);
    tts.cleanup(local);

    // A local Arabic model must not make English status appear ready.
    const forcedLocalEnglish = await tts.status({ backend: 'local', voice: 'en-US-JennyNeural', allowCloud: false });
    assert.equal(forcedLocalEnglish.ready, false, 'Arabic-only Piper must not be reported ready for English');
    await assert.rejects(() => tts.generate('Hello there', { backend: 'local', voice: 'en-US-JennyNeural', allowCloud: false, proofread: false }), /Piper المحلي المرفق عربي فقط/);
    await assert.rejects(() => tts.generate('Hello there', { backend: 'local', voice: 'ar-OM-AyshaNeural', allowCloud: false, proofread: false }), /Piper المحلي المرفق عربي فقط/, 'Arabic voice selection must not bypass the text-language guard');
    await assert.rejects(() => tts.generate('Hello there', { backend: 'auto', voice: 'ar-OM-AyshaNeural', allowCloud: false, proofread: false }), /فعّل موافقة السحابة/, 'auto must route English text away from Arabic Piper even when an Arabic voice is selected');
    const englishStatus = await tts.status({ backend: 'auto', voice: 'en-US-JennyNeural', allowCloud: false });
    assert.equal(englishStatus.ready, false);
    assert.equal(englishStatus.cloudConsentRequired, true);
    assert.equal(pythonStatusChecks, 1, 'remote TTS readiness must remain unqueried without consent; only the cached local worker status runs');
    await assert.rejects(() => tts.generate('Hello there', { backend: 'auto', voice: 'en-US-JennyNeural', allowCloud: false, proofread: false }), /فعّل موافقة السحابة/);
    await assert.rejects(() => tts.generate('مرحبا', { backend: 'edge-tts', voice: 'ar-OM-AyshaNeural', allowCloud: false, proofread: false }), /موافقة السحابة/);
    await assert.rejects(() => tts.generate('مرحبا', { backend: 'openai-compatible', allowCloud: false, proofread: false }), /موافقة السحابة/);
    assert.equal(pythonStatusChecks, 1, 'remote TTS readiness must remain unqueried without consent; only the cached local worker status runs');
    assert.equal(remoteSpawns, 0);
    assert.equal(cloudFetches, 0);

    // Once explicitly consented, the remote backend may be probed for non-Arabic.
    const consented = await tts.status({ backend: 'auto', voice: 'en-US-JennyNeural', allowCloud: true });
    assert.equal(consented.ready, true);
    assert.equal(consented.activeBackend, 'edge-tts');
    assert.ok(pythonStatusChecks > 1, 'explicit cloud consent allows a separate Edge TTS readiness check');
    console.log('tts-privacy-defaults: ok (local default, local-first Arabic, non-Arabic readiness gated, local diagnostics remain available while remote status/generate stay blocked without consent)');
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
})().catch(error => { console.error(error); process.exitCode = 1; });
