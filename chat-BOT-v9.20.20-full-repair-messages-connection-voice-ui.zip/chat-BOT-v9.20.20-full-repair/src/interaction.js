"use strict";

const triggerEngine = require('./trigger-engine');
const replyEngine = require('./reply-engine');
const { lintRuleReply } = require('./reply-quality');
const commandPriority = require('./command-priority');
const antiConflict = require('./anti-conflict');
const recipientReplies = require('./recipient-replies');
const conversationTargets = require('./conversation-targets');
const { isStaleMessage, messageEventKey, pruneEventLedger } = require('./message-lifecycle');
const { isQuietHours: quiet, quietAction } = require('./time-policy');
const { templateReply, conversationSystemPrompt } = require('./smart-reply');
const { sendSpeechInSegments } = require('./tts-delivery');

function norm(v) { return triggerEngine.normalizeArabic(v); }
function minutes(v) {
  const m = String(v ?? '').match(/^(\d{2}):(\d{2})$/); if (!m) return null;
  const h = Number(m[1]), n = Number(m[2]); return h > 23 || n > 59 ? null : h * 60 + n;
}
function validTimeZone(value, fallback = 'Asia/Muscat') {
  const requested = String(value || '').trim() || fallback;
  try { new Intl.DateTimeFormat('en-US', { timeZone: requested }).format(new Date(0)); return requested; }
  catch {
    try { new Intl.DateTimeFormat('en-US', { timeZone: fallback }).format(new Date(0)); return fallback; }
    catch { return 'UTC'; }
  }
}
function localClock(now, timezone = 'Asia/Muscat') {
  const parts = new Intl.DateTimeFormat('en-US', { timeZone: validTimeZone(timezone), weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(now);
  const get = type => parts.find(x => x.type === type)?.value || '';
  const weekdays = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  return { minutes: Number(get('hour')) * 60 + Number(get('minute')), day: weekdays[get('weekday')] };
}
function activeWindow(start, end, days, now = new Date(), timezone = 'Asia/Muscat') {
  const a = minutes(start), b = minutes(end); if (a == null || b == null || a === b) return false;
  let local; try { local = localClock(now, timezone); } catch { return false; }
  const isInTime = a < b ? local.minutes >= a && local.minutes < b : local.minutes >= a || local.minutes < b;
  if (!isInTime) return false;
  const allowed = Array.isArray(days) ? days.map(Number).filter(x => Number.isInteger(x) && x >= 0 && x <= 6) : [];
  if (!allowed.length) return true;
  const startDay = a > b && local.minutes < b ? (local.day + 6) % 7 : local.day;
  return allowed.includes(startDay);
}
function ruleActiveNow(rule, settings = {}, now = new Date()) {
  const schedule = rule?.schedule; if (!schedule?.enabled) return true;
  return activeWindow(schedule.start, schedule.end, schedule.days, now, schedule.timezone || settings.timezone || 'Asia/Muscat');
}
function scopeOk(scope, chatId, selected = []) {
  const id = String(chatId || '').toLowerCase(), isGroup = id.endsWith('@g.us');
  if (scope === 'groups') return isGroup;
  if (scope === 'private') return !isGroup;
  if (scope === 'selected') return selected.map(norm).includes(norm(chatId));
  return true;
}
function match(rule, event, text, emoji, options = {}) { return triggerEngine.matchTrigger(rule, event, text, emoji, options).matched; }
function render(text, ctx, tz = 'Asia/Muscat') { return replyEngine.renderTemplate(text, ctx, tz); }
function valid(rule) {
  triggerEngine.validateTrigger(rule);
  if (!['all', 'groups', 'private', 'selected'].includes(rule.scope || 'all')) throw new Error('نطاق غير مدعوم.');
  const then = rule.then || {};
  if (!replyEngine.replyVariants(rule).length && !then.reaction) throw new Error('أضف ردًا واحدًا على الأقل أو اختر Reaction.');
  if (rule.schedule?.enabled) {
    if (minutes(rule.schedule.start) == null || minutes(rule.schedule.end) == null || rule.schedule.start === rule.schedule.end) throw new Error('وقت القاعدة غير صالح؛ حدّد بداية ونهاية مختلفتين.');
    if (rule.schedule.days !== undefined && (!Array.isArray(rule.schedule.days) || rule.schedule.days.some(day => !Number.isInteger(Number(day)) || Number(day) < 0 || Number(day) > 6))) throw new Error('أيام تشغيل القاعدة غير صالحة.');
    try { new Intl.DateTimeFormat('en-US', { timeZone: rule.schedule.timezone || 'Asia/Muscat' }).format(new Date()); } catch { throw new Error('المنطقة الزمنية للقاعدة غير صالحة.'); }
  }
}
function ensureState(s) {
  s.interaction ||= {};
  s.interaction.rules = Array.isArray(s.interaction.rules) ? s.interaction.rules : [];
  s.interaction.counterTriggers = Array.isArray(s.interaction.counterTriggers) ? s.interaction.counterTriggers : [];
  s.interaction.variantState = s.interaction.variantState && typeof s.interaction.variantState === 'object' ? s.interaction.variantState : {};
  s.interaction.contextByChat = s.interaction.contextByChat && typeof s.interaction.contextByChat === 'object' ? s.interaction.contextByChat : {};
  s.interaction.eventState = s.interaction.eventState && typeof s.interaction.eventState === 'object' ? s.interaction.eventState : { seenMessages: {} };
  s.interaction.eventState.seenMessages = s.interaction.eventState.seenMessages && typeof s.interaction.eventState.seenMessages === 'object' ? s.interaction.eventState.seenMessages : {};
  s.interaction.counterState = s.interaction.counterState && typeof s.interaction.counterState === 'object' ? s.interaction.counterState : {};
  const cs = s.interaction.counterState;
  cs.totalCount = Math.max(0, Number(cs.totalCount) || 0);
  cs.byChat = cs.byChat && typeof cs.byChat === 'object' ? cs.byChat : {};
  cs.fired = cs.fired && typeof cs.fired === 'object' ? cs.fired : {};
  cs.pending = cs.pending && typeof cs.pending === 'object' ? cs.pending : {};
  return s.interaction;
}
function senderFor(raw, chat) {
  return String(raw?.notifyName || raw?._data?.notifyName || raw?.author || raw?._data?.author || chat?.name || 'صديق').slice(0, 120);
}
function counterKey(trigger) { return `${String(trigger.id)}:${Math.max(1, Number(trigger.threshold) || 1)}`; }
function safeCounterScope(trigger, chatId) { return trigger.scope === 'chat' ? chatId : 'session'; }

class InteractionEngine {
  constructor({ store, whatsapp, log, localLlm = null, speechSynthesizer = null }) {
    this.store = store; this.whatsapp = whatsapp; this.log = log; this.localLlm = localLlm; this.speechSynthesizer = speechSynthesizer; this.seen = new Map(); this.cool = new Map(); this.rate = new Map(); this.inFlight = new Set(); this.quietCool = new Map(); this.recipientCool = new Map(); this.fallbackCool = new Map(); this.conversationHistory = new Map();
  }
  clearChatState(id, chatIds) {
    const sid = this.store.safeSessionId(id), chats = new Set((Array.isArray(chatIds) ? chatIds : [chatIds])
      .map(value => String(value || '').trim().toLowerCase()).filter(Boolean));
    if (!chats.size) return 0;
    const removeMatching = (collection, matches) => {
      if (!collection || typeof collection.delete !== 'function') return 0;
      let removed = 0;
      for (const key of collection.keys()) if (matches(String(key))) { collection.delete(key); removed++; }
      return removed;
    };
    const sessionPrefix = `${sid}|`, quietPrefix = `quiet|${sid}|`;
    let removed = 0;
    for (const map of [this.rate, this.quietCool, this.fallbackCool]) {
      removed += removeMatching(map, key => key.startsWith(sessionPrefix) && chats.has(key.slice(sessionPrefix.length).split('|')[0]));
    }
    for (const map of [this.cool, this.recipientCool]) {
      removed += removeMatching(map, key => {
        if (!key.startsWith(sessionPrefix)) return false;
        const parts = key.slice(sessionPrefix.length).split('|');
        return chats.has(parts.at(-1) || '');
      });
    }
    removed += removeMatching(this.conversationHistory, key => key.startsWith(sessionPrefix) && chats.has(key.slice(sessionPrefix.length)));
    removed += removeMatching(this.seen, key => {
      if (key.startsWith(sessionPrefix)) return chats.has(key.slice(sessionPrefix.length).split('|')[1] || '');
      if (key.startsWith(quietPrefix)) return chats.has(key.slice(quietPrefix.length).split('|')[0] || '');
      return false;
    });
    return removed;
  }
  saveSessionPreservingRecipientState(source) {
    // Interaction state is owned by this engine; recipient/group enable flags are not.
    // Merge the freshest recipient/group lists before persisting any in-flight snapshot,
    // so a concurrent stop/delete action is never undone by a reply finishing later.
    try {
      const id = String(source?.id || '');
      if (id) {
        const latest = this.store.loadSession(id);
        if (Array.isArray(latest?.recipients)) source.recipients = latest.recipients;
        if (Array.isArray(latest?.groups)) source.groups = latest.groups;
      }
    } catch {}
    return this.store.saveSession(source);
  }
  assertChatEnabled(id, chatId) {
    const current = this.store.loadSession(id);
    if (recipientReplies.recipientIsPaused(current, chatId)) {
      throw Object.assign(new Error('المستلم موقوف؛ لم يُرسل أي رد تلقائي.'), { code: 'RECIPIENT_DISABLED', retryable: false });
    }
  }
  async replyToActiveChat(id, raw, chatId, text) {
    this.assertChatEnabled(id, chatId);
    const result = await this.whatsapp.replyToMessage(id, raw, text);
    // Voice replies are additive: text remains the source of truth and is never lost if TTS is unavailable.
    const latest = this.store.loadSession(id);
    if (latest.settings?.interactionVoiceRepliesEnabled === true) {
      await this.maybeSendVoiceReply(id, chatId, text).catch(error => {
        this.log(id, 'WARN', `تعذر إرسال النسخة الصوتية للرد النصي؛ تم الاحتفاظ بالرد النصي: ${String(error?.message || error).slice(0, 220)}`);
      });
    }
    return result;
  }
  async maybeSendVoiceReply(id, chatId, text) {
    if (String(chatId || '').toLowerCase().endsWith('@g.us')) return { sent: false, reason: 'group-voice-replies-disabled' };
    if (!this.speechSynthesizer || typeof this.speechSynthesizer.generate !== 'function' || typeof this.speechSynthesizer.toWhatsAppVoice !== 'function' || typeof this.whatsapp.sendVoice !== 'function') {
      throw new Error('محرك النطق المحلي غير مربوط أو غير مكتمل.');
    }
    const assertAllowed = () => this.assertChatEnabled(id, chatId);
    assertAllowed();
    const getLatestSettings = () => this.store.loadSession(id).settings || {};
    const settings = getLatestSettings();
    const status = await this.speechSynthesizer.status({ backend: settings.ttsBackend || 'local', allowCloud: settings.ttsCloudConsent === true, voice: settings.ttsVoice || 'ar-EG-ShakirNeural' });
    if (!status?.ready || !status?.ffmpegReady) throw new Error(status?.message || 'محرك النطق أو FFmpeg غير جاهز.');
    return sendSpeechInSegments({
      synthesizer: this.speechSynthesizer,
      text: String(text || ''),
      settings,
      getLatestSettings,
      assertAllowed,
      sendVoice: async voiceFile => this.whatsapp.sendVoice(id, chatId, voiceFile),
    });
  }

  async reactToActiveChat(id, messageId, chatId, emoji) {
    this.assertChatEnabled(id, chatId);
    return this.whatsapp.reactToMessage(id, messageId, emoji);
  }
  rateOk(key, limit) {
    const now = Date.now(); let bucket = this.rate.get(key);
    if (!bucket || now - bucket.start >= 60000) { bucket = { start: now, count: 0 }; this.rate.set(key, bucket); }
    if (bucket.count >= limit) return false; bucket.count++; return true;
  }
  async onMessage(id, msg) { return this.handle(id, 'message', msg); }
  async onReaction(id, reaction) { if (reaction?.fromMe) return; return this.handle(id, 'reaction', reaction); }

  async handleRecipientReply(id, session, recipient, raw, chatId, text, ctx, intent, messageCount, previousContext) {
    if (!recipient || !recipient.replyProfile) return null;
    const profile = recipientReplies.normalizeReplyProfile(recipient.replyProfile);
    if (profile.mode === 'inherit') return null;
    const finish = (result) => {
      this.updateContext(session, chatId, text, intent, messageCount, previousContext);
      this.saveSessionPreservingRecipientState(session);
      return result;
    };
    if (profile.mode === 'disabled' || profile.enabled === false) {
      return finish({ handled: false, personalReply: true, action: 'disabled', reason: 'recipient-reply-disabled' });
    }

    const matchedRule = profile.rules.find(rule => recipientReplies.matchPersonalRule(rule, text));
    let response = '', ruleName = '', ruleId = '';
    if (matchedRule) {
      response = matchedRule.reply;
      ruleName = matchedRule.name || 'قاعدة شخصية';
      ruleId = matchedRule.id || 'personal-rule';
    } else if (profile.defaultReply.trim()) {
      response = profile.defaultReply;
      ruleName = 'الرد الافتراضي الشخصي';
      ruleId = 'personal-default';
    } else if (profile.fallbackToGlobal) {
      return null;
    } else {
      return finish({ handled: false, personalReply: true, action: 'no-match', reason: 'personal-no-match' });
    }

    const cooldownKey = `${id}|${recipient.id}|${chatId}`;
    const cooldownMs = Math.max(0, Number(profile.cooldownSec) || 0) * 1000;
    if (Date.now() - (this.recipientCool.get(cooldownKey) || 0) < cooldownMs) {
      return finish({ handled: false, personalReply: true, action: 'cooldown', reason: 'recipient-cooldown' });
    }
    if (!this.rateOk(`${id}|${chatId}`, Number(session.settings.maxActionsPerMinute) || 20)) {
      return finish({ handled: false, personalReply: true, action: 'rate-limited', reason: 'rate-limited' });
    }
    const rendered = replyEngine.renderTemplate(response, ctx, session.settings.timezone);
    if (!rendered.trim()) return finish({ handled: false, personalReply: true, action: 'empty-reply', reason: 'empty-reply' });
    const quality = lintRuleReply(rendered);
    if (!quality.ok) {
      const detail = quality.issues.map(item => item.message).join('؛ ');
      this.record(id, 'message', { id: ruleId, name: `رد شخصي: ${ruleName}` }, 'blocked', chatId, text, '', new Error(detail), session);
      this.log(id, 'WARN', `حُجب رد شخصي غير صالح قبل الإرسال: ${detail}`); this.syncLogs(session);
      return finish({ handled: false, personalReply: true, action: 'quality-blocked', reason: 'reply-quality-check-failed', issues: quality.issues.map(item => item.code) });
    }
    const record = { id: ruleId, name: `رد شخصي: ${ruleName}` };
    try {
      await this.replyToActiveChat(id, raw, chatId, rendered);
      this.recipientCool.set(cooldownKey, Date.now());
      if (this.recipientCool.size > 5000) {
        const cutoff = Date.now() - 86400000;
        for (const [key, at] of this.recipientCool) if (at < cutoff) this.recipientCool.delete(key);
      }
      this.record(id, 'message', record, 'success', chatId, text, '', null, session);
      return finish({ handled: true, personalReply: true, action: 'reply', ruleId, ruleName, response: rendered });
    } catch (error) {
      this.record(id, 'message', record, error.code === 'SEND_UNCERTAIN' ? 'uncertain' : 'error', chatId, text, '', error, session);
      this.log(id, 'ERROR', `تعذر إرسال الرد الشخصي إلى ${recipient.name || recipient.id}: ${error.message || error}`);
      this.syncLogs(session);
      return finish({ handled: true, personalReply: true, action: 'error', error: error.message || String(error) });
    }
  }

  async chatContext(raw, event) {
    let chat = null; try { if (typeof raw?.getChat === 'function') chat = await raw.getChat(); } catch {}
    const serialized = value => {
      if (!value) return '';
      if (typeof value === 'string') return value;
      return String(value._serialized || value.$1 || value.remote?._serialized || value.remote?.$1 || '');
    };
    const candidates = event === 'message'
      ? [chat?.id, raw?.from, raw?.chatId, raw?.to, raw?.id?.remote, raw?._data?.id?.remote]
      : [chat?.id, raw?.chatId, raw?.msgId?.remote, raw?.messageId?.remote, raw?.id?.remote];
    const chatId = candidates.map(serialized).find(x => x) || '';
    return { chat, chatId: chatId.toLowerCase() };
  }

  incrementCounters(s, chatId, event) {
    const cs = ensureState(s).counterState;
    if (event !== 'message') return { total: cs.totalCount, chat: Number(cs.byChat[chatId]?.count || 0), previousTotal: cs.totalCount, previousChat: Number(cs.byChat[chatId]?.count || 0) };
    const previousTotal = cs.totalCount, previousChat = Number(cs.byChat[chatId]?.count || 0);
    cs.totalCount = previousTotal + 1;
    cs.byChat[chatId] = { count: previousChat + 1, lastAt: new Date().toISOString() };
    const chatKeys = Object.keys(cs.byChat); if (chatKeys.length > 2500) for (const key of chatKeys.slice(0, chatKeys.length - 2500)) delete cs.byChat[key];
    return { total: cs.totalCount, chat: previousChat + 1, previousTotal, previousChat };
  }

  updateContext(s, chatId, text, intent, count, previous) {
    const contexts = ensureState(s).contextByChat;
    contexts[chatId] = { lastMessage: String(text || '').slice(0, 300), lastIntent: String(intent || 'unknown'), count: Number(count || 0), updatedAt: new Date().toISOString() };
    const keys = Object.keys(contexts); if (keys.length > 2500) for (const key of keys.slice(0, keys.length - 2500)) delete contexts[key];
  }

  buildCounterCandidates(s, chatId, counts) {
    const state = ensureState(s), cs = state.counterState, out = [];
    for (let index = 0; index < state.counterTriggers.length; index++) {
      const trigger = state.counterTriggers[index];
      if (trigger.enabled === false) continue;
      const scopeKey = safeCounterScope(trigger, chatId), key = counterKey(trigger), current = scopeKey === 'session' ? counts.total : counts.chat, previous = scopeKey === 'session' ? counts.previousTotal : counts.previousChat;
      const firedMap = cs.fired[scopeKey] ||= {};
      const pendingMap = cs.pending[scopeKey] ||= {};
      const armedAt = Math.max(0, Number(trigger.armedAtCount) || 0);
      if (!firedMap[key] && !pendingMap[key] && previous < Number(trigger.threshold) && current >= Number(trigger.threshold) && current > armedAt) pendingMap[key] = { crossedAt: current, at: new Date().toISOString() };
      if (firedMap[key] || !pendingMap[key]) continue;
      out.push({ kind: 'counter', trigger, item: trigger, id: trigger.id, name: trigger.name, priority: Number(trigger.priority) || 0, matchScore: 1, order: 10000 + index, counterScopeKey: scopeKey, counterStateKey: key });
    }
    return out;
  }

  async handle(id, event, raw) {
    const s = this.store.loadSession(id); ensureState(s);
    if (!s.settings.interactionEnabled || !s.interaction.enabled) return { handled: false, reason: 'disabled' };
    if (event === 'message' && raw?.fromMe && s.settings.interactionIgnoreOwn !== false && !raw?.__chatBotSelfInput) return { handled: false, reason: 'own-message' };
    const { chat, chatId } = await this.chatContext(raw, event);
    if (!chatId) return { handled: false, reason: 'scope' };
    const access = conversationTargets.resolveChatAccess(s, chatId, this.whatsapp.selfChatId?.(id) || '');
    if (!access.allowed) return { handled: true, reason: access.reason === 'disabled' ? 'recipient-disabled' : 'unregistered-chat', action: 'blocked' };
    if (!scopeOk(s.settings.interactionScope || 'all', chatId, s.settings.interactionChatIds || [])) return { handled: false, reason: 'scope' };

    if (event === 'message' && isStaleMessage(raw, s.settings.maxInboundMessageAgeSec || 300)) return { handled: false, reason: 'stale-message' };
    const text = event === 'message' ? String(raw?.body || '') : '';
    const emoji = event === 'reaction' ? String(raw?.reaction || raw?.emoji || raw?.value || '') : '';
    const stable = String(raw?.id?._serialized || raw?.id?.$1 || raw?.msgId?._serialized || raw?.msgId?.$1 || raw?.messageId?._serialized || raw?.messageId?.$1 || raw?.id || raw?.timestamp || `${chatId}|${text}|${emoji}`);
    const seenKey = `${id}|${event}|${chatId}|${stable}|${text}|${emoji}`;
    const persistentKey = messageEventKey(id, chatId, raw, event);
    const persistentSeen = s.interaction.eventState.seenMessages;
    pruneEventLedger(persistentSeen, { now: Date.now(), maxEntries: 3000, maxAgeMs: 86400000 });
    if (this.seen.has(seenKey) || persistentSeen[persistentKey]) return { handled: false, reason: 'duplicate' };
    const seenAt = Date.now();
    this.seen.set(seenKey, seenAt);
    persistentSeen[persistentKey] = { at: seenAt, status: 'claimed' };
    this.saveSessionPreservingRecipientState(s);
    if (this.seen.size > 5000) for (const [k, t] of this.seen) if (Date.now() - t > 600000) this.seen.delete(k);

    const prevCtx = s.interaction.contextByChat[chatId] || {};
    const counts = this.incrementCounters(s, chatId, event);
    const messageCount = event === 'message' ? counts.total : counts.total;
    const intent = event === 'message' ? triggerEngine.inferIntent(text) : 'unknown';
    const ctx = { message: text, sender: senderFor(raw, chat), chat: chatId, type: event, emoji, intent, count: messageCount, messageCount, lastMessage: prevCtx.lastMessage || '', lastIntent: prevCtx.lastIntent || '' };

    const isQuiet = event === 'message' && quiet(s.settings), quietMode = quietAction(s.settings);
    if (isQuiet && quietMode === 'silence') {
      this.updateContext(s, chatId, text, intent, messageCount, prevCtx); this.saveSessionPreservingRecipientState(s);
      return { handled: true, quiet: true, action: 'silence' };
    }
    const quietStable = `${id}|${chatId}|${stable}`;
    if (isQuiet && quietMode === 'reply') {
      const content = replyEngine.renderTemplate(s.settings.interactionQuietReply || '', ctx, s.settings.timezone);
      if (!content) return { handled: true, quiet: true, action: 'silence-empty' };
      const quietQuality = lintRuleReply(content);
      if (!quietQuality.ok) {
        const detail = quietQuality.issues.map(item => item.message).join('؛ ');
        this.recordQuiet(id, chatId, text, 'blocked', '', new Error(detail), s);
        this.log(id, 'WARN', `حُجب رد فترة الهدوء قبل الإرسال: ${detail}`); this.syncLogs(s);
        return { handled: true, quiet: true, action: 'quality-blocked', reason: 'reply-quality-check-failed' };
      }
      const key = `${id}|${chatId}`, cooldownMs = Math.max(0, Number(s.settings.interactionQuietCooldownSec ?? 300)) * 1000;
      if (Date.now() - (this.quietCool.get(key) || 0) < cooldownMs) { this.updateContext(s, chatId, text, intent, messageCount, prevCtx); this.saveSessionPreservingRecipientState(s); return { handled: true, quiet: true, action: 'cooldown' }; }
      if (!this.rateOk(`${id}|${chatId}`, Number(s.settings.maxActionsPerMinute) || 20)) return { handled: true, quiet: true, action: 'rate-limited' };
      try {
        await this.replyToActiveChat(id, raw, chatId, content); this.seen.set(`quiet|${quietStable}`, Date.now()); this.quietCool.set(key, Date.now());
        this.recordQuiet(id, chatId, text, 'success', content, null, s); this.updateContext(s, chatId, text, intent, messageCount, prevCtx); this.saveSessionPreservingRecipientState(s);
        return { handled: true, quiet: true, action: 'reply', response: content };
      } catch (error) {
        this.recordQuiet(id, chatId, text, 'error', content, error, s); this.updateContext(s, chatId, text, intent, messageCount, prevCtx); this.saveSessionPreservingRecipientState(s);
        this.log(id, 'ERROR', `تعذر إرسال رد فترة الهدوء: ${error.message || error}`); this.syncLogs(s); return { handled: true, quiet: true, action: 'error', error: error.message || String(error) };
      }
    }

    if (event === 'message' && !(isQuiet && quietMode === 'rules')) {
      const recipient = recipientReplies.recipientForChat(s, chatId);
      const personalResult = await this.handleRecipientReply(id, s, recipient, raw, chatId, text, ctx, intent, messageCount, prevCtx);
      if (personalResult) return personalResult;
    }

    const candidates = [], rules = s.interaction.rules || [];
    for (let index = 0; index < rules.length; index++) {
      const rule = rules[index]; if (rule.enabled === false) continue;
      if (!scopeOk(rule.scope || 'all', chatId, rule.chatIds || [])) continue;
      if (isQuiet && quietMode !== 'rules') continue;
      if (!ruleActiveNow(rule, s.settings, new Date())) continue;
      let result;
      try { valid(rule); result = triggerEngine.matchTrigger(rule, event, text, emoji, { threshold: s.settings.interactionSimilarityThreshold, smartContains: s.settings.interactionSmartMatching !== false, smartThreshold: s.settings.interactionSmartThreshold ?? .82 }); }
      catch (error) { this.record(id, event, rule, 'error', chatId, text, emoji, error, s); continue; }
      if (!result.matched) continue;
      const actionKey = `${id}|${rule.id}|${chatId}`;
      if (this.inFlight.has(actionKey)) continue;
      const cooldown = Math.min(Math.max(0, Number(rule.cooldownSec) || 0), Number(s.settings.interactionCooldownCapSec) || 86400);
      if (Date.now() - (this.cool.get(actionKey) || 0) < cooldown * 1000) continue;
      candidates.push({ kind: 'rule', rule, item: rule, id: rule.id, priority: Number(rule.priority) || 0, matchScore: result.score, order: index, actionKey, intent: result.intent });
    }
    const counterCandidates = event === 'message' && !(isQuiet && quietMode !== 'rules') ? this.buildCounterCandidates(s, chatId, counts) : [];
    candidates.push(...counterCandidates);
    if (!candidates.length) {
      if (event === 'message') {
        const fallback = await this.handleSmartFallback({ id, session: s, raw, chatId, text, intent, messageCount, prevCtx, ctx });
        if (fallback) return fallback;
      }
      this.updateContext(s, chatId, text, intent, messageCount, prevCtx); this.saveSessionPreservingRecipientState(s);
      return { handled: false, reason: 'no-rule-matched', messageCount };
    }

    const conflictMode = ['first-match','highest-score','allow-multiple'].includes(s.settings.interactionConflictMode) ? s.settings.interactionConflictMode : 'first-match';
    const ordered = antiConflict.resolveCandidates(candidates, conflictMode);
    let handled = false, sentCount = 0, matched = null;
    for (const candidate of ordered.slice(0, conflictMode === 'allow-multiple' ? 5 : ordered.length)) {
      const isCounter = candidate.kind === 'counter', item = candidate.item;
      const actionKey = isCounter ? `${id}|counter:${item.id}|${candidate.counterScopeKey}` : candidate.actionKey;
      if (this.inFlight.has(actionKey)) continue;
      if (!this.rateOk(`${id}|${chatId}`, Number(s.settings.maxActionsPerMinute) || 20)) {
        if (isCounter) break;
        continue;
      }
      this.inFlight.add(actionKey);
      let actionSucceeded = false, attempted = false;
      try {
        let content = '', actionType = isCounter ? (item.actionType || 'reply') : 'rule';
        if (actionType === 'reply' || !isCounter) {
          const picked = replyEngine.pickReply(item, s.interaction.variantState, `${item.id}|${chatId}`);
          content = replyEngine.renderTemplate(picked || item.then?.reply || '', { ...ctx, count: isCounter ? (candidate.counterScopeKey === 'session' ? counts.total : counts.chat) : messageCount, messageCount: isCounter ? (candidate.counterScopeKey === 'session' ? counts.total : counts.chat) : messageCount }, s.settings.timezone);
          const quality = lintRuleReply(content);
          if ((actionType === 'reply' || !isCounter) && !quality.ok) {
            const qualityError = new Error(quality.issues.map(issue => issue.message).join('؛ ')); qualityError.code = 'REPLY_QUALITY_BLOCKED'; throw qualityError;
          }
          this.saveSessionPreservingRecipientState(s); // Persist variation state before external send to avoid reusing a picked response after a restart.
        }
        if (isCounter && actionType === 'log') {
          this.record(id, event, item, 'success', chatId, text, emoji, null, s); actionSucceeded = true; attempted = true;
        } else {
          if (content) { await this.replyToActiveChat(id, raw, chatId, content); attempted = true; }
          const reaction = isCounter ? (actionType === 'reaction' ? (item.then?.reaction || item.reaction || '') : '') : (item.then?.reaction || '');
          if (reaction) { const messageId = raw?.id || raw?.msgId || raw?.messageId; if (messageId) await this.reactToActiveChat(id, messageId, chatId, reaction); attempted = true; }
          if (!content && !reaction && !isCounter) throw new Error('لا يوجد نص رد أو Reaction بعد معالجة المتغيرات.');
          this.cool.set(actionKey, Date.now());
          this.record(id, event, item, 'success', chatId, text, emoji, null, s); actionSucceeded = true;
        }
      } catch (error) {
        attempted = true;
        const failureStatus = error.code === 'SEND_UNCERTAIN' ? 'uncertain' : error.code === 'REPLY_QUALITY_BLOCKED' ? 'blocked' : 'error';
        this.record(id, event, item, failureStatus, chatId, text, emoji, error, s);
        this.log(id, error.code === 'REPLY_QUALITY_BLOCKED' ? 'WARN' : 'ERROR', `${error.code === 'REPLY_QUALITY_BLOCKED' ? 'حُجب رد غير صالح' : 'فشل التفاعل'} ${item.name || item.id}: ${error.message || error}`); this.syncLogs(s);
      } finally { this.inFlight.delete(actionKey); }

      if (isCounter && attempted) {
        const cs = ensureState(s).counterState, firedMap = cs.fired[candidate.counterScopeKey] ||= {}, pendingMap = cs.pending[candidate.counterScopeKey] ||= {};
        firedMap[candidate.counterStateKey] = { at: new Date().toISOString(), status: actionSucceeded ? 'success' : 'error', count: candidate.counterScopeKey === 'session' ? counts.total : counts.chat };
        delete pendingMap[candidate.counterStateKey];
        this.saveSessionPreservingRecipientState(s);
      }
      if (actionSucceeded) {
        handled = true; sentCount++; matched = { handled: true, action: isCounter ? 'counter' : 'rule', ruleId: item.id, ruleName: item.name, responseCount: sentCount };
        if (conflictMode !== 'allow-multiple' || (!isCounter && item.then?.stopAfter !== false)) break;
      } else if (conflictMode !== 'allow-multiple' && !isCounter) {
        // If a higher-priority action failed, allow the next matching rule to serve as a fallback.
        continue;
      }
    }

    // Consume same-message counter collisions after another action succeeds, rather than unexpectedly firing later.
    if (handled && conflictMode !== 'allow-multiple') {
      for (const candidate of counterCandidates) {
        if (matched?.action === 'counter' && candidate.id === matched.ruleId) continue;
        const cs = ensureState(s).counterState, firedMap = cs.fired[candidate.counterScopeKey] ||= {}, pendingMap = cs.pending[candidate.counterScopeKey] ||= {};
        firedMap[candidate.counterStateKey] = { at: new Date().toISOString(), status: 'suppressed-conflict', count: candidate.counterScopeKey === 'session' ? counts.total : counts.chat };
        delete pendingMap[candidate.counterStateKey];
      }
    }
    this.updateContext(s, chatId, text, intent, messageCount, prevCtx); this.saveSessionPreservingRecipientState(s);
    return matched || { handled: false, reason: 'actions-failed-or-conflicted', messageCount };
  }

  async handleSmartFallback({ id, session, raw, chatId, text, intent, messageCount, prevCtx, ctx }) {
    const settings = session.settings || {};
    const message = String(text || '').trim().slice(0, 1200);
    if (!message || settings.interactionFallbackEnabled !== true || quiet(settings)) return null;
    const isGroup = String(chatId || '').endsWith('@g.us');
    // Group fallback is opt-in, while private chat fallback is enabled by default.
    if (isGroup && settings.interactionFallbackInGroups !== true) return null;
    if (!isGroup && !String(chatId || '').endsWith('@c.us') && !String(chatId || '').endsWith('@lid')) return null;
    const cooldownMs = Math.max(10, Number(settings.interactionFallbackCooldownSec) || 45) * 1000;
    const key = `${id}|${chatId}`;
    if (Date.now() - (this.fallbackCool.get(key) || 0) < cooldownMs) return { handled: false, reason: 'smart-fallback-cooldown', messageCount };
    if (!this.rateOk(`${id}|${chatId}`, Number(settings.maxActionsPerMinute) || 20)) return { handled: false, reason: 'rate-limited', messageCount };

    let response = '';
    let source = 'local-intent';
    const historyKey = `${id}|${chatId}`;
    const history = this.conversationHistory.get(historyKey) || [];
    if (settings.smartReplyEnabled === true && this.localLlm) {
      try {
        response = await this.localLlm.generate({
          model: settings.smartReplyModel || 'qwen2.5:3b',
          system: conversationSystemPrompt(settings.smartReplySystemPrompt),
          messages: [...history, { role: 'user', content: message }],
          timeoutMs: settings.smartReplyTimeoutMs || 12000,
          maxTokens: 220,
        });
        source = 'ollama-local';
      } catch (error) {
        this.log(id, 'WARN', `تعذر استخدام النموذج المحلي؛ سيُستخدم الرد الاحتياطي: ${String(error?.message || error).slice(0, 180)}`);
      }
    }
    if (!response) response = templateReply(message, { sender: ctx.sender, fallbackReply: settings.interactionFallbackReply || '' });
    response = String(response || '').trim().slice(0, 1400);
    if (!response) return null;
    try {
      await this.replyToActiveChat(id, raw, chatId, response);
      this.fallbackCool.set(key, Date.now());
      const nextHistory = [...history, { role: 'user', content: message }, { role: 'assistant', content: response }].slice(-10);
      this.conversationHistory.set(historyKey, nextHistory);
      if (this.conversationHistory.size > 1000) this.conversationHistory.delete(this.conversationHistory.keys().next().value);
      this.record(id, 'message', { id: `smart-fallback-${source}`, name: source === 'ollama-local' ? 'الرد الذكي المحلي' : 'الرد الاحتياطي حسب النية' }, 'success', chatId, message, '', null, session);
      this.updateContext(session, chatId, message, intent, messageCount, prevCtx);
      this.saveSessionPreservingRecipientState(session);
      return { handled: true, action: 'smart-fallback', source, response, intent, messageCount };
    } catch (error) {
      this.record(id, 'message', { id: 'smart-fallback', name: 'الرد الاحتياطي' }, error.code === 'SEND_UNCERTAIN' ? 'uncertain' : 'error', chatId, message, '', error, session);
      this.updateContext(session, chatId, message, intent, messageCount, prevCtx);
      this.saveSessionPreservingRecipientState(session);
      return { handled: false, action: 'smart-fallback-error', error: String(error?.message || error).slice(0, 240), messageCount };
    }
  }

  syncLogs(session) {
    // The logger persists a fresh session snapshot. Keep those entries on the in-flight snapshot
    // so the final context/counter save does not accidentally overwrite them.
    try { const latest = this.store.loadSession(session.id); if (Array.isArray(latest.logs)) session.logs = latest.logs; } catch {}
  }
  recordQuiet(id, chatId, text, status, reply, error, sessionRef = null) {
    const s = sessionRef || this.store.loadSession(id); ensureState(s); s.stats ||= {};
    s.interaction.recent = [...s.interaction.recent, { at: new Date().toISOString(), ruleName: 'رد فترة الهدوء', event: 'message', ruleId: 'quiet-hours', status, chatId, text: String(text || '').slice(0, 250), detail: error ? String(error.message || error) : undefined, response: String(reply || '').slice(0, 250) }].slice(-200);
    status === 'success' ? s.stats.interactionActions = Number(s.stats.interactionActions || 0) + 1 : s.stats.interactionErrors = Number(s.stats.interactionErrors || 0) + 1;
    this.saveSessionPreservingRecipientState(s);
    if (status === 'success') { this.log(id, 'INFO', `رد فترة الهدوء → ${chatId}`); this.syncLogs(s); }
  }
  record(id, event, rule, status, chatId, text, emoji, error, sessionRef = null) {
    const s = sessionRef || this.store.loadSession(id); ensureState(s); s.stats ||= {};
    s.interaction.recent = [...s.interaction.recent, { at: new Date().toISOString(), ruleName: rule.name || rule.id, event, ruleId: rule.id, kind: rule.threshold ? 'counter' : 'rule', status, chatId, text: String(text || '').slice(0, 250), emoji, detail: error ? String(error.message || error) : undefined }].slice(-200);
    status === 'success' ? s.stats.interactionActions = Number(s.stats.interactionActions || 0) + 1 : s.stats.interactionErrors = Number(s.stats.interactionErrors || 0) + 1;
    this.saveSessionPreservingRecipientState(s);
    if (status === 'success') { this.log(id, 'INFO', `تفاعل: ${rule.name || rule.id} → ${chatId}`); this.syncLogs(s); }
  }
}
module.exports = { InteractionEngine, match, valid, quiet, quietAction, activeWindow, ruleActiveNow, scopeOk, render, normalizeArabic: norm, inferIntent: triggerEngine.inferIntent, similarityScore: triggerEngine.similarityScore };
