'use strict';

// Safe operational report for the local dashboard. The report intentionally
// exposes only fixed labels, counts and coarse states; never forwards paths,
// contact identifiers, QR/pairing material, tokens, message bodies or raw errors.

function majorVersion(value) {
  const match = String(value || '').trim().match(/^(?:v)?(\d{1,3})(?:\.\d{1,3}){0,2}(?:[-+][0-9A-Za-z.-]{1,20})?$/i);
  return match ? Number(match[1]) : 0;
}
function count(value) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.min(1000000000, Math.max(0, Math.trunc(n))) : 0;
}
function safeVersion(value) {
  const raw = String(value || '').trim();
  return /^(?:v)?\d{1,3}(?:\.\d{1,3}){0,2}(?:[-+][0-9A-Za-z.-]{1,20})?$/.test(raw) ? raw.slice(0, 30) : 'غير محدد';
}
function stateText(value) {
  const state = String(value || '').toLowerCase();
  const labels = {
    ready: 'جاهز', connected: 'متصل', qr: 'بانتظار مسح رمز QR',
    pairing_code: 'بانتظار رمز الربط', initializing: 'جارٍ التهيئة',
    connecting: 'جارٍ الاتصال', disconnected: 'غير متصل',
    auth_failure: 'تعذر التحقق من الجلسة', failed: 'فشل التشغيل',
    stopped: 'متوقف', idle: 'لم يبدأ بعد', preparing: 'جارٍ التجهيز',
  };
  return labels[state] || 'الحالة غير معروفة';
}
function buildReport(input = {}) {
  const checks = [];
  const add = (id, label, status, detail, recommendation = '') => checks.push({ id, label, status, detail, recommendation });
  const nodeMajor = majorVersion(input.nodeVersion);
  const safeNodeVersion = safeVersion(input.nodeVersion);
  add('node-runtime', 'إصدار Node.js', nodeMajor >= 20 ? 'pass' : 'error',
    nodeMajor >= 20 ? `الإصدار ${safeNodeVersion} مناسب للمشروع.` : 'يتطلب المشروع Node.js 20 أو أحدث.',
    nodeMajor >= 20 ? '' : 'ثبّت إصدار LTS حديثًا من Node.js ثم أعد التشغيل.');

  const storage = input.storage || {};
  const dataOK = storage.dataReadable === true && storage.dataWritable === true;
  const sessionsOK = storage.sessionsReadable === true && storage.sessionsWritable === true;
  const storageOK = dataOK && sessionsOK;
  add('data-storage', 'مجلد بيانات المشروع', dataOK ? 'pass' : 'error',
    dataOK ? 'نجحت قراءة المجلد وكتابة الملف التجريبي وإعادة قراءته والتحقق من محتواه ثم حذفه.' : 'تعذرت قراءة مجلد البيانات أو الكتابة فيه أو تنظيف ملف الاختبار.',
    dataOK ? '' : 'تحقق من صلاحيات مجلد البيانات ومساحة القرص، ثم أعد الفحص.');
  add('sessions-storage', 'مجلد الجلسات', sessionsOK ? 'pass' : 'error',
    sessionsOK ? 'نجحت قراءة مجلد الجلسات وكتابة الملف التجريبي وإعادة قراءته والتحقق من محتواه ثم حذفه.' : 'تعذرت قراءة مجلد الجلسات أو الكتابة فيه أو تنظيف ملف الاختبار.',
    sessionsOK ? '' : 'تحقق من صلاحيات مجلد الجلسات ومساحة القرص، ولا تحذف ملفات الجلسة يدويًا.');
  add('local-storage', 'ملخص التخزين المحلي', storageOK ? 'pass' : 'info',
    storageOK ? 'مجلدا البيانات والجلسات قابلان للقراءة والكتابة الفعلية.' : 'راجع النتيجة المنفصلة لمجلدي البيانات والجلسات؛ تُسجل المشكلة في الفحص المحدد لتجنب عدّ العطل مرتين.',
    storageOK ? '' : 'أصلح المجلد المحدد في النتائج أعلاه ثم أعد الفحص.');
  add('session-data', 'بيانات الجلسة', input.sessionLoaded === true ? 'pass' : 'error',
    input.sessionLoaded === true ? 'تم تحميل بيانات الجلسة الحالية.' : 'تعذر تحميل بيانات الجلسة الحالية.',
    input.sessionLoaded === true ? '' : 'استخدم نسخة احتياطية سليمة وافحص سجل التشغيل المحلي قبل استبدال البيانات.');
  const mediaOK = input.mediaWritable === true && input.mediaReadable !== false;
  add('media-storage', 'مكتبة الوسائط', mediaOK ? 'pass' : 'warning',
    mediaOK ? `نجحت القراءة والكتابة وإعادة القراءة المطابقة والتنظيف؛ عدد الملفات المحفوظة: ${count(input.mediaCount)}.` : 'مجلد الوسائط غير موجود أو تعذرت قراءته أو الكتابة فيه أو تنظيف ملف الاختبار.',
    mediaOK ? '' : 'افحص صلاحيات التخزين المحلي ومساحة القرص؛ قد يتعذر حفظ المرفقات أو إرسالها حتى تُحل المشكلة.');

  const wa = input.whatsapp || {};
  if (wa.ready === true) add('whatsapp-session', 'اتصال WhatsApp', 'pass', 'الجلسة متصلة وفق حالة التشغيل الحالية.');
  else if (['failed', 'auth_failure', 'error'].includes(String(wa.status || '').toLowerCase())) add('whatsapp-session', 'اتصال WhatsApp', 'error', `حالة الاتصال: ${stateText(wa.status)}.`, 'راجع صفحة الجلسة وسجل التشغيل، ثم أعد الربط عند الحاجة.');
  else add('whatsapp-session', 'اتصال WhatsApp', 'warning', `حالة الاتصال: ${stateText(wa.status)}.`, 'امسح QR أو أكمل رمز الربط من صفحة الجلسة. لا يمكن اختبار التسليم قبل الاتصال.');
  add('whatsapp-auth', 'بيانات جلسة WhatsApp المحفوظة', wa.hasSavedAuth === true ? 'pass' : 'warning',
    wa.hasSavedAuth === true ? 'عُثر على بيانات جلسة محفوظة؛ هذا لا يضمن قبول WhatsApp لها.' : 'لا توجد بيانات جلسة محفوظة مؤكدة.',
    wa.hasSavedAuth === true ? 'إذا لم يتصل الحساب، أعد الربط من صفحة الجلسة.' : 'اربط الحساب من صفحة الجلسة إذا أردت تشغيله.');

  const voice = input.voice || {};
  if (voice.ready === true) add('voice-runtime', 'محركات الصوت المحلية', 'pass', 'تهيئة محركات الصوت أبلغت عن الجاهزية.');
  else if (String(voice.state || '').toLowerCase() === 'failed') add('voice-runtime', 'محركات الصوت المحلية', 'warning', 'تهيئة الصوت لم تكتمل؛ بقية لوحة التحكم تبقى مستقلة عن هذا المحرك.', 'افتح صفحة المحركات الذكية لمراجعة حالة الصوت وإعادة التهيئة التلقائية.');
  else if (['preparing', 'installing', 'downloading'].includes(String(voice.state || '').toLowerCase())) add('voice-runtime', 'محركات الصوت المحلية', 'info', `تهيئة الصوت قيد التنفيذ (${Math.min(100, count(voice.progress))}%).`, 'انتظر انتهاء التهيئة ثم نفّذ اختبار صوت حقيقي من صفحة المحركات الذكية.');
  else add('voice-runtime', 'محركات الصوت المحلية', 'warning', `حالة محرك الصوت: ${stateText(voice.state)}.`, 'نفّذ اختبار اللغات الأربع؛ حالة الخدمة وحدها لا تثبت نجاح التفريغ أو الإرسال الصوتي.');

  const session = input.session || {};
  const recipientCount = count(session.recipients);
  const groupCount = count(session.groups);
  const enabledRuleCount = count(session.enabledInteractionRules);
  const enabledTaskCount = count(session.enabledAutomationTasks);
  add('targets', 'جهات الإرسال', recipientCount + groupCount > 0 ? 'pass' : 'info',
    `الأشخاص المحفوظون: ${recipientCount}؛ المجموعات المحفوظة: ${groupCount}.`,
    recipientCount + groupCount > 0 ? '' : 'أضف شخصًا أو مجموعة قبل اختبار الإرسال.');
  add('automation', 'القواعد والأتمتة', enabledRuleCount + enabledTaskCount > 0 ? 'pass' : 'info',
    `قواعد التفاعل المفعّلة: ${enabledRuleCount}؛ مهام الأتمتة المفعّلة: ${enabledTaskCount}.`,
    enabledRuleCount + enabledTaskCount > 0 ? '' : 'فعّل قاعدة بعد مراجعتها إذا كنت تحتاج إلى ردود أو مهام تلقائية.');
  if (input.maintenance === true) add('maintenance', 'صيانة النسخ الاحتياطي', 'warning', 'هناك عملية نسخ أو استعادة أو إعادة تهيئة جلسات جارية.', 'انتظر انتهاء العملية قبل اختبار واجهات أخرى.');
  else add('maintenance', 'صيانة النسخ الاحتياطي', 'pass', 'لا توجد عملية صيانة معروفة قيد التنفيذ.');

  const counts = checks.reduce((result, check) => { result[check.status] = (result[check.status] || 0) + 1; return result; }, { pass: 0, warning: 0, error: 0, info: 0 });
  const overall = counts.error ? 'needs_attention' : counts.warning ? 'degraded' : 'healthy';
  return {
    ok: true,
    schemaVersion: 2,
    version: safeVersion(input.version),
    checkedAt: new Date().toISOString(),
    overall,
    summary: { total: checks.length, ...counts },
    checks,
    privacy: 'يعرض التقرير حالات عامة وأعدادًا فقط؛ لا يتضمن محتوى الرسائل أو أرقام الهواتف أو معرفات المحادثات أو رموز الربط أو كلمات المرور أو المسارات المحلية.',
  };
}

module.exports = { buildReport, majorVersion, stateText };
