import contextlib
import importlib.util
import io
import json
import os
import sys
import tempfile
import types
import unittest
from dataclasses import dataclass
from unittest.mock import patch
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKER_PATH = ROOT / 'scripts' / 'voice_worker.py'
spec = importlib.util.spec_from_file_location('chatbot_voice_worker_tested', WORKER_PATH)
worker = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = worker
spec.loader.exec_module(worker)

class Info:
    def __init__(self, language):
        self.language = language
        self.language_probability = 0.98
        self.duration = 2.5

class Segment:
    def __init__(self, text, avg_logprob=-0.15, token_count=4):
        self.text = text
        self.avg_logprob = avg_logprob
        self.tokens = list(range(token_count))
        self.no_speech_prob = 0.02
        self.compression_ratio = 1.12

class FakeModel:
    calls = []
    def __init__(self, path, device='cpu', compute_type='int8'):
        self.path = path
        self.device = device
        self.compute_type = compute_type
    def transcribe(self, source, **kwargs):
        self.calls.append(kwargs)
        language = kwargs.get('language') or 'ar'
        samples = {
            'ar': 'مرحبا هذا اختبار صوتي',
            'en': 'Hello this is a speech test',
            'fr': 'Bonjour ceci est un test vocal',
            'de': 'Guten Morgen dies ist ein Sprachtest',
        }
        return iter([Segment(samples[language], -0.15, 4), Segment('', -0.60, 1)]), Info(language)

class VoiceWorkerQualityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / 'sample.wav'
        self.source.write_bytes(b'fake-wave-data')
        self.model = self.root / 'model'
        self.model.mkdir()
        (self.model / 'model.bin').write_bytes(b'model')
        (self.model / 'config.json').write_text('{}', encoding='utf-8')
        self.old_env = dict(os.environ)
        os.environ.update({
            'WHISPER_PY_DEVICE': 'cpu', 'WHISPER_PY_COMPUTE_TYPE': 'int8',
            'WHISPER_PY_BEAM_SIZE': '5', 'WHISPER_PY_VAD': 'true',
            'WHISPER_PY_VAD_THRESHOLD': '0.5', 'WHISPER_PY_MIN_SILENCE_MS': '450',
            'WHISPER_PY_LOG_PROB_THRESHOLD': '-1.0', 'WHISPER_PY_NO_SPEECH_THRESHOLD': '0.6',
            'WHISPER_PY_COMPRESSION_RATIO_THRESHOLD': '2.4', 'WHISPER_PY_CONDITION_ON_PREVIOUS_TEXT': 'false',
        })
        self.fake_module = types.ModuleType('faster_whisper')
        self.fake_module.WhisperModel = FakeModel
        self.fake_module.__version__ = '1.1.0'
        self.fake_av = types.ModuleType('av')
        self.fake_av.__version__ = '18.1.0'
        self.previous_fw = sys.modules.get('faster_whisper')
        self.previous_av = sys.modules.get('av')
        sys.modules['faster_whisper'] = self.fake_module
        sys.modules['av'] = self.fake_av
        FakeModel.calls.clear()

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self.old_env)
        if self.previous_fw is None: sys.modules.pop('faster_whisper', None)
        else: sys.modules['faster_whisper'] = self.previous_fw
        if self.previous_av is None: sys.modules.pop('av', None)
        else: sys.modules['av'] = self.previous_av
        self.temp.cleanup()

    def call_worker(self, language):
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout):
            worker.do_transcribe(str(self.source), language, str(self.model))
        lines = [line for line in stdout.getvalue().splitlines() if line.strip()]
        return json.loads(lines[-1])

    def test_four_languages_use_local_model_and_return_quality_metrics(self):
        expected = {
            'ar': 'مرحبا هذا اختبار صوتي',
            'en': 'Hello this is a speech test',
            'fr': 'Bonjour ceci est un test vocal',
            'de': 'Guten Morgen dies ist ein Sprachtest',
        }
        for language, phrase in expected.items():
            result = self.call_worker(language)
            self.assertTrue(result['ok'])
            self.assertEqual(result['language'], language)
            self.assertEqual(result['transcript'], phrase)
            self.assertEqual(result['languageProbability'], 0.98)
            self.assertEqual(result['avgLogProbability'], -0.24, 'segment average log probability is weighted by token count, not segment count')
            self.assertEqual(result['avgNoSpeechProbability'], 0.02)
            self.assertEqual(result['maxCompressionRatio'], 1.12)
            self.assertEqual(result['segments'], 2)
            self.assertEqual(result['lowConfidenceSegments'], 0)
        self.assertEqual(len(FakeModel.calls), 4)
        for call in FakeModel.calls:
            self.assertEqual(call['beam_size'], 5)
            self.assertTrue(call['vad_filter'])
            self.assertEqual(call['vad_parameters']['threshold'], 0.5)
            self.assertEqual(call['vad_parameters']['min_silence_duration_ms'], 450)
            self.assertFalse(call['condition_on_previous_text'])
            self.assertEqual(call['compression_ratio_threshold'], 2.4)
            self.assertEqual(call['log_prob_threshold'], -1.0)
            self.assertEqual(call['no_speech_threshold'], 0.6)

    def test_auto_language_is_left_to_model(self):
        result = self.call_worker('auto')
        self.assertEqual(result['language'], 'ar')
        self.assertIsNone(FakeModel.calls[-1]['language'])

    def test_pyav_19_is_rejected(self):
        self.fake_av.__version__ = '19.0.0'
        runtime = worker.runtime_compatibility()
        self.assertFalse(runtime['avCompatible'])
        with self.assertRaisesRegex(RuntimeError, 'PyAV غير متوافق'):
            worker.do_transcribe(str(self.source), 'ar', str(self.model))

    def test_high_no_speech_with_strong_words_is_not_counted_as_weak_segment(self):
        class StrongWordHighSilenceSegment(Segment):
            def __init__(self):
                super().__init__("نص مفهوم", -0.1, 3)
                self.no_speech_prob = 0.95
        original = FakeModel.transcribe
        try:
            FakeModel.transcribe = lambda _self, _source, **_kwargs: (iter([StrongWordHighSilenceSegment()]), Info("ar"))
            payload = self.call_worker("auto")
        finally:
            FakeModel.transcribe = original
        self.assertEqual(payload["lowConfidenceSegments"], 0, "high no-speech alone must not downgrade a segment with strong token probability")

    def test_piper_18_reports_arabic_tashkeel_default(self):
        piper_package = types.ModuleType('piper')
        piper_package.__path__ = []
        piper_voice_module = types.ModuleType('piper.voice')
        @dataclass
        class FakePiperVoice:
            use_tashkeel: bool = True
            model_path: str = ''
        piper_voice_module.PiperVoice = FakePiperVoice
        with patch.dict(sys.modules, {'piper': piper_package, 'piper.voice': piper_voice_module}):
            with patch('importlib.metadata.version', return_value='1.8.0'):
                result = worker.piper_tashkeel_info()
        self.assertEqual(result['piperTtsVersion'], '1.8.0')
        self.assertTrue(result['arabicTashkeelAvailable'])
        self.assertTrue(result['arabicTashkeelEnabledByDefault'])

    def test_old_piper_does_not_claim_tashkeel_support(self):
        with patch('importlib.metadata.version', return_value='1.7.0'):
            result = worker.piper_tashkeel_info()
        self.assertEqual(result['piperTtsVersion'], '1.7.0')
        self.assertFalse(result['arabicTashkeelAvailable'])
        self.assertFalse(result['arabicTashkeelEnabledByDefault'])

    def test_supported_pyav_and_invalid_device_configuration(self):
        self.assertTrue(worker.runtime_compatibility()['avCompatible'])
        os.environ['WHISPER_PY_DEVICE'] = 'mystery-device'
        with self.assertRaisesRegex(ValueError, 'WHISPER_PY_DEVICE'):
            worker._transcription_options()

if __name__ == '__main__':
    unittest.main()
