'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const EventEmitter = require('node:events');
const Module = require('node:module');

const originalLoad = Module._load;
const originalResolve = Module._resolveFilename;
const clients = [];
let conversionDelay = 30;
let initializeMode = 'sync';
class FakeClient extends EventEmitter {
  constructor(options) { super(); this.options = options; this.destroyCount = 0; clients.push(this); }
  async initialize() {
    if (this.options.pairWithPhoneNumber?.phoneNumber) { this.emit('code', 'AB12CD34'); return true; }
    if (initializeMode === 'delayed-qr-pending') {
      setTimeout(() => this.emit('qr', 'REAL-CLIENT-QR-PAYLOAD'), 15);
      return new Promise(() => {});
    }
    if (initializeMode === 'reject-after-disconnect' || initializeMode === 'auth-failure-pending') { this.emit('qr', 'REAL-CLIENT-QR-PAYLOAD'); return new Promise((resolve, reject) => { this.rejectInitialize = reject; }); }
    this.emit('qr', 'REAL-CLIENT-QR-PAYLOAD'); return true;
  }
  async destroy() { this.destroyCount++; }
  async getState() { return null; }
}
Module._resolveFilename = function (request, parent, isMain, options) {
  if (request === 'whatsapp-web.js/package.json') return '/tmp/chatbot-connection-test/package.json';
  return originalResolve.call(this, request, parent, isMain, options);
};
Module._load = function (request, parent, isMain) {
  if (request === 'whatsapp-web.js') return { Client: FakeClient, LocalAuth: class LocalAuth { constructor(options) { this.options = options; } }, MessageMedia: { fromFilePath: file => ({ file }) } };
  if (request === 'qrcode') return { toDataURL: async (value, options) => {
    await new Promise(resolve => setTimeout(resolve, conversionDelay));
    assert.equal(value, 'REAL-CLIENT-QR-PAYLOAD');
    assert.equal(options.width, 360);
    assert.equal(options.errorCorrectionLevel, 'H');
    return 'data:image/png;base64,aGVsbG8=';
  } };
  return originalLoad.call(this, request, parent, isMain);
};

(async () => {
  process.env.NODE_ENV = 'test';
  let WhatsAppManager, navigationRecoveryPlan, normalizePairingPhoneNumber, browserProfileConflictError, classifyDisconnectReason, shouldAutoReconnectAfterDisconnect;
  try { ({ WhatsAppManager, navigationRecoveryPlan, normalizePairingPhoneNumber, browserProfileConflictError, classifyDisconnectReason, shouldAutoReconnectAfterDisconnect } = require('../src/whatsapp')); }
  finally { Module._load = originalLoad; Module._resolveFilename = originalResolve; }
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-connection-'));
  try {
    const savedSessions = new Map();
    const store = {
      safeSessionId: id => String(id || 'main'),
      ensureDir(id) { fs.mkdirSync(path.join(root, String(id)), { recursive: true }); },
      getPaths(id) { const dir = path.join(root, String(id)); return { dir, auth: path.join(dir, 'auth') }; },
      loadSession(id) { return savedSessions.get(String(id)) || { id: String(id), whatsappLifecycle: { requiresReauth: false, lastDisconnectReason: '', lastLogoutAt: null, lastProfileBackup: '' } }; },
      saveSession(session) { savedSessions.set(String(session.id), JSON.parse(JSON.stringify(session))); return session; },
    };
    const managerLogs = [];
    const manager = new WhatsAppManager({ store, log: (...args) => managerLogs.push(args) });
    const started = await manager.start('main');
    assert.equal(started.status, 'qr');
    assert.equal(started.qr, null, 'must not expose raw QR payload before conversion is finished');
    assert.equal(manager.listRuntime('main').qr, null);
    await new Promise(resolve => setTimeout(resolve, conversionDelay + 15));
    let runtime = manager.listRuntime('main');
    assert.equal(runtime.status, 'qr');
    assert.match(runtime.qr, /^data:image\/png;base64,/);
    assert.notEqual(runtime.qr, 'REAL-CLIENT-QR-PAYLOAD');
    assert.ok(runtime.qrUpdatedAt, 'QR timestamp exists for live refreshes');

    // Repeated Connect must leave the active QR client intact.
    const again = await manager.start('main');
    assert.equal(again.status, 'qr');
    assert.equal(clients.length, 1, 'second click must not create a competing WhatsApp client');
    assert.equal(clients[0].destroyCount, 0, 'second click must not destroy the active QR flow');

    assert.ok(navigationRecoveryPlan(new Error('Execution context was destroyed, most likely because of a navigation')));
    assert.equal(navigationRecoveryPlan(new Error('ordinary invalid phone number')), null);
    assert.equal(classifyDisconnectReason('LOGOUT'), 'logout');
    assert.equal(classifyDisconnectReason(new Error('WhatsApp LOGOUT')), 'logout');
    assert.equal(classifyDisconnectReason('UNPAIRED'), 'reauth');
    assert.equal(classifyDisconnectReason('CONFLICT'), 'transient');
    assert.equal(shouldAutoReconnectAfterDisconnect('LOGOUT'), false, 'explicit logout must never schedule an automatic reconnect');
    assert.equal(shouldAutoReconnectAfterDisconnect('TIMEOUT'), true, 'temporary disconnects remain eligible for bounded recovery');

    // Repeated context destruction can be caused by a Chromium profile created by a different
    // browser build. Preserve the old profile as a backup and let LocalAuth generate a fresh QR.
    const damagedPaths = store.getPaths('damaged');
    const damagedProfile = path.join(damagedPaths.auth, 'session-damaged');
    fs.mkdirSync(damagedProfile, { recursive: true });
    fs.writeFileSync(path.join(damagedProfile, 'Preferences'), '{"profile":{"test":true}}');
    const damagedRuntime = manager.entry('damaged');
    assert.equal(manager.quarantineNavigationDamagedProfile('damaged', damagedRuntime), true);
    assert.equal(fs.existsSync(damagedProfile), false, 'damaged profile must no longer be used by LocalAuth');
    assert.equal(damagedRuntime.navigationProfileReset, true);
    assert.match(damagedRuntime.profileRecoveryNotice, /احتياطيًا/);
    const backups = path.join(damagedPaths.dir, 'auth-profile-backups');
    const backupDirs = fs.readdirSync(backups);
    assert.equal(backupDirs.length, 1);
    assert.equal(fs.readFileSync(path.join(backups, backupDirs[0], 'Preferences'), 'utf8'), '{"profile":{"test":true}}', 'previous credentials/profile must be preserved, not deleted');

    await manager.stop('main');
    assert.equal(manager.listRuntime('main').status, 'stopped');

    // A real Chromium initialize() may stay pending while WhatsApp Web is navigating.
    // Connect must return immediately, and a later QR event must still reach the poll endpoint.
    initializeMode = 'delayed-qr-pending';
    const startedAt = Date.now();
    const slowStart = await manager.start('pending');
    assert.ok(Date.now() - startedAt < 500, 'connection start must not wait for browser navigation to finish');
    assert.equal(slowStart.status, 'starting');
    await new Promise(resolve => setTimeout(resolve, conversionDelay + 35));
    runtime = manager.listRuntime('pending');
    assert.equal(runtime.status, 'qr');
    assert.match(runtime.qr, /^data:image\/png;base64,/);
    const notReadyStartedAt = Date.now();
    await assert.rejects(() => manager.ensureReady('pending', 1000), /امسح رمز QR/);
    assert.ok(Date.now() - notReadyStartedAt < 250, 'send paths should explain QR pairing promptly instead of hanging until timeout');
    await manager.stop('pending');
    initializeMode = 'sync';

    const source = fs.readFileSync(path.join(__dirname, '..', 'public', 'app.js'), 'utf8');
    const server = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf8');
    assert.match(source, /refreshSessionRuntime\(\)/, 'the UI needs a live state poll for async QR events');
    assert.match(source, /setInterval\(\(\) => \{ if \(state\.page === 'session'\) refreshSessionRuntime\(\); \}, 1400\)/);
    assert.match(source, /id="sessionQrImage"/);
    assert.match(source, /sessionQrPlaceholder/);
    assert.match(source, /runtime\.qrWaitWarning/);
    assert.match(source, /img\.hidden = !goodQr/);
    assert.match(source, /ERR_BLOCKED_BY_ADMINISTRATOR/,'network administrator blocks should show a specific actionable hint');
    assert.match(source, /لن يتم إنشاء رمز وهمي/,'the UI must not imply a QR exists when WhatsApp Web could not open');
    assert.match(server, /app\.get\('\/api\/session\/status'/);
    assert.match(server, /Cache-Control', 'no-store/);
    const compat = fs.readFileSync(path.join(__dirname, '..', 'src', 'compat.js'), 'utf8');
    const browserLoader = fs.readFileSync(path.join(__dirname, '..', 'scripts', 'ensure-browser.js'), 'utf8');
    const managerSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'whatsapp.js'), 'utf8');
    assert.match(compat, /waitForFunction\('window\.Debug\?\.VERSION != undefined'/, 'Debug polling must survive execution-context resets');
    assert.match(compat, /waitForFunction\('window\.WWebJS != undefined'/, 'injected-helper polling must survive navigation');
    assert.match(compat, /_chatBotInjectWithNavigationRetry/, 'inject must retry context-loss errors in a bounded way');
    assert.match(managerSource, /quarantineNavigationDamagedProfile/, 'repeated context loss must preserve the bad profile and start with a fresh QR profile');
    assert.match(browserLoader, /configuredCandidate\(\) \|\| markerCandidate\(\) \|\| puppeteerPath\(\)/, 'browser choice should prefer an explicitly configured or pinned executable');

    // Phone-based pairing is an actual whatsapp-web.js option, not merely a visible UI choice.
    assert.equal(normalizePairingPhoneNumber('+968 9123-4567'), '96891234567');
    assert.equal(normalizePairingPhoneNumber('+٩٦٨ ٩١٢٣-٤٥٦٧'), '96891234567', 'Arabic numerals should be normalized before validation');
    assert.equal(normalizePairingPhoneNumber('00968 9123 4567'), '96891234567', 'international 00 prefix should work as a simpler alternative to +');
    assert.throws(() => normalizePairingPhoneNumber('91234567'), /رمز الدولة|الصيغة الدولية|دوليًا/);
    assert.throws(() => normalizePairingPhoneNumber('123'), /رقم الربط/);
    const pairingStart = await manager.start('pairing', { method: 'phone', phoneNumber: '+968 9123 4567' });
    assert.equal(pairingStart.status, 'pairing_code');
    assert.equal(pairingStart.pairingCode, 'AB12CD34');
    assert.equal(clients.at(-1).options.pairWithPhoneNumber.phoneNumber, '96891234567');
    assert.equal(clients.at(-1).options.pairWithPhoneNumber.intervalMs, 180000);
    assert.equal((await manager.start('pairing', { method: 'phone', phoneNumber: '+968 9123 4567' })).pairingCode, 'AB12CD34');
    const pairingClientCount = clients.length;
    assert.equal(clients.at(-1).destroyCount, 0, 'repeat Connect during a pairing code session must not destroy the active browser');
    assert.equal(clients.length, pairingClientCount);
    await assert.rejects(() => manager.start('invalid-pairing', { method: 'phone', phoneNumber: '123' }), /رقم الربط/);
    const recoveryEntry = manager.entry('recovery-phone');
    recoveryEntry.connectionMethod = 'phone'; recoveryEntry.pairingPhoneDigits = '96891234567'; recoveryEntry.status = 'disconnected';
    await manager.start('recovery-phone', { recovery: true });
    assert.equal(clients.at(-1).options.pairWithPhoneNumber.phoneNumber, '96891234567', 'recovery should preserve phone pairing mode and never silently switch back to QR');
    await manager.stop('recovery-phone');
    const profileConflict = browserProfileConflictError(new Error('The browser is already running for C:\\secret\\profile. Use a different userDataDir or stop the running browser first.'));
    assert.equal(profileConflict.code, 'BROWSER_PROFILE_IN_USE');
    assert.match(profileConflict.message, /أوقف النسخة القديمة/);

    // An explicit WhatsApp LOGOUT is terminal for the current credentials: do not reconnect,
    // persist the re-auth requirement across process restart, and archive the obsolete profile
    // before the user starts a fresh QR/phone pairing flow.
    initializeMode = 'reject-after-disconnect';
    const logoutStart = await manager.start('logout-case', { method: 'qr' });
    await new Promise(resolve => setTimeout(resolve, conversionDelay + 15));
    assert.equal(manager.listRuntime('logout-case').status, 'qr');
    const logoutClient = clients.at(-1);
    const logoutPaths = store.getPaths('logout-case');
    const loggedOutProfile = path.join(logoutPaths.auth, 'session-logout-case');
    fs.mkdirSync(loggedOutProfile, { recursive: true });
    fs.writeFileSync(path.join(loggedOutProfile, 'Preferences'), '{"profile":"logged-out"}');
    logoutClient.emit('disconnected', 'LOGOUT');
    logoutClient.rejectInitialize?.(new Error("Attempted to use detached Frame 'old-logout-frame'"));
    await new Promise(resolve => setTimeout(resolve, 40));
    initializeMode = 'sync';
    assert.equal(manager.listRuntime('logout-case').status, 'logged_out');
    assert.equal(manager.entry('logout-case').reconnectTimer, null, 'LOGOUT must cancel any pending reconnect timer');
    assert.equal(manager.entry('logout-case').authResetRequired, true);
    assert.equal(store.loadSession('logout-case').whatsappLifecycle.requiresReauth, true, 'the logout requirement must survive process restart');
    assert.equal(fs.existsSync(loggedOutProfile), true, 'logout must not delete the old profile before a user requests a new pairing');
    assert.equal(managerLogs.some(args => String(args[2] || '').includes('انتهت محاولة تشغيل قديمة بعد تغيير حالة الجلسة')), false, 'stale init rejection after logout must not be reported as a warning');
    assert.equal(managerLogs.some(args => String(args[2] || '').includes('أُهملت نتيجة تهيئة المتصفح القديم بعد تسجيل الخروج المقصود')), true, 'the expected stale frame rejection is recorded as an informational lifecycle event');
    const afterRestartManager = new WhatsAppManager({ store, log: () => {} });
    const freshStart = await afterRestartManager.start('logout-case', { method: 'qr' });
    assert.equal(freshStart.status, 'qr');
    assert.equal(afterRestartManager.entry('logout-case').authResetRequired, false);
    assert.equal(fs.existsSync(loggedOutProfile), false, 'manual re-pair archives the obsolete LocalAuth browser profile');
    const backupRoot = path.join(logoutPaths.dir, 'auth-profile-backups');
    const logoutBackups = fs.readdirSync(backupRoot).filter(name => name.includes('logged-out'));
    assert.equal(logoutBackups.length, 1, 'the invalidated profile must remain available as a backup');
    assert.equal(fs.readFileSync(path.join(backupRoot, logoutBackups[0], 'Preferences'), 'utf8'), '{"profile":"logged-out"}');
    assert.equal(store.loadSession('logout-case').whatsappLifecycle.requiresReauth, false, 'a successful new pairing attempt clears the pending auth-reset marker after archiving');
    await afterRestartManager.stop('logout-case');

    // auth_failure must close the old Chromium instance even when initialize() never settles.
    // The next pairing attempt may proceed only after that cleanup and must preserve the old profile.
    initializeMode = 'auth-failure-pending';
    const authFailureStart = await manager.start('auth-failure-case', { method: 'qr' });
    assert.equal(authFailureStart.status, 'qr');
    await new Promise(resolve => setTimeout(resolve, conversionDelay + 15));
    const authFailureClient = clients.at(-1);
    const authFailurePaths = store.getPaths('auth-failure-case');
    const authFailureProfile = path.join(authFailurePaths.auth, 'session-auth-failure-case');
    fs.mkdirSync(authFailureProfile, { recursive: true });
    fs.writeFileSync(path.join(authFailureProfile, 'Preferences'), '{"profile":"auth-failure"}');
    authFailureClient.emit('auth_failure', 'Invalid authentication');
    await new Promise(resolve => setTimeout(resolve, 30));
    assert.equal(manager.listRuntime('auth-failure-case').status, 'auth_failure');
    assert.equal(authFailureClient.destroyCount, 1, 'auth_failure must close the stale browser even if initialize remains pending');
    assert.equal(manager.entry('auth-failure-case').cleanupClient, null, 'successful auth_failure cleanup must release the old client reference');
    assert.equal(manager.entry('auth-failure-case').processLock, null, 'auth_failure cleanup must release the profile process lock');
    assert.equal(store.loadSession('auth-failure-case').whatsappLifecycle.requiresReauth, true);
    initializeMode = 'sync';
    await manager.start('auth-failure-case', { method: 'qr' });
    await new Promise(resolve => setTimeout(resolve, conversionDelay + 15));
    assert.equal(manager.listRuntime('auth-failure-case').status, 'qr');
    assert.equal(fs.existsSync(authFailureProfile), false, 'the invalid auth profile must be archived before a fresh pairing attempt');
    const authFailureBackupRoot = path.join(authFailurePaths.dir, 'auth-profile-backups');
    const authFailureBackup = fs.readdirSync(authFailureBackupRoot).find(name => name.includes('logged-out'));
    assert.ok(authFailureBackup, 'auth_failure must preserve the previous browser profile in backup storage');
    assert.equal(fs.readFileSync(path.join(authFailureBackupRoot, authFailureBackup, 'Preferences'), 'utf8'), '{"profile":"auth-failure"}');
    await manager.stop('auth-failure-case');

    // The old disconnect handler started another client while Chrome still owned the same
    // profile. Verify that the new start waits for old-client cleanup first.
    const beforeReconnect = clients.length;
    const reconnectStart = await manager.start('reconnect', { method: 'qr' });
    assert.equal(reconnectStart.status, 'qr');
    const disconnectedClient = clients.at(-1);
    await new Promise(resolve => setTimeout(resolve, 20));
    disconnectedClient.emit('disconnected', 'test disconnect');
    await manager.start('reconnect', { method: 'qr' });
    await new Promise(resolve => setTimeout(resolve, conversionDelay + 30));
    assert.equal(clients.length, beforeReconnect + 2, 'the reconnect request should wait for the previous Chrome instance to be cleaned');

    const nativeDestroy = manager.destroyClientSafely.bind(manager);
    // Concurrent Connect clicks during a slow cleanup share one gate and produce one client.
    const concurrentStart = await manager.start('concurrent-cleanup', { method: 'qr' });
    assert.equal(concurrentStart.status, 'qr');
    const concurrentOldClient = clients.at(-1);
    manager.destroyClientSafely = async (client, ...args) => {
      if (client === concurrentOldClient) await new Promise(resolve => setTimeout(resolve, 40));
      return nativeDestroy(client, ...args);
    };
    concurrentOldClient.emit('disconnected', 'slow cleanup');
    const clientCountBeforeConcurrentRetry = clients.length;
    await Promise.all([
      manager.start('concurrent-cleanup', { method: 'qr' }),
      manager.start('concurrent-cleanup', { method: 'qr' }),
    ]);
    await new Promise(resolve => setTimeout(resolve, conversionDelay + 25));
    assert.equal(clients.length, clientCountBeforeConcurrentRetry + 1, 'concurrent Connect clicks must be coalesced into one new client');
    manager.destroyClientSafely = nativeDestroy;
    await manager.stop('concurrent-cleanup');

    // A failed close must remain tracked after the first cleanup Promise settles.
    // Manual retries must not create a second Client until the stale browser is closed.
    const cleanupStart = await manager.start('cleanup-proof', { method: 'qr' });
    assert.equal(cleanupStart.status, 'qr');
    const staleClient = clients.at(-1);
    let refuseCleanup = true;
    manager.destroyClientSafely = async (client, ...args) => {
      if (client === staleClient && refuseCleanup) return false;
      return nativeDestroy(client, ...args);
    };
    staleClient.emit('disconnected', 'forced cleanup failure');
    await new Promise(resolve => setTimeout(resolve, 10));
    const countBeforeBlockedRetry = clients.length;
    await assert.rejects(() => manager.start('cleanup-proof', { method: 'qr' }), /تعذر إغلاق متصفح WhatsApp السابق بأمان/);
    assert.equal(clients.length, countBeforeBlockedRetry, 'a failed cleanup must block creation of a competing WhatsApp Client');
    assert.equal(manager.entry('cleanup-proof').cleanupClient, staleClient, 'failed cleanup keeps the browser reference for a later retry');
    assert.equal(manager.listRuntime('cleanup-proof').cleanupPending, true);
    refuseCleanup = false;
    await manager.start('cleanup-proof', { method: 'qr' });
    assert.equal(clients.length, countBeforeBlockedRetry + 1, 'a replacement client may start only after the tracked browser closes');
    assert.equal(manager.entry('cleanup-proof').cleanupClient, null, 'successful retry clears the stale browser marker');
    manager.destroyClientSafely = nativeDestroy;

    // Unlinking must never erase LocalAuth files if Chromium cleanup cannot be verified.
    const unlinkStart = await manager.start('unlink-safe', { method: 'qr' });
    assert.equal(unlinkStart.status, 'qr');
    const unlinkClient = clients.at(-1);
    const authDir = store.getPaths('unlink-safe').auth;
    const authBackupDir = path.join(store.getPaths('unlink-safe').dir, 'auth-profile-backups');
    fs.mkdirSync(authBackupDir, { recursive: true });
    fs.writeFileSync(path.join(authBackupDir, 'old-profile-secret.txt'), 'old-auth');
    fs.mkdirSync(authDir, { recursive: true });
    fs.writeFileSync(path.join(authDir, 'auth-preserve.txt'), 'preserve');
    manager.destroyClientSafely = async (client, ...args) => client === unlinkClient ? false : nativeDestroy(client, ...args);
    await assert.rejects(() => manager.stop('unlink-safe', { clearAuth: true }), /لم تُحذف بيانات الربط/);
    assert.equal(fs.readFileSync(path.join(authDir, 'auth-preserve.txt'), 'utf8'), 'preserve', 'auth remains intact if the browser is still in use');
    manager.destroyClientSafely = nativeDestroy;
    await manager.stop('unlink-safe', { clearAuth: true });
    assert.equal(fs.existsSync(authDir), false, 'user-selected unlink removes auth only after safe browser cleanup');
    assert.equal(fs.existsSync(authBackupDir), false, 'explicit unlink also removes archived browser credentials so old backups cannot retain a logged-out account');

    await manager.stop('pairing');
    await manager.stop('reconnect');
    await manager.stop('cleanup-proof');
    console.log('whatsapp-connection: ok (QR, phone pairing, duplicate starts, retained cleanup failure, safe unlink, profile lock diagnostics, disconnect cleanup and bounded navigation recovery)');
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
})().catch(error => { console.error(error); process.exitCode = 1; });
