"use strict";
const assert = require('node:assert/strict');
const { AutomationEngine, normalizeAutomationRule, normalizeMute, matchText, getTargets, isRealCalendarDate, pruneSeenMessages } = require('../src/automation-engine');
const { dueForItem, nextRunForItem } = require('../src/scheduler');
const { isQuietHours, quietAction, automationAllowedDuringQuiet } = require('../src/time-policy');

function makeSession() {
  return {
    id: 'test', settings: { timezone: 'UTC', automationEnabled: true, automationGroupPermissions: { allowDeleteMessage: false, allowDeleteChat: false, allowArchive: true, allowMute: true, adminsOnly: false } },
    recipients: [
      { id: 'r1', phone: '96891234567', enabled: true, name: 'Contact' },
      ...['96890001111@c.us','96890002222@c.us','96890007777@c.us','96890008888@c.us'].map((chatId, index) => ({ id: `test-${index}`, chatId, enabled: true, name: `Test ${index}` })),
    ],
    groups: [{ id: 'g1', gid: '120363000000@g.us', name: 'Group', enabled: true, admins: [{ id: '96890000000@c.us', admin: true }], participants: [] }],
    automation: { enabled: true, tasks: [], rules: [], mutes: [], eventState: { totalMessages: 0, byChat: {}, seenMessages: {}, ruleCounts: {} }, recent: [] },
    stats: {},
  };
}
function message(chat, suffix, body = 'مرحبا') {
  return { from: chat, author: '96891230000@c.us', fromMe: false, body, timestamp: Math.floor(Date.now() / 1000), id: { _serialized: `true_${chat}_${suffix}`, remote: chat } };
}
(async () => {
  assert.equal(matchText({ matchMode: 'contains', pattern: 'مرحبا' }, 'أهلًا مرحبا بك'), true);
  assert.equal(matchText({ matchMode: 'starts', pattern: 'أهلًا' }, 'أهلًا بك'), true);
  assert.equal(matchText({ matchMode: 'ends', pattern: 'بك' }, 'أهلًا بك'), true);
  assert.equal(matchText({ matchMode: 'exact', pattern: 'مرحبا' }, 'مرحبا'), true);
  assert.equal(matchText({ matchMode: 'regex', pattern: '^مرحب[اًا]' }, 'مرحبا'), true);
  assert.equal(matchText({ matchMode: 'regex', pattern: '[' }, 'anything'), false);
  assert.equal(matchText({ matchMode: 'regex', pattern: '^(a+)+$' }, 'aaaaaaaaaaaaaaaaaaaaaaaa!'), false, 'potentially catastrophic regular expressions are refused');
  assert.equal(isRealCalendarDate('2026-02-28'), true);
  const quietSettings = { interactionQuietEnabled: true, interactionQuietStart: '23:00', interactionQuietEnd: '07:00', interactionQuietAction: 'silence', timezone: 'Asia/Muscat' };
  assert.equal(isQuietHours(quietSettings, new Date('2026-10-30T20:30:00Z')), true, 'quiet window crosses midnight in the configured timezone');
  assert.equal(isQuietHours(quietSettings, new Date('2026-10-30T03:00:00Z')), false, 'the quiet interval end is exclusive');
  assert.equal(isQuietHours({ ...quietSettings, interactionQuietStart: '07:00', interactionQuietEnd: '07:00' }, new Date('2026-10-30T20:30:00Z')), false, 'identical quiet bounds do not accidentally mean all day');
  assert.equal(quietAction({ interactionQuietAction: 'invalid' }), 'silence');
  assert.equal(automationAllowedDuringQuiet(quietSettings, new Date('2026-10-30T20:30:00Z')), false, 'silence mode blocks automation replies');
  assert.equal(automationAllowedDuringQuiet({ ...quietSettings, interactionQuietAction: 'reply' }, new Date('2026-10-30T20:30:00Z')), false, 'reply mode reserves the quiet reply for the interaction engine');
  assert.equal(automationAllowedDuringQuiet({ ...quietSettings, interactionQuietAction: 'rules' }, new Date('2026-10-30T20:30:00Z')), true, 'rules mode explicitly allows configured rules');
  assert.equal(isRealCalendarDate('2026-02-31'), false);
  assert.throws(() => normalizeAutomationRule({ triggerType: 'time', mode: 'once', date: '2026-02-31', action: 'log' }, makeSession()), /تاريخ/);
  assert.throws(() => normalizeAutomationRule({ triggerType: 'message', action: 'log', matchMode: 'regex', pattern: '^(a+)+$' }, makeSession()), /Regex/);
  const staleSeen = { old: Date.now() - 90000000, keep: Date.now() };
  pruneSeenMessages(staleSeen); assert.deepEqual(Object.keys(staleSeen), ['keep']);

  const base = makeSession();
  assert.throws(() => normalizeAutomationRule({ name: 'unsafe', triggerType: 'message', action: 'delete-message', matchMode: 'any' }, base), /تأكيد/);
  const deleteRule = normalizeAutomationRule({ name: 'delete matched message', triggerType: 'message', action: 'delete-message', matchMode: 'contains', pattern: 'مرحبا', confirmDestructive: true, targetMode: 'current' }, base);
  assert.equal(deleteRule.action, 'delete-message');
  const ageRule = normalizeAutomationRule({ name: 'retention', triggerType: 'message-age', action: 'log', mode: 'daily', time: '22:00', targetMode: 'all', confirmDestructive: true }, base);
  assert.equal(ageRule.action, 'cleanup-old-messages');

  const temporary = normalizeMute({ chatId: '96891234567@c.us', mode: 'temporary', minutes: 10 });
  assert.equal(temporary.mode, 'temporary');
  assert.ok(new Date(temporary.expiresAt).getTime() > Date.now());
  const permanent = normalizeMute({ chatId: '120363000000@g.us', mode: 'permanent' });
  assert.equal(permanent.mode, 'permanent');
  assert.equal(permanent.expiresAt, '');
  assert.throws(() => normalizeMute({ chatId: 'not-a-jid', mode: 'permanent' }), /غير صالح/);

  assert.deepEqual(getTargets(base, { targetMode: 'all', targetKeys: [], targetChatIds: [] }, '' ).sort(), ['120363000000@g.us', '96890001111@c.us', '96890002222@c.us', '96890007777@c.us', '96890008888@c.us', '96891234567@c.us'].sort());
  const schedulerItem = { id: 'daily', enabled: true, mode: 'daily', time: '22:00', timezone: 'UTC', lastRunKey: '' };
  const due = dueForItem(new Date('2026-10-22T22:02:00.000Z'), schedulerItem);
  assert.equal(due.due, true);
  assert.equal(dueForItem(new Date('2026-10-22T22:02:00.000Z'), { ...schedulerItem, lastRunKey: due.key }).due, false);
  assert.equal(nextRunForItem({ ...schedulerItem, time: '23:59' }, new Date('2026-10-22T22:00:00.000Z'))?.slice(0, 10), '2026-10-22');

  let session = makeSession();
  const store = { loadSession: () => session, saveSession: s => { session = s; return s; } };
  const executed = { deleted: 0, chatActions: [] };
  const whatsapp = {
    deleteMessage: async (_id, msg, opts) => { executed.deleted++; return { messageId: msg.id._serialized, everyone: opts.everyone }; },
    actOnChat: async (_id, id, action) => { executed.chatActions.push([id, action]); return { action }; },
    deleteMessagesOlderThan: async (_id, id, cutoff, opts) => ({ chatId: id, cutoff, deleted: 2, failed: 0, everyone: opts.everyone }),
  };

  // Quiet hours apply consistently to message-triggered automation rules.
  session = makeSession();
  session.settings.interactionQuietEnabled = true;
  session.settings.interactionQuietStart = '00:00';
  session.settings.interactionQuietEnd = '23:59';
  session.settings.timezone = 'UTC';
  session.settings.interactionQuietAction = 'silence';
  const quietStore = { loadSession: () => session, saveSession: s => { session = s; return s; } };
  const quietEngine = new AutomationEngine({ store: quietStore, whatsapp });
  const quietResult = await quietEngine.handleMessage('test', message('96890001111@c.us', 'quiet-silence', 'مرحبا'));
  assert.equal(quietResult.reason, 'quiet-hours');
  assert.equal(session.automation.eventState.totalMessages, 0, 'silence hours must stop automated replies and counting before rule evaluation');
  session.settings.interactionQuietAction = 'rules';
  const rulesEngine = new AutomationEngine({ store: quietStore, whatsapp });
  const rulesResult = await rulesEngine.handleMessage('test', message('96890001111@c.us', 'quiet-rules', 'مرحبا'));
  assert.equal(rulesResult.reason, undefined, 'rules-only mode allows explicitly configured automation rules');
  assert.equal(session.automation.eventState.totalMessages, 1);

  session = makeSession();
  const engine = new AutomationEngine({ store, whatsapp });
  session.automation.rules.push(deleteRule);
  const r = await engine.handleMessage('test', message('96890001111@c.us', 'one', 'رسالة مرحبا'));
  assert.equal(r.handled, true);
  assert.equal(executed.deleted, 1);
  assert.equal(session.automation.eventState.totalMessages, 1);

  session = makeSession();
  const counter = normalizeAutomationRule({ name: 'threshold', triggerType: 'message-count', action: 'archive-chat', threshold: 2, countScope: 'chat', targetMode: 'current' }, session);
  session.automation.rules.push(counter);
  const engine2 = new AutomationEngine({ store, whatsapp });
  const one = await engine2.handleMessage('test', message('96890002222@c.us', 'two', 'hello'));
  const two = await engine2.handleMessage('test', message('96890002222@c.us', 'three', 'hello'));
  assert.equal(one.handled, false);
  assert.equal(two.handled, true);
  assert.deepEqual(executed.chatActions.at(-1), ['96890002222@c.us', 'archive']);

  session = makeSession();
  const groupPermissionRule = normalizeAutomationRule({ name: 'blocked group delete', triggerType: 'group-message', action: 'delete-message', pattern: 'مرحبا', matchMode: 'contains', targetMode: 'current', confirmDestructive: true }, session);
  session.automation.rules.push(groupPermissionRule);
  const engine3 = new AutomationEngine({ store, whatsapp });
  const previousDeleted = executed.deleted;
  await engine3.handleMessage('test', message('120363000000@g.us', 'four', 'مرحبا'));
  assert.equal(executed.deleted, previousDeleted, 'group destructive action should be blocked unless owner enables group delete permission');

  // Duplicate event protection survives creating a fresh engine instance (simulated process restart).
  session = makeSession();
  const restartStore = { loadSession: () => session, saveSession: s => { session = s; return s; } };
  const restartEngine1 = new AutomationEngine({ store: restartStore, whatsapp });
  const repeatedEvent = message('96890007777@c.us', 'persisted-id', 'hello');
  await restartEngine1.handleMessage('test', repeatedEvent);
  assert.equal(session.automation.eventState.totalMessages, 1);
  const restartEngine2 = new AutomationEngine({ store: restartStore, whatsapp });
  const replayed = await restartEngine2.handleMessage('test', repeatedEvent);
  assert.equal(replayed.reason, 'duplicate');
  assert.equal(session.automation.eventState.totalMessages, 1, 'duplicate message after restart must not increment persisted counters');

  // Failed threshold action does not consume the threshold or start its cooldown.
  session = makeSession();
  let archiveAttempts = 0;
  const retryWhatsapp = { ...whatsapp, actOnChat: async (_id, chatId, action) => {
    archiveAttempts++; if (archiveAttempts === 1) throw new Error('temporary transport failure');
    return { chatId, action };
  } };
  const retryRule = normalizeAutomationRule({ id: 'retry-threshold', name: 'retry threshold', triggerType: 'message-count', action: 'archive-chat', threshold: 2, countScope: 'chat', targetMode: 'current', cooldownSec: 60 }, session);
  session.automation.rules.push(retryRule);
  const retryEngine = new AutomationEngine({ store: restartStore, whatsapp: retryWhatsapp });
  await retryEngine.handleMessage('test', message('96890008888@c.us', 'retry-a', 'hello'));
  const failedThreshold = await retryEngine.handleMessage('test', message('96890008888@c.us', 'retry-b', 'hello'));
  assert.equal(failedThreshold.executed[0].result.ok, false);
  assert.equal(session.automation.eventState.ruleCounts['retry-threshold|96890008888@c.us'], undefined, 'failed action must not consume threshold');
  const retriedThreshold = await retryEngine.handleMessage('test', message('96890008888@c.us', 'retry-c', 'hello'));
  assert.equal(retriedThreshold.executed[0].result.ok, true);
  assert.equal(archiveAttempts, 2, 'failed rule should retry once without waiting for cooldown');
  assert.equal(session.automation.eventState.ruleCounts['retry-threshold|96890008888@c.us'], 1);

  // A scheduled "delete-message" rule must never fall through to bulk age-based deletion.
  session = makeSession();
  let bulkDeletes = 0;
  const safetyWhatsapp = { ...whatsapp, deleteMessagesOlderThan: async () => { bulkDeletes++; return { deleted: 10 }; } };
  const safetyEngine = new AutomationEngine({ store: restartStore, whatsapp: safetyWhatsapp });
  await assert.rejects(() => safetyEngine.executeRule('test', { id: 'delete-one', name: 'delete one', action: 'delete-message', targetMode: 'all', confirmDestructive: true, ageHours: 24 }, { event: 'scheduled' }), /رسالة محددة/);
  assert.equal(bulkDeletes, 0, 'single-message deletion cannot invoke bulk deletion');

  console.log('PASS automation safety, persistent deduplication, retryable thresholds, calendar validation, regex limits, scheduler, mutes, group permissions and message counters');
})().catch(error => { console.error(error); process.exitCode = 1; });
