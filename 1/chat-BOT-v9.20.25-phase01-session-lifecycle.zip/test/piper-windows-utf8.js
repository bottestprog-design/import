'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { EventEmitter } = require('node:events');
const { TextToSpeech } = require('../src/text-to-speech');

(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-piper-utf8-'));
  try {
    const scripts = path.join(root, 'scripts');
    fs.mkdirSync(scripts);
    fs.writeFileSync(path.join(scripts, 'voice_worker.py'), '# worker stub');
    const piper = path.join(root, 'piper.exe');
    const model = path.join(root, 'arabic.onnx');
    const ffmpeg = path.join(root, 'ffmpeg.exe');
    fs.writeFileSync(piper, 'mock piper');
    fs.writeFileSync(ffmpeg, 'mock ffmpeg');
    const fd = fs.openSync(model, 'w');
    fs.ftruncateSync(fd, 10 * 1024 * 1024 + 1);
    fs.closeSync(fd);

    let spawnOptions = null;
    const spawnImpl = (binary, args, options) => {
      assert.equal(binary, piper);
      spawnOptions = options;
      const child = new EventEmitter();
      child.stderr = new EventEmitter();
      child.stdin = new EventEmitter();
      child.kill = () => {};
      child.stdin.end = input => {
        assert.match(String(input), /مرحبا/u);
        const output = args[args.indexOf('--output_file') + 1];
        fs.writeFileSync(output, Buffer.alloc(512, 1));
        setImmediate(() => child.emit('close', 0));
      };
      return child;
    };
    const tts = new TextToSpeech({
      root,
      tempRoot: root,
      env: {
        PIPER_BIN: piper,
        PIPER_MODEL_PATH: model,
        FFMPEG_BIN: ffmpeg,
        TTS_BACKEND: 'local',
        TTS_TIMEOUT_MS: '5000',
        // Deliberately hostile values must not override the enforced UTF-8 settings.
        PYTHONUTF8: '0',
        PYTHONIOENCODING: 'ascii',
      },
      spawnImpl,
    });
    const generated = await tts.generate('مرحبا هذا اختبار صوت عربي', { backend: 'local', proofread: false });
    assert.equal(spawnOptions.env.PYTHONUTF8, '1');
    assert.equal(spawnOptions.env.PYTHONIOENCODING, 'utf-8');
    assert.ok(fs.statSync(generated.wavPath).size >= 128);
    assert.equal(tts.cleanup(generated), true);
    console.log('piper-windows-utf8: ok (Arabic stdin, UTF-8 override, local Piper spawn, cleanup)');
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
