'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { probeDirectory } = require('../src/diagnostics-probes');

function memoryFs({ readMode = 'ok', unlinkFails = false, chunkSize = Infinity, writeBlocked = false } = {}) {
  const files = new Map();
  const handles = new Map();
  let nextFd = 10;
  return {
    statSync: () => ({ isDirectory: () => true }),
    readdirSync: () => [],
    openSync(filename, mode) {
      if (mode === 'wx' && writeBlocked) throw new Error('synthetic write denied');
      if (mode === 'wx') files.set(filename, Buffer.alloc(0));
      if (mode === 'r' && !files.has(filename)) throw new Error('missing probe');
      const fd = nextFd++;
      handles.set(fd, { filename, mode });
      return fd;
    },
    writeSync(fd, buffer, offset, length, position) {
      const handle = handles.get(fd);
      const amount = Math.min(length, chunkSize);
      const existing = files.get(handle.filename) || Buffer.alloc(0);
      const bytes = Buffer.from(buffer.subarray(offset, offset + amount));
      const next = Buffer.alloc(Math.max(existing.length, position + amount));
      existing.copy(next, 0, 0, Math.min(existing.length, position));
      bytes.copy(next, position);
      if (position + amount < existing.length) existing.copy(next, position + amount, position + amount);
      files.set(handle.filename, next);
      return amount;
    },
    readSync(fd, buffer, offset, length, position) {
      if (readMode === 'denied') throw new Error('synthetic read denied');
      const handle = handles.get(fd);
      const stored = Buffer.from(files.get(handle.filename));
      if (readMode === 'mismatch' && stored.length) stored[0] ^= 0xff;
      const chunk = stored.subarray(position, position + Math.min(length, chunkSize));
      chunk.copy(buffer, offset);
      return chunk.length;
    },
    closeSync(fd) { handles.delete(fd); },
    unlinkSync(filename) {
      if (unlinkFails) throw new Error('synthetic cleanup failure');
      files.delete(filename);
    },
    files,
  };
}

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-diagnostics-probe-'));
try {
  const healthy = probeDirectory(root);
  assert.deepEqual(healthy, { exists: true, isDirectory: true, readable: true, writable: true });
  assert.deepEqual(fs.readdirSync(root), [], 'the temporary probe file must always be removed');

  const missing = probeDirectory(path.join(root, 'missing-folder'));
  assert.deepEqual(missing, { exists: false, isDirectory: false, readable: false, writable: false });

  const filePath = path.join(root, 'not-a-directory');
  fs.writeFileSync(filePath, 'x');
  const notDirectory = probeDirectory(filePath);
  assert.deepEqual(notDirectory, { exists: false, isDirectory: false, readable: false, writable: false });

  const blockedWrite = probeDirectory('/synthetic-directory', {
    statSync: () => ({ isDirectory: () => true }),
    readdirSync: () => [],
    openSync: () => { throw new Error('synthetic EACCES'); },
  });
  assert.deepEqual(blockedWrite, { exists: true, isDirectory: true, readable: true, writable: false });

  const readDeniedFs = memoryFs({ readMode: 'denied' });
  const readDenied = probeDirectory('/synthetic-directory', readDeniedFs);
  assert.deepEqual(readDenied, { exists: true, isDirectory: true, readable: false, writable: true }, 'read-back denial must be reported without misclassifying a successful write');
  assert.equal(readDeniedFs.files.size, 0, 'the probe file must be removed after read failure');

  const mismatchFs = memoryFs({ readMode: 'mismatch' });
  const mismatch = probeDirectory('/synthetic-directory', mismatchFs);
  assert.deepEqual(mismatch, { exists: true, isDirectory: true, readable: false, writable: true }, 'read-back bytes must match the written payload exactly');
  assert.equal(mismatchFs.files.size, 0, 'the mismatched probe file must be removed');

  const chunkedFs = memoryFs({ chunkSize: 5 });
  assert.deepEqual(probeDirectory('/synthetic-directory', chunkedFs), { exists: true, isDirectory: true, readable: true, writable: true }, 'partial read/write operations must be completed with bounded loops');
  assert.equal(chunkedFs.files.size, 0);

  const incompleteWriteFs = memoryFs({ chunkSize: 0 });
  assert.deepEqual(probeDirectory('/synthetic-directory', incompleteWriteFs), { exists: true, isDirectory: true, readable: true, writable: false }, 'zero-byte writes must fail closed');
  assert.equal(incompleteWriteFs.files.size, 0);

  const cleanupFs = memoryFs({ unlinkFails: true });
  const cleanupFailure = probeDirectory('/synthetic-directory', cleanupFs);
  assert.deepEqual(cleanupFailure, { exists: true, isDirectory: true, readable: true, writable: false }, 'a probe is not successful unless its temporary file is cleaned up');
  assert.equal(cleanupFs.files.size, 1, 'the simulated cleanup failure remains detectable');

  console.log('diagnostics-probes: ok (real read/write/read-back/delete, missing path, non-directory, write/read denial, partial IO, content mismatch and cleanup failure)');
} finally {
  fs.rmSync(root, { recursive: true, force: true });
}
