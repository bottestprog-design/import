'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
assert.ok(fs.existsSync(path.join(root, 'RELEASES_AR.md')), 'the detailed release notes must ship with the project');
assert.ok(fs.existsSync(path.join(root, 'REPORT_REMAINING_WORK_AR.md')), 'the remaining-work audit must ship with the project');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const app = read('public/app.js');
const server = read('server.js');
const wa = read('src/whatsapp.js');
const lock = read('src/process-lock.js');

const connectionSelectStart = app.indexOf('id="connectionMethod"');
const connectionSelectEnd = app.indexOf('</select>', connectionSelectStart);
const connectionSelect = connectionSelectStart >= 0 && connectionSelectEnd > connectionSelectStart ? app.slice(connectionSelectStart, connectionSelectEnd) : '';
for (const [label, ok] of [
  ['connection choices are simplified to QR by default and phone code as an explicit alternative', /connectionMethod: 'qr'/.test(app) && /option value="qr"/.test(connectionSelect) && /option value="phone"/.test(connectionSelect) && !/option value="auto"/.test(connectionSelect)],
  ['real QR option available', /option value="qr"/.test(app)],
  ['phone pairing option available', /option value="phone"/.test(app)],
  ['phone number sent to connect API', /phoneNumber: state\.connectionPhoneNumber/.test(app)],
  ['pairing code displayed only from actual runtime code', /runtime\.pairingCode/.test(app) && /client\.on\('code'/.test(wa)],
  ['QR generated from real client event', /client\.on\('qr'/.test(wa) && /QRCode\.toDataURL\(qr\.trim\(\)/.test(wa)],
  ['official pairing option passed to whatsapp-web.js', /pairWithPhoneNumber = \{ phoneNumber: requestedPhone, showNotification: true, intervalMs: 180000 \}/.test(wa)],
  ['profile conflicts translated to actionable message', /BROWSER_PROFILE_IN_USE/.test(wa) && /browserProfileConflictError/.test(wa)],
  ['single server lock is acquired before application setup', /acquireProcessLock\(path\.join\(__dirname, '\.runtime', 'server\.lock'\)\)/.test(server)],
  ['lock is exclusive, stale PID recovery implemented', /fs\.openSync\(file, 'wx'/.test(lock) && /pidIsAlive/.test(lock)],
  ['user-selected unlink is the only path passing clearAuth', /app\.post\('\/api\/session\/unlink'[\s\S]*?clearAuth: true/.test(server)],
  ['release log contains full current review', /version: 'v9\.9\.8'/.test(app) && /REPORT_REMAINING_WORK_AR\.md/.test(app)],
]) {
  console.log(`${ok ? 'OK' : 'FAIL'} ${label}`);
  assert.ok(ok, label);
}
console.log('whatsapp-pairing-ui: ok (all connection choices wired to backend; real events only)');
