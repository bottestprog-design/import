'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { acquireSessionProcessLock, readLock, isPidAlive, canRecoverLock } = require('../src/session-process-lock');

function waitForChildLine(child, expected, timeoutMs = 5000) {
  return new Promise((resolve, reject) => {
    let buffer = '';
    const timer = setTimeout(() => finish(new Error(`child did not emit ${expected}`)), timeoutMs);
    const onData = chunk => {
      buffer += chunk.toString('utf8');
      if (buffer.includes(expected)) finish(null);
    };
    const onError = error => finish(error);
    const onExit = (code, signal) => finish(new Error(`child exited before readiness (${code ?? signal})`));
    function finish(error) {
      clearTimeout(timer);
      child.stdout.off('data', onData);
      child.off('error', onError);
      child.off('exit', onExit);
      if (error) reject(error); else resolve();
    }
    child.stdout.on('data', onData);
    child.once('error', onError);
    child.once('exit', onExit);
  });
}

function waitForExit(child, timeoutMs = 5000) {
  if (child.exitCode !== null || child.signalCode !== null) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { child.kill(); reject(new Error('child process did not exit after lock release test')); }, timeoutMs);
    child.once('exit', () => { clearTimeout(timer); resolve(); });
  });
}

(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-session-lock-'));
  try {
    const lockPath = path.join(root, 'runtime', 'whatsapp-session.lock');
    const first = acquireSessionProcessLock(lockPath, { sessionId: 'main' });
    assert.ok(fs.existsSync(lockPath));
    const initial = readLock(lockPath);
    assert.equal(initial.pid, process.pid);
    assert.equal(initial.sessionId, 'main');
    assert.equal(initial.token, first.token);
    assert.throws(() => acquireSessionProcessLock(lockPath, { sessionId: 'main' }), error => error.code === 'WHATSAPP_SESSION_PROCESS_LOCKED');
    assert.equal(first.update({ browserPid: process.pid }), true);
    assert.equal(readLock(lockPath).browserPid, process.pid);
    assert.equal(first.release(), true);
    assert.equal(fs.existsSync(lockPath), false);
    assert.equal(first.release(), false, 'a released lock cannot be released twice');

    // Cross-process contention: a second Node process must not open the same profile.
    const modulePath = path.resolve(__dirname, '../src/session-process-lock.js');
    const childCode = `const {acquireSessionProcessLock}=require(${JSON.stringify(modulePath)});acquireSessionProcessLock(${JSON.stringify(lockPath)},{sessionId:'main'});process.stdout.write('LOCKED\\n');setInterval(()=>{},1000);`;
    const child = spawn(process.execPath, ['-e', childCode], { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
    try {
      await waitForChildLine(child, 'LOCKED');
      assert.equal(readLock(lockPath).pid, child.pid);
      assert.throws(() => acquireSessionProcessLock(lockPath, { sessionId: 'main' }), error => error.code === 'WHATSAPP_SESSION_PROCESS_LOCKED');
    } finally {
      if (child.exitCode === null && child.signalCode === null) child.kill();
      await waitForExit(child);
    }
    const afterChildExit = acquireSessionProcessLock(lockPath, { sessionId: 'main' });
    assert.equal(afterChildExit.release(), true, 'a dead cross-process lock owner may be recovered');

    // Concurrent recovery attempts must not rename/replace a new owner's lock file.
    fs.writeFileSync(lockPath, JSON.stringify({ version: 1, token: 'stale-race', pid: 2147483000, browserPid: null, sessionId: 'main' }));
    const racers = Array.from({ length: 5 }, () => spawn(process.execPath, ['-e',
      `const {acquireSessionProcessLock}=require(${JSON.stringify(modulePath)});try{const l=acquireSessionProcessLock(${JSON.stringify(lockPath)},{sessionId:'race'});process.stdout.write('OWNER'+String.fromCharCode(10));setTimeout(()=>{l.release();process.exit(0)},500)}catch(e){process.stdout.write('BLOCKED:'+e.code+String.fromCharCode(10))}`
    ], { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true }));
    const racerResults = await Promise.all(racers.map(child => new Promise((resolve, reject) => {
      let output = '';
      const timer = setTimeout(() => reject(new Error('stale lock recovery racer did not report a result')), 5000);
      child.stdout.on('data', chunk => {
        output += chunk.toString('utf8');
        if (output.includes('OWNER') || output.includes('BLOCKED:')) { clearTimeout(timer); resolve({ child, output }); }
      });
      child.once('error', error => { clearTimeout(timer); reject(error); });
    })));
    assert.equal(racerResults.filter(item => item.output.includes('OWNER')).length, 1, 'only one process may own the recovered LocalAuth lock');
    const raceOwner = readLock(lockPath);
    assert.ok(raceOwner && racerResults.some(item => item.child.pid === raceOwner.pid), 'the lock path must continue to point to the winning process');
    await Promise.all(racers.map(child => waitForExit(child)));
    assert.equal(fs.existsSync(`${lockPath}.recovery`), false, 'normal recovery must remove its temporary gate');

    // If a process is interrupted inside recovery, fail closed instead of guessing
    // whether it is safe to remove the recovery gate automatically.
    fs.writeFileSync(lockPath, JSON.stringify({ version: 1, token: 'stale-with-gate', pid: 2147483000, sessionId: 'main' }));
    fs.mkdirSync(`${lockPath}.recovery`, { recursive: true });
    fs.writeFileSync(path.join(`${lockPath}.recovery`, 'owner.json'), JSON.stringify({ pid: 2147483002, token: 'interrupted-recovery' }));
    assert.throws(() => acquireSessionProcessLock(lockPath, { sessionId: 'main' }), error => error.code === 'WHATSAPP_SESSION_RECOVERY_LOCKED');
    assert.equal(readLock(lockPath).token, 'stale-with-gate', 'interrupted recovery must not mutate the underlying LocalAuth lock');
    fs.rmSync(`${lockPath}.recovery`, { recursive: true, force: true });

    // A partially written young lock may belong to a process between wx-open and write.
    fs.writeFileSync(lockPath, '{');
    assert.equal(canRecoverLock(lockPath, null), false, 'a young unreadable lock must not be stolen');
    assert.throws(() => acquireSessionProcessLock(lockPath, { sessionId: 'main' }), error => error.code === 'WHATSAPP_SESSION_PROCESS_LOCKED');
    const old = new Date(Date.now() - 20000); fs.utimesSync(lockPath, old, old);
    assert.equal(canRecoverLock(lockPath, null), true, 'an old unreadable lock can be recovered after the grace period');

    // A dead Node + browser owner leaves a stale file; the next start may recover it.
    fs.writeFileSync(lockPath, JSON.stringify({ version: 1, token: 'stale', pid: 2147483000, browserPid: 2147482999, sessionId: 'main' }));
    assert.equal(isPidAlive(2147483000), false);
    const recovered = acquireSessionProcessLock(lockPath, { sessionId: 'main' });
    assert.notEqual(readLock(lockPath).token, 'stale');
    assert.equal(recovered.release(), true);

    // EPERM means the process exists but is inaccessible, so it must not be treated as stale.
    const originalKill = process.kill;
    process.kill = (pid, signal) => { if (Number(pid) === 2147483001 && signal === 0) throw Object.assign(new Error('denied'), { code: 'EPERM' }); return originalKill(pid, signal); };
    try {
      fs.writeFileSync(lockPath, JSON.stringify({ version: 1, token: 'protected', pid: 2147483001, sessionId: 'main' }));
      assert.throws(() => acquireSessionProcessLock(lockPath, { sessionId: 'main' }), error => error.code === 'WHATSAPP_SESSION_PROCESS_LOCKED');
    } finally { process.kill = originalKill; }
    console.log('session-process-lock: ok (exclusive ownership, cross-process contention, browser PID tracking, stale recovery, corrupt-lock grace, EPERM safety, idempotent release)');
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
