'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const media = require('../src/media');
const { normalizeAutomationTask } = require('../src/store');
const { DeliveryService } = require('../src/delivery');

(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-media-options-'));
  try {
    for (const name of ['share.webm', 'voice.opus', 'clip.aac', 'mix.flac', 'clip.mov', 'archive.heic']) fs.writeFileSync(path.join(dir, name), 'mock');
    const scan = media.scan(dir);
    const map = Object.fromEntries(scan.files.map(item => [item.filename, item]));
    assert.equal(map['share.webm'].isVideo, true);
    assert.equal(map['share.webm'].mediaKind, 'media');
    assert.equal(map['voice.opus'].isAudio, true);
    assert.equal(map['clip.aac'].isAudio, true);
    assert.equal(map['mix.flac'].isAudio, true);
    assert.ok(media.MEDIA_EXT.has('.mov') && media.MEDIA_EXT.has('.heic'), 'less common WhatsApp formats must remain downloadable instead of silently becoming .bin');
    assert.equal(map['clip.mov'].isVideo, true, 'recognized video extensions are classified as video for WhatsApp delivery');
    assert.equal(map['clip.mov'].mediaKind, 'media', 'video files should use the media delivery path even when the browser only offers a download link');
    for (const ext of ['.avi', '.3gp', '.m4v', '.mpeg', '.mpg']) assert.ok(media.VIDEO_EXT.has(ext), `${ext} should be recognized as a video file`);
    assert.equal(map['archive.heic'].mediaKind, 'document');
    assert.equal(media.MIME['.webm'], 'video/webm');
    assert.equal(media.MIME['.opus'], 'audio/opus');

    const normalized = normalizeAutomationTask({ id: 'task-media', targetKeys: ['r:p1'], mediaIds: ['image.jpg'], deliveryMediaMode: 'document', captionWithMedia: true });
    assert.equal(normalized.deliveryMediaMode, 'document', 'scheduled media mode must survive persistence');
    assert.equal(normalized.captionWithMedia, true, 'caption option must survive persistence');
    const stickerNormalized = normalizeAutomationTask({ id: 'task-sticker', targetKeys: ['r:p1'], mediaIds: ['sticker.webp'], deliveryMediaMode: 'sticker' });
    assert.equal(stickerNormalized.deliveryMediaMode, 'sticker', 'sticker delivery mode must survive persistence');

    const saved = { id: 'main', recipients: [], groups: [], settings: {}, automation: { tasks: [] }, cycle: { round: 1, currentIndex: 0, imageOrder: [], delivery: {}, manualGuard: {} }, stats: {} };
    const store = { safeSessionId: value => String(value || 'main'), loadSession: () => saved, getPaths: () => ({ dir, media: dir, images: dir }) };
    const service = new DeliveryService({ store, whatsapp: {}, log: () => {} });
    let captured = null;
    service.sendNow = async (_id, options) => { captured = options; return { ok: true, sent: [], failed: [] }; };
    await service.scheduledTaskRun('main', { id: 'task-media', targetKeys: ['r:p1'], mediaIds: ['image.jpg'], mediaMode: 'selected', deliveryMediaMode: 'document', captionWithMedia: true, preText: 'تعليق', postText: '' });
    assert.equal(captured.mediaMode, 'document');
    assert.equal(captured.captionWithMedia, true);
    console.log('media-options: ok (audio/video type detection, MIME types, and persisted scheduled delivery controls including sticker mode)');
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
})().catch(error => { console.error(error); process.exitCode = 1; });
