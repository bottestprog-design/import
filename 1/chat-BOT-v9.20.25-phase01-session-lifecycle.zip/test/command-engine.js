'use strict';
const assert = require('node:assert/strict');
const { CommandEngine, tokenizeArgs, MAX_COMMAND_LENGTH } = require('../src/command-engine');

(async () => {
  assert.deepEqual(tokenizeArgs('one "two words" \'three words\' ""'), { args: ['one', 'two words', 'three words', ''], error: '' });
  assert.equal(tokenizeArgs('"unfinished').error, 'unclosed-quote');
  assert.equal(tokenizeArgs("'unfinished").error, 'unclosed-quote');

  let calls = 0;
  const audited = [];
  const engine = new CommandEngine({ prefixes: ['/', '/!'], audit: event => audited.push(event) });
  engine.register('send', { ownerOnly: false, handler: ({ args }) => { calls++; return args; } });
  const parsed = engine.parse('/!send "hello world" \'second part\'');
  assert.equal(parsed.prefix, '/!');
  assert.deepEqual(parsed.args, ['hello world', 'second part']);
  const result = await engine.execute('/!send "hello world" \'second part\'');
  assert.deepEqual(result, { handled: true, ok: true, result: ['hello world', 'second part'] });
  assert.equal(calls, 1);

  const malformed = await engine.execute('/!send "unfinished');
  assert.equal(malformed.handled, true); assert.equal(malformed.ok, false); assert.equal(malformed.error, 'invalid-arguments');
  assert.equal(calls, 1, 'malformed quoted arguments must not reach the handler');

  engine.register('schema', { ownerOnly: false, schema: () => { throw new Error('schema exploded'); }, handler: () => { calls++; } });
  const schemaFailure = await engine.execute('/!schema');
  assert.equal(schemaFailure.ok, false); assert.equal(schemaFailure.error, 'schema exploded');
  assert.equal(calls, 1, 'schema exception must not call command handler');

  const safeWithBrokenAudit = new CommandEngine({ ownerOnlyByDefault: false, audit: () => { throw new Error('audit store offline'); } });
  safeWithBrokenAudit.register('hello', { handler: () => 'completed' });
  const safeResult = await safeWithBrokenAudit.execute('!hello');
  assert.deepEqual(safeResult, { handled: true, ok: true, result: 'completed' }, 'audit failure must not invalidate or rerun a successful command');

  const owner = new CommandEngine();
  owner.register('danger', { handler: () => 'not reached' });
  const denied = await owner.execute('!danger', { isOwner: false, actorId: 'test' });
  assert.equal(denied.error, 'owner-only');
  assert.ok(audited.some(e => e.command === 'send' && e.ok === true));
  assert.ok(audited.some(e => e.command === 'send' && e.error === 'invalid-arguments'));
  assert.equal(engine.parse('!send ' + 'x'.repeat(MAX_COMMAND_LENGTH + 1)), null, 'oversized command input should be rejected before parsing');
  console.log('PASS command parsing, quoted arguments, malformed input, async-safe schema failures, owner gates, and audit isolation');
})().catch(error => { console.error(error); process.exitCode = 1; });
