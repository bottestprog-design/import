'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');
const { spawn } = require('node:child_process');

function availablePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      server.close(error => error ? reject(error) : resolve(port));
    });
  });
}
async function waitForHealth(base, child) {
  const deadline = Date.now() + 15000;
  let lastError;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error(`test server exited before readiness (${child.exitCode})`);
    try {
      const response = await fetch(`${base}/api/health`, { signal: AbortSignal.timeout(1000) });
      if (response.ok) return response.json();
    } catch (error) { lastError = error; }
    await new Promise(resolve => setTimeout(resolve, 150));
  }
  throw new Error(`test server did not become healthy: ${lastError?.message || 'timeout'}`);
}
async function stop(child) {
  if (!child || child.exitCode !== null) return;
  child.kill('SIGTERM');
  await Promise.race([
    new Promise(resolve => child.once('exit', resolve)),
    new Promise(resolve => setTimeout(() => { if (child.exitCode === null) child.kill('SIGKILL'); resolve(); }, 5000)),
  ]);
}
(async () => {
  const source = path.resolve(__dirname, '..');
  try { require.resolve('express', { paths: [source] }); }
  catch { console.log('SKIP settings-endpoint-integration: express/npm dependencies are not installed in this test environment'); return; }
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-settings-http-'));
  let child;
  try {
    fs.cpSync(source, temp, { recursive: true, filter: item => {
      const rel = path.relative(source, item);
      if (!rel) return true;
      const first = rel.split(path.sep)[0];
      if (['node_modules', 'data', '.runtime', '.git', '.env'].includes(first)) return false;
      return !rel.endsWith('.log') && !rel.endsWith('.zip');
    }});
    fs.symlinkSync(path.join(source, 'node_modules'), path.join(temp, 'node_modules'), process.platform === 'win32' ? 'junction' : 'dir');
    const port = await availablePort();
    const base = `http://127.0.0.1:${port}`;
    child = spawn(process.execPath, ['server.js'], {
      cwd: temp,
      env: { ...process.env, HOST: '127.0.0.1', PORT: String(port), OLLAMA_HOST: 'http://127.0.0.1:11439', WHISPER_CPP_BIN: 'chatbot-missing-whisper-binary', WHISPER_MODEL_PATH: path.join(temp, 'missing-whisper-model.ggml') },
      stdio: 'ignore',
    });
    const health = await waitForHealth(base, child);
    assert.equal(health.ok, true);
    assert.equal(health.version, require('../package.json').version);
    assert.equal(health.service, 'running');
    assert.ok(health.components && health.components.whatsapp && health.components.voice, 'health must report subsystems independently');
    assert.equal(typeof health.components.whatsapp.ready, 'boolean');
    assert.equal(typeof health.components.voice.ready, 'boolean');
    assert.equal(Object.hasOwn(health.components.whatsapp, 'qr'), false, 'health must never expose QR contents');
    assert.equal(Object.hasOwn(health.components.whatsapp, 'pairingCode'), false, 'health must never expose pairing codes');

    const saved = await fetch(`${base}/api/settings`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ sessionId: 'main', interactionQuietEnabled: true, interactionQuietStart: '22:30', interactionQuietEnd: '07:30', smartReplyEnabled: true, smartReplyModel: 'qwen2.5:3b', voiceAutoTranscribeEnabled: true, ttsCloudConsent: true }) });
    assert.equal(saved.status, 200, 'settings endpoint should accept valid settings even if optional engines are absent');
    const result = await saved.json();
    assert.equal(result.ok, true);
    assert.equal(result.runtime.smartReplyEnabled, false, 'the API should not claim local AI is active when the service is unavailable');
    assert.ok(result.warnings.length >= 2, 'the API should report missing Ollama and Whisper dependencies');

    const stateResponse = await fetch(`${base}/api/state?sessionId=main`);
    assert.equal(stateResponse.status, 200);
    const state = await stateResponse.json();
    assert.equal(state.settings.interactionQuietEnabled, true);
    assert.equal(state.settings.interactionQuietStart, '22:30');
    assert.equal(state.settings.smartReplyEnabled, false);
    assert.equal(state.settings.voiceAutoTranscribeEnabled, true, 'voice remains an explicit preference with a dependency warning');
    assert.equal(state.settings.ttsBackend, 'local', 'new settings must retain local TTS as the safe default');
    assert.equal(state.settings.ttsCloudConsent, true, 'explicit cloud consent must persist in this session');
    const revoked = await fetch(`${base}/api/settings`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ sessionId: 'main', ttsCloudConsent: false }) });
    assert.equal(revoked.status, 200);
    const revokedState = await (await fetch(`${base}/api/state?sessionId=main`)).json();
    assert.equal(revokedState.settings.ttsCloudConsent, false, 'cloud consent must be revocable and persisted as off');

    const disabled = await fetch(`${base}/api/settings`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ sessionId: 'main', interactionEnabled: false }) });
    assert.equal(disabled.status, 200);
    const stateAfterDisable = await (await fetch(`${base}/api/state?sessionId=main`)).json();
    assert.equal(stateAfterDisable.settings.interactionEnabled, false);
    assert.equal(stateAfterDisable.interaction.enabled, false, 'runtime and UI interaction switches should stay synchronized');
    console.log('settings-endpoint-integration: ok (real local HTTP startup, settings persistence, per-session cloud TTS consent/revocation, honest Ollama/Whisper warnings, interaction toggle synchronization)');
  } finally {
    await stop(child);
    try { fs.rmSync(temp, { recursive: true, force: true }); } catch {}
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
