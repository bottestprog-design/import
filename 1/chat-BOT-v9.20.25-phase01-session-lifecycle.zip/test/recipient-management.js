'use strict';
const assert = require('node:assert/strict');
const { deleteRecipients } = require('../src/recipient-management');

const session = {
  recipients: [
    { id: 'a', name: 'أحمد', digits: '96890000000' },
    { id: 'b', name: 'سارة', e164: '+96891111111' },
    { id: 'c', name: 'مريم', digits: '96892222222' },
  ],
  settings: { scheduleTargetKeys: ['r:a', 'r:b', 'r:c', 'g:g1'], interactionChatIds: ['96890000000@c.us', '96891111111@c.us', 'external@c.us'] },
  automation: {
    tasks: [{ id: 'task', targetKeys: ['r:a', 'r:b', 'g:g1'] }, { id: 'task-empty', targetKeys: ['r:c'] }],
    rules: [{ id: 'rule', targetKeys: ['r:a', 'r:c', 'g:g1'], targetChatIds: ['96890000000@c.us', 'external@c.us'] }],
  },
  interaction: { contextByChat: { '96890000000@c.us': { count: 1 }, 'external@c.us': { count: 2 } }, counterState: { byChat: { '96891111111@c.us': { count: 1 } }, fired: { '96890000000@c.us': { t: 1 }, session: { retained: true } }, pending: { '96890000000@c.us': { t: 1 } } } },
};
const result = deleteRecipients(session, ['a', 'b', 'a', 'not-there']);
assert.deepEqual(result.removedIds.sort(), ['a', 'b']);
assert.deepEqual(session.recipients.map(x => x.id), ['c']);
assert.deepEqual(session.settings.scheduleTargetKeys, ['r:c', 'g:g1']);
assert.deepEqual(session.settings.interactionChatIds, ['external@c.us']);
assert.deepEqual(session.automation.tasks.map(x => x.targetKeys), [['g:g1'], ['r:c']]);
assert.deepEqual(session.automation.rules[0].targetKeys, ['r:c', 'g:g1']);
assert.deepEqual(session.automation.rules[0].targetChatIds, ['external@c.us']);
assert.equal(session.interaction.contextByChat['96890000000@c.us'], undefined);
assert.equal(session.interaction.counterState.byChat['96891111111@c.us'], undefined);
assert.equal(session.interaction.counterState.fired['96890000000@c.us'], undefined);
assert.equal(session.interaction.counterState.pending['96890000000@c.us'], undefined);
assert.deepEqual(session.interaction.counterState.fired.session, { retained: true }, 'session-scoped counters must not be removed with one contact');
assert.throws(() => deleteRecipients(session, []), /حدد/);
assert.throws(() => deleteRecipients(session, ['missing']), /العثور/);
const onlyScheduledRecipient = { recipients: [{ id: 'last', phone: '96890000000' }], settings: { scheduleEnabled: true, scheduleTargetKeys: ['r:last'] }, automation: { tasks: [], rules: [] }, interaction: {} };
const lastDelete = deleteRecipients(onlyScheduledRecipient, ['last']);
assert.equal(lastDelete.scheduleDisabledToPreventWidening, true);
assert.equal(onlyScheduledRecipient.settings.scheduleEnabled, false, 'a schedule should stop rather than silently broaden to all remaining targets');
assert.deepEqual(onlyScheduledRecipient.settings.scheduleTargetKeys, []);
const lidRecipient = { recipients: [{ id: 'lid-person', name: 'جهة LID', whatsappJid: { _serialized: '123456789012345@lid' }, e164: '+96893334444', digits: '96893334444' }], settings: { interactionChatIds: ['123456789012345@lid', '96893334444@c.us'] }, automation: { tasks: [], rules: [{ id: 'lid-rule', targetChatIds: ['123456789012345@lid', '96893334444@c.us'] }] }, interaction: { contextByChat: { '123456789012345@lid': { count: 1 }, '96893334444@c.us': { count: 2 } } } };
const lidResult = deleteRecipients(lidRecipient, ['lid-person']);
assert.deepEqual(lidResult.removedIds, ['lid-person']);
assert.deepEqual(lidRecipient.settings.interactionChatIds, [], 'delete cleanup must remove the LID and separately saved phone identity without pretending LID digits are a phone number');
assert.deepEqual(lidRecipient.automation.rules[0].targetChatIds, []);
assert.equal(lidRecipient.interaction.contextByChat['123456789012345@lid'], undefined);
assert.equal(lidRecipient.interaction.contextByChat['96893334444@c.us'], undefined);
console.log('recipient-management: ok (bulk delete, duplicate ids, schedule/task/rule cleanup, numeric JID, serialized LID and LID chat-state cleanup)');
