'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {
  resolveExpressiveTuning,
  classifyExpressiveStyle,
  splitExpressiveSegments,
  CHATTERBOX_LANGUAGES,
  detectSpeechLanguage,
} = require('../src/text-to-speech');
const { ChatterboxRuntime } = require('../src/chatterbox-runtime');

const root = path.resolve(__dirname, '..');

// Context-aware styles should select distinct model conditioning, not merely
// apply one fixed rate/pitch filter to every response.
assert.equal(classifyExpressiveStyle('أنا آسف، وأفهم تمامًا شعورك.'), 'empathetic');
assert.equal(classifyExpressiveStyle('مبروك! خبر رائع فعلًا!'), 'energetic');
assert.equal(classifyExpressiveStyle('كان يا ما كان في قديم الزمان.'), 'storytelling');
assert.equal(classifyExpressiveStyle('هههه دي نكتة مضحكة.'), 'playful');
assert.equal(classifyExpressiveStyle('لماذا حدث هذا؟'), 'curious');
assert.equal(classifyExpressiveStyle('معلش، حاسس بيك ومش عايزك تقلق.'), 'empathetic');
assert.equal(classifyExpressiveStyle('خد وقتك، مفيش استعجال.'), 'calm');
assert.equal(classifyExpressiveStyle('أهلًا بيك، نورتنا.'), 'warm');
assert.equal(classifyExpressiveStyle('يرجى العلم بأنه تم استلام طلبكم.'), 'formal');

const calm = resolveExpressiveTuning({ text: 'خلينا نأخذ الأمر بهدوء.', style: 'calm', exaggeration: 0.55, cfgWeight: 0.45, temperature: 0.8 });
const excited = resolveExpressiveTuning({ text: 'مبروك! خبر رائع!', style: 'energetic', exaggeration: 0.55, cfgWeight: 0.45, temperature: 0.8 });
assert.ok(excited.exaggeration > calm.exaggeration, 'emotion presets remain different when the global slider is at neutral');
assert.ok(excited.temperature > calm.temperature);
assert.ok(resolveExpressiveTuning({ text: 'مرحبًا', exaggeration: 1.2 }).exaggeration <= 1.2);
assert.ok(resolveExpressiveTuning({ text: 'مرحبًا', exaggeration: 0.1 }).exaggeration >= 0.25);

const mixed = 'أهلًا بك. أنا سعيد جدًا بنجاحك! لكنني أتفهم قلقك، لماذا حدث ذلك؟';
const parts = splitExpressiveSegments(mixed);
assert.equal(parts.length, 3, 'each complete sentence gets its own expressive conditioning');
assert.equal(parts.join(' '), mixed, 'sentence splitting preserves the spoken text');
assert.deepEqual(splitExpressiveSegments(''), []);
assert.ok(splitExpressiveSegments('جملة طويلة '.repeat(150), { maxSegments: 8 }).length <= 8);

for (const lang of ['ar', 'en', 'fr', 'de', 'es']) assert.ok(CHATTERBOX_LANGUAGES.has(lang));
assert.equal(detectSpeechLanguage('Hola, ¿cómo estás?'), 'es');
assert.equal(detectSpeechLanguage('Bonjour, comment allez-vous?'), 'fr');
assert.equal(detectSpeechLanguage('Guten Morgen, wie geht es Ihnen?'), 'de');

const worker = fs.readFileSync(path.join(root, 'scripts/chatterbox_tts_worker.py'), 'utf8');
const bootstrap = fs.readFileSync(path.join(root, 'src/voice-bootstrap.js'), 'utf8');
const runtime = fs.readFileSync(path.join(root, 'src/chatterbox-runtime.js'), 'utf8');
const ui = fs.readFileSync(path.join(root, 'public/app.js'), 'utf8');
const requirements = fs.readFileSync(path.join(root, 'scripts/voice-tts-requirements.txt'), 'utf8');
assert.match(requirements, /chatterbox-tts @ git\+https:\/\/github\.com\/resemble-ai\/chatterbox\.git@3f35dfc8fbe63e5b29793289dc68f1875bb317a5/);
assert.match(bootstrap, /inspect\.signature\(ChatterboxMultilingualTTS\.from_local\)/, 'the installed Python package must really expose the V3 loader');
assert.match(bootstrap, /MULTILINGUAL_T3_MODELS\.get\(\"v3\"\)/);
assert.match(worker, /MODEL_REVISION = \"5bb1f6ee58e50c3b8d408bc82a6d3740c2db6e18\"/);
assert.match(worker, /revision=MODEL_REVISION/);
assert.match(worker, /\"s3gen\.pt\"/);
assert.doesNotMatch(worker, /\"s3gen_v3\.pt\"/, 'the pinned official V3 loader uses s3gen.pt');
assert.match(bootstrap, /CHATTERBOX_AUTO_DOWNLOAD/);
assert.match(bootstrap, /\.voice-tts-venv/);
assert.match(bootstrap, /ensureChatterbox\(python\)/);
assert.match(worker, /t3_mtl23ls_v3\.safetensors/);
assert.match(worker, /engine\.generate\(/);
assert.match(worker, /requested_segments/);
assert.match(runtime, /message\.ok === false && !this\.readyInfo/);
assert.match(runtime, /segments = \[\]/);
assert.match(ui, /\['ttsExaggeration','ttsExaggerationOutput'/);
assert.match(ui, /id="ttsExaggeration"/);

// Startup failures emitted by the Python worker must resolve immediately,
// rather than waiting for the 12-minute start timeout.
const instance = Object.create(ChatterboxRuntime.prototype);
let captured;
instance.readyInfo = null;
instance.pending = new Map();
instance.log = () => {};
instance.handleLine(JSON.stringify({ ok: false, error: 'model load failed' }), error => { captured = error; });
assert.ok(captured instanceof Error);
assert.match(captured.message, /model load failed/);

console.log('chatterbox-expressive-tts: ok (style modulation, sentence-level expressive splitting, multilingual routing, local bootstrap, and startup error handling)');
