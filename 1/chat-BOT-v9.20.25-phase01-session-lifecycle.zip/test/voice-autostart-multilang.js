'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const store = require('../src/store');
const { VoiceBootstrap, normalizeTtsBackend } = require('../src/voice-bootstrap');
const { TextToSpeech, detectSpeechLanguage, defaultVoiceForText } = require('../src/text-to-speech');
const { AudioTranscriber } = require('../src/audio-transcriber');
const { parseEnv } = require('../src/env-loader');

(async () => {
  const root = path.resolve(__dirname, '..');
  const manifest = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  assert.equal(manifest.version, '9.20.25');
  assert.equal(store.APP_VERSION, '9.20.25');

  // Regression: v9.18/v9.19 stored the old off/local voice defaults at schema 9.
  const legacyId = `voice-migration-${process.pid}-${Date.now()}`;
  const legacyPaths = store.ensureDir(legacyId);
  try {
    const legacy = {
      schemaVersion: 9, id: legacyId, name: 'legacy voice migration',
      settings: { ...store.clone(store.DEFAULT_SETTINGS), ttsBackend: 'local', interactionVoiceRepliesEnabled: false, voiceAutoTranscribeEnabled: true },
      recipients: [], groups: [], interaction: {}, automation: {}, logs: [], stats: {}, cycle: {}, scheduleState: {},
    };
    fs.writeFileSync(legacyPaths.json, JSON.stringify(legacy), 'utf8');
    const migrated = store.loadSession(legacyId);
    assert.equal(migrated.schemaVersion, 13);
    assert.equal(migrated.settings.ttsBackend, 'local', 'migration must preserve explicit local choice and never silently enable cloud TTS');
    assert.equal(migrated.settings.ttsCloudConsent, false, 'cloud consent must default off after migration');
    assert.equal(migrated.settings.interactionVoiceRepliesEnabled, true);
    const current = { ...migrated, settings: { ...migrated.settings, interactionVoiceRepliesEnabled: false, ttsBackend: 'local' } };
    store.saveSession(current);
    const userOptOut = store.loadSession(legacyId);
    assert.equal(userOptOut.schemaVersion, 13);
    assert.equal(userOptOut.settings.interactionVoiceRepliesEnabled, false, 'an explicit setting saved to schema 11 must be respected');
    assert.equal(userOptOut.settings.ttsBackend, 'local');
  } finally { fs.rmSync(legacyPaths.dir, { recursive: true, force: true }); }

  const unsetId = `voice-migration-unset-${process.pid}-${Date.now()}`;
  const unsetPaths = store.ensureDir(unsetId);
  try {
    const legacyWithoutBackend = { schemaVersion: 9, id: unsetId, name: 'legacy without TTS backend', settings: { automationEnabled: true }, recipients: [], groups: [], interaction: {}, automation: {}, logs: [], stats: {}, cycle: {}, scheduleState: {} };
    fs.writeFileSync(unsetPaths.json, JSON.stringify(legacyWithoutBackend), 'utf8');
    const migratedUnset = store.loadSession(unsetId);
    assert.equal(migratedUnset.settings.ttsBackend, 'local', 'legacy sessions without an explicit choice must migrate to local, not auto');
    assert.equal(migratedUnset.settings.ttsCloudConsent, false, 'legacy sessions must never acquire cloud consent during migration');
  } finally { fs.rmSync(unsetPaths.dir, { recursive: true, force: true }); }

  // Four independent language mappings for neural voice selection.
  const matrix = [
    ['ar', 'مرحبًا، كيف حالك؟', 'ar-EG-ShakirNeural'],
    ['en', 'Hello, how are you today?', 'en-US-JennyNeural'],
    ['fr', 'Bonjour, comment allez-vous?', 'fr-FR-DeniseNeural'],
    ['de', 'Guten Morgen, wie geht es Ihnen?', 'de-DE-KatjaNeural'],
  ];
  for (const [language, phrase, voice] of matrix) {
    assert.equal(detectSpeechLanguage(phrase), language, `language detection failed for ${language}`);
    assert.equal(defaultVoiceForText(phrase, 'ar-EG-ShakirNeural'), voice, `voice routing failed for ${language}`);
  }

  const voices = JSON.parse(fs.readFileSync(path.join(root, 'scripts/voice-voices.json'), 'utf8'));
  const worker = fs.readFileSync(path.join(root, 'scripts/voice_worker.py'), 'utf8');
  const ui = fs.readFileSync(path.join(root, 'public/app.js'), 'utf8');
  const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
  for (const [, , voice] of matrix) {
    assert.ok(voices.includes(voice), `voice catalog missing ${voice}`);
    assert.ok(worker.includes(voice), `worker allowlist missing ${voice}`);
    assert.ok(ui.includes(voice), `UI voice selector missing ${voice}`);
  }
  assert.ok(server.includes('/api/voice/test-four-languages'));
  assert.ok(server.includes('waitUntilReady'), 'incoming voice should wait through automatic setup rather than immediately failing');
  assert.ok(fs.readFileSync(path.join(root, 'src/voice-bootstrap.js'), 'utf8').includes('async waitUntilReady'));
  assert.ok(ui.includes('testVoiceFourLanguagesBtn'));
  assert.ok(ui.includes("api('/api/voice/runtime-status')"), 'bootstrap progress must be polled without restarting heavy model probes');
  assert.ok(fs.readFileSync(path.join(root, '.env.example'), 'utf8').includes('VOICE_AUTOSTART=true'));

  for (const backend of ['auto', 'local', 'edge-tts', 'openai-compatible']) {
    assert.equal(normalizeTtsBackend(backend), backend, `voice setup must preserve explicitly selected ${backend} backend`);
  }
  assert.equal(normalizeTtsBackend('unsupported-backend'), 'local', 'unknown TTS backend must safely fall back to local');

  const tts = new TextToSpeech({ env: {} });
  assert.equal(store.DEFAULT_SETTINGS.ttsBackend, 'local', 'new sessions must default to local TTS');
  assert.equal(store.DEFAULT_SETTINGS.ttsCloudConsent, false, 'cloud consent must be disabled in new sessions');
  assert.equal(tts.config().backend, 'local', 'TTS must default to local, not online neural voice');
  const transcriber = new AudioTranscriber({ env: {} });
  assert.equal(transcriber.config().backend, 'python-faster-whisper', 'transcription must default to a local multilingual engine');

  // Run the real bootstrap method with provisioner actions stubbed, and verify it
  // keeps every explicit backend when writing the project-owned .env file.
  for (const backend of ['auto', 'local', 'edge-tts', 'openai-compatible']) {
    const backendRoot = fs.mkdtempSync(path.join(os.tmpdir(), `chatbot-voice-backend-${backend}-`));
    try {
      const modelDir = path.join(backendRoot, 'models', 'faster-whisper-small');
      fs.mkdirSync(modelDir, { recursive: true });
      fs.writeFileSync(path.join(modelDir, 'model.bin'), 'model-fixture');
      fs.writeFileSync(path.join(modelDir, 'config.json'), '{}');
      const ffmpeg = path.join(backendRoot, 'ffmpeg.exe');
      const piper = path.join(backendRoot, 'piper.exe');
      fs.writeFileSync(ffmpeg, 'fixture'); fs.writeFileSync(piper, 'fixture');
      const env = { TTS_BACKEND: backend };
      const bootstrap = new VoiceBootstrap({ root: backendRoot, env });
      bootstrap.ensurePython = async () => path.join(backendRoot, 'python.exe');
      bootstrap.ensurePackages = async () => piper;
      bootstrap.ensurePiperModel = async () => {};
      bootstrap.runWorker = async (_python, action) => action === 'status'
        ? { ffmpegPath: ffmpeg }
        : { piper: true, ffmpegOpus: true, fasterWhisper: true, transcript: 'اختبار صوت' };
      await bootstrap.runSetup();
      const written = parseEnv(fs.readFileSync(path.join(backendRoot, '.env'), 'utf8'));
      assert.equal(written.TTS_BACKEND, backend, `actual bootstrap must preserve ${backend}`);
    } finally { fs.rmSync(backendRoot, { recursive: true, force: true }); }
  }

  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-voice-env-test-'));
  try {
    const env = {};
    const bootstrap = new VoiceBootstrap({ root: tempRoot, env });
    bootstrap.writeEnv({ VOICE_PYTHON_BIN: 'C:\\Program Files\\chat BOT\\.voice-venv\\Scripts\\python.exe', TTS_BACKEND: 'local', WHISPER_BACKEND: 'python-faster-whisper' });
    const parsed = parseEnv(fs.readFileSync(path.join(tempRoot, '.env'), 'utf8'));
    assert.equal(parsed.VOICE_PYTHON_BIN, 'C:\\Program Files\\chat BOT\\.voice-venv\\Scripts\\python.exe');
    assert.equal(parsed.TTS_BACKEND, 'local');
    bootstrap.writeEnv({ TTS_BACKEND: normalizeTtsBackend('local') });
    assert.equal(parseEnv(fs.readFileSync(path.join(tempRoot, '.env'), 'utf8')).TTS_BACKEND, 'local', 'selected local backend must survive bootstrap env persistence');
    assert.equal(env.WHISPER_BACKEND, 'python-faster-whisper');
    assert.deepEqual(bootstrap.publicStatus().languages, ['ar', 'en', 'fr', 'de', 'es']);
  } finally { fs.rmSync(tempRoot, { recursive: true, force: true }); }

  // The first incoming voice message can wait for auto-provisioning instead of requiring the user to resend it.
  const waitRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-voice-wait-test-'));
  try {
    const bootstrap = new VoiceBootstrap({ root: waitRoot, env: {} });
    bootstrap.runSetup = async () => { await new Promise(resolve => setTimeout(resolve, 15)); bootstrap.update('ready', 'اختبار', 100, 'جاهز'); };
    const ready = await bootstrap.waitUntilReady({ timeoutMs: 1000, pollMs: 250 });
    assert.equal(ready.ready, true, 'waitUntilReady must wait for setup without user intervention');
  } finally { fs.rmSync(waitRoot, { recursive: true, force: true }); }

  // Retry is scheduled automatically after a failed setup; clear the unref'd timer in this isolated test.
  const retryRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-voice-retry-test-'));
  try {
    const bootstrap = new VoiceBootstrap({ root: retryRoot, env: {} });
    bootstrap.runSetup = async () => { throw new Error('mock temporary network failure'); };
    const result = await bootstrap.start();
    assert.equal(result.state, 'failed');
    assert.equal(result.attempts, 1);
    assert.equal(result.retryScheduled, true);
    clearTimeout(bootstrap.retryTimer); bootstrap.retryTimer = null;
  } finally { fs.rmSync(retryRoot, { recursive: true, force: true }); }

  console.log('voice-autostart-multilang: ok (local defaults, migration preserves local preference, cloud consent default off, five-language voice routing and shared setup)');
})().catch(error => { console.error(error); process.exitCode = 1; });
