'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { refreshContactPictures, profileKey } = require('../src/whatsapp-contacts');

function fakeResponse(bytes) {
  return {
    status: 200,
    ok: true,
    headers: { get: name => String(name).toLowerCase() === 'content-length' ? String(bytes.length) : null },
    arrayBuffer: async () => bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
  };
}

(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-phase6-photo-refresh-'));
  const profiles = path.join(root, 'profiles');
  fs.mkdirSync(profiles, { recursive: true });
  const originalFetch = global.fetch;
  try {
    const freshJid = '96890000101@c.us';
    const offlineJid = '96890000102@c.us';
    // Signature-valid tiny fixtures are sufficient for this module's binary gate.
    const oldPng = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10, 0]);
    const newJpeg = Buffer.from([0xff, 0xd8, 0xff, 0xd9]);
    const oldFreshPath = path.join(profiles, `${profileKey(freshJid)}.png`);
    const oldOfflinePath = path.join(profiles, `${profileKey(offlineJid)}.png`);
    fs.writeFileSync(oldFreshPath, oldPng);
    fs.writeFileSync(oldOfflinePath, oldPng);

    const session = {
      id: 'main',
      recipients: [
        { id: 'r1', name: 'جهة تحتاج تحديثًا', digits: '96890000101', whatsappJid: freshJid, whatsappProfilePhoto: path.basename(oldFreshPath) },
        { id: 'r2', name: 'جهة بلا اتصال', digits: '96890000102', whatsappJid: offlineJid, whatsappProfilePhoto: path.basename(oldOfflinePath) },
      ],
    };
    const store = {
      safeSessionId: value => String(value || 'main'),
      getPaths: () => ({ dir: root, profiles }),
      listSessionIds: () => ['main'],
      loadSession: () => JSON.parse(JSON.stringify(session)),
      saveSession: value => { Object.assign(session, JSON.parse(JSON.stringify(value))); return session; },
    };
    const lookups = [];
    const whatsapp = {
      getContactProfilePictureUrl: async (_id, jid) => {
        lookups.push(jid);
        return `https://pps.whatsapp.net/${jid === freshJid ? 'fresh-avatar' : 'offline-avatar'}`;
      },
    };

    global.fetch = async url => {
      assert.match(String(url), /^https:\/\/pps\.whatsapp\.net\//);
      if (String(url).endsWith('fresh-avatar')) return fakeResponse(newJpeg);
      throw new Error('simulated CDN interruption');
    };

    const result = await refreshContactPictures({ store, whatsapp, sessionId: 'main', jids: [freshJid, offlineJid] });
    assert.equal(lookups.length, 2, 'a selected refresh must query WhatsApp even when a valid local cache already exists');
    assert.deepEqual(new Set(lookups), new Set([freshJid, offlineJid]));
    assert.equal(result.photosUpdated, 2, 'successful refresh plus safe retention of the old cache should both remain usable');
    assert.equal(session.recipients[0].whatsappProfilePhoto, `${profileKey(freshJid)}.jpg`, 'fresh bytes should replace the stale extension/cache');
    assert.equal(fs.existsSync(oldFreshPath), false, 'replaced cache file should be cleaned up');
    assert.equal(session.recipients[1].whatsappProfilePhoto, `${profileKey(offlineJid)}.png`, 'failed refresh must keep the last known-good photo');
    assert.equal(fs.existsSync(oldOfflinePath), true, 'failed refresh must not delete the last known-good photo');
    console.log('phase6-photo-refresh-cache-bypass: ok (fresh lookup despite valid cache; old verified avatar retained on CDN failure)');
  } finally {
    global.fetch = originalFetch;
    fs.rmSync(root, { recursive: true, force: true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
