"use strict";
const assert = require('node:assert/strict');
const vm = require('node:vm');
const { patchUtilsText, patchClientText, patchClientProfilePicText, patchPuppeteerText, syntaxOk } = require('../src/compat');
const bad = `const message={id:1};\nif (message && message.__x_id) delete message.__x_id;\nconst x = message.id;`;
const fixed = patchUtilsText(bad);
assert.equal(fixed.ok,true);
assert.equal(syntaxOk(fixed.text,'synthetic-utils.js'),true);
assert.equal(fixed.text.includes('message && message.__x_id'),false);
const modern = `function make(input,mediaOptions){\n        const ephemeralFields = {};\n        const message = {\n            ...input,\n            ...mediaOptions,\n        };\n        // Bot's won't reply if canonicalUrl is set (linking)\n        return window.WAWebCollections.Msg.get(newMsgKey._serialized);\n    }`;
const modernFixed = patchUtilsText(modern);
assert.equal(modernFixed.ok,true);
assert.equal(syntaxOk(modernFixed.text,'modern-utils.js'),true);
assert.equal(modernFixed.text.includes('delete message.__x_id'),true);
assert.equal(modernFixed.text.includes('newMsgKey._serialized || newMsgKey.$1'),true);
const modernWithBlankLine = `function make(input,mediaOptions){
        const message = {
            ...input,
            ...mediaOptions,
        };

        // Bot's won't reply if canonicalUrl is set (linking)
        return message;
    }`;
const modernBlankFixed = patchUtilsText(modernWithBlankLine);
assert.equal(modernBlankFixed.ok, true);
assert.equal(syntaxOk(modernBlankFixed.text, 'modern-blank-utils.js'), true);
assert.equal(modernBlankFixed.text.includes('delete message.__x_id;'), true, 'whitespace changes upstream must not skip media ID fix');
const valid = `const message={id:1};\nconst x = message.id;`;
const untouched = patchUtilsText(valid);
assert.equal(untouched.ok,true);
assert.equal(untouched.text,valid);
console.log('OK compat sanitizer');

const upstreamClient = `
class Client {
 async inject() {
  if (this.options.authTimeoutMs === undefined || this.options.authTimeoutMs == 0) { this.options.authTimeoutMs = 30000; }
  let start = Date.now();
  let timeout = this.options.authTimeoutMs;
  let res = false;
  while (start > Date.now() - timeout) {
   res = await this.pupPage.evaluate(
    'window.Debug?.VERSION != undefined',
   );
   if (res) { break; }
   await new Promise((r) => setTimeout(r, 200));
  }
  if (!res) { throw 'auth timeout'; }
  await this.pupPage.evaluate(ExposeAuthStore);
  await this.pupPage.evaluate(LoadUtils);
  let start = Date.now();
  let res = false;
  while (start > Date.now() - 30000) {
   // Check window.WWebJS Injection
   res = await this.pupPage.evaluate(
    'window.WWebJS != undefined',
   );
   if (res) { break; }
   await new Promise((r) => setTimeout(r, 200));
  }
  if (!res) { throw 'ready timeout'; }
 }
 async initialize() {
  await page.goto(WhatsWebURL, { waitUntil: 'load', timeout: 0 });
  await this.inject();
  this.pupPage.on('framenavigated', async (frame) => {
   if (frame.url().includes('post_logout=1') || this.lastLoggedOut) {
    this.emit(Events.DISCONNECTED, 'LOGOUT');
    await this.authStrategy.logout();
    await this.authStrategy.beforeBrowserInitialized();
    await this.authStrategy.afterBrowserInitialized();
    this.lastLoggedOut = false;
   }
   await this.inject();
  });
 }
}
`;
const fixedClient = patchClientText(upstreamClient);
assert.equal(fixedClient.ok, true, fixedClient.note);
assert.equal(syntaxOk(fixedClient.text, 'synthetic-client.js'), true);
assert.ok(fixedClient.text.includes("waitForFunction('window.Debug?.VERSION != undefined'"));
assert.ok(fixedClient.text.includes("waitForFunction('window.WWebJS != undefined'"));
assert.ok(fixedClient.text.includes('async _chatBotInjectWithNavigationRetry()'));
assert.ok(fixedClient.text.includes('this.__chatBotInjectTask'));
assert.ok(fixedClient.text.indexOf("this.pupPage.on('framenavigated'") < fixedClient.text.lastIndexOf('await this.inject();'), 'navigation handler must be installed before the first injection');
assert.ok(fixedClient.text.includes('frame !== this.pupPage.mainFrame()'));
const fixedClientAgain = patchClientText(fixedClient.text);
assert.equal(fixedClientAgain.ok, true, fixedClientAgain.note);
assert.equal(fixedClientAgain.text, fixedClient.text, 'Client.js patch should be idempotent');
console.log('OK Client.js navigation-safe injection patch');


const upstreamProfileClient = `class Client {
 async getProfilePicUrl(contactId) {
  const profilePic = await this.pupPage.evaluate(async (contactId) => {
   try {
    const chat = await window.WWebJS.getChat(contactId);
    return await window.require('WAWebContactProfilePicThumbBridge').requestProfilePicFromServer(chat);
   } catch (err) {
    if (err.name === 'ServerStatusCodeError') return undefined;
    throw err;
   }
  }, contactId);
  return profilePic;
 }
 async getCommonGroups(contactId) {}
}`;
const profileFixed = patchClientProfilePicText(upstreamProfileClient);
assert.equal(profileFixed.ok, true, profileFixed.note);
assert.equal(profileFixed.changed, true);
assert.equal(syntaxOk(profileFixed.text, 'synthetic-profile-client.js'), true);
assert.ok(profileFixed.text.includes("window.require('WAWebWidFactory').createWid(contactId)"));
assert.ok(profileFixed.text.includes("window.require('WAWebFindChatAction').findOrCreateLatestChat(wid)"));
assert.ok(profileFixed.text.includes('result.chat || result'));
const profileFixedAgain = patchClientProfilePicText(profileFixed.text);
assert.equal(profileFixedAgain.ok, true, profileFixedAgain.note);
assert.equal(profileFixedAgain.text, profileFixed.text, 'profile picture patch must be idempotent');
assert.equal(patchClientProfilePicText('class Client { async getProfilePicUrl(contactId) { return contactId; } async getCommonGroups() {} }').ok, false, 'unknown source layouts must fail closed');
console.log('OK WhatsApp profile-photo compatibility patch');


const upstreamUtilsForWhatsApp3000 = `
window.WWebJS.getMessageModel = (message) => {
    const msg = message.serialize();
    return msg;
};
window.WWebJS.getChatModel = async (chat) => {
    const chatWid = window.require('WAWebWidFactory').createWid(chat.id._serialized);
    await groupMetadata.update(chatWid);
    const lastMessage = chat.lastReceivedKey ? window.require('WAWebCollections').Msg.get(chat.lastReceivedKey._serialized) || await window.require('WAWebCollections').Msg.getMessagesById([chat.lastReceivedKey._serialized])?.messages?.[0] : null;
    return lastMessage;
};
window.WWebJS.getChats = async () => {
    const chats = window.require('WAWebCollections').Chat.getModelsArray();
    const chatPromises = chats.map((chat) =>
        window.WWebJS.getChatModel(chat),
    );
    return await Promise.all(chatPromises);
};`;
const w3000 = patchUtilsText(upstreamUtilsForWhatsApp3000);
assert.equal(w3000.ok, true, w3000.note);
assert.equal(syntaxOk(w3000.text, 'whatsapp-3000-utils.js'), true);
assert.ok(w3000.text.includes('key?._serialized ?? key?.$1'));
assert.ok(w3000.text.includes('CHAT_BOT_SERIALIZED_MESSAGE_ID'));
assert.ok(w3000.text.includes('getMsgKeyId(msg.id)'));
assert.ok(w3000.text.includes('chat.lastReceivedKey._serialized || chat.lastReceivedKey.$1'));
assert.ok(w3000.text.includes('chat.id._serialized || chat.id.$1'));
assert.ok(w3000.text.includes('CHAT_BOT_LID_GROUP_METADATA_GUARD'));
assert.ok(w3000.text.includes('CHAT_BOT_LID_CHAT_ISOLATION'));
assert.ok(w3000.text.includes('for (const chat of chats)'));
assert.ok(!w3000.text.includes('Promise.all(chatPromises)'));
const w3000Again = patchUtilsText(w3000.text);
assert.equal(w3000Again.ok, true, w3000Again.note);
assert.equal(w3000Again.text, w3000.text, 'WhatsApp $1/LID patch must be idempotent');
const unrecognizedGetChats = patchUtilsText(`window.WWebJS.getChats = async () => { const chats = window.require('WAWebCollections').Chat.getModelsArray(); const chatPromises = chats.map((chat) => window.WWebJS.getChatModel(chat)); return await Promise.all(chatPromises); };`);
assert.equal(unrecognizedGetChats.ok, false, 'unknown getChats block should fail closed instead of keeping Promise.all');
console.log('OK WhatsApp Web 2.3000.x $1/LID IDs and broken-chat isolation');

const upstreamPuppeteer = `async function exposeFunctionIfAbsent(page, name, fn) {
    const exist = await page.evaluate((name) => name in window, name);
    if (exist) {
        return;
    }
    await page.exposeFunction(name, fn);
}
module.exports = { exposeFunctionIfAbsent };`;
const fixedPuppeteer = patchPuppeteerText(upstreamPuppeteer);
assert.equal(fixedPuppeteer.ok, true, fixedPuppeteer.note);
assert.equal(fixedPuppeteer.changed, true);
assert.equal(syntaxOk(fixedPuppeteer.text, 'synthetic-puppeteer.js'), true);
assert.ok(fixedPuppeteer.text.includes('CHAT_BOT_EXPOSE_FUNCTION_RETRY'));
assert.ok(fixedPuppeteer.text.includes('const maxAttempts = 5;'));
assert.ok(fixedPuppeteer.text.includes('const retryDelayMs = 250;'));
assert.ok(fixedPuppeteer.text.includes('/Target closed|TargetCloseError'));
assert.ok(fixedPuppeteer.text.includes("if (/already exists/i.test(message)) return;"));
assert.equal(patchPuppeteerText(fixedPuppeteer.text).text, fixedPuppeteer.text, 'exposeFunction retry patch must be idempotent');

// A previous build could already have the narrow duplicate-registration guard.
// It must be upgraded rather than incorrectly considered equivalent to Target-closed retry.
const oldDuplicateGuard = `async function exposeFunctionIfAbsent(page, name, fn) {
  const exist = await page.evaluate((name) => name in window, name);
  if (exist) return;
  try { await page.exposeFunction(name, fn); }
  catch (error) { if (!/already exists/i.test(String(error?.message || error))) throw error; }
}
module.exports = { exposeFunctionIfAbsent };`;
const upgradedDuplicateGuard = patchPuppeteerText(oldDuplicateGuard);
assert.equal(upgradedDuplicateGuard.ok, true, upgradedDuplicateGuard.note);
assert.equal(upgradedDuplicateGuard.changed, true);
assert.ok(upgradedDuplicateGuard.text.includes('CHAT_BOT_EXPOSE_FUNCTION_RETRY'));

// Execute the patched helper against a deterministic fake Puppeteer page.
const runtimeContext = { module: { exports: {} }, setTimeout: (fn, ms) => { runtimeContext.delays.push(ms); fn(); }, window: {}, delays: [] };
vm.runInNewContext(`${fixedPuppeteer.text}
this.__expose = exposeFunctionIfAbsent;`, runtimeContext);
let evaluateAttempts = 0, exposeAttempts = 0;
const fakePage = {
  isClosed: () => false,
  evaluate: async () => { evaluateAttempts++; if (evaluateAttempts <= 2) throw new Error('Protocol error (Runtime.callFunctionOn): Target closed'); return false; },
  exposeFunction: async () => { exposeAttempts++; }
};
(async () => {
  await runtimeContext.__expose(fakePage, 'binding', () => {});
  assert.equal(evaluateAttempts, 3, 'Target closed from page.evaluate should be retried');
  assert.equal(exposeAttempts, 1, 'exposeFunction should run once after page context recovers');
  assert.deepEqual(runtimeContext.delays, [250, 250]);

  const duplicatePage = { isClosed: () => false, evaluate: async () => false, exposeFunction: async () => { throw new Error('Function with name already exists'); } };
  await runtimeContext.__expose(duplicatePage, 'binding', () => {});

  const fatalPage = { isClosed: () => false, evaluate: async () => false, exposeFunction: async () => { throw new Error('Permission denied'); } };
  await assert.rejects(() => runtimeContext.__expose(fatalPage, 'binding', () => {}), /Permission denied/, 'non-transient errors must not be swallowed or retried');

  const existingPage = { isClosed: () => false, evaluate: async () => true, exposeFunction: async () => { throw new Error('must not be called'); } };
  await runtimeContext.__expose(existingPage, 'binding', () => {});
  assert.equal(syntaxOk(fixedPuppeteer.text, 'synthetic-puppeteer.js'), true);
  assert.equal(patchPuppeteerText('async function exposeFunctionIfAbsent(page, name, fn) { return name; }').ok, false, 'unknown Puppeteer source layouts must fail closed');
  console.log('OK Puppeteer Target-closed bounded retry, duplicate race, and fail-closed behavior');
})().catch(error => { console.error(error); process.exitCode = 1; });
