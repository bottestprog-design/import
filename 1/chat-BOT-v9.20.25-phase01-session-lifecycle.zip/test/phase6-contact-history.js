'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { ConversationArchive } = require('../src/conversation-archive');
const { syncContacts, digitsFromJid } = require('../src/whatsapp-contacts');

(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-phase6-'));
  const originalFetch = global.fetch;
  try {
    const store = { safeSessionId: value => String(value || 'main'), getPaths: id => ({ dir: path.join(root, id), profiles: path.join(root, id, 'profiles') }) };
    const archive = new ConversationArchive({ store });
    // WhatsApp timestamps can match for many messages. Cursor pagination must
    // neither duplicate nor lose any messages at a tied timestamp boundary.
    const tieRows = Array.from({ length: 17 }, (_, index) => ({
      chatId: '96890000000@c.us', targetKey: 'r:tie', messageId: `tie-${String(index).padStart(2, '0')}`,
      timestamp: 1793000000, body: `رسالة ${index}`,
    }));
    assert.equal(archive.recordMany('main', tieRows).stored, tieRows.length);
    const seen = new Set(); let cursor = null; let rounds = 0; let hasOlder = true;
    while (hasOlder && rounds++ < 10) {
      const result = archive.list('main', 'r:tie', { limit: 4, ...(cursor ? { cursor } : {}) });
      for (const row of result.messages) {
        const key = `${row.chatId}|${row.messageId}`;
        assert.equal(seen.has(key), false, 'a message must never repeat across cursor pages');
        seen.add(key);
      }
      hasOlder = result.hasOlder;
      cursor = result.nextCursor;
      if (hasOlder) assert.ok(cursor, 'a non-final page must provide a compound cursor');
    }
    assert.equal(seen.size, tieRows.length, 'all tied-timestamp messages must be reachable via pagination');
    assert.equal(rounds <= 5, true);

    const targetOld = archive.list('main', 'r:tie', { limit: 4 });
    assert.equal(typeof targetOld.nextBefore, 'number', 'legacy clients still receive numeric nextBefore');
    assert.match(targetOld.nextCursor, /^c:[A-Za-z0-9_-]+$/);

    // Synchronization with a slow avatar CDN must not overwrite a concurrent
    // settings edit made while the image is being fetched.
    const jid = '96891111111@c.us';
    let persisted = { id: 'main', recipients: [], groups: [], settings: { marker: 'before' }, interaction: { rules: [] }, automation: { tasks: [], rules: [] }, logs: [] };
    const syncStore = {
      safeSessionId: value => String(value || 'main'),
      getPaths: store.getPaths,
      listSessionIds: () => ['main'],
      loadSession: () => JSON.parse(JSON.stringify(persisted)),
      saveSession: value => { persisted = JSON.parse(JSON.stringify(value)); return JSON.parse(JSON.stringify(value)); },
    };
    const phones = { parse: value => { const digits = String(value).replace(/\D/g, ''); return { digits, e164: `+${digits}`, international: `+${digits}`, formatted: `+${digits}`, country: 'OM' }; } };
    const wa = { listContacts: async () => [{ jid, digits: jid.split('@')[0], name: 'جهة اختبار', isMyContact: true, profilePicUrl: 'https://pps.whatsapp.net/photo.jpg' }] };
    global.fetch = async () => {
      await new Promise(resolve => setTimeout(resolve, 20));
      persisted.settings.concurrentEdit = 'must-survive-sync';
      return new Response(Buffer.from([0xff, 0xd8, 0xff, 0xd9]), { status: 200, headers: { 'content-type': 'image/jpeg' } });
    };
    const synced = await syncContacts({ store: syncStore, whatsapp: wa, phones, sessionId: 'main', jids: [jid], importMissing: true, updateNames: false, updatePictures: true });
    assert.equal(synced.imported.length, 1);
    assert.equal(persisted.settings.concurrentEdit, 'must-survive-sync', 'contact sync must load the latest session after external I/O');
    assert.equal(persisted.recipients[0].whatsappJid, jid);

    // Same display name must not merge two contacts; an inaccessible profile
    // picture is a partial failure and must not block saving the contact data.
    const duplicateRoot = path.join(root, 'duplicate-names');
    let duplicatePersisted = { id: 'main', recipients: [], groups: [], settings: {}, interaction: { rules: [] }, automation: { tasks: [], rules: [] }, logs: [] };
    const duplicateStore = {
      safeSessionId: value => String(value || 'main'),
      getPaths: () => ({ dir: duplicateRoot, profiles: path.join(duplicateRoot, 'profiles') }),
      listSessionIds: () => ['main'],
      loadSession: () => JSON.parse(JSON.stringify(duplicatePersisted)),
      saveSession: value => { duplicatePersisted = JSON.parse(JSON.stringify(value)); return JSON.parse(JSON.stringify(value)); },
    };
    const duplicateJids = ['96892222222@c.us', '96893333333@c.us'];
    const duplicateWa = { listContacts: async () => duplicateJids.map((contactJid) => ({ jid: contactJid, digits: contactJid.split('@')[0], name: 'اسم مشترك', isMyContact: true, profilePicUrl: '' })) };
    global.fetch = async () => new Response('not an image', { status: 403, headers: { 'content-type': 'text/html' } });
    const duplicateSync = await syncContacts({ store: duplicateStore, whatsapp: duplicateWa, phones, sessionId: 'main', jids: duplicateJids, importMissing: true, updateNames: false, updatePictures: true });
    assert.equal(duplicateSync.imported.length, 2, 'same display name must not merge distinct WhatsApp identities');
    assert.equal(new Set(duplicatePersisted.recipients.map(person => person.whatsappJid)).size, 2);
    assert.equal(new Set(duplicatePersisted.recipients.map(person => person.id)).size, 2);
    assert.equal(duplicateSync.photosFailed, 2, 'inaccessible pictures are reported independently of contact import');
    assert.equal(digitsFromJid('123456789@lid'), '', 'LID must not be mistaken for a confirmed phone number');

    const restartedArchive = new ConversationArchive({ store });
    assert.equal(restartedArchive.list('main', 'r:tie', { limit: 50 }).messages.length, tieRows.length, 'archive cursor data must persist across a new archive instance/restart');

    const server = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf8');
    const app = fs.readFileSync(path.join(__dirname, '..', 'public', 'app.js'), 'utf8');
    const archiveSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'conversation-archive.js'), 'utf8');
    assert.match(server, /confirmedImportHistory !== true/, 'history import must have a server-side explicit-confirmation gate');
    assert.match(server, /const freshTarget = conversationTargets\.allowedTarget\(freshSession, target\.key/, 'target must be revalidated after the awaited WhatsApp history fetch');
    assert.match(server, /!conversationTargets\.targetIsEnabled\(freshTarget\)/, 'history import must stop if the target is disabled or paused during retrieval');
    assert.match(app, /confirmedImportHistory: true/, 'UI must pass explicit confirmation only after showing its confirmation dialog');
    assert.match(app, /nextCursor \|\| state\.conversationMeta\.nextBefore/, 'conversation history must prefer the compound cursor but support old numeric cursors');
    assert.match(app, /whatsappContactsPageSize: 50/);
    assert.match(app, /contactPagination\.addEventListener\('click'/, 'pagination listeners must be bound on the persistent container rather than replaced inner buttons');
    assert.match(archiveSource, /cutoffId/, 'archive cursor must include a deterministic message identifier tie-breaker');
    assert.match(server, /confirmedDownloadMedia !== true/, 'attachment retrieval requires explicit confirmation');
    assert.match(server, /const freshTarget = conversationTargets\.allowedTarget\(freshSession, target\.key/, 'attachment download target must be revalidated after acquiring the chat');
    assert.match(server, /completeHistoryGuaranteed: false/, 'the server must not promise WhatsApp exposes complete history');
    assert.match(server, /Number\(freshSession\.settings\?\.maxImageSizeMB\)/, 'media limits must use the latest session settings after network calls');
    assert.match(server, /confirmedDownloadMedia !== true/, 'attachment retrieval requires explicit confirmation');
    assert.match(server, /const freshTarget = conversationTargets\.allowedTarget\(freshSession, target\.key/, 'attachment download target must be revalidated after acquiring the chat');
    assert.match(app, /previousWhatsAppContactsPage/);
    assert.match(app, /nextWhatsAppContactsPage/);
    assert.match(app, /id=\"whatsappContactPageSize\"/);
    assert.match(app, /contactPagination\.addEventListener\('change'/, 'the page-size control must use the same persistent event container');
    assert.match(app, /whatsappContactPageInfo\(\)\.visible\.forEach/, 'select-visible must not silently select off-page contacts');

    console.log('phase6-contact-history: ok (stable tie-safe archive pagination, explicit history import, post-fetch recipient revalidation, contact UI pagination, visible-only bulk selection, and stale-session race protection)');
  } finally {
    global.fetch = originalFetch;
    fs.rmSync(root, { recursive: true, force: true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
