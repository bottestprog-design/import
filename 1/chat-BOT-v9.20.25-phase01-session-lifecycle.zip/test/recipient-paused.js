const assert = require('node:assert/strict');
const { recipientForChat, recipientIsPaused } = require('../src/recipient-replies');
const session = {
  recipients: [
    { id: 'alice', name: 'Alice', e164: '+96890001111', enabled: false },
    { id: 'lid-user', name: 'LID User', lid: '123456789012345@lid', enabled: true, paused: true },
    { id: 'bob', name: 'Bob', digits: '96890002222', enabled: true },
    { id: 'stopped', name: 'Stopped flag', digits: '96890003333', stopped: true }
  ],
  groups: [
    { id: 'group-1', name: 'Paused group', gid: '120363000000001@g.us', enabled: false },
    { id: 'group-2', name: 'Active group', jid: '120363000000002@g.us', enabled: true }
  ]
};
assert.equal(recipientForChat(session, '96890001111@c.us')?.id, 'alice');
assert.equal(recipientForChat(session, '123456789012345@lid')?.id, 'lid-user');
assert.equal(recipientForChat(session, '999999999999999@lid'), null, 'do not guess a phone number from a LID');
assert.equal(recipientIsPaused(session, '96890001111@c.us'), true);
assert.equal(recipientIsPaused(session, '123456789012345@lid'), true);
assert.equal(recipientIsPaused(session, '96890002222@c.us'), false);
assert.equal(recipientIsPaused(session, '96890003333@c.us'), true);
assert.equal(recipientIsPaused(session, '120363000000001@g.us'), true);
assert.equal(recipientIsPaused(session, '120363000000002@g.us'), false);
assert.equal(recipientIsPaused(session, '96890004444@c.us'), false);
console.log('recipient-paused: ok (paused people/groups, explicit LID matching, no LID-to-phone guessing)');

const aliasSession = { recipients: [{ id: 'wa', name: 'Alias', waChatId: '96890005555@c.us', enabled: false }], groups: [] };
assert.equal(recipientIsPaused(aliasSession, '96890005555@c.us'), true, 'alternate saved WhatsApp chat ID must honor the pause flag');
