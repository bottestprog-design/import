'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { OwnerAssistant, WELCOME_GUIDE, isConfirm, isExactConfirmation, isRealCalendarDate } = require('../src/owner-assistant');

const clone = value => JSON.parse(JSON.stringify(value));
function createHarness() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-owner-assistant-'));
  const original = {
    id: 'main', name: 'الجلسة الرئيسية', setupComplete: true,
    recipients: [{ id: 'ahmed', name: 'أحمد', digits: '96890000000', e164: '+96890000000', international: '+968 9000 0000', enabled: true }],
    groups: [], logs: [], settings: { automationEnabled: true, ttsBackend: 'local', ttsCloudConsent: false },
    interaction: { rules: [], enabled: true }, automation: { tasks: [], enabled: true },
  };
  let saved = clone(original);
  const store = {
    safeSessionId: value => String(value || 'main'),
    loadSession: () => clone(saved),
    saveSession: session => { saved = clone(session); return clone(saved); },
    normalizeAutomationTask: task => ({ ...clone(task), id: task.id || 'task-1', targetKeys: [...(task.targetKeys || [])] }),
    getPaths: () => ({ dir: root, profiles: path.join(root, 'profiles') }),
    cleanup: () => fs.rmSync(root, { recursive: true, force: true }),
    get current() { return clone(saved); },
  };
  const sent = [];
  const contactCalls = [];
  const resolveCalls = [];
  const whatsapp = {
    selfChatId: () => '15555555555@c.us',
    listRuntime: () => ({ ready: true, status: 'ready' }),
    sendText: async (id, chatId, text) => { sent.push({ id, chatId, text }); return { __chatBotAck: { status: 'accepted' } }; },
    resolveChatId: async (_id, data) => { resolveCalls.push(clone(data)); return `${String(data.digits || data.phone || data.e164 || '96895555555').replace(/\D/g, '')}@c.us`; },
    listContacts: async (_id, opts) => { contactCalls.push(opts); return [{ jid: '96897777777@c.us', digits: '96897777777', name: 'جهة واتساب', isMyContact: true }]; },
  };
  const phones = { parse: value => {
    const digits = String(value).replace(/\D/g, '');
    if (digits.length < 8) throw new Error('رقم غير صالح للاختبار');
    return { digits, e164: `+${digits}`, international: `+${digits}`, formatted: `+${digits}`, national: digits, country: 'OM', callingCode: '968' };
  } };
  const assistant = new OwnerAssistant({ store, whatsapp, phones, log: () => {} });
  return { assistant, store, whatsapp, phones, sent, contactCalls, resolveCalls };
}
async function send(h, body) { return h.assistant.handleSelfChatMessage('main', { body, fromMe: true }); }
(async () => {
  const h = createHarness();
  assert.equal(isConfirm('تأكيد الإرسال'), true, 'Arabic confirmation with hamza must work after normalization');
  assert.equal(await h.assistant.maybeSendWelcome('main'), true);
  assert.match(h.sent[0].text, /الرسائل إلى نفسك/);
  assert.equal(h.store.current.ownerAssistant.welcomeAttempt.status, 'sent', 'successful welcome delivery leaves a durable receipt');
  assert.equal(await h.assistant.maybeSendWelcome('main'), false, 'welcome guide must not be repeated on every status event');
  const interruptedState = h.store.current;
  interruptedState.ownerAssistant.welcomeSentAt = '';
  interruptedState.ownerAssistant.welcomeAttempt = { key: 'owner-welcome-v1', status: 'sending', at: Date.now() - 1000 };
  h.store.saveSession(interruptedState);
  const sentBeforeCrashRecovery = h.sent.length;
  assert.equal(await h.assistant.maybeSendWelcome('main'), false, 'an interrupted ambiguous welcome must not be sent again after restart');
  assert.equal(h.store.current.ownerAssistant.welcomeAttempt.status, 'uncertain');
  assert.equal(h.sent.length, sentBeforeCrashRecovery, 'uncertain startup recovery must not duplicate the welcome');

  const recoverable = createHarness();
  let failOnce = true;
  const originalSend = recoverable.whatsapp.sendText;
  recoverable.whatsapp.sendText = async (...args) => {
    if (failOnce) { failOnce = false; throw Object.assign(new Error('session not ready'), { code: 'WHATSAPP_SESSION_NOT_READY' }); }
    return originalSend(...args);
  };
  await assert.rejects(recoverable.assistant.maybeSendWelcome('main'));
  assert.equal(recoverable.store.current.ownerAssistant.welcomeAttempt.status, 'failed', 'known non-ambiguous failures remain eligible for retry');
  assert.equal(await recoverable.assistant.maybeSendWelcome('main'), true);
  assert.equal(recoverable.store.current.ownerAssistant.welcomeAttempt.status, 'sent');
  recoverable.store.cleanup();

  const uncertainWelcome = createHarness();
  uncertainWelcome.whatsapp.sendText = async () => { throw Object.assign(new Error('delivery uncertain'), { code: 'SEND_UNCERTAIN' }); };
  await assert.rejects(uncertainWelcome.assistant.maybeSendWelcome('main'));
  assert.equal(uncertainWelcome.store.current.ownerAssistant.welcomeAttempt.status, 'uncertain');
  assert.equal(await uncertainWelcome.assistant.maybeSendWelcome('main'), false, 'uncertain welcome must not retry without inspection');
  uncertainWelcome.store.cleanup();
  const concurrent = createHarness();
  const welcomeResults = await Promise.all([concurrent.assistant.maybeSendWelcome('main'), concurrent.assistant.maybeSendWelcome('main')]);
  assert.equal(welcomeResults.filter(Boolean).length, 1, 'concurrent ready events must only send one welcome');
  assert.equal(concurrent.sent.filter(item => item.text.startsWith(WELCOME_GUIDE)).length, 1);
  assert.match(concurrent.sent[0].text, /انطق آخر رد/, 'bot replies should include the subtle text-to-speech hint');
  concurrent.store.cleanup();

  await send(h, 'عايز أضيف شخص جديد');
  await send(h, 'ليلى');
  await send(h, 'عمان');
  await send(h, '+96891234567');
  assert.ok(h.store.current.recipients.some(person => person.name === 'ليلى' && person.digits === '96891234567'), 'self-chat add-person wizard saves a recipient');

  let chatReadCalls = 0;
  const recallLimits = [];
  h.whatsapp.getChatSafe = async (_id, chatId) => {
    chatReadCalls++;
    return { id: chatId, fetchMessages: async ({ limit }) => {
      recallLimits.push(limit);
      assert.ok(limit > 0 && limit <= 500, 'recall reads are bounded');
      return [{ id: { $1: 'recall-message-1' }, timestamp: 1792944000, fromMe: false, body: 'هذه الفاتورة الشهرية', type: 'chat', hasMedia: false, _data: { notifyName: 'أحمد' } }];
    } };
  };
  const archiveCalls = [];
  h.assistant.conversationArchive = {
    recordMany: (_id, rows) => { archiveCalls.push(...rows); return { stored: rows.length, duplicates: 0, failed: 0 }; },
    search: () => [],
  };
  await send(h, 'ابحث في محادثة أحمد عن الفاتورة');
  assert.match(h.sent.at(-1).text, /هذه الفاتورة الشهرية/);
  assert.equal(archiveCalls.length, 1, 'messages read from a registered chat should enter the local archive');
  const recentRecall = await send(h, 'هات آخر 2 رسائل من أحمد');
  assert.equal(recentRecall.action, 'conversation-recall-recent');
  assert.equal(recallLimits.at(-1), 2, 'recent-message recall must request only the requested bounded number');
  assert.match(h.sent.at(-1).text, /آخر 2 رسائل من «أحمد»/);
  const readsBeforeUnregistered = chatReadCalls;
  await send(h, 'هات آخر 2 رسائل من شخص غير مسجل');
  assert.equal(chatReadCalls, readsBeforeUnregistered, 'unregistered target names must be rejected without reading WhatsApp chats');
  assert.match(h.sent.at(-1).text, /لا أسترجع الرسائل إلا من محادثة/);

  const voiceCalls = [];
  h.whatsapp.sendVoice = async (id, chatId, file) => { voiceCalls.push({ id, chatId, file }); return { __chatBotAck: { status: 'confirmed' } }; };
  h.assistant.speechSynthesizer = {
    status: async () => ({ ready: true, activeBackend: 'local', binaryReady: true, modelReady: true, ffmpegReady: true, message: 'محرك الاختبار جاهز.' }),
    generate: async text => ({ backend: 'local', wavPath: '/tmp/chatbot-tts-test/speech.wav', directory: '/tmp/chatbot-tts-test', text, proofreadUsed: true }),
    toWhatsAppVoice: async () => '/tmp/chatbot-tts-test/voice.ogg',
    cleanup: () => true,
  };
  await send(h, 'انطق آخر رد');
  assert.equal(voiceCalls.length, 1, 'the speech command should send one generated OGG/Opus voice message');
  assert.equal(voiceCalls[0].chatId, '15555555555@c.us');
  const longLastReply = Array.from({ length: 85 }, (_, i) => `هذه جملة طويلة رقم ${i + 1} لاختبار تحويل آخر رد بالكامل إلى مقاطع صوتية مرتبة دون قص النص.`).join(' ');
  h.assistant.lastReplies.set('main', { text: longLastReply, at: new Date().toISOString() });
  const beforeLongReplyVoice = voiceCalls.length;
  await send(h, 'انطق آخر رد');
  assert.ok(voiceCalls.length > beforeLongReplyVoice + 1, 'long self-chat replies are sent as multiple ordered voice notes instead of truncating at 1800 characters');
  assert.match(h.sent.at(-1).text, /مقطع صوتي/);
  await send(h, 'فحص النطق');
  assert.match(h.sent.at(-1).text, /محرك النطق \(local\): جاهز/);
  const countBeforePreview = voiceCalls.length;
  await send(h, 'اختبر النطق');
  assert.equal(voiceCalls.length, countBeforePreview + 1, 'the explicit pronunciation test sends only a preview voice to self-chat');
  assert.match(h.sent.at(-1).text, /عينة النطق إلى محادثة النفس فقط/);
  h.assistant.speechSynthesizer.generate = async text => ({ backend: 'local', wavPath: '/tmp/chatbot-tts-test/speech.wav', directory: '/tmp/chatbot-tts-test', text, proofreadUsed: false });
  const strictVoiceSettings = h.store.current;
  strictVoiceSettings.settings.ttsRequireProofread = true;
  strictVoiceSettings.settings.ttsProofreadEnabled = true;
  h.store.saveSession(strictVoiceSettings);
  const voiceCountBeforeBlocked = voiceCalls.length;
  await send(h, 'انطق آخر رد');
  assert.equal(voiceCalls.length, voiceCountBeforeBlocked, 'strict proofreading must block sending an unreviewed voice reply');
  assert.match(h.sent.at(-1).text, /لم أرسل مقاطع غير مكتملة/);

  const priorCount = h.sent.filter(item => item.chatId === '96890000000@c.us').length;
  await send(h, 'أرسل رسالة');
  await send(h, 'أحمد');
  await send(h, 'رسالة اختبار آمنة');
  assert.equal(h.sent.filter(item => item.chatId === '96890000000@c.us').length, priorCount, 'message is not sent before confirmation');
  await send(h, 'تأكيد الإرسال');
  assert.equal(h.sent.filter(item => item.chatId === '96890000000@c.us' && item.text === 'رسالة اختبار آمنة').length, 1, 'confirmation triggers exactly one send');
  assert.equal(h.resolveCalls.at(-1)?.id, 'ahmed', 'owner-assistant sends must resolve the saved recipient through the WhatsApp identity resolver');
  assert.equal(h.store.current.ownerAssistant.flow, null);

  await send(h, 'أنشئ موعد');
  await send(h, 'أحمد');
  await send(h, 'رسالة موعد');
  await send(h, 'يومي');
  await send(h, '17:30');
  await send(h, 'تأكيد الحفظ');
  assert.equal(h.store.current.automation.tasks.length, 1, 'schedule wizard stores the task only after confirmation');
  assert.deepEqual(h.store.current.automation.tasks[0].targetKeys, ['r:ahmed']);

  await send(h, 'أنشئ رد تلقائي');
  await send(h, 'حالة الطلب');
  await send(h, 'سيتم التحقق من طلبك');
  await send(h, 'تأكيد الحفظ');
  assert.ok(h.store.current.interaction.rules.some(rule => rule.when?.value === 'حالة الطلب'), 'auto-reply wizard stores a rule');

  assert.equal(isExactConfirmation('تمام', 'send-text'), false, 'generic acknowledgement is not authorization for outbound text');
  assert.equal(isExactConfirmation('تأكيد الإرسال', 'send-text'), true);
  assert.equal(isRealCalendarDate('2026-02-28'), true);
  assert.equal(isRealCalendarDate('2026-02-31'), false, 'non-existent calendar dates are rejected');
  assert.equal(isRealCalendarDate('2024-02-29'), true, 'valid leap days are accepted');

  const strictSend = createHarness();
  await send(strictSend, 'أرسل رسالة');
  await send(strictSend, 'أحمد');
  await send(strictSend, 'رسالة يجب تأكيدها');
  await send(strictSend, 'تمام');
  assert.equal(strictSend.sent.filter(item => item.chatId === '96890000000@c.us' && item.text === 'رسالة يجب تأكيدها').length, 0, 'generic acknowledgement must not send a text message');
  assert.equal(strictSend.store.current.ownerAssistant.flow?.step, 'confirm', 'send flow remains pending after generic acknowledgement');
  await send(strictSend, 'تأكيد الإرسال');
  assert.equal(strictSend.sent.filter(item => item.chatId === '96890000000@c.us' && item.text === 'رسالة يجب تأكيدها').length, 1, 'only the exact send confirmation performs the action');
  strictSend.store.cleanup();

  const strictSchedule = createHarness();
  await send(strictSchedule, 'أنشئ موعد');
  await send(strictSchedule, 'أحمد');
  await send(strictSchedule, 'رسالة موعد آمن');
  await send(strictSchedule, 'يومي');
  await send(strictSchedule, '17:30');
  await send(strictSchedule, 'تمام');
  assert.equal(strictSchedule.store.current.automation.tasks.length, 0, 'generic acknowledgement must not persist a schedule');
  assert.equal(strictSchedule.store.current.ownerAssistant.flow?.step, 'confirm');
  await send(strictSchedule, 'تأكيد الحفظ');
  assert.equal(strictSchedule.store.current.automation.tasks.length, 1, 'exact save confirmation persists the schedule');
  strictSchedule.store.cleanup();

  const strictRule = createHarness();
  await send(strictRule, 'أنشئ رد تلقائي');
  await send(strictRule, 'حالة خاصة');
  await send(strictRule, 'رد محفوظ بعد التأكيد');
  await send(strictRule, 'تمام');
  assert.equal(strictRule.store.current.interaction.rules.length, 0, 'generic acknowledgement must not save an auto-reply rule');
  assert.equal(strictRule.store.current.ownerAssistant.flow?.step, 'confirm');
  await send(strictRule, 'تأكيد الحفظ');
  assert.equal(strictRule.store.current.interaction.rules.length, 1, 'exact save confirmation persists an auto-reply rule');
  strictRule.store.cleanup();

  const invalidDate = createHarness();
  await send(invalidDate, 'أنشئ موعد');
  await send(invalidDate, 'أحمد');
  await send(invalidDate, 'موعد بتاريخ غير صحيح');
  await send(invalidDate, 'مرة واحدة');
  await send(invalidDate, '17:30');
  await send(invalidDate, '2026-02-31');
  assert.equal(invalidDate.store.current.ownerAssistant.flow?.step, 'date', 'impossible calendar date keeps the wizard on the date step');
  assert.equal(invalidDate.store.current.automation.tasks.length, 0, 'invalid date must not create a task');
  await send(invalidDate, '2026-11-01');
  assert.equal(invalidDate.store.current.ownerAssistant.flow?.step, 'confirm', 'valid date advances to the explicit confirmation step');
  assert.equal(invalidDate.store.current.automation.tasks.length, 0);
  invalidDate.store.cleanup();

  await send(h, 'شخّص الرد التلقائي على: حالة الطلب');
  assert.match(h.sent.at(-1).text, /قواعد طابقت النص/);
  assert.match(h.sent.at(-1).text, /لم يتم إرسال أي رسالة/);

  await send(h, 'استدعاء جهات واتساب');
  await send(h, 'تمام');
  assert.equal(h.store.current.ownerAssistant.flow?.type, 'sync-confirm', 'generic acknowledgement must not run a contact import');
  assert.equal(h.contactCalls.length, 1, 'a generic acknowledgement must not query contacts for the import phase');
  await send(h, 'تأكيد المزامنة');
  assert.ok(h.store.current.recipients.some(person => person.digits === '96897777777'), 'self-chat WhatsApp contact sync imports missing numeric contacts');
  assert.equal(h.contactCalls.length, 2, "preview plus explicitly confirmed sync query WhatsApp contacts");
  assert.equal(h.store.current.ownerAssistant.flow, null);

  let mediaDownloads = 0;
  const requestedMediaTypes = [];
  h.whatsapp.downloadMediaFromChat = async (_id, chatId, limits) => {
    mediaDownloads++;
    requestedMediaTypes.push(limits.mediaType);
    assert.equal(chatId, '96890000000@c.us');
    assert.equal(limits.maxFiles, 100);
    return { chatId, chatName: 'أحمد', scanned: 12, mediaFound: 1, considered: 1, downloaded: [{ filename: 'voice.ogg', bytes: 2048 }], failed: [], skipped: [], mediaDirectory: '/local/media' };
  };
  await send(h, 'استخرج الملفات من محادثة أحمد');
  assert.equal(h.store.current.ownerAssistant.flow?.type, 'download-chat-media');
  await send(h, 'تمام');
  assert.equal(mediaDownloads, 0, 'generic acknowledgement cannot authorize downloading private chat attachments');
  assert.equal(h.store.current.ownerAssistant.flow?.step, 'confirm');
  await send(h, 'تأكيد التنزيل');
  assert.equal(mediaDownloads, 1, 'explicit download confirmation runs the scoped attachment operation once');
  assert.equal(requestedMediaTypes[0], 'all');
  assert.match(h.sent.at(-1).text, /اكتمل فحص المحادثة/);
  await send(h, 'استخرج الصوتيات من محادثة أحمد');
  assert.match(h.sent.at(-1).text, /الصوتيات والرسائل الصوتية/);
  await send(h, 'تمام');
  assert.equal(mediaDownloads, 1, 'a generic acknowledgement must not authorize audio extraction');
  await send(h, 'تأكيد التنزيل');
  assert.equal(mediaDownloads, 2, 'audio-only extraction is supported as a distinct command');
  assert.equal(requestedMediaTypes[1], 'audio', 'the requested attachment filter reaches the WhatsApp downloader');
  assert.equal(h.store.current.ownerAssistant.flow, null);

  await send(h, 'أنشئ موعد');
  await send(h, 'إلغاء');
  assert.equal(h.store.current.ownerAssistant.flow, null, 'cancel abandons any pending wizard');
  h.store.cleanup();
  console.log('owner-assistant: ok (welcome, add-person wizard, explicit send confirmation, scheduling, safe registered-chat recall, Arabic rule diagnostics, local TTS status/preview, auto-reply, contact sync, cancellation)');
})().catch(error => { console.error(error); process.exitCode = 1; });
