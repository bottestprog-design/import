'use strict';
const assert = require('node:assert/strict');
const { sendSpeechInSegments } = require('../src/tts-delivery');
const { splitSpeechText } = require('../src/text-to-speech');

function longText(sentences = 90) {
  return Array.from({ length: sentences }, (_, i) => `هذه جملة اختبار رقم ${i + 1} للتأكد من عدم حذف أي جزء من الرد الصوتي الطويل، مع الحفاظ على ترتيب المقاطع وعلامات الوقف.`).join(' ');
}

(async () => {
  const text = longText(90);
  const expected = splitSpeechText(text, { maxSegments: 10 });
  assert.ok(expected.length > 1 && expected.length <= 10, 'long text is split into multiple bounded segments');
  assert.equal(expected.join(' ').replace(/\s+/gu, ' ').trim(), text.replace(/\s+/gu, ' ').trim(), 'all normalized content is preserved across segments');

  const sent = [], generated = [], cleaned = [];
  const synthesizer = {
    generate: async (part, options) => {
      generated.push({ part, options });
      return { text: part, backend: 'local', wavPath: `/tmp/mock-${generated.length}.wav`, directory: `/tmp/chatbot-tts-${generated.length}`, proofreadUsed: true };
    },
    toWhatsAppVoice: async file => `${file}.ogg`,
    cleanup: result => { cleaned.push(result.wavPath); },
  };
  const result = await sendSpeechInSegments({
    synthesizer, text, settings: { ttsMaxReplySegments: 10, ttsRequireProofread: true, ttsPronunciationDictionary: [{ term: 'ChatGPT', pronunciation: 'شات جي بي تي' }] },
    sendVoice: async (file, info) => sent.push({ file, info }),
  });
  assert.equal(result.sentSegments, expected.length);
  assert.equal(result.proofreadSegments, expected.length);
  assert.deepEqual(sent.map(x => x.info.index), expected.map((_, i) => i + 1), 'voice notes are sent in order');
  assert.ok(generated.every(item => item.options.pronunciationDictionary.length === 1), 'the pronunciation dictionary reaches every segment');
  assert.equal(cleaned.length, expected.length, 'all generated WAV files are cleaned');

  let latestSettings = { ttsCloudConsent: true, ttsBackend: 'edge-tts', ttsMaxReplySegments: 10 };
  let remoteSent = 0;
  const cloudSynth = {
    generate: async part => { latestSettings.ttsCloudConsent = false; return { text: part, backend: 'edge-tts', wavPath: '/tmp/cloud.wav', directory: '/tmp/chatbot-tts-cloud' }; },
    toWhatsAppVoice: async () => '/tmp/cloud.ogg', cleanup: () => { cleaned.push('cloud'); },
  };
  await assert.rejects(() => sendSpeechInSegments({ synthesizer: cloudSynth, text: 'جملة قصيرة.', settings: { ...latestSettings }, getLatestSettings: () => latestSettings, sendVoice: async () => { remoteSent++; } }), /أُلغيت موافقة الصوت الخارجي/);
  assert.equal(remoteSent, 0, 'revoked consent blocks delivery after generation');

  let calls = 0, allowed = true, partialCleaned = 0;
  const partialSynth = {
    generate: async part => {
      calls++;
      if (calls === 2) throw new Error('second segment failed');
      return { text: part, backend: 'local', wavPath: '/tmp/partial.wav', directory: '/tmp/chatbot-tts-partial', proofreadUsed: true };
    },
    toWhatsAppVoice: async () => '/tmp/partial.ogg', cleanup: () => { partialCleaned++; },
  };
  await assert.rejects(() => sendSpeechInSegments({ synthesizer: partialSynth, text, settings: { ttsMaxReplySegments: 10 }, assertAllowed: () => { if (!allowed) throw new Error('recipient paused'); }, sendVoice: async () => { allowed = false; } }), error => {
    assert.equal(error.code, 'VOICE_REPLY_PARTIAL');
    assert.equal(error.sentSegments, 1);
    assert.ok(error.message.includes('بقي الرد النصي كاملًا'));
    return true;
  });
  assert.equal(partialCleaned, 1);

  const uncertainFirstSend = {
    generate: async part => ({ text: part, backend: 'local', wavPath: '/tmp/uncertain-first.wav', directory: '/tmp/chatbot-tts-uncertain-first', proofreadUsed: true }),
    toWhatsAppVoice: async () => '/tmp/uncertain-first.ogg', cleanup: () => {},
  };
  await assert.rejects(() => sendSpeechInSegments({
    synthesizer: uncertainFirstSend, text: 'رسالة صوتية قصيرة.', settings: {},
    sendVoice: async () => { throw Object.assign(new Error('ack timeout'), { code: 'SEND_UNCERTAIN' }); },
  }), error => {
    assert.equal(error.code, 'VOICE_REPLY_UNCERTAIN');
    assert.equal(error.sentSegments, 0);
    assert.match(error.message, /افحص محادثة WhatsApp/);
    return true;
  });

  const noProofread = {
    generate: async part => ({ text: part, backend: 'local', wavPath: '/tmp/no-proof.wav', directory: '/tmp/chatbot-tts-no-proof', proofreadUsed: false }),
    toWhatsAppVoice: async () => '/tmp/no-proof.ogg', cleanup: () => {},
  };
  await assert.rejects(() => sendSpeechInSegments({ synthesizer: noProofread, text: 'اختبار.', settings: { ttsRequireProofread: true }, sendVoice: async () => {} }), /لم ينجح التدقيق/);

  await assert.rejects(() => sendSpeechInSegments({ synthesizer, text: longText(400), settings: { ttsMaxReplySegments: 1 }, sendVoice: async () => {} }), /الرد طويل جدًا/);
  console.log('tts-delivery-segments: ok (ordered chunking, complete text preservation, dictionary propagation, cleanup, cloud-consent revocation, recipient stop, partial-send and uncertain-first-send safety)');
})().catch(error => { console.error(error); process.exitCode = 1; });
