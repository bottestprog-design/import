'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const candidates = process.platform === 'win32'
  ? [path.join(root, '.voice-venv', 'Scripts', 'python.exe'), 'py', 'python']
  : [path.join(root, '.voice-venv', 'bin', 'python'), 'python3', 'python'];
const script = path.join(__dirname, 'voice-worker-quality.py');
let completed = null;
for (const binary of candidates) {
  if (binary.includes(path.sep) && !fs.existsSync(binary)) continue;
  const args = binary === 'py' ? ['-3', script] : [script];
  const result = spawnSync(binary, args, { cwd: root, encoding: 'utf8', timeout: 60000, windowsHide: true, env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' } });
  if (result.error?.code === 'ENOENT') continue;
  completed = result;
  break;
}
if (!completed) {
  console.log('voice-worker-quality: skipped (no compatible Python executable available in test environment)');
  process.exit(0);
}
if (completed.error) throw completed.error;
if (completed.status !== 0) throw new Error(`voice worker contract tests failed:\n${completed.stdout}\n${completed.stderr}`);
const output = `${completed.stdout || ''}\n${completed.stderr || ''}`;
assert.match(output, /Ran 7 tests/);
assert.match(output, /OK/);
console.log('voice-worker-quality: ok (Python worker, four-language decoding contract, VAD/beam configuration, PyAV 19 rejection, silence/log-probability combination)');
