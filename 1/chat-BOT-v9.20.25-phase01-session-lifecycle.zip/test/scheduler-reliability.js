'use strict';
const assert = require('node:assert/strict');
const { ReliableScheduler, parts } = require('../src/scheduler');
const clone = value => JSON.parse(JSON.stringify(value));

function harness(session) {
  let saved = clone(session);
  const store = {
    listSessionIds: () => [saved.id],
    loadSession: () => clone(saved),
    saveSession: value => { saved = clone(value); return clone(saved); },
    get current() { return clone(saved); },
  };
  return store;
}
function currentLocalSchedule() {
  const local = parts(new Date(), 'Asia/Muscat');
  return { mode: 'daily', time: `${String(local.hour).padStart(2, '0')}:${String(local.minute).padStart(2, '0')}`, timezone: 'Asia/Muscat' };
}

(async () => {
  const schedule = currentLocalSchedule();
  const base = {
    id: 'scheduler-test',
    settings: { timezone: 'Asia/Muscat', scheduleEnabled: true, scheduleMode: schedule.mode, scheduleTime: schedule.time, scheduleDate: '', automationEnabled: true },
    scheduleState: { lastRunKey: '', lastAttempt: null },
    automation: { enabled: true, tasks: [], recent: [] },
  };

  const retryStore = harness(clone(base));
  let legacyRuns = 0;
  const retryScheduler = new ReliableScheduler({ store: retryStore, run: async () => { legacyRuns++; return { ok: false, sent: [], failed: [{ retryable: true, code: 'TEMPORARY' }] }; }, log: () => {} });
  retryScheduler.stop();
  await retryScheduler.tickSession(base.id);
  assert.equal(legacyRuns, 1);
  assert.equal(retryStore.current.scheduleState.lastAttempt.status, 'failed', 'known-safe failure is recorded as retryable');
  assert.equal(retryStore.current.scheduleState.lastRunKey, '', 'retryable failure does not consume the schedule key');
  retryStore.current.scheduleState.lastAttempt.retryAt = Date.now() - 1;
  const forcedRetry = retryStore.current;
  forcedRetry.scheduleState.lastAttempt.retryAt = Date.now() - 1;
  retryStore.saveSession(forcedRetry);
  await retryScheduler.tickSession(base.id);
  assert.equal(legacyRuns, 2, 'a known-safe failure can retry after its backoff');
  retryScheduler.stop();

  const partialSession = clone(base); partialSession.id = 'scheduler-partial';
  const partialStore = harness(partialSession);
  let partialRuns = 0;
  const partialScheduler = new ReliableScheduler({ store: partialStore, run: async () => { partialRuns++; return { ok: false, sent: [{ recipient: 'first' }], failed: [{ retryable: true }] }; }, log: () => {} });
  partialScheduler.stop();
  await partialScheduler.tickSession(partialSession.id);
  assert.equal(partialStore.current.scheduleState.lastAttempt.status, 'partial');
  assert.ok(partialStore.current.scheduleState.lastRunKey, 'partial success consumes the schedule key to avoid duplicate sends');
  await partialScheduler.tickSession(partialSession.id);
  assert.equal(partialRuns, 1, 'partial success is never blindly repeated');
  partialScheduler.stop();

  const uncertainSession = clone(base); uncertainSession.id = 'scheduler-uncertain';
  const uncertainStore = harness(uncertainSession);
  let uncertainRuns = 0;
  const uncertainScheduler = new ReliableScheduler({ store: uncertainStore, run: async () => { uncertainRuns++; throw Object.assign(new Error('transport lost after send'), { code: 'SEND_UNCERTAIN' }); }, log: () => {} });
  uncertainScheduler.stop();
  await uncertainScheduler.tickSession(uncertainSession.id);
  assert.equal(uncertainStore.current.scheduleState.lastAttempt.status, 'uncertain');
  await uncertainScheduler.tickSession(uncertainSession.id);
  assert.equal(uncertainRuns, 1, 'uncertain delivery is not retried automatically');
  uncertainScheduler.stop();

  const taskSession = clone(base); taskSession.id = 'scheduler-task'; taskSession.settings.scheduleEnabled = false;
  taskSession.automation.tasks = [{ id: 'task-1', name: 'اختبار', enabled: true, mode: schedule.mode, time: schedule.time, targetKeys: [], lastRunKey: '', lastAttempt: null }];
  const taskStore = harness(taskSession);
  let taskRuns = 0;
  const taskScheduler = new ReliableScheduler({ store: taskStore, runTask: async () => { taskRuns++; return { ok: false, sent: [{ recipient: 'first' }], failed: [{ retryable: true }] }; }, log: () => {} });
  taskScheduler.stop();
  await taskScheduler.tickSession(taskSession.id);
  assert.equal(taskStore.current.automation.tasks[0].lastAttempt.status, 'partial');
  assert.ok(taskStore.current.automation.tasks[0].lastRunKey);
  await taskScheduler.tickSession(taskSession.id);
  assert.equal(taskRuns, 1, 'scheduled task partial sends are not repeated on the next scheduler tick');
  taskScheduler.stop();

  console.log('scheduler-reliability: ok (serialized session lock, persisted attempt reservation, bounded retry, partial-send protection and uncertain-send no-retry)');
})().catch(error => { console.error(error); process.exitCode = 1; });
