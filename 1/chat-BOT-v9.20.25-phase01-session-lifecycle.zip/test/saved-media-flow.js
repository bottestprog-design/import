'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { OwnerAssistant } = require('../src/owner-assistant');

const clone = value => JSON.parse(JSON.stringify(value));
function harness({ fileCount = 2 } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-saved-media-'));
  const initial = {
    id: 'main', name: 'جلسة الاختبار', setupComplete: true,
    recipients: [{ id: 'ahmed', name: 'أحمد', digits: '96890000000', enabled: true }],
    groups: [], logs: [], settings: { automationEnabled: true },
    interaction: { rules: [], enabled: true }, automation: { tasks: [], enabled: true },
  };
  let current = clone(initial);
  const store = {
    safeSessionId: value => String(value || 'main'),
    loadSession: () => clone(current),
    saveSession: value => { current = clone(value); return clone(current); },
    getPaths: () => ({ dir: root, images: root, media: root }),
    get current() { return clone(current); },
    cleanup: () => fs.rmSync(root, { recursive: true, force: true }),
  };
  const messages = [];
  const whatsapp = {
    selfChatId: () => '15555555555@c.us',
    sendText: async (_id, chatId, text) => { messages.push({ chatId, text }); return { __chatBotAck: { status: 'accepted' } }; },
    listRuntime: () => ({ ready: true, status: 'ready' }),
  };
  const files = Array.from({ length: fileCount }, (_, index) => {
    const filename = index === 0 ? 'report.pdf' : index === 1 ? 'photo.jpg' : `file-${String(index + 1).padStart(3, '0')}.txt`;
    return { id: filename, filename, ext: path.extname(filename), size: 2048 + index, isImage: filename.endsWith('.jpg'), isVideo: false, isAudio: false, isVisualMedia: filename.endsWith('.jpg'), mediaKind: filename.endsWith('.jpg') ? 'media' : 'document' };
  });
  const deliveries = [];
  const delivery = {
    files: () => files.slice(),
    sendNow: async (_id, opts) => { deliveries.push(clone(opts)); return { ok: true, sent: [{ target: 'أحمد', targetId: 'ahmed' }], failed: [] }; },
  };
  const assistant = new OwnerAssistant({ store, whatsapp, phones: {}, log: () => {}, delivery });
  return { assistant, store, whatsapp, messages, files, deliveries, delivery, cleanup: store.cleanup };
}
async function send(h, body) { return h.assistant.handleSelfChatMessage('main', { body, fromMe: true }); }
(async () => {
  const h = harness();
  try {
    const start = await send(h, 'أرسل من الملفات المحفوظة');
    assert.equal(start.action, 'send-saved-media-started');
    assert.equal(h.store.current.ownerAssistant.flow.step, 'choose-file');
    assert.match(h.messages.at(-1).text, /report\.pdf/);
    assert.equal(h.deliveries.length, 0, 'opening the library must never send a file');

    await send(h, 'تمام');
    assert.equal(h.deliveries.length, 0, 'generic approval must not choose a file or send anything');
    assert.equal(h.store.current.ownerAssistant.flow.step, 'choose-file');

    await send(h, 'report.pdf');
    assert.equal(h.store.current.ownerAssistant.flow.step, 'choose-target');
    await send(h, 'أحمد');
    assert.equal(h.store.current.ownerAssistant.flow.step, 'caption');
    await send(h, 'بدون نص');
    assert.equal(h.store.current.ownerAssistant.flow.step, 'confirm');
    assert.match(h.messages.at(-1).text, /لم يُرسل أي ملف بعد/);
    await send(h, 'تمام');
    assert.equal(h.deliveries.length, 0, 'generic approval cannot bypass the exact send confirmation');
    await send(h, 'تأكيد الإرسال');
    assert.equal(h.deliveries.length, 1);
    assert.deepEqual(h.deliveries[0].targetKeys, ['r:ahmed']);
    assert.deepEqual(h.deliveries[0].mediaIds, ['report.pdf']);
    assert.equal(h.deliveries[0].repeatGuard, true);
    assert.equal(h.store.current.ownerAssistant.flow, null);
    assert.match(h.messages.at(-1).text, /تمرير الملف/);
  } finally { h.cleanup(); }

  const stale = harness();
  try {
    await send(stale, 'أرسل من الملفات المحفوظة');
    await send(stale, 'report.pdf');
    await send(stale, 'أحمد');
    await send(stale, 'بدون نص');
    const changed = stale.store.current; changed.recipients[0].enabled = false; stale.store.saveSession(changed);
    await send(stale, 'تأكيد الإرسال');
    assert.equal(stale.deliveries.length, 0, 'the recipient must be revalidated right before delivery');
    assert.equal(stale.store.current.ownerAssistant.flow, null);
    assert.match(stale.messages.at(-1).text, /لم أبدأ إرسالًا جديدًا/);
  } finally { stale.cleanup(); }

  const staleFile = harness();
  try {
    await send(staleFile, 'أرسل من الملفات المحفوظة');
    await send(staleFile, 'report.pdf');
    await send(staleFile, 'أحمد');
    await send(staleFile, 'بدون نص');
    staleFile.files.splice(0, 1);
    await send(staleFile, 'تأكيد الإرسال');
    assert.equal(staleFile.deliveries.length, 0, 'a file removed after review must not be sent');
    assert.match(staleFile.messages.at(-1).text, /الملف أو الجهة لم يعد موجودًا/);
  } finally { staleFile.cleanup(); }

  const uncertain = harness();
  try {
    let attempted = 0;
    uncertain.delivery.sendNow = async () => { attempted++; return { ok: false, sent: [], failed: [{ error: 'نتيجة غير مؤكدة' }] }; };
    await send(uncertain, 'أرسل من الملفات المحفوظة');
    await send(uncertain, 'report.pdf');
    await send(uncertain, 'أحمد');
    await send(uncertain, 'بدون نص');
    await send(uncertain, 'تأكيد الإرسال');
    assert.equal(attempted, 1, 'an uncertain outcome must not trigger a blind send retry');
    assert.match(uncertain.messages.at(-1).text, /لم أعد المحاولة تلقائيًا/);
    assert.equal(uncertain.store.current.ownerAssistant.flow, null);
  } finally { uncertain.cleanup(); }

  const paged = harness({ fileCount: 43 });
  try {
    await send(paged, 'أرسل من الملفات المحفوظة');
    assert.match(paged.messages.at(-1).text, /اكتب «التالي»/);
    await send(paged, 'التالي');
    assert.match(paged.messages.at(-1).text, /صفحة 2 من 2/);
    assert.match(paged.messages.at(-1).text, /file-043\.txt/);
    assert.equal(paged.deliveries.length, 0);
  } finally { paged.cleanup(); }

  console.log('saved-media-flow: ok (file browsing, target allowlist, strict confirmation, stale file/target guards, paging, uncertain-send no-retry)');
})().catch(error => { console.error(error); process.exitCode = 1; });
