'use strict';
const assert = require('node:assert/strict');
const { InteractionEngine } = require('../src/interaction');
const makeSession = (enabled) => ({
  id: 'main',
  settings: { interactionEnabled: true, interactionScope: 'all', interactionChatIds: [], interactionIgnoreOwn: true, maxActionsPerMinute: 20, interactionCooldownCapSec: 86400, timezone: 'UTC' },
  recipients: [{ id: 'alice', name: 'Alice', digits: '96890001111', enabled }],
  groups: [],
  interaction: { enabled: true, rules: [{ id: 'rule1', name: 'global', enabled: true, priority: 1, cooldownSec: 0, when: { type: 'message', match: 'any', value: '' }, then: { reply: 'هذا رد آلي' }, scope: 'all', chatIds: [] }], counterTriggers: [], variantState: {}, contextByChat: {}, counterState: {}, recent: [] },
  stats: {}, logs: []
});
let persisted = makeSession(false);
const clone = value => JSON.parse(JSON.stringify(value));
const store = { loadSession: () => clone(persisted), saveSession: value => { persisted = clone(value); return clone(persisted); } };
const sent = [];
const whatsapp = {
  replyToMessage: async (_id, _raw, text) => {
    sent.push(text);
    // Simulate the user stopping the recipient while a send is in flight.
    persisted.recipients[0].enabled = false;
  },
  reactToMessage: async () => { throw new Error('unexpected reaction'); }
};
const incoming = () => ({
  body: 'مرحبا', from: '96890001111@c.us', notifyName: 'Alice',
  id: { _serialized: 'incoming-1', remote: { _serialized: '96890001111@c.us' } },
  getChat: async () => ({ id: { _serialized: '96890001111@c.us' }, name: 'Alice' })
});
(async () => {
  const blockedEngine = new InteractionEngine({ store, whatsapp, log: () => {} });
  const blocked = await blockedEngine.onMessage('main', incoming());
  assert.equal(blocked.reason, 'recipient-disabled');
  assert.deepEqual(sent, [], 'a disabled recipient must not receive any automatic reply');

  persisted = makeSession(true);
  sent.length = 0;
  const activeEngine = new InteractionEngine({ store, whatsapp, log: () => {} });
  const first = await activeEngine.onMessage('main', incoming());
  assert.equal(first.action, 'rule', 'the active recipient may follow its configured global rule')
  assert.equal(sent.length, 1, 'the active recipient may receive its configured rule response');
  assert.equal(persisted.recipients[0].enabled, false, 'late persistence must not undo a concurrent stop');

  const second = await activeEngine.onMessage('main', { ...incoming(), id: { _serialized: 'incoming-2', remote: { _serialized: '96890001111@c.us' } } });
  assert.equal(second.reason, 'recipient-disabled');
  assert.equal(sent.length, 1, 'future replies must remain blocked after the stop');
  console.log('interaction-recipient-pause: ok (paused inbound blocked; in-flight persistence cannot undo stop)');
})().catch(error => { console.error(error); process.exitCode = 1; });
