'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { AudioTranscriber } = require('../src/audio-transcriber');
const { TextToSpeech } = require('../src/text-to-speech');
const { createOggOpusFixture } = require('./ogg-opus-fixture');

(async () => {
  let request;
  const audio = new AudioTranscriber({ env: { WHISPER_BACKEND: 'openai-compatible', WHISPER_API_KEY: 'test-key', WHISPER_API_URL: 'https://speech.example/v1/audio/transcriptions', WHISPER_API_MODEL: 'whisper-1' }, fetchImpl: async (url, opts) => { request = { url: String(url), opts }; return new Response(JSON.stringify({ text: 'تم التفريغ بنجاح' }), { status: 200, headers: { 'content-type': 'application/json' } }); } });
  const audioStatus = await audio.status(); assert.equal(audioStatus.ready, true);
  const transcript = await audio.transcribeBuffer(Buffer.from('fake audio'), { extension: '.ogg', language: 'ar' });
  assert.equal(transcript.transcript, 'تم التفريغ بنجاح'); assert.equal(transcript.backend, 'openai-compatible');
  assert.equal(transcript.quality.status, 'unverified', 'a remote provider response without token metrics must be reviewed, not used as a trusted voice command');
  assert.equal(transcript.quality.actionable, false);
  assert.equal(request.opts.headers.Authorization, 'Bearer test-key'); assert.ok(request.opts.body instanceof FormData);
  request = undefined; // reset after the deliberately selected remote ASR call; the TTS test below must remain idle until consent.

  const insecure = new AudioTranscriber({ env: { WHISPER_BACKEND: 'openai-compatible', WHISPER_API_KEY: 'test-key', WHISPER_API_URL: 'http://example.com/transcribe' }, fetchImpl: async () => { throw new Error('must not fetch insecure endpoint'); } });
  await assert.rejects(() => insecure.transcribeBuffer(Buffer.from('fake'), { extension: '.wav' }), /HTTPS أو localhost/);

  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tts-cloud-test-'));
  try {
    const ffmpeg = path.join(root, 'ffmpeg'); fs.writeFileSync(ffmpeg, 'mock');
    const model = path.join(root, 'unused.onnx');
    const tts = new TextToSpeech({ root, tempRoot: root, env: { TTS_BACKEND: 'openai-compatible', TTS_API_KEY: 'test-key', TTS_API_URL: 'https://speech.example/v1/audio/speech', FFMPEG_BIN: ffmpeg, TTS_REQUIRE_PROOFREAD: 'false' }, execFileImpl: async (binary, args) => { if (binary === 'which' || binary === 'where.exe') return { stdout: ffmpeg }; if (binary === ffmpeg) { fs.writeFileSync(args.at(-1), createOggOpusFixture()); return { stdout: '' }; } throw new Error('unexpected command'); }, fetchImpl: async (url, opts) => { request = { url: String(url), opts }; return new Response(Buffer.alloc(512, 7), { status: 200, headers: { 'content-type': 'audio/wav' } }); } });
    const blockedStatus = await tts.status(); assert.equal(blockedStatus.ready, false); assert.equal(blockedStatus.cloudConsentRequired, true);
    await assert.rejects(() => tts.generate('اختبار النطق', { proofread: false }), /موافقة السحابة/);
    assert.equal(request, undefined, 'no cloud HTTP request may occur before consent');
    const status = await tts.status({ allowCloud: true }); assert.equal(status.ready, true);
    const generated = await tts.generate('اختبار النطق', { proofread: false, allowCloud: true });
    assert.ok(fs.statSync(generated.wavPath).size >= 128); assert.equal(generated.backend, 'openai-compatible');
    const voice = await tts.toWhatsAppVoice(generated.wavPath); assert.ok(voice.endsWith('.ogg')); assert.ok(fs.existsSync(voice));
    assert.match(request.url, /audio\/speech$/); assert.equal(JSON.parse(request.opts.body).input, 'اختبار النطق');
    assert.equal(tts.cleanup(generated), true);
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
  console.log('cloud-voice-adapters: ok (explicit cloud opt-in, transcription, TTS, local conversion, HTTPS enforcement)');
})().catch(error => { console.error(error); process.exitCode = 1; });
