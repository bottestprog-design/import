'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { inspectOggOpusBuffer, inspectOggOpusFile, assertOggOpusFile } = require('../src/audio-format');
const { createOggOpusFixture } = require('./ogg-opus-fixture');
function ogg() { return createOggOpusFixture(); }
assert.equal(inspectOggOpusBuffer(ogg()).valid, true);
assert.equal(inspectOggOpusBuffer(Buffer.alloc(512, 0)).reason, 'not-ogg');
const vorbisLike = Buffer.alloc(512, 0); vorbisLike.write('OggS', 0, 'ascii'); vorbisLike[4] = 0; vorbisLike[5] = 2; vorbisLike[26] = 1; vorbisLike[27] = 20; vorbisLike.write('VorbisHeadNotOpus!', 28, 'ascii');
assert.equal(inspectOggOpusBuffer(vorbisLike).reason, 'opus-head-missing');
const brokenHead = ogg(); brokenHead[37] = 0; assert.equal(inspectOggOpusBuffer(brokenHead).reason, 'invalid-opus-channel-count');
const misplacedHead = Buffer.alloc(512, 0); misplacedHead.write('OggS', 0, 'ascii'); misplacedHead[4] = 0; misplacedHead[5] = 2; misplacedHead[26] = 1; misplacedHead[27] = 40; misplacedHead.write('OpusHead', 45, 'ascii'); assert.equal(inspectOggOpusBuffer(misplacedHead).reason, 'opus-head-missing', 'an OpusHead string outside the first Ogg packet must not be accepted');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-ogg-guard-'));
try {
  const valid = path.join(dir, 'valid.ogg'), invalid = path.join(dir, 'invalid.ogg');
  fs.writeFileSync(valid, ogg()); fs.writeFileSync(invalid, Buffer.alloc(512, 1));
  assert.equal(inspectOggOpusFile(valid).valid, true);
  assert.equal(assertOggOpusFile(valid).codec, 'opus');
  assert.throws(() => assertOggOpusFile(invalid), /ترويسة OGG/);
  assert.equal(inspectOggOpusFile(valid, { maxBytes: 128 }).reason, 'too-large');
} finally { fs.rmSync(dir, { recursive: true, force: true }); }
console.log('audio-format: ok (OGG container, OpusHead, size limits, and fail-closed send validation)');
