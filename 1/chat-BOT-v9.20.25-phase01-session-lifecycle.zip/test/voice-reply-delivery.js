'use strict';
const assert = require('node:assert/strict');
const { InteractionEngine } = require('../src/interaction');

(async () => {
  const calls = [];
  let live = { id: 'main', settings: { interactionVoiceRepliesEnabled: true, ttsRequireProofread: false, ttsBackend: 'local', ttsCloudConsent: false, ttsVoice: 'ar-EG-ShakirNeural' }, recipients: [], groups: [] };
  const store = { loadSession: () => live, saveSession: value => { live = value; return value; } };
  const whatsapp = {
    replyToMessage: async (_id, _raw, text) => { calls.push(['text', text]); return { ok: true }; },
    sendVoice: async (_id, chatId, file) => { calls.push(['voice', chatId, file]); return { ok: true }; },
  };
  let cleaned = false;
  const speechSynthesizer = {
    status: async () => ({ ready: true, ffmpegReady: true }),
    generate: async text => ({ text, backend: 'local', wavPath: '/tmp/mock.wav', directory: '/tmp/chatbot-tts-test' }),
    toWhatsAppVoice: async () => '/tmp/mock.ogg',
    cleanup: () => { cleaned = true; return true; },
  };
  const engine = new InteractionEngine({ store, whatsapp, log: () => {}, speechSynthesizer });
  await engine.replyToActiveChat('main', { from: '1234567890@c.us' }, '1234567890@c.us', 'أهلًا بك');
  assert.deepEqual(calls.map(x => x[0]), ['text', 'voice']);
  assert.equal(calls[1][1], '1234567890@c.us');
  assert.equal(cleaned, true, 'temporary TTS files are cleaned after sending');

  calls.length = 0; cleaned = false;
  await engine.replyToActiveChat('main', { from: '1234567890-123456@g.us' }, '1234567890-123456@g.us', 'رد مجموعة');
  assert.deepEqual(calls.map(x => x[0]), ['text'], 'group rules do not produce unsolicited voice notes');

  calls.length = 0; cleaned = false;
  live.settings.interactionVoiceRepliesEnabled = false;
  await engine.replyToActiveChat('main', { from: '1234567890@c.us' }, '1234567890@c.us', 'رد نصي فقط');
  assert.deepEqual(calls.map(x => x[0]), ['text'], 'voice replies are off by default and controlled by an explicit setting');

  // Cloud consent can be revoked while an external TTS job is still generating.
  // The text reply remains, but no external audio is delivered after revocation.
  calls.length = 0; cleaned = false;
  live.settings.interactionVoiceRepliesEnabled = true;
  live.settings.ttsBackend = 'edge-tts';
  live.settings.ttsCloudConsent = true;
  speechSynthesizer.generate = async text => {
    live.settings.ttsCloudConsent = false;
    return { text, backend: 'edge-tts', wavPath: '/tmp/mock-cloud.wav', directory: '/tmp/chatbot-tts-test' };
  };
  await engine.replyToActiveChat('main', { from: '1234567890@c.us' }, '1234567890@c.us', 'رد مع موافقة سحابية');
  assert.deepEqual(calls.map(x => x[0]), ['text'], 'revoking cloud consent during generation must block external voice delivery');
  assert.equal(cleaned, true, 'a generated but undelivered cloud result must still be cleaned');
  live.settings.ttsBackend = 'local';
  live.settings.ttsCloudConsent = false;
  speechSynthesizer.generate = async text => ({ text, backend: 'local', wavPath: '/tmp/mock.wav', directory: '/tmp/chatbot-tts-test' });

  live.settings.interactionVoiceRepliesEnabled = true;
  live.recipients = [{ id: 'recipient-1', phone: '1234567890', enabled: false }];
  await assert.rejects(() => engine.replyToActiveChat('main', { from: '1234567890@c.us' }, '1234567890@c.us', 'لا ترسل'), /المستلم موقوف/);
  const fs = require('node:fs'), path = require('node:path');
  const app = fs.readFileSync(path.join(__dirname, '..', 'public', 'app.js'), 'utf8');
  const server = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf8');
  assert.match(app, /id=\"interactionVoiceRepliesEnabled\"/);
  assert.ok(app.includes("interactionVoiceRepliesEnabled: $('#interactionVoiceRepliesEnabled')?.checked !== false"));
  assert.match(server, /'interactionVoiceRepliesEnabled'/);
  console.log('voice-reply-delivery: ok (local voice replies, cloud consent revocation gate, no group voice, text preserved, recipient stop gate, cleanup, settings wiring)');
})().catch(error => { console.error(error); process.exitCode = 1; });
