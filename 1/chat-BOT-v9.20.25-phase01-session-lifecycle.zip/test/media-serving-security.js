'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const media = require('../src/media');
const root = path.resolve(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');

for (const name of ['photo.png', 'picture.avif', 'clip.mp4', 'clip.webm', 'voice.ogg', 'voice.wav']) {
  assert.equal(media.isInlineBrowserMedia(name), true, `${name} remains displayable/streamable in the browser`);
}
for (const name of ['payload.html', 'payload.htm', 'payload.js', 'payload.py', 'document.pdf', 'archive.zip', 'data.json']) {
  assert.equal(media.isInlineBrowserMedia(name), false, `${name} must not execute/render inline in the dashboard origin`);
  assert.match(media.contentDisposition(name), /^attachment; filename=/);
}
const hostileName = 'bad"name\r\nX-Test: injected.html';
const disposition = media.contentDisposition(hostileName);
assert.equal(/[\r\n\u0000]/u.test(disposition), false, 'untrusted filenames cannot inject response headers');
assert.match(disposition, /filename\*=UTF-8''/);
assert.ok(disposition.length < 700, 'response header length is bounded');

const routeStart = server.indexOf("app.get('/media/:filename'");
const routeEnd = server.indexOf("app.post('/api/send'", routeStart);
assert.ok(routeStart >= 0 && routeEnd > routeStart, 'media serving route must exist');
const route = server.slice(routeStart, routeEnd);
assert.match(route, /X-Content-Type-Options', 'nosniff'/);
assert.match(route, /Cache-Control', 'private, no-store'/);
assert.match(route, /!media\.isInlineBrowserMedia\(name\)/);
assert.match(route, /media\.contentDisposition\(name\)/);
assert.match(route, /media\.safePath\(/);
console.log('media-serving-security: ok (inline safe media only, attachment headers for documents/code, nosniff, no-store and header-injection resistance)');
