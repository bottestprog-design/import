const assert = require('node:assert/strict');
const os = require('node:os');
const { DeliveryService } = require('../src/delivery');
let persisted = {
  id: 'main', recipients: [{ id: 'alice', name: 'Alice', enabled: true, digits: '96890001111' }], groups: [],
  settings: { timezone: 'UTC', preText: '', postText: '', sendDelayMs: 0, sendTimeoutMs: 1000, retryAttempts: 3, retryDelayMs: 0 },
  stats: { sentMessages: 0, sentImages: 0, sentFiles: 0, confirmedAcks: 0, createdSends: 0, uncertainSends: 0, failedSends: 0 },
  cycle: { delivery: {}, manualGuard: {}, round: 1 }
};
const clone = value => JSON.parse(JSON.stringify(value));
const store = {
  safeSessionId: value => String(value || 'main'),
  loadSession: () => clone(persisted),
  saveSession: value => { persisted = clone(value); return clone(persisted); },
  getPaths: () => ({ images: os.tmpdir() })
};
const sent = [];
const whatsapp = {
  resolveChatId: async () => '96890001111@c.us',
  sendText: async (_id, _chatId, body) => {
    sent.push(body);
    if (sent.length === 1) persisted.recipients[0].enabled = false;
    return { __chatBotAck: { status: 'confirmed' } };
  },
  sendMedia: async () => { throw new Error('unexpected media send'); }
};
(async () => {
  const delivery = new DeliveryService({ store, whatsapp, log: () => {} });
  await assert.rejects(
    () => delivery.sequence('main', { id: 'alice', targetId: 'alice', kind: 'recipient', name: 'Alice', enabled: true }, null,
      { scheduled: false, preText: 'first message', postText: 'must not be sent', countTowardCycle: false }),
    error => error?.code === 'RECIPIENT_DISABLED'
  );
  assert.deepEqual(sent, ['first message'], 'no later stage may send after the recipient is disabled');
  assert.equal(persisted.recipients[0].enabled, false, 'saving send progress must not undo the stop action');
  assert.equal(persisted.stats.sentMessages, 1, 'send counter must be persisted once');
  console.log('delivery-recipient-pause: ok (pause takes effect between send stages and survives progress persistence)');
})().catch(error => { console.error(error); process.exitCode = 1; });
