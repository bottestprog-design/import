'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const media = require('../src/media');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-media-hash-'));
try {
  const fixture = path.join(root, 'large-fixture.bin');
  const fd = fs.openSync(fixture, 'w');
  try {
    const chunk = Buffer.alloc(1024 * 1024);
    for (let i = 0; i < 24; i++) {
      chunk.fill(i);
      fs.writeSync(fd, chunk, 0, chunk.length);
    }
  } finally { fs.closeSync(fd); }
  const expected = crypto.createHash('sha256');
  const read = fs.createReadStream(fixture, { highWaterMark: 128 * 1024 });
  const actual = media.hashFile(fixture);
  assert.equal(fs.statSync(fixture).size, 24 * 1024 * 1024);
  // Independent streaming calculation, so the expected digest never needs the entire file in memory.
  const verify = async () => {
    for await (const chunk of read) expected.update(chunk);
    assert.equal(actual, expected.digest('hex'), 'chunked SHA-256 must match the standard digest');
  };
  verify().then(() => console.log('media-hash-streaming: ok (24 MiB fixture; streaming digest matches SHA-256)')).catch(error => { console.error(error); process.exitCode = 1; });
} finally {
  // Defer cleanup until the read stream finishes.
  process.on('exit', () => { try { fs.rmSync(root, { recursive: true, force: true }); } catch {} });
}
