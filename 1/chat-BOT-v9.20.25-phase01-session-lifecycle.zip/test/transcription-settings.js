'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const { validateTranscriptionSettings, readCurrentTranscriptionSettings } = require('../src/transcription-settings');
const { AudioTranscriber } = require('../src/audio-transcriber');
const { VoiceBootstrap } = require('../src/voice-bootstrap');

const current = {
  modelSize: 'small', device: 'cpu', computeType: 'int8', beamSize: '5', vad: 'true',
  vadThreshold: '0.5', minSilenceMs: '450', logProbThreshold: '-1.0', noSpeechThreshold: '0.6',
  compressionRatioThreshold: '2.4', conditionOnPreviousText: 'false',
};
const upgraded = validateTranscriptionSettings({ modelSize: 'medium', beamSize: 8, vad: false, minSilenceMs: 700, device: 'auto' }, current);
assert.equal(upgraded.modelChanged, true);
assert.equal(upgraded.restartRequired, true);
assert.equal(upgraded.env.WHISPER_PY_MODEL, 'medium');
assert.equal(upgraded.env.WHISPER_PY_MODEL_PATH, 'models/faster-whisper-medium');
assert.equal(upgraded.env.WHISPER_PY_BEAM_SIZE, '8');
assert.equal(upgraded.env.WHISPER_PY_VAD, 'false');
assert.equal(upgraded.env.WHISPER_PY_MIN_SILENCE_MS, '700');
assert.equal(upgraded.settings.device, 'auto');

const tuningOnly = validateTranscriptionSettings({ beamSize: 6, vadThreshold: 0.65 }, current);
assert.equal(tuningOnly.modelChanged, false);
assert.equal(tuningOnly.restartRequired, false);
assert.equal(tuningOnly.env.WHISPER_PY_MODEL_PATH, undefined, 'tuning changes do not overwrite a custom model folder');
assert.equal(tuningOnly.env.WHISPER_PY_BEAM_SIZE, '6');
assert.equal(tuningOnly.env.WHISPER_PY_VAD, 'true', 'unspecified settings survive a partial update');
assert.throws(() => validateTranscriptionSettings({ modelSize: '../../outside' }, current), /حجم النموذج/);
assert.throws(() => validateTranscriptionSettings({ beamSize: 99 }, current), /Beam size/);
assert.throws(() => validateTranscriptionSettings({ vadThreshold: 2 }, current), /VAD threshold/);
assert.throws(() => validateTranscriptionSettings({ device: 'remote' }, current), /الجهاز/);
assert.throws(() => validateTranscriptionSettings({ computeType: 'float16' }, current), /نوع الحساب/, 'FP16 is not exposed as a safe cross-device default without explicit CUDA validation');

const read = readCurrentTranscriptionSettings({ WHISPER_PY_MODEL: 'large-v3-turbo', WHISPER_PY_BEAM_SIZE: '9', WHISPER_PY_VAD: 'false' });
assert.equal(read.modelSize, 'large-v3-turbo');
assert.equal(read.beamSize, '9');
assert.equal(read.vad, 'false');

const transcriber = new AudioTranscriber({ env: { WHISPER_PY_MODEL: 'medium' } });
assert.ok(transcriber.config().pyModelPath.endsWith(path.join('models', 'faster-whisper-medium')), 'model-size fallback must not silently load the small model');
const bootstrapRoot = path.resolve(__dirname, '..');
const bootstrap = new VoiceBootstrap({ root: bootstrapRoot, env: { WHISPER_PY_MODEL: 'large-v3-turbo' } });
assert.equal(bootstrap.modelSize, 'large-v3-turbo');
assert.ok(bootstrap.modelDir.endsWith(path.join('models', 'faster-whisper-large-v3-turbo')));
console.log('transcription-settings: ok (safe model sizes, restart semantics, tuning validation, custom folder preservation and model-path consistency)');
