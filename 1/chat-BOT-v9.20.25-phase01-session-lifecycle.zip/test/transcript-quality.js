'use strict';
const assert = require('node:assert/strict');
const { evaluateTranscriptQuality, normalizeTranscriptText, normalizeLanguage, summarizeQuality } = require('../src/transcript-quality');
const { canExecuteTranscript, transcriptReviewRequired } = require('../src/voice-transcript-guard');

const clean = {
  transcript: 'مَرْحَبًا، هذا اختبار واضح.', language: 'ar', requestedLanguage: 'ar',
  languageProbability: 0.98, avgLogProbability: -0.16, avgNoSpeechProbability: 0.02,
  maxCompressionRatio: 1.18, segments: 3, lowConfidenceSegments: 0,
};
const good = evaluateTranscriptQuality(clean, { requestedLanguage: 'ar' });
assert.equal(good.status, 'clear');
assert.equal(good.actionable, true);
assert.equal(good.metadataSufficient, true);
assert.equal(good.notStatisticallyCalibrated, true, 'heuristic score must never claim statistical calibration');
assert.equal(good.method, 'whisper-segment-metadata-heuristic-v1');
assert.ok(good.score > 0.9);
assert.equal(canExecuteTranscript({ ...clean, quality: good }), true);
assert.equal(transcriptReviewRequired({ ...clean, quality: good }), false);
assert.equal(normalizeTranscriptText(clean.transcript), clean.transcript, 'the recognizer preserves optional Arabic diacritics rather than stripping or hallucinating them');
assert.equal(normalizeTranscriptText('می\u200cروم 👩\u200d💻'), 'می\u200cروم 👩\u200d💻', 'Arabic ZWNJ and emoji ZWJ shaping must be preserved');

const mismatch = evaluateTranscriptQuality({ ...clean, language: 'en' }, { requestedLanguage: 'ar' });
assert.equal(mismatch.status, 'rejected');
assert.equal(mismatch.actionable, false);
assert.ok(mismatch.reasons.includes('language-mismatch'));

const lowProbability = evaluateTranscriptQuality({ ...clean, languageProbability: 0.1 });
assert.equal(lowProbability.status, 'rejected');
assert.ok(lowProbability.reasons.includes('language-detection-very-weak'));

const lowTokens = evaluateTranscriptQuality({ ...clean, avgLogProbability: -1.8 });
assert.equal(lowTokens.status, 'rejected');
assert.ok(lowTokens.reasons.includes('very-low-token-probability'));

const silence = evaluateTranscriptQuality({ ...clean, avgNoSpeechProbability: 0.92, avgLogProbability: -1.4 });
assert.equal(silence.status, 'rejected');
assert.ok(silence.reasons.includes('high-no-speech-probability'));
const speechWithBackground = evaluateTranscriptQuality({ ...clean, avgNoSpeechProbability: 0.82, avgLogProbability: -0.2 });
assert.equal(speechWithBackground.status, 'review', 'high no-speech probability alone should not reject otherwise strong speech; the upstream rule considers token probability too');

const repetition = evaluateTranscriptQuality({ ...clean, maxCompressionRatio: 3.8 });
assert.equal(repetition.status, 'rejected');
assert.ok(repetition.reasons.includes('repetition-or-hallucination-risk'));

const partial = evaluateTranscriptQuality({ ...clean, avgLogProbability: -0.98, lowConfidenceSegments: 1 });
assert.equal(partial.status, 'review');
assert.equal(partial.actionable, false);
assert.equal(canExecuteTranscript({ ...clean, quality: partial }), false);
assert.match(summarizeQuality(partial), /غير مؤكدة|منخفض|تحتاج/);

const noMetadata = evaluateTranscriptQuality({ transcript: 'Please send the image.', language: 'en', requestedLanguage: 'en', backend: 'openai-compatible' });
assert.equal(noMetadata.status, 'unverified');
assert.equal(noMetadata.metadataSufficient, false);
assert.equal(noMetadata.actionable, false);
assert.equal(transcriptReviewRequired({ transcript: noMetadata.transcript, quality: noMetadata }), true);

const wrongExpected = evaluateTranscriptQuality({ ...clean, language: 'ar' }, { requestedLanguage: 'en' });
assert.equal(wrongExpected.status, 'rejected');
assert.equal(normalizeLanguage('ar-SA'), 'ar');
assert.equal(normalizeLanguage('French'), 'fr');
assert.equal(normalizeLanguage('unknown'), 'unknown');
console.log('transcript-quality: ok (language match, Whisper token/silence/compression metrics, segment quality, metadata-sufficiency execution gate, unverified backend safety, Arabic diacritic preservation)');
