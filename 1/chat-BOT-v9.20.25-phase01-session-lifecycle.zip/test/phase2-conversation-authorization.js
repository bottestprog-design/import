'use strict';
const assert = require('node:assert/strict');
process.env.NODE_ENV = 'test';
const Module = require('node:module');
const originalLoad = Module._load;
Module._load = function(request, parent, isMain) {
  if (request === 'whatsapp-web.js') return { Client: class Client {}, LocalAuth: class LocalAuth {}, MessageMedia: class MessageMedia {} };
  if (request === 'qrcode') return {};
  return originalLoad.call(this, request, parent, isMain);
};
const targets = require('../src/conversation-targets');
const { WhatsAppManager } = require('../src/whatsapp');
const { OwnerAssistant } = require('../src/owner-assistant');
const { InteractionEngine } = require('../src/interaction');
const { AutomationEngine } = require('../src/automation-engine');
const fs = require('node:fs');
const path = require('node:path');

const selfId = '96895550000@c.us';
let session = {
  id: 'main',
  settings: { interactionEnabled: true, interactionIgnoreOwn: true, interactionScope: 'all', automationEnabled: true, timezone: 'Asia/Muscat' },
  recipients: [
    { id: 'active', name: 'مستخدم نشط', phone: '+96890000000', digits: '96890000000', whatsappJid: '96890000000@c.us', enabled: true },
    { id: 'paused', name: 'مستخدم موقوف', phone: '+96891111111', digits: '96891111111', whatsappJid: '96891111111@c.us', enabled: true, paused: true },
    { id: 'stopped', name: 'مستخدم متوقف', chatId: '96892222222@c.us', stopped: true },
    { id: 'lid-only', name: 'LID فقط', whatsappJid: '123456789012345@lid', enabled: true },
  ],
  groups: [{ id: 'group', name: 'مجموعة نشطة', gid: '120363000000@g.us', enabled: true }, { id: 'paused-group', name: 'مجموعة موقوفة', gid: '120363000001@g.us', paused: true }],
  interaction: { enabled: true, rules: [{ id: 'catch-all', enabled: true, when: { type: 'message', match: 'contains', value: 'hello' }, then: { reply: 'reply' } }], recent: [], contextByChat: {}, counterState: { totalCount: 0, byChat: {}, fired: {}, pending: {} } },
  automation: { enabled: true, rules: [{ id: 'log', enabled: true, triggerType: 'message', action: 'log', pattern: 'hello', matchMode: 'contains', targetMode: 'all' }], tasks: [], mutes: [], eventState: { totalMessages: 0, byChat: {}, seenMessages: {}, ruleCounts: {} } },
  stats: {},
};
const store = {
  safeSessionId: value => String(value || 'main'),
  loadSession: () => session,
  saveSession: value => { session = value; return value; },
};

assert.equal(targets.resolveChatAccess(session, selfId, selfId).key, 'self');
assert.equal(targets.resolveChatAccess(session, '96890000000@c.us').key, 'r:active');
assert.equal(targets.resolveChatAccess(session, '120363000000@g.us').key, 'g:group');
assert.equal(targets.resolveChatAccess(session, '96891111111@c.us').reason, 'disabled');
assert.equal(targets.resolveChatAccess(session, '96892222222@c.us').reason, 'disabled');
assert.equal(targets.resolveChatAccess(session, '120363000001@g.us').reason, 'disabled');
assert.equal(targets.resolveChatAccess(session, '99999999999@c.us').reason, 'unregistered');
assert.equal(targets.resolveChatAccess(session, '123456789012345@lid').key, 'r:lid-only');
assert.equal(targets.resolveChatAccess(session, '123456789012345@lid').target.chatId, '123456789012345@lid');
assert.equal(targets.targetKeyForChat(session, '99999999999@lid'), '', 'LID digits must never be interpreted as a phone number');

(async () => {
  const manager = new WhatsAppManager({ store, log: () => {} });
  manager.entry('main').selfChatOverride = selfId;
  let sendCalled = false;
  await assert.rejects(() => manager.sendConfirmed('main', '99999999999@c.us', async () => { sendCalled = true; return { id: 'never' }; }, 1000, 'test'), error => error.code === 'CHAT_UNREGISTERED' && error.statusCode === 403);
  await assert.rejects(() => manager.sendConfirmed('main', '96891111111@c.us', async () => { sendCalled = true; return { id: 'never' }; }, 1000, 'test'), error => error.code === 'RECIPIENT_DISABLED' && error.statusCode === 403);
  assert.equal(sendCalled, false, 'central send gate must reject before the WhatsApp operation runs');
  assert.equal(manager.assertChatAuthorized('main', selfId).key, 'self');

  // A pause that occurs while a WhatsApp chat object is being resolved must
  // stop the action immediately before the underlying archive/mute/delete call.
  let mutationCalled = false;
  manager.getChatSafe = async () => {
    session.recipients.find(person => person.id === 'active').paused = true;
    return { id: '96890000000@c.us', archive: async () => { mutationCalled = true; } };
  };
  await assert.rejects(() => manager.actOnChat('main', '96890000000@c.us', 'archive'), error => error.code === 'RECIPIENT_DISABLED');
  assert.equal(mutationCalled, false, 'chat mutations must re-check authorization after resolving the WhatsApp chat');
  session.recipients.find(person => person.id === 'active').paused = false;

  // A pause that occurs while a WhatsApp chat object is being resolved must
  // stop the action immediately before the underlying archive/mute/delete call.
  // LID delivery is possible only through an exact official LID→PN mapping or
  // a separately stored phone field; opaque LID digits are never reused as a phone.
  let lookedUpDigits = [];
  const mappedClient = {
    getContactLidAndPhone: async ids => { assert.deepEqual(ids, ['123456789012345@lid']); return [{ lid: '123456789012345@lid', pn: '96893334444@c.us' }]; },
    getNumberId: async digits => { lookedUpDigits.push(digits); return { _serialized: `${digits}@c.us` }; },
  };
  manager.ensureReady = async () => mappedClient;
  assert.equal(await manager.resolveChatId('main', { name: 'LID mapped', whatsappJid: '123456789012345@lid' }), '96893334444@c.us');
  assert.deepEqual(lookedUpDigits, ['96893334444']);
  const noMapClient = { getContactLidAndPhone: async () => [], getNumberId: async digits => { lookedUpDigits.push(digits); return { _serialized: `${digits}@c.us` }; } };
  manager.ensureReady = async () => noMapClient;
  const beforeOpaque = lookedUpDigits.length;
  await assert.rejects(() => manager.resolveChatId('main', { name: 'LID unmapped', whatsappJid: '123456789012345@lid' }), /لم يتم تخمين رقم من LID/);
  assert.equal(lookedUpDigits.length, beforeOpaque, 'unmapped LID must not trigger a phone-number lookup');
  manager.ensureReady = async () => mappedClient;
  await assert.rejects(() => manager.resolveChatId('main', { name: 'Mismatched LID', whatsappJid: '123456789012345@lid', phone: '96890000000' }), /لا يطابق ربط WhatsApp الرسمي/);

  // The interaction and automation engines reject the same unknown/paused chat
  // before incrementing counters, persisting context, matching rules, or replying.
  let sent = 0;
  const interaction = new InteractionEngine({ store, whatsapp: { selfChatId: () => selfId, sendText: async () => { sent++; }, replyToMessage: async () => { sent++; } }, log: () => {} });
  const unknownMessage = { from: '99999999999@c.us', body: 'hello', timestamp: Math.floor(Date.now() / 1000), id: { _serialized: 'unknown-message', remote: '99999999999@c.us' }, getChat: async () => ({ id: '99999999999@c.us' }) };
  const interactionResult = await interaction.onMessage('main', unknownMessage);
  assert.equal(interactionResult.action, 'blocked');
  assert.equal(session.interaction.counterState.totalCount, 0);
  assert.equal(session.interaction.contextByChat['99999999999@c.us'], undefined);
  assert.equal(sent, 0);

  const automation = new AutomationEngine({ store, whatsapp: { selfChatId: () => selfId, sendText: async () => { sent++; } } });
  const automationResult = await automation.handleMessage('main', unknownMessage);
  assert.equal(automationResult.reason, 'unregistered-chat');
  assert.equal(session.automation.eventState.totalMessages, 0);
  assert.equal(session.automation.eventState.byChat['99999999999@c.us'], undefined);
  assert.equal(sent, 0);
  const pausedResult = await automation.handleMessage('main', { ...unknownMessage, from: '96891111111@c.us', id: { _serialized: 'paused-message', remote: '96891111111@c.us' } });
  assert.equal(pausedResult.reason, 'recipient-disabled');
  assert.equal(session.automation.eventState.totalMessages, 0);

  const cacheEngine = new InteractionEngine({ store, whatsapp: { selfChatId: () => selfId }, log: () => {} });
  const oldChat = '96895551111@c.us', retainedChat = '96895552222@c.us';
  cacheEngine.rate.set(`main|${oldChat}`, { count: 3 });
  cacheEngine.rate.set(`main|${retainedChat}`, { count: 1 });
  cacheEngine.quietCool.set(`main|${oldChat}`, Date.now());
  cacheEngine.fallbackCool.set(`main|${oldChat}`, Date.now());
  cacheEngine.cool.set(`main|rule|${oldChat}`, Date.now());
  cacheEngine.recipientCool.set(`main|person|${oldChat}`, Date.now());
  cacheEngine.conversationHistory.set(`main|${oldChat}`, [{ role: 'user', content: 'private history' }]);
  cacheEngine.seen.set(`main|message|${oldChat}|msg-1|hello|`, Date.now());
  cacheEngine.seen.set(`quiet|main|${oldChat}|stable`, Date.now());
  assert.ok(cacheEngine.clearChatState('main', [oldChat]) >= 7);
  for (const map of [cacheEngine.rate, cacheEngine.quietCool, cacheEngine.fallbackCool, cacheEngine.cool, cacheEngine.recipientCool, cacheEngine.conversationHistory, cacheEngine.seen]) {
    assert.equal([...map.keys()].some(key => key.includes(oldChat)), false, 'deleted-chat local cache must be removed');
  }
  assert.equal(cacheEngine.rate.has(`main|${retainedChat}`), true, 'deleting one contact must preserve unrelated contact caches');

  const assistantStore = {
    safeSessionId: value => String(value),
    loadSession: () => session,
    saveSession: value => { session = value; return value; },
  };
  let identityCleared = null;
  const assistant = new OwnerAssistant({ store: assistantStore, whatsapp: { selfChatId: () => 'new-owner@c.us' }, phones: { parse: () => ({}) }, log: () => {}, interactionEngine: { clearChatState: (sessionId, chats) => { identityCleared = { sessionId, chats }; } } });
  assert.equal((await assistant.resolveTarget(session, 'مستخدم نشط')).chatId, '96890000000@c.us');
  await assert.rejects(() => assistant.resolveTarget(session, '99999999999@c.us'), /لا يُسمح بالإرسال إلى معرّف غير مسجل/);
  await assert.rejects(() => assistant.resolveTarget(session, '120363000001@g.us'), /محفوظة ومفعّلة/);

  assistant.lastReplies.set('main', { text: 'محتوى خاص من حساب سابق' });
  const identitySession = {
    id: 'main',
    ownerAssistant: { boundSelfChatId: 'old-owner@c.us', conversation: [{ role: 'user', text: 'سر قديم' }], flow: { type: 'send-message', data: { target: 'old' } }, lastReply: { text: 'سر قديم' }, recent: [{ type: 'local-chat' }] },
    commandBridge: { pending: { command: 'dangerous-old-command' } },
  };
  assert.equal(assistant.bindOwnerIdentity('main', identitySession), true);
  assert.equal(identitySession.ownerAssistant.boundSelfChatId, 'new-owner@c.us');
  assert.deepEqual(identitySession.ownerAssistant.conversation, []);
  assert.equal(identitySession.ownerAssistant.flow, null);
  assert.equal(identitySession.ownerAssistant.lastReply, null);
  assert.equal(identitySession.commandBridge.pending, null);
  assert.equal(assistant.lastReplies.has('main'), false);
  assert.deepEqual(identityCleared, { sessionId: 'main', chats: ['old-owner@c.us'] });
  assert.equal(identitySession.ownerAssistant.recent.some(item => item.type === 'owner-identity-reset'), true);

  const server = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf8');
  const bulkDeleteRoute = server.slice(server.indexOf("app.delete('/api/recipients/bulk'"), server.indexOf("app.delete('/api/recipient/:id'"));
  assert.match(bulkDeleteRoute, /interaction\.clearChatState\(s\.id, result\.removedChats\)/, 'bulk contact deletion must clear in-memory interaction context and cooldowns');
  const deleteRoute = server.slice(server.indexOf("app.delete('/api/recipient/:id'"), server.indexOf("app.post('/api/groups/discover'"));
  assert.match(deleteRoute, /recipientManagement\.deleteRecipients\(s, \[String\(req\.params\.id\)\]\)/, 'single delete must reuse full cleanup logic');
  const groupDeleteRoute = server.slice(server.indexOf("app.delete('/api/groups/:id'"), server.indexOf("app.post('/api/transcription/transcribe-latest'"));
  assert.match(groupDeleteRoute, /counterState\?\.fired[\s\S]*?delete s\.interaction\.counterState\.fired\[chat\]/, 'group deletion must clear chat-scoped fired counter state');
  assert.match(groupDeleteRoute, /counterState\?\.pending[\s\S]*?delete s\.interaction\.counterState\.pending\[chat\]/, 'group deletion must clear chat-scoped pending counter state');
  const toggleRoute = server.slice(server.indexOf("app.post('/api/recipient/:id/toggle'"), server.indexOf("app.get('/api/recipient/:id/reply-profile'"));
  assert.match(toggleRoute, /r\.paused = false; r\.stopped = false/, 'reactivating a recipient must clear every pause/stop flag');
  assert.match(deleteRoute, /interaction\.clearChatState\(s\.id, result\.removedChats\)/, 'single contact deletion must clear in-memory interaction context and cooldowns');
  assert.match(groupDeleteRoute, /interaction\.clearChatState\(s\.id, \[\.\.\.removedChats\]\)/, 'group deletion must clear in-memory interaction context and cooldowns');
  const bridgeSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'local-command-bridge.js'), 'utf8');
  assert.match(bridgeSource, /لا يُسمح بالإرسال إلى أرقام غير مسجلة/, 'one-line sends must reject raw phone numbers that do not map to a saved recipient');
  assert.match(bridgeSource, /const activeSaved = saved\.filter\(person => person\.enabled !== false && person\.paused !== true && person\.stopped !== true\)/, 'one-line numeric target resolution must enforce the active recipient state');
  const ownerSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'owner-assistant.js'), 'utf8');
  assert.match(ownerSource, /registeredChatTargets\(s, this\.whatsapp\.selfChatId\(id\)\)\.filter\(chat => conversationTargets\.targetIsEnabled\(chat\)\)/, 'private archive media extraction must not read media from paused contacts');
  assert.match(fs.readFileSync(path.join(__dirname, '..', 'src', 'whatsapp.js'), 'utf8'), /async downloadMediaFromChat[\s\S]*?this\.assertChatAuthorized\(sid, chatId\)[\s\S]*?this\.assertChatAuthorized\(sid, actualChatId\)[\s\S]*?this\.assertChatAuthorized\(sid, actualChatId\)/, 'direct media download must re-check active authorization around chat and message reads');

  console.log('phase2-conversation-authorization: ok (strict inbound/outbound allowlist, paused/stopped gates, LID-safe resolution, isolated owner identity, send API gate, and consistent deletion cleanup)');
})().catch(error => { console.error(error); process.exitCode = 1; });
