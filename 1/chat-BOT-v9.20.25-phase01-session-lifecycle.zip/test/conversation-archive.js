'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { ConversationArchive, sanitizeRecord, normalizeSearch } = require('../src/conversation-archive');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-conversation-archive-'));
const store = { safeSessionId: value => String(value || 'main'), getPaths: id => ({ dir: path.join(root, String(id)) }) };
try {
  const archive = new ConversationArchive({ store });
  for (let i = 1; i <= 5; i++) {
    const result = archive.record('main', { chatId: '96890000000@c.us', targetKey: 'r:ahmed', messageId: `m${i}`, timestamp: 1790000000 + i, fromMe: i % 2 === 0, body: `رسالة اختبار ${i}` });
    assert.equal(result.stored, true);
  }
  assert.equal(archive.record('main', { chatId: '96890000000@c.us', targetKey: 'r:ahmed', messageId: 'm5', timestamp: 1790000005, body: 'duplicate' }).reason, 'duplicate');
  const page = archive.list('main', 'r:ahmed', { limit: 2 });
  assert.equal(page.messages.length, 2); assert.equal(page.hasOlder, true);
  const older = archive.list('main', 'r:ahmed', { limit: 2, before: page.nextBefore });
  assert.equal(older.messages.length, 2); assert.ok(older.messages[1].timestampMs < page.messages[0].timestampMs);
  assert.equal(archive.search('main', 'رسالة اختبار 3')[0].body, 'رسالة اختبار 3');
  assert.equal(archive.summary('main', 'r:ahmed')[0].count, 5);
  // A scoped search must apply the target filter before the result limit.
  for (let i = 1; i <= 8; i++) archive.record('main', { chatId: '96891111111@c.us', targetKey: 'r:flood', messageId: `search-other-${i}`, timestamp: 1791000000 + i, body: 'كلمة مشتركة' });
  archive.record('main', { chatId: '96890000000@c.us', targetKey: 'r:ahmed', messageId: 'search-ahmed', timestamp: 1790000010, body: 'كلمة مشتركة لأحمد' });
  assert.equal(archive.search('main', 'كلمة مشتركة', { limit: 1, targetKey: 'r:ahmed' })[0].targetKey, 'r:ahmed', 'scoped query should not be crowded out by another contact');
  assert.equal(archive.search('main', 'كلمة مشتركة', { limit: 1, targetKeys: ['r:ahmed'] })[0].targetKey, 'r:ahmed', 'allowlisted global search should filter unregistered/unselected targets before the limit');
  assert.equal(normalizeSearch('إِختبـار'), 'اختبار');
  const clean = sanitizeRecord({ chatId: '96890000000@c.us', targetKey: 'self', messageId: 'x', filename: '../../evil.wav', body: 'السلام' });
  assert.equal(clean.filename, 'evil.wav');
  assert.equal(sanitizeRecord({ chatId: '', targetKey: 'self', body: 'x' }), null);
  const batch = archive.recordMany('main', [
    { chatId: '96891111111@c.us', targetKey: 'r:other', messageId: 'batch-1', timestamp: 1790000101, body: 'استيراد واحد' },
    { chatId: '96891111111@c.us', targetKey: 'r:other', messageId: 'batch-2', timestamp: 1790000102, body: 'استيراد اثنين' },
    { chatId: '96891111111@c.us', targetKey: 'r:other', messageId: 'batch-2', timestamp: 1790000102, body: 'تكرار' },
    { chatId: '', targetKey: 'r:other', messageId: 'invalid', body: 'غير صالح' },
  ]);
  assert.equal(batch.received, 4);
  assert.equal(batch.stored, 2);
  assert.equal(batch.duplicates, 1);
  assert.equal(batch.invalid, 1);
  assert.equal(archive.summary('main', 'r:other')[0].count, 2);
  const reloaded = new ConversationArchive({ store });
  assert.equal(reloaded.summary('main', 'r:other')[0].count, 2, 'batch import is persisted atomically and reloaded');

  // Recover archived rows after a contact was deleted and recreated with the same
  // verified WhatsApp identity; never relink to a different chat ID.
  const orphanRows = archive.orphanedTargets('main', new Set(['self', 'r:ahmed', 'r:flood', 'r:other']));
  const orphanAhmed = orphanRows.find(row => row.targetKey === 'r:deleted-ahmed');
  assert.equal(orphanAhmed, undefined, 'the archive must not invent a deleted target without archived rows');
  archive.recordMany('main', [
    { chatId: '96890000000@c.us', targetKey: 'r:deleted-ahmed', messageId: 'orphan-a', timestamp: 1792000001, body: 'رسالة يتيمة أحمد' },
  ]);
  const actualOrphan = archive.orphanedTargets('main', new Set(['self', 'r:ahmed', 'r:flood', 'r:other']))
    .find(row => row.targetKey === 'r:deleted-ahmed');
  assert.equal(actualOrphan.restorable, true);
  assert.equal(actualOrphan.count, 1);
  assert.throws(() => archive.relinkTarget('main', 'r:deleted-ahmed', 'r:ahmed', '96891111111@c.us'), /لا يطابق/,
    'a mismatch must never move messages to another recipient');
  const relinked = archive.relinkTarget('main', 'r:deleted-ahmed', 'r:ahmed', '96890000000@c.us');
  assert.equal(relinked.moved, 1);
  assert.equal(archive.list('main', 'r:ahmed', { limit: 500 }).messages.some(row => row.body === 'رسالة يتيمة أحمد'), true);
  assert.equal(archive.orphanedTargets('main', new Set(['self', 'r:ahmed', 'r:flood', 'r:other'])).some(row => row.targetKey === 'r:deleted-ahmed'), false);
  const reloadedAfterRelink = new ConversationArchive({ store });
  assert.equal(reloadedAfterRelink.list('main', 'r:ahmed', { limit: 500 }).messages.some(row => row.body === 'رسالة يتيمة أحمد'), true,
    'the relink must be persisted and survive archive reload');
  const limitedRoot = path.join(root, 'limited');
  const limitedStore = { safeSessionId: value => String(value || 'main'), getPaths: id => ({ dir: path.join(limitedRoot, String(id)) }) };
  const limited = new ConversationArchive({ store: limitedStore, maxArchiveBytes: 1024 * 1024 });
  const longBody = 'نص أرشيف طويل للاختبار. '.repeat(700);
  for (let i = 1; i <= 70; i++) limited.record('main', { chatId: '96891234567@c.us', targetKey: 'r:cap', messageId: `cap-${i}`, timestamp: 1790010000 + i, body: longBody });
  assert.ok(fs.statSync(limited.filePath('main')).size <= 1024 * 1024, 'single-message appends compact the file when the byte cap is crossed');
  assert.ok(limited.summary('main', 'r:cap')[0].count < 70, 'byte-bound compaction discards only older rows when needed');
  assert.ok(fs.statSync(path.join(root, 'main', 'conversations.jsonl')).size > 0);
  console.log('conversation-archive: ok (local persistence, dedupe, bounded pages, Arabic search, summaries, filename sanitization and identity-verified orphan relinking)');
} finally { fs.rmSync(root, { recursive: true, force: true }); }
