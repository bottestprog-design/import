'use strict';
function makePage(packet, flags = 0, sequence = 0) {
  const lacing = [];
  let left = packet.length;
  while (left >= 255) { lacing.push(255); left -= 255; }
  lacing.push(left);
  const page = Buffer.alloc(27 + lacing.length + packet.length);
  page.write('OggS', 0, 'ascii');
  page[4] = 0;
  page[5] = flags;
  page.writeUInt32LE(0x12345678, 14);
  page.writeUInt32LE(sequence, 18);
  page[26] = lacing.length;
  Buffer.from(lacing).copy(page, 27);
  packet.copy(page, 27 + lacing.length);
  return page;
}
function createOggOpusFixture(size = 512) {
  const head = Buffer.alloc(19);
  head.write('OpusHead', 0, 'ascii'); head[8] = 1; head[9] = 1; head.writeUInt32LE(48000, 12);
  const first = makePage(head, 0x02, 0);
  const tags = Buffer.from('OpusTagschat-BOT-test-v1', 'ascii');
  const second = makePage(tags, 0, 1);
  const third = makePage(Buffer.from([0xf8, 0xff, 0xfe, 0x00, 0x00, 0x00, 0x00, 0x00]), 0x04, 2);
  const stream = Buffer.concat([first, second, third]);
  return stream.length >= size ? stream : Buffer.concat([stream, Buffer.alloc(size - stream.length)]);
}
module.exports = { createOggOpusFixture };
