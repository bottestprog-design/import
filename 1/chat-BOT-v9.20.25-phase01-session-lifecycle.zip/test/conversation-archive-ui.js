'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const server = read('server.js'), app = read('public/app.js'), owner = read('src/owner-assistant.js'), archive = read('src/conversation-archive.js'), targets = read('src/conversation-targets.js'), tts = read('src/text-to-speech.js'), interaction = read('src/interaction.js'), wa = read('src/whatsapp.js');
const checks = [
  ['per-target archive files are stored below the local session directory', /conversations\.jsonl/.test(archive) && /this\.store\.getPaths\(sessionId\)\.dir/.test(archive)],
  ['self-chat and registered recipients/groups are the only allowed conversation targets', /listRegisteredTargets\(session, whatsapp\.selfChatId/.test(server) && /resolveChatAccess\(session, chatId, whatsapp\.selfChatId/.test(server) && /if \(!access\.allowed\) return/.test(server)],
  ['conversation message endpoint rejects unregistered target keys', /allowedConversationTarget\(id, req\.query\?\.targetKey\)/.test(server)],
  ['history import revalidates the actual WhatsApp chat before and after fetch against the saved target', /targetKeyForChat\(initialSession, actualChatId, whatsapp\.selfChatId\(id\)\) !== target\.key/.test(server) && /targetKeyForChat\(freshSession, actualChatId, whatsapp\.selfChatId\(id\)\) !== target\.key/.test(server) && /لم تُكتب الرسائل المسترجعة/.test(server)],
  ['history import offers a bounded deep-history limit and reports when the limit is reached', /Math\.min\(20000, Number\(req\.body\?\.limit\)/.test(server) && /limitReached: rows\.length >= limit/.test(server) && /value="20000"/.test(app)],
  ['conversation UI allows paging, search and explicit user-triggered import', /conversationLoadOlder/.test(app) && /conversationSearchForm/.test(app) && /conversationImportBtn/.test(app)],
  ['file extraction is confined to registered targets and requires exact confirmation', /registeredChatTargets\(s, this\.whatsapp\.selfChatId\(id\)\)/.test(owner) && /تأكيد التنزيل/.test(owner) && /registeredTargetKey/.test(owner)],
  ['new replies display the subtle command to request spoken output', /لتحويل آخر رد إلى صوت، اكتب: انطق آخر رد/.test(owner)],
  ['speech sends WhatsApp voice-note format instead of attaching an ordinary audio document', /async sendVoice\(/.test(wa) && /sendAudioAsVoice: true/.test(wa) && /\.ogg.*\.opus/.test(wa)],
  ['voice generation prefers local expressive Audar-TTS-V1, keeps Piper Arabic fallback and converts OGG/Opus', /audar-tts-v1-\$\{cfg\.audarTier\}/.test(tts) && /piper-arabic-fallback/.test(tts) && /PIPER_MODEL_PATH/.test(tts) && /libopus/.test(tts)],
  ['voice sending fails closed when strict local proofreading has not succeeded', /proofreadRequired && !generated\.proofreadUsed/.test(owner)],
  ['local voice quality gate is configurable in the UI and persisted by the settings endpoint', /id=\"ttsRequireProofread\"/.test(app) && /ttsRequireProofread: \$\('#ttsRequireProofread'\)\?\.checked/.test(app) && /b\.ttsRequireProofread !== undefined/.test(server)],
  ['automation replies are validated before sending and blocked if invalid', /lintRuleReply\(rendered\)/.test(interaction) && /REPLY_QUALITY_BLOCKED/.test(interaction)],
  ['release has a dedicated conversation archive section and TTS readiness panel', /سجل المحادثات/.test(app) && /refreshTtsStatus/.test(app) && /v9\.16\.0/.test(app)],
];
let failed = false;
for (const [label, ok] of checks) { console.log(`${ok ? 'OK' : 'FAIL'} ${label}`); if (!ok) failed = true; }
assert.equal(failed, false, 'one or more conversation archive/voice integration checks failed');
console.log('conversation-archive-ui: ok (archive UI and API, deep import safety, local voice output and reply-quality gate wiring)');
