@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title chat BOT - إعداد الصوت الكامل
call "%~dp0SETUP-PYTHON-VOICE-WINDOWS.bat"
if errorlevel 1 exit /b 1
echo.
echo اختياري: يمكنك تشغيل scripts\setup-local-ai.ps1 لاحقًا لتثبيت Ollama ونموذج تدقيق محلي.
echo لم يعد وجود Ollama شرطًا لإرسال الصوت؛ شرط التدقيق مغلق افتراضيًا ويمكن تفعيله من الإعدادات.
pause
exit /b 0
