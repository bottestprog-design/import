(() => {
  'use strict';

  const state = {
    data: null,
    countries: null,
    uiMode: (() => { try { return localStorage.getItem('chatbot-ui-mode') === 'light' ? 'light' : 'dark'; } catch { return 'dark'; } })(),
    companionNotice: null,
    assistantMessages: (() => { try { const value = JSON.parse(localStorage.getItem('chatbot-local-assistant-history') || '[]'); return Array.isArray(value) ? value.filter(x => x && ['user','assistant'].includes(x.role) && typeof x.text === 'string').slice(-80) : []; } catch { return []; } })(),
    assistantBusy: false,
    page: location.hash.slice(1) || 'dashboard',
    bgEngine: null,
    selectedGroup: null,
    pendingTargets: null,
    selectedMedia: new Set(),
    peopleFilter: '',
    selectedRecipientIds: new Set(),
    groupFilter: '',
    settingsView: 'appearance',
    loadPromise: null,
    loadController: null,
    bgLivePending: 0,
    interactionEditingRule: '',
    interactionEditingCounter: '',
    editingAutomationRuleId: '',
    whatsappContacts: null,
    whatsappContactsBusy: false,
    whatsappContactsOpen: false,
    whatsappContactsSession: '',
    whatsappContactsSelected: new Set(),
    whatsappContactFilter: '',
    whatsappContactsPage: 1,
    whatsappContactsPageSize: 50,
    connectionMethod: 'qr',
    connectionPhoneNumber: '',
    integrationHub: null,
    integrationHealth: null,
    integrationHubLoadedSession: '',
    integrationLatestRun: null,
    integrationWebhookPath: '',
    integrationEnrollment: null,
    integrationAgentCommand: '',
    conversationTargets: [],
    conversationTargetsSession: '',
    conversationOrphans: [],
    conversationOrphansSession: '',
    conversationTargetKey: 'self',
    conversationMessages: [],
    conversationMeta: null,
    conversationQuery: '',
    conversationLoadedKey: '',
    conversationBusy: false,
    conversationPollTimer: null,
    conversationPollBusy: false,
    conversationPollSession: '',
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function robotSvgMarkup(className = 'robot-svg') {
    return `<svg class="${className}" viewBox="0 0 96 104" role="img" aria-label="روبوت chat BOT" focusable="false">
      <ellipse cx="48" cy="96" rx="29" ry="5" fill="#06101e" opacity=".24"/>
      <path d="M29 70Q21 73 20 84V91Q20 95 25 95H71Q76 95 76 91V84Q75 73 67 70Z" fill="#172b46" stroke="#70e8de" stroke-width="2"/>
      <path d="M36 71 34 86Q48 92 62 86L60 71Z" fill="#26496c"/><path d="M48 8V17" stroke="#7ff6df" stroke-width="3.5" stroke-linecap="round"/><circle cx="48" cy="6" r="5" fill="#72f6dc" stroke="#d7fff7" stroke-width="1.5"/>
      <path d="M22 30Q22 20 33 20H63Q74 20 74 30V57Q74 68 63 68H33Q22 68 22 57Z" fill="#14243b" stroke="#78e8e0" stroke-width="2.4"/><path d="M28 31Q28 25 36 25H60Q68 25 68 31V53Q68 60 60 60H36Q28 60 28 53Z" fill="#1d3955" stroke="#375e7d" stroke-width="1.2"/>
      <rect x="34" y="36" width="10" height="12" rx="4" fill="#68f4dc"/><rect x="52" y="36" width="10" height="12" rx="4" fill="#68f4dc"/><circle cx="37" cy="39" r="2" fill="#effffb"/><circle cx="55" cy="39" r="2" fill="#effffb"/><path d="M40 54Q48 60 56 54" stroke="#b4fff0" stroke-width="2.8" fill="none" stroke-linecap="round"/><path d="M18 39Q12 44 18 50M78 39Q84 44 78 50" stroke="#84eddf" stroke-width="3" fill="none" stroke-linecap="round"/>
      <path d="M33 80 40 76H56L63 80 60 91H36Z" fill="#32718a" stroke="#83f4dc" stroke-width="1.3"/><circle cx="48" cy="83" r="4" fill="#8c8aff" stroke="#d7d0ff" stroke-width="1.2"/><path d="M26 76 21 82M70 76 75 82" stroke="#a3fff0" stroke-width="4" stroke-linecap="round"/>
    </svg>`;
  }
  const sid = () => $('#sessionSelect')?.value || state.data?.session?.id || '';
  const pendingTargetStorageKey = sessionId => `chatbot-pending-targets-v1:${String(sessionId || '')}`;
  function restorePendingTargets() {
    if (Array.isArray(state.pendingTargets)) return;
    const sessionId = String(state.data?.session?.id || '');
    if (!sessionId) return;
    try {
      const raw = sessionStorage.getItem(pendingTargetStorageKey(sessionId));
      if (!raw) return;
      const saved = JSON.parse(raw);
      if (saved && Array.isArray(saved.targets)) state.pendingTargets = [...new Set(saved.targets.map(String).filter(Boolean))];
    } catch {}
  }
  function persistPendingTargets() {
    const sessionId = sid();
    if (!sessionId) return;
    try {
      if (Array.isArray(state.pendingTargets)) sessionStorage.setItem(pendingTargetStorageKey(sessionId), JSON.stringify({ targets: [...new Set(state.pendingTargets.map(String).filter(Boolean))] }));
      else sessionStorage.removeItem(pendingTargetStorageKey(sessionId));
    } catch {}
  }

  function activeTargets(data) {
    return [
      ...(data.recipients || []).map((x) => ({ ...x, key: `r:${x.id}`, type: 'recipient' })),
      ...(data.groups || []).map((x) => ({ ...x, key: `g:${x.id}`, type: 'group' })),
    ];
  }

  function chatIdForTarget(target) {
    if (!target) return '';
    if (target.type === 'group') return String(target.gid || '').toLowerCase();
    const digits = String(target.digits || target.phone || '').replace(/\D/g, '');
    return digits ? `${digits}@c.us` : String(target.chatId || '').toLowerCase();
  }

  function typeLabel(target) {
    return target?.type === 'group' ? 'مجموعة' : 'شخص';
  }

  async function api(url, options = {}) {
    const isForm = options.body instanceof FormData;
    const headers = { ...(isForm ? {} : { 'Content-Type': 'application/json' }), ...(options.headers || {}) };
    const response = await fetch(url, { ...options, headers });
    const raw = await response.text();
    let body = {};
    try { body = raw ? JSON.parse(raw) : {}; } catch { body = { raw }; }
    if (!response.ok || body.ok === false) throw new Error(body.error || body.raw || `HTTP ${response.status}`);
    return body;
  }

  function notify(message, type = 'info') {
    const toast = $('#toast');
    if (toast) {
      toast.className = `toast ${type}`;
      toast.textContent = message;
      toast.hidden = false;
      clearTimeout(notify.timer);
      notify.timer = setTimeout(() => { toast.hidden = true; }, 4200);
    }
    // The robot is a visual helper for real status messages, not an AI claim.
    const speech = $('#assistantSpeech');
    const speechText = $('#assistantSpeechText');
    const robot = $('#assistantRobotButton');
    if (speech && speechText && message) {
      speechText.textContent = String(message);
      speech.className = `assistant-speech activity-${['success','error','warning'].includes(type) ? type : 'info'}`;
      speech.hidden = false;
      if (robot) { robot.dataset.mood = ['success','error','warning'].includes(type) ? type : 'neutral'; robot.classList.remove('robot-talk'); void robot.offsetWidth; robot.classList.add('robot-talk'); }
      clearTimeout(notify.speechTimer);
      notify.speechTimer = setTimeout(() => { if (speech && speechText.textContent === String(message)) speech.hidden = true; }, 9000);
    }
  }

  async function load(force = false) {
    if (state.loadPromise) return state.loadPromise;
    state.loadPromise = (async () => {
      state.loadController?.abort();
      const controller = new AbortController();
      state.loadController = controller;
      const current = sid();
      const query = current ? `?sessionId=${encodeURIComponent(current)}${force ? '&fresh=1' : ''}` : '';
      try {
        state.data = await api(`/api/state${query}`, { signal: controller.signal });
        if (!controller.signal.aborted) { restorePendingTargets(); render(); }
      } finally {
        if (state.loadController === controller) state.loadController = null;
      }
    })();
    try { return await state.loadPromise; }
    finally { state.loadPromise = null; }
  }

  async function loadCountries() {
    if (!state.countries) state.countries = await api('/api/countries');
    return state.countries;
  }

  function countryOptions(selected = 'OM') {
    return (state.countries?.countries || []).map((country) => `<option value="${esc(country.code)}" ${country.code === selected ? 'selected' : ''}>+${esc(country.callingCode)} · ${esc(country.code)}</option>`).join('');
  }

  function nav() {
    const groups = [
      { title: 'مساحة العمل', items: [['dashboard', '⌂', 'الرئيسية'], ['send', '➜', 'الإرسال'], ['owner-center', '◉', 'مركز المساعد'], ['assistant', '✧', 'المساعد المحلي'], ['conversations', '▤', 'سجل المحادثات']] },
      { title: 'جهات الإرسال', items: [['people', '●', 'الأشخاص'], ['groups', '◆', 'المجموعات']] },
      { title: 'التحكم', items: [['interaction', '✦', 'التفاعل'], ['automation', '⏱', 'الأتمتة'], ['integrations', '⇄', 'التكاملات والربط'], ['session', '◉', 'الجلسة'], ['settings', '⚙', 'الإعدادات']] },
      { title: 'الإضافات الجديدة', items: [['tools', '⌘', 'المحركات الذكية'], ['guide', '▤', 'الدليل والمساعدة'], ['updates', '↗', 'التعديلات والإصدارات']] },
    ];
    return groups.map((group) => `<div class="nav-group"><span class="nav-group-label">${group.title}</span>${group.items.map(([id, icon, label]) => `<button class="navbtn ${state.page === id ? 'active' : ''}" data-page="${id}" aria-current="${state.page === id ? 'page' : 'false'}"><span class="nav-icon" aria-hidden="true">${icon}</span><span>${label}</span>${state.page === id ? '<span class="nav-active-mark" aria-hidden="true"></span>' : ''}</button>`).join('')}</div>`).join('');
  }

  function shell(content) {
    const data = state.data || { session: {}, sessions: [], whatsapp: {} };
    const ready = !!data.whatsapp?.ready;
    const connectionText = ready ? 'متصل' : (data.whatsapp?.status === 'qr' ? 'بانتظار QR' : 'غير متصل');
    const defaultNotice = state.companionNotice?.message || 'أهلًا بك. افتح «المساعد المحلي» للسؤال عن حالة النظام أو الانتقال إلى صفحات البرنامج. يستخدم المساعد قواعد محلية ولا ينفّذ إرسالًا أو حذفًا من المحادثة.';
    return `<div class="app-shell">
      <header class="topbar">
        <div class="brand"><span class="brand-mark" aria-hidden="true">${robotSvgMarkup('brand-robot-svg')}</span><div><strong>chat BOT</strong><small>مركز إدارة الرسائل</small></div></div>
        <div class="top-actions">
          <label class="session-picker"><span>الجلسة الحالية</span><select id="sessionSelect" aria-label="اختر الجلسة">${(data.sessions || []).map((session) => `<option value="${esc(session.id)}" ${session.id === data.session.id ? 'selected' : ''}>${esc(session.name || session.id)}</option>`).join('')}</select></label>
          <span class="status-pill ${ready ? 'ready' : ''}" title="حالة اتصال WhatsApp"><span class="status-dot"></span><span>${connectionText}</span></span>
          <button class="mode-btn" id="modeToggleBtn" type="button" aria-label="${state.uiMode === 'dark' ? 'التبديل إلى الوضع الفاتح' : 'التبديل إلى الوضع الداكن'}"><span class="mode-icon" aria-hidden="true">${state.uiMode === 'dark' ? '☼' : '☾'}</span><span>${state.uiMode === 'dark' ? 'الوضع الفاتح' : 'الوضع الداكن'}</span></button>
          <button class="icon-btn" id="refreshBtn" title="تحديث البيانات" aria-label="تحديث البيانات">↻</button>
          <div class="more-settings-wrap"><button class="btn more-settings-btn" id="moreSettingsBtn" type="button" aria-expanded="false" aria-controls="moreSettingsMenu">⚙ إعدادات إضافية <span aria-hidden="true">▾</span></button>
            <div class="more-settings-menu" id="moreSettingsMenu" hidden>
              <button type="button" data-go="operation"><b>إعدادات التشغيل المتقدمة</b><small>الموثوقية والمحاولات وفترة الهدوء</small></button>
              <button type="button" data-go="appearance"><b>المظهر والخلفيات</b><small>ألوان الواجهة وتأثيرات الخلفية</small></button>
              <button type="button" data-go="tools"><b>المحركات الذكية</b><small>فحص البنية والقاموس وتحليل الأوامر</small></button>
              <button type="button" data-go="updates"><b>التعديلات والإصدارات</b><small>الميزات المضافة والقيود المعروفة</small></button>
              <button type="button" data-go="guide"><b>الدليل والخصوصية</b><small>طريقة التشغيل والمساعدة</small></button>
            </div>
          </div>
        </div>
      </header>
      <div class="workspace-layout">
        <aside class="sidebar" aria-label="التنقل الرئيسي">
          <div class="sidebar-heading"><span>القائمة الرئيسية</span><small>تنقّل واضح وسريع</small></div>
          <nav class="navrow" aria-label="صفحات chat BOT">${nav()}</nav>
          <div class="sidebar-foot"><span class="sidebar-foot-icon" aria-hidden="true">✓</span><div><b>إدارة محلية</b><small>البيانات محفوظة على جهازك</small></div></div>
        </aside>
        <main class="main" id="mainContent" tabindex="-1">${content}</main>
      </div>
      <div class="assistant-companion" id="assistantCompanion" aria-label="مساعد chat BOT">
        <section id="assistantSpeech" class="assistant-speech" hidden role="status" aria-live="polite">
          <div class="assistant-speech-top"><span class="assistant-speech-origin">${robotSvgMarkup('speech-mini-robot')}<span>مساعد chat BOT</span></span><button id="assistantSpeechClose" class="assistant-speech-close" type="button" aria-label="إغلاق الرسالة" title="إغلاق الرسالة">×</button></div>
          <p id="assistantSpeechText">${esc(defaultNotice)}</p><button id="assistantSpeechOpen" class="assistant-speech-link" type="button">فتح المساعد المحلي ↗</button><span class="assistant-speech-tail" aria-hidden="true"></span>
        </section>
        <button id="assistantRobotButton" class="assistant-robot-button" type="button" aria-label="افتح المساعد المحلي في chat BOT" title="افتح المساعد المحلي" data-mood="neutral">${robotSvgMarkup('assistant-robot-svg')}<span class="assistant-robot-status" aria-hidden="true"></span></button><div class="assistant-robot-caption" aria-hidden="true">مساعدك</div>
      </div>
      <div id="toast" class="toast sr-only" hidden role="status" aria-live="polite"></div>
    </div>`;
  }

  function pageDashboard(data) {
    const targets = activeTargets(data);
    const stats = data.stats || {};
    const logs = (data.logs || []).slice(0, 12);
    const runtime = data.whatsapp || {};
    return `<section class="hero-card">
      <div><p class="eyebrow">لوحة الجلسة الحالية</p><h1>${esc(data.session?.name || 'الجلسة الرئيسية')}</h1><p>كل شيء واضح من هنا: الإرسال، الأشخاص، المجموعات، التفاعل والسجل.</p></div>
      <div class="hero-actions"><button class="btn primary" data-go="send">إرسال الآن</button><button class="btn" data-go="interaction">التفاعل</button></div>
    </section>
    <section class="stats-grid">
      <article class="stat-card"><span>الحالة</span><b>${runtime.ready ? 'جاهز' : 'غير متصل'}</b><small>${runtime.info?.wid?.user ? '+' + esc(runtime.info.wid.user) : 'اربط الحساب من الجلسة'}</small></article>
      <article class="stat-card"><span>الأشخاص</span><b>${(data.recipients || []).length}</b><small>هذه الجلسة</small></article>
      <article class="stat-card"><span>المجموعات</span><b>${(data.groups || []).length}</b><small>هذه الجلسة</small></article>
      <article class="stat-card"><span>الإرسال</span><b>${Number(stats.sentMessages || 0) + Number(stats.sentImages || 0) + Number(stats.sentFiles || 0)}</b><small>عمليات تم تسجيلها</small></article>
    </section>
    <section class="content-grid two-col">
      <article class="panel"><div class="panel-head"><div><h2>الوصول السريع</h2><p>اختصر الطريق إلى المهمة التي تريدها.</p></div></div>
        <div class="quick-list">
          <button class="quick-item" data-go="send"><span class="quick-icon">➜</span><span><b>رسالة جديدة</b><small>حدد الأهداف والملفات ثم أرسل.</small></span></button>
          <button class="quick-item" data-go="people"><span class="quick-icon">＋</span><span><b>إضافة أشخاص</b><small>أرقام دولية وقوائم متعددة.</small></span></button>
          <button class="quick-item" data-go="groups"><span class="quick-icon">◆</span><span><b>المجموعات</b><small>اكتشاف، ربط، تحليل وحفظ.</small></span></button>
          <button class="quick-item" data-go="settings"><span class="quick-icon">⚙</span><span><b>الإعدادات</b><small>المظهر والخلفيات والتشغيل.</small></span></button>
        </div>
      </article>
      <article class="panel"><div class="panel-head"><div><h2>آخر نشاط</h2><p>السجل محفوظ لهذه الجلسة فقط.</p></div><button class="btn small" id="dashboardRefresh">تحديث</button></div>
        <div class="log-list">${logs.length ? logs.map(logRow).join('') : '<div class="empty">لا يوجد نشاط بعد.</div>'}</div>
      </article>
    </section>`;
  }

  function logRow(log) {
    const at = log.at || log.time || log.timestamp || '';
    const date = at ? new Date(at) : null;
    const when = date && !Number.isNaN(date.getTime()) ? date.toLocaleString('ar-OM') : '';
    const level = String(log.level || 'INFO').toLowerCase();
    return `<div class="log-row"><span class="log-time">${esc(when)}</span><span class="log-level ${esc(level)}">${esc(log.level || 'INFO')}</span><span class="log-message">${esc(log.message || '')}</span></div>`;
  }

  function targetList(data, selected = state.pendingTargets) {
    const useAll = !Array.isArray(selected);
    const chosen = new Set(useAll ? [] : selected.map(String));
    const targets = activeTargets(data);
    return targets.length ? targets.map((target) => {
      const displayName = target.displayName || target.localName || target.name || target.phone || target.gid || 'بدون اسم';
      const initial = Array.from(String(displayName).trim())[0] || '•';
      const pictureUrl = target.type === 'recipient' ? (target.avatarUrl || (target.whatsappProfilePhoto ? `/profile/${encodeURIComponent(target.whatsappProfilePhoto)}?sessionId=${encodeURIComponent(sid())}` : '')) : '';
      const fallbackPhotoUrl = target.type === 'recipient' && target.whatsappJid ? `/api/whatsapp/contact-picture?sessionId=${encodeURIComponent(sid())}&jid=${encodeURIComponent(target.whatsappJid)}` : '';
      return `<label class="target-row">
      <input type="checkbox" class="target" value="${esc(target.key)}" ${(useAll || chosen.has(target.key)) ? 'checked' : ''}>
      ${target.type === 'group' ? `<span class="target-mark group">◆</span>` : `<span class="target-avatar"><span class="target-avatar-initial">${esc(initial)}</span>${pictureUrl ? `<img class="target-avatar-photo" src="${esc(pictureUrl)}" data-fallback-url="${esc(fallbackPhotoUrl)}" alt="" loading="lazy" decoding="async" onerror="if(this.dataset.fallbackUrl && !this.dataset.fallbackTried){this.dataset.fallbackTried='1';const u=new URL(this.dataset.fallbackUrl,location.href);u.searchParams.set('refresh','1');u.searchParams.set('retry',String(Date.now()));this.src=u.href;}else if(this.dataset.photoRetry!=='1'){this.dataset.photoRetry='1';const u=new URL(this.src,location.href);u.searchParams.set('refresh','1');u.searchParams.set('retry',String(Date.now()));this.src=u.href;}else{this.hidden=true;}">` : ''}</span>`}
      <span class="target-main"><b>${esc(displayName)}</b><small>${typeLabel(target)}${target.type === 'group' ? ` · ${esc(target.gid || '')}` : ` · ${esc(target.international || target.e164 || '')}`}</small></span>
      <span class="target-state ${target.enabled === false ? 'off' : ''}">${target.enabled === false ? 'متوقف' : 'جاهز'}</span>
    </label>`;
    }).join('') : '<div class="empty">لا توجد أهداف. أضف شخصًا أو اربط مجموعة أولًا.</div>';
  }

  function pageOwnerCenter(data) {
    const stats = data.stats || {};
    const runtime = data.whatsapp || {};
    const status = runtime.ready ? 'متصل' : runtime.status === 'qr' ? 'بانتظار QR' : runtime.status || 'غير متصل';
    const recent = (data.logs || []).slice(0, 12);
    const personalReplies = (data.recipients || []).filter(person => person.replyProfile?.mode === 'custom').length;
    const statsRows = [
      ['رسائل أُرسلت', Number(stats.sentMessages || 0)],
      ['ملفات أُرسلت', Number(stats.sentFiles || 0) + Number(stats.sentImages || 0)],
      ['إجراءات التفاعل', Number(stats.interactionActions || 0)],
      ['أخطاء التفاعل', Number(stats.interactionErrors || 0)],
    ];
    return `<section class="page-title"><p class="eyebrow">OWNER CENTER • LOCAL STATUS</p><h1>مركز المساعد</h1><p>لوحة متابعة للجلسة الحالية، والأشخاص والمجموعات والإرسال والتفاعل. هذه الشاشة تقرأ البيانات المحلية ولا تدّعي تنفيذ إجراءات من دون طلبك.</p></section>
      <section class="hero-card owner-center-hero"><div><span class="eyebrow">حالة الحساب</span><h2>${esc(status)}</h2><p>${runtime.info?.wid?.user ? `الحساب المتصل: +${esc(runtime.info.wid.user)}` : 'اربط WhatsApp من صفحة الجلسة لمتابعة الاتصال.'}</p></div><div class="hero-actions"><button class="btn primary" data-go="assistant">افتح المساعد المحلي</button><button class="btn" data-go="session">إدارة الاتصال</button></div></section>
      <section class="stats-grid owner-center-stats">${statsRows.map(([label,value]) => `<article class="stat-card"><span>${esc(label)}</span><b>${value.toLocaleString('ar-OM')}</b><small>مجمّع لهذه الجلسة فقط</small></article>`).join('')}</section>
      <section class="content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>ملخص الجلسة</h2><p>عدد العناصر المحفوظة وحالتها.</p></div><button class="btn small" id="ownerCenterRefresh">تحديث</button></div><div class="owner-metric-list">
        <div><span>الأشخاص المحفوظون</span><b>${(data.recipients || []).length}</b><button class="btn small" data-go="people">عرض</button></div>
        <div><span>ردود شخصية مخصصة</span><b>${personalReplies}</b><button class="btn small" data-go="people">إدارة</button></div>
        <div><span>المجموعات المحفوظة</span><b>${(data.groups || []).length}</b><button class="btn small" data-go="groups">عرض</button></div>
        <div><span>قواعد التفاعل المفعّلة</span><b>${(data.interaction?.rules || []).filter(rule => rule.enabled !== false).length}</b><button class="btn small" data-go="interaction">عرض</button></div>
        <div><span>مهام الأتمتة المفعّلة</span><b>${(data.automation?.tasks || []).filter(task => task.enabled !== false).length}</b><button class="btn small" data-go="automation">عرض</button></div>
      </div><div class="action-bar"><button class="btn" data-go="send">الذهاب إلى الإرسال</button><button class="btn" data-go="tools">فحص المحركات</button><button class="btn" data-go="updates">التعديلات الجديدة</button></div></article>
      <article class="panel"><div class="panel-head"><div><h2>آخر النشاطات</h2><p>السجل المخزن في الجلسة الحالية.</p></div></div><div class="log-list tall">${recent.map(logRow).join('') || '<div class="empty">لا توجد نشاطات مسجلة بعد.</div>'}</div><div class="action-bar"><button class="btn" data-go="session">سجل الجلسة الكامل</button></div></article></section>`;
  }

  function pageAssistant(data) {
    const messages = state.assistantMessages.length ? state.assistantMessages : [{ role: 'assistant', text: 'أهلًا بك. أنا المساعد المحلي في chat BOT. أستطيع قراءة حالة النظام والعناصر المحفوظة والتنقل إلى صفحات البرنامج باستخدام قواعد محلية. لا أستخدم خدمة ذكاء اصطناعي خارجية ولا أنفّذ حذفًا أو إرسالًا من المحادثة.', at: '' }];
    return `<section class="page-title"><p class="eyebrow">ASSISTANTS • LOCAL CONTROL</p><h1>المساعد ومحادثة WhatsApp</h1><p>استخدم المحادثة هنا للأسئلة والتنقل، أو افتح WhatsApp واكتب للبوت داخل محادثة «الرسائل إلى نفسك» لتنفيذ الحوارات التفاعلية خطوة بخطوة.</p></section>
      <section class="panel self-chat-guide-panel"><div class="panel-head"><div><h2>محادثة البوت داخل WhatsApp</h2><p>هذه هي قناة الأوامر الفعلية، منفصلة عن دردشة المتصفح.</p></div><span class="mini-tag ${data.whatsapp?.ready ? 'connected' : ''}">${data.whatsapp?.ready ? 'WhatsApp متصل' : 'يلزم الاتصال'}</span></div>
        <div class="self-chat-guide-grid"><div><b>1. اربط حساب WhatsApp</b><small>من صفحة الجلسة، ابدأ الاتصال وامسح QR عند ظهوره.</small></div><div><b>2. افتح «الرسائل إلى نفسك»</b><small>اكتب طلبك كما تكتبه لشخص؛ سيرشدك البوت سؤالًا بعد سؤال.</small></div><div><b>3. راجع ثم أكّد</b><small>لن يرسل رسالة أو يحفظ موعدًا أو قاعدة إلا بعد تأكيد واضح منك.</small></div></div>
        <div class="self-chat-examples"><span>جرّب في WhatsApp:</span><code>مساعدة</code><code>عايز أضيف شخص جديد</code><code>أرسل رسالة</code><code>أنشئ موعد</code><code>أنشئ رد تلقائي</code><code>استدعاء جهات واتساب</code></div>
        <div class="action-bar"><button class="btn primary" data-go="session">ربط WhatsApp</button><button class="btn" data-go="people">استدعاء ومزامنة جهات WhatsApp</button><button class="btn" data-go="guide">دليل الاستخدام</button></div>
        <details class="advanced-panel"><summary>تعليمات محادثة النفس بالتفصيل</summary><p>بعد نجاح الاتصال يرسل البوت رسالة دليل مرة واحدة لكل جلسة. يمكنك استعادتها بكتابة «مساعدة». أثناء إضافة شخص، يطلب الاسم ثم الدولة ثم الرقم ويتعامل مع التكرار. إرسال الرسائل يمرّ باختيار المستلم ثم نص الرسالة ثم التأكيد. المواعيد والردود التلقائية لها خطوات مراجعة وتأكيد. اكتب «إلغاء» لإيقاف أي حوار جارٍ.</p></details>
      </section>
      <section class="content-grid assistant-content-grid"><article class="panel local-assistant-panel"><div class="panel-head"><div><h2>محادثة محلية</h2><p>يتم حفظ سجل الواجهة في المتصفح على هذا الجهاز، بحد أقصى 80 رسالة.</p></div><span class="mini-tag">محلي</span></div>
        <div id="localAssistantMessages" class="local-assistant-messages" role="log" aria-live="polite" aria-relevant="additions text">${messages.map(message => `<div class="local-assistant-message ${message.role === 'user' ? 'user' : 'assistant'}"><span>${message.role === 'user' ? 'أنت' : 'مساعد chat BOT'}</span><p>${esc(message.text).replace(/\n/g, '<br>')}</p></div>`).join('')}${state.assistantBusy ? '<div class="local-assistant-message assistant"><span>مساعد chat BOT</span><p>أفحص البيانات المحلية…</p></div>' : ''}</div>
        <form id="localAssistantForm" class="local-assistant-form"><label class="sr-only" for="localAssistantPrompt">اكتب سؤالًا أو أمرًا</label><textarea id="localAssistantPrompt" maxlength="1000" rows="2" placeholder="مثال: الحالة، قائمة الأشخاص، افتح الإعدادات" ${state.assistantBusy ? 'disabled' : ''}></textarea><div class="local-assistant-form-footer"><small>الأوامر الحساسة لا تُنفّذ من هنا.</small><button class="btn primary" type="submit" ${state.assistantBusy ? 'disabled' : ''}>${state.assistantBusy ? 'جارٍ الفحص…' : 'إرسال السؤال'}</button></div></form>
        <div class="local-assistant-quick">${['الحالة','قائمة الأشخاص','قائمة المجموعات','قواعد التفاعل','الأتمتة','افتح الإرسال','مساعدة'].map(prompt => `<button type="button" class="btn small" data-assistant-prompt="${esc(prompt)}">${esc(prompt)}</button>`).join('')}</div>
        <div class="action-bar"><button class="btn" id="clearLocalAssistantHistory">مسح سجل المحادثة</button><button class="btn" data-go="tools">المحركات الذكية</button><button class="btn" data-go="guide">الدليل</button></div>
      </article><aside class="panel"><div class="panel-head"><div><h2>ما يستطيع المساعد فعله</h2><p>نطاق واضح من دون ادعاء ذكاء عام.</p></div></div><div class="engine-list">
        <div class="engine-row"><span class="engine-icon">✓</span><div><b>قراءة الحالة</b><small>حالة WhatsApp، عدد الأشخاص والمجموعات والقواعد.</small></div></div>
        <div class="engine-row"><span class="engine-icon">↗</span><div><b>التنقل بين الصفحات</b><small>افتح الإرسال أو الأشخاص أو الإعدادات بالكلام.</small></div></div>
        <div class="engine-row"><span class="engine-icon">⌕</span><div><b>السجل المحلي</b><small>عرض آخر النشاطات المحفوظة في الجلسة.</small></div></div>
        <div class="engine-row"><span class="engine-icon">!</span><div><b>تأكيد الإجراءات الحساسة</b><small>تحليل الأمر لا يعني تنفيذه على حساب WhatsApp.</small></div></div>
      </div><div class="privacy-box"><p>المساعد لا يرسل رسائل ولا يحذف جهات اتصال ولا يكتم محادثات. استخدم صفحة الوظيفة نفسها لمراجعة الإجراء وتنفيذه يدويًا.</p></div></aside></section>`;
  }

  function persistAssistantMessages() {
    try { localStorage.setItem('chatbot-local-assistant-history', JSON.stringify(state.assistantMessages.slice(-80))); } catch { /* Local history is optional if browser storage is unavailable. */ }
  }

  async function submitAssistantPrompt(value) {
    const prompt = String(value || '').trim().slice(0, 1000);
    if (!prompt || state.assistantBusy) return;
    state.assistantMessages.push({ role: 'user', text: prompt, at: new Date().toISOString() });
    state.assistantMessages = state.assistantMessages.slice(-80);
    state.assistantBusy = true;
    persistAssistantMessages();
    render();
    try {
      const messages = state.assistantMessages.slice(-10).map(message => ({ role: message.role === 'user' ? 'user' : 'assistant', content: String(message.text || '').slice(0, 1000) }));
      const result = await api('/api/assistant/local', { method: 'POST', body: JSON.stringify({ sessionId: sid(), prompt, messages }) });
      state.assistantMessages.push({ role: 'assistant', text: String(result.reply || 'لم تُرجع المحركات ردًا.'), at: new Date().toISOString() });
      state.assistantMessages = state.assistantMessages.slice(-80);
      state.assistantBusy = false;
      persistAssistantMessages();
      if (result.navigate) {
        const target = result.navigate;
        render();
        go(target);
      } else render();
    } catch (error) {
      state.assistantMessages.push({ role: 'assistant', text: `تعذر إكمال السؤال المحلي: ${error.message}`, at: new Date().toISOString() });
      state.assistantMessages = state.assistantMessages.slice(-80);
      state.assistantBusy = false;
      persistAssistantMessages();
      render();
    }
  }

  async function bindAssistant() {
    $('#localAssistantForm')?.addEventListener('submit', async event => {
      event.preventDefault();
      const input = $('#localAssistantPrompt'); const prompt = input?.value || '';
      await submitAssistantPrompt(prompt);
    });
    $$('[data-assistant-prompt]').forEach(button => button.addEventListener('click', () => submitAssistantPrompt(button.dataset.assistantPrompt)));
    $('#clearLocalAssistantHistory')?.addEventListener('click', () => {
      if (!confirm('مسح سجل محادثة المساعد المحلي المحفوظ في هذا المتصفح؟')) return;
      state.assistantMessages = []; persistAssistantMessages(); render();
    });
  }

  function pageSend(data) {
    const media = data.media || [];
    const tasks = data.automation?.tasks || [];
    const selectedTargets = state.pendingTargets;
    const groupsCount = (data.groups || []).length;
    return `<section class="page-title"><p class="eyebrow">إرسال</p><h1>أرسل بسهولة</h1><p>حدد الأهداف، اكتب الرسالة، ارفع الملفات، ثم نفّذ الآن أو احفظ موعدًا مستقلًا.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>من سيرسل إليه؟</h2><p>كل الاختيارات تخص الجلسة الحالية.</p></div><div class="panel-actions"><button class="btn small" id="selectAllTargets">الكل</button><button class="btn small" id="clearTargets">مسح</button></div></div>
          <div class="target-summary"><b>${selectedTargets === null ? 'الكل' : selectedTargets.length}</b><span>${selectedTargets === null ? 'كل الأهداف' : 'أهداف محددة'}</span><span>· ${groupsCount} مجموعة محفوظة</span></div>
          <div class="target-list">${targetList(data, selectedTargets)}</div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الرسالة والملفات</h2><p>ارفع مرة واحدة واختر ما يدخل في الإرسال.</p></div></div>
          <label>نص الرسالة<textarea id="sendText" rows="6" placeholder="اكتب الرسالة هنا..."></textarea></label>
          <div class="form-grid two"><label>قبل الملف<input id="sendPreText" placeholder="اختياري"></label><label>بعد الملف<input id="sendPostText" placeholder="اختياري"></label></div>
          <div class="upload-box" id="mediaDropZone" tabindex="0" role="button" aria-label="اسحب الملفات هنا أو اضغط لاختيارها"><input id="mediaFiles" type="file" multiple accept="image/*,.pdf,.txt,.md,.log,.csv,.json,.xml,.html,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.7z,.rar,.tar,.gz,.mp4,.webm,.mkv,.avi,.mov,.3gp,.m4v,.mpeg,.mpg,.mp3,.m4a,.ogg,.wav,.aac,.flac,.opus"><label for="mediaFiles"><span>＋</span> اسحب الملفات إلى هنا أو اضغط للاختيار</label><small>معاينة الصور والصوت والفيديو والمستندات قبل الإرسال. حد الملف: ${Number(data.settings?.maxImageSizeMB || 100)} MB؛ يمكن رفع الملفات بالسحب والإفلات.</small><label class="upload-option"><input id="replaceDuplicates" type="checkbox"><span>استبدال الملف المكرر تلقائيًا</span></label><div id="uploadStatus" class="muted" aria-live="polite"></div></div>
          <div class="media-library-toolbar"><b>مكتبة الملفات (${media.length}) · <span id="sendMediaCount">${state.selectedMedia.size} محدد للإرسال</span></b><div class="panel-actions"><button type="button" class="btn small" id="selectAllMedia">تحديد النتائج الظاهرة</button><button type="button" class="btn small" id="clearMediaSelection">إلغاء كل التحديد</button><button type="button" class="btn small" id="clearSendText">مسح النصوص</button></div></div>
          <div class="media-library-filters"><label>بحث بالاسم<input id="mediaSearch" type="search" placeholder="اكتب اسم الملف أو امتداده…" aria-label="بحث في أسماء الملفات المحفوظة" autocomplete="off"></label><label>نوع الملف<select id="mediaTypeFilter"><option value="all">كل الأنواع</option><option value="image">الصور</option><option value="video">الفيديو</option><option value="audio">الصوت</option><option value="document">المستندات والملفات</option></select></label><label>ترتيب النتائج<select id="mediaSort"><option value="name-asc">الاسم: أ–ي</option><option value="name-desc">الاسم: ي–أ</option><option value="size-desc">الحجم: الأكبر أولًا</option><option value="size-asc">الحجم: الأصغر أولًا</option><option value="date-desc">الأحدث تعديلًا</option><option value="date-asc">الأقدم تعديلًا</option></select></label><p id="mediaSearchStatus" class="muted" aria-live="polite">عرض الملفات المحفوظة في هذه الجلسة.</p></div>
          <div class="file-list media-card-grid" id="mediaCardGrid">${media.length ? media.map(mediaChip).join('') : '<div class="empty">لا توجد ملفات محفوظة. اختر الملفات أو اسحبها إلى منطقة الرفع.</div>'}</div><div id="mediaFilteredEmpty" class="empty" hidden>لا توجد ملفات تطابق البحث والتصفية الحاليين.</div>
          <details class="advanced-panel"><summary>خيارات الإرسال والتحكم بالوسائط</summary><div class="form-grid three"><label>الترتيب<select id="sendOrder"><option value="target-first">كل هدف ثم ملفاته</option><option value="image-first">كل ملف ثم جميع الأهداف</option></select></label><label>طريقة إرسال الملفات<select id="mediaMode"><option value="media">كصور/فيديو/صوت عند دعم النوع</option><option value="document">كل الملفات كمستندات</option><option value="sticker">تحويل الصور إلى ملصقات WhatsApp</option></select></label><label>منع التكرار<select id="repeatGuard"><option value="on">مفعّل (موصى به)</option><option value="off">متوقف لهذا الإرسال</option></select></label><label>النص الافتراضي<input id="defaultPreText" value="${esc(data.settings?.preText || '')}" placeholder="اختياري"></label><label class="toggle-row"><input id="captionWithMedia" type="checkbox"><span><b>إرفاق النص مع الصورة أو الفيديو</b><small>يظهر النص أسفل الصورة/الفيديو بدل إرسال رسالة منفصلة. حد التعليق 1024 حرفًا.</small></span></label><label class="toggle-row send-repeat-override"><input id="replaceSendDuplicate" type="checkbox"><span><b>السماح بتكرار إرسال موجود</b><small>منفصل عن استبدال الملفات المكررة؛ استخدمه فقط عندما تريد إعادة الإرسال عمدًا.</small></span></label></div><p class="help-note">وضع الملصقات يحوّل الصور المختارة فقط إلى ملصقات WhatsApp (حتى 16 MB للصورة)؛ لا تخلط معه مستندات أو فيديو أو صوت. وضع المستندات لا يدعم التعليقات. عند اختيار صور عادية، يمكن إرفاق النص أسفلها.</p></details>
          <div class="action-bar"><button class="btn primary large" id="sendNowBtn">إرسال الآن</button></div>
        </article>
      </section>
      <section class="panel"><div class="panel-head"><div><h2>الإرسال التلقائي</h2><p>المواعيد المحفوظة تظهر هنا. افتح المحرر فقط عند إنشاء موعد أو تعديله.</p></div><span class="release-pill">${tasks.length} موعد</span></div>
        <details class="section-editor" id="sendScheduleDisclosure" ${state.editingTaskId ? 'open' : ''}><summary>${state.editingTaskId ? 'تعديل الموعد المحدد' : '＋ إنشاء موعد إرسال جديد'}</summary>
          <div class="form-grid four"><label>اسم الموعد<input id="scheduleName" placeholder="مثال: تذكير يومي"></label><label>الوقت<input id="scheduleTime" type="time" value="17:30"></label><label>التكرار<select id="scheduleMode"><option value="once">مرة واحدة</option><option value="daily">يوميًا</option><option value="weekly">أسبوعيًا</option><option value="monthly">شهريًا</option><option value="yearly">سنويًا</option></select></label><label class="schedule-date">التاريخ<input id="scheduleDate" type="date"></label></div>
          <div class="form-grid four"><label class="schedule-day" hidden>اليوم<select id="scheduleDay"><option value="0">الأحد</option><option value="1">الاثنين</option><option value="2">الثلاثاء</option><option value="3">الأربعاء</option><option value="4">الخميس</option><option value="5">الجمعة</option><option value="6">السبت</option></select></label><label class="schedule-dom" hidden>يوم الشهر<input id="scheduleDayOfMonth" type="number" min="1" max="31" value="1"></label><label class="schedule-month" hidden>الشهر<select id="scheduleMonth">${Array.from({ length: 12 }, (_, index) => `<option value="${index + 1}">${index + 1}</option>`).join('')}</select></label><label>نوع الملفات<select id="scheduleMediaMode"><option value="selected">الملفات المحددة فقط</option><option value="cycle">دورة الصور تلقائيًا</option></select></label><label class="toggle-box"><input id="scheduleGroupsEnabled" type="checkbox" checked><span>تشغيل على المجموعات</span></label></div>
          <div class="form-grid two"><label>نص الموعد<input id="scheduleText" placeholder="إن كان فارغًا سيستخدم نص الإرسال"></label><label>نص بعد الملف<input id="schedulePostText" placeholder="اختياري"></label></div>
          <div class="action-bar"><button class="btn primary" id="scheduleBtn">${state.editingTaskId ? 'حفظ تعديل الموعد' : 'حفظ الموعد'}</button><button class="btn" id="cancelScheduleEditBtn" type="button" ${state.editingTaskId ? '' : 'hidden'}>إلغاء التعديل</button></div>
        </details>
        <div class="schedule-list">${tasks.length ? tasks.map(taskRow).join('') : '<div class="empty">لا توجد مواعيد محفوظة بعد. افتح «إنشاء موعد إرسال جديد» لإضافة أول موعد.</div>'}</div>
      </section>`;
  }

  function mediaChip(media) {
    const id = String(media.id || media.filename || '');
    const selected = state.selectedMedia.has(id);
    const url = media.url || `/media/${encodeURIComponent(media.filename || id)}?sessionId=${encodeURIComponent(sid())}`;
    const ext = String(media.ext || '').toLowerCase();
    let preview = `<div class="media-file-preview"><span>${mediaIcon(ext)}</span><b>${esc(ext.replace('.', '').toUpperCase() || 'FILE')}</b></div>`;
    if (media.isImage) preview = `<a class="media-preview-frame image-preview" href="${esc(url)}" target="_blank" rel="noopener" title="فتح الصورة بالحجم الكامل"><img src="${esc(url)}" loading="lazy" decoding="async" alt="معاينة ${esc(media.filename || 'الصورة')}" onerror="this.hidden=true;this.closest('.image-preview')?.classList.add('preview-failed')"></a>`;
    else if (ext === '.pdf') preview = `<div class="media-preview-frame pdf-preview"><iframe src="${esc(url)}#page=1&toolbar=0&navpanes=0" loading="lazy" title="معاينة PDF ${esc(media.filename || id)}"></iframe><a href="${esc(url)}" target="_blank" rel="noopener">فتح الملف ↗</a></div>`;
    else if (['.txt','.md','.log','.csv','.json','.xml','.html'].includes(ext)) preview = `<div class="media-preview-frame text-preview"><pre data-text-preview="${esc(id)}">جارٍ تحميل معاينة النص…</pre></div>`;
    else if (media.isVideo || ['.mp4','.webm','.mov','.mkv','.avi'].includes(ext)) preview = ['.mp4','.webm'].includes(ext) ? `<div class="media-preview-frame video-preview"><video src="${esc(url)}#t=0.1" controls preload="metadata" playsinline></video></div>` : `<a class="media-preview-frame video-preview" href="${esc(url)}" target="_blank" rel="noopener"><span>🎬 فتح ملف الفيديو</span></a>`;
    else if (media.isAudio || ['.mp3','.m4a','.ogg','.wav','.aac','.flac','.opus'].includes(ext)) preview = ['.mp3','.m4a','.ogg','.wav'].includes(ext) ? `<div class="media-preview-frame audio-preview"><span>♫</span><audio src="${esc(url)}" controls preload="none"></audio></div>` : `<a class="media-preview-frame audio-preview" href="${esc(url)}" target="_blank" rel="noopener"><span>🎵 تشغيل / تنزيل الصوت</span></a>`;
    const filterKind = media.isImage ? 'image' : media.isVideo ? 'video' : media.isAudio ? 'audio' : 'document';
    return `<article class="media-card" data-media-card="${esc(id)}" data-media-name="${esc(media.filename || media.name || id)}" data-media-kind="${filterKind}" data-media-size="${Math.max(0, Number(media.size) || 0)}" data-media-updated="${esc(media.updatedAt || '')}"><div class="media-preview-wrap">${preview}</div><div class="media-card-details"><label class="media-card-select"><input class="send-media" type="checkbox" value="${esc(id)}" ${selected ? 'checked' : ''}><span>اختيار للإرسال</span></label><b class="media-card-name" title="${esc(media.filename || id)}">${esc(media.filename || media.name || id)}</b><small>${esc(ext.replace('.', '').toUpperCase() || 'FILE')} · ${formatBytes(media.size)}</small><div class="media-card-actions"><button type="button" class="btn small" data-deselect-media="${esc(id)}">إزالة من الإرسال</button><button type="button" class="btn danger small" data-delete-media="${esc(id)}">حذف من المكتبة</button></div></div></article>`;
  }

  function mediaIcon(ext) {
    if (ext === '.pdf') return '📕';
    if (['.doc','.docx','.txt','.md','.log','.csv','.json','.xml','.html'].includes(ext)) return '📝';
    if (['.xls','.xlsx'].includes(ext)) return '📊';
    if (['.ppt','.pptx'].includes(ext)) return '📽️';
    if (['.zip','.7z','.rar','.tar','.gz'].includes(ext)) return '🗜️';
    if (['.mp4','.webm','.mov','.mkv','.avi','.3gp','.m4v','.mpeg','.mpg'].includes(ext)) return '🎬';
    if (['.mp3','.m4a','.ogg','.wav','.aac','.flac','.opus'].includes(ext)) return '🎵';
    if (['.jpg','.jpeg','.png','.gif','.webp','.avif'].includes(ext)) return '🖼️';
    return '📄';
  }
  function formatBytes(value) {
    const bytes = Math.max(0, Number(value) || 0);
    return bytes < 1024 ? `${bytes} B` : bytes < 1024*1024 ? `${(bytes/1024).toFixed(1)} KB` : `${(bytes/1024/1024).toFixed(2)} MB`;
  }

  function normalizeMediaSearch(value) {
    return String(value || '').normalize('NFKC').toLocaleLowerCase()
      .replace(/[\u064B-\u065F\u0670ـ]/g, '').replace(/[إأآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').trim();
  }

  function applyMediaFilters() {
    const grid = $('#mediaCardGrid');
    if (!grid) return;
    const query = normalizeMediaSearch($('#mediaSearch')?.value || '');
    const kind = String($('#mediaTypeFilter')?.value || 'all');
    const sort = String($('#mediaSort')?.value || 'name-asc');
    const cards = $$('.media-card', grid);
    const compareName = (a, b) => normalizeMediaSearch(a.dataset.mediaName).localeCompare(normalizeMediaSearch(b.dataset.mediaName), 'ar');
    cards.sort((a, b) => {
      if (sort === 'name-desc') return compareName(b, a);
      if (sort === 'size-desc') return Number(b.dataset.mediaSize || 0) - Number(a.dataset.mediaSize || 0) || compareName(a, b);
      if (sort === 'size-asc') return Number(a.dataset.mediaSize || 0) - Number(b.dataset.mediaSize || 0) || compareName(a, b);
      if (sort === 'date-desc') return Date.parse(b.dataset.mediaUpdated || '') - Date.parse(a.dataset.mediaUpdated || '') || compareName(a, b);
      if (sort === 'date-asc') return Date.parse(a.dataset.mediaUpdated || '') - Date.parse(b.dataset.mediaUpdated || '') || compareName(a, b);
      return compareName(a, b);
    });
    let shown = 0;
    for (const card of cards) {
      const matchesName = !query || normalizeMediaSearch(card.dataset.mediaName).includes(query) || normalizeMediaSearch(card.dataset.mediaName).split('.').some(part => part.includes(query));
      const matchesKind = kind === 'all' || card.dataset.mediaKind === kind;
      card.hidden = !(matchesName && matchesKind);
      if (!card.hidden) shown++;
      grid.appendChild(card);
    }
    const status = $('#mediaSearchStatus');
    if (status) status.textContent = `الظاهر ${shown} من ${cards.length} ملف · المحدد للإرسال ${state.selectedMedia.size}`;
    const empty = $('#mediaFilteredEmpty');
    if (empty) empty.hidden = shown > 0 || cards.length === 0;
  }

  async function loadTextPreviews() {
    for (const pre of $$('[data-text-preview]')) {
      const id = String(pre.dataset.textPreview || '');
      const item = (state.data?.media || []).find(media => String(media.id || media.filename) === id);
      if (!item?.url) { pre.textContent = 'تعذرت معاينة هذا الملف.'; continue; }
      try {
        const response = await fetch(item.url, { cache: 'no-store' });
        if (!response.ok) throw new Error('preview unavailable');
        const text = await response.text();
        pre.textContent = text.slice(0, 12000) + (text.length > 12000 ? '\n… تم اقتطاع المعاينة' : '');
      } catch { pre.textContent = 'تعذرت معاينة النص؛ افتح الملف لقراءته.'; }
    }
  }

  function taskRow(task) {
    const next = task.nextRun ? `التالي: ${new Date(task.nextRun).toLocaleString('ar-OM')}` : 'لا يوجد موعد قادم';
    return `<div class="schedule-row"><div><b>${esc(task.name || 'موعد')}</b><small>${esc(scheduleLabel(task))} · ${esc(next)}</small></div><div class="row-actions"><button class="btn small" data-run-task="${esc(task.id)}">تشغيل</button><button class="btn small" data-edit-task="${esc(task.id)}">تعديل</button><button class="btn small" data-toggle-task="${esc(task.id)}">${task.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-task="${esc(task.id)}">حذف</button></div></div>`;
  }

  function scheduleLabel(task) {
    return ({ once: 'مرة واحدة', daily: 'يوميًا', weekly: 'أسبوعيًا', monthly: 'شهريًا', yearly: 'سنويًا' }[task.mode] || task.mode) + ` · ${task.time || ''}`;
  }

  function pageAutomation(data) {
    const a = data.automation || {}, rules = a.rules || [], mutes = a.mutes || [], targets = activeTargets(data);
    const edited = state.editingAutomationRuleId ? rules.find(r => r.id === state.editingAutomationRuleId) : null;
    const rule = edited || {};
    const selectedKeys = new Set(rule.targetKeys || []), perms = a.groupPermissions || {};
    const actionLabels = { 'delete-message':'حذف الرسالة الحالية / القديمة عند الجدولة', 'delete-chat':'حذف المحادثة', 'archive-chat':'أرشفة المحادثة', 'mute-notifications':'كتم الإشعارات', 'unmute-notifications':'إلغاء كتم الإشعارات', 'cleanup-old-messages':'تنظيف الرسائل الأقدم من مدة محددة', log:'تسجيل إجراء فقط' };
    const triggerLabels = { message:'عند وصول رسالة مطابقة', 'group-message':'عند وصول رسالة في مجموعة', 'message-count':'عند تجاوز عدّاد الرسائل', time:'في وقت محدد', 'message-age':'تنظيف الرسائل حسب عمرها' };
    const fmt = value => { try { return new Date(value).toLocaleString('ar-OM'); } catch { return String(value || ''); } };
    const targetSelectOptions = targets.map(t => { const id = chatIdForTarget(t); return id ? `<option value="${esc(id)}">${esc(t.name || id)} · ${esc(typeLabel(t))}</option>` : ''; }).filter(Boolean).join('');
    return `<section class="page-title"><p class="eyebrow">Automation Control Center</p><h1>الأتمتة والتحكم بالوقت والقواعد</h1><p>قواعد زمنية وشرطية، إجراءات للمحادثات والرسائل، كتم مؤقت أو دائم، ومحفزات خاصة بالمجموعات. كل القواعد محفوظة داخل الجلسة الحالية.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>${edited ? 'تعديل قاعدة أتمتة' : 'إنشاء قاعدة أتمتة'}</h2><p>اختر الحدث والشرط والإجراء بدقة. القواعد مرتبة حسب الأولوية.</p></div></div>
          <details class="section-editor" id="automationRuleDisclosure" ${edited ? 'open' : ''}><summary>${edited ? 'تعديل قاعدة الأتمتة' : '＋ إنشاء قاعدة أتمتة'}</summary><form id="automationRuleForm">
            <div class="form-grid two"><label>اسم القاعدة<input id="autoRuleName" maxlength="100" required value="${esc(rule.name || '')}" placeholder="مثال: تنظيف نهاية اليوم"></label><label>الأولوية<input id="autoRulePriority" type="number" min="-1000" max="1000" value="${Number(rule.priority || 0)}"></label>
              <label>المحفّز<select id="autoRuleTrigger"><option value="message" ${rule.triggerType === 'message' || !rule.triggerType ? 'selected' : ''}>رسالة جديدة</option><option value="group-message" ${rule.triggerType === 'group-message' ? 'selected' : ''}>رسالة مجموعة</option><option value="message-count" ${rule.triggerType === 'message-count' ? 'selected' : ''}>عداد الرسائل</option><option value="time" ${rule.triggerType === 'time' ? 'selected' : ''}>وقت / تكرار</option><option value="message-age" ${rule.triggerType === 'message-age' ? 'selected' : ''}>عمر الرسائل (تنظيف مجدول)</option></select></label>
              <label>نوع المطابقة<select id="autoRuleMatch"><option value="any" ${rule.matchMode === 'any' || !rule.matchMode ? 'selected' : ''}>أي رسالة</option><option value="contains" ${rule.matchMode === 'contains' ? 'selected' : ''}>تحتوي العبارة</option><option value="starts" ${rule.matchMode === 'starts' ? 'selected' : ''}>تبدأ بالعبارة</option><option value="ends" ${rule.matchMode === 'ends' ? 'selected' : ''}>تنتهي بالعبارة</option><option value="exact" ${rule.matchMode === 'exact' ? 'selected' : ''}>مطابقة تامة</option><option value="regex" ${rule.matchMode === 'regex' ? 'selected' : ''}>Regex</option></select></label>
            </div>
            <label>العبارة أو النمط<input id="autoRulePattern" maxlength="500" value="${esc(rule.pattern || '')}" placeholder="مثال: مرحبا"></label>
            <div class="form-grid three"><label>الإجراء<select id="autoRuleAction">${Object.entries(actionLabels).map(([k,v]) => `<option value="${k}" ${rule.action === k || (!rule.action && k === 'log') ? 'selected' : ''}>${v}</option>`).join('')}</select></label><label>نطاق الأهداف<select id="autoRuleTargetMode"><option value="current" ${rule.targetMode === 'current' || !rule.targetMode ? 'selected' : ''}>المحادثة الحالية</option><option value="selected" ${rule.targetMode === 'selected' ? 'selected' : ''}>أهداف محددة</option><option value="all" ${rule.targetMode === 'all' ? 'selected' : ''}>كل الأشخاص والمجموعات</option></select></label><label>مهلة منع التكرار (ثانية)<input id="autoRuleCooldown" type="number" min="0" max="86400" value="${Number(rule.cooldownSec || 0)}"></label></div>
            <div class="form-grid three"><label>حدّ الرسائل<input id="autoRuleThreshold" type="number" min="1" max="100000000" value="${Number(rule.threshold || 50)}"></label><label>نطاق العدّاد<select id="autoRuleCountScope"><option value="chat" ${rule.countScope !== 'session' ? 'selected' : ''}>لكل محادثة</option><option value="session" ${rule.countScope === 'session' ? 'selected' : ''}>كل الجلسة</option></select></label><label>عمر الرسائل (ساعة)<input id="autoRuleAgeHours" type="number" min="1" max="8760" value="${Number(rule.ageHours || 24)}"></label></div>
            <div class="form-grid four"><label>وقت التشغيل<input id="autoRuleTime" type="time" required value="${esc(rule.time || '22:00')}"></label><label>التكرار<select id="autoRuleMode"><option value="daily" ${rule.mode === 'daily' || !rule.mode ? 'selected' : ''}>يومي</option><option value="weekly" ${rule.mode === 'weekly' ? 'selected' : ''}>أسبوعي</option><option value="monthly" ${rule.mode === 'monthly' ? 'selected' : ''}>شهري</option><option value="yearly" ${rule.mode === 'yearly' ? 'selected' : ''}>سنوي</option><option value="once" ${rule.mode === 'once' ? 'selected' : ''}>مرة واحدة</option></select></label><label>تاريخ مرة واحدة<input id="autoRuleDate" type="date" value="${esc(rule.date || '')}"></label><label>اليوم الأسبوعي<select id="autoRuleDay">${['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'].map((v,i)=>`<option value="${i}" ${Number(rule.day ?? 5) === i ? 'selected' : ''}>${v}</option>`).join('')}</select></label></div>
            <div class="form-grid four"><label>يوم الشهر<input id="autoRuleDayOfMonth" type="number" min="1" max="31" value="${Number(rule.dayOfMonth || 1)}"></label><label>الشهر السنوي<input id="autoRuleMonth" type="number" min="1" max="12" value="${Number(rule.month || 1)}"></label><label>الحد الأدنى للرسائل<input id="autoRuleMinCount" type="number" min="0" value="${Number(rule.minMessageCount || 0)}"></label><label>الحد الأقصى للرسائل<input id="autoRuleMaxCount" type="number" min="0" value="${Number(rule.maxMessageCount || 0)}"></label></div>
            <div class="form-grid two"><label>شرط إضافي: تحتوي الرسالة<input id="autoRuleConditionContains" value="${esc(rule.conditionContains || '')}" placeholder="اختياري"></label><label>محادثات إضافية (JID، كل سطر معرّف)<textarea id="autoRuleChatIds" rows="2" placeholder="120363...@g.us">${esc((rule.targetChatIds || []).join('\n'))}</textarea></label></div>
            <div class="automation-target-picker"><b>الأهداف المحفوظة</b><small>تُستخدم عندما يكون نطاق الأهداف «أهداف محددة» أو «كل الأهداف».</small><div class="target-list">${targets.length ? targets.map(t => `<label class="target-row"><input type="checkbox" class="automation-target" value="${esc(t.key)}" ${selectedKeys.has(t.key) ? 'checked' : ''}><span class="target-mark ${t.type === 'group' ? 'group' : 'recipient'}">${t.type === 'group' ? '◆' : '●'}</span><span class="target-main"><b>${esc(t.name || t.gid || t.phone || 'هدف')}</b><small>${esc(typeLabel(t))} · ${esc(chatIdForTarget(t) || '')}</small></span></label>`).join('') : '<div class="empty">أضف أشخاصًا أو مجموعات أولًا.</div>'}</div></div>
            <div class="form-grid two"><label class="toggle-box"><input id="autoRuleMutePermanent" type="checkbox" ${rule.mutePermanent ? 'checked' : ''}><span>كتم دائم عند تنفيذ القاعدة</span></label><label>مدة الكتم بالدقائق<input id="autoRuleMuteMinutes" type="number" min="1" max="525600" value="${Number(rule.muteMinutes || 60)}"></label></div>
            <div class="toggle-list"><label class="toggle-row"><input id="autoRuleRepeatCount" type="checkbox" ${rule.repeatCount ? 'checked' : ''}><span><b>إعادة التشغيل عند كل مضاعف للحد</b><small>مثل 50 و100 و150 رسالة بدل تشغيلها مرة واحدة.</small></span></label><label class="toggle-row"><input id="autoRuleRequireAdmin" type="checkbox" ${rule.requireGroupAdmin ? 'checked' : ''}><span><b>اشتراط أن يكون المرسل مشرف مجموعة</b><small>يعتمد على بيانات المشرفين التي حصل عليها WhatsApp.</small></span></label><label class="toggle-row"><input id="autoRuleDeleteEveryone" type="checkbox" ${rule.deleteForEveryone ? 'checked' : ''}><span><b>طلب الحذف لدى الجميع</b><small>قد يرفض WhatsApp الطلب بسبب الصلاحيات أو القيود الزمنية؛ الافتراضي حذف من حسابك فقط.</small></span></label><label class="toggle-row"><input id="autoRuleConfirmDestructive" type="checkbox" ${rule.confirmDestructive ? 'checked' : ''}><span><b>أؤكد تنفيذ الحذف أو تنظيف الرسائل</b><small>مطلوب صراحة للإجراءات التي قد تزيل بيانات.</small></span></label></div>
            <div class="action-bar"><button class="btn primary" type="submit">${edited ? 'حفظ التعديلات' : 'إنشاء القاعدة'}</button>${edited ? '<button class="btn" id="cancelAutoRuleEdit" type="button">إلغاء التعديل</button>' : ''}</div>
          </form></details>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>صلاحيات الأتمتة في المجموعات</h2><p>العمليات الحساسة متوقفة افتراضيًا. اضبطها حسب إدارة المالك.</p></div></div><div class="toggle-list">
          ${[['allowDeleteMessage','السماح بحذف الرسائل من المجموعات'],['allowDeleteChat','السماح بحذف محادثات المجموعات من القائمة'],['allowArchive','السماح بأرشفة المجموعات'],['allowMute','السماح بكتم مجموعات'],['adminsOnly','تطبيق محفزات رسائل المجموعة على المشرفين فقط']].map(([k,label]) => `<label class="toggle-row"><input type="checkbox" class="automation-permission" data-permission="${k}" ${perms[k] ? 'checked' : ''}><span><b>${label}</b></span></label>`).join('')}
          </div><div class="action-bar"><button id="saveAutomationPermissions" class="btn primary">حفظ الصلاحيات</button></div>
          <div class="divider-line"></div><div class="panel-head"><div><h2>قواعد الأتمتة</h2><p>${rules.length} قاعدة محفوظة · ${rules.filter(r=>r.enabled !== false).length} مفعّلة</p></div></div>
          <div class="schedule-list">${rules.length ? rules.map(r => `<div class="schedule-row"><div><b>${esc(r.name)}</b><small>${esc(triggerLabels[r.triggerType] || r.triggerType)} · ${esc(actionLabels[r.action] || r.action)} · أولوية ${Number(r.priority || 0)}${['time','message-age'].includes(r.triggerType) ? ` · ${esc(r.time || '')} · ${esc(r.mode || 'daily')}` : ''}${r.lastRunKey ? ` · آخر تشغيل: ${esc(r.lastRunKey.split('|').slice(-2).join(' '))}` : ''}</small><small class="mini-state ${r.enabled === false ? 'off' : ''}">${r.enabled === false ? 'متوقفة' : 'مفعّلة'}</small></div><div class="row-actions">${['time','message-age'].includes(r.triggerType) ? `<button class="btn small" data-run-auto-rule="${esc(r.id)}">تشغيل</button>` : ''}<button class="btn small" data-edit-auto-rule="${esc(r.id)}">تعديل</button><button class="btn small" data-toggle-auto-rule="${esc(r.id)}">${r.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-auto-rule="${esc(r.id)}">حذف</button></div></div>`).join('') : '<div class="empty">لم تنشئ قواعد أتمتة بعد.</div>'}</div>
        </article>
      </section>
      <section class="content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>كتم الإشعارات</h2><p>كتم جهة اتصال أو مجموعة لمدة محددة أو بلا مدة حتى تلغيها يدويًا.</p></div></div><form id="automationMuteForm"><label>هدف محفوظ<select id="muteSavedTarget"><option value="">اختر جهة اتصال أو مجموعة (اختياري)</option>${targetSelectOptions}</select></label><label>معرّف المحادثة<input id="muteChatId" required placeholder="رقم@c.us أو GID@ g.us"></label><div class="form-grid two"><label>المدة<select id="muteMode"><option value="temporary">مؤقت</option><option value="permanent">دائم حتى الإلغاء اليدوي</option></select></label><label>الدقائق<input id="muteMinutes" type="number" min="1" max="525600" value="60"></label></div><div class="action-bar"><button class="btn primary" type="submit">كتم المحادثة</button></div></form>
          <div class="schedule-list">${mutes.length ? mutes.slice().reverse().map(m => `<div class="schedule-row"><div><b>${esc(m.chatName || m.chatId)}</b><small>${m.chatType === 'group' ? 'مجموعة' : 'محادثة خاصة'} · ${m.mode === 'permanent' ? 'دائم' : `حتى ${esc(fmt(m.expiresAt))}`}</small><small class="mini-state ${m.enabled === false ? 'off' : ''}">${m.enabled === false ? 'منتهٍ أو ملغى' : 'مفعّل'}</small></div><div class="row-actions">${m.enabled !== false ? `<button class="btn small" data-unmute-record="${esc(m.id)}">إلغاء الكتم</button>` : ''}<button class="btn danger small" data-delete-mute="${esc(m.id)}">حذف السجل</button></div></div>`).join('') : '<div class="empty">لا توجد سجلات كتم محفوظة.</div>'}</div>
        </article><article class="panel"><div class="panel-head"><div><h2>سجل التنفيذ</h2><p>عمليات الأتمتة ونتائجها الأخيرة.</p></div></div><div class="schedule-list">${(a.recent || []).slice().reverse().slice(0,30).map(x => `<div class="schedule-row"><div><b>${esc(x.name || x.action || 'إجراء آلي')}</b><small>${esc(fmt(x.at))} · ${esc(x.action || '')}</small><small class="mini-state ${x.ok ? '' : 'off'}">${x.ok ? 'نجح' : 'تعذر'}</small>${x.error ? `<small>${esc(x.error)}</small>` : ''}</div></div>`).join('') || '<div class="empty">لا توجد عمليات مسجلة بعد.</div>'}</div><div class="action-bar"><button id="refreshAutomationBtn" class="btn">تحديث السجل</button></div></article></section>`;
  }

  function whatsappContactPageInfo() {
    const contacts = Array.isArray(state.whatsappContacts) ? state.whatsappContacts : [];
    const needle = String(state.whatsappContactFilter || '').normalize('NFKC').trim().toLocaleLowerCase('ar');
    const filtered = contacts.filter(contact => `${contact.name || ''} ${contact.pushname || ''} ${contact.notifyName || ''} ${contact.digits || ''} ${contact.jid || ''}`.normalize('NFKC').toLocaleLowerCase('ar').includes(needle));
    const pageSize = Math.max(10, Math.min(100, Number(state.whatsappContactsPageSize) || 50));
    const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
    const page = Math.max(1, Math.min(pages, Number(state.whatsappContactsPage) || 1));
    if (page !== state.whatsappContactsPage) state.whatsappContactsPage = page;
    const start = (page - 1) * pageSize;
    return { contacts, filtered, visible: filtered.slice(start, start + pageSize), page, pages, pageSize, start, end: Math.min(start + pageSize, filtered.length), total: filtered.length };
  }

  function whatsappContactPagination() {
    if (!Array.isArray(state.whatsappContacts)) return '';
    const info = whatsappContactPageInfo();
    const range = info.total ? `${(info.start + 1).toLocaleString('ar')}–${info.end.toLocaleString('ar')} من ${info.total.toLocaleString('ar')}` : 'لا توجد نتائج';
    return `<button type="button" id="previousWhatsAppContactsPage" class="btn small" ${info.page <= 1 ? 'disabled' : ''}>السابق</button><span class="muted-note" aria-live="polite">صفحة ${info.page.toLocaleString('ar')} من ${info.pages.toLocaleString('ar')} · عرض ${range}</span><label class="wa-page-size-label" for="whatsappContactPageSize">في الصفحة <select id="whatsappContactPageSize"><option value="25" ${info.pageSize === 25 ? 'selected' : ''}>25</option><option value="50" ${info.pageSize === 50 ? 'selected' : ''}>50</option><option value="100" ${info.pageSize === 100 ? 'selected' : ''}>100</option></select></label><button type="button" id="nextWhatsAppContactsPage" class="btn small" ${info.page >= info.pages ? 'disabled' : ''}>التالي</button>`;
  }

  function whatsappContactRows() {
    const info = whatsappContactPageInfo();
    const contacts = info.contacts;
    const visible = info.visible;
    if (!visible.length) return `<div class="empty">${contacts.length ? 'لا توجد جهات تطابق البحث.' : 'لم يتم العثور على جهات رقمية قابلة للمزامنة.'}</div>`;
    return visible.map(contact => {
      const displayName = contact.name || contact.pushname || contact.notifyName || `+${contact.digits}`;
      const pictureUrl = contact.pictureUrl || `/api/whatsapp/contact-picture?sessionId=${encodeURIComponent(sid())}&jid=${encodeURIComponent(contact.jid)}`;
      const initial = Array.from(String(displayName).trim())[0] || '•';
      const profileName = String(contact.pushname || contact.notifyName || '').trim();
      const nameCaption = contact.isMyContact
        ? (profileName && profileName !== displayName ? `اسم دفتر العناوين · اسم ملف الحساب: ${profileName}` : 'اسم محفوظ في دفتر عناوين WhatsApp')
        : 'الاسم الظاهر في ملف WhatsApp';
      const digits = String(contact.digits || '').replace(/\D/g, '');
      const existing = (state.data?.recipients || []).find(person => String(person.whatsappJid || '').toLowerCase() === String(contact.jid).toLowerCase() || digits && String(person.digits || person.e164 || person.phone || '').replace(/\D/g, '') === digits);
      const actionLabel = existing ? 'تحديث الصورة والبيانات' : 'إضافة إلى الإرسال';
      const pictureFallbackUrl = contact.pictureFallbackUrl || `/api/whatsapp/contact-picture?sessionId=${encodeURIComponent(sid())}&jid=${encodeURIComponent(contact.jid)}`;
      return `<div class="wa-contact-option whatsapp-contact-row"><input type="checkbox" aria-label="تحديد ${esc(displayName)}" data-wa-contact-select="${esc(contact.jid)}" ${state.whatsappContactsSelected.has(contact.jid) ? 'checked' : ''}><span class="person-avatar small-avatar wa-contact-avatar-wrap"><img class="wa-contact-photo" src="${esc(pictureUrl)}" data-fallback-url="${esc(pictureFallbackUrl)}" alt="صورة ${esc(displayName)}" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="if(this.dataset.fallbackUrl && this.src!==this.dataset.fallbackUrl){this.src=this.dataset.fallbackUrl;this.dataset.fallbackUrl='';}else if(this.dataset.photoRetry!=='1'){this.dataset.photoRetry='1';const u=new URL(this.src,location.href);u.searchParams.set('refresh','1');u.searchParams.set('retry',String(Date.now()));setTimeout(()=>{this.src=u.href;},650);}else{this.parentElement.classList.add('avatar-image-failed');this.hidden=true;}"><span class="avatar-fallback">${esc(initial)}</span></span><span class="wa-contact-main person-main"><b>${esc(displayName)}</b><small dir="ltr">+${esc(contact.digits)}</small><small>${esc(nameCaption)}${contact.profileSynced ? ' · تمت مزامنة الصورة' : ' · الصورة خاصة أو غير متاحة'}</small></span><button type="button" class="btn small wa-contact-import" data-import-wa-contact="${esc(contact.jid)}">${actionLabel}</button></div>`;
    }).join('');
  }

  function refreshWhatsAppContactList() {
    const list = $('#whatsappContactsList'); if (list) list.innerHTML = whatsappContactRows();
    const pagination = $('#whatsappContactsPagination'); if (pagination) pagination.innerHTML = whatsappContactPagination();
    bindWhatsAppContactCheckboxes();
    bindWhatsAppContactImportButtons();
    refreshWhatsAppSelectionUI();
  }

  function pagePeople(data) {
    const filter = state.peopleFilter.trim().toLocaleLowerCase('ar');
    const allRecipients = data.recipients || [];
    const validIds = new Set(allRecipients.map(person => String(person.id)));
    for (const id of state.selectedRecipientIds) if (!validIds.has(String(id))) state.selectedRecipientIds.delete(id);
    const recipients = allRecipients.filter((item) => `${item.name || ''} ${item.international || ''} ${item.e164 || ''}`.toLocaleLowerCase('ar').includes(filter));
    const selectedVisible = recipients.filter(person => state.selectedRecipientIds.has(String(person.id))).length;
    return `<section class="page-title"><p class="eyebrow">الأشخاص</p><h1>جهات الإرسال</h1><p>الأرقام منفصلة حسب الجلسة الحالية، وتدعم رموز الدول تلقائيًا. يمكنك تحديد عدة أشخاص وحذفهم دفعة واحدة أو ضبط رد مستقل لكل شخص.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>إضافة شخص</h2><p>اختر الدولة أو اكتب الرقم بصيغة دولية مباشرة.</p></div></div>
          <div class="form-grid three"><label>الاسم<input id="recipientName" placeholder="اسم الشخص"></label><label>الدولة<select id="recipientCountry">${countryOptions('OM')}</select></label><label>رقم الهاتف<input id="recipientPhone" inputmode="tel" placeholder="+968 9xxxxxxx"></label></div>
          <div id="phonePreview" class="inline-status">اكتب الرقم لمراجعته.</div>
          <div class="action-bar"><button class="btn primary" id="addRecipientBtn">إضافة الشخص</button></div>
          <details class="advanced-panel"><summary>إضافة قائمة أرقام</summary><p>سطر لكل رقم: الاسم|الرقم</p><textarea id="bulkRecipients" rows="5" placeholder="أحمد|+96890000000\nSara|+966500000000"></textarea><button class="btn" id="bulkAddBtn">إضافة القائمة</button></details>
          <details class="advanced-panel whatsapp-sync-panel" id="whatsappContactsDisclosure" ${state.whatsappContactsOpen ? 'open' : ''}><summary>استدعاء ومزامنة جهات WhatsApp</summary>
            <p>استدعِ الأسماء الحالية وصور الحساب المتاحة، ثم اضغط «إضافة إلى الإرسال» بجانب أي شخص أو حدّد عدة أشخاص واضغط زر الإضافة أسفل القائمة. تُحفظ الجهة فورًا في المشروع وقائمة الإرسال؛ ولا تتغير الأسماء المحلية الحالية افتراضيًا.</p>
            <div class="action-bar"><button type="button" class="btn primary" id="loadWhatsAppContactsBtn" ${state.whatsappContactsBusy ? 'disabled' : ''}>${state.whatsappContactsBusy ? 'جارٍ الاستدعاء…' : state.whatsappContacts ? 'تحديث جهات WhatsApp' : 'استدعاء جهات WhatsApp'}</button>${Array.isArray(state.whatsappContacts) ? '<button type="button" class="btn" id="syncWhatsAppProfilesBtn" ' + (state.whatsappContactsBusy || !state.whatsappContactsSelected.size ? 'disabled' : '') + '>تحديث صور المحدد</button>' : ''}<span class="sync-connection-note">${state.data?.whatsapp?.ready ? 'متصل' : 'اتصل بواتساب أولًا'}</span></div>
            <div id="whatsappContactsStatus" class="inline-status">${state.whatsappContactsBusy ? 'يتم استدعاء جهات الاتصال…' : state.whatsappContacts ? `تم العثور على ${state.whatsappContacts.length} جهة رقمية ضمن الحد الحالي (2,000 جهة). ابحث واستخدم الصفحات لعرض النتائج.` : 'اضغط «استدعاء جهات WhatsApp» لتحميل جهات الحساب المتصل.'}</div>
            ${Array.isArray(state.whatsappContacts) ? `<div class="wa-contact-tools"><input id="whatsappContactFilter" value="${esc(state.whatsappContactFilter)}" placeholder="ابحث في جهات WhatsApp…"><div class="action-bar"><button type="button" id="selectAllWhatsAppContacts" class="btn small">تحديد الظاهر</button><button type="button" id="clearWhatsAppContacts" class="btn small">إلغاء التحديد</button><span class="release-pill">محدد: <b id="whatsappSelectedCount">${state.whatsappContactsSelected.size}</b></span></div></div>
              <div class="wa-contact-list" id="whatsappContactsList">${whatsappContactRows()}</div>
              <div class="action-bar whatsapp-contact-pagination" id="whatsappContactsPagination">${whatsappContactPagination()}</div>
              <div class="wa-sync-options"><div class="inline-status">سيتم إضافة الجهات الجديدة تلقائيًا إلى قائمة الإرسال، وتحديث بيانات الجهات الموجودة دون إنشاء تكرار.</div><label class="toggle-row"><input id="syncWhatsAppUpdateNames" type="checkbox"><span><b>تحديث الأسماء المحلية بأسماء WhatsApp</b><small>اتركه مغلقًا للمحافظة على الأسماء التي كتبتها في المشروع.</small></span></label><label class="toggle-row"><input id="syncWhatsAppUpdatePictures" type="checkbox" checked><span><b>مزامنة صور الملف الشخصي</b><small>حتى 100 جهة في كل دفعة؛ تُحفظ الجهات فورًا وتُحدّث الصور في الخلفية داخل الجلسة الحالية.</small></span></label></div>
              <div class="action-bar"><button type="button" id="syncWhatsAppContactsBtn" class="btn primary" ${state.whatsappContactsSelected.size ? '' : 'disabled'}>إضافة المحدد إلى قائمة الإرسال (${state.whatsappContactsSelected.size})</button></div>` : ''}
          </details>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الأشخاص المحفوظون</h2><p>${recipients.length} من ${allRecipients.length} شخص · محدد ${state.selectedRecipientIds.size}</p></div><span class="release-pill">${allRecipients.length} محفوظ</span></div>
          <input id="peopleSearch" value="${esc(state.peopleFilter)}" placeholder="بحث بالاسم أو الرقم...">
          <div class="people-selection-bar"><label class="people-select-all"><input id="selectVisiblePeople" type="checkbox" ${recipients.length && selectedVisible === recipients.length ? 'checked' : ''} ${recipients.length ? '' : 'disabled'}><span>تحديد الأشخاص الظاهرين (${selectedVisible}/${recipients.length})</span></label><button class="btn danger small" id="deleteSelectedPeopleBtn" ${state.selectedRecipientIds.size ? '' : 'disabled'}>حذف المحدد (${state.selectedRecipientIds.size})</button></div>
          <div class="people-list">${recipients.length ? recipients.map(personRow).join('') : '<div class="empty">لا توجد نتائج.</div>'}</div>
        </article>
      </section>`;
  }

  function personalRuleEditor(rule = {}, index = 0) {
    const modes = [['contains','تحتوي على'],['exact','تطابق تمامًا'],['startsWith','تبدأ بـ'],['endsWith','تنتهي بـ'],['any','أي رسالة']];
    return `<div class="personal-rule-row" data-person-rule-row data-rule-id="${esc(rule.id || '')}">
      <div class="personal-rule-heading"><b>قاعدة شخصية ${index + 1}</b><button type="button" class="btn danger small" data-delete-person-rule>حذف القاعدة</button></div>
      <div class="form-grid two"><label>اسم القاعدة<input data-person-rule-name maxlength="100" value="${esc(rule.name || `قاعدة ${index + 1}`)}" required></label><label>نوع المطابقة<select data-person-rule-match>${modes.map(([value,label]) => `<option value="${value}" ${String(rule.match || 'contains') === value ? 'selected' : ''}>${label}</option>`).join('')}</select></label></div>
      <label>نص المطابقة<input data-person-rule-value maxlength="500" value="${esc(rule.value || '')}" placeholder="مثال: سعر المنتج"></label>
      <label>الرد الذي سيُرسل<textarea data-person-rule-reply rows="3" maxlength="4000" required placeholder="اكتب الرد، ويمكنك استخدام {{sender}} و{{message}} و{{chat}} و{{time}}">${esc(rule.reply || '')}</textarea></label>
      <label class="toggle-box"><input data-person-rule-enabled type="checkbox" ${rule.enabled === false ? '' : 'checked'}><span>القاعدة مفعّلة</span></label>
    </div>`;
  }

  function personRow(person) {
    const profile = person.replyProfile || {};
    const mode = ['inherit', 'custom', 'disabled'].includes(profile.mode) ? profile.mode : 'inherit';
    const rules = Array.isArray(profile.rules) ? profile.rules.slice(0, 30) : [];
    const pictureUrl = person.avatarUrl || (person.localAvatarFile ? `/api/recipient/${encodeURIComponent(person.id)}/avatar?sessionId=${encodeURIComponent(sid())}` : person.whatsappProfilePhoto ? `/profile/${encodeURIComponent(person.whatsappProfilePhoto)}?sessionId=${encodeURIComponent(sid())}` : (person.whatsappJid ? `/api/whatsapp/contact-picture?sessionId=${encodeURIComponent(sid())}&jid=${encodeURIComponent(person.whatsappJid)}` : ''));
    const fallbackPictureUrl = person.whatsappJid ? `/api/whatsapp/contact-picture?sessionId=${encodeURIComponent(sid())}&jid=${encodeURIComponent(person.whatsappJid)}` : `/api/recipient/${encodeURIComponent(person.id)}/whatsapp-avatar?sessionId=${encodeURIComponent(sid())}`;
    const waName = person.whatsappPushname || person.whatsappName || '';
    const waBookName = person.whatsappName || ''; 
    const initial = Array.from(String(person.displayName || person.localName || person.name || waName || '•').trim())[0] || '•';
    return `<article class="person-record" data-person-record="${esc(person.id)}"><div class="person-row"><label class="person-select-label" aria-label="تحديد ${esc(person.name || 'الشخص')}"><input type="checkbox" class="person-select" data-person-select="${esc(person.id)}" ${state.selectedRecipientIds.has(String(person.id)) ? 'checked' : ''}><span class="sr-only">تحديد الشخص</span></label><div class="person-main"><span class="person-avatar-wrap"><span class="person-avatar-fallback">${esc(initial)}</span>${pictureUrl ? `<img class="person-profile-photo" src="${esc(pictureUrl)}" data-fallback-url="${esc(fallbackPictureUrl)}" alt="صورة ${esc(person.displayName || waName || person.name || 'الشخص')}" loading="lazy" decoding="async" onerror="if(this.dataset.fallbackUrl && this.src!==this.dataset.fallbackUrl){this.src=this.dataset.fallbackUrl;this.dataset.fallbackUrl='';}else if(this.dataset.photoRetry!=='1'){this.dataset.photoRetry='1';const u=new URL(this.src,location.href);u.searchParams.set('refresh','1');u.searchParams.set('retry',String(Date.now()));setTimeout(()=>{this.src=u.href;},650);}else{this.hidden=true;}">` : ''}</span><b>${esc(person.displayName || person.localName || person.name || waName || 'بدون اسم')}</b><small>${esc(person.international || person.e164 || person.phone || '')} · ${esc(person.country || '')}</small>${waName && waName !== person.name ? `<small class="whatsapp-live-name">اسم ملف WhatsApp: ${esc(waName)}</small>` : ''}${waBookName && waBookName !== person.name && waBookName !== waName ? `<small class="whatsapp-live-name">اسم دفتر العناوين: ${esc(waBookName)}</small>` : ''}<small class="personal-reply-status">${mode === 'custom' ? `ردود شخصية (${rules.length} قاعدة)` : mode === 'disabled' || profile.enabled === false ? 'الرد الشخصي متوقف' : 'يرث القواعد العامة'}</small></div><span class="mini-state ${person.enabled === false ? 'off' : ''}">${person.enabled === false ? 'متوقف' : 'مفعّل'}</span><div class="row-actions person-tools"><button type="button" class="btn small" data-avatar-open="${esc(person.id)}" title="رفع صورة محلية لهذا الشخص">تغيير الصورة</button><input type="file" accept="image/jpeg,image/png,image/webp,image/gif,image/avif" data-avatar-file="${esc(person.id)}" hidden><button type="button" class="btn small" data-reset-avatar="${esc(person.id)}" ${person.localAvatarFile ? '' : 'disabled'} title="حذف الصورة المحلية والعودة لصورة WhatsApp">استعادة WA</button><button class="btn small" data-toggle-person="${esc(person.id)}">${person.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-person="${esc(person.id)}">حذف</button></div></div>
      <details class="personal-reply-editor"><summary>إعداد الرد التلقائي لهذا الشخص</summary><form class="personal-reply-form" data-person-reply-form="${esc(person.id)}">
        <div class="form-grid two"><label>وضع الرد<select data-person-profile-mode><option value="inherit" ${mode === 'inherit' ? 'selected' : ''}>استخدم القواعد العامة</option><option value="custom" ${mode === 'custom' ? 'selected' : ''}>قواعد وردود خاصة</option><option value="disabled" ${mode === 'disabled' ? 'selected' : ''}>تعطيل الرد لهذا الشخص</option></select></label><label>فترة التهدئة بين الردود (ثانية)<input data-person-profile-cooldown type="number" min="0" max="86400" value="${Number.isFinite(Number(profile.cooldownSec)) ? Math.max(0, Math.min(86400, Number(profile.cooldownSec))) : 45}"></label></div>
        <label class="toggle-box"><input data-person-profile-enabled type="checkbox" ${profile.enabled === false ? '' : 'checked'}><span>السماح بالرد التلقائي لهذا الشخص</span></label>
        <label>الرد الافتراضي عند عدم تطابق قاعدة شخصية<textarea data-person-profile-default rows="3" maxlength="4000" placeholder="اتركه فارغًا لاستخدام خيار الرجوع إلى القواعد العامة">${esc(profile.defaultReply || '')}</textarea></label>
        <label class="toggle-box"><input data-person-profile-fallback type="checkbox" ${profile.fallbackToGlobal === false ? '' : 'checked'}><span>الرجوع إلى القواعد العامة إذا لم تطابق قاعدة شخصية ولم يوجد رد افتراضي</span></label>
        <div class="personal-rules-head"><div><b>قواعد الرد الخاصة</b><small>حد أقصى 30 قاعدة للشخص. الأنواع مدعومة محليًا ولا تحتاج API خارجي.</small></div><span class="release-pill"><span data-person-rule-count>${rules.length}</span>/30</span></div>
        <div class="personal-rules-list" data-person-rules>${rules.map((rule,i)=>personalRuleEditor(rule,i)).join('') || '<div class="empty" data-person-rules-empty>لا توجد قواعد شخصية؛ يمكن استخدام الرد الافتراضي أو القواعد العامة.</div>'}</div>
        <div class="action-bar"><button type="button" class="btn" data-add-person-rule>＋ إضافة قاعدة</button><button type="submit" class="btn primary">حفظ إعداد الرد الشخصي</button></div>
      </form></details></article>`;
  }

  function conversationMessageKey(item) {
    const id = String(item?.messageId || item?.id || '').trim();
    const chat = String(item?.chatId || state.conversationTargetKey || '');
    return id ? `${chat}|${id}` : `${chat}|${Number(item?.timestampMs || 0)}|${String(item?.body || item?.caption || '').slice(0,80)}`;
  }

  function renderConversationMessage(item, selected = null) {
    const title = item?.fromMe ? 'أنت / البوت' : (item?.senderName || selected?.label || 'الطرف الآخر');
    const content = String(item?.body || item?.caption || '').trim();
    const time = item?.at || (item?.timestampMs ? new Date(item.timestampMs).toISOString() : '');
    let timeLabel = 'وقت غير معروف';
    try { if (time) timeLabel = new Date(time).toLocaleString('ar', { dateStyle: 'medium', timeStyle: 'short' }); } catch {}
    const media = item?.hasMedia ? `<div class="conversation-attachment"><span aria-hidden="true">📎</span><span>${esc(item.filename || item.mimetype || item.type || 'مرفق')}</span><small>بيانات المرفق محفوظة؛ الملف نفسه يحتاج تنزيلًا من «الإرسال/الوسائط» إن لم يكن قد نُزّل.</small></div>` : '';
    return `<article class="conversation-message ${item?.fromMe ? 'own' : 'incoming'}" data-message-key="${esc(conversationMessageKey(item))}"><div class="conversation-message-meta"><b>${esc(title)}</b><time datetime="${esc(time)}">${esc(timeLabel)}</time></div>${content ? `<p dir="auto">${esc(content)}</p>` : (item?.hasMedia ? '<p class="conversation-empty-body">رسالة تحتوي على مرفق ولا يتوفر نص قابل للعرض.</p>' : '<p class="conversation-empty-body">رسالة بلا نص.</p>')}${media}<div class="conversation-message-foot"><span>${esc(item?.type || 'رسالة')}</span>${item?.fromMe ? '<span>صادرة</span>' : '<span>واردة</span>'}</div></article>`;
  }

  function stopConversationPolling() {
    if (state.conversationPollTimer) clearInterval(state.conversationPollTimer);
    state.conversationPollTimer = null;
    state.conversationPollSession = '';
    state.conversationPollBusy = false;
  }

  function startConversationPolling() {
    const sessionId = sid();
    if (state.conversationPollTimer && state.conversationPollSession === sessionId) return;
    stopConversationPolling();
    if (!sessionId) return;
    state.conversationPollSession = sessionId;
    state.conversationPollTimer = setInterval(() => { refreshLiveConversation().catch(() => {}); }, 2200);
  }

  async function refreshLiveConversation() {
    const sessionId = sid();
    const targetKey = state.conversationTargetKey || 'self';
    const query = state.conversationQuery || '';
    const routeKey = `${sessionId}|${targetKey}|${query}`;
    if (state.page !== 'conversations' || !sessionId || query || state.conversationBusy || state.conversationPollBusy || state.conversationPollSession !== sessionId || state.conversationLoadedKey !== routeKey) return;
    state.conversationPollBusy = true;
    try {
      const params = new URLSearchParams({ sessionId, targetKey, limit: '100' });
      const result = await api(`/api/conversations/messages?${params.toString()}`);
      if (state.page !== 'conversations' || sid() !== sessionId || (state.conversationTargetKey || 'self') !== targetKey || state.conversationQuery || state.conversationLoadedKey !== routeKey) return;
      const received = Array.isArray(result.messages) ? result.messages : [];
      const prior = Array.isArray(state.conversationMessages) ? state.conversationMessages : [];
      const priorKeys = new Set(prior.map(conversationMessageKey));
      const merged = new Map(prior.map(item => [conversationMessageKey(item), item]));
      for (const item of received) merged.set(conversationMessageKey(item), item);
      const sorted = [...merged.values()].sort((a, b) => Number(a.timestampMs || 0) - Number(b.timestampMs || 0));
      state.conversationMessages = sorted.length > 1000 ? sorted.slice(-1000) : sorted;
      state.conversationMeta = { totalStoredForTarget: result.totalStoredForTarget, hasOlder: result.hasOlder, nextBefore: result.nextBefore, nextCursor: result.nextCursor || null, oldestTimestampMs: result.oldestTimestampMs };
      const added = received.some(item => !priorKeys.has(conversationMessageKey(item)));
      if (added) {
        const thread = $('#conversationThread');
        if (thread) {
          const stayAtBottom = thread.scrollHeight - thread.scrollTop - thread.clientHeight < 100;
          const previousTop = thread.scrollTop;
          const selected = state.conversationTargets.find(item => item.key === targetKey) || null;
          thread.innerHTML = state.conversationMessages.map(item => renderConversationMessage(item, selected)).join('') || '<div class="empty">لا توجد رسائل محفوظة بعد.</div>';
          thread.scrollTop = stayAtBottom ? thread.scrollHeight : previousTop;
        }
        const count = $('#conversationDisplayCount');
        if (count) count.textContent = `عدد النتائج المعروضة: ${state.conversationMessages.length.toLocaleString('ar')}`;
        const older = $('.conversation-load-older');
        if (!older && state.conversationMeta.hasOlder) {
          const footer = $('.conversation-footer');
          if (footer) footer.insertAdjacentHTML('beforebegin', '<div class="conversation-load-older"><button type="button" class="btn" id="conversationLoadOlder">تحميل رسائل أقدم</button></div>');
          $('#conversationLoadOlder')?.addEventListener('click', async () => {
            if (state.conversationBusy || !state.conversationMeta?.hasOlder) return;
            const before = state.conversationMeta.nextCursor || state.conversationMeta.nextBefore;
            if (before === null || before === undefined) return;
            await loadConversationMessages({ before, append: true }); render();
          });
        }
      }
      const stamp = $('#conversationLiveAt');
      if (stamp) stamp.textContent = `آخر تحديث ${new Date().toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`;
    } finally { state.conversationPollBusy = false; }
  }

  function pageConversations(data) {
    const sessionId = String(data.session?.id || sid() || '');
    const targets = state.conversationTargetsSession === sessionId ? state.conversationTargets : [];
    const selectedKey = state.conversationTargetKey || 'self';
    const selected = targets.find(item => item.key === selectedKey) || targets[0] || null;
    const rows = state.conversationMessages || [];
    const meta = state.conversationMeta || {};
    const targetList = targets.map(target => `<button type="button" class="conversation-target-btn ${target.key === selectedKey ? 'active' : ''}" data-conversation-target="${esc(target.key)}"><span class="conversation-target-icon">${target.type === 'self' ? '🤖' : target.type === 'group' ? '👥' : '👤'}</span><span class="conversation-target-main"><b>${esc(target.label)}</b><small>${Number(target.archivedCount || 0).toLocaleString('ar')} رسالة محفوظة · ${Number(target.mediaCount || 0).toLocaleString('ar')} مرفق</small>${target.lastText ? `<small class="conversation-target-last">${esc(target.lastText)}</small>` : ''}</span>${target.key === selectedKey ? '<span class="conversation-target-mark">✓</span>' : ''}</button>`).join('');
    const orphans = state.conversationOrphansSession === sessionId ? state.conversationOrphans : [];
    const orphanRows = orphans.map(orphan => {
      const options = (orphan.candidateTargets || []).map(target => `<option value="${esc(target.key)}">${esc(target.label)} · ${target.type === 'group' ? 'مجموعة' : target.type === 'self' ? 'محادثة النفس' : 'شخص'}</option>`).join('');
      const canRelink = orphan.restorable === true && (orphan.candidateTargets || []).length > 0;
      return `<article class="conversation-orphan-row"><div class="conversation-orphan-info"><b>${esc(orphan.chatId || 'معرّف غير محسوم')}</b><small>${Number(orphan.count || 0).toLocaleString('ar')} رسالة محفوظة · ${Number(orphan.mediaCount || 0).toLocaleString('ar')} مرفق</small>${orphan.lastText ? `<small>${esc(orphan.lastText)}</small>` : ''}</div>${canRelink ? `<div class="conversation-orphan-actions"><label>اربط السجل بالجهة المطابقة<select data-orphan-target="${esc(orphan.targetKey)}">${options}</select></label><button type="button" class="btn small" data-relink-orphan="${esc(orphan.targetKey)}">استعادة الربط</button></div>` : '<small class="muted-note">لا توجد جهة مسجلة تطابق معرّف هذا السجل تمامًا. أضف/استعد الجهة الصحيحة أولًا؛ لن يتم تخمين المستلم.</small>'}</article>`;
    }).join('');
    const orphanPanel = `<details class="conversation-orphan-panel"><summary>استعادة سجلات محادثات غير مرتبطة (${Number(orphans.length).toLocaleString('ar')})</summary><p class="muted-note">قد تبقى رسائل محفوظة بعد حذف جهة أو إعادة إنشائها بمعرّف مختلف. يربط النظام السجل فقط بجهة مسجلة تطابق معرّف WhatsApp نفسه، ولا يرسل أو يحذف أي رسالة.</p><div class="action-bar"><button type="button" class="btn small" id="conversationOrphanRefreshBtn">تحديث السجلات</button></div>${orphanRows || '<div class="empty">لا توجد سجلات يتيمة ظاهرة لهذه الجلسة.</div>'}</details>`;
    const messages = rows.map(item => renderConversationMessage(item, selected)).join('');
    const isLoading = state.conversationBusy;
    return `<section class="page-title"><p class="eyebrow">أرشيف محلي حسب الجهة</p><h1>سجل المحادثات</h1><p>صفحة مستقلة لمحادثتك مع البوت ولكل شخص أو مجموعة مسجلة. تُحفظ الرسائل الجديدة تلقائيًا عند استقبالها أو إرسالها، ويمكنك استيراد آخر ما يتيحه WhatsApp.</p></section>
      <section class="conversation-browser"><aside class="panel conversation-sidebar"><div class="panel-head"><div><h2>المحادثات</h2><p>${targets.length.toLocaleString('ar')} جهة مسجلة</p></div><button class="icon-btn" id="conversationRefreshBtn" title="تحديث القائمة" aria-label="تحديث سجل المحادثات">↻</button></div><div class="conversation-target-list">${targetList || '<div class="empty">جارٍ تحميل الجهات المسجلة…</div>'}</div>${orphanPanel}<p class="muted-note">الخصوصية: لا تظهر المحادثات غير المرتبطة ضمن قائمة الدردشات العادية.</p></aside>
      <section class="panel conversation-main"><div class="panel-head conversation-heading"><div><h2>${esc(selected?.label || 'اختر محادثة')}</h2><p>${Number(meta.totalStoredForTarget || selected?.archivedCount || 0).toLocaleString('ar')} رسالة في الأرشيف المحلي</p></div><div class="conversation-actions"><label class="conversation-import-depth" for="conversationImportLimit">عمق السجل<select id="conversationImportLimit" ${!selected || !selected.hasChatId || isLoading ? 'disabled' : ''}><option value="1000">1,000 رسالة</option><option value="5000">5,000 رسالة</option><option value="20000">20,000 رسالة</option></select></label><button class="btn small" id="conversationImportBtn" ${!selected || !selected.hasChatId || isLoading ? 'disabled' : ''}>استيراد السجل</button></div></div>
        <div class="conversation-media-tools"><label>نوع المرفقات<select id="conversationMediaType" ${!selected || !selected.hasChatId || isLoading ? 'disabled' : ''}><option value="all">كل الأنواع</option><option value="image">الصور</option><option value="video">الفيديو</option><option value="audio">الصوت والرسائل الصوتية</option><option value="sticker">الملصقات</option><option value="document">المستندات والملفات</option></select></label><label>عدد الرسائل للفحص<select id="conversationMediaDepth" ${!selected || !selected.hasChatId || isLoading ? 'disabled' : ''}><option value="100">آخر 100</option><option value="200" selected>آخر 200</option><option value="500">آخر 500</option></select></label><label>حد الملفات<select id="conversationMediaFileLimit" ${!selected || !selected.hasChatId || isLoading ? 'disabled' : ''}><option value="10">10 ملفات</option><option value="25">25 ملفًا</option><option value="50" selected>50 ملفًا</option><option value="100">100 ملف</option></select></label><button type="button" class="btn" id="conversationDownloadMediaBtn" ${!selected || !selected.hasChatId || !selected.enabled || isLoading ? 'disabled' : ''}>تنزيل المرفقات إلى المكتبة</button></div>
        <form id="conversationSearchForm" class="conversation-search"><label for="conversationSearch">ابحث داخل هذه المحادثة</label><div class="conversation-search-row"><input id="conversationSearch" value="${esc(state.conversationQuery)}" placeholder="كلمة أو عبارة من الرسائل…" maxlength="160"><button class="btn primary" type="submit">بحث</button><button class="btn" type="button" id="conversationClearSearch">مسح</button></div></form>
        <div class="conversation-notice">يُحفظ نص السجل محليًا. لتنزيل الصور والفيديو والصوت والملصقات والمستندات اختر النوع والحدود أعلاه ثم أكد العملية؛ يبحث النظام في أحدث رسائل WhatsApp المتاحة فقط ويكتب الملفات في مكتبة هذه الجلسة. التنزيل لا يرسل شيئًا، ولا يضمن WhatsApp إتاحة كامل التاريخ.</div>
        <div class="conversation-live-status" id="conversationLiveStatus"><span class="live-dot" aria-hidden="true"></span><b>تحديث مباشر</b><small id="conversationLiveAt">يُحدّث السجل تلقائيًا أثناء فتح هذه الصفحة</small></div>
        <div class="conversation-thread" id="conversationThread" role="log" aria-live="polite" aria-relevant="additions text" aria-label="رسائل المحادثة">${isLoading ? '<div class="empty">جارٍ تحميل سجل المحادثة…</div>' : messages || '<div class="empty">لا توجد رسائل محفوظة بعد. اضغط «استيراد آخر الرسائل» بعد اتصال WhatsApp، أو ابدأ المحادثة لتُحفظ الرسائل الجديدة.</div>'}</div>
        ${meta.hasOlder ? '<div class="conversation-load-older"><button type="button" class="btn" id="conversationLoadOlder">تحميل رسائل أقدم</button></div>' : ''}
        <div class="conversation-footer"><span id="conversationDisplayCount">عدد النتائج المعروضة: ${rows.length.toLocaleString('ar')}</span><span>محفوظ محليًا داخل مجلد الجلسة</span></div>
      </section></section>`;
  }

  function pageGroups(data) {
    const filter = state.groupFilter.trim().toLocaleLowerCase('ar');
    const groups = (data.groups || []).filter((group) => `${group.name || ''} ${group.gid || ''}`.toLocaleLowerCase('ar').includes(filter));
    const current = state.selectedGroup && (data.groups || []).find((group) => group.gid === state.selectedGroup);
    return `<section class="page-title"><p class="eyebrow">المجموعات</p><h1>المجموعات هذه الجلسة</h1><p>اكتشاف وربط وتحليل وحفظ المجموعة في الجلسة الحالية، ثم استخدامها كهدف مستقل في الإرسال والتفاعل.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>ربط أو اكتشاف</h2><p>ضع GID أو رابط دعوة وسيُحلل تلقائيًا.</p></div></div>
          <label>GID أو رابط الدعوة<input id="groupValue" placeholder="120363...@g.us أو chat.whatsapp.com/..." value=""></label>
          <div class="action-bar"><button class="btn primary" id="connectGroupBtn">ربط وتحليل</button><button class="btn" id="discoverGroupsBtn">اكتشاف</button><button class="btn" id="refreshGroupsBtn">تحديث الكل</button></div>
          <div id="groupResult" class="result-box">سيتم عرض نتيجة التحليل هنا.</div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>المجموعات المحفوظة</h2><p>${groups.length} مجموعة.</p></div></div><input id="groupSearch" value="${esc(state.groupFilter)}" placeholder="ابحث باسم المجموعة أو GID..."><div class="group-list">${groups.length ? groups.map((group) => groupRow(group, current?.gid === group.gid)).join('') : '<div class="empty">لا توجد مجموعات محفوظة.</div>'}</div></article>
      </section>
      <section class="panel"><div class="panel-head"><div><h2>تفاصيل المجموعة</h2><p>اعرض البيانات الكاملة المتاحة، ثم استخدم المجموعة مباشرة في الإرسال.</p></div></div><div id="groupDetail">${groupDetails(current)}</div></section>`;
  }

  function groupRow(group, selected) {
    return `<article class="group-row ${selected ? 'selected' : ''}"><div class="group-main"><b>${esc(group.name || group.gid)}</b><small>${esc(group.gid || '')}</small></div><div class="group-meta"><span>${Number(group.participantsCount || group.participants?.length || 0)} عضو</span><span>${Number(group.admins?.length || 0)} مشرف</span><span class="mini-state ${group.enabled === false ? 'off' : ''}">${group.enabled === false ? 'متوقفة' : 'مفعّلة'}</span></div><div class="row-actions"><button class="btn small" data-show-group="${esc(group.gid)}">عرض</button><button class="btn small" data-send-group="${esc(group.id)}">إرسال</button><button class="btn small" data-copy-group="${esc(group.gid)}">نسخ GID</button><button class="btn small" data-toggle-group="${esc(group.id)}">${group.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-group="${esc(group.id)}">حذف</button></div></article>`;
  }

  function groupDetails(group) {
    if (!group) return '<div class="empty">اختر مجموعة من القائمة.</div>';
    const members = Array.isArray(group.participants) ? group.participants : [];
    const admins = Array.isArray(group.admins) ? group.admins : members.filter((item) => item.admin);
    return `<div class="info-grid six"><div><span>الاسم</span><b>${esc(group.name || '')}</b></div><div><span>GID</span><b class="mono">${esc(group.gid || '')}</b></div><div><span>الأعضاء</span><b>${Number(group.participantsCount || members.length || 0)}</b></div><div><span>المشرفون</span><b>${admins.length}</b></div><div><span>المالك</span><b class="mono">${esc(group.owner || 'غير متاح')}</b></div><div><span>رمز الدعوة</span><b>${esc(group.inviteCode || 'غير متاح')}</b></div></div><div class="detail-line"><strong>الوصف:</strong> ${esc(group.description || 'لا يوجد وصف')}</div><details class="member-details"><summary>الأعضاء (${members.length})</summary>${members.length ? `<div class="table-wrap"><table><thead><tr><th>#</th><th>الاسم</th><th>المعرف</th><th>الدور</th></tr></thead><tbody>${members.map((member, index) => `<tr><td>${index + 1}</td><td>${esc(member.name || 'بدون اسم')}</td><td class="mono">${esc(member.id || '')}</td><td>${member.admin ? 'مشرف' : 'عضو'}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لم يوفر WhatsApp قائمة الأعضاء.</div>'}</details>`;
  }

  function pageInteraction(data) {
    const interaction = data.interaction || {};
    const rules = interaction.rules || [];
    const counters = interaction.counterTriggers || [];
    const counterState = interaction.counterState || {};
    const recent = interaction.recent || [];
    const selected = new Set((data.settings?.interactionChatIds || []).map(String));
    const candidates = activeTargets(data);
    const conflictMode = data.settings?.interactionConflictMode || 'first-match';
    const threshold = Number(data.settings?.interactionSimilarityThreshold ?? .68);
    return `<section class="page-title"><p class="eyebrow">التفاعل</p><h1>محرك الردود الذكي</h1><p>ردود متغيرة، مطابقة سياقية وتقريبية، أولوية للأوامر، ومنع للتعارض داخل كل جلسة.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>تحكم المالك</h2><p>كل الميزات قابلة للإيقاف والتخصيص محليًا.</p></div></div>
          <div class="toggle-list"><label class="toggle-row"><input id="interactionEnabled" type="checkbox" ${data.settings?.interactionEnabled !== false ? 'checked' : ''}><span><b>التفاعل التلقائي</b><small>تشغيل أو إيقاف محرك القواعد والعدادات.</small></span></label><label class="toggle-row"><input id="groupAssistantEnabled" type="checkbox" ${data.settings?.groupAssistantEnabled !== false ? 'checked' : ''}><span><b>مساعد المجموعات</b><small>أوامر GID والتحليل داخل المجموعات.</small></span></label><label class="toggle-row"><input id="interactionIgnoreOwn" type="checkbox" ${data.settings?.interactionIgnoreOwn !== false ? 'checked' : ''}><span><b>منع حلقات الرد</b><small>تجاهل رسائل الحساب ما عدا إدخال النفس الصريح المدعوم.</small></span></label></div>
          <div class="action-bar"><button class="btn primary" id="saveInteractionSettings">حفظ إعدادات المحرك</button></div>
          <details class="advanced-panel"><summary>المطابقة والتعارض والنطاق</summary><div class="form-grid two"><label>سياسة تعارض الردود<select id="interactionConflictMode"><option value="first-match" ${conflictMode==='first-match'?'selected':''}>أول قاعدة ناجحة حسب الأولوية</option><option value="highest-score" ${conflictMode==='highest-score'?'selected':''}>أعلى دقة مطابقة وأولوية</option><option value="allow-multiple" ${conflictMode==='allow-multiple'?'selected':''}>السماح بعدة إجراءات غير متعارضة</option></select></label><label>عتبة التشابه <output id="interactionSimilarityOutput">${Math.round(threshold*100)}%</output><input id="interactionSimilarityThreshold" type="range" min="0.30" max="0.98" step="0.01" value="${threshold}"></label><label>النطاق العام<select id="interactionScope"><option value="all" ${data.settings?.interactionScope === 'all' ? 'selected' : ''}>كل المحادثات</option><option value="groups" ${data.settings?.interactionScope === 'groups' ? 'selected' : ''}>المجموعات</option><option value="private" ${data.settings?.interactionScope === 'private' ? 'selected' : ''}>الخاص</option><option value="selected" ${data.settings?.interactionScope === 'selected' ? 'selected' : ''}>أهداف محددة</option></select></label><label>الحد الأقصى للأفعال/الدقيقة<input id="maxActionsPerMinute" type="number" min="1" max="1000" value="${Number(data.settings?.maxActionsPerMinute || 20)}"></label><label class="toggle-box"><input id="interactionQuietEnabled" type="checkbox" ${data.settings?.interactionQuietEnabled ? 'checked' : ''}><span>فترة هدوء</span></label><label>من<input id="interactionQuietStart" type="time" value="${esc(data.settings?.interactionQuietStart || '23:00')}"></label><label>إلى<input id="interactionQuietEnd" type="time" value="${esc(data.settings?.interactionQuietEnd || '07:00')}"></label><label>السلوك أثناء الهدوء<select id="interactionQuietAction"><option value="silence" ${(data.settings?.interactionQuietAction || 'silence') === 'silence' ? 'selected' : ''}>لا ترد نهائيًا</option><option value="reply" ${data.settings?.interactionQuietAction === 'reply' ? 'selected' : ''}>رد برسالة مخصصة</option><option value="rules" ${data.settings?.interactionQuietAction === 'rules' ? 'selected' : ''}>شغّل القواعد المسموح بها فقط</option></select></label><label>نص رد الهدوء<input id="interactionQuietReply" maxlength="1000" value="${esc(data.settings?.interactionQuietReply || 'أنا في فترة الهدوء الآن، سأرد عليك لاحقًا.')}"></label><label>فاصل تكرار رد الهدوء (ثانية)<input id="interactionQuietCooldownSec" type="number" min="0" max="86400" value="${Number(data.settings?.interactionQuietCooldownSec ?? 300)}"></label></div><div class="help-note">الأوامر النصية التي تبدأ بـ ! أو / تقدم تلقائيًا في الترتيب. «أعلى دقة» يقارن نوع المطابقة وقيمتها والأولوية؛ و«متعدد» يزيل الإجراءات المتطابقة.</div><details class="advanced-panel smart-fallback-settings"><summary>إعدادات إضافية: فهم الرسائل والرد الذكي</summary><div class="toggle-list"><label class="toggle-row"><input id="interactionFallbackEnabled" type="checkbox" ${data.settings?.interactionFallbackEnabled !== false ? 'checked' : ''}><span><b>الرد عند عدم وجود قاعدة مطابقة</b><small>يرد تلقائيًا على المحادثات الخاصة بقوالب محافظة، مع احترام فترة الهدوء ومهلة منع التكرار.</small></span></label><label class="toggle-row"><input id="interactionSmartMatching" type="checkbox" ${data.settings?.interactionSmartMatching !== false ? 'checked' : ''}><span><b>فهم الأخطاء الإملائية البسيطة</b><small>يسمح بمطابقة العبارة القريبة فقط إذا تجاوزت عتبة التشابه المحددة.</small></span></label><label class="toggle-row"><input id="interactionFallbackInGroups" type="checkbox" ${data.settings?.interactionFallbackInGroups === true ? 'checked' : ''}><span><b>الرد الاحتياطي داخل المجموعات</b><small>مغلق افتراضيًا حتى لا يتحول البوت إلى مصدر إزعاج في المجموعة.</small></span></label><label class="toggle-row"><input id="smartReplyEnabled" type="checkbox" ${data.settings?.smartReplyEnabled === true ? 'checked' : ''}><span><b>استخدام نموذج محلي للمحادثة</b><small>مهم لثراء المفردات وتنوع صياغة الردود: يحتاج Ollama ونموذج محادثة مثبتًا على هذا الجهاز. دون تفعيله يستخدم البوت قوالب الردود المحلية المتنوعة لكنها محدودة المعرفة. لا يرسل المحادثات إلى خدمة سحابية.</small></span></label><label class="toggle-row"><input id="voiceAutoTranscribeEnabled" type="checkbox" ${data.settings?.voiceAutoTranscribeEnabled !== false ? 'checked' : ''}><span><b>تفريغ الصوتيات الواردة تلقائيًا</b><small>عند توفر Whisper المحلي، يحوّل البوت الصوت إلى نص ويستخدم النص في قواعد الرد؛ يحتاج البرنامج والنموذج محليًا.</small></span></label><label class="toggle-row"><input id="voiceAutoTranscribeSelfChat" type="checkbox" ${data.settings?.voiceAutoTranscribeSelfChat !== false ? 'checked' : ''}><span><b>فهم الصوتيات في محادثة النفس</b><small>يفرّغ الرسالة الصوتية قبل تمريرها إلى مساعد المالك.</small></span></label><label class="toggle-row"><input id="interactionVoiceRepliesEnabled" type="checkbox" ${data.settings?.interactionVoiceRepliesEnabled !== false ? 'checked' : ''}><span><b>إرسال الردود التلقائية كصوت أيضًا</b><small>يرسل الرد النصي أولًا ثم نسخة صوتية محلية عبر Audar-TTS-V1 التعبيري، أو Piper كخطة احتياطية عربية إذا تعذر تشغيله. لا تُرسل نسخ صوتية تلقائية للمجموعات.</small></span></label><label class="toggle-row"><input id="ttsRequireProofread" type="checkbox" ${data.settings?.ttsRequireProofread === true ? 'checked' : ''}><span><b>اشتراط التدقيق اللغوي قبل إرسال الرد الصوتي</b><small>اختياري ومغلق افتراضيًا حتى لا يمنع الصوت عند غياب Ollama. عند تفعيله لا يرسل الصوت إذا لم ينجح التدقيق المحلي.</small></span></label><label class="toggle-row"><input id="ttsCloudConsent" type="checkbox" ${data.settings?.ttsCloudConsent === true ? 'checked' : ''}><span><b>أوافق على إرسال نص الرد إلى خدمة صوت خارجية</b><small>مغلق افتراضيًا لكل جلسة. لا يخرج نص الرد من الجهاز بدونه، حتى لو كان المحرك auto أو ظل إعداد قديم في .env. إلغاء الموافقة يمنع الطلبات الخارجية التالية ويوقف تسليم أي ناتج لم يُرسل بعد؛ لكنه لا يستطيع استرجاع نص وصل بالفعل إلى المزود قبل الإلغاء.</small></span></label></div><div class="form-grid two"><label>لغة تفريغ الصوت<select id="voiceTranscribeLanguage"><option value="auto" ${(data.settings?.voiceTranscribeLanguage || 'auto') === 'auto' ? 'selected' : ''}>اكتشاف تلقائي (مفضّل للغات المختلطة)</option><option value="ar" ${(data.settings?.voiceTranscribeLanguage || 'auto') === 'ar' ? 'selected' : ''}>العربية</option><option value="en" ${data.settings?.voiceTranscribeLanguage === 'en' ? 'selected' : ''}>الإنجليزية</option><option value="fr" ${data.settings?.voiceTranscribeLanguage === 'fr' ? 'selected' : ''}>الفرنسية</option><option value="de" ${data.settings?.voiceTranscribeLanguage === 'de' ? 'selected' : ''}>الألمانية</option><option value="es" ${data.settings?.voiceTranscribeLanguage === 'es' ? 'selected' : ''}>الإسبانية</option><option value="ur" ${data.settings?.voiceTranscribeLanguage === 'ur' ? 'selected' : ''}>الأوردية</option><option value="hi" ${data.settings?.voiceTranscribeLanguage === 'hi' ? 'selected' : ''}>الهندية</option><option value="tr" ${data.settings?.voiceTranscribeLanguage === 'tr' ? 'selected' : ''}>التركية</option></select></label></div><div class="form-grid two voice-tuning-settings"><label>محرك النطق<select id="ttsBackend"><option value="local" ${(data.settings?.ttsBackend || 'local') === 'local' ? 'selected' : ''}>محلي — Audar-TTS-V1 Turbo التعبيري مع Piper احتياطيًا، دون إرسال النص للإنترنت</option><option value="auto" ${data.settings?.ttsBackend === 'auto' ? 'selected' : ''}>تلقائي — المحلي أولًا؛ السحابي بعد الموافقة فقط</option><option value="edge-tts" ${data.settings?.ttsBackend === 'edge-tts' ? 'selected' : ''}>Edge TTS — خدمة خارجية (تحتاج موافقة)</option><option value="openai-compatible" ${data.settings?.ttsBackend === 'openai-compatible' ? 'selected' : ''}>واجهة API خارجية (تحتاج موافقة ومفتاح API)</option></select></label><label>أسلوب الأداء<select id="ttsStyle"><option value="natural" ${(data.settings?.ttsStyle || 'natural') === 'natural' ? 'selected' : ''}>تلقائي — يغيّر الأداء حسب معنى الكلام</option><option value="calm" ${data.settings?.ttsStyle === 'calm' ? 'selected' : ''}>هادئ وبطيء نسبيًا</option><option value="warm" ${data.settings?.ttsStyle === 'warm' ? 'selected' : ''}>ودود ودافئ</option><option value="energetic" ${data.settings?.ttsStyle === 'energetic' ? 'selected' : ''}>حيوي وأكثر نشاطًا</option><option value="formal" ${data.settings?.ttsStyle === 'formal' ? 'selected' : ''}>رسمي ومتزن</option><option value="friendly" ${data.settings?.ttsStyle === 'friendly' ? 'selected' : ''}>ودود</option><option value="empathetic" ${data.settings?.ttsStyle === 'empathetic' ? 'selected' : ''}>متعاطف ومطمئن</option><option value="storytelling" ${data.settings?.ttsStyle === 'storytelling' ? 'selected' : ''}>حكائي وسردي</option><option value="playful" ${data.settings?.ttsStyle === 'playful' ? 'selected' : ''}>مرح وخفيف</option><option value="curious" ${data.settings?.ttsStyle === 'curious' ? 'selected' : ''}>فضولي واستفهامي</option><option value="whisper" ${data.settings?.ttsStyle === 'whisper' ? 'selected' : ''}>همس فعلي</option><option value="sarcastic" ${data.settings?.ttsStyle === 'sarcastic' ? 'selected' : ''}>ساخر</option><option value="laughing" ${data.settings?.ttsStyle === 'laughing' ? 'selected' : ''}>ضحك</option></select></label><label>الصوت العربي المحلي (Audar)<select id="ttsAudarVoice">${[['demo_male_1','رجالي — دافئ وواثق'],['demo_male_2','رجالي — هادئ وقريب'],['demo_male_3','رجالي — مشرق وفضولي'],['demo_female_1','نسائي — حيوي ومرح'],['demo_female_2','نسائي — ناعم ومرح'],['demo_female_3','نسائي — رقيق وحالم']].map(([value,label]) => `<option value="${value}" ${(data.settings?.ttsAudarVoice || 'demo_male_1') === value ? 'selected' : ''}>${label}</option>`).join('')}</select></label><label>الصوت / اللغة الاحتياطي (Edge TTS)<select id="ttsVoice">${[['ar-EG-ShakirNeural','مصري — صوت رجالي'], ['ar-EG-SalmaNeural','مصري — صوت نسائي'], ['ar-SA-HamedNeural','سعودي — صوت رجالي'], ['ar-SA-ZariyahNeural','سعودي — صوت نسائي'], ['ar-AE-HamdanNeural','إماراتي — صوت رجالي'], ['ar-AE-FatimaNeural','إماراتي — صوت نسائي'], ['ar-OM-AbdullahNeural','عُماني — صوت رجالي'], ['ar-OM-AyshaNeural','عُماني — صوت نسائي'], ['ar-JO-TaimNeural','أردني — صوت رجالي'], ['ar-JO-SanaNeural','أردني — صوت نسائي'], ['ar-LB-RamiNeural','لبناني — صوت رجالي'], ['ar-LB-LaylaNeural','لبناني — صوت نسائي'], ['ar-IQ-BasselNeural','عراقي — صوت رجالي'], ['ar-IQ-RanaNeural','عراقي — صوت نسائي'], ['ar-SY-LaithNeural','سوري — صوت رجالي'], ['ar-SY-AmanyNeural','سوري — صوت نسائي'], ['ar-MA-JamalNeural','مغربي — صوت رجالي'], ['ar-MA-MounaNeural','مغربي — صوت نسائي'], ['ar-BH-AliNeural','بحريني — صوت رجالي'], ['ar-BH-LailaNeural','بحريني — صوت نسائي'], ['ar-KW-FahedNeural','كويتي — صوت رجالي'], ['ar-KW-NouraNeural','كويتي — صوت نسائي'], ['ar-QA-MoazNeural','قطري — صوت رجالي'], ['ar-QA-AmalNeural','قطري — صوت نسائي'], ['ar-DZ-IsmaelNeural','جزائري — صوت رجالي'], ['ar-DZ-AminaNeural','جزائري — صوت نسائي'], ['ar-TN-HediNeural','تونسي — صوت رجالي'], ['ar-TN-ReemNeural','تونسي — صوت نسائي'], ['ar-YE-SalehNeural','يمني — صوت رجالي'], ['ar-YE-MaryamNeural','يمني — صوت نسائي'], ['ar-LY-OmarNeural','ليبي — صوت رجالي'], ['ar-LY-ImanNeural','ليبي — صوت نسائي'], ['en-US-JennyNeural','English — female'], ['en-US-GuyNeural','English — male'], ['en-US-AriaNeural','English — expressive female'], ['fr-FR-DeniseNeural','Français — voix féminine'], ['fr-FR-HenriNeural','Français — voix masculine'], ['de-DE-KatjaNeural','Deutsch — weibliche Stimme'], ['de-DE-ConradNeural','Deutsch — männliche Stimme'], ['es-ES-ElviraNeural','Español — voz femenina'], ['es-ES-AlvaroNeural','Español — voz masculina']].map(([value,label]) => `<option value="${value}" ${(data.settings?.ttsVoice || 'ar-EG-ShakirNeural') === value ? 'selected' : ''}>${label}</option>`).join('')}</select></label><label>سرعة الكلام <output id="ttsRateOutput">${Number(data.settings?.ttsRate || 0) > 0 ? '+' : ''}${Number(data.settings?.ttsRate || 0)}%</output><input id="ttsRate" type="range" min="-40" max="40" step="5" value="${Number(data.settings?.ttsRate || 0)}"></label><label>ارتفاع النبرة (للمحركات الاحتياطية) <output id="ttsPitchOutput">${Number(data.settings?.ttsPitch || 0) > 0 ? '+' : ''}${Number(data.settings?.ttsPitch || 0)} Hz</output><input id="ttsPitch" type="range" min="-30" max="30" step="5" value="${Number(data.settings?.ttsPitch || 0)}"></label><label>مستوى الصوت <output id="ttsVolumeOutput">${Number(data.settings?.ttsVolume || 0) > 0 ? '+' : ''}${Number(data.settings?.ttsVolume || 0)}%</output><input id="ttsVolume" type="range" min="-30" max="30" step="5" value="${Number(data.settings?.ttsVolume || 0)}"></label><label>شدة التعبير والانفعال <output id="ttsExaggerationOutput">${Number(data.settings?.ttsExaggeration ?? .55).toFixed(2)}</output><input id="ttsExaggeration" type="range" min="0.25" max="1.2" step="0.05" value="${Number(data.settings?.ttsExaggeration ?? .55)}"></label><label>تنوع النطق في Piper الاحتياطي <output id="ttsNoiseScaleOutput">${Number(data.settings?.ttsNoiseScale ?? .667).toFixed(2)}</output><input id="ttsNoiseScale" type="range" min="0.1" max="1.5" step="0.1" value="${Number(data.settings?.ttsNoiseScale ?? .667)}"></label><label>عرض التنوع في Piper الاحتياطي <output id="ttsNoiseWidthOutput">${Number(data.settings?.ttsNoiseWidth ?? .8).toFixed(2)}</output><input id="ttsNoiseWidth" type="range" min="0.1" max="1.5" step="0.1" value="${Number(data.settings?.ttsNoiseWidth ?? .8)}"></label></div><p class="help-note voice-privacy-note">المحرك المحلي الأساسي هو Audar-TTS-V1 Turbo Q5_K_M: مخصص للعربية والإنجليزية ولهجات عربية متعددة، مع وسوم تعبير صوتي فعلية داخل النص مثل الفضول والحماس والهمس والضحك. ينزّل المشروع الأوزان مرة واحدة عند التشغيل (نحو 1.2 جيجابايت) وستة أصوات اصطناعية وNeuCodec داخل مجلد models؛ ويمكن اختيار Flash الأخف من AUDAR_TTS_TIER. Piper العربي احتياطي، وChatterbox اختياري للفرنسية والألمانية والإسبانية ولا يثبت تلقائيًا. لا تُرسل النصوص إلى الإنترنت في الوضع المحلي. قائمة Audar أدناه تختار الصوت المرجعي الذي يحدد خامة الصوت واللهجة؛ وسوم الأداء تضيف الانفعال إلى الجمل. قائمة أصوات Edge TTS الإقليمية تخص الخدمة الخارجية فقط ولا تعمل إلا بعد موافقة صريحة. الصوت الطبيعي ليس ضمانًا لمحاكاة إنسان حقيقي؛ جودة النتيجة تعتمد أيضًا على الجهاز والنص واللهجة.</p><div class="voice-preset-card"><div><b>الصوت المحلي التعبيري</b><small>يعتمد على ملف الصوت المحلي الذي تختاره في Audar، ولا يرسل النص إلى أي خدمة خارجية. لا يحتاج إلى تفعيل موافقة السحابة.</small></div><button class="btn primary" type="button" id="activateNaturalVoicePreset">استخدام الصوت المحلي المحدد</button></div><details class="advanced-panel"><summary>معجم النطق ومعاينة الصوت وتقسيم الردود الطويلة</summary><div class="form-grid two"><label>عدد المقاطع الصوتية الأقصى للرد الواحد<select id="ttsMaxReplySegments">${[2,3,4,5,6,7,8,9,10].map(n => `<option value="${n}" ${Number(data.settings?.ttsMaxReplySegments || 6) === n ? 'selected' : ''}>${n} مقاطع</option>`).join('')}</select></label><label>حد المعجم الصوتي<small>حتى 300 كلمة أو اسم</small><textarea id="ttsPronunciationDictionary" rows="5" maxlength="14000" placeholder="ChatGPT => شات جي بي تي\nAPI Sentinel => أي بي آي سنتينل\nOpenAI => أوبن إيه آي">${esc((data.settings?.ttsPronunciationDictionary || []).map(item => `${item.term} => ${item.pronunciation}`).join('\n'))}</textarea></label></div><p class="help-note">كل سطر بالشكل: الكلمة المكتوبة =&gt; طريقة نطقها. يُستخدم المعجم في الصوت فقط ولا يغيّر الرسالة النصية. يقسم المشروع الرد الطويل إلى مقاطع متتابعة بدل قصّه بصمت؛ إذا تجاوز العدد الحد المحدد يتوقف ويخبرك ولا يحذف نهاية الرد.</p><div class="form-grid"><label>نص معاينة الصوت<textarea id="ttsPreviewText" rows="3" maxlength="1800" placeholder="اكتب جملة تريد سماعها قبل اعتماد الصوت">مرحبًا، هذه معاينة لصوت البوت. يمكنك تعديل النطق والسرعة ثم حفظ الإعدادات والاستماع مرة أخرى.</textarea></label></div><div class="action-bar"><button class="btn" id="ttsPreviewButton" type="button">استمع إلى المعاينة</button><span id="ttsPreviewStatus" class="inline-status" aria-live="polite">احفظ الإعدادات أولًا ثم جرّب الصوت دون إرسال رسالة إلى WhatsApp.</span></div><audio id="ttsPreviewPlayer" controls hidden style="width:100%;margin-top:10px"></audio></details><div class="form-grid two"><label>عتبة المطابقة الذكية <output id="interactionSmartOutput">${Math.round(Number(data.settings?.interactionSmartThreshold ?? .82)*100)}%</output><input id="interactionSmartThreshold" type="range" min="0.72" max="0.98" step="0.01" value="${Number(data.settings?.interactionSmartThreshold ?? .82)}"></label><label>الفاصل بين الردود الاحتياطية (ثانية)<input id="interactionFallbackCooldownSec" type="number" min="10" max="86400" value="${Number(data.settings?.interactionFallbackCooldownSec ?? 45)}"></label><label>اسم نموذج Ollama المحلي<input id="smartReplyModel" maxlength="100" value="${esc(data.settings?.smartReplyModel || 'qwen3.5:4b')}" placeholder="qwen3.5:4b"></label><label>مهلة النموذج (مللي ثانية)<input id="smartReplyTimeoutMs" type="number" min="1500" max="60000" value="${Number(data.settings?.smartReplyTimeoutMs ?? 12000)}"></label><label>رد احتياطي مخصص (اختياري)<textarea id="interactionFallbackReply" rows="3" maxlength="1500" placeholder="استخدم {{message}} لعرض نص الرسالة و{{sender}} لاسم المرسل">${esc(data.settings?.interactionFallbackReply || '')}</textarea></label><label>تعليمات إضافية للمساعد المحلي<textarea id="smartReplySystemPrompt" rows="3" maxlength="3000" placeholder="مثال: أجب باللهجة المصرية، واجعل الردود مختصرة.">${esc(data.settings?.smartReplySystemPrompt || '')}</textarea></label></div><div class="action-bar"><button class="btn" id="checkSmartReplyStatus" type="button">فحص نموذج الذكاء المحلي</button><span id="smartReplyStatus" class="inline-status" aria-live="polite">لم يتم فحص Ollama بعد.</span></div><p class="help-note">لتوسيع مفردات البوت وصياغة ردود حوارية غير مكررة فعّل «استخدام نموذج محلي للمحادثة» بعد تثبيت Ollama ونموذج محلي مثل qwen3.5:4b. محرك Audar ينطق النص ولا يخترع الرد. تشغيل الذكاء المحلي لا يعني أن المعرفة مضمونة أو أن البوت يستطيع معرفة أسعار/توفر غير محفوظة. عندما لا يعرف الإجابة، ينبغي أن يسأل عن التفاصيل بدل التخمين. إعدادات المجموعة منفصلة وتحتاج تفعيلًا صريحًا.</p></details><div class="target-picker"><b>الأهداف المحددة</b>${candidates.length ? candidates.map((target) => `<label><input type="checkbox" class="rule-target" value="${esc(chatIdForTarget(target))}" ${selected.has(chatIdForTarget(target)) ? 'checked' : ''}><span>${esc(target.name || target.gid || target.phone || '')}</span><small>${typeLabel(target)}</small></label>`).join('') : '<div class="empty">لا توجد أهداف في الجلسة.</div>'}</div></details>
        </article>
        <article class="panel"><div class="panel-head"><div><h2 id="ruleEditorTitle">${state.interactionEditingRule ? 'تعديل القاعدة' : 'إنشاء قاعدة رد'}</h2><p>كل سطر في حقل الرد يعد صيغة مستقلة، ويُدوّر المحرك بينها لتجنب التكرار المباشر.</p></div></div>
          <details class="section-editor" id="ruleEditorDisclosure" ${state.interactionEditingRule ? 'open' : ''}><summary>${state.interactionEditingRule ? 'تعديل بيانات القاعدة' : '＋ إنشاء أو تعديل قاعدة رد'}</summary>
          <div class="form-grid two"><label>اسم القاعدة<input id="ruleName" placeholder="ترحيب"></label><label>الحدث<select id="ruleEvent"><option value="message">رسالة</option><option value="reaction">Reaction</option></select></label><label>نوع المطابقة<select id="ruleMatch"><option value="contains">يحتوي على عبارة</option><option value="exact">مطابقة تامة</option><option value="starts">يبدأ بعبارة</option><option value="ends">ينتهي بعبارة</option><option value="regex">Regex</option><option value="similarity">تشابه تقريبي</option><option value="intent">نية الرسالة</option><option value="any">أي رسالة / حدث</option></select></label><label>العبارة أو النية أو Regex<input id="ruleValue" placeholder="مرحبا أو greeting أو !help"></label><label>النطاق<select id="ruleScope"><option value="all">الكل</option><option value="groups">المجموعات</option><option value="private">الخاص</option><option value="selected">أهداف محددة</option></select></label><label>الإجراء<select id="ruleAction"><option value="reply">رد نصي متغير</option><option value="reaction">Reaction</option><option value="both">رد + Reaction</option></select></label></div>
          <div class="form-grid two"><label id="ruleReplyWrap">صيغ الرد — كل رد في سطر<textarea id="ruleReply" rows="5" placeholder="أهلًا {{sender}} ✨&#10;مرحبًا بك يا {{firstName}}&#10;نورتنا {{sender}} 🌟&#10;أهلًا وسهلًا بك!"></textarea><small>متغيرات: {{message}} · {{sender}} · {{firstName}} · {{chat}} · {{time}} · {{count}} · {{lastMessage}} · {{lastIntent}} · {{intent}} · {{day}}</small></label><label id="ruleEmojiWrap">Reaction<input id="ruleEmoji" placeholder="👍"></label></div>
          <div class="preset-row"><span>قوالب جاهزة:</span><button class="btn small" data-rule-preset="welcome">ترحيب</button><button class="btn small" data-rule-preset="help">مساعدة</button><button class="btn small" data-rule-preset="reaction">Reaction</button></div>
          <details class="advanced-panel"><summary>الأولوية والاختبار وجدولة القاعدة</summary><div class="form-grid three"><label>الأولوية<input id="rulePriority" type="number" min="-1000" max="1000" value="10"></label><label>منع التكرار (ثانية)<input id="ruleCooldown" type="number" min="0" max="86400" value="45"></label><label class="toggle-box"><input id="ruleStop" type="checkbox" checked><span>أوقف القواعد التالية بعد نجاح التنفيذ</span></label><label class="toggle-box"><input id="ruleCommandPriority" type="checkbox"><span>اجعلها أمرًا عالي الأولوية</span></label><label>مجموعة تعارض اختيارية<input id="ruleConflictGroup" placeholder="welcome-replies"></label></div><details class="advanced-panel"><summary>جدول تشغيل هذه القاعدة</summary><div class="form-grid three"><label class="toggle-box"><input id="ruleScheduleEnabled" type="checkbox"><span>تفعيل وقت محدد للقاعدة</span></label><label>من الساعة<input id="ruleScheduleStart" type="time" value="09:00"></label><label>إلى الساعة<input id="ruleScheduleEnd" type="time" value="17:00"></label></div><div class="rule-days-grid"><b>أيام التشغيل</b><div class="check-grid"><label><input type="checkbox" class="rule-schedule-day" value="0" checked> الأحد</label><label><input type="checkbox" class="rule-schedule-day" value="1" checked> الاثنين</label><label><input type="checkbox" class="rule-schedule-day" value="2" checked> الثلاثاء</label><label><input type="checkbox" class="rule-schedule-day" value="3" checked> الأربعاء</label><label><input type="checkbox" class="rule-schedule-day" value="4" checked> الخميس</label><label><input type="checkbox" class="rule-schedule-day" value="5" checked> الجمعة</label><label><input type="checkbox" class="rule-schedule-day" value="6" checked> السبت</label></div></div></details><label class="test-field">رسالة الاختبار<textarea id="ruleTestMessage" rows="3" placeholder="اكتب الرسالة التي تريد اختبارها"></textarea></label><label class="test-field">إيموجي الاختبار<input id="ruleTestEmoji" placeholder="👍"></label><div class="action-bar"><button class="btn" id="testRuleBtn">اختبار المطابقة</button></div></details>
          <div class="action-bar"><button class="btn primary" id="addRuleBtn">${state.interactionEditingRule ? 'حفظ التعديلات' : 'حفظ القاعدة'}</button><button class="btn" id="cancelRuleEditBtn" ${state.interactionEditingRule ? '' : 'hidden'}>إلغاء التعديل</button></div></details>
        </article>
      </section>
      <section class="content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>القواعد الحالية</h2><p>${rules.length} قاعدة محفوظة لهذه الجلسة.</p></div></div><div class="rule-list">${rules.length ? rules.map(ruleRow).join('') : '<div class="empty">لا توجد قواعد بعد.</div>'}</div></article><article class="panel"><div class="panel-head"><div><h2>آخر التفاعلات</h2><p>سجل إجراءات المحرك الفعلية.</p></div></div><div class="interaction-list">${recent.length ? recent.slice().reverse().map(interactionRow).join('') : '<div class="empty">لا يوجد تفاعل حتى الآن.</div>'}</div></article></section>
      <section class="panel"><div class="panel-head"><div><h2>عدادات الرسائل والإجراءات التلقائية</h2><p>تمت معالجة <b>${Number(counterState.totalCount || 0).toLocaleString('ar-OM')}</b> رسالة في هذه الجلسة. نفّذ إجراءً عند بلوغ 100 أو 500 أو 1000 أو أي حد يحدده المالك.</p></div><button class="btn small" id="resetCountersBtn">تصفير العدادات</button></div>
        <div class="content-grid two-col"><article><details class="section-editor" id="counterEditorDisclosure" ${state.interactionEditingCounter ? 'open' : ''}><summary>${state.interactionEditingCounter ? 'تعديل محفّز العداد' : '＋ إعداد محفّز عدّاد الرسائل (اختياري)'}</summary><div class="form-grid two"><label>اسم المحفز<input id="counterName" placeholder="مكافأة 100 رسالة"></label><label>عدد الرسائل<input id="counterThreshold" type="number" min="1" max="100000000" value="100"></label><label>نطاق العداد<select id="counterScope"><option value="session">كل الجلسة</option><option value="chat">كل محادثة منفردة</option></select></label><label>الأولوية<input id="counterPriority" type="number" min="-1000" max="1000" value="5"></label><label>نوع الإجراء<select id="counterActionType"><option value="reply">إرسال رد</option><option value="reaction">إضافة Reaction</option><option value="log">تسجيل الحدث فقط</option></select></label><label id="counterEmojiWrap">إيموجي الإجراء<input id="counterEmoji" placeholder="🎉"></label><label id="counterRepliesWrap" class="wide">الردود — كل صيغة في سطر<textarea id="counterReplies" rows="3" placeholder="وصلنا إلى {{count}} رسالة 🎉&#10;شكرًا على تفاعلك! وصلت المحادثة إلى {{count}} رسالة"></textarea></label></div><div class="action-bar"><button class="btn primary" id="saveCounterBtn">${state.interactionEditingCounter ? 'حفظ تعديل العداد' : 'إضافة محفز عداد'}</button><button class="btn" id="cancelCounterEditBtn" ${state.interactionEditingCounter ? '' : 'hidden'}>إلغاء التعديل</button></div><p class="help-note">يُنفَّذ كل محفز مرة واحدة عند عبور الحد المحدد لكل نطاق. بعد التعديل، لا يُعاد إطلاقه إلا عند عبور الحد وفق حالة العداد الجديدة؛ «تصفير» يعيد تسليح المحفزات.</p></details></article><article><div class="rule-list">${counters.length ? counters.map(counterRow).join('') : '<div class="empty">لا توجد محفزات للعداد بعد.</div>'}</div></article></div>
      </section>`;
  }

  function ruleRow(rule) {
    const variants = Array.isArray(rule.then?.replies) && rule.then.replies.length ? rule.then.replies : [rule.then?.reply || ''];
    const action = [variants.filter(Boolean).length > 1 ? `${variants.filter(Boolean).length} صيغ رد` : (variants[0] || ''), rule.then?.reaction || ''].filter(Boolean).join(' · ');
    const days = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
    const schedule = rule.schedule?.enabled ? `وقت ${rule.schedule.start || '09:00'}–${rule.schedule.end || '17:00'} · ${(Array.isArray(rule.schedule.days) && rule.schedule.days.length ? rule.schedule.days.map(day => days[Number(day)]).filter(Boolean).join('، ') : 'كل الأيام')}` : 'طوال الوقت';
    const command = rule.commandPriority || /^\s*[!/]/.test(String(rule.when?.value || '')) ? ' · أمر عالي الأولوية' : '';
    return `<div class="rule-row"><div><b>${esc(rule.name || 'قاعدة')}</b><small>${esc(rule.when?.type || 'message')} · ${esc(rule.when?.match || '')} · ${esc(rule.when?.value || 'أي')} · أولوية ${Number(rule.priority || 0)}${esc(command)} · ${esc(schedule)}</small><span>${esc(action || 'بدون إجراء')}</span></div><div class="row-actions"><button class="btn small" data-edit-rule="${esc(rule.id)}">تعديل</button><button class="btn small" data-toggle-rule="${esc(rule.id)}">${rule.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-rule="${esc(rule.id)}">حذف</button></div></div>`;
  }

  function counterRow(trigger) {
    const action = trigger.actionType === 'log' ? 'تسجيل فقط' : trigger.actionType === 'reaction' ? `Reaction ${trigger.then?.reaction || ''}` : `${(trigger.then?.replies || []).length || (trigger.then?.reply ? 1 : 0)} صيغة رد`;
    return `<div class="rule-row"><div><b>${esc(trigger.name || 'عداد رسائل')}</b><small>عند ${Number(trigger.threshold || 0).toLocaleString('ar-OM')} رسالة · ${trigger.scope === 'chat' ? 'لكل محادثة' : 'الجلسة كلها'} · أولوية ${Number(trigger.priority || 0)}</small><span>${esc(action)}</span></div><div class="row-actions"><button class="btn small" data-edit-counter="${esc(trigger.id)}">تعديل</button><button class="btn small" data-toggle-counter="${esc(trigger.id)}">${trigger.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-counter="${esc(trigger.id)}">حذف</button></div></div>`;
  }

  function interactionRow(item) {
    const when = item.at ? new Date(item.at) : null;
    return `<div class="interaction-row"><div><b>${esc(item.ruleName || item.ruleId || 'قاعدة')}</b><span>${esc(item.status || '')}</span></div><small>${esc(item.chatId || '')} · ${when && !Number.isNaN(when.getTime()) ? esc(when.toLocaleString('ar-OM')) : ''}</small></div>`;
  }

  function connectionStatusLabel(runtime = {}) {
    if (runtime.ready || runtime.status === 'ready') return 'متصل وجاهز';
    return ({ qr:'بانتظار مسح رمز QR', pairing_code:'رمز الربط بالهاتف جاهز', pairing_code_expired:'انتهت مهلة عرض رمز الربط', starting:'جارٍ فتح WhatsApp Web', authenticated:'تم التوثيق؛ جارٍ الإعداد', recovering:'جارٍ إصلاح الاتصال تلقائيًا', auth_failure:'فشل التوثيق ويحتاج ربطًا جديدًا', logged_out:'تم تسجيل الخروج — يلزم إعادة الربط', disconnected:'انقطع الاتصال', error:'تعذر بدء الاتصال', stopping:'جارٍ الإيقاف', stopped:'متوقف', idle:'لم يبدأ الاتصال' }[runtime.status] || runtime.status || 'غير متصل');
  }
  function connectionStatusHint(runtime = {}) {
    if (runtime.profileRecoveryNotice) return runtime.profileRecoveryNotice;
    if (runtime.authBackupNotice) return runtime.authBackupNotice;
    if (runtime.status === 'logged_out') return 'تم تسجيل خروج الحساب من WhatsApp. أوقف النظام محاولات الاستعادة التلقائية، وحفظ ملف الجلسة القديم احتياطيًا. اضغط «ربط / تشغيل» لمسح QR أو طلب رمز جديد؛ لن تُحذف محادثاتك أو إعدادات البوت.';
    if (runtime.ready || runtime.status === 'ready') return 'الاتصال جاهز. يمكنك الآن استخدام الاستقبال والردود والإرسال.';
    if (runtime.status === 'pairing_code') return 'أدخل الرمز الظاهر أدناه في WhatsApp على الهاتف: الأجهزة المرتبطة ← ربط جهاز ← الربط برقم الهاتف. يخفيه البوت محليًا بعد 3 دقائق؛ مدة الصلاحية الرسمية يحددها WhatsApp. لا تشاركه.';
    if (runtime.status === 'pairing_code_expired') return 'أُخفي الرمز القديم بعد انتهاء مهلة الحماية المحلية. اضغط «طلب رمز جديد» ولا تعِد استخدام الرمز السابق.';
    if (runtime.status === 'qr' && !runtime.qr) return 'تم استلام رمز الربط؛ جارٍ تحويله إلى صورة آمنة…';
    if (runtime.status === 'qr') return 'افتح WhatsApp في الهاتف ← الأجهزة المرتبطة ← ربط جهاز، ثم امسح هذا الرمز. الرمز يتجدد تلقائيًا إذا انتهت صلاحيته.';
    if (runtime.status === 'starting' && runtime.qrWaitWarning) return `${runtime.qrWaitWarning} أوقف الجلسة ثم جرّب الربط مرة أخرى بعد معالجة السبب.`;
    if (runtime.status === 'starting') return 'جارٍ تشغيل Chromium وفتح WhatsApp Web. سيظهر رمز الربط هنا تلقائيًا دون إعادة تحميل الصفحة؛ إذا استغرق فتح الموقع وقتًا طويلًا ستظهر رسالة تشخيص هنا.';
    if (runtime.status === 'authenticated') return 'قبل WhatsApp عملية التوثيق؛ جارٍ التأكد من جاهزية الجلسة.';
    if (runtime.status === 'recovering') return `يحاول النظام استعادة متصفح WhatsApp (${Number(runtime.navigationRetries || 0)}/3). اتركه يعمل ولا تضغط الاتصال مرارًا.`;
    if (runtime.status === 'auth_failure') return 'تعذر استعادة بيانات المصادقة. اضغط «فصل الحساب» ثم «ربط / تشغيل» للحصول على QR جديد إذا لزم الأمر.';
    if (runtime.status === 'error' && /WHATSAPP_SESSION_PROCESS_LOCKED|BROWSER_PROFILE_IN_USE|ملف جلسة WhatsApp مستخدم بالفعل|جلسة WhatsApp محجوزة بالفعل|بقي متصفح Chromium السابق مفتوحًا/i.test(String(runtime.lastError || ''))) return 'ملف جلسة WhatsApp مفتوح في نسخة أخرى. أوقف النسخة القديمة من chat BOT أو أغلق Chromium الذي يستخدم ملف الجلسة نفسه، ثم أعد المحاولة. لا تحذف مجلد auth يدويًا.';
    if (runtime.status === 'error' && /ERR_BLOCKED_BY_ADMINISTRATOR|ERR_BLOCKED_BY_CLIENT/i.test(String(runtime.lastError || ''))) return 'المتصفح أو سياسة الشبكة تمنع فتح WhatsApp Web. اسمح لـ web.whatsapp.com في الجدار الناري/برنامج الحماية، أو جرّب شبكة ومتصفحًا مسموحًا. لن يظهر QR صالح قبل أن يفتح WhatsApp Web فعليًا.';
    if (runtime.status === 'error' && /ERR_PROXY_CONNECTION_FAILED|ERR_TUNNEL_CONNECTION_FAILED|ERR_NAME_NOT_RESOLVED|ERR_INTERNET_DISCONNECTED/i.test(String(runtime.lastError || ''))) return 'تعذر الوصول إلى WhatsApp Web عبر الشبكة الحالية. تحقق من الإنترنت وDNS وإعدادات البروكسي؛ سيظهر QR بعد نجاح فتح الصفحة، ولن يتم إنشاء رمز وهمي.';
    if (runtime.status === 'error') return 'افحص رسالة الخطأ وسجل الجلسة أدناه، ثم تأكد من الإنترنت ووجود Chrome/Chromium صالح.';
    if (runtime.status === 'disconnected') return 'الجلسة منقطعة. سيحاول النظام الاستعادة عند توفر جلسة محفوظة؛ افحص السبب أدناه.';
    return 'اضغط «ابدأ الربط» مرة واحدة. انتظر ظهور QR أو رمز الهاتف، ولا تضغط الزر مرارًا أثناء تشغيل المتصفح.';
  }
  function pageIntegrations(data) {
    const h = state.integrationHub || { connections: [], rules: [], inbox: [], templates: [], catalog: { total: 320, families: 20 } };
    const health = state.integrationHealth;
    const healthLevels = { success: 'سليم في السجل', info: 'معلومة', warning: 'يحتاج مراجعة', error: 'مشكلة' };
    const healthPanel = `<section class="panel integration-health-panel"><div class="panel-head"><div><h2>تشخيص المركز بنظرة واحدة</h2><p>تقرير محلي للاتصالات والأجهزة والقواعد والمهام، دون تنفيذ طلبات إضافية على أهدافك.</p></div><button class="btn small" id="refreshIntegrationHealthBtn">تحديث التشخيص</button></div>${health ? `<div class="stats-grid integration-summary"><article class="stat-card"><span>لم تُفحص</span><b>${Number(health.summary?.neverChecked)||0}</b><small>اتصالات تحتاج اكتشافًا</small></article><article class="stat-card"><span>أجهزة متصلة</span><b>${Number(health.summary?.onlineDevices)||0}/${Number(health.summary?.devices)||0}</b><small>حسب آخر نبضة</small></article><article class="stat-card"><span>قواعد غير مدعومة</span><b>${Number(health.summary?.unsupportedEnabledRules)||0}</b><small>مفعّلة دون دليل قدرة</small></article><article class="stat-card"><span>تشغيلات فاشلة</span><b>${Number(health.summary?.failedRuns||0)+Number(health.summary?.failedTasks||0)}</b><small>نتائج محفوظة</small></article></div><div class="integration-health-checks">${(health.checks||[]).map(check=>`<div class="integration-inbox-row"><span class="integration-inbox-dot ${esc(check.level||'info')}"></span><div><b>${esc(check.title)}${Number(check.count)>0?` (${Number(check.count)})`:''}</b><small>${esc(check.detail||'')}</small></div><span class="integration-state ${check.level==='success'?'success':check.level==='error'?'warning':''}">${esc(healthLevels[check.level]||'مراجعة')}</span></div>`).join('')||'<div class="empty">لا توجد ملاحظات.</div>'}</div><p class="muted">آخر تحديث: ${esc(health.generatedAt?new Date(health.generatedAt).toLocaleString('ar-OM'):'—')}. ${esc((health.notes||[]).join(' '))}</p>`:'<div class="empty">تعذّر جلب التشخيص. اضغط تحديث التشخيص.</div>'}</section>`;
    const connections = h.connections || [], rules = h.rules || [], inbox = h.inbox || [], devices = h.devices || [], plugins = h.plugins || [], agentTasks = h.agentTasks || [];
    const types = [['http','موقع أو API عبر HTTP'],['openapi','OpenAPI / Swagger'],['folder','مجلد أو ملفات محلية'],['database','ملف قاعدة بيانات للقراءة فقط'],['command','برنامج محلي من قائمة آمنة'],['webhook','استقبال أحداث من تطبيق آخر']];
    const options = types.map(([id,label])=>`<option value="${id}">${label}</option>`).join('');
    const typeName = t => ({http:'موقع / API',openapi:'OpenAPI',folder:'مجلد محلي',database:'قاعدة بيانات',command:'برنامج محلي',webhook:'Webhook'}[t]||t);
    const statusLabel = c => ({new:'لم يتم الفحص',reachable:'يمكن الوصول',warning:'يحتاج مراجعة',failed:'فشل الفحص','spec-only':'مواصفات فقط',ready:'جاهز'}[c.status]||c.status||'غير معروف');
    const statusClass = c => ['reachable','ready','spec-only'].includes(c.status)?'success':(['warning','failed'].includes(c.status)?'warning':'');
    const connectionDiagnosis = c => { const status=Number(c.lastProbe?.status||0), error=String(c.lastProbe?.error||''); if(status===401) return 'HTTP 401: بيانات الدخول مطلوبة أو غير صحيحة. أضف Authorization/API Key من حقل بيانات الدخول المشفّرة.'; if(status===403) return 'HTTP 403: الحساب لا يملك الصلاحية المطلوبة، أو أن الموقع يمنع هذا الجهاز/العنوان.'; if(status===404) return 'HTTP 404: راجع عنوان API والمسار؛ قد يكون الرابط الأساسي ناقصًا.'; if(status===429) return 'HTTP 429: تجاوزت حد الطلبات. خفّض التكرار وانتظر حسب سياسة الموقع.'; if(status>=500) return `HTTP ${status}: المشكلة غالبًا من الخادم الهدف؛ راجع سجله أو جرّب لاحقًا.`; if(!status && error) return /مهلة|timeout|timed out|AbortError/i.test(error)?'انتهت مهلة الطلب. تحقق من الرابط والشبكة والجدار الناري ثم أعد الفحص.':`تعذر الاتصال: ${error}`; if(status>=200&&status<300&&!c.specSummary) return 'الاتصال يصل، لكن لم تُكتشف مواصفات API. الصق OpenAPI/Swagger أو تحقق من المسارات يدويًا.'; return ''; };
    const connectionCards = connections.length ? connections.map(c=>`<article class="panel integration-card"><div class="integration-card-head"><div><span class="integration-type">${esc(typeName(c.type))}</span><h3>${esc(c.name)}</h3><p class="integration-target" dir="auto">${esc(c.url||c.folderPath||c.filePath||c.command||'نقطة استقبال محلية')}</p>${c.hasCredentials?'<small class="muted">بيانات دخول محفوظة مشفّرة</small>':''}${connectionDiagnosis(c)?`<small class="unsupported-reason">${esc(connectionDiagnosis(c))}</small>`:''}</div><span class="integration-state ${statusClass(c)}">${esc(statusLabel(c))}</span></div><div class="integration-metrics"><span><b>${(c.capabilities||[]).length}</b><small>قدرات مؤكدة</small></span><span><b>${c.specSummary?.paths||0}</b><small>مسارات موثقة</small></span><span><b>${c.webhookReceived||0}</b><small>أحداث مستقبلة</small></span></div><div class="integration-actions"><button class="btn primary small" data-discover-integration="${esc(c.id)}">اكتشاف وفحص</button><button class="btn small" data-test-integration="${esc(c.id)}">اختبار 320 حالة</button>${['http','openapi'].includes(c.type)?`<button class="btn small" data-edit-integration-credentials="${esc(c.id)}">${c.hasCredentials?'تغيير/حذف بيانات الدخول':'إضافة بيانات دخول'}</button>`:''}${c.type==='webhook'?`<button class="btn small" data-rotate-webhook="${esc(c.id)}">رابط استقبال جديد</button>`:''}<button class="btn danger small" data-delete-integration="${esc(c.id)}">حذف</button></div><div class="integration-capabilities">${(c.capabilities||[]).length?(c.capabilities||[]).map(cap=>`<span>${esc(cap)}</span>`).join(''):'<small>لم يتم اكتشاف قدرات بعد. ابدأ بالفحص.</small>'}</div><details class="integration-templates"><summary>القوالب الجاهزة (20 قاعدة)</summary><p class="muted">القالب غير المدعوم يبقى معطّلًا. أضف القاعدة ثم شغّلها من قائمة القواعد عند مراجعتها.</p><div class="integration-template-list">${(c.templates||[]).map(t=>`<div class="integration-template ${t.supported?'':'unsupported'}"><div><b>${esc(t.name)}</b><small>${esc(t.description)}</small>${!t.supported?`<small class="unsupported-reason">${esc(t.reason||'القدرة غير مثبتة')}</small>`:''}</div><button class="btn small" data-add-template="${esc(c.id)}" data-template-id="${esc(t.id)}" ${t.supported?'':'disabled'} title="${esc(t.reason||'إضافة القاعدة')}">إضافة القاعدة</button></div>`).join('')}</div></details></article>`).join('') : '<div class="empty">لا يوجد اتصال بعد. أضف موقعًا أو API أو مجلدًا أو برنامجًا من النموذج أعلاه.</div>';
    const ruleCards = rules.length ? rules.map(r=>`<div class="integration-rule"><div class="integration-rule-main"><b>${esc(r.name)}</b><small>${esc(r.description||r.action)} · ${esc(r.triggerType==='schedule'?`كل ${r.everyMinutes} دقيقة`:r.triggerType==='webhook'?'عند وصول Webhook':'تشغيل يدوي')}</small><small>${esc(r.lastResult?.summary||'لم تعمل بعد')}</small></div><span class="integration-state ${r.enabled?'success':''}">${r.enabled?'مفعّلة':'متوقفة'}</span><div class="integration-actions"><button class="btn small" data-run-integration-rule="${esc(r.id)}" ${r.supported?'':'disabled'}>تشغيل الآن</button><button class="btn small" data-toggle-integration-rule="${esc(r.id)}" data-enabled="${r.enabled?'false':'true'}" ${(!r.supported&&!r.enabled)?'disabled':''}>${r.enabled?'إيقاف':'تشغيل'}</button><button class="btn danger small" data-delete-integration-rule="${esc(r.id)}">حذف</button></div></div>`).join('') : '<div class="empty">لا توجد قواعد بعد. أضف قالبًا جاهزًا أو اكتب قاعدة بكلامك.</div>';
    const notices = inbox.length ? inbox.slice(0,20).map(n=>`<div class="integration-inbox-row"><span class="integration-inbox-dot ${esc(n.level)}"></span><div><b>${esc(n.title)}</b><small>${esc(n.message)}</small><time>${esc(n.at?new Date(n.at).toLocaleString('ar-OM'):'')}</time></div></div>`).join('') : '<div class="empty">سيظهر هنا نجاح الفحص وفشله والتنبيهات داخل البوت.</div>';
    const targetOptions = [...(data.recipients||[]).map(r=>({id:`r:${r.id}`,label:`شخص: ${r.name||r.international||r.phone||r.id}`})),...(data.groups||[]).map(g=>({id:`g:${g.id}`,label:`مجموعة: ${g.name||g.gid}`}))].map(x=>`<option value="${esc(x.id)}" ${h.settings?.whatsappTarget===x.id?'selected':''}>${esc(x.label)}</option>`).join('');
    const report = state.integrationLatestRun;
    const counts = report?.counts || {};
    const pluginCards = plugins.length ? plugins.map(p=>`<div class="integration-rule"><div class="integration-rule-main"><b>${esc(p.name)}</b><small>${esc(p.adapter)} · الإصدار ${esc(p.version)}</small><small>${esc(p.description||'إضافة تعريفية آمنة')}</small></div><div class="integration-actions"><button class="btn small primary" data-connect-plugin="${esc(p.id)}">إنشاء اتصال</button><button class="btn danger small" data-delete-plugin="${esc(p.id)}">حذف الإضافة</button></div></div>`).join('') : '<div class="empty">لا توجد إضافات خاصة بعد. يمكن إضافة تعريف اتصال بصيغة JSON بسيطة.</div>';
    const deviceCards = devices.length ? devices.map(d=>`<div class="integration-rule"><div class="integration-rule-main"><b>${esc(d.name||d.hostname||d.id)}</b><small>${esc(d.os||'نظام غير معروف')} / ${esc(d.arch||'')} · ${esc(d.status==='online'?'متصل':d.status==='revoked'?'ملغى':'غير متصل')}</small><small>${esc(d.hostname||d.id)} · آخر ظهور: ${esc(d.lastSeenAt?new Date(d.lastSeenAt).toLocaleString('ar-OM'):'—')}</small></div>${d.status!=='revoked'?`<div class="integration-actions"><button class="btn small" data-agent-info="${esc(d.id)}">فحص الجهاز</button><button class="btn small" data-agent-command="${esc(d.id)}">فحص برنامج</button><button class="btn small" data-agent-folder="${esc(d.id)}">عرض مجلد مسموح</button><button class="btn small" data-agent-db="${esc(d.id)}">فحص ملف بيانات</button><button class="btn danger small" data-revoke-agent="${esc(d.id)}">إلغاء الربط</button></div>`:'<span class="integration-state warning">تم إلغاء الربط</span>'}</div>`).join('') : '<div class="empty">لم يتم ربط أجهزة أخرى بعد. أنشئ رمزًا مؤقتًا ثم شغّل الوكيل على الجهاز الذي تريد ربطه.</div>';
    const agentTaskRows = agentTasks.length ? agentTasks.slice(0,10).map(t=>`<div class="integration-inbox-row"><span class="integration-inbox-dot ${t.status==='failed'?'error':t.status==='done'?'success':'warning'}"></span><div><b>${esc(t.action)} · ${esc(t.status)}</b><small>${esc(t.result?.summary||t.result?.error||'بانتظار نتيجة الجهاز')}</small><time>${esc(t.updatedAt?new Date(t.updatedAt).toLocaleString('ar-OM'):'')}</time></div></div>`).join('') : '<div class="empty">ستظهر نتائج مهام الأجهزة هنا.</div>';
    return `<section class="page-title"><p class="eyebrow">مركز التكاملات المحلي</p><h1>ربط التطبيقات والمواقع</h1><p>اربط موقعًا أو API أو ملفات أو برنامجًا محليًا، افحص ما يدعمه فعلًا، ثم أنشئ قواعد آمنة. لا يحتاج مركز التكاملات إلى خدمة سحابية خاصة به.</p></section>
    ${healthPanel}
    <section class="stats-grid integration-summary"><article class="stat-card"><span>الاتصالات المحفوظة</span><b>${connections.length}</b><small>محفوظة محليًا حسب الجلسة</small></article><article class="stat-card"><span>سيناريوهات الاختبار</span><b>${h.catalog?.total||320}</b><small>من قاعدة اختبارات مركزية</small></article><article class="stat-card"><span>القواعد</span><b>${rules.length}</b><small>${rules.filter(r=>r.enabled).length} مفعّلة</small></article><article class="stat-card"><span>رسائل المركز</span><b>${inbox.length}</b><small>نتائج وسجل نشاط</small></article></section>
    <section class="content-grid two-col integration-main-grid"><article class="panel"><div class="panel-head"><div><h2>إضافة اتصال جديد</h2><p>حدد نوع الاتصال. ابدأ بالفحص لاكتشاف القدرات المتاحة.</p></div></div><div class="form-grid two"><label>اسم الاتصال<input id="integrationName" placeholder="مثال: متجر المدرسة"></label><label>نوع الاتصال<select id="integrationType">${options}</select></label><label class="wide integration-field-url">رابط الموقع أو API<input id="integrationUrl" placeholder="https://example.com أو http://127.0.0.1:3000"><small>يُستخدم طلب قراءة فقط. لا تضع كلمات مرور أو مفاتيح سر داخل الرابط.</small></label><label class="wide integration-field-auth" hidden>بيانات الدخول (اختياري، JSON)<textarea id="integrationHeaders" rows="3" spellcheck="false" dir="ltr" placeholder='{"Authorization":"Bearer YOUR_TOKEN","X-API-Key":"YOUR_KEY"}'></textarea><small>تُشفّر القيم محليًا بمفتاح خاص بهذه الجلسة، ولا تعود قيمها إلى الواجهة بعد الحفظ. امسح النموذج بعد الاستخدام ولا تضع الأسرار في الرابط.</small></label><label class="wide integration-field-folder" hidden>مسار المجلد الكامل<input id="integrationFolderPath" dir="ltr" placeholder="C:\\Users\\You\\Documents أو /home/user/files"></label><label class="wide integration-field-file" hidden>مسار ملف البيانات<input id="integrationFilePath" dir="ltr" placeholder="C:\\data\\app.db أو /home/user/data.json"><small>يدعم JSON وCSV وSQLite بقراءة فقط.</small></label><label class="wide integration-field-command" hidden>البرنامج<select id="integrationCommand"><option value="node">Node.js</option><option value="npm">npm</option><option value="python">Python</option><option value="git">Git</option><option value="ollama">Ollama المحلي</option><option value="curl">curl</option></select><small>لا يسمح بتشغيل أمر حر أو حذف ملفات.</small></label><label class="wide integration-field-spec" hidden>مواصفات OpenAPI/Swagger (JSON أو YAML)<textarea id="integrationSpec" rows="6" placeholder="الصق ملف OpenAPI هنا؛ أو اتركه فارغًا ليحاول النظام اكتشافه من الرابط."></textarea><input id="integrationSpecFile" type="file" accept=".json,.yaml,.yml,.txt,application/json,text/yaml"></label></div><div class="action-bar"><button class="btn primary" id="createIntegrationBtn">حفظ الاتصال</button><button class="btn" id="refreshIntegrationsBtn">تحديث المركز</button></div>${state.integrationWebhookPath?`<div class="webhook-created"><b>رابط الاستقبال الجديد (احتفظ به الآن)</b><code dir="ltr">${esc(state.integrationWebhookPath)}</code><button class="btn small" id="copyIntegrationWebhook">نسخ الرابط</button><small>الرابط سرّي. أي شخص يمتلكه يمكنه إرسال أحداث إلى البوت. يمكنك إبطاله بإنشاء رابط جديد.</small></div>`:''}</article>
    <article class="panel"><div class="panel-head"><div><h2>طريقة الفحص</h2><p>اختبارات كثيرة، من دون مخاطرة على الهدف.</p></div></div><div class="integration-explain"><div><b>1. اكتشاف</b><p>يفحص رابطك، ترويساته، زمن الاستجابة ويحاول العثور على OpenAPI.</p></div><div><b>2. 320 حالة</b><p>يشغّل فحصًا آمنًا أساسيًا، ويصنّف بقية الحالات إلى ناجح أو فاشل أو متخطى أو غير مدعوم حسب الدليل الفعلي.</p></div><div><b>3. قواعد تعمل على القدرة المتاحة</b><p>لا يمكن تشغيل قالب يحتاج قدرة لم تثبت. لا تُرسل طلبات كتابة أو حذف بشكل تلقائي.</p></div></div><p class="callout">تنبيه: قد يتطلب أي موقع تسجيل دخول أو مفتاح API أو صلاحية من صاحبه. لا يتجاوز المركز الحماية أو CAPTCHA، ولا يضمن دعم كل برنامج بلا طريقة اتصال مناسبة.</p></article></section>
    <section class="panel"><div class="panel-head"><div><h2>الاتصالات</h2><p>اكتشف القدرات أولًا لتظهر القوالب التي يمكن استخدامها بأمان.</p></div><span class="release-pill">${connections.length} اتصال</span></div><div class="integration-connection-list">${connectionCards}</div></section>
    <section class="content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>ربط جهاز آخر</h2><p>اربط كمبيوترًا موثوقًا لتفحص البرامج أو المجلدات المسموح بها من مركز البوت.</p></div></div><div class="form-grid two"><label class="wide">عنوان البوت من الجهاز الآخر<input id="integrationAgentServer" dir="ltr" value="${esc(location.origin)}" placeholder="http://192.168.1.20:7005"><small>على الجهاز نفسه اترك العنوان كما هو. لجهاز آخر يجب أن يكون الخادم متاحًا عبر شبكة موثوقة أو VPN؛ لا تعرض HTTP للإنترنت.</small></label><label class="wide">اسم الجهاز<input id="integrationAgentName" maxlength="100" value="جهاز جديد"></label></div><div class="action-bar"><button class="btn primary" id="createAgentEnrollmentBtn">إنشاء رمز ربط مؤقت</button><button class="btn" id="copyIntegrationAgentCommand" ${state.integrationAgentCommand?'':'disabled'}>نسخ أمر الربط</button></div>${state.integrationEnrollment?`<div class="webhook-created"><b>رمز تسجيل مؤقت — صالح حتى ${esc(new Date(state.integrationEnrollment.expiresAt).toLocaleTimeString('ar-OM'))}</b><p>انسخ الأمر التالي وشغّله في مجلد المشروع على الجهاز الآخر. الرمز يُستخدم مرة واحدة فقط.</p><code dir="ltr" style="white-space:pre-wrap;overflow-wrap:anywhere">${esc(state.integrationAgentCommand)}</code><button class="btn small" id="dismissAgentEnrollment">إخفاء الرمز من الشاشة</button></div>`:''}<div class="integration-rule-list">${deviceCards}</div></article><article class="panel"><div class="panel-head"><div><h2>الإضافات الخاصة</h2><p>احفظ إعدادًا جاهزًا لموقع أو برنامج ثم حوّله إلى اتصال.</p></div></div><label>ملف إضافة JSON<textarea id="integrationPluginManifest" rows="9" dir="ltr" spellcheck="false" placeholder='{"id":"school-api","name":"School API","version":"1.0.0","adapter":"http","url":"https://example.com/health","description":"فحص حالة واجهة المدرسة"}'></textarea><small>الأنواع المسموحة: http, openapi, folder, database, command, webhook. هذه الإضافات تعريفات إعدادات آمنة؛ لا تشغّل كود JavaScript مجهولًا.</small></label><div class="action-bar"><button class="btn primary" id="addIntegrationPluginBtn">حفظ الإضافة</button></div><div class="integration-rule-list">${pluginCards}</div></article></section>
    <section class="panel"><div class="panel-head"><div><h2>مهام الأجهزة</h2><p>كل مهمة محدودة وواضحة؛ الأوامر الحرة والحذف والتنفيذ التعسفي غير مسموح.</p></div><button class="btn small" id="refreshIntegrationsBtn2">تحديث</button></div><div class="integration-inbox">${agentTaskRows}</div></section>
    <section class="content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>القواعد وسير العمل</h2><p>أضف قاعدة بلغة بسيطة. القاعدة تبدأ متوقفة لحين مراجعتها.</p></div></div><div class="form-grid two"><label class="wide">الاتصال<select id="integrationRuleConnection">${connections.map(c=>`<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('')}</select></label><label class="wide">صف القاعدة بكلامك<textarea id="integrationRuleText" rows="3" placeholder="مثال: افحص حالة الموقع كل 15 دقيقة وسجل أي خطأ"></textarea></label><label>الإجراء (اختياري)<select id="integrationRuleAction"><option value="">استنتج من الكلام</option><option value="http_health">فحص حالة الموقع</option><option value="http_latency">قياس وقت الاستجابة</option><option value="http_security_headers">فحص ترويسات الأمان</option><option value="http_content_type">فحص نوع المحتوى</option><option value="http_redirects">فحص التحويلات</option><option value="openapi_report">ملخص OpenAPI</option><option value="openapi_get_list">قائمة مسارات GET</option><option value="http_get_endpoint">طلب GET لمسار محدد</option><option value="folder_list">عرض الملفات</option><option value="command_version">فحص إصدار برنامج</option><option value="database_inspect">فحص قاعدة بيانات</option><option value="webhook_report">ملخص Webhook</option><option value="local_audit">تسجيل في السجل</option></select></label><label>طريقة التشغيل<select id="integrationRuleTrigger"><option value="manual">يدوي</option><option value="schedule">مجدول</option><option value="webhook">عند وصول Webhook</option></select></label><label>الفاصل بالدقائق<input id="integrationRuleEvery" type="number" min="1" max="1440" value="15"></label><label>مسار GET (إن اخترت طلب مسار)<input id="integrationRuleEndpoint" dir="ltr" placeholder="/api/health"></label></div><button class="btn primary" id="createIntegrationRuleBtn" ${connections.length?'':'disabled'}>إضافة القاعدة</button><div class="integration-rule-list">${ruleCards}</div></article><article class="panel"><div class="panel-head"><div><h2>رسائل المركز والتنبيهات</h2><p>تظهر النتائج هنا تلقائيًا. التنبيه إلى WhatsApp مغلق حتى تسمح به.</p></div></div><div class="integration-notify-settings"><label class="toggle-row"><input id="integrationWhatsappNotify" type="checkbox" ${h.settings?.whatsappNotificationsEnabled?'checked':''}><span>إرسال تنبيهات الفشل والتحذير إلى WhatsApp (بموافقتي)</span></label><label>الجهة التي ستستقبل التنبيه<select id="integrationWhatsappTarget"><option value="">اختر شخصًا أو مجموعة</option>${targetOptions}</select></label><button class="btn small" id="saveIntegrationNotify">حفظ إعدادات التنبيه</button><small>يُحفظ سجل المركز محليًا دائمًا. إرسال WhatsApp لا يعمل إلا بعد تحديد جهة وتشغيل الخيار صراحةً واتصال الحساب.</small></div><div class="integration-inbox">${notices}</div></article></section>
    <section class="panel"><div class="panel-head"><div><h2>آخر تقرير للاختبار</h2><p>لا تساوي الحالات التي تم تخطيها أو التي لا يدعمها الاتصال فشلًا.</p></div><div class="integration-actions"><button class="btn small" id="downloadIntegrationReport" ${report?'':'disabled'}>تنزيل التقرير JSON</button><button class="btn small" id="refreshIntegrationReport">تحديث التقرير</button></div></div>${report?`<div class="integration-report-summary"><span>سيناريوهات الكتالوج <b>${report.catalogScenarios||report.total}</b></span><span>حالات نُفذت فعلًا <b>${report.executedCases||0}</b></span><span>طلبات الهدف <b>${report.actualTargetProbes||0}</b></span>${Object.entries(counts).map(([k,v])=>`<span class="test-count ${k.toLowerCase()}">${esc(k)} <b>${v}</b></span>`).join('')}</div><div class="integration-test-table"><table><thead><tr><th>الرمز</th><th>الفحص</th><th>النتيجة</th><th>التفاصيل</th></tr></thead><tbody>${(report.results||[]).slice(0,40).map(r=>`<tr><td dir="ltr">${esc(r.id)}</td><td>${esc(r.title)}</td><td><span class="test-status ${String(r.status).toLowerCase()}">${esc(r.status)}</span></td><td>${esc(r.detail)}</td></tr>`).join('')}</tbody></table></div><p class="muted">المعروض أول 40 حالة من التقرير؛ زر التنزيل يحفظ كل الحالات. سيناريوهات الكتالوج ليست 320 طلبًا حيًا. الحالات المبنية على دليل الاكتشاف فقط تظهر INCONCLUSIVE ولا تُحسب نجاحًا منفذًا؛ حالات مراجعة الإنسان تبقى متخطاة.</p>`:'<div class="empty">شغّل «اختبار 320 حالة» على أحد الاتصالات لعرض تقرير مفصل هنا.</div>'}</section>`;
  }

  function pageSession(data) {
    const runtime = data.whatsapp || {};
    const qr = typeof runtime.qr === 'string' && /^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(runtime.qr) ? runtime.qr : '';
    const pendingQr = ['starting', 'qr', 'recovering'].includes(runtime.status);
    const showQrPanel = Boolean(qr) || pendingQr;
    const showPairingCode = Boolean(runtime.pairingCode) || ['pairing_code','pairing_code_expired'].includes(runtime.status);
    const method = ['qr','phone'].includes(state.connectionMethod) ? state.connectionMethod : (['qr','phone'].includes(runtime.connectionMethod) ? runtime.connectionMethod : 'qr');
    const phoneNumber = state.connectionPhoneNumber || '';
    const qrPendingText = runtime.connectionMethod === 'phone' && runtime.status === 'starting' ? 'جارٍ طلب رمز الربط المرتبط برقم الهاتف…' : runtime.status === 'qr' ? 'وصل رمز الربط؛ جارٍ تجهيز الصورة…' : runtime.status === 'recovering' ? 'جارٍ استعادة المتصفح…' : 'جارٍ فتح WhatsApp Web وانتظار رمز الربط الحقيقي…';
    return `<section class="page-title"><p class="eyebrow">الجلسة</p><h1>اتصال وإدارة الحساب</h1><p>كل جلسة مستقلة بحسابها وأهدافها وسجلها.</p></section><section class="content-grid two-col">
      <article class="panel"><div class="panel-head"><div><h2>اتصال WhatsApp</h2><p>حالة الاتصال والـ QR تتحدث تلقائيًا خلال ثوانٍ.</p></div><button class="btn small" id="refreshSessionStatusBtn">تحديث الحالة</button></div><div class="status-panel"><span>الحالة</span><b id="sessionConnectionStatus">${esc(connectionStatusLabel(runtime))}</b><small id="sessionConnectionAccount">${runtime.info?.wid?.user ? `+${esc(runtime.info.wid.user)}` : ''}</small><small id="sessionConnectionHint" role="status">${esc(connectionStatusHint(runtime))}</small><small id="sessionConnectionError" class="session-error-detail" ${runtime.lastError ? '' : 'hidden'}>${runtime.lastError ? `تفاصيل آخر خطأ: ${esc(runtime.lastError)}` : ''}</small></div><div class="connection-method-panel"><label for="connectionMethod">اختر طريقة واحدة<select id="connectionMethod"><option value="qr" ${method === 'qr' ? 'selected' : ''}>QR — الأسهل والأفضل للربط الأول</option><option value="phone" ${method === 'phone' ? 'selected' : ''}>رمز الهاتف — إذا تعذر مسح QR</option></select></label><label id="pairingPhoneRow" ${method === 'phone' ? '' : 'hidden'}>رقم WhatsApp مع رمز الدولة<input id="pairingPhoneNumber" inputmode="tel" autocomplete="tel" dir="ltr" value="${esc(phoneNumber)}" placeholder="+968XXXXXXXX"><small>مثال: +96891234567. اكتب الرقم الكامل مع رمز الدولة.</small></label><ol class="connection-steps"><li>اضغط «ابدأ الربط».</li><li>لـ QR: افتح WhatsApp على الهاتف ← الأجهزة المرتبطة ← ربط جهاز، ثم امسح الصورة التي تظهر هنا.</li><li>انتظر حتى تصبح الحالة «متصل وجاهز».</li></ol><p class="muted connection-method-help">تغيير طريقة الربط لا يحذف الجلسة المحفوظة. استخدم «فصل الحساب» فقط إذا أردت إزالة ربط الحساب الحالي وربط حساب آخر.</p></div><div class="qr-box" id="sessionQrBox" ${showQrPanel ? '' : 'hidden'}><p><b>افتح WhatsApp على الهاتف</b> ← الأجهزة المرتبطة ← ربط جهاز، ثم امسح رمز QR الظاهر أدناه.</p><div class="session-qr-placeholder" id="sessionQrPlaceholder" ${qr ? 'hidden' : ''}><span class="session-qr-spinner" aria-hidden="true"></span><b id="sessionQrPlaceholderText">${esc(qrPendingText)}</b><small>لن يُعرض أي رمز حتى يصدر من WhatsApp Web الفعلي.</small></div><img ${qr ? `src="${esc(qr)}"` : ''} class="session-qr" id="sessionQrImage" alt="رمز ربط WhatsApp" decoding="async" ${qr ? '' : 'hidden'}><p class="qr-timestamp" id="sessionQrTimestamp">${runtime.qrUpdatedAt ? `آخر تحديث: ${esc(new Date(runtime.qrUpdatedAt).toLocaleTimeString('ar-OM'))}` : ''}</p></div><div class="pairing-code-panel" id="pairingCodePanel" ${showPairingCode ? '' : 'hidden'}><p class="eyebrow">رمز ربط الهاتف</p><div class="pairing-code-value" id="pairingCodeValue">${esc(runtime.pairingCode || '••••••••')}</div><p class="muted">على الهاتف: WhatsApp ← الأجهزة المرتبطة ← ربط جهاز ← الربط برقم الهاتف، ثم أدخل الرمز أعلاه. قد تنتهي صلاحية الرمز؛ اطلب رمزًا جديدًا عند الحاجة.</p><div class="action-bar"><button type="button" class="btn" id="copyPairingCodeBtn" ${runtime.pairingCode ? '' : 'disabled'}>نسخ رمز الربط</button><button type="button" class="btn primary" id="requestNewPairingCodeBtn">طلب رمز جديد</button></div></div><div class="action-bar"><button class="btn primary" id="connectSessionBtn">ابدأ الربط</button><button class="btn" id="stopSessionBtn">إيقاف</button><button class="btn danger" id="unlinkSessionBtn">فصل الحساب وإعادة الربط</button></div><p class="muted session-privacy-note">رمز QR ورمز الهاتف كلاهما بيانات ربط حساسة. لا تشارك أيًا منهما؛ لا تُكتب رموز الربط في سجل النشاط.</p></article>
      <article class="panel"><div class="panel-head"><div><h2>إعداد الجلسة</h2><p>الاسم يتغير فقط في الجلسة الحالية.</p></div></div><label>اسم الجلسة<input id="sessionName" value="${esc(data.session?.name || '')}" placeholder="الجلسة الرئيسية"></label><div class="action-bar"><button class="btn primary" id="saveSessionBtn">حفظ الاسم</button><button class="btn" id="newSessionBtn">جلسة جديدة</button><button class="btn danger" id="deleteSessionBtn">حذف الجلسة</button></div><div class="info-grid"><div><span>الحساب</span><b>${esc(runtime.info?.wid?.user || 'غير معروف')}</b></div><div><span>الاسم</span><b>${esc(runtime.info?.pushname || 'غير معروف')}</b></div><div><span>المجموعات</span><b>${(data.groups || []).length}</b></div><div><span>الأشخاص</span><b>${(data.recipients || []).length}</b></div></div></article>
    </section><section class="panel"><div class="panel-head"><div><h2>سجل الجلسة</h2><p>هذا السجل يخص هذه الجلسة وحدها.</p></div><button class="btn small" id="sessionRefreshLog">تحديث</button></div><div class="log-list tall">${(data.logs || []).map(logRow).join('') || '<div class="empty">السجل فارغ.</div>'}</div></section>`;
  }

  let sessionStatusPollBusy = false;
  async function refreshSessionRuntime() {
    if (sessionStatusPollBusy || state.page !== 'session' || !$('#sessionConnectionStatus')) return;
    sessionStatusPollBusy = true;
    try {
      const requestedSession = sid();
      const response = await fetch(`/api/session/status?sessionId=${encodeURIComponent(requestedSession)}&_=${Date.now()}`, { cache: 'no-store', headers: { 'Accept': 'application/json' } });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const payload = await response.json();
      if (!payload?.ok || state.page !== 'session' || requestedSession !== sid()) return;
      const runtime = payload.runtime || {};
      if (state.data) state.data.whatsapp = runtime;
      const label = $('#sessionConnectionStatus'); if (label) label.textContent = connectionStatusLabel(runtime);
      const account = $('#sessionConnectionAccount'); if (account) account.textContent = runtime.info?.wid?.user ? `+${runtime.info.wid.user}` : '';
      const hint = $('#sessionConnectionHint'); if (hint) hint.textContent = connectionStatusHint(runtime);
      const error = $('#sessionConnectionError');
      if (error) { error.textContent = runtime.lastError ? `تفاصيل آخر خطأ: ${runtime.lastError}` : ''; error.hidden = !runtime.lastError; }
      const box = $('#sessionQrBox'), img = $('#sessionQrImage'), placeholder = $('#sessionQrPlaceholder');
      const goodQr = typeof runtime.qr === 'string' && /^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(runtime.qr);
      const showPending = ['starting', 'qr', 'recovering'].includes(runtime.status);
      if (box) box.hidden = !(goodQr || showPending);
      if (img) {
        if (goodQr && img.dataset.qr !== runtime.qr) { img.src = runtime.qr; img.dataset.qr = runtime.qr; }
        if (!goodQr) { img.removeAttribute('src'); delete img.dataset.qr; }
        img.hidden = !goodQr;
      }
      if (placeholder) placeholder.hidden = goodQr || !showPending;
      const placeholderText = $('#sessionQrPlaceholderText');
      if (placeholderText) placeholderText.textContent = runtime.qrWaitWarning || (runtime.status === 'qr' ? 'وصل رمز الربط؛ جارٍ تجهيز الصورة…' : runtime.status === 'recovering' ? 'جارٍ استعادة المتصفح…' : 'جارٍ فتح WhatsApp Web وانتظار رمز الربط الحقيقي…');
      const stamp = $('#sessionQrTimestamp'); if (stamp) stamp.textContent = runtime.qrUpdatedAt ? `آخر تحديث: ${new Date(runtime.qrUpdatedAt).toLocaleTimeString('ar-OM')}` : '';
      const pairingPanel = $('#pairingCodePanel'), pairingValue = $('#pairingCodeValue'), copyPairing = $('#copyPairingCodeBtn');
      if (pairingPanel) pairingPanel.hidden = !(runtime.pairingCode || ['pairing_code','pairing_code_expired'].includes(runtime.status));
      if (pairingValue) pairingValue.textContent = runtime.pairingCode || '••••••••';
      if (copyPairing) copyPairing.disabled = !runtime.pairingCode;
    } catch (pollError) {
      // Keep the UI usable but surface a one-line connectivity issue instead of hiding it silently.
      const hint = $('#sessionConnectionHint'); if (hint && !hint.textContent.includes('تعذر تحديث حالة')) hint.textContent = 'تعذر تحديث حالة الاتصال الآن. تأكد أن الخادم المحلي يعمل، ثم اضغط «تحديث الحالة».';
    }
    finally { sessionStatusPollBusy = false; }
  }

  const bgNames = { aurora: 'الشفق', nebula: 'السديم', meteor: 'النيزك', matrix: 'المصفوفة', 'cyber-grid': 'الشبكة', plasma: 'البلازما', starfield: 'النجوم', vortex: 'الدوامة', galaxy: 'المجرة', ocean: 'الموجة' };
  function pageAppearance(data) {
    const background = data.background || {};
    const cfg = background.settings || {};
    const a = data.settings?.appearance || {};
    const visiblePresets = [['mint','نعناعي'],['ocean','بحري'],['violet','بنفسجي'],['sunset','غروب']];
    return `<section class="page-title"><p class="eyebrow">المظهر</p><h1>المظهر والخلفيات</h1><p>غيّر اللون والخلفية بسهولة، والتخصيص الكامل موجود داخل الخيارات المتقدمة.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>لون الواجهة</h2><p>اختر لونًا جاهزًا أو لونك الخاص.</p></div></div>
          <div class="theme-preview"><span class="theme-dot" id="themeDot1"></span><div><b>chat BOT</b><small>لون واحد واضح للواجهة</small></div></div>
          <div class="preset-row">${visiblePresets.map(([id,label]) => `<button class="btn small" data-ui-preset="${id}">${label}</button>`).join('')}</div>
          <label>اللون الأساسي<input id="uiAccent" type="color" value="${esc(a.accent || '#5ed6c1')}"></label>
          <details class="advanced-panel"><summary>تفاصيل الواجهة</summary><div class="form-grid two"><label>لون مساعد<input id="uiAccent2" type="color" value="${esc(a.accent2 || '#8b7cf6')}"></label>${rangeControl('uiPanelOpacity','وضوح البطاقات',a.panelOpacity ?? .94,.78,.97,.01)}${rangeControl('uiPanelBlur','نعومة البطاقات',a.panelBlur ?? 0,0,12,1)}${rangeControl('uiRadius','استدارة العناصر',a.radius ?? 13,10,24,1)}${rangeControl('uiGlow','وهج اللون',a.glow ?? .28,0,.8,.05)}</div></details>
          <div class="action-bar"><button class="btn primary" id="saveUiThemeBtn">حفظ اللون</button><button class="btn" id="resetUiThemeBtn">إعادة الافتراضي</button></div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الخلفية</h2><p>خلفيات جميلة وخفيفة على الجهاز.</p></div></div>
          <div class="bg-picker">${Object.entries(bgNames).map(([id,name]) => `<button class="bg-choice ${background.mode === id ? 'selected' : ''}" data-bg-mode="${id}"><span class="bg-swatch bg-${id}"></span><b>${name}</b></button>`).join('')}</div>
          <div class="upload-box"><input id="customBackground" type="file" accept="image/png,image/jpeg,image/webp"><label for="customBackground"><span>＋</span> اختيار صورة</label><small>الصورة تحفظ لهذه الجلسة فقط.</small></div>
          ${background.imageUrl ? `<div class="custom-current"><img src="${esc(background.imageUrl)}" alt="الخلفية الحالية"><span>الخلفية الحالية</span></div><div class="action-bar"><button class="btn danger" id="removeCustomBackgroundBtn">إزالة الصورة</button></div>` : ''}
          <details class="advanced-panel"><summary>تخصيص الخلفية بالتفصيل</summary><div class="range-grid">${rangeControl('bgSpeed','السرعة',cfg.speed, .1,2,.05)}${rangeControl('bgDensity','الكثافة',cfg.density,.2,1.6,.05)}${rangeControl('bgGlow','التوهج',cfg.glow,0,1,.05)}${rangeControl('bgIntensity','القوة',cfg.intensity,.2,1.5,.05)}${rangeControl('bgMouse','تأثير المؤشر',cfg.mouseStrength,0,1.5,.05)}${rangeControl('bgBrightness','السطوع',cfg.brightness,.6,1.4,.05)}${rangeControl('bgContrast','التباين',cfg.contrast,.7,1.4,.05)}${rangeControl('bgSaturation','التشبع',cfg.saturation,.5,1.6,.05)}${rangeControl('bgHue','تغيير اللون',cfg.hueRotate,0,360,1)}${rangeControl('bgBlur','التمويه',cfg.blur,0,6,.25)}${rangeControl('bgOpacity','الشفافية',background.opacity ?? .22,.08,.60,.01)}</div><div class="toggle-list"><label class="toggle-row"><input id="bgInteractive" type="checkbox" ${cfg.interactive !== false ? 'checked' : ''}><span><b>التفاعل</b><small>استجابة بسيطة للمؤشر والنقر.</small></span></label><label class="toggle-row"><input id="bgTrail" type="checkbox" ${cfg.trail !== false ? 'checked' : ''}><span><b>أثر الحركة</b><small>يعطي نعومة إضافية.</small></span></label></div></details>
          <div class="action-bar"><button class="btn primary" id="saveBackgroundBtn">حفظ الخلفية</button><button class="btn" id="resetBackgroundBtn">إعادة الافتراضي</button></div>
        </article>
      </section>`;
  }

  function pageSettings(data) {
    const active = state.settingsView === 'operation' ? 'operation' : 'appearance';
    return `<section class="settings-shell">
      <div class="settings-switch" role="tablist" aria-label="أقسام الإعدادات">
        <button class="settings-tab ${active === 'appearance' ? 'active' : ''}" data-settings-view="appearance" role="tab" aria-selected="${active === 'appearance'}">المظهر والخلفيات</button>
        <button class="settings-tab ${active === 'operation' ? 'active' : ''}" data-settings-view="operation" role="tab" aria-selected="${active === 'operation'}">التشغيل المتقدم</button>
      </div>
      <div class="settings-content">${active === 'appearance' ? pageAppearance(data) : pageOperation(data)}</div>
    </section>`;
  }

  function rangeControl(id, label, value, min, max, step) {
    const safe = Number.isFinite(Number(value)) ? Number(value) : Number(min);
    return `<label class="range-item"><span>${esc(label)} <output id="${id}Out">${safe.toFixed(step < 1 ? 2 : 0)}</output></span><input id="${id}" type="range" min="${min}" max="${max}" step="${step}" value="${safe}"></label>`;
  }

  function pageOperation(data) {
    const settings = data.settings || {};
    return `<section class="page-title"><p class="eyebrow">التشغيل</p><h1>إعدادات التشغيل</h1><p>الإعدادات الأساسية ظاهرة، والتفاصيل الإضافية داخل أقسام واضحة.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>الأساسيات</h2><p>هذه أهم الخيارات للاستخدام اليومي.</p></div></div>
          <div class="form-grid two"><label>المنطقة الزمنية<input id="opTimezone" value="${esc(settings.timezone || 'Asia/Muscat')}" placeholder="Asia/Muscat"></label><label>ترتيب الإرسال<select id="opSendOrder"><option value="target-first" ${settings.sendOrder === 'target-first' ? 'selected' : ''}>هدف ثم ملفاته</option><option value="image-first" ${settings.sendOrder === 'image-first' ? 'selected' : ''}>ملف ثم الأهداف</option></select></label></div>
          <div class="toggle-list"><label class="toggle-row"><input id="opAutoStart" type="checkbox" ${settings.autoStartSession !== false ? 'checked' : ''}><span><b>تشغيل الجلسة تلقائيًا</b><small>استعادة الحساب المحفوظ عند بدء البوت.</small></span></label><label class="toggle-row"><input id="opAutomation" type="checkbox" ${settings.automationEnabled !== false ? 'checked' : ''}><span><b>التشغيل التلقائي</b><small>تشغيل المواعيد المحفوظة لهذه الجلسة.</small></span></label></div>
          <div class="action-bar"><button class="btn primary" id="saveOperationMain">حفظ</button></div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الخصوصية والتشغيل</h2><p>المعلومات التي تحتاجها فقط.</p></div></div><div class="privacy-box"><p>المشروع يعمل محليًا وتبقى بيانات الجلسات والوسائط والسجل على الجهاز.</p><p>التشغيل المعتاد عبر <code>run.py</code> والمنفذ 7005.</p></div><div class="action-bar"><button class="btn" data-go="session">إدارة الجلسة</button><button class="btn" data-go="dashboard">الرئيسية</button></div></article>
      </section>
      <section class="content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>الموثوقية</h2><p>خيارات متقدمة، لا تحتاج تغييرها غالبًا.</p></div></div><details class="advanced-panel"><summary>إظهار إعدادات الموثوقية (اختياري)</summary><div class="form-grid two"><label>التأخير بين الإرسال (مللي ثانية)<input id="opDelay" type="number" min="0" max="60000" value="${Number(settings.sendDelayMs || 700)}"></label><label>مهلة الإرسال (مللي ثانية)<input id="opTimeout" type="number" min="5000" max="180000" value="${Number(settings.sendTimeoutMs || 30000)}"></label><label>عدد المحاولات<input id="opRetryAttempts" type="number" min="1" max="4" value="${Number(settings.retryAttempts || 2)}"></label><label>التأخير بين المحاولات (مللي ثانية)<input id="opRetryDelay" type="number" min="250" max="120000" value="${Number(settings.retryDelayMs || 1600)}"></label><label>أقصى حجم للملف MB<input id="opMaxSize" type="number" min="1" max="250" value="${Number(settings.maxImageSizeMB || 100)}"></label><label>عمر الرسالة المقبول للمعالجة (ثانية)<input id="opInboundAge" type="number" min="30" max="86400" value="${Number(settings.maxInboundMessageAgeSec || 300)}"></label><label>أقصى انتظار في طابور الرسائل (ثانية)<input id="opQueueWait" type="number" min="10" max="600" value="${Number(settings.maxInboundQueueWaitSec || 60)}"></label><label>أقصى رسائل قيد المعالجة والانتظار لكل جلسة<input id="opQueueDepth" type="number" min="5" max="200" value="${Number(settings.maxInboundQueueDepth || 40)}"></label></div><p class="help-note">تُحفظ الرسائل القديمة في الأرشيف، لكن لا تُنفّذ أوامرها ولا تُرسل ردودًا عليها. الرسائل التي تتجاوز مهلة الانتظار أو سعة الطابور لا تُعالج تلقائيًا.</p><div class="action-bar"><button class="btn primary" id="saveOperationReliability">حفظ</button></div></details></article>
        <article class="panel"><div class="panel-head"><div><h2>فترة هدوء التفاعل</h2><p>أوقف الردود التلقائية خلال وقت تحدده.</p></div></div><details class="advanced-panel"><summary>إظهار إعدادات فترة الهدوء</summary><div class="form-grid three"><label class="toggle-box"><input id="opQuietEnabled" type="checkbox" ${settings.interactionQuietEnabled ? 'checked' : ''}><span>تفعيل</span></label><label>من<input id="opQuietStart" type="time" value="${esc(settings.interactionQuietStart || '23:00')}"></label><label>إلى<input id="opQuietEnd" type="time" value="${esc(settings.interactionQuietEnd || '07:00')}"></label><label>السلوك<select id="opQuietAction"><option value="silence" ${(settings.interactionQuietAction || 'silence') === 'silence' ? 'selected' : ''}>لا ترد</option><option value="reply" ${settings.interactionQuietAction === 'reply' ? 'selected' : ''}>رد مخصص</option><option value="rules" ${settings.interactionQuietAction === 'rules' ? 'selected' : ''}>القواعد</option></select></label><label>الرد المخصص<input id="opQuietReply" maxlength="1000" value="${esc(settings.interactionQuietReply || 'أنا في فترة الهدوء الآن، سأرد عليك لاحقًا.')}"></label><label>تكرار الرد (ثانية)<input id="opQuietCooldownSec" type="number" min="0" max="86400" value="${Number(settings.interactionQuietCooldownSec ?? 300)}"></label></div><div class="action-bar"><button class="btn primary" id="saveOperationQuiet">حفظ</button></div></details></article></section>
      <section class="content-grid two-col"><article class="panel backup-panel"><div class="panel-head"><div><h2>نسخ احتياطي مشفّر</h2><p>احفظ إعدادات كل الجلسات والوسائط وملفات ربط WhatsApp والتكاملات في ملف محمي بكلمة مرور.</p></div><span class="mini-tag">محلي / AES-256-GCM</span></div>
        <div class="privacy-box"><b>قبل البدء</b><p>النسخة تحتوي بيانات حساسة. استخدم كلمة مرور طويلة واحفظها في مكان آمن؛ لا يمكن استعادتها عند نسيانها. لا تتم إضافة ملفات الصوت المؤقتة إلى النسخة.</p></div>
        <div class="form-grid two"><label>كلمة مرور النسخة الاحتياطية<input id="backupPassword" type="password" minlength="12" maxlength="256" autocomplete="new-password" placeholder="12 محرفًا على الأقل"></label><label>تأكيد كلمة المرور<input id="backupPasswordConfirm" type="password" minlength="12" maxlength="256" autocomplete="new-password" placeholder="أعد كتابة كلمة المرور"></label></div>
        <div class="action-bar"><button class="btn primary" id="createBackupBtn">إنشاء وتنزيل النسخة</button><button class="btn" id="chooseBackupFileBtn">اختيار ملف للاستعادة</button><input id="restoreBackupFile" type="file" accept=".cbotbackup,application/octet-stream" hidden><button class="btn" id="inspectBackupBtn" disabled>فحص النسخة أولًا</button><button class="btn danger" id="restoreBackupBtn" disabled>استعادة النسخة بعد الفحص</button></div>
        <p id="backupFileStatus" class="help" aria-live="polite">لم يتم اختيار ملف للاستعادة.</p><div id="backupInspectionResult" class="result-box" hidden aria-live="polite"></div><p class="help">الحد: 128 MB إجماليًا و64 MB للملف الواحد. افحص النسخة أولًا للتحقق من كلمة المرور وسلامة ملفات الجلسات وعدد الأشخاص والمجموعات والأرشيفات. لا تغيّر الملف أو كلمة المرور بعد الفحص. الاستعادة تستبدل البيانات الحالية بعد حفظ نقطة رجوع مشفرة، ثم يحاول النظام تشغيل الجلسات المستعادة. لا تغلق التطبيق أثناء العملية.</p>
      </article></section>`;
  }

  function pageTools() {
    return `<section class="page-title"><p class="eyebrow">TOOLS • LOCAL ENGINES</p><h1>المحركات الذكية</h1><p>واجهة للأدوات المحلية: تفريغ الصوت بنموذج Whisper، ونطق ردود البوت بصوت عربي محلي مع التدقيق، وقاموس المصطلحات وتحليل النص قبل أي تنفيذ. لا يُرفع الصوت أو النص إلى خدمة سحابية.</p></section>
      <section class="stats-grid tools-stats">
        <article class="stat-card"><span>ناقل الأحداث</span><b>Event Bus</b><small>أحداث داخلية بحدود للذاكرة والتزامن</small></article>
        <article class="stat-card"><span>محرك الأوامر</span><b>Command Engine</b><small>صلاحيات وتحقق من المدخلات</small></article>
        <article class="stat-card"><span>قاموس النصوص</span><b>Dictionary</b><small>تطبيع عربي وبحث تقريبي</small></article>
        <article class="stat-card"><span>الأوامر الصوتية</span><b>Voice Parser</b><small>تحليل النص المفرّغ فقط</small></article>
      </section>
      <section class="panel tools-grid operational-diagnostics-panel"><div class="panel-head"><div><h2>التشخيص التشغيلي الشامل</h2><p>فحص محلي للاتصال والتخزين والقواعد والصوت؛ يختبر القراءة والكتابة وإعادة قراءة المحتوى ومقارنته بملفات مؤقتة تُحذف بعد الفحص. لا يعرض المسارات أو محتوى الرسائل أو أرقام الهواتف أو رموز الربط.</p></div><span class="mini-tag">تقرير آمن للمشاركة</span></div><div class="action-bar"><button class="btn primary" type="button" id="refreshOperationalDiagnostics">تشغيل الفحص</button><button class="btn" type="button" id="copyOperationalDiagnostics" disabled>نسخ التقرير الآمن</button></div><div id="operationalDiagnosticsSummary" class="result-box" aria-live="polite">اضغط «تشغيل الفحص» لإعداد التقرير.</div><div id="operationalDiagnosticsChecks" class="architecture-grid" aria-live="polite"></div><details class="advanced-panel"><summary>عرض التقرير الفني بصيغة JSON</summary><textarea id="operationalDiagnosticsJson" rows="10" readonly dir="ltr" aria-label="التقرير الفني الآمن"></textarea><p class="help">تم حذف مسارات الملفات ومعرّفات المحادثات ومحتوى الرسائل وأسرار المصادقة من هذا التقرير.</p></details></section>
      <section class="content-grid two-col tools-grid">
        <article class="panel"><div class="panel-head"><div><h2>حالة البنية</h2><p>قراءة مباشرة من الخادم المحلي، وليست فحصًا خارجيًا.</p></div><button class="btn small" id="refreshArchitecture">تحديث الحالة</button></div><div id="architectureStatus" class="architecture-status"><div class="empty">اضغط «تحديث الحالة» لجلب حالة المحركات.</div></div><div class="privacy-box tools-note"><p><b>ملاحظة تشغيلية:</b> حفظ الجلسات الحالي محلي، ولا يعني أن تشغيل عدة نسخ أو ملايين الرسائل جاهز تلقائيًا.</p><p>التوسّع الإنتاجي يحتاج قاعدة بيانات دائمة، وطابور مهام موزّعًا، وقفل جدولة مشتركًا واختبارات تحميل.</p></div></article>
        <article class="panel"><div class="panel-head"><div><h2>تحليل أمر صوتي</h2><p>الصق ما قاله المستخدم أو النص الذي أخرجه محوّل الكلام إلى نص.</p></div><span class="mini-tag">لا يسجّل الميكروفون</span></div><label class="tools-label" for="voiceTranscript">النص المُفرّغ</label><textarea id="voiceTranscript" maxlength="1000" placeholder="مثال: الحالة أو مساعدة أو اكتم إشعارات المجموعة"></textarea><div class="form-grid two tools-fields"><label>الثقة (0–1)<input id="voiceConfidence" type="number" min="0" max="1" step="0.05" value="1"></label><label>اللغة<select id="voiceLocale"><option value="auto">اكتشاف تلقائي (مفضّل للغات المختلطة)</option><option value="ar">العربية</option><option value="en">English</option></select></label></div><div class="action-bar"><button class="btn primary" id="voiceParseBtn">تحليل النص</button><button class="btn" id="voiceClearBtn">مسح</button></div><div id="voiceParseResult" class="result-box" aria-live="polite">لم يتم تحليل أي نص بعد.</div><p class="help tools-footnote">النتيجة تفسير للنية فقط؛ لا يتم تنفيذ كتم أو حذف أو أي إجراء في واتساب من هذه الشاشة.</p></article>
      </section>
      <section class="content-grid two-col tools-grid transcription-grid">
        <article class="panel"><div class="panel-head"><div><h2>تفريغ الصوتيات إلى نص</h2><p>محرك Faster-Whisper يعمل محليًا عبر Python؛ يدعم صوتيات WhatsApp وصيغ OGG/OPUS وM4A وWAV.</p></div><span class="mini-tag">محلي / بلا سحابة</span></div><div id="transcriptionStatus" class="inline-status" aria-live="polite">جارٍ فحص إعداد Whisper…</div><details class="advanced-panel transcription-tuning"><summary>إعدادات النموذج ودقة التعرف</summary><div class="form-grid two tools-fields"><label>حجم نموذج التفريغ<select id="transcriptionModelSize"><option value="tiny">Tiny — تنزيل أخف</option><option value="base">Base</option><option value="small">Small — الافتراضي المتوازن</option><option value="medium">Medium — موارد أعلى</option><option value="large-v3">Large v3 — موارد مرتفعة</option><option value="large-v3-turbo">Large v3 Turbo — موارد مرتفعة</option></select></label><label>الجهاز<select id="transcriptionDevice"><option value="cpu">CPU — متوافق على نطاق أوسع</option><option value="auto">Auto — اختيار تلقائي</option></select></label><label>نوع الحساب<select id="transcriptionComputeType"><option value="int8">INT8 — الافتراضي للمعالج</option><option value="int8_float32">INT8 + FP32</option><option value="float32">FP32</option></select></label><label>دقة البحث Beam Size<input id="transcriptionBeamSize" type="number" min="1" max="10" step="1" value="5"></label><label>عتبة كشف الكلام VAD<input id="transcriptionVadThreshold" type="number" min="0.1" max="0.95" step="0.05" value="0.5"></label><label>أدنى صمت لتقسيم المقاطع (ms)<input id="transcriptionMinSilence" type="number" min="100" max="3000" step="50" value="450"></label><label>حد احتمال الكلمات (Log probability)<input id="transcriptionLogProb" type="number" min="-3" max="0" step="0.1" value="-1"></label><label>حد احتمال عدم الكلام (No speech)<input id="transcriptionNoSpeech" type="number" min="0.1" max="0.99" step="0.05" value="0.6"></label><label>حد التكرار (Compression ratio)<input id="transcriptionCompression" type="number" min="1" max="5" step="0.1" value="2.4"></label></div><div class="form-grid two tools-fields"><label class="check-row"><input id="transcriptionVad" type="checkbox" checked> تفعيل اكتشاف الكلام وتقليل الصمت</label><label class="check-row"><input id="transcriptionPreviousText" type="checkbox"> استخدام المقطع السابق كسياق (قد يقلل التكرار أو يزيده بحسب التسجيل)</label></div><div class="action-bar"><button class="btn primary" type="button" id="saveTranscriptionSettings">حفظ إعدادات التفريغ</button></div><p class="help">زيادة Beam Size قد تزيد زمن المعالجة والذاكرة. نوع الحسابات المعروضة متوافق مع CPU أو الاختيار التلقائي لتفادي خيارات FP16 غير المدعومة على بعض الأجهزة. تغيير حجم النموذج يحتاج إعادة تشغيل البوت؛ سينزل النموذج المختار تلقائيًا داخل مجلد المشروع عند بدء التشغيل التالي. المؤشر الظاهر لاحقًا تقدير إرشادي من بيانات Whisper وليس نسبة دقة مثبتة.</p></details><div class="form-grid two tools-fields"><label>لغة الصوت<select id="transcriptionLanguage"><option value="auto">اكتشاف تلقائي (مفضّل للغات المختلطة)</option><option value="ar">العربية</option><option value="en">English</option><option value="fr">Français</option><option value="de">Deutsch</option><option value="es">Español</option><option value="ur">اردو</option><option value="hi">हिन्दी</option><option value="tr">Türkçe</option></select></label><label>ملف صوتي<input id="transcriptionFile" type="file" accept="audio/*,.ogg,.opus,.mp3,.m4a,.mp4,.wav,.webm,.aac,.flac"></label></div><div class="action-bar"><button class="btn primary" id="transcribeUploadBtn" type="button">تفريغ الملف المحدد</button><button class="btn" id="transcribeLatestBtn" type="button">تفريغ آخر صوتية في WhatsApp</button></div><label class="tools-label" for="transcriptOutput">النص الناتج — قابل للتحديد والنسخ</label><textarea id="transcriptOutput" class="transcript-output" rows="8" readonly placeholder="سيظهر النص هنا بعد اكتمال التفريغ."></textarea><div id="transcriptQualityStatus" class="inline-status" aria-live="polite">ستظهر مؤشرات جودة التفريغ هنا بعد المعالجة.</div><div class="action-bar"><button class="btn" id="copyTranscriptBtn" type="button">نسخ النص</button><button class="btn" id="useTranscriptForCommandBtn" type="button">تحليل النص كأمر (من دون تنفيذ)</button></div><p class="help tools-footnote">لطلب التفريغ من محادثة النفس في WhatsApp اكتب: «فرّغ آخر صوتية». الأوامر الصوتية ذات التفريغ الضعيف أو غير الموثّق لا تُنفذ تلقائيًا؛ يعرض البوت النص للمراجعة ويطلب إرساله كتابةً. تُحفظ علامات التشكيل التي يتعرف عليها النموذج ولا نضيف تشكيلًا تخمينيًا قد يغيّر المعنى.</p></article>
        <article class="panel"><div class="panel-head"><div><h2>كيف تفعّل التفريغ المحلي؟</h2><p>في Windows لا تكتفِ بتفعيل الخيار: ثبّت المحرك والنموذج أولًا.</p></div></div><ol class="transcription-steps"><li><b>Windows:</b> أغلق التطبيق، وافتح مجلد المشروع، ثم شغّل <code>SETUP-VOICE-WINDOWS.bat</code>. سيُنشئ بيئة Python معزولة ويثبت Faster-Whisper وPiper وEdge TTS وFFmpeg، وينزّل نموذج التفريغ المحلي ثم يضبط <code>.env</code>.</li><li>المثبت يضمّن FFmpeg عبر imageio-ffmpeg ويختبر وجوده؛ وهو مطلوب لتحويل الصوت الناتج إلى OGG/Opus للإرسال. التفريغ عبر Faster-Whisper يستخدم PyAV ولا يتطلب FFmpeg خارجيًا عادةً.</li><li>أعد تشغيل Chat BOT، وافتح هذه الصفحة واضغط «فحص حالة التفريغ» وتأكد أن Python والحزمة والنموذج ظهرت جاهزة. لا تعتبر الصوت جاهزًا إلا بعد نجاح اختبار صوت حقيقي.</li><li><b>أنظمة أخرى:</b> اتبع <code>docs/VOICE_SETUP_AR.md</code> لتجهيز Python وFaster-Whisper يدويًا.</li></ol><button class="btn" id="refreshTranscriptionStatus" type="button">فحص حالة التفريغ</button><div class="privacy-box tools-note"><b>الخصوصية والحدود</b><p>بعد التنزيل الأول، تتم المعالجة محليًا وتُحذف الملفات المؤقتة. لم نضمّن نموذجًا ضخمًا داخل ZIP. إذا غاب المحرك أو النموذج أو FFmpeg فلن يعمل التفريغ الحقيقي، وسيُظهر البوت السبب بدل ادعاء النجاح.</p></div></article>
      </section>
      <section class="content-grid two-col tools-grid tts-grid">
        <article class="panel"><div class="panel-head"><div><h2>تحويل رد البوت إلى رسالة صوتية</h2><p>محرك Audar العربي التعبيري محليًا أولًا، مع ستة أصوات ووسوم انفعالية فعلية؛ Piper احتياطي وChatterbox اختياري.</p></div><span class="mini-tag">Audar-TTS / Piper</span></div><div id="ttsStatus" class="inline-status" aria-live="polite">جارٍ فحص محرك النطق…</div><div class="tts-readiness" id="ttsReadiness"><div class="empty">اضغط «فحص حالة النطق» لمعرفة المحركات المتاحة.</div></div><div class="action-bar"><button class="btn primary" id="refreshTtsStatus" type="button">فحص حالة النطق</button><button class="btn" id="testVoiceFourLanguagesBtn" type="button">اختبار 4 لغات فعليًا</button><button class="btn" data-go="guide" type="button">دليل الإعداد</button></div><div id="voiceFourLanguageTestResult" class="voice-roundtrip-results" aria-live="polite"><p class="help">الاختبار يشغّل دورة النطق ثم تحويل OGG/Opus ثم التفريغ لكل من العربية والإنجليزية والفرنسية والألمانية.</p></div><div class="privacy-box tools-note"><b>طريقة الاستخدام</b><p>في محادثة النفس على WhatsApp اكتب <code>انطق آخر رد</code>. سيحوّل البوت آخر نص محفوظ إلى رسالة صوتية، ولا يُشترط Ollama للنطق الأساسي؛ لن يُوقفه التدقيق إلا إذا فعّلت شرط التدقيق صراحةً في الإعدادات.</p><p>المفترض أن يجهز البوت Python والمكتبات والنموذج تلقائيًا عند أول تشغيل؛ لا تحتاج إلى تشغيل مثبت الصوت يدويًا. راقب حالة التهيئة في هذه الصفحة. أول تشغيل يحتاج الإنترنت ومساحة تخزين لتنزيل النموذج. جودة الصوت تعتمد أيضًا على النموذج واللهجة وصحة النص. محرك النطق يحسّن طريقة إلقاء النص ولا يضيف مفردات أو معرفة من عنده؛ تنوع صياغة الرد نفسه مصدره نموذج المحادثة. يمكن ضبط أسماء المصطلحات غير الدقيقة في «معجم النطق».</p></div></article>
        <article class="panel"><div class="panel-head"><div><h2>سياسة جودة النص المنطوق</h2><p>لا يتعامل البوت مع النطق كتحويل آلي أعمى.</p></div></div><ul class="update-list"><li>تُزال تنسيقات Markdown والروابط الصعبة القراءة قبل الصوت.</li><li>يُطلب من النموذج المحلي تدقيق الإملاء والنحو وعلامات الترقيم دون تلخيص أو إضافة معلومات.</li><li>تُفحص الأرقام والتواريخ والروابط المحمية؛ إذا غيّرها المدقق يُرفض النص المصحح ويُوقف إرسال الصوت عند اشتراط التدقيق.</li><li>يستخدم Audar-TTS محليًا أولًا، ويدمج وسوم التعبير مثل الفضول والحماس والهمس والضحك داخل النص المنطوق؛ وعند فشله يعود إلى Chatterbox الاختياري أو Piper العربي.</li><li>لا تُرسل رسالة صوتية إذا غاب محرك النطق أو النموذج أو فشل تجهيز OGG/Opus.</li></ul><div class="privacy-box"><b>ملاحظة مهمة</b><p>نجاح التدقيق الآلي ليس ضمانًا لغويًا مطلقًا؛ ولا يضمن تطابق نطق كل اسم علم أو اختصار مع النطق المقصود.</p></div></article>
      </section>
      <section class="content-grid two-col tools-grid">
        <article class="panel"><div class="panel-head"><div><h2>قاموس المصطلحات</h2><p>بحث عربي يدعم تطبيع الهمزات والتشكيل وبعض المطابقات التقريبية.</p></div><span class="mini-tag">محلي</span></div><form id="dictionaryForm" class="dictionary-form"><label class="tools-label" for="dictionaryQuery">كلمة أو مصطلح</label><div class="dictionary-search"><input id="dictionaryQuery" maxlength="160" placeholder="اكتب المصطلح المراد البحث عنه"><button class="btn primary" type="submit">بحث</button></div></form><div id="dictionaryResult" class="result-box" aria-live="polite">أدخل مصطلحًا لبدء البحث.</div><div id="dictionaryMeta" class="help">القاموس الحالي فارغ ما لم تُضَف له بيانات عبر التطبيق أو الخادم.</div></article>
        <article class="panel"><div class="panel-head"><div><h2>خريطة المحركات</h2><p>ترتيب الإضافات الجديدة داخل بنية واحدة.</p></div></div><div class="engine-list">
          <div class="engine-row"><span class="engine-icon">↔</span><div><b>Event Bus</b><small>تمرير أحداث الرسائل والأنشطة بين الوحدات.</small></div><span class="engine-tag">أحداث</span></div>
          <div class="engine-row"><span class="engine-icon">⌘</span><div><b>Command Engine</b><small>تسجيل الأوامر والتحقق من الصلاحيات والمدخلات.</small></div><span class="engine-tag">أوامر</span></div>
          <div class="engine-row"><span class="engine-icon">Aa</span><div><b>Dictionary Engine</b><small>توحيد النص العربي والبحث عن المصطلحات والمرادفات.</small></div><span class="engine-tag">نصوص</span></div>
          <div class="engine-row"><span class="engine-icon">◖</span><div><b>Voice-to-Command</b><small>تحويل النص المفرّغ إلى نية مفهومة مع عتبة ثقة.</small></div><span class="engine-tag">تحليل</span></div>
        </div></article>
      </section>`;
  }

  function pageGuide() {
    return `<section class="page-title"><p class="eyebrow">HELP • QUICK GUIDE</p><h1>الدليل والمساعدة</h1><p>دليل مختصر للبدء الآمن، إدارة الجلسات، الإرسال، الأتمتة، والميزات الجديدة. الواجهة محلية وتعرض حالة النظام عند طلب التحديث أو تنفيذ إجراء.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>ابدأ من هنا</h2><p>خطوات الاستخدام اليومية بالترتيب.</p></div></div><div class="guide-list">
          <div class="guide-card"><span class="guide-number">01</span><div><b>اربط الجلسة</b><p>افتح «الجلسة» واختر استعادة الجلسة أو QR أو رمز الهاتف؛ استخدم QR/رمز الهاتف في الربط الأول فقط، ثم تُستعاد الجلسة المحفوظة.</p></div></div>
          <div class="guide-card"><span class="guide-number">02</span><div><b>جهّز الأشخاص والمجموعات</b><p>أضف أرقامًا بصيغة دولية أو اكتشف المجموعات من الجلسة المتصلة، ثم راجع الأهداف قبل الإرسال.</p></div></div>
          <div class="guide-card"><span class="guide-number">03</span><div><b>جرّب قبل التنفيذ</b><p>ابدأ بهدف واحد، راجع السجل، ثم استخدم الجدولة أو قواعد التفاعل بعد التأكد من الإعدادات.</p></div></div>
          <div class="guide-card"><span class="guide-number">04</span><div><b>افحص المحركات الجديدة</b><p>من «المحركات الذكية» يمكنك فحص صحة البنية، تجربة البحث في القاموس، وتحليل نص أمر صوتي دون تنفيذه.</p></div></div>
        </div></article>
        <article class="panel"><div class="panel-head"><div><h2>الخصوصية وحدود التشغيل</h2><p>معلومات مهمة قبل الاعتماد على النظام.</p></div></div><div class="guide-callouts"><div class="privacy-box"><b>البيانات محلية</b><p>بيانات الجلسات والإعدادات والوسائط تُدار محليًا في المشروع. احمِ ملفات مجلد البيانات ولا تشاركها لأنها قد تحتوي على معلومات خاصة.</p></div><div class="privacy-box"><b>المعالجة المحلية هي الافتراضية</b><p>يمكن تفعيل Ollama وWhisper وPiper محليًا. توجد موصلات خارجية اختيارية للصوت، لكنها لا تعمل افتراضيًا؛ عند اختيارها صراحةً تُرسل الملفات أو النصوص إلى المزود المحدد، فراجع سياسة الخصوصية ولا تشارك مفاتيح الخدمة.</p></div><div class="privacy-box"><b>التوسع الإنتاجي يحتاج تجهيزًا إضافيًا</b><p>النسخة الحالية ليست بعدُ نظامًا موزعًا جاهزًا لملايين الرسائل. قبل التوسع يلزم تخزين دائم، طابور موزع، مراقبة، صلاحيات، نسخ احتياطية واختبارات تحميل.</p></div></div><div class="action-bar"><button class="btn primary" data-go="session">إدارة الجلسة</button><button class="btn" data-go="tools">فتح المحركات الذكية</button><button class="btn" data-go="settings">الإعدادات</button></div></article>
      </section>`;
  }

  function pageUpdates() {
    const releases = [
      { version: 'v9.20.25', title: 'تعزيز تنظيف الجلسات ومنع تعارض استعادة الأقفال', date: '31 أكتوبر 2026', state: 'إغلاق Chromium بعد AUTH_FAILURE، وحماية استعادة القفل اليتيم من سباق العمليات.', items: ['إبطال callbacks القديمة وإغلاق المتصفح بعد فشل المصادقة حتى لا يظل ملف LocalAuth محجوزًا.', 'منع عمليات الاستعادة المتزامنة من إزالة قفل جديد؛ بوابة الاستعادة تتوقف بأمان عند انقطاع العملية.', 'أرشفة ملف المصادقة القديم قبل الربط الجديد مع إبقاء بيانات المحادثات والإعدادات.', 'اختبارات auth_failure مع initialize معلّق وتنافس خمس عمليات على قفل يتيم. لم يُنفذ اختبار WhatsApp حي.'] },
      { version: 'v9.20.24', title: 'تقوية دورة حياة جلسة WhatsApp وقفل التشغيل المحلي', date: '31 أكتوبر 2026', state: 'قفل حصري لكل جلسة، فصل LOGOUT عن الانقطاع المؤقت، حفظ حالة إعادة المصادقة، وأرشفة ملف LocalAuth القديم عند الربط الجديد.', items: ['منع عمليتين من تشغيل ملف LocalAuth نفسه باستخدام قفل PID محلي ومراعاة PID متصفح Chromium.', 'عدم جدولة إعادة اتصال تلقائية بعد LOGOUT أو AUTH_FAILURE؛ إعادة الاتصال المحدودة مخصصة للانقطاعات المؤقتة.', 'حفظ حالة المصادقة المطلوبة بعد إعادة تشغيل البرنامج، وأرشفة ملف الجلسة المنتهي بدل حذفه عند بدء QR جديد.', 'اختبارات قفل حصري واستعادة قفل يتيم ومحاكاة detached Frame بعد LOGOUT.'] },
      { version: 'v9.20.23', title: 'Audar-TTS العربي التعبيري مع ستة أصوات', date: '31 أكتوبر 2026', state: 'Audar Turbo Q5 محليًا، تحميل تلقائي عند بدء التهيئة، تعبيرات أصلية داخل النص، وتدوير قوالب الرد الاحتياطية.', items: ['تجهيز GGUF وNeuCodec والأصوات الستة مرة واحدة عند بدء المشروع.', 'عامل Python دائم يختبر توليدًا عربيًا فعليًا قبل إعلان جاهزية الاستدلال.', 'اختيار صوت رجالي أو نسائي محلي، ووسوم curious وexcited وwhispers وlaughs وmischievously وsarcastic.', 'توسيع معجم النطق إلى 300 مدخل وتنويع قوالب الرد؛ الثراء المعرفي يحتاج تفعيل نموذج المحادثة المحلي. Chatterbox اختياري ولا يُنزّل تلقائيًا.'] },
      { version: 'v9.20.21', title: 'محرك صوت تعبيري محلي متعدد اللغات', date: '31 أكتوبر 2026', state: 'دمج Chatterbox Multilingual V3 محليًا، تنزيل تلقائي مرة واحدة، تعبير متغير لكل جملة، وPiper كخطة احتياطية عربية.', items: ['تثبيت Chatterbox داخل بيئة Python مستقلة كي لا تتعارض مكتبات PyTorch مع Whisper/Piper.', 'تنزيل أوزان النموذج الأساسية إلى models/chatterbox-multilingual-v3 مرة واحدة (نحو 3.2 جيجابايت) مع التحقق من اكتمال الملفات وتحميل النموذج قبل إعلان الجاهزية.', 'توليد كل جملة بأداء تعبيري يختلف حسب مؤشرات النص، مع منزلق شدة الانفعال وإعدادات الهدوء والحيوية والسرد والمرح والتعاطف.', 'إبقاء Piper العربي كخطة احتياطية محلية إذا فشل تحميل Chatterbox أو فشل التوليد؛ لا تُرسل النصوص إلى الإنترنت في الوضع المحلي.', 'إضافة تعليمات تنزيل يدوي للنموذج عند تعذر التنزيل التلقائي، وإصلاح تشخيص خطأ بدء عامل الصوت وتحديث قيمة منزلق التعبير مباشرة.'] },
      { version: 'v9.20.19', title: 'استكمال المرحلة السابعة — تحقق القراءة بعد الكتابة', date: '30 أكتوبر 2026 — الإصدار السابق', state: 'تشخيص قراءة/كتابة مع مقارنة بايتية، ومعالجة I/O الجزئي وحذف مؤقت حتى عند الفشل.', items: ['بعد الكتابة والإغلاق يعاد فتح الملف وقراءة كامل محتواه ومقارنته بالمحتوى الأصلي.', 'تستكمل عمليات القراءة والكتابة الجزئية مع منع الدوران عند تقدم صفري، ويُفصل فشل القراءة عن فشل الكتابة.', 'يستمر تنظيف الملف المؤقت في finally، ويُسجل فشل التنظيف بوضوح ضمن فشل الاختبار الآمن.'] },
      { version: 'v9.20.18', title: 'المرحلة السابعة — تشخيص أدق وفحص تخزين فعلي', date: '30 أكتوبر 2026 — الإصدار السابق', state: 'اختبار قراءة وكتابة وحذف حقيقي في مجلدات البيانات والجلسات والوسائط مع تقرير آمن.', items: ['ملفات تشخيص مؤقتة ذات أسماء عشوائية تُنشأ وتُحذف فورًا؛ لا تظهر المسارات أو الأسماء في التقرير.', 'تمييز مشاكل مجلد البيانات عن مجلد الجلسات ومكتبة الوسائط.', 'استمرار توليد التقرير عند تعطل تحميل الجلسة أو فحص خدمة فرعية، بدل فقدان كل النتائج.', 'تنقيح إصدار البرنامج وضبط تقدم الصوت ومنع التخزين المؤقت لمسار التشخيص القديم أيضًا.'] },
      { version: 'v9.20.17', title: 'المرحلة السادسة — تحسين موثوقية تحديث صور الجهات', date: '30 أكتوبر 2026 — إصدار سابق', state: 'التحديث الصريح يعيد جلب الصورة الأحدث حتى مع وجود كاش محلي، ويحافظ على الصورة السليمة عند فشل الشبكة.', items: ['عند غياب رابط الصورة المباشر من قائمة WhatsApp، يُعاد الاستعلام الفعلي بدل الاكتفاء بالصورة المخزنة.', 'استبدال الكاش بعد تنزيل صورة موثوقة، مع الإبقاء على الصورة القديمة السليمة عند الفشل.', 'اختبار انحدار يحاكي نجاح التحديث وفشل CDN دون حذف الصورة القديمة.', 'الحفاظ على حدود الهوية والجلسة والجهات المحفوظة والحد الأقصى 100 جهة.'] },
      { version: 'v9.20.16', title: 'المرحلة السادسة — إدارة الجهات وسجل المحادثات', date: '30 أكتوبر 2026', state: 'تحديث صور جهات WhatsApp المحددة بعملية فعلية محكومة بالهوية والجلسة، مع صور متجاوبة وأرشيف محفوظ.', items: ['زر تحديث الصور يعمل على الجهات المحددة والمحفوظه فقط، ويتحقق الخادم من JID والجهة الحية قبل التنزيل.', 'حد 100 جهة لكل دفعة ورفض الجهات غير المحفوظة أو المعرفات غير الرقمية.', 'صور جهات موحدة 44×44 على سطح المكتب و38×38 على الهاتف دون تشويه.', 'الحفاظ على استيراد سجل المحادثة وتنزيل المرفقات بعد التأكيد وإعادة التحقق من المستلم.'] },
      { version: 'v9.20.15', title: 'المرحلة الخامسة — جودة النطق والردود الصوتية الطويلة', date: '30 أكتوبر 2026 — الإصدار الحالي', state: 'مقاطع صوتية مرتبة بلا قص صامت، معجم نطق للأسماء والمصطلحات، معاينة قبل الإرسال، وفحص دعم التشكيل العربي في Piper.', items: ['إرسال الردود الطويلة في مقاطع متتابعة بدل اقتصاصها عند 1800 حرف؛ الحد الأقصى 1–10 مقاطع، وما يتجاوزه يبقى نصيًا دون حذف.', 'إعادة التحقق من المستلم وموافقة السحابة قبل كل مقطع؛ الإرسال الجزئي لا يعاد تلقائيًا لتجنب تكرار المقاطع التي وصلت.', 'إضافة معجم نطق محلي حتى 80 مدخلًا بصيغة الكلمة => النطق، مع بقاء النص الكتابي الأصلي كما هو.', 'معاينة صوت في لوحة التحكم دون إرسال إلى WhatsApp؛ تستخدم إعدادات الجلسة المحفوظة وموافقة الخدمات الخارجية نفسها.', 'إظهار إصدار Piper ودعم التشكيل العربي الآلي إذا أمكن التحقق منه في بيئة Python.'] },
      { version: 'v9.20.14', title: 'المرحلة الرابعة — جودة التفريغ وفحص ثقة النص', date: '30 أكتوبر 2026 — إصدار سابق', state: 'مقاييس Whisper حقيقية لكل تفريغ، حظر تنفيذ النص الملتبس، واختيار حجم النموذج وضبط البحث من اللوحة.', items: ['جمع لغة الصوت واحتمالها ومتوسط احتمالات المقاطع واحتمال الصمت والتكرار وعدد المقاطع الضعيفة.', 'تصنيف النص إلى واضح/مراجعة/ضعيف/غير موثق. النتيجة heuristic وليست نسبة صحة أو WER مُعايرة.', 'منع تشغيل الأوامر والردود والأتمتة من التفريغ الضعيف أو غير الموثق، مع حفظ النص للمراجعة وطلب تصحيحه كتابةً.', 'اختيار tiny/base/small/medium/large-v3/large-v3-turbo من لوحة التفريغ؛ تنزيل النموذج الجديد يبدأ تلقائيًا بعد إعادة تشغيل البوت.', 'إعداد Beam Size وVAD والعتبات والصمت والجهاز ونوع الحساب؛ والمثبت اليدوي يحافظ على الخيارات المحفوظة في .env.', 'استمرار حراسة توافق PyAV >=11 و<19 قبل إعلان الجاهزية.'] },
      { version: 'v9.20.13', title: 'المرحلة الثالثة — طابور الرسائل والاعتمادية', date: '30 أكتوبر 2026 — إصدار سابق', state: 'FIFO لكل جلسة، تجاهل الرسائل القديمة بعد أرشفتها، منع تكرار الأحداث، وجدولة متحفظة عند فشل أو غموض الإرسال.', items: ['الرسائل الواردة ورسائل محادثة النفس تمر في طابور محدود؛ يمنع التوازي داخل الجلسة مع السماح بتوازٍ مضبوط بين الجلسات.', 'الرسالة الأقدم من 300 ثانية افتراضيًا تُحفظ في الأرشيف ولا تشغّل قواعد أو أوامر ولا تنتج ردًا متأخرًا. يمكن تغيير العمر من إعدادات الموثوقية.', 'مهلة انتظار الطابور 60 ثانية وسعته 40 رسالة قيد المعالجة والانتظار لكل جلسة افتراضيًا؛ عند الامتلاء/انتهاء المهلة يُسجل السبب ولا تُحذف الرسالة من الأرشيف.', 'سجل حدث محفوظ داخل الجلسة يمنع إعادة معالجة المعرف نفسه بعد إعادة تشغيل التطبيق.', 'حجز موعد الجدولة قبل الإرسال؛ الفشل الآمن المعروف فقط يعاد، أما الإرسال الجزئي أو SEND_UNCERTAIN فلا يعاد تلقائيًا لمنع التكرار.', 'حماية رسالة الترحيب من الإرسال المكرر بعد تعطل التطبيق، وقفل مجدول واحد لكل جلسة.', 'تصحيح حدود منتصف الليل والتوقيت الصيفي، وإصلاح وضع القواعد فقط خلال ساعات الهدوء.'] },
      { version: 'v9.20.12', title: 'المرحلة الثانية — عزل المحادثات وفرض صلاحيات الجهات', date: '30 أكتوبر 2026 — إصدار سابق', state: 'قائمة سماح مركزية لكل محادثة، منع الجهات غير المسجلة أو الموقوفة من التفاعل والإرسال والوسائط، وفصل ذاكرة المالك عند تبديل حساب WhatsApp.', items: ['فحص الرسائل الواردة قبل الأرشفة والتفريغ والأتمتة والردود وأوامر المجموعات؛ الرسائل من جهات غير مسجلة أو موقوفة لا تدخل أي مسار معالجة.', 'توحيد حارس الإرسال في WhatsApp للنصوص والوسائط والصوت والردود والتفاعلات وإجراءات المحادثة؛ لا يقبل إلا محادثة النفس أو شخصًا/مجموعة مسجلين ومفعّلين.', 'قصر أهداف الأتمتة والجدولة والإرسال من مساعد المالك على الجهات المسجلة؛ أوامر الإرسال ترفض الأرقام الحرة ما لم تطابق جهة واحدة مفعّلة. حذف الجهة ينظف القواعد والكتم والعدادات والسياق.', 'تنظيف سياق المساعد وتدفقاته والرد الخاص والأوامر المعلقة عند تغير حساب WhatsApp المرتبط.', 'دعم ربط LID برقم الهاتف عبر واجهة WhatsApp الرسمية في المسارات المباشرة والمجدولة، ورفض تخمين الرقم من أرقام LID أو استخدام ربط متعارض.', 'يبقى الأرشيف السابق قابلًا للعرض للجهة الموقوفة؛ لا تُضاف رسائل جديدة ولا تُنزّل مرفقاتها حتى إعادة التفعيل.'] },
      { version: 'v9.20.11', title: 'المرحلة الأولى — أساس صوت محلي وخصوصية خارجية صريحة', date: '30 أكتوبر 2026 — إصدار سابق', state: 'توحيد اعتماديات Python، جعل النطق المحلي هو الافتراضي، ومنع أي إرسال صوتي خارجي دون موافقة الجلسة.', items: ['توحيد متطلبات الصوت في scripts/voice-requirements.txt واستخدام الملف نفسه من التهيئة التلقائية ومثبت Windows اليدوي، بما يشمل av>=11,<19.', 'إصلاح الترحيل الذي كان يحول اختيار local المحفوظ إلى auto، وتعيين local كافتراضي آمن في الإعدادات وملف .env والواجهة.', 'إضافة موافقة سحابية صريحة لكل جلسة؛ auto يعمل محليًا أولًا، والخدمات الخارجية تُحظر بلا موافقة، مع إعادة فحص الموافقة قبل إرسال الصوت بعد التوليد.', 'تصحيح حالة الجاهزية للغات غير العربية حتى لا يعلن Piper العربي جاهزًا لصوت إنجليزي أو فرنسي أو ألماني.'] },
      { version: 'v9.20.10', title: 'إصلاح توافق Whisper وPyAV وفحص مسار الربط', date: '30 أكتوبر 2026 — إصدار سابق', state: 'تثبيت PyAV متوافق والتحقق من إصدار المكتبة قبل إعلان جاهزية التفريغ المحلي.', items: ['يُثبت PyAV بإصدار >=11 و<19 لتجنب TypeError metadata_errors الذي يظهر مع Faster-Whisper الحالي وPyAV 19.', 'إذا كانت مكتبات الصوت موجودة لكن إصدار PyAV غير متوافق، يعيد المثبّت تجهيز الاعتماديات ولا يعتبر المحرك جاهزًا.', 'QR هو المسار الافتراضي، ورمز الهاتف بديل يعتمد على حدث pairing code الحقيقي؛ الاختبارات المحلية تتحقق من توصيل المسارين لكن لا تقيس اتصال WhatsApp حيًا.'] },
      { version: 'v9.20.9', title: 'إصلاح اختبار الصوت العربي وترميز Windows', date: '29 أكتوبر 2026', state: 'فرض UTF-8 عند تمرير النص العربي إلى Piper، وتحسين تشخيص الخطأ ومنع تكرار تقدم التنزيل.', items: ['فرض PYTHONUTF8 وPYTHONIOENCODING على عامل الصوت وعملية Piper حتى لا يعتمد النص العربي على ترميز نظام Windows.', 'تبسيط عبارة اختبار Piper وحفظ بداية ونهاية سجل الخطأ حتى يظهر السبب الجذري بدل موجز إغلاق WAV فقط.', 'تحديثات تقدم التنزيل تظهر فقط عندما يتغير عدد الميجابايت المكتملة. يلزم اختبار التشغيل الفعلي على جهاز Windows لتأكيد النتيجة.'] },
      { version: 'v9.20.8', title: 'مراجعة الاعتمادية الشاملة وإصلاح الذاكرة وإعداد الصوت', date: '29 أكتوبر 2026 — إصدار سابق', state: 'تقليل استهلاك الذاكرة أثناء بصمات الملفات، والحفاظ على محرك النطق الذي اختاره المستخدم، وتوسيع اختبارات الانحدار.', items: ['إصلاح قراءة الملفات الكبيرة على دفعات ثابتة عند حساب SHA-256 بدل تحميل الملف كاملًا إلى الذاكرة.', 'إصلاح التهيئة الصوتية كي تحافظ على اختيار محرك النطق local أو edge-tts أو openai-compatible أو auto بدل فرض auto على الخيارات الأخرى.', 'إضافة اختبارات انحدار لخيارات محرك الصوت وبصمات الملفات، وإعادة فحص بنية المشروع واعتمادياته.'] },
      { version: 'v9.20.7', title: 'المرحلة السابعة: التشخيص التشغيلي والتقارير الآمنة', date: '29 أكتوبر 2026', state: 'تقرير تشغيل موحد ومقروء، توصيات قابلة للتنفيذ، ومنع إظهار الأسرار في التقرير', items: ['إضافة فحص منظم لحالة Node.js والتخزين المحلي والجلسة واتصال WhatsApp وبيانات الربط ومحركات الصوت والجهات والقواعد والصيانة.', 'تصنيف النتائج إلى جاهز وتحذير ومشكلة ومعلومة مع اقتراح معالجة واضح بدل إظهار قيمة اتصال مبهمة.', 'إتاحة نسخ تقرير JSON آمن من الواجهة لمشاركته عند طلب الدعم؛ التقرير لا يحتوي محتوى الرسائل أو أرقام الهواتف أو معرّفات المحادثات أو رموز الربط أو المسارات المحلية.', 'الحفاظ على endpoint التشخيص القديم للتوافق وإضافة مسار تقرير جديد مع ترويسات منع التخزين المؤقت وحماية لوحة التحكم الحالية.', 'تأكيد أن التقرير لا يثبت تسليم WhatsApp حيًا أو نجاح تفريغ صوت فعلي؛ تلك الاختبارات تحتاج حسابًا ومحركات حقيقية.'] },
      { version: 'v9.20.6', title: 'المرحلة السادسة: استرجاع المحادثات والجهات', date: '29 أكتوبر 2026 — إصدار سابق', state: 'ترقيم صفحات ثابت للأرشيف، تحقق من الجهة بعد جلب التاريخ، ومزامنة جهات لا تستبدل التغييرات المتزامنة', items: ['مؤشر صفحات مركب يضمن عدم إسقاط الرسائل عند تساوي الطوابع الزمنية، مع الإبقاء على توافق المؤشر الرقمي القديم.', 'تأكيد استيراد تاريخ WhatsApp من جهة الخادم، وإعادة التحقق من تسجيل الجهة وتفعيلها قبل حفظ الرسائل.', 'تقسيم قائمة جهات WhatsApp إلى صفحات قابلة للبحث، واختيار العناصر الظاهرة فقط في الصفحة الحالية.', 'قراءة حالة الجلسة الحديثة بعد انتظار الصور والشبكة حتى لا تمحو المزامنة تغييرات المستخدم المتزامنة.', 'الصور الخاصة أو تاريخ WhatsApp غير المتاح لا يُقدمان على أنهما مسترجعان؛ ولا يجري تخمين أرقام من معرّفات LID.'] },
      { version: 'v9.20.5', title: 'المرحلة الخامسة: موثوقية القواعد والأوامر', date: '29 أكتوبر 2026 — إصدار سابق', state: 'منع التكرار بعد إعادة التشغيل، وإعادة المحاولة بعد فشل القاعدة، وحواجز الحذف، وتحليل الأوامر بأمان', items: ['حفظ بصمات أحداث الأتمتة لمنع احتساب الحدث نفسه مرة ثانية بعد إعادة تشغيل الخادم.', 'عدم استهلاك عتبة عداد الرسائل أو تفعيل التهدئة إلا بعد نجاح الإجراء.', 'فصل حذف رسالة محددة عن التنظيف الجماعي للرسائل القديمة، ومنع التحول الخاطئ بينهما.', 'رفض أنماط Regex الطويلة أو ذات مؤشرات التراجع المكلف، والتحقق من التاريخ التقويمي الحقيقي.', 'تحسين تحليل الأمر ذي الاقتباسات، ورفض الاقتباس غير المكتمل، وعزل سجل التدقيق عن التنفيذ.'] },
      { version: 'v9.20.4', title: 'المرحلة الرابعة: استعادة موثوقة للمحادثات والبيانات', date: '29 أكتوبر 2026', state: 'فحص النسخ قبل الاستبدال، والتحقق من إعدادات الجلسات، وتنظيف مراجع WhatsApp', items: ['فحص نسخة مشفرة دون تعديل البيانات الحالية قبل السماح بزر الاستعادة.', 'عرض عدد الجلسات والأشخاص والمجموعات وأرشيفات المحادثات والوسائط الموجودة داخل النسخة.', 'رفض النسخ التي تحتوي إعداد جلسة تالفًا أو معرّف جلسة متعارضًا قبل استبدال البيانات.', 'تنظيف مراجع الحالة عند حذف جهة تستخدم معرف WhatsApp محفوظًا بدل رقم الهاتف.', 'الحفاظ على أرشيف المحادثات محليًا ونقطة رجوع مشفرة قبل الاستعادة.', 'إعادة ربط الأرشيف غير المرتبط فقط بعد مطابقة معرف WhatsApp نفسه، دون تخمين هوية المستلم.'] },
      { version: 'v9.20.3', title: 'المرحلة الثالثة: مكتبة الملفات والإرسال المنظّم', date: '29 أكتوبر 2026 — إصدار سابق', state: 'بحث وتصفية ومعاينة واختيار صريح للملفات؛ حوار إرسال محفوظ إلى مستلم مسجل مع تأكيد آمن', items: ['بحث سريع باسم الملف وتصنيف الصور والفيديو والصوت والمستندات، وترتيب حسب الاسم والحجم والتاريخ.', 'الملفات غير محددة افتراضيًا؛ رفع الملف لا يضيفه تلقائيًا إلى الإرسال.', 'تحديد العناصر الظاهرة فقط، وعرض سبب رفض الملفات المرفوضة أو المكررة.', 'إرسال من محادثة النفس: اختر ملفًا بالاسم/الرقم، ثم مستلمًا مسجلًا، ثم راجع التفاصيل وأكد الإرسال حرفيًا.', 'إعادة التحقق من وجود الملف وفعالية المستلم قبيل الإرسال، مع الحفاظ على إصلاحات v9.20.1 والصوت v9.20.2.'] },
      { version: 'v9.20.2', title: 'المرحلة الثانية: الصوت من البداية إلى النهاية', date: '29 أكتوبر 2026 — إصدار سابق', state: 'اختبارات وحدات ومحاكاة محلية؛ يلزم نموذج صوت وFFmpeg وWhatsApp حي لتأكيد الدورة الكاملة', items: [
        'إضافة اكتشاف تلقائي للغة التفريغ مع الإبقاء على الاختيار اليدوي للعربية والإنجليزية والفرنسية والألمانية.',
        'تسلسل التفريغ الصوتي في طابور محدود لحماية الذاكرة ومنع تشغيل تحميل نموذج Whisper بالتوازي.',
        'منع معالجة الرسالة الصوتية نفسها مرتين عند تزامن أحداث WhatsApp، مع تخزين مؤقت محدود للنتيجة.',
        'رفض إرسال ملفات صوت غير مؤكدة كـ OGG/Opus عبر التحقق من OggS وOpusHead قبل الإرسال وبعد التحويل.',
        'اختبار اللغات الأربع يتحقق من اللغة المكتشفة واسترجاع الكلمات؛ لا يعدّ أي نص عشوائي نجاحًا.',
        'إصلاحات المرحلة الأولى للاتصال والإغلاق محفوظة. لم يتم اعتماد الصوت الحي أو تسليم الرسالة على حساب WhatsApp حقيقي في بيئة البناء.'
      ] },
      { version: 'v9.20.1', title: 'المرحلة الأولى: موثوقية الاتصال ودورة التشغيل', date: '29 أكتوبر 2026 — إصدار سابق', state: 'اختبارات انحدار محلية؛ يلزم اختبار WhatsApp حي قبل الاعتماد النهائي', items: [
        'الاحتفاظ بمرجع متصفح WhatsApp إذا فشل إغلاقه، ومنع إنشاء Client ثانٍ على ملف LocalAuth نفسه حتى نجاح التنظيف.',
        'إعادة محاولة التنظيف قبل إعادة الاتصال، مع منع طلبات Connect المتزامنة من بدء متصفحات متنافسة.',
        'إيقاف آمن وإلغاء ربط يحافظ على بيانات المصادقة إذا تعذر التحقق من إغلاق Chromium.',
        'فحص صحة يعرض حالة HTTP وWhatsApp ومحرك الصوت كلًا على حدة، من دون كشف QR أو رمز الاقتران أو بيانات الحساب.',
        'إغلاق منظم للخادم ومركز التكاملات والمجدول وجلسات WhatsApp عند SIGINT/SIGTERM، مع مهلة قصوى وتحرير قفل التشغيل.',
        'اختبارات انحدار جديدة لحالات فشل التنظيف وحماية بيانات الربط. نجاح الاختبارات المحلية لا يثبت اتصالًا حيًا أو جودة الصوت الفعلية.'
      ] },
      { version: 'v9.20.0', title: 'صوت تلقائي متعدد اللغات واختبار دورة كاملة', date: '28 أكتوبر 2026 — إصدار سابق', state: 'تهيئة داخلية تلقائية؛ اختبار مستقل لكل لغة', items: [
        'بدء إعداد Python والمكتبات والنماذج تلقائيًا عند تشغيل الخادم؛ إعادة المحاولة تلقائيًا عند فشل عابر، ولا حاجة إلى تشغيل ملف BAT يدويًا في الاستخدام المعتاد.',
        'ترحيل جلسات v9.18/v9.19 القديمة من وضع Piper فقط/تعطيل الرد الصوتي إلى الوضع التلقائي بعد تحديث مخطط الجلسة.',
        'اختبار فعلي مستقل للعربية والإنجليزية والفرنسية والألمانية: نطق ثم OGG/Opus ثم تفريغ محلي، مع نتيجة منفصلة لكل لغة.' ,
        'استبدال مسار التفريغ الموصى به بـ Faster-Whisper Python مع نموذج محلي متعدد اللغات؛ يدعم OGG/OPUS عبر PyAV بعد تنزيل النموذج.',
        'إضافة Edge TTS الاختياري بـ 32 صوتًا عربيًا إقليميًا، وسرعة ونبرة ومستوى صوت وستة أساليب أداء، مع إعلان إرسال النص إلى الإنترنت في هذا الوضع.',
        'إلغاء إلزام Ollama من النطق الأساسي، وتوحيد أدوات الإعداد القديمة حتى لا تعيد ضبط المحرك إلى whisper.cpp.',
        'الاختبارات الآلية تحاكي Python وFFmpeg؛ لا تعتبر الصوت متعدد اللغات جاهزًا إلا بعد نجاح زر اختبار اللغات الأربع على الجهاز.'
      ] },
      { version: 'v9.16.8', title: 'تصحيح تتبع الصوت والملصقات في محادثة النفس', date: '27 أكتوبر 2026 — إصدار سابق', state: 'اختبارات محلية؛ يلزم التحقق الحي على جهاز WhatsApp', items: [
        'تصحيح تتبع الإرسال البرمجي للصوتيات والملصقات التي لا تحتوي على نص رسالة عادي؛ لا تُعامل كأوامر جديدة من صاحب الحساب داخل محادثة النفس.',
        'إضافة اختبار انحدار مباشر لتأكيد أن أحداث رسالة صوتية أو ملصق صادرة من البوت تُطابق نية الوسائط وتُستهلك مرة واحدة.',
        'الحفاظ على تنزيل المرفقات المؤكد، ومكتبة الوسائط، وتحويل الصور إلى ملصقات من v9.16.7، وعلى ضوابط الصوت وإيقاف المستلمين من الدفعات السابقة.',
        'التحقق محلي فقط؛ لم يتم اختبار حساب WhatsApp حي أو مزود صوت خارجي في بيئة البناء.'
      ] },
      { version: 'v9.16.7', title: 'إدارة الوسائط وتأكيد الإرسال والربط', date: '27 أكتوبر 2026 — إصدار سابق', state: 'اختبارات محلية؛ يلزم التحقق الحي على جهاز WhatsApp', items: [
        'إضافة تنزيل مرفقات المحادثة من الواجهة مع اختيار النوع والحدود، وتأكيد صريح قبل التنزيل وإعادة التحقق من الجهة المسجلة.',
        'إضافة فحص على الخادم يمنع إرسال الملفات عبر API دون علامة تأكيد صريحة من واجهة الإرسال، مع عرض قائمة الملفات والأهداف قبل المتابعة.',
        'تطبيق حد حجم الملف من الإعدادات أثناء الرفع نفسه، لضمان أن الملفات المقبولة ستظل ظاهرة في مكتبة الوسائط.',
        'الحفاظ على مركز واحد للتكاملات والمواقع والخدمات وعلى قواعد متوقفة افتراضيًا حتى تفعيلها يدويًا.',
        'لم يتم اختبار جلسة WhatsApp حية أو تنزيل ملفات حقيقية في بيئة الإصدار؛ يُجرى ذلك محليًا بعد الربط.'
      ] },
      { version: 'v9.16.6', title: 'الردود الصوتية الاختيارية ومحركات الصوت', date: '27 أكتوبر 2026 — إصدار سابق', state: 'اختبارات محلية؛ يلزم التحقق الحي على جهاز WhatsApp', items: [
        'إصلاح مستمع message_create نفسه لاستخدام فاحص fromMe المشترك، حتى لا تُسقط الرسالة التي تشير إلى الإرسال في معرّفها المتسلسل true_ أو 1_.',
        'إضافة اختبار رجوع يثبت أن معرّف الرسالة المتسلسل يمرّ عبر مستمع WhatsApp إلى مسار مساعد محادثة النفس.',
        'إصلاح فحص مسارات Piper ليحسب المسار المتوقع حسب نظام التشغيل الجاري، بدل توقع مسار Linux على Windows.',
        'توحيد كشف الرسائل الصادرة حتى إذا غابت fromMe عن الغلاف وبقيت في معرّف الرسالة المتسلسل true_ أو 1_.',
        'إظهار سبب تجاهل رسالة صادرة غير مؤكدة كمحادثة نفس في سجل التشخيص دون الرد على جهات أخرى.',
        'تحسين كشف محادثة النفس عندما يعرض WhatsApp معرّف LID بدل @c.us، وحفظ معرّف المحادثة الفعلي بعد التحقق حتى تذهب الردود إلى المكان الصحيح.',
        'إضافة فحص لعلامات محادثة النفس واسمها مع رفض اعتبار كل الرسائل الصادرة محادثة نفس، لمنع الرد على رسائل الآخرين.',
        'تحسين إعداد Whisper على Windows ودعم أسماء حزم CPU الرسمية، والتحقق من تشغيل whisper-cli.exe بعد فك الضغط.',
        'تجاهل مسار محرك أو نموذج Whisper قديم مفقود عند وجود محرك/نموذج محلي صالح؛ النموذج متعدد اللغات small هو الخيار الافتراضي.',
        'إضافة مثبّت صوت موحّد يفحص Whisper وPiper وOllama المحلي، ويعرض تثبيت Python 3.12 ونموذج التدقيق المحلي بموافقة المستخدم.',
        'توحيد تصنيف الرسائل الصادرة في توجيه الردود واستخراج معرف الدردشة وأرشفة/استيراد المحادثات، بما في ذلك معرّفات true_ و1_.',
        'كل التفريغ والتحويل الصوتي والتدقيق المدعوم عبر Ollama المحلي يجري على الجهاز بعد تنزيل المكوّنات؛ يلزم FFmpeg لتحويل معظم فويسات WhatsApp OGG/OPUS، ولم يُدّعَ اختبار صوت حي في بيئة البناء.'
      ] },
      { version: 'v9.16.3', title: 'تقوية توجيه محادثة النفس وتشخيص تجاهل الرسائل', date: '26 أكتوبر 2026 — إصدار سابق', state: 'تحسين توجيه LID والصوت المحلي؛ يلزم اختبار حي', items: [
        'توحيد كشف الرسائل الصادرة في وحدة مستقلة مشتركة بين معالج WhatsApp ومسار محادثة النفس.',
        'إظهار سبب تجاهل رسالة صادرة غير مؤكدة كمحادثة نفس في سجل التشخيص دون الرد على جهات أخرى.',
        'تحسين كشف محادثة النفس عندما يعرض WhatsApp معرّف LID بدل @c.us، وحفظ معرّف المحادثة الفعلي بعد التحقق حتى تذهب الردود إلى المكان الصحيح.',
        'تحسين إعداد Whisper على Windows ودعم أسماء حزم CPU الرسمية، والتحقق من تشغيل whisper-cli.exe بعد فك الضغط.',
        'اختيار نموذج Whisper multilingual small افتراضيًا لتحسين دقة العربية، وتجاهل مسار نموذج قديم مفقود عند وجود نموذج محلي صالح.',
        'كل التفريغ والتحويل الصوتي محلي. يلزم تثبيت FFmpeg لتحويل معظم فويسات WhatsApp OGG/OPUS؛ لم يتم ادعاء اختبار صوت حي في بيئة البناء.'
      ] },
      { version: 'v9.16.1', title: 'إصلاح اختبار مسارات Windows ودمج طبقة التوافق', date: '25 أكتوبر 2026 — إصدار سابق', state: 'إصلاح مسارات الاختبار وتضمين رقعة WhatsApp', items: [
        'إصلاح اختبار محرك النطق الذي كان يفشل على Windows بسبب توقع مسار Linux ثابت؛ القيمة المتوقعة أصبحت تُحسب حسب نظام التشغيل.',
        'إضافة اختبار لمسارات Windows المطلقة وتضمين src/compat.js المحدثة داخل الحزمة.',
        'تشغيل فحص صارم يمنع بدء البوت إذا تم تخطي اختبار بسبب اعتماد ناقص.'
      ] },
      { version: 'v9.16.0', title: 'أربع إضافات: استدعاء المحادثات، تشخيص القواعد، اختبار الصوت، وصحة التكاملات', date: '25 أكتوبر 2026 — إصدار سابق', state: 'اختبارات وحدات ومحاكاة؛ الربط والصوت الحي يحتاجان تجربة فعلية على جهاز المستخدم', items: [
        'من محادثة النفس: «هات آخر 10 رسائل من أحمد» أو «ابحث في محادثة أحمد عن فاتورة». الاسترجاع يقتصر على جهة مسجلة، ويعيد رفض الاسم الملتبس/غير المسجل، ويقرأ من WhatsApp المتاح والأرشيف المحلي دون إرسال شيء إلى الهدف.',
        'بحث الأرشيف المقيّد بالجهة أصبح يفلتر قبل تطبيق حد النتائج، حتى لا تطغى نتائج جهة أخرى على المحادثة المختارة.',
        'تشخيص قراءة فقط لقواعد التفاعل: «شخّص الرد التلقائي على: السلام عليكم» أو «ليه البوت مش بيرد على: صباح الخير». يعرض أسباب عدم التنفيذ المحتملة دون إرسال رسالة أو تعديل قاعدة.',
        '«فحص النطق» يعرض حالة Piper ونموذج العربية وFFmpeg والتدقيق المحلي، و«اختبر النطق» يرسل عينة عربية إلى محادثة النفس فقط. لا يُرسل صوت غير مدقق إذا كان التدقيق إلزاميًا.',
        'صفحة التكاملات تعرض «تشخيص المركز بنظرة واحدة»: فحوصات غائبة أو قديمة، أجهزة غير متصلة، قواعد غير مدعومة، وتشغيلات/مهام فاشلة اعتمادًا على السجل المحلي دون كشف الأسرار أو الاتصال بالأهداف.',
        'تشديد عمليات تنزيل المرفقات ومزامنة جهات WhatsApp: «تمام» وحدها لم تعد تؤكد العمليات؛ يلزم «تأكيد التنزيل» أو «تأكيد المزامنة» صراحةً.',
        'تشغيل الاختبارات بعد استخراج ZIP مطلوب. لا يُدّعى اختبار WhatsApp حي أو جودة صوت عربية فعلية هنا؛ ويمكن أن يبقى اختبار HTTP متخطّيًا إذا لم تتوفر Express.'
      ] },
      { version: 'v9.15.0', title: 'أرشيف المحادثات، النطق العربي، نطاق الاسترجاع، وجودة الردود', date: '25 أكتوبر 2026 — إصدار سابق', state: 'تنفيذ محلي مع حدود موثقة', items: [
        'إضافة صفحة أرشيف مستقلة للرسائل الجديدة والمستوردة حسب محادثة النفس وكل شخص/مجموعة مسجلة، مع بحث وصفحات زمنية واستيراد محدد حتى 1000 رسالة في المرة. لا يضمن التطبيق إتاحة كامل تاريخ WhatsApp القديم.',
        'إضافة رسالة صوتية لآخر رد: أمر «انطق آخر رد»، Piper بنموذج عربي محلي وتحويل OGG/Opus عبر FFmpeg؛ شرط التدقيق اللغوي المحلي يمنع إرسال الصوت إذا لم ينجح التدقيق ما لم يُعطّل الخيار صراحة.',
        'تقييد استرجاع الرسائل والمرفقات بالأشخاص والمجموعات المسجلة في المشروع؛ رفض المحادثات غير المسجلة وإعادة التحقق من الجهة قبل تنزيل المرفقات.',
        'إضافة بوابة جودة لردود القواعد الشخصية والعادية ورد فترة الهدوء لمنع الرد الفارغ أو المتغيرات غير المستبدلة أو القيم البرمجية المسربة.',
        'حدود التحقق: لا يوجد اتصال WhatsApp حي في بيئة البناء؛ يجب إعداد Piper/FFmpeg/Ollama والنموذج المحلي على جهاز المستخدم، ثم اختبار النطق العربي والرسائل الحقيقية. اختبار HTTP يعتمد على توفر Express.'
      ] },
      { version: 'v9.13.0', title: 'أوامر قواعد عربية ثابتة وإصلاح توافق WhatsApp والصوت المحلي', date: 'إصدار سابق — 25 أكتوبر 2026', state: 'اختبارات قواعد وcompat والوحدات المحلية ناجحة؛ الربط الحي والصوت العربي الحقيقي لم يُختبرا هنا', items: ['قالب ثابت لقواعد الشات يقرأ اسم القاعدة وشرطها ونوع المطابقة والرد والنطاق والتهدئة، ويعرض الملخص قبل الحفظ. لا يحفظ قبل «تأكيد القاعدة».', 'دليل «مساعدة القواعد» يوضح الصيغة والمتغيرات ويقبل القالب متعدد الأسطر أو المختصر؛ الحقول غير المعروفة أو القيم غير الصالحة تُرفض.', 'إضافة إعداد Windows لمحرك whisper.cpp والنموذج محليًا، وتنبيه عند غياب FFmpeg أو النموذج بدل الإيحاء بأن الصوت جاهز. الملفات الكبيرة لا تدخل في ZIP.', 'تقوية رقعة whatsapp-web.js 1.34.7 لدعم _serialized/$1، وعزل المحادثة المتعطلة، وحماية بيانات المجموعات من فشل مؤقت، ومنع سباق exposeFunction أثناء إعادة الحقن.', 'توضيح الربط: QR افتراضي ورمز الهاتف بديل، مع الحفاظ على الجلسة عند تغيير الطريقة. يجب تجربة الربط والصوت الحي بعد تثبيت الاعتماديات على الجهاز.'] },
      { version: 'v9.12.3', title: 'فحص شامل للاعتماديات وإظهار الاختبارات المتخطاة بوضوح', date: 'إصدار سابق — 25 أكتوبر 2026', state: 'اختبارات محلية ديناميكية؛ الاختبارات التي تحتاج اعتماديات تُعرض كمتخطاة ولا تُحتسب نجاحًا كاملًا', items: ['إصلاح مشغّل Windows/Python: كان يتحقق من وجود نسختي whatsapp-web.js وPuppeteer فقط، وقد لا يكتشف غياب Express أو Multer أو QR أو مكتبات أخرى؛ أصبح يفحص جميع الاعتماديات المباشرة وفق package.json وملف القفل قبل بدء الخادم.', 'تحويل التحقق إلى اكتشاف ديناميكي لكل ملفات JavaScript والاختبارات، حتى لا تُنسى الملفات الجديدة في قائمة ثابتة طويلة.', 'إظهار حالات PASS وPARTIAL وFAIL وعدد الاختبارات المتخطاة، وإضافة npm run test:strict لرفض أي تخطٍّ بسبب اعتماد مفقود.', 'إضافة اختبار للـlauncher يغطي الاعتماديات المفقودة، الأسماء ذات النطاق مثل @scope/package، وإصدارًا مختلفًا عن ملف القفل.', 'حماية لوحة الإدارة بتسجيل دخول عند الاستماع على عنوان شبكة؛ تتطلب كلمة مرور قوية، مع إبقاء مسارات الوكيل وWebhook محددة وتحت مصادقة رموزها الخاصة.', 'إضافة نسخ احتياطي واستعادة من الواجهة بأرشيف AES-256-GCM وكلمة مرور، مع التحقق من المسارات والملف وحفظ نسخة رجوع مشفرة قبل الاستبدال (حد 128 MB من البيانات).', 'لا يثبت فحص الوحدة اتصال WhatsApp حيًا؛ اختبار HTTP سيظهر متخطّيًا إذا لم تكن Express مثبتة، بدل تمرير ذلك على أنه نجاح.'] },
      { version: 'v9.12.2', title: 'مركز التكاملات المحلي، ربط الأجهزة، الإضافات، وإصلاح الربط عبر الهاتف', date: '25 أكتوبر 2026 — إصدار سابق', state: 'اختبارات محلية ناجحة؛ يجب تجربة WhatsApp فعليًا على الهاتف', items: ['مركز تكاملات محلي للمواقع وواجهات API وOpenAPI والملفات وقواعد البيانات والأوامر الآمنة وWebhooks.', 'كتالوج من 320 حالة اختبار و20 قالب قاعدة؛ يميّز ما فُحص فعليًا عن المتخطى وغير المدعوم.', 'بيانات دخول مشفّرة محليًا، ورمز تسجيل جهاز لمرة واحدة ينتهي بعد 10 دقائق، وسجل مهام وأجهزة مع الإلغاء.', 'إضافات تعريفية آمنة، وجدولة وقواعد تبدأ متوقفة، وسجل تنبيهات محلي واختيار صريح لتنبيهات WhatsApp.', 'تحسين قبول رقم الهاتف الدولي، وإخفاء رمز الربط محليًا بعد مدة، وإتاحة طلب رمز جديد.', 'حماية بيانات الدخول من الانتقال إلى نطاق آخر عبر تحويل HTTP.', 'منع وكيل الأجهزة من اتباع تحويل خادم المركز، وإيقاف فحص الموقع عند التحويل، وإصلاح قاعدة HTTPS ومعالجة رمز Webhook التالف.'] },
      { version: 'v9.11.0', title: 'تعميق التفاعل والمحادثة وفحص مراجعة الإصدار السابق', date: '24 أكتوبر 2026 — إصدار سابق', state: 'اختبارات المنطق والواجهة نجحت؛ اختبار HTTP والربط الحي لم يُثبتا هنا', items: [
        'إصلاح خطأ جوهري في «اختبر الرد التلقائي»: كانت دالة المطابقة ترجع true/false بينما شاشة الاختبار تنتظر كائن نتيجة؛ أصبح dry-run يستخدم matchTrigger مع matched/score الفعلية، واختبار الترحيب يؤكد المطابقة دون إرسال حقيقي.',
        'توسيع أوامر المساعد داخل محادثة النفس: إمكانيات البوت، آخر النشاط، ملخص النظام، القواعد النشطة، العدادات، اختبار قاعدة على نص، ومسح سجل ذاكرة المحادثة بعد تأكيد صريح.',
        'توسيع قواعد التفاعل: مطابقة تحتوي/مطابقة تامة/بداية/نهاية/تشابه/نية/Regex آمن/أي رسالة، ونطاق محدد، وعتبة تشابه، وأولوية، وتهدئة، وجدولة بحسب الأيام والمنطقة الزمنية، وردود بديلة، وتفاعل Emoji، ووقف بعد عدد محدد.',
        'إصلاح صياغات عربية قريبة للحقول في إنشاء القواعد، وإضافة اختبارات للإعدادات المتقدمة، ورفض العتبة غير الصحيحة والنطاق المحدد من دون جهات.',
        'تحسين مسار تأكيد الأوامر الملتبسة حتى لا يؤدي التشابه وحده إلى تنفيذ إرسال/حذف أو تعديل إعداد؛ إضافة خيار واضح لإلغاء الحوار وإبقاء المهام الحساسة تتطلب تأكيدًا.',
        'حفظ سياق محادثة المساعد المحلي عبر عدة رسائل عند إعداد Ollama؛ يظل نموذج الذكاء المحلي اختياريًا، ويعرض النظام عذر عدم الجاهزية بدل ادّعاء التنفيذ.',
        'تحديث رقم الإصدار في package.json وpackage-lock وstore والواجهة والاختبارات، وإضافة سجل إصدار جديد وتقارير مراجعة واختبارات محدثة.',
        'حدود معلنة: اختبار HTTP تم تخطيه لغياب express؛ لم يُختبر QR/رمز الهاتف أو تسليم الرسائل/صور الحساب على WhatsApp حي، ولم تُقَس دقة تفريغ الصوتيات على تسجيلات عربية حقيقية.'
      ] },
      { version: 'v9.10.0', title: 'مراجعة شاملة لإضافات الصور والمزامنة والوسائط والشات والصوت وعدم الإزعاج', date: '24 أكتوبر 2026 — إصدار سابق', state: 'اختبارات الوحدة والرجوع نجحت؛ اختبار HTTP والربط الحي لم يُثبتا هنا', items: [
        'إصلاح عيب حفظ صورة الحساب: تحديث الخلفية كان يحفظ كائن النتيجة بدل اسم ملف الصورة، مما يكسر رابط العرض؛ الآن يحفظ اسم الملف أو رابط CDN آمنًا كبديل ويعرض أعداد التخزين والفشل بدقة.',
        'رفض ملفات الكاش التي لا تحمل توقيع صورة حقيقيًا وحذف النسخ التالفة حتى يُعاد الجلب، مع اختبارات للصور التالفة وبديل CDN.',
        'تسريع قائمة جهات WhatsApp: تُعرض قائمة الأسماء دون انتظار عمليات CDN، وتبدأ تهيئة الصور في الخلفية بحد توازٍ، مع بقاء إضافة الأشخاص لقائمة الإرسال صريحة.',
        'تحسين فهم الصيغ العربية، وتحويل الصيغ الملتبسة إلى سؤال تأكيد بدل التنفيذ بالتخمين.',
        'اختبار تنزيل المرفقات عمليًا: أحدث العناصر الصالحة أولًا، حد أقصى 500 رسالة و100 ملف، 100 MiB للملف و500 MiB للمجموع، ورفض Base64 التالف قبل الكتابة.',
        'دعم امتدادات إضافية للمرفقات (MOV/MKV/HEIC/HEIF) وحماية محرك التفاعل من المنطقة الزمنية التالفة عبر بديل آمن.',
        'حدود معلنة: لم يكتمل اختبار HTTP لغياب Express في بيئة الاختبار، ولا يوجد اتصال WhatsApp حي هنا؛ يلزم اختبار الصور والتسليم الحقيقي وWhisper/Ollama بعد الإعداد.'
      ] },
      { version: 'v9.9.9', title: 'تصحيح فهم إعدادات الرد داخل المجموعات', date: '24 أكتوبر 2026 — إصدار سابق', state: 'اختبارات محلية ناجحة؛ اختبار HTTP والربط الحي غير مثبتين هنا', items: [
        'تقديم صياغات «الرد الاحتياطي في المجموعات» على الرد الاحتياطي العام، حتى لا تغيّر العبارة إعدادًا مختلفًا عن المقصود.',
        'توضيح أن «مساعد المجموعات» يخص أوامر GID وتحليل معلومات المجموعة ولا يشغّل الرد التلقائي العادي.',
        'إعادة اختبار فهم الصيغ العربية والأخطاء الإملائية القريبة، وطلب التأكيد عند الالتباس قبل تنفيذ الإرسال أو الحذف.',
        'تقرير الفحوص يميّز اختبار HTTP الذي تخطّاه المشغل بسبب غياب Express عن الاختبارات المحلية الناجحة؛ يجب إعادة الاختبار بعد تثبيت الاعتمادات.'
      ] },
      { version: 'v9.9.8', title: 'إصلاح فهم أوامر الشات وحالة إعدادات الذكاء والصوت', date: '24 أكتوبر 2026', state: 'اختبارات محلية ناجحة؛ الربط الحي يحتاج تحققًا على جهازك', items: [
        'إضافة فهم مرن لصيغ الأوامر العربية والأخطاء الإملائية الشائعة، مع سؤال تأكيد قبل المهام الملتبسة بدل تجاهلها أو تخمينها.',
        'ربط الردود عبر محادثة النفس بتغيير إعدادات التشغيل والرد التلقائي وعدم الإزعاج وفهم الصوتيات، مع التحقق من جاهزية المحرك الفعلي.',
        'منع حفظ خيار الذكاء المحلي على أنه يعمل إذا كانت خدمة Ollama أو النموذج المطلوب غير متاح، وعرض تحذير واضح بدل نجاح مضلل.',
        'حفظ سجل المحادثة المحلية للردود الذكية وإظهار حالة Whisper وOllama بدل عرض خيار مفعّل بلا تشخيص.'
      ] },
      { version: 'v9.9.7 — استعادة الاتصال', title: 'خيارات الربط واستعادة الجلسة وقفل Chromium', date: '24 أكتوبر 2026', state: 'منفذ؛ التحقق الحي مطلوب', items: [
        'ثلاث طرق ربط حقيقية: تلقائي لاستعادة LocalAuth، وQR صادر من WhatsApp، ورمز هاتف عبر pairWithPhoneNumber وحدث code الرسميين في whatsapp-web.js 1.34.7.',
        'QR يتحول إلى PNG قبل العرض ولا يستبدل برمز وهمي؛ رمز الهاتف لا يظهر إلا من حدث المكتبة الفعلي، ويُتحقق من الرقم الدولي ولا يُكتب الرمز في السجل.',
        'إصلاح السباق الذي كان يبدأ إعادة الاتصال قبل انتهاء تنظيف متصفح الجلسة؛ ينتظر النظام إغلاق عميل WhatsApp القديم قبل إعادة استخدام ملف LocalAuth.',
        'إضافة قفل تشغيل حصري يمنع نسختين من خادم المشروع نفسه من استخدام مجلد البيانات، مع تعافي من قفل PID قديم ورسالة واضحة عند وجود نسخة تعمل بالفعل.',
        'عند فشل الإغلاق الطبيعي، يحاول النظام إيقاف عملية Chromium التي يملكها العميل فقط. لا يقتل متصفحًا خارجيًا ولا يحذف بيانات الربط عند ظهور خطأ عابر.',
        'زر الربط المتكرر لا ينشئ عميلًا موازيًا، وتغيير طريقة الربط أثناء محاولة نشطة يحتاج إلى إيقاف المحاولة أولًا.',
        'اختبارات محلية مخصصة لمسار QR ورمز الهاتف وتعارض userDataDir وقفل الخادم وتنظيف العميل بعد الانفصال، بالإضافة إلى مجموعة اختبارات الصور والردود والصوت والوسائط.',
        'ما لم يتأكد حيًا: مسح QR من هاتف حقيقي، نجاح رمز الهاتف لحساب المستخدم، واستعادة الجلسة بعد إعادة تشغيل الجهاز. بيئة البناء لا تحتوي على حساب WhatsApp حي، لذلك لا تُعد المحاكاة برهان اتصال فعلي.'
      ] },
      { version: 'v9.9.7 — تقرير مراجعة الوظائف', title: 'حالة كل الطلبات السابقة وما لم يكتمل بعد', date: 'تقرير تدقيق الإصدار الحالي', state: 'منفذ جزئيًا مع حدود معلنة', items: [
        'صور الحسابات: حقل الصورة القديم والجديد، التخزين المحلي، رابط CDN موثوق كبديل، وصورة محلية قابلة للرفع والإزالة؛ ظهور الصور الحقيقية يعتمد على خصوصية الحساب وتحديث WhatsApp Web ولم يختبر حيًا.',
        'استدعاء جهات الاتصال: استيراد فوري للجهة إلى المشروع وقائمة الإرسال ومزامنة الاسم والصورة؛ المزامنة الحية الكاملة لكل صورة لم تثبت على حساب حقيقي، وفشل الصورة لا ينبغي أن يمنع إضافة جهة.',
        'الصور والوسائط: معرض ومعاينات وخيارات طريقة الإرسال والتعليق وترتيب النص والوسائط وحفظ خيارات الجدولة؛ إرسال فعلي إلى مستلم حقيقي ما زال بحاجة إلى تجربة بعد الربط.',
        'الرد التلقائي: القواعد والأولوية والتعارض وفترات التهدئة والنطاق لها اختبارات محلية؛ يجب فحص تشغيل القواعد ونطاق الدردشة على رسائل حقيقية بعد الاتصال.',
        'محادثة النفس: مساعد المالك وجسر الأوامر ومراحل التأكيد والإضافة والإرسال والموعد ومزامنة جهات الاتصال موجودة ومختبرة محليًا؛ لم تختبر دورة محادثة حية كاملة.',
        'فهم الكلام: تطبيع النص والمطابقة الذكية والرد الاحتياطي قابلة للضبط لكنها ليست ضمانًا لفهم كل لهجة أو كل نية. الرد السياقي يحتاج Ollama ونموذجًا محليًا وتمكين الخيار.',
        'الصوتيات والفويسات: Whisper المحلي يحول الصوت إلى نص ويدعم تمرير النص إلى مسارات التفاعل عند الإعداد؛ يتطلب تثبيت Whisper والنموذج وقد يتطلب FFmpeg. دقة العربية على عينات حقيقية لم تقاس بعد.',
        'تنزيل الملفات من المحادثة: متاح عبر المساعد بعد تأكيد صريح، محدود بآخر 200 رسالة و50 ملفًا و100 MiB للملف و300 MiB إجمالًا؛ ليس استخراجًا غير محدود لكل أرشيف المحادثة.',
        'عدم الإزعاج: ساعات هدوء وتصرف silence/reply/rules وفترة منع تكرار لها اختبارات محلية؛ لم تختبر رسائل حية تعبر منتصف الليل والمنطقة الزمنية.',
        'تثبيت الاعتمادات npm ci تجاوز المهلة في بيئة البناء؛ لذلك لم أدّعِ أن خادم HTTP بدأ فعليًا من هذه البيئة. يجب تشغيل run.py على الجهاز بعد أن ينجح تثبيت الاعتمادات. قبل وصف النظام بالمكتمل تمامًا يلزم اختبار حي من هاتف المستخدم للربط والاستعادة وصورة جهة وإرسال وسائط ورد تلقائي ومحادثة النفس وتنزيل مرفق وتفريغ صوت، ثم اختبار ضغط وتشغيل طويل. التفاصيل وخطوات التشخيص في REPORT_REMAINING_WORK_AR.md وRELEASES_AR.md.'
      ] },
      { version: 'v9.9.1', title: 'إصلاح دورة QR وتحديث حالة الاتصال في الخلفية', date: 'سابق', state: 'مضاف', items: ['زر الاتصال لا ينتظر انتهاء تهيئة Chromium؛ يبدأ العملية ويرجع فورًا، وتستمر قراءة الحالة عبر API دون تجميد الطلب.', 'إبقاء لوحة QR ظاهرة أثناء التشغيل وتحديثها بصورة PNG الفعلية فور وصولها من WhatsApp Web، مع مؤشر انتظار واضح عندما لم يصدر الرمز بعد.', 'إضافة تحذير بعد 45 ثانية بلا QR وتوضيح رسائل الخطأ بدل ترك الصفحة فارغة.', 'عمليات الإرسال تنتظر حالة اتصال حقيقية أو تعطي سببًا واضحًا، ولا تفترض أن بدء الاتصال يعني الجاهزية.'] },
      { version: 'v9.9.5', title: 'استعادة صور الحسابات وتحسين مكتبة الوسائط', date: 'سابق', state: 'مضاف', items: ['استعادة توافق صورة الشخص مع الحقول القديمة من v8.6: الصورة المحلية، صورة WhatsApp المحفوظة، وصورة الملف الشخصي الحالية.', 'إعادة دمج إصلاح Client.js لجلب صور الحسابات باستخدام WAWebWidFactory وWAWebFindChatAction بعد التحقق من شكل المكتبة؛ كانت رقعة المرجع v8.6 مفقودة في البناء الأحدث.', 'تقديم رابط CDN موثوق كبديل بعد التحقق من نطاقه إذا تعذر تخزين الصورة محليًا، مع محاولة المسار المحلي أولًا.', 'إضافة مسارات آمنة لرفع صورة محلية وتغييرها أو إزالتها، مع التحقق من توقيع محتوى الصورة وحد 5 ميجابايت.', 'استعادة معرض الوسائط ببطاقات معاينة متجاوبة للصور وملفات PDF والنص والفيديو والصوت، مع سحب وإفلات وتحديد/إلغاء تحديد وحذف منفصل.', 'الإبقاء على مسار الاتصال وQR وإعدادات Whisper والرد الذكي وفترة عدم الإزعاج كما هي.'] },
      { version: 'v9.9.2', title: 'صور جهات بالمقاس المرجعي، مزامنة أوضح، وفهم الصوت وتنزيل مرفقات المحادثات', date: 'سابق', state: 'مضاف', items: ['تحويل QR القادم من عميل WhatsApp إلى صورة PNG قبل عرضه، وعدم تمرير حمولة الربط الخام إلى المتصفح.', 'تحديث حالة الجلسة والـ QR تلقائيًا دون إعادة تحميل الصفحة، مع عرض أخطاء المتصفح والمصادقة.', 'منع نقرة الاتصال المتكررة من تدمير جلسة QR الحالية، واستعادة السياق عند أخطاء تنقل Chromium، والتحقق من أخطاء العميل.', 'إعدادات مستقلة للرد الاحتياطي الخاص والمجموعات، المطابقة الإملائية وحدود التكرار.', 'خيار Ollama المحلي للمحادثة مع تعليمات مالك مخصصة، من دون خدمة ذكاء اصطناعي سحابية.', 'معاينات للصور والفيديو والصوت في قائمة الملفات، والتحكم في إرسال الوسائط كمرفقات أو مستندات وإرفاق النص كتعليق.', 'لوحة تفريغ صوت إلى نص باستخدام Whisper المحلي، لآخر صوتية في WhatsApp أو ملف تختاره مع نسخ النص الناتج.', 'تحسين جلب صورة جهة الاتصال من المسار البديل الموثوق عند تعذر المسار المباشر.'] },
      { version: 'v9.9.0', title: 'ردود سياقية أذكى وتحكم موسّع بالوسائط وتفريغ الصوت محليًا', date: 'سابق', state: 'مضاف', items: ['إعدادات مستقلة للردود الاحتياطية وفهم الأخطاء الإملائية.', 'Ollama محلي اختياري للردود السياقية.', 'Whisper محلي اختياري لتفريغ الصوتيات إلى نص.', 'توسيع معاينات الوسائط وخيارات الإرسال وحفظها ضمن المواعيد.'] },
      { version: 'v9.8.1', title: 'إصلاحات إضافية للصور والإضافة الفورية وحماية رسائل الخطأ', date: 'تدقيق ومراجعة إضافية', state: 'مضاف', items: ['حفظ جهات WhatsApp المحددة وقائمة الإرسال فورًا قبل انتظار CDN الصور؛ تحديث الصور يجري في الخلفية ولا يعطل الإضافة.', 'إعادة fallback آمن متوافق مع v8.6.0: إذا تعذر تنزيل صورة موثوقة محليًا، يُعرض رابط WhatsApp الموثوق مباشرة بعد التحقق من المضيف.', 'تحسين التعرف على AVIF الذي يستخدم mif1 كعلامة أساسية وavif كعلامة متوافقة.', 'تنقية رسائل الأخطاء من بيانات الاعتماد وكلمات المرور والرموز والمسارات والروابط الحساسة قبل عرضها في الواجهة أو API.', 'إضافة اختبارات لتأخير الصور، وصيغ AVIF الإضافية، وحماية رسائل الخطأ الحساسة.'] },
      { version: 'v9.8.0', title: 'إصلاح الاستدعاء الفوري وصور الحساب وتفاصيل أخطاء الإرسال', date: 'مراجعة وظيفية إضافية', state: 'مضاف', items: ['إصلاح اختيار جهة WhatsApp المستوردة: تتحول قائمة الإرسال من وضع «الكل» إلى تحديد الجهات التي أضافها المستخدم فقط، لمنع الإرسال غير المقصود إلى بقية الأشخاص.', 'قبول صورة الملف الشخصي بعد التحقق من ترويسة الملف حتى عندما يرسل CDN نوع MIME عامًا مثل application/octet-stream، مع إبقاء فحص التوقيع والحجم والتحويلات الموثوقة.', 'السماح بخدمة ملفات AVIF المحفوظة في مسار الصور الشخصي، بدل رفضها بسبب امتداد الملف.', 'توسيع تصنيف أخطاء الإذن إلى HTTP 401/403 وبيانات statusCode ورسائل إدارة المجموعات، وتوضيح عدم اتصال WhatsApp بالعربية.', 'إصلاح حساب عدد المستلمين الفاشلين من كامل قائمة النتائج حتى عندما تُعرض تفاصيل أول ثمانية فقط، وإبقاء الإرسال الجزئي قابلًا للفحص من الواجهة.', 'فصل خيار السماح بإعادة إرسال رسالة مكررة عن خيار استبدال ملف مكرر، وعرض خيار الإعادة في صف واضح كامل العرض.'] },
      { version: 'v9.7.0', title: 'إصلاح الإرسال والأذونات واستدعاء جهات WhatsApp', date: 'تصحيح المسارات الحرجة', state: 'مضاف', items: ['تصنيف أخطاء الصلاحيات والاتصال والمستلم غير المتحقق منه إلى رسائل عربية واضحة مع رمز خطأ، وعدم إعادة المحاولة للأخطاء غير القابلة للتكرار.', 'إصلاح ترتيب إرسال ملف ثم نص عند اختيار «كل ملف ثم جميع الأهداف»؛ ترتيب الوظائف داخل كل هدف أصبح يطابق الاختيار الفعلي مع حفظ حالة كل جزء لتجنب التكرار.', 'استعادة الرجوع من معرّف الهاتف إلى معرّف LID الموثّق عند فشل طلب صورة الملف الشخصي المباشر، بدل التوقف عند أول استجابة فارغة.', 'ضبط تخطيط صف جهة WhatsApp حتى يظهر زر الإضافة مع الصورة والاسم والرقم، ويتحول لتخطيط صغير على الشاشات الضيقة.', 'إبقاء الاسم المحلي كما هو، وتخزين الاسم الظاهر واسم دفتر WhatsApp والصورة في حقول منفصلة.'] },
      { version: 'v9.6.0', title: 'إصلاح صور WhatsApp والإرسال واستدعاء جهات الاتصال', date: 'مراجعة تشغيلية ووسائط', state: 'مضاف', items: ['عرض صورة ملف WhatsApp الحالية في قائمة الاستدعاء وبطاقات الأشخاص عبر نقطة نهاية محلية آمنة، مع تحميل كسول وتخزين مؤقت للصورة بدل كشف رابط CDN منتهي الصلاحية.', 'تحسين اختيار الاسم الظاهر: الاسم المحفوظ في دفتر WhatsApp للجهة المحفوظة، واسم الملف الشخصي/الاسم الظاهر لغير المحفوظة، مع إبقاء الاسم المحلي للمشروع دون تغيير افتراضيًا.', 'تحسين تنزيل الصور لدعم التحويلات الموثقة على نطاقات WhatsApp/Facebook المسموحة، وفحص نوع المحتوى وبصمة الصورة وحجمها ورفض التحويل إلى نطاق غير موثوق.', 'إصلاح رسالة نتيجة الإرسال التي كانت تحوّل مصفوفة الرسائل إلى NaN، وعرض تفاصيل الفشل لكل مستلم مع الاحتفاظ بتحديد الأهداف التي فشلت بدل تحديد الجميع مجددًا.', 'استعادة حلّ معرف المستلم عند امتلاك السجل القديم لحقل digits أو WhatsApp JID الموثق فقط، والتحقق من أن الملف المحدد موجود وصالح قبل إرسال الوسائط.', 'إضافة اختبارات فعلية لمسار إدارة صور الملفات الشخصية وتدفق إرسال الوسائط المحلي ومعرفات المستلمين القديمة.'] },
      { version: 'v9.5.0', title: 'استعادة محادثة النفس ومزامنة WhatsApp وتقليل ازدحام الإعدادات', date: 'إصلاحات واستعادة الوظائف', state: 'مضاف', items: ['إعادة ربط رسائل «الرسائل إلى نفسك» بمساعد محلي حواري: دليل، حالة، إضافة جهة، إرسال بتأكيد، موعد، رد تلقائي، ومزامنة جهات.', 'إرسال دليل الاستخدام بعد اتصال الجلسة، مع منع تكرار إرساله عند ورود حالات اتصال متزامنة.', 'استعادة استدعاء جهات WhatsApp من الجلسة، والاختيار قبل المزامنة، واستيراد الجهات الرقمية وصور الملف الشخصي مع المحافظة على الأسماء المحلية افتراضيًا.', 'إخفاء محررات الأتمتة والردود والإعدادات الإضافية افتراضيًا، وفتح المحرر تلقائيًا عند اختيار تعديل.', 'إضافة اختبارات مستقلة لمسار الحوار ومزامنة جهات الاتصال والواجهات المرتبطة.'] },
      { version: 'v9.4.0', title: 'إكمال إدارة الأشخاص والردود الشخصية', date: 'تحديث وظيفي ومرئي', state: 'مضاف', items: ['إضافة تحديد متعدد للأشخاص وحذف جماعي مع تنظيف أهداف الجدولة والأتمتة المرتبطة.', 'إضافة وضع الرد لكل شخص: الوراثة من القواعد العامة، أو قواعد شخصية، أو تعطيل الرد، مع رد افتراضي وفترة تهدئة.', 'رفع حد الملف القابل للضبط إلى 250 ميجابايت، والقيمة الافتراضية 100 ميجابايت، مع بقاء فحص حجم الملف مفعّلًا.', 'الحفاظ على القائمة الجانبية المرجعية وأقسام المحركات الذكية وسجل التعديلات.'] },
      { version: 'v9.3.0', title: 'استعادة تخطيط الواجهة الجانبية المرجعي', date: 'تحديث سابق', state: 'مضاف', items: ['إعادة ترتيب الصفحة حول رأس علوي وقائمة جانبية رأسية مقسمة إلى مجموعات ومساحة محتوى رئيسية.', 'إبقاء صفحات التشغيل الأساسية، مع مجموعة مستقلة للمحركات الذكية والدليل وسجل التعديلات.', 'إضافة مبدل فاتح/داكن محفوظ محليًا، وروبوت مرئي لعرض إشعارات الحالة وفتح الدليل.', 'الاحتفاظ بقائمة «إعدادات إضافية» وروابطها إلى الإعدادات المتقدمة والمظهر والميزات الجديدة.'] },
      { version: 'v9.2.0', title: 'قائمة الإعدادات الإضافية وسجل التغييرات', date: 'تحديث سابق', state: 'مضاف', items: ['قائمة إضافية للوصول إلى الإعدادات المتقدمة والمظهر والمحركات والدليل.', 'إضافة صفحة سجل التعديلات وحدود الميزات.'] },
      { version: 'v9.0.0', title: 'محركات البنية الجديدة', date: 'معمارية محلية قابلة للتوسعة', state: 'مضاف', items: ['ناقل أحداث داخلي محدود السجل والتزامن.', 'محرك أوامر مع التحقق من المدخلات والصلاحيات.', 'قاموس عربي مع تطبيع النصوص والبحث التقريبي.', 'محلل نص أوامر صوتية؛ يحلل نصًا مكتوبًا/مفرغًا ولا يقوم بالتعرف على الصوت نفسه.', 'واجهات فحص الحالة والقاموس وتحليل الأمر.'] },
      { version: 'v8.9.0', title: 'الأتمتة والجدولة', date: 'تحسينات تشغيلية', state: 'مضاف', items: ['تطوير محرك المهام والمواعيد وربطها بالجلسة الحالية.', 'تحسين إدارة القواعد وسجل النشاط ومسارات التفاعل.', 'إضافة اختبارات للتحقق من الأتمتة والتوافق وحفظ البيانات.'] },
      { version: 'ملاحظات تشغيل', title: 'حدود معروفة بشفافية', date: 'ما يحتاج إلى استكمال', state: 'قيد التطوير', items: ['التخزين الحالي محلي وليس قاعدة بيانات موزعة.', 'لا يوجد طابور رسائل موزع أو قفل جدولة مشترك بين عدة نسخ.', 'القاموس الجديد في الذاكرة ولا يضمن الاحتفاظ بالإضافات بعد إعادة التشغيل.', 'التعرف على الصوت يحتاج مكوّن تحويل صوت إلى نص مستقل.', 'لا ينبغي وصف النظام بأنه جاهز لملايين الرسائل قبل إضافة التخزين والطوابير والمراقبة واختبارات الضغط.'] },
    ];
    return `<section class="page-title"><p class="eyebrow">سجل التغييرات</p><h1>التعديلات والإضافات</h1><p>ملخص واضح للتغييرات التي أضيفت إلى المشروع، مع الفصل بين الميزات الموجودة والاحتياجات التي لم تكتمل بعد.</p></section>
      <section class="updates-summary content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>ما أضيف إلى الواجهة</h2><p>مداخل واضحة بدل تكديس الخيارات في صفحة واحدة.</p></div><span class="release-pill">واجهة</span></div><ul class="update-list"><li>رأس علوي لاختيار الجلسة ومراجعة حالة الاتصال والتبديل بين الوضعين.</li><li>قائمة جانبية رأسية مقسّمة حسب مساحة العمل وجهات الإرسال والتحكم والإضافات الجديدة.</li><li>قائمة «إعدادات إضافية» للوصول إلى المظهر والتشغيل المتقدم.</li><li>صفحة مستقلة لسجل التعديلات وحدود الميزات، مع المحركات الذكية والدليل.</li></ul></article><article class="panel"><div class="panel-head"><div><h2>حالة التحقق</h2><p>ما يمكن تأكيده من الاختبارات الحالية.</p></div><span class="release-pill">محلي</span></div><div class="update-status"><b>اختبارات المشروع</b><p>تغطي الاختبارات الآلية وظائف المنطق والواجهات والمحاكاة. لا يُعد نجاحها دليلًا على إكمال الربط الحي أو اختبار الإرسال على حساب WhatsApp حقيقي. راجع تقرير المراجعة الكامل في REPORT_REMAINING_WORK_AR.md داخل المشروع.</p></div><div class="action-bar"><button class="btn primary" data-go="tools">فحص المحركات</button><button class="btn" data-go="guide">قراءة حدود التشغيل</button></div></article></section>
      <section class="release-list">${releases.map((release) => `<article class="panel release-card"><div class="release-heading"><div><span class="release-version">${esc(release.version)}</span><h2>${esc(release.title)}</h2><small>${esc(release.date)}</small></div><span class="release-state ${release.state === 'قيد التطوير' ? 'pending' : ''}">${esc(release.state)}</span></div><ul class="update-list">${release.items.map((item) => `<li>${esc(item)}</li>`).join('')}</ul></article>`).join('')}</section>`;
  }

  function render() {
    const data = state.data || { session: {}, sessions: [], whatsapp: {} };
    if (state.page !== 'conversations') stopConversationPolling();
    let content = pageDashboard(data);
    if (state.page === 'send') content = pageSend(data);
    else if (state.page === 'owner-center') content = pageOwnerCenter(data);
    else if (state.page === 'assistant') content = pageAssistant(data);
    else if (state.page === 'people') content = pagePeople(data);
    else if (state.page === 'conversations') content = pageConversations(data);
    else if (state.page === 'groups') content = pageGroups(data);
    else if (state.page === 'interaction') content = pageInteraction(data);
    else if (state.page === 'automation') content = pageAutomation(data);
    else if (state.page === 'session') content = pageSession(data);
    else if (state.page === 'integrations') content = pageIntegrations(data);
    else if (state.page === 'settings') content = pageSettings(data);
    else if (state.page === 'tools') content = pageTools();
    else if (state.page === 'guide') content = pageGuide();
    else if (state.page === 'updates') content = pageUpdates();
    else if (state.page === 'appearance') { state.page = 'settings'; state.settingsView = 'appearance'; content = pageSettings(data); }
    else if (state.page === 'operation') { state.page = 'settings'; state.settingsView = 'operation'; content = pageSettings(data); }
    applyInterfaceTheme(data);
    $('#app').innerHTML = shell(content);
    setupBackground();
    bindCommon();
    bindPage();
  }

  if (!document.documentElement.dataset.moreMenuOutsideBound) {
    document.addEventListener('click', (event) => {
      if (event.target.closest('.more-settings-wrap')) return;
      const menu = $('#moreSettingsMenu');
      if (menu) menu.hidden = true;
      $('#moreSettingsBtn')?.setAttribute('aria-expanded', 'false');
    });
    document.documentElement.dataset.moreMenuOutsideBound = '1';
  }

  function bindCommon() {
    $$('.navbtn').forEach((button) => { button.onclick = () => go(button.dataset.page); });
    const moreButton = $('#moreSettingsBtn');
    const moreMenu = $('#moreSettingsMenu');
    moreButton?.addEventListener('click', (event) => { event.stopPropagation(); const open = moreMenu?.hidden !== false; if (moreMenu) moreMenu.hidden = !open; moreButton.setAttribute('aria-expanded', String(open)); });
    $('#modeToggleBtn')?.addEventListener('click', () => {
      state.uiMode = state.uiMode === 'dark' ? 'light' : 'dark';
      try { localStorage.setItem('chatbot-ui-mode', state.uiMode); } catch { /* Theme remains active for this page view. */ }
      document.documentElement.dataset.theme = state.uiMode;
      render();
    });
    $('#assistantRobotButton')?.addEventListener('click', () => {
      const bubble = $('#assistantSpeech');
      const bubbleText = $('#assistantSpeechText');
      if (!bubble) return;
      if (bubble.hidden && bubbleText && !bubbleText.textContent.trim()) bubbleText.textContent = 'افتح «المساعد المحلي» للسؤال عن حالة النظام والتنقل بين صفحات البرنامج. هذا المساعد يستخدم قواعد محلية ولا يستدعي API خارجيًا.';
      bubble.hidden = !bubble.hidden;
      $('#assistantRobotButton')?.classList.toggle('robot-talk', !bubble.hidden);
    });
    $('#assistantSpeechClose')?.addEventListener('click', () => { const bubble = $('#assistantSpeech'); if (bubble) bubble.hidden = true; $('#assistantRobotButton')?.classList.remove('robot-talk'); });
    $('#assistantSpeechOpen')?.addEventListener('click', () => go('assistant'));
    $$('[data-go]').forEach((button) => { button.onclick = () => go(button.dataset.go); });
    $('#refreshBtn')?.addEventListener('click', () => load(true).catch((e) => notify(e.message, 'error')));
    $('#dashboardRefresh')?.addEventListener('click', () => load(true).catch((e) => notify(e.message, 'error')));
    $('#sessionRefreshLog')?.addEventListener('click', () => load(true).catch((e) => notify(e.message, 'error')));
    $('#sessionSelect')?.addEventListener('change', async (event) => {
      try {
        await api('/api/sessions/switch', { method: 'POST', body: JSON.stringify({ sessionId: event.target.value }) });
        state.pendingTargets = null;
        state.selectedRecipientIds.clear();
        state.selectedGroup = null;
        state.whatsappContacts = null; state.whatsappContactsSession = ''; state.whatsappContactsSelected.clear(); state.whatsappContactFilter = ''; state.whatsappContactsPage = 1;
        state.whatsappContactsOpen = false; state.whatsappContactsBusy = false; state.connectionMethod = ''; state.connectionPhoneNumber = '';
        state.conversationTargetsSession = ''; state.conversationLoadedKey = ''; state.conversationMessages = []; state.conversationMeta = null; state.conversationTargetKey = 'self'; state.conversationTargets = []; state.conversationQuery = '';
        stopConversationPolling();

        await load(true);
      } catch (error) { notify(error.message, 'error'); }
    });
  }

  async function bindPage() {
    if (state.page === 'send') bindSend();
    if (state.page === 'assistant') bindAssistant();
    if (state.page === 'owner-center') $('#ownerCenterRefresh')?.addEventListener('click', () => load(true).catch(error => notify(error.message, 'error')));
    if (state.page === 'people') bindPeople();
    if (state.page === 'conversations') bindConversations();
    if (state.page === 'groups') bindGroups();
    if (state.page === 'interaction') bindInteraction();
    if (state.page === 'automation') bindAutomation();
    if (state.page === 'session') bindSession();
    if (state.page === 'integrations') bindIntegrations();
    if (state.page === 'appearance') bindAppearance();
    if (state.page === 'tools') bindTools();
    if (state.page === 'settings') {
      bindSettings();
      if (state.settingsView === 'operation') bindOperation(); else bindAppearance();
    }
  }

  async function loadConversationMessages({ before = null, append = false, query = null } = {}) {
    const sessionId = sid();
    const currentQuery = query === null ? state.conversationQuery : query;
    const targetKey = state.conversationTargetKey || 'self';
    if (!sessionId || !targetKey || state.conversationBusy) return;
    state.conversationBusy = true;
    const routeKey = `${sessionId}|${targetKey}|${currentQuery}`;
    try {
      const params = new URLSearchParams({ sessionId, targetKey, limit: '100' });
      if (before !== null && before !== undefined) {
        const token = String(before);
        if (token.startsWith('c:')) params.set('cursor', token); else params.set('before', token);
      }
      if (currentQuery) params.set('q', currentQuery);
      const result = await api(`/api/conversations/messages?${params.toString()}`);
      if (sid() !== sessionId || (state.conversationTargetKey || 'self') !== targetKey || state.conversationQuery !== currentQuery || state.page !== 'conversations') return;
      const received = Array.isArray(result.messages) ? result.messages : [];
      if (append) {
        const union = new Map([...state.conversationMessages, ...received].map(item => [`${item.chatId}|${item.messageId || item.id}`, item]));
        state.conversationMessages = [...union.values()].sort((a, b) => Number(a.timestampMs) - Number(b.timestampMs));
      } else state.conversationMessages = received;
      state.conversationMeta = { totalStoredForTarget: result.totalStoredForTarget, hasOlder: result.hasOlder, nextBefore: result.nextBefore, nextCursor: result.nextCursor || null, oldestTimestampMs: result.oldestTimestampMs };
      state.conversationLoadedKey = routeKey;
    } catch (error) {
      notify(`تعذر تحميل سجل المحادثة: ${error.message}`, 'error');
    } finally {
      state.conversationBusy = false;
    }
  }

  async function refreshConversationOrphans() {
    const sessionId = sid();
    if (!sessionId) return;
    try {
      const result = await api(`/api/conversations/orphaned?sessionId=${encodeURIComponent(sessionId)}`);
      if (sid() !== sessionId) return;
      state.conversationOrphans = Array.isArray(result.orphaned) ? result.orphaned : [];
      state.conversationOrphansSession = sessionId;
    } catch (error) {
      state.conversationOrphans = []; state.conversationOrphansSession = '';
      if (state.page === 'conversations') notify(`تعذر قراءة سجلات المحادثات غير المرتبطة: ${error.message}`, 'warning');
    }
  }

  async function refreshConversationTargets() {
    const sessionId = sid();
    if (!sessionId || state.conversationBusy) return;
    state.conversationBusy = true;
    state.conversationTargetsSession = `loading:${sessionId}`;
    try {
      const result = await api(`/api/conversations/targets?sessionId=${encodeURIComponent(sessionId)}`);
      state.conversationTargets = Array.isArray(result.targets) ? result.targets : [];
      state.conversationTargetsSession = sessionId;
      if (!state.conversationTargets.some(item => item.key === state.conversationTargetKey)) state.conversationTargetKey = state.conversationTargets.some(item => item.key === 'self') ? 'self' : (state.conversationTargets[0]?.key || 'self');
      state.conversationLoadedKey = '';
    } catch (error) {
      state.conversationTargetsSession = '';
      notify(`تعذر تحميل الجهات المسجلة: ${error.message}`, 'error');
    } finally { state.conversationBusy = false; }
    await refreshConversationOrphans();
    if (state.page === 'conversations') render();
  }

  function bindConversations() {
    startConversationPolling();
    $('#conversationOrphanRefreshBtn')?.addEventListener('click', async () => { await refreshConversationOrphans(); if (state.page === 'conversations') render(); });
    $$('[data-relink-orphan]').forEach(button => button.addEventListener('click', async () => {
      if (state.conversationBusy) return;
      const fromTargetKey = button.dataset.relinkOrphan || '';
      const selector = $$('[data-orphan-target]').find(item => item.dataset.orphanTarget === fromTargetKey);
      const toTargetKey = String(selector?.value || '');
      const orphan = state.conversationOrphans.find(item => item.targetKey === fromTargetKey);
      const target = state.conversationTargets.find(item => item.key === toTargetKey);
      if (!orphan || !target) return notify('اختر جهة مسجلة مطابقة للسجل أولًا.', 'warning');
      if (!confirm(`سيُربط ${Number(orphan.count || 0)} رسالة محفوظة من ${orphan.chatId} بالجهة «${target.label}». يجب أن يتطابق معرّف WhatsApp حرفيًا. لن يرسل البرنامج أو يحذف أي رسالة. متابعة؟`)) return;
      state.conversationBusy = true; button.disabled = true; button.classList.add('loading');
      try {
        const result = await api('/api/conversations/relink', { method: 'POST', body: JSON.stringify({ sessionId: sid(), fromTargetKey, toTargetKey }) });
        notify(result.message || 'تم استعادة ربط سجل المحادثة.', 'success');
      } catch (error) { notify(`تعذر استعادة الربط: ${error.message}`, 'error'); }
      finally { state.conversationBusy = false; button.disabled = false; button.classList.remove('loading'); }
      await refreshConversationTargets();
      if (state.page === 'conversations') { await loadConversationMessages(); render(); }
    }));
    $$('[data-conversation-target]').forEach(button => button.addEventListener('click', async () => {
      if (state.conversationBusy) return;
      state.conversationTargetKey = button.dataset.conversationTarget || 'self';
      state.conversationQuery = ''; state.conversationMessages = []; state.conversationMeta = null; state.conversationLoadedKey = '';
      await loadConversationMessages(); render();
    }));
    $('#conversationSearchForm')?.addEventListener('submit', async event => {
      event.preventDefault();
      if (state.conversationBusy) return;
      state.conversationQuery = String($('#conversationSearch')?.value || '').trim();
      state.conversationLoadedKey = ''; state.conversationMeta = null;
      await loadConversationMessages({ query: state.conversationQuery }); render();
    });
    $('#conversationClearSearch')?.addEventListener('click', async () => {
      if (state.conversationBusy) return;
      state.conversationQuery = ''; state.conversationLoadedKey = ''; state.conversationMeta = null;
      await loadConversationMessages({ query: '' }); render();
    });
    $('#conversationRefreshBtn')?.addEventListener('click', async () => {
      if (state.conversationBusy) return;
      state.conversationTargetsSession = ''; state.conversationLoadedKey = '';
      await refreshConversationTargets();
      if (state.page === 'conversations') { await loadConversationMessages(); render(); }
    });
    $('#conversationLoadOlder')?.addEventListener('click', async () => {
      if (state.conversationBusy || !state.conversationMeta?.hasOlder) return;
      const before = state.conversationMeta.nextCursor || state.conversationMeta.nextBefore;
      if (before === null || before === undefined) return;
      await loadConversationMessages({ before, append: true }); render();
    });
    $('#conversationDownloadMediaBtn')?.addEventListener('click', async event => {
      if (state.conversationBusy) return;
      const button = event.currentTarget;
      const target = state.conversationTargets.find(item => item.key === state.conversationTargetKey);
      if (!target?.hasChatId || target.enabled === false) { notify('اختر جهة مسجلة ومفعّلة ذات معرّف WhatsApp مؤكد.', 'warning'); return; }
      const mediaType = String($('#conversationMediaType')?.value || 'all');
      const messageLimit = Math.max(1, Math.min(500, Number($('#conversationMediaDepth')?.value) || 200));
      const maxFiles = Math.max(1, Math.min(100, Number($('#conversationMediaFileLimit')?.value) || 50));
      const mediaLabels = { all: 'كل الأنواع', image: 'الصور', video: 'الفيديو', audio: 'الصوت والرسائل الصوتية', sticker: 'الملصقات', document: 'المستندات والملفات' };
      if (!confirm(`تأكيد تنزيل مرفقات المحادثة «${target.label}»؟\n\nالنوع: ${mediaLabels[mediaType] || 'كل الأنواع'}\nالرسائل التي ستُفحص: آخر ${messageLimit}\nالحد الأقصى للملفات: ${maxFiles}\nالحجم: حتى 100 MB للملف و500 MB إجمالًا (وقد يخفض إعداد الجلسة الحد).\n\nستُحفظ الملفات في مكتبة الجلسة المحلية فقط. لن يرسل البرنامج أي ملف إلى جهة ولن يحذف رسائل. قد لا يتيح WhatsApp المرفقات القديمة. متابعة؟`)) return;
      button.disabled = true; const priorText = button.textContent; button.textContent = 'جارٍ التنزيل…';
      state.conversationBusy = true;
      try {
        const result = await api('/api/conversations/download-media', { method: 'POST', body: JSON.stringify({ sessionId: sid(), targetKey: target.key, mediaType, messageLimit, maxFiles, confirmedDownloadMedia: true }) });
        const failures = Number(result.failed?.length || 0), skipped = Number(result.skipped?.length || 0);
        const names = (result.downloaded || []).slice(0, 8).map(item => item.filename).join('، ');
        notify(`${result.message || 'اكتمل تنزيل المرفقات.'}${names ? `\nالملفات: ${names}` : ''}`, failures || skipped ? 'warning' : 'success');
        state.conversationTargetsSession = ''; state.conversationLoadedKey = '';
        await load(true);
      } catch (error) { notify(`تعذر تنزيل المرفقات: ${error.message}`, 'error'); }
      finally { state.conversationBusy = false; if (button.isConnected) { button.disabled = false; button.textContent = priorText; } }
      if (state.page === 'conversations') { await refreshConversationTargets(); await loadConversationMessages(); render(); }
    });
    $('#conversationImportBtn')?.addEventListener('click', async () => {
      if (state.conversationBusy) return;
      const target = state.conversationTargets.find(item => item.key === state.conversationTargetKey);
      if (!target?.hasChatId) { notify('لا يوجد معرّف WhatsApp مؤكد لهذه الجهة. اتصل أولًا وحدّث بيانات الجهة.', 'warning'); return; }
      const requestedLimit = Math.max(1000, Math.min(20000, Number($('#conversationImportLimit')?.value) || 1000));
      if (!confirm(`سيطلب البرنامج ما يصل إلى ${requestedLimit.toLocaleString('ar')} رسالة أقدم/أحدث متاحة للمحادثة «${target.label}»، ويحفظها محليًا. قد يستغرق ذلك وقتًا في المحادثات الكبيرة. لن يرسل أو يحذف شيئًا، وقد يظل تاريخ غير متاح لدى WhatsApp. متابعة؟`)) return;
      state.conversationBusy = true; render();
      try {
        const result = await api('/api/conversations/import', { method: 'POST', body: JSON.stringify({ sessionId: sid(), targetKey: target.key, limit: requestedLimit, confirmedImportHistory: true }) });
        notify(`استيراد سجل «${target.label}»: استُقبل ${Number(result.fetched || 0)}، حُفظ ${Number(result.stored || 0)}، مكرر ${Number(result.duplicates || 0)}، تعذر ${Number(result.failed || 0)}. ${result.limitReached ? 'وصلت إلى حد الرسائل المحدد؛ قد توجد رسائل أقدم.' : 'قد يظل جزء من التاريخ غير متاح لدى WhatsApp.'}`, result.failed || result.limitReached ? 'warning' : 'success');
        state.conversationTargetsSession = ''; state.conversationLoadedKey = '';
      } catch (error) { notify(`فشل استيراد السجل: ${error.message}`, 'error'); }
      finally { state.conversationBusy = false; }
      await refreshConversationTargets();
      if (state.page === 'conversations') { await loadConversationMessages(); render(); }
    });
    const current = sid();
    if (!state.conversationTargetsSession || state.conversationTargetsSession !== current) {
      refreshConversationTargets();
      return;
    }
    const loadedKey = `${current}|${state.conversationTargetKey || 'self'}|${state.conversationQuery}`;
    if (state.conversationLoadedKey !== loadedKey && !state.conversationBusy) {
      loadConversationMessages().then(() => { if (state.page === 'conversations') render(); });
    }
  }

  async function bindTools() {
    const healthBox = $('#architectureStatus');
    const healthButton = $('#refreshArchitecture');
    const refreshHealth = async () => {
      if (!healthBox) return;
      healthButton?.classList.add('loading');
      healthBox.innerHTML = '<div class="empty">جارٍ قراءة حالة البنية…</div>';
      try {
        const result = await api('/api/architecture/health');
        const modules = result.modules || {};
        const rows = [
          ['ناقل الأحداث', typeof modules.eventBus === 'object' ? 'نشط' : 'متاح', typeof modules.eventBus === 'object' ? `${Number(modules.eventBus.types || 0)} أنواع أحداث · ${Number(modules.eventBus.history || 0)} أحداث في السجل` : 'لم تتوفر تفاصيل'],
          ['محرك الأوامر', 'متاح', `${Number(modules.commandEngine || 0)} أمر مسجل`],
          ['قاموس المصطلحات', 'متاح', `${Number(modules.dictionaryEngine || 0)} مدخل/مفتاح في الذاكرة`],
          ['محلل الأوامر الصوتية', modules.voiceTranscriber ? 'متاح' : (modules.voiceParser ? 'جزئي' : 'غير متاح'), 'يفرّغ الصوت محليًا عند إعداد Whisper؛ ثم يحلل النص قبل أي تنفيذ'],
          ['الحفظ', 'محلي', String(modules.persistence || 'غير محدد')],
          ['التوسع الموزّع', 'غير مهيأ', String(modules.productionScaleAdapter || 'غير محدد')],
        ];
        healthBox.innerHTML = `<div class="architecture-head"><span class="mini-tag">الإصدار ${esc(result.version || '—')}</span><span class="mini-tag">فحص محلي</span></div><div class="architecture-grid">${rows.map(([name, status, detail]) => `<div class="architecture-item"><span class="architecture-check">${status === 'نشط' || status === 'متاح' || status === 'محلي' ? '✓' : '!'}</span><div><b>${esc(name)}</b><small>${esc(detail)}</small></div><span class="architecture-state ${status === 'غير مهيأ' ? 'warning' : ''}">${esc(status)}</span></div>`).join('')}</div>`;
      } catch (error) {
        healthBox.innerHTML = `<div class="empty">تعذر جلب الحالة: ${esc(error.message)}</div>`;
      } finally { healthButton?.classList.remove('loading'); }
    };
    healthButton?.addEventListener('click', refreshHealth);
    await refreshHealth();

    let latestOperationalReport = null;
    const operationalSummary = $('#operationalDiagnosticsSummary');
    const operationalChecks = $('#operationalDiagnosticsChecks');
    const operationalJson = $('#operationalDiagnosticsJson');
    const operationalRefresh = $('#refreshOperationalDiagnostics');
    const operationalCopy = $('#copyOperationalDiagnostics');
    const refreshOperationalDiagnostics = async () => {
      if (!operationalSummary || !operationalChecks) return;
      operationalRefresh?.classList.add('loading');
      if (operationalRefresh) operationalRefresh.disabled = true;
      operationalSummary.textContent = 'جارٍ فحص المكونات المحلية…';
      operationalChecks.innerHTML = '';
      try {
        const report = await api(`/api/diagnostics/report?sessionId=${encodeURIComponent(sid())}`);
        latestOperationalReport = report;
        const overallLabels = { healthy: 'لا توجد مشكلة حرجة معروفة', degraded: 'توجد عناصر تحتاج مراجعة', needs_attention: 'توجد مشكلة تحتاج إجراءً' };
        const overallStatus = report.overall === 'healthy' ? 'success' : report.overall === 'degraded' ? 'warning' : 'error';
        const counts = report.summary || {};
        operationalSummary.innerHTML = `<div class="tool-result-title"><span class="result-status ${overallStatus}">${esc(overallLabels[report.overall] || 'اكتمل الفحص')}</span><b>الإصدار ${esc(report.version || '—')}</b></div><p>${Number(counts.pass || 0)} ناجح · ${Number(counts.warning || 0)} تحذير · ${Number(counts.error || 0)} مشكلة · ${Number(counts.info || 0)} معلومة</p><small>وقت الفحص: ${esc(report.checkedAt || '—')}</small><p class="help">${esc(report.privacy || '')}</p>`;
        const labels = { pass: ['✓', 'جاهز', ''], warning: ['!', 'تحذير', 'warning'], error: ['×', 'مشكلة', 'warning'], info: ['i', 'معلومة', ''] };
        operationalChecks.innerHTML = (report.checks || []).map(check => {
          const meta = labels[check.status] || labels.info;
          return `<div class="architecture-item"><span class="architecture-check">${esc(meta[0])}</span><div><b>${esc(check.label || check.id || 'فحص')}</b><small>${esc(check.detail || '')}${check.recommendation ? `<br><strong>الإجراء المقترح:</strong> ${esc(check.recommendation)}` : ''}</small></div><span class="architecture-state ${meta[2]}">${esc(meta[1])}</span></div>`;
        }).join('');
        if (operationalJson) operationalJson.value = JSON.stringify(report, null, 2);
        if (operationalCopy) operationalCopy.disabled = false;
      } catch (error) {
        latestOperationalReport = null;
        operationalSummary.textContent = `تعذر إنشاء التقرير: ${error.message}`;
        operationalChecks.innerHTML = '';
        if (operationalJson) operationalJson.value = '';
        if (operationalCopy) operationalCopy.disabled = true;
      } finally {
        operationalRefresh?.classList.remove('loading');
        if (operationalRefresh) operationalRefresh.disabled = false;
      }
    };
    operationalRefresh?.addEventListener('click', refreshOperationalDiagnostics);
    operationalCopy?.addEventListener('click', async () => {
      if (!latestOperationalReport) return notify('شغّل الفحص أولًا.', 'warning');
      try { await navigator.clipboard.writeText(JSON.stringify(latestOperationalReport, null, 2)); notify('تم نسخ التقرير التشغيلي الآمن.', 'success'); }
      catch { if (operationalJson) { operationalJson.focus(); operationalJson.select(); } notify('تعذر النسخ التلقائي؛ حدّد JSON وانسخه يدويًا باستخدام Ctrl+C.', 'info'); }
    });
    await refreshOperationalDiagnostics();

    $('#voiceParseBtn')?.addEventListener('click', async () => {
      const transcript = $('#voiceTranscript')?.value.trim() || '';
      if (!transcript) return notify('أدخل النص أولًا.', 'error');
      const output = $('#voiceParseResult');
      output.textContent = 'جارٍ تحليل النص…';
      try {
        const confidence = Math.max(0, Math.min(1, Number($('#voiceConfidence')?.value ?? 1)));
        const result = await api('/api/voice/parse', { method: 'POST', body: JSON.stringify({ transcript, confidence, locale: $('#voiceLocale')?.value || 'ar' }) });
        const parsed = result.parsed || {};
        if (parsed.accepted) {
          output.innerHTML = `<div class="tool-result-title"><span class="result-status success">تم التعرف على النية</span><b>${esc(parsed.intent || '—')}</b></div><dl class="tool-result-dl"><dt>الهدف النصي</dt><dd>${esc(parsed.targetText || 'لا يوجد هدف محدد')}</dd><dt>الثقة</dt><dd>${Math.round(Number(parsed.confidence || 0) * 100)}%</dd><dt>النص الموحّد</dt><dd>${esc(parsed.normalized || parsed.transcript || '')}</dd></dl>${parsed.requiresConfirmation ? '<div class="callout">يتطلب هذا النوع تأكيدًا صريحًا. لم يتم تنفيذ أي إجراء.</div>' : '<div class="help">تم التحليل فقط؛ لا يوجد تنفيذ تلقائي.</div>'}`;
        } else {
          const reason = parsed.reason === 'low-confidence' ? 'مستوى الثقة أقل من الحد المطلوب.' : parsed.reason === 'empty' ? 'النص فارغ.' : 'لم يتم التعرف على أمر مدعوم.';
          output.innerHTML = `<span class="result-status warning">لم يتم قبول الأمر</span><p>${esc(reason)}</p><small>${esc(parsed.transcript || transcript)}</small>`;
        }
      } catch (error) { output.textContent = `تعذر تحليل النص: ${error.message}`; }
    });
    $('#voiceClearBtn')?.addEventListener('click', () => { $('#voiceTranscript').value = ''; $('#voiceParseResult').textContent = 'لم يتم تحليل أي نص بعد.'; });

    $('#dictionaryForm')?.addEventListener('submit', async (event) => {
      event.preventDefault();
      const query = $('#dictionaryQuery')?.value.trim() || '';
      if (!query) return notify('اكتب مصطلحًا للبحث.', 'error');
      const output = $('#dictionaryResult');
      output.textContent = 'جارٍ البحث…';
      try {
        const result = await api(`/api/dictionary/lookup?q=${encodeURIComponent(query)}`);
        if (result.entry) {
          const entry = result.entry;
          output.innerHTML = `<div class="tool-result-title"><span class="result-status success">عُثر على مصطلح</span><b>${esc(entry.term || query)}</b></div><p>${esc(entry.definition || 'لا يوجد تعريف مسجل لهذا المصطلح.')}</p>${entry.aliases?.length ? `<div class="tool-tags">${entry.aliases.map(alias => `<span>${esc(alias)}</span>`).join('')}</div>` : ''}`;
        } else output.innerHTML = `<span class="result-status warning">لا توجد نتيجة</span><p>لم يُعثر على «${esc(query)}» في القاموس المحلي الحالي.</p><small>محرك القاموس موجود، لكن بياناته لا تُحمّل تلقائيًا ولا تُحفَظ بين مرات التشغيل في هذه النسخة.</small>`;
        const all = await api('/api/dictionary?limit=1');
        if ($('#dictionaryMeta')) $('#dictionaryMeta').textContent = `عدد المصطلحات الحالية: ${(all.entries || []).length ? 'يوجد محتوى' : '0'} · القاموس في الذاكرة ويحتاج مصدر بيانات دائمًا مستقبلًا.`;
      } catch (error) { output.textContent = `تعذر البحث: ${error.message}`; }
    });

    const transcriptionStatus = $('#transcriptionStatus');
    const transcriptOutput = $('#transcriptOutput');
    const transcriptQualityStatus = $('#transcriptQualityStatus');
    let transcriptionSettingsInitialized = false;
    const showTranscriptQuality = result => {
      const quality = result?.quality || { status: 'unverified', score: null, metadataSufficient: false, notStatisticallyCalibrated: true, warnings: ['quality-metadata-missing'], reasons: [] };
      const labels = { clear: 'واضح وفق المؤشرات المتاحة', review: 'يحتاج مراجعة', rejected: 'ضعيف — لا يستخدم كأمر', unverified: 'غير موثّق — راجع النص' };
      const parts = [];
      if (quality.score !== null && quality.score !== undefined) parts.push(`مؤشر إرشادي ${(Number(quality.score) * 100).toFixed(0)}% — ليس احتمال صحة النص`);
      parts.push(quality.metadataSufficient ? 'قياسات كافية للفحص (ليست معايرة إحصائيًا)' : 'القياسات غير كافية للثقة الآلية');
      if (quality.reasons?.length || quality.warnings?.length) parts.push(`تنبيهات: ${quality.summary || (quality.reasons || []).concat(quality.warnings || []).join('، ')}`);
      if (transcriptQualityStatus) {
        transcriptQualityStatus.textContent = `${labels[quality.status] || labels.unverified} · ${parts.join(' · ')}`;
        transcriptQualityStatus.classList.toggle('status-ready', quality.status === 'clear');
        transcriptQualityStatus.classList.toggle('status-warning', quality.status !== 'clear');
      }
      return quality;
    };
    const refreshTranscriptionStatus = async () => {
      if (!transcriptionStatus) return;
      transcriptionStatus.textContent = 'جارٍ فحص البرنامج والنموذج المحليين…';
      try {
        const result = await api('/api/transcription/status');
        transcriptionStatus.textContent = result.message || (result.ready ? 'Whisper جاهز.' : 'Whisper غير مهيأ.');
        if (result.avVersion) transcriptionStatus.textContent += ` · PyAV ${result.avVersion} ${result.avCompatible ? 'متوافق' : 'غير متوافق'}`;
        if (result.inference) {
          transcriptionStatus.textContent += ` · beam ${result.inference.beamSize} · VAD ${result.inference.vad ? 'مفعّل' : 'متوقف'} · ${result.inference.device || 'cpu'}/${result.inference.computeType || 'int8'}`;
          if (!transcriptionSettingsInitialized) {
            const values = {
              transcriptionModelSize: result.modelSize || result.runtime?.modelSize || 'small',
              transcriptionDevice: result.inference.device || 'cpu',
              transcriptionComputeType: result.inference.computeType || 'int8',
              transcriptionBeamSize: result.inference.beamSize || 5,
              transcriptionVadThreshold: result.inference.vadThreshold ?? 0.5,
              transcriptionMinSilence: result.inference.minSilenceMs || 450,
              transcriptionLogProb: result.inference.logProbThreshold ?? -1,
              transcriptionNoSpeech: result.inference.noSpeechThreshold ?? 0.6,
              transcriptionCompression: result.inference.compressionRatioThreshold ?? 2.4,
            };
            for (const [id, value] of Object.entries(values)) { const field = $(`#${id}`); if (field) field.value = String(value); }
            if ($('#transcriptionVad')) $('#transcriptionVad').checked = result.inference.vad !== false;
            if ($('#transcriptionPreviousText')) $('#transcriptionPreviousText').checked = result.inference.conditionOnPreviousText === true;
            transcriptionSettingsInitialized = true;
          }
        }
        if (result.restartRequired === true) transcriptionStatus.textContent += ' · يلزم إعادة تشغيل لتطبيق النموذج المختار';
        transcriptionStatus.classList.toggle('status-ready', result.ready === true);
        transcriptionStatus.classList.toggle('status-warning', result.ready !== true);
      } catch (error) { transcriptionStatus.textContent = error.message; transcriptionStatus.classList.add('status-warning'); }
    };
    $('#saveTranscriptionSettings')?.addEventListener('click', async () => {
      const button = $('#saveTranscriptionSettings');
      button?.classList.add('loading');
      try {
        const result = await api('/api/transcription/settings', { method: 'PUT', body: JSON.stringify({
          modelSize: $('#transcriptionModelSize')?.value || 'small',
          device: $('#transcriptionDevice')?.value || 'cpu',
          computeType: $('#transcriptionComputeType')?.value || 'int8',
          beamSize: Number($('#transcriptionBeamSize')?.value || 5),
          vad: $('#transcriptionVad')?.checked === true,
          vadThreshold: Number($('#transcriptionVadThreshold')?.value || 0.5),
          minSilenceMs: Number($('#transcriptionMinSilence')?.value || 450),
          logProbThreshold: Number($('#transcriptionLogProb')?.value ?? -1),
          noSpeechThreshold: Number($('#transcriptionNoSpeech')?.value || 0.6),
          compressionRatioThreshold: Number($('#transcriptionCompression')?.value || 2.4),
          conditionOnPreviousText: $('#transcriptionPreviousText')?.checked === true,
        }) });
        notify(result.message || 'تم حفظ إعدادات التفريغ.', result.restartRequired ? 'warning' : 'success');
        if (result.restartRequired && transcriptionStatus) transcriptionStatus.textContent = `${result.message} النموذج الجاري لن يتغير حتى إعادة التشغيل.`;
        await refreshTranscriptionStatus();
      } catch (error) { notify(error.message, 'error'); }
      finally { button?.classList.remove('loading'); }
    });
    $('#refreshTranscriptionStatus')?.addEventListener('click', refreshTranscriptionStatus);
    await refreshTranscriptionStatus();
    const ttsStatus = $('#ttsStatus'), ttsReadiness = $('#ttsReadiness');
    const refreshTtsStatus = async () => {
      if (!ttsStatus || !ttsReadiness) return;
      ttsStatus.textContent = 'جارٍ فحص محرك النطق والنموذج وFFmpeg…';
      try {
        const result = await api(`/api/tts/status?sessionId=${encodeURIComponent(sid())}`);
        ttsStatus.textContent = result.message || (result.ready ? 'محرك النطق الأساسي جاهز.' : 'محرك النطق غير مكتمل.');
        const fullyReady = result.ready === true && result.ffmpegReady === true && (result.proofreaderRequired !== true || result.proofreaderAvailable === true);
        ttsStatus.classList.toggle('status-ready', fullyReady);
        ttsStatus.classList.toggle('status-warning', !fullyReady);
        const localBackend = result.backend === 'local' || result.activeBackend === 'local';
        const audar = result.audar || {};
        const expressive = result.chatterbox || {};
        const rows = [
          [`المحرك النشط (${result.activeEngine || result.activeBackend || result.backend || 'local'})`, result.ready === true],
          ...(localBackend ? [
            [`بيئة Audar Python (${audar.tier || 'Turbo'})`, audar.packageReady === true],
            ['ملف أوزان Audar Q5_K_M', audar.modelReady === true],
            ['الأصوات المرجعية الستة', Number(audar.voiceCount || 0) >= 6],
            ['ملفات Audar والحزم جاهزة لبدء الاستدلال', audar.ready === true],
            ['اختبار التوليد العربي الفعلي اجتاز', audar.smokeTested === true],
            ['Chatterbox الاختياري', expressive.ready === true],
            ['Piper العربي الاحتياطي', result.piperFallbackReady === true],
            [`تشكيل العربية في Piper${result.piperTtsVersion ? ` (${result.piperTtsVersion})` : ''}`, result.arabicTashkeelEnabledByDefault === true],
          ] : []),
          ['FFmpeg لتحويل OGG/Opus', result.ffmpegReady],
          [`المدقق المحلي (${result.proofreaderModel || 'Ollama'})${result.proofreaderRequired ? ' — مطلوب' : ' — اختياري'}`, result.proofreaderRequired ? result.proofreaderAvailable : (result.proofreaderAvailable || true)],
        ];
        ttsReadiness.innerHTML = rows.map(([name, ready]) => `<div class="tts-readiness-row"><span class="tts-readiness-mark ${ready ? 'ready' : ''}">${ready ? '✓' : '!'} </span><span>${esc(name)}</span><b>${ready ? 'جاهز' : 'غير جاهز'}</b></div>`).join('') + `<p class="help">${result.message ? `${esc(result.message)} ` : ''}${result.proofreaderAvailable ? 'يمكن تدقيق النص محليًا قبل النطق.' : (result.proofreaderRequired ? 'النطق مع اشتراط التدقيق سيتوقف حتى يتوفر نموذج Ollama المحلي المحدد في إعدادات الجلسة.' : 'تنبيه: التدقيق غير إلزامي؛ قد يُنطق النص الأصلي كما هو دون تصحيح لغوي.')}</p>`;
      } catch (error) { ttsStatus.textContent = `تعذر فحص النطق: ${error.message}`; ttsStatus.classList.add('status-warning'); }
    };
    $('#refreshTtsStatus')?.addEventListener('click', refreshTtsStatus);
    $('#testVoiceFourLanguagesBtn')?.addEventListener('click', async () => {
      const button = $('#testVoiceFourLanguagesBtn'), output = $('#voiceFourLanguageTestResult');
      if (!button || !output) return;
      button.disabled = true; button.classList.add('loading');
      output.innerHTML = '<p class="help">جارٍ اختبار النطق وتحويل OGG/Opus والتفريغ للعربية والإنجليزية والفرنسية والألمانية. قد يستغرق الاختبار وقتًا لأنه يستخدم المحركات الفعلية.</p>';
      try {
        const result = await api('/api/voice/test-four-languages', { method: 'POST', body: JSON.stringify({}) });
        if (!result.completed) {
          output.innerHTML = `<p class="help">${esc(result.message || 'الصوت ما زال قيد الإعداد التلقائي.')}</p>`;
          notify(result.message || 'الصوت ما زال قيد الإعداد.', 'info');
        } else {
          output.innerHTML = `<p class="help">النتيجة: ${Number(result.passed || 0)} من ${Number(result.total || 4)} لغات نجحت.</p>` + (result.results || []).map(item => `<div class="tts-readiness-row"><span class="tts-readiness-mark ${item.passed ? 'ready' : ''}">${item.passed ? '✓' : '!'}</span><span><b>${esc(item.name || item.language)}</b><small>${esc(item.message || '')}${item.transcript ? `<br>النص المفرغ: ${esc(item.transcript)}` : ''}</small></span><b>${item.passed ? 'نجح' : 'فشل'}</b></div>`).join('');
          notify(result.message || 'اكتمل اختبار اللغات الأربع.', result.ready ? 'success' : 'error');
        }
        await refreshTtsStatus(); await refreshTranscriptionStatus();
      } catch (error) { output.innerHTML = `<p class="help">فشل اختبار اللغات: ${esc(error.message || 'خطأ غير معروف')}</p>`; notify(error.message, 'error'); }
      finally { button.disabled = false; button.classList.remove('loading'); }
    });
    await refreshTtsStatus();
    if (window.__chatBotVoiceStatusPoll) clearInterval(window.__chatBotVoiceStatusPoll);
    window.__chatBotVoiceStatusPoll = setInterval(async () => {
      if (document.hidden || !$('#transcriptionStatus') || !$('#ttsStatus')) return;
      try {
        const runtime = await api('/api/voice/runtime-status');
        if (runtime.state === 'preparing') {
          const message = `${runtime.stage || 'إعداد الصوت'} (${Math.round(Number(runtime.progress) || 0)}٪) — ${runtime.message || 'جارٍ تجهيز محركات الصوت تلقائيًا.'}`;
          $('#transcriptionStatus').textContent = message;
          $('#ttsStatus').textContent = message;
        } else if (runtime.state === 'ready' || (runtime.state === 'failed' && !runtime.retryScheduled)) {
          clearInterval(window.__chatBotVoiceStatusPoll); window.__chatBotVoiceStatusPoll = null;
          await refreshTranscriptionStatus(); await refreshTtsStatus();
        } else if (runtime.state === 'failed' && runtime.retryScheduled) {
          const message = `${runtime.stage || 'سيعاد إعداد الصوت تلقائيًا'} — ${runtime.message || ''}`;
          $('#transcriptionStatus').textContent = message;
          $('#ttsStatus').textContent = message;
        }
      } catch { /* Status polling is advisory; never block the main dashboard. */ }
    }, 12000);
    $('#transcribeUploadBtn')?.addEventListener('click', async () => {
      const file = $('#transcriptionFile')?.files?.[0];
      if (!file) return notify('اختر ملفًا صوتيًا من جهازك أولًا.', 'error');
      const button = $('#transcribeUploadBtn'); button?.classList.add('loading');
      const form = new FormData(); form.append('file', file); form.append('language', $('#transcriptionLanguage')?.value || 'auto');
      try { const result = await api('/api/transcription/upload', { method: 'POST', body: form }); if (transcriptOutput) transcriptOutput.value = result.transcript || ''; const quality = showTranscriptQuality(result); notify(result.message || 'اكتمل التفريغ.', quality.status === 'clear' ? 'success' : 'warning'); }
      catch (error) { notify(error.message, 'error'); if (transcriptionStatus) transcriptionStatus.textContent = error.message; if (transcriptQualityStatus) transcriptQualityStatus.textContent = 'لم يكتمل التفريغ؛ لم تتوفر نتيجة جودة.'; }
      finally { button?.classList.remove('loading'); }
    });
    $('#transcribeLatestBtn')?.addEventListener('click', async () => {
      const button = $('#transcribeLatestBtn'); button?.classList.add('loading');
      try { const result = await api('/api/transcription/transcribe-latest', { method: 'POST', body: JSON.stringify({ sessionId: sid(), language: $('#transcriptionLanguage')?.value || 'auto' }) }); if (transcriptOutput) transcriptOutput.value = result.transcript || ''; const quality = showTranscriptQuality(result); notify(result.message || 'اكتمل تفريغ صوتية WhatsApp.', quality.status === 'clear' ? 'success' : 'warning'); }
      catch (error) { notify(error.message, 'error'); if (transcriptionStatus) transcriptionStatus.textContent = error.message; }
      finally { button?.classList.remove('loading'); }
    });
    $('#copyTranscriptBtn')?.addEventListener('click', async () => { const value = transcriptOutput?.value || ''; if (!value) return notify('لا يوجد نص لنسخه بعد.', 'warning'); try { await navigator.clipboard.writeText(value); notify('تم نسخ النص إلى الحافظة.', 'success'); } catch { if (transcriptOutput) { transcriptOutput.focus(); transcriptOutput.select(); } notify('حدد النص وانسخه يدويًا باستخدام Ctrl+C.', 'info'); } });
    $('#useTranscriptForCommandBtn')?.addEventListener('click', () => { const text = transcriptOutput?.value.trim() || ''; if (!text) return notify('فرّغ الصوت أولًا.', 'warning'); const input = $('#voiceTranscript'); if (input) input.value = text.slice(0, 1000); $('#voiceParseBtn')?.click(); $('#voiceTranscript')?.scrollIntoView({ behavior: 'smooth', block: 'center' }); });
  }

  function currentTargetKeys() {
    return $$('.target:checked').map((input) => input.value);
  }

  function selectedMediaIds() {
    return $$('.send-media:checked').map((input) => input.value);
  }

  async function bindSend() {
    await loadCountries().then(() => {
      const country = $('#recipientCountry');
      if (country) country.innerHTML = countryOptions(country.value || 'OM');
    }).catch(() => {});
    $$('.target').forEach((checkbox) => checkbox.addEventListener('change', () => { state.pendingTargets = currentTargetKeys(); persistPendingTargets(); }));
    $('#selectAllTargets')?.addEventListener('click', () => { $$('.target').forEach((input) => { input.checked = true; }); state.pendingTargets = currentTargetKeys(); persistPendingTargets(); });
    $('#clearTargets')?.addEventListener('click', () => { $$('.target').forEach((input) => { input.checked = false; }); state.pendingTargets = []; persistPendingTargets(); });
    $('#mediaFiles')?.addEventListener('change', uploadMediaFiles);
    const dropZone = $('#mediaDropZone');
    for (const name of ['dragenter','dragover']) dropZone?.addEventListener(name, event => { event.preventDefault(); event.stopPropagation(); dropZone.classList.add('drag-active'); });
    for (const name of ['dragleave','dragend']) dropZone?.addEventListener(name, event => { event.preventDefault(); event.stopPropagation(); if (!dropZone.contains(event.relatedTarget)) dropZone.classList.remove('drag-active'); });
    dropZone?.addEventListener('drop', event => { event.preventDefault(); event.stopPropagation(); dropZone.classList.remove('drag-active'); uploadFiles([...(event.dataTransfer?.files || [])]); });
    dropZone?.addEventListener('click', event => {
      if (event.target === dropZone || event.target.matches('small')) $('#mediaFiles')?.click();
    });
    dropZone?.addEventListener('keydown', event => { if (event.target === dropZone && ['Enter',' '].includes(event.key)) { event.preventDefault(); $('#mediaFiles')?.click(); } });
    $$('.send-media').forEach(input => input.addEventListener('change', () => {
      if (input.checked) state.selectedMedia.add(input.value); else state.selectedMedia.delete(input.value);
      updateMediaCount();
    }));
    $$('[data-deselect-media]').forEach(button => button.addEventListener('click', () => {
      const id = button.dataset.deselectMedia;
      state.selectedMedia.delete(id);
      const input = $$('.send-media').find(item => item.value === id); if (input) input.checked = false;
      updateMediaCount(); notify('تمت إزالة الملف من قائمة الإرسال فقط؛ ما زال محفوظًا في المكتبة.', 'success');
    }));
    $$('[data-delete-media]').forEach(button => button.addEventListener('click', async event => {
      event.preventDefault();
      if (!confirm('سيُحذف الملف من مكتبة هذه الجلسة، وقد يُزال من المواعيد التي تستخدمه. هل تريد المتابعة؟')) return;
      try { await api(`/api/media/${encodeURIComponent(button.dataset.deleteMedia)}`, { method:'DELETE', body:JSON.stringify({ sessionId:sid() }) }); state.selectedMedia?.delete(button.dataset.deleteMedia); await load(true); }
      catch (error) { notify(error.message, 'error'); }
    }));
    $('#clearSendText')?.addEventListener('click', () => { ['sendText','sendPreText','sendPostText'].forEach(id => { if ($('#'+id)) $('#'+id).value = ''; }); state.assistantDraft = ''; notify('تم مسح نصوص الإرسال.', 'success'); });
    $('#sendText')?.addEventListener('input', event => { state.assistantDraft = event.target.value; });
    $('#sendNowBtn')?.addEventListener('click', sendNow);
    $('#mediaSearch')?.addEventListener('input', applyMediaFilters);
    $('#mediaTypeFilter')?.addEventListener('change', applyMediaFilters);
    $('#mediaSort')?.addEventListener('change', applyMediaFilters);
    $('#selectAllMedia')?.addEventListener('click', () => {
      const visible = $$('.media-card:not([hidden])');
      for (const card of visible) { const input = $('.send-media', card); if (input) { input.checked = true; state.selectedMedia.add(input.value); } }
      updateMediaCount(); applyMediaFilters();
      notify(`تم تحديد ${visible.length} ملف ظاهر؛ الملفات المخفية لم تتغير.`, 'success');
    });
    $('#clearMediaSelection')?.addEventListener('click', () => { state.selectedMedia.clear(); $$('.send-media').forEach(input => { input.checked = false; }); updateMediaCount(); applyMediaFilters(); });
    loadTextPreviews(); updateMediaCount(); applyMediaFilters(); bindSchedule();
  }

  function updateMediaCount() {
    const label = $('#sendMediaCount'); if (label) label.textContent = `${selectedMediaIds().length} محدد للإرسال`;
    const status = $('#mediaSearchStatus'); if (status) { const shown = $$('.media-card:not([hidden])').length; status.textContent = `الظاهر ${shown} من ${(state.data?.media || []).length} ملف · المحدد للإرسال ${selectedMediaIds().length}`; }
  }

  async function uploadMediaFiles(event) {
    await uploadFiles([...(event.target.files || [])]);
    event.target.value = '';
  }

  async function uploadFiles(files) {
    const selectedFiles = [...(files || [])].filter(Boolean);
    if (!selectedFiles.length) return;
    const priorSelection = new Set(state.selectedMedia);
    const form = new FormData(); selectedFiles.forEach(file => form.append('files', file, file.name));
    form.append('sessionId', sid()); form.append('replaceDuplicates', $('#replaceDuplicates')?.checked ? 'true' : 'false');
    const status = $('#uploadStatus'); if (status) status.textContent = `جارٍ رفع ${selectedFiles.length} ملف…`;
    const input = $('#mediaFiles'); if (input) input.disabled = true;
    try {
      const result = await api('/api/media', { method: 'POST', body: form });
      state.selectedMedia = priorSelection;
      const savedCount = Array.isArray(result.saved) ? result.saved.length : 0;
      const duplicateCount = Array.isArray(result.duplicates) ? result.duplicates.length : 0;
      const rejected = Array.isArray(result.rejected) ? result.rejected : [];
      const detail = rejected.slice(0, 4).map(item => `${item.filename || 'ملف'}: ${item.error || 'مرفوض'}`).join(' | ');
      if (status) status.textContent = `حُفظ ${savedCount} · مكرر ${duplicateCount} · مرفوض ${rejected.length}. الملفات الجديدة لم تُحدد للإرسال تلقائيًا.` + (detail ? ` ${detail}` : '');
      notify(`${result.message || `تم رفع ${savedCount} ملف`}${rejected.length ? ` المرفوض: ${rejected.length}` : ''}${duplicateCount ? ` المكرر: ${duplicateCount}` : ''}. الملفات الجديدة غير محددة للإرسال حتى تختارها.`, rejected.length || duplicateCount ? 'warning' : 'success');
      await load(true);
    } catch (error) { if (status) status.textContent = error.message; notify(error.message, 'error'); }
    finally { if (input) input.disabled = false; }
  }

  async function sendNow() {
    const targets = currentTargetKeys();
    const mediaIds = selectedMediaIds();
    const text = String($('#sendText')?.value || '').trim();
    const extraPreText = String($('#sendPreText')?.value || '').trim();
    const defaultPreText = String($('#defaultPreText')?.value || '').trim();
    // The old default was the literal brand label "chat BOT", which accidentally
    // overrode the message the user typed. Combine actual user-entered text first.
    const preText = [extraPreText, text].filter(Boolean).join('\n') || (mediaIds.length ? defaultPreText : '');
    const postText = String($('#sendPostText')?.value || '').trim();
    if (!targets.length) return notify('حدد شخصًا أو مجموعة واحدة على الأقل.', 'error');
    if (!preText.trim() && !postText.trim() && !mediaIds.length) return notify('اكتب رسالة أو اختر ملفًا.', 'error');
    if (mediaIds.length) {
      const fileRows = mediaIds.map(id => (state.data?.media || []).find(item => String(item.id || item.filename) === String(id))).filter(Boolean);
      if (fileRows.length !== mediaIds.length) return notify('تغيّرت قائمة الملفات؛ حدّث المكتبة وأعد الاختيار.', 'error');
      if ($('#mediaMode')?.value === 'sticker' && fileRows.some(item => !item.isImage || Number(item.size) > 16 * 1024 * 1024)) return notify('وضع الملصق يقبل الصور فقط، ويشترط ألا يتجاوز كل ملف 16 MB. لم يتم إرسال أي ملف.', 'error');
      const targetLabels = targets.map(key => {
        const [kind, id] = String(key).split(':');
        const list = kind === 'g' ? (state.data?.groups || []) : (state.data?.recipients || []);
        const found = list.find(item => String(item.id) === id);
        return found?.name || found?.displayName || found?.localName || found?.gid || id;
      });
      const fileNames = fileRows.slice(0, 12).map(item => `• ${item.filename || item.id}`).join('\n');
      const extraFiles = fileRows.length > 12 ? `\n… و${fileRows.length - 12} ملف إضافي` : '';
      const targetNames = targetLabels.slice(0, 8).join('، ') + (targetLabels.length > 8 ? `، و${targetLabels.length - 8} جهات أخرى` : '');
      const confirmation = `تأكيد إرسال الوسائط\n\nالملفات: ${fileRows.length}\n${fileNames}${extraFiles}\n\nالأهداف (${targets.length}): ${targetNames}\n\nسيتم إرسال الملفات الفعلية إلى الأهداف المحددة. تأكد من نوع الملف وخصوصية المستلمين قبل المتابعة. هل تريد الإرسال الآن؟`;
      if (!confirm(confirmation)) return notify('تم إلغاء الإرسال قبل إرسال أي ملف.', 'info');
    }
    try {
      const result = await api('/api/send', { method: 'POST', body: JSON.stringify({
        sessionId: sid(), targetKeys: targets, text: '', preText, postText, mediaIds, confirmedMediaSend: mediaIds.length > 0,
        sendOrder: $('#sendOrder')?.value || 'target-first', mediaMode: $('#mediaMode')?.value || 'media', captionWithMedia: $('#captionWithMedia')?.checked === true, repeatGuard: $('#repeatGuard')?.value !== 'off', replaceDuplicate: $('#replaceSendDuplicate')?.checked === true
      }) });
      const failed = Array.isArray(result.failed) ? result.failed : [];
      const sentCount = Number.isFinite(Number(result.sentCount)) ? Number(result.sentCount) : (Array.isArray(result.sent) ? result.sent.length : 0);
      // Only transient failures may be preselected for a retry. Permission,
      // rate-limit, duplicate-guard and uncertain outcomes require user review first.
      const failedKeys = [...new Set(failed.filter(item => item.targetId && item.retryable === true && item.code !== 'SEND_UNCERTAIN').map(item => `${item.kind === 'group' ? 'g' : 'r'}:${item.targetId}`))];
      state.pendingTargets = failedKeys; persistPendingTargets();
      const details = failed.slice(0, 4).map(item => `${item.target || 'مستلم'}: ${item.error || 'تعذر الإرسال'}`).join(' | ');
      const hasNeedsReview = failed.some(item => item.retryable !== true || item.code === 'SEND_UNCERTAIN');
      const summary = result.message || `تمت ${sentCount} عملية إرسال${failed.length ? `، وفشلت ${failed.length}` : ''}.`;
      const review = hasNeedsReview ? ' الأخطاء غير القابلة لإعادة المحاولة لم تُحدّد تلقائيًا؛ راجعها قبل محاولة جديدة.' : '';
      notify(details ? `${summary} ${details}${review}` : `${summary}${review}`, failed.length ? 'warning' : 'success');
      await load(true);
    } catch (error) { notify(error.message, 'error'); }
  }

  function bindSchedule() {
    $('#scheduleMode')?.addEventListener('change', (event) => {
      const value = event.target.value;
      $('.schedule-date')?.toggleAttribute('hidden', value !== 'once');
      $('.schedule-day')?.toggleAttribute('hidden', value !== 'weekly');
      $('.schedule-dom')?.toggleAttribute('hidden', !['monthly', 'yearly'].includes(value));
      $('.schedule-month')?.toggleAttribute('hidden', value !== 'yearly');
    });
    $$('[data-delete-task]').forEach((button) => button.addEventListener('click', async () => {
      try { await api(`/api/automation/task/${encodeURIComponent(button.dataset.deleteTask)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); }
    }));
    $$('[data-toggle-task]').forEach((button) => button.addEventListener('click', async () => {
      try { await api(`/api/automation/task/${encodeURIComponent(button.dataset.toggleTask)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); }
    }));
    $$('[data-run-task]').forEach((button) => button.addEventListener('click', async () => {
      try { const result = await api(`/api/automation/task/${encodeURIComponent(button.dataset.runTask)}/run`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم التشغيل.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    }));
    $$('[data-edit-task]').forEach((button) => button.addEventListener('click', () => loadTaskIntoEditor(button.dataset.editTask)));
    $('#scheduleBtn')?.addEventListener('click', createOrUpdateTask);
    $('#cancelScheduleEditBtn')?.addEventListener('click', () => { state.editingTaskId = null; render(); });
  }

  async function loadTaskIntoEditor(taskId) {
    const task = (state.data?.automation?.tasks || []).find((item) => item.id === taskId);
    if (!task) return notify('الموعد غير موجود.', 'error');
    $('#scheduleName').value = task.name || '';
    $('#scheduleTime').value = task.time || '17:30';
    $('#scheduleMode').value = task.mode || 'weekly';
    $('#scheduleDate').value = task.date || '';
    $('#scheduleDay').value = String(task.day ?? 5);
    $('#scheduleDayOfMonth').value = String(task.dayOfMonth ?? 1);
    $('#scheduleMonth').value = String(task.month || 1);
    $('#scheduleText').value = task.preText || '';
    $('#schedulePostText').value = task.postText || '';
    $('#scheduleMediaMode').value = task.mediaMode || 'selected';
    if ($('#mediaMode')) $('#mediaMode').value = task.deliveryMediaMode || 'media';
    if ($('#captionWithMedia')) $('#captionWithMedia').checked = task.captionWithMedia === true;
    $('#scheduleGroupsEnabled').checked = task.scheduledGroupsEnabled !== false;
    state.editingTaskId = task.id;
    if ($('#sendScheduleDisclosure')) { $('#sendScheduleDisclosure').open = true; $('#sendScheduleDisclosure').scrollIntoView({ behavior: 'smooth', block: 'center' }); }
    const scheduleButton = $('#scheduleBtn'); if (scheduleButton) scheduleButton.textContent = 'حفظ تعديل الموعد';
    const cancelButton = $('#cancelScheduleEditBtn'); if (cancelButton) cancelButton.hidden = false;
    state.pendingTargets = Array.isArray(task.targetKeys) ? [...task.targetKeys] : []; persistPendingTargets();
    $$('.target').forEach((input) => { input.checked = state.pendingTargets.includes(input.value); });
    state.selectedMedia = new Set((task.mediaIds || []).map(String));
    $$('.send-media').forEach((input) => { input.checked = state.selectedMedia.has(input.value); });
    updateMediaCount();
    notify('تم تحميل الموعد للتعديل. عدّل ثم اضغط حفظ.', 'info');
  }

  async function createOrUpdateTask() {
    const targets = currentTargetKeys();
    const mediaIds = selectedMediaIds();
    const mode = $('#scheduleMode').value;
    const text = $('#scheduleText').value.trim() || $('#sendText')?.value.trim() || '';
    if (!targets.length) return notify('حدد أهداف الموعد.', 'error');
    if (!text && !mediaIds.length && $('#scheduleMediaMode').value !== 'cycle') return notify('أضف نصًا أو ملفًا للموعد.', 'error');
    const payload = {
      sessionId: sid(), name: $('#scheduleName').value.trim() || 'موعد جديد', mode, time: $('#scheduleTime').value,
      date: $('#scheduleDate').value, day: Number($('#scheduleDay').value), dayOfMonth: Number($('#scheduleDayOfMonth').value), month: Number($('#scheduleMonth').value),
      targetKeys: targets, mediaIds, mediaMode: $('#scheduleMediaMode').value, deliveryMediaMode: $('#mediaMode')?.value || 'media', captionWithMedia: $('#captionWithMedia')?.checked === true, preText: text, postText: $('#schedulePostText').value.trim(), sendOrder: $('#sendOrder')?.value || 'target-first',
      scheduledGroupsEnabled: $('#scheduleGroupsEnabled').checked
    };
    try {
      const url = state.editingTaskId ? `/api/automation/task/${encodeURIComponent(state.editingTaskId)}` : '/api/automation/task';
      const method = state.editingTaskId ? 'PUT' : 'POST';
      const result = await api(url, { method, body: JSON.stringify(payload) });
      notify(result.message || 'تم حفظ الموعد.', 'success');
      state.editingTaskId = null;
      await load(true);
    } catch (error) { notify(error.message, 'error'); }
  }

  function bindAutomation() {
    $('#automationRuleForm')?.addEventListener('submit', async (event) => {
      event.preventDefault();
      const triggerType = $('#autoRuleTrigger').value;
      const targetMode = $('#autoRuleTargetMode').value;
      const action = triggerType === 'message-age' ? 'cleanup-old-messages' : $('#autoRuleAction').value;
      const payload = {
        sessionId: sid(), name: $('#autoRuleName').value.trim(), priority: Number($('#autoRulePriority').value || 0), triggerType,
        matchMode: $('#autoRuleMatch').value, pattern: $('#autoRulePattern').value,
        action, targetMode, targetKeys: $$('.automation-target:checked').map(input => input.value),
        targetChatIds: $('#autoRuleChatIds').value.split(/[\n,;\s]+/).map(x => x.trim()).filter(Boolean),
        cooldownSec: Number($('#autoRuleCooldown').value || 0), threshold: Number($('#autoRuleThreshold').value || 50),
        countScope: $('#autoRuleCountScope').value, ageHours: Number($('#autoRuleAgeHours').value || 24),
        time: $('#autoRuleTime').value || '22:00', mode: $('#autoRuleMode').value, date: $('#autoRuleDate').value,
        day: Number($('#autoRuleDay').value), dayOfMonth: Number($('#autoRuleDayOfMonth').value || 1), month: Number($('#autoRuleMonth').value || 1), timezone: state.data?.settings?.timezone || 'Asia/Muscat',
        minMessageCount: Number($('#autoRuleMinCount').value || 0), maxMessageCount: Number($('#autoRuleMaxCount').value || 0), conditionContains: $('#autoRuleConditionContains').value.trim(),
        repeatCount: $('#autoRuleRepeatCount').checked, requireGroupAdmin: $('#autoRuleRequireAdmin').checked,
        deleteForEveryone: $('#autoRuleDeleteEveryone').checked, confirmDestructive: $('#autoRuleConfirmDestructive').checked,
        mutePermanent: $('#autoRuleMutePermanent').checked, muteMinutes: Number($('#autoRuleMuteMinutes').value || 60),
      };
      if (['time','message-age'].includes(triggerType) && payload.targetMode === 'current' && action !== 'log') return notify('اختر أهدافًا محددة أو كل الأهداف للقاعدة المجدولة.', 'error');
      if (triggerType === 'message-age' && !payload.confirmDestructive) return notify('أكد إجراء تنظيف الرسائل القديمة قبل الحفظ.', 'error');
      if (payload.mode === 'once' && !payload.date) return notify('اختر تاريخ تشغيل القاعدة.', 'error');
      try {
        const editing = state.editingAutomationRuleId;
        const result = await api(editing ? `/api/automation/rules/${encodeURIComponent(editing)}` : '/api/automation/rules', { method: editing ? 'PUT' : 'POST', body: JSON.stringify(payload) });
        state.editingAutomationRuleId = '';
        notify(result.message || 'تم حفظ قاعدة الأتمتة.', 'success');
        await load(true);
      } catch (error) { notify(error.message, 'error'); }
    });
    $('#autoRuleTrigger')?.addEventListener('change', () => {
      const trigger = $('#autoRuleTrigger').value;
      if (trigger === 'message-age') $('#autoRuleAction').value = 'cleanup-old-messages';
      if (['time','message-age'].includes(trigger) && $('#autoRuleTargetMode').value === 'current') $('#autoRuleTargetMode').value = 'selected';
      if (trigger === 'group-message') $('#autoRuleRequireAdmin').checked = true;
    });
    $('#autoRuleTargetMode')?.addEventListener('change', () => {
      const mode = $('#autoRuleTargetMode').value;
      const trigger = $('#autoRuleTrigger').value;
      if (['time','message-age'].includes(trigger) && mode === 'current') notify('القاعدة المجدولة تحتاج أهدافًا محددة أو كل الأهداف.', 'info');
    });
    $('#cancelAutoRuleEdit')?.addEventListener('click', () => { state.editingAutomationRuleId = ''; render(); });
    $$('[data-edit-auto-rule]').forEach(button => button.addEventListener('click', () => { state.editingAutomationRuleId = button.dataset.editAutoRule; render(); $('#automationRuleForm')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }));
    $$('[data-toggle-auto-rule]').forEach(button => button.addEventListener('click', async () => { try { await api(`/api/automation/rules/${encodeURIComponent(button.dataset.toggleAutoRule)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-auto-rule]').forEach(button => button.addEventListener('click', async () => { if (!confirm('حذف قاعدة الأتمتة نهائيًا؟')) return; try { await api(`/api/automation/rules/${encodeURIComponent(button.dataset.deleteAutoRule)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); if (state.editingAutomationRuleId === button.dataset.deleteAutoRule) state.editingAutomationRuleId = ''; await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-run-auto-rule]').forEach(button => button.addEventListener('click', async () => { if (!confirm('تنفيذ الإجراء الآن على الأهداف المحددة؟ قد يؤدي ذلك إلى حذف بيانات أو تغيير حالة المحادثة.')) return; try { const result = await api(`/api/automation/rules/${encodeURIComponent(button.dataset.runAutoRule)}/run`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم التنفيذ.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $('#saveAutomationPermissions')?.addEventListener('click', async () => { const payload = { sessionId: sid() }; $$('.automation-permission').forEach(input => { payload[input.dataset.permission] = input.checked; }); try { const result = await api('/api/automation/group-permissions', { method: 'POST', body: JSON.stringify(payload) }); notify(result.message || 'تم الحفظ.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#muteSavedTarget')?.addEventListener('change', () => { if ($('#muteSavedTarget').value) $('#muteChatId').value = $('#muteSavedTarget').value; });
    $('#muteMode')?.addEventListener('change', () => { $('#muteMinutes').disabled = $('#muteMode').value === 'permanent'; });
    $('#automationMuteForm')?.addEventListener('submit', async (event) => { event.preventDefault(); const chatId = $('#muteChatId').value.trim(); const mode = $('#muteMode').value; if (!chatId) return notify('أدخل معرّف المحادثة.', 'error'); if (mode === 'permanent' && !confirm('سيظل الكتم قائمًا حتى تلغيه يدويًا. هل تريد المتابعة؟')) return; try { const target = activeTargets(state.data || {}).find(t => chatIdForTarget(t) === chatId); const result = await api('/api/automation/mutes', { method: 'POST', body: JSON.stringify({ sessionId: sid(), chatId, chatName: target?.name || chatId, mode, minutes: Number($('#muteMinutes').value || 60) }) }); notify(result.message || 'تم تطبيق الكتم.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $$('[data-unmute-record]').forEach(button => button.addEventListener('click', async () => { if (!confirm('إلغاء كتم هذه المحادثة؟')) return; try { const result = await api(`/api/automation/mutes/${encodeURIComponent(button.dataset.unmuteRecord)}/unmute`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم إلغاء الكتم.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-mute]').forEach(button => button.addEventListener('click', async () => { if (!confirm('حذف إعداد الكتم؟ إذا كان نشطًا سيُلغى الكتم أولًا.')) return; try { const result = await api(`/api/automation/mutes/${encodeURIComponent(button.dataset.deleteMute)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم حذف السجل.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $('#refreshAutomationBtn')?.addEventListener('click', () => load(true).catch(e => notify(e.message, 'error')));
  }

  function bindPeopleSearch() {}
  function bindGroupSearch() {}

  function bindPeople() {
    loadCountries().then(() => {
      const country = $('#recipientCountry');
      if (country) country.innerHTML = countryOptions(country.value || 'OM');
    }).catch(() => {});
    $('#recipientPhone')?.addEventListener('blur', async () => {
      const value = $('#recipientPhone').value.trim();
      if (!value) return;
      try { const result = await api('/api/phone/validate', { method: 'POST', body: JSON.stringify({ phone: value, country: $('#recipientCountry').value }) }); $('#phonePreview').textContent = `سيُحفظ كـ ${result.phone?.international || result.phone?.e164 || 'رقم صالح'}`; } catch (error) { $('#phonePreview').textContent = error.message; }
    });
    $('#addRecipientBtn')?.addEventListener('click', async () => {
      try { const result = await api('/api/recipient', { method: 'POST', body: JSON.stringify({ sessionId: sid(), name: $('#recipientName').value.trim(), phone: $('#recipientPhone').value, country: $('#recipientCountry').value }) }); notify(`تمت إضافة ${result.recipient?.name || 'الشخص'}`, 'success'); await load(true); } catch (error) { notify(error.message, 'error'); }
    });
    $('#bulkAddBtn')?.addEventListener('click', async () => {
      try { const result = await api('/api/recipients/bulk', { method: 'POST', body: JSON.stringify({ sessionId: sid(), lines: $('#bulkRecipients').value, country: $('#recipientCountry').value }) }); notify(`أضيف ${result.added?.length || 0} رقم${result.failed?.length ? `، وتعذر ${result.failed.length}` : ''}`, result.failed?.length ? 'info' : 'success'); await load(true); } catch (error) { notify(error.message, 'error'); }
    });
    $('#loadWhatsAppContactsBtn')?.addEventListener('click', () => loadWhatsAppContacts());
    $('#syncWhatsAppProfilesBtn')?.addEventListener('click', async () => {
      const jids = [...state.whatsappContactsSelected];
      if (!jids.length) return notify('حدد جهات محفوظة لتحديث صورها.', 'warning');
      if (jids.length > 100) return notify('حد تحديث الصور 100 جهة في المرة الواحدة.', 'warning');
      const button = $('#syncWhatsAppProfilesBtn'); if (button) { button.disabled = true; button.textContent = 'جارٍ تحديث الصور…'; }
      try {
        const result = await api('/api/whatsapp/contacts/refresh-pictures', { method: 'POST', body: JSON.stringify({ sessionId: sid(), jids }) });
        notify(result.message || 'اكتمل تحديث الصور.', result.photosFailed ? 'info' : 'success');
        state.whatsappContactsSelected.clear();
        await load(true);
        state.whatsappContactsOpen = true;
        render();
        $('#whatsappContactsDisclosure')?.setAttribute('open', '');
      } catch (error) {
        notify(error.message, 'error');
        if (button) { button.disabled = false; button.textContent = 'تحديث صور المحدد'; }
      }
    });
    $('#whatsappContactFilter')?.addEventListener('input', event => {
      state.whatsappContactFilter = event.target.value;
      state.whatsappContactsPage = 1;
      refreshWhatsAppContactList();
    });
    const contactPagination = $('#whatsappContactsPagination');
    if (contactPagination && contactPagination.dataset.bound !== '1') {
      contactPagination.dataset.bound = '1';
      contactPagination.addEventListener('click', event => {
        const button = event.target.closest('button');
        if (!button || button.disabled) return;
        if (button.id === 'previousWhatsAppContactsPage') state.whatsappContactsPage = Math.max(1, Number(state.whatsappContactsPage || 1) - 1);
        else if (button.id === 'nextWhatsAppContactsPage') {
          const info = whatsappContactPageInfo();
          state.whatsappContactsPage = Math.min(info.pages, Number(state.whatsappContactsPage || 1) + 1);
        } else return;
        refreshWhatsAppContactList();
      });
      contactPagination.addEventListener('change', event => {
        if (event.target?.id !== 'whatsappContactPageSize') return;
        const value = Number(event.target.value);
        if (![25, 50, 100].includes(value)) return;
        state.whatsappContactsPageSize = value; state.whatsappContactsPage = 1;
        refreshWhatsAppContactList();
      });
    }
    $('#selectAllWhatsAppContacts')?.addEventListener('click', () => {
      whatsappContactPageInfo().visible.forEach(contact => state.whatsappContactsSelected.add(contact.jid));
      refreshWhatsAppSelectionUI();
    });
    $('#clearWhatsAppContacts')?.addEventListener('click', () => { state.whatsappContactsSelected.clear(); refreshWhatsAppSelectionUI(); });
    $('#syncWhatsAppContactsBtn')?.addEventListener('click', async () => {
      const jids = [...state.whatsappContactsSelected];
      if (!jids.length) return notify('حدد جهات WhatsApp التي تريد مزامنتها.', 'warning');
      const pictures = $('#syncWhatsAppUpdatePictures')?.checked !== false;
      const max = pictures ? 100 : 500;
      if (jids.length > max) return notify(`حد هذه الدفعة ${max} جهة${pictures ? ' عند مزامنة الصور' : ''}. حدّد عددًا أقل ثم تابع بدفعات متعددة.`, 'warning');
      if (!confirm(`ستتم مزامنة ${jids.length} جهة إلى الجلسة الحالية. ${$('#syncWhatsAppUpdateNames')?.checked ? 'قد تتغير الأسماء المحلية حسب خيار التحديث.' : 'ستظل الأسماء المحلية الحالية كما هي.'} المتابعة؟`)) return;
      const button = $('#syncWhatsAppContactsBtn'); if (button) { button.disabled = true; button.textContent = 'جارٍ المزامنة…'; }
      try {
        const result = await api('/api/whatsapp/contacts/sync', { method: 'POST', body: JSON.stringify({ sessionId: sid(), jids, importMissing: true, updateNames: $('#syncWhatsAppUpdateNames')?.checked === true, updatePictures: pictures }) });
        const recipientIds = queueRecipientsForSending(result);
        state.whatsappContactsSelected.clear(); state.whatsappContactsOpen = true;
        notify(`${result.message || 'اكتملت إضافة جهات WhatsApp.'}${recipientIds.length ? ` تمت إضافتها/تحديثها في قائمة الإرسال (${recipientIds.length}).` : ''}`, 'success');
        await load(true);
      } catch (error) { notify(error.message, 'error'); if (button) { button.disabled = false; button.textContent = `إضافة المحدد إلى قائمة الإرسال (${jids.length})`; } }
    });
    bindWhatsAppContactCheckboxes();
    bindWhatsAppContactImportButtons();
    $('#selectVisiblePeople')?.addEventListener('change', event => {
      const ids = $$('.person-select').map(box => String(box.dataset.personSelect));
      if (event.target.checked) ids.forEach(id => state.selectedRecipientIds.add(id)); else ids.forEach(id => state.selectedRecipientIds.delete(id));
      updatePeopleSelection();
    });
    $('#deleteSelectedPeopleBtn')?.addEventListener('click', async () => {
      const ids = [...state.selectedRecipientIds];
      if (!ids.length) return notify('حدد شخصًا واحدًا على الأقل.', 'warning');
      if (!confirm(`سيُحذف ${ids.length} شخصًا من الجلسة الحالية، وستُنظف أهدافهم المرتبطة بالجدولة والأتمتة. لا يمكن التراجع عن الحذف من داخل التطبيق. متابعة؟`)) return;
      try {
        const result = await api('/api/recipients/bulk', { method: 'DELETE', body: JSON.stringify({ sessionId: sid(), ids }) });
        for (const id of (result.removedIds || ids)) state.selectedRecipientIds.delete(String(id));
        notify(result.message || `تم حذف ${result.deleted?.length || 0} شخصًا.`, 'success');
        await load(true);
      } catch (error) { notify(error.message, 'error'); }
    });
    $('#peopleSearch')?.addEventListener('input', (event) => { state.peopleFilter = event.target.value; clearTimeout(bindPeopleSearch.timer); bindPeopleSearch.timer = setTimeout(() => { const list = $('.people-list'); if (list) { const filter = state.peopleFilter.trim().toLocaleLowerCase('ar'); const rows = (state.data?.recipients || []).filter((item) => `${item.name || ''} ${item.international || ''} ${item.e164 || ''}`.toLocaleLowerCase('ar').includes(filter)); list.innerHTML = rows.length ? rows.map(personRow).join('') : '<div class="empty">لا توجد نتائج.</div>'; bindPeopleRows(); } }, 120); });
    bindPeopleRows();
  }

  async function loadWhatsAppContacts({ refresh = false } = {}) {
    if (state.whatsappContactsBusy) return;
    state.whatsappContactsOpen = true; state.whatsappContactsBusy = true;
    const status = $('#whatsappContactsStatus'); if (status) status.textContent = 'جارٍ استدعاء جهات WhatsApp من الجلسة المتصلة…';
    const button = $('#loadWhatsAppContactsBtn'); if (button) { button.disabled = true; button.textContent = 'جارٍ الاستدعاء…'; }
    try {
      const result = await api(`/api/whatsapp/contacts?sessionId=${encodeURIComponent(sid())}${refresh ? '&refresh=1' : ''}`);
      state.whatsappContacts = Array.isArray(result.contacts) ? result.contacts : [];
      state.whatsappContactsSession = sid(); state.whatsappContactsSelected.clear(); state.whatsappContactFilter = ''; state.whatsappContactsPage = 1;
      notify(result.message || `تم استدعاء ${state.whatsappContacts.length} جهة.`, 'success');
    } catch (error) {
      state.whatsappContacts = null;
      notify(error.message, 'error');
    } finally {
      state.whatsappContactsBusy = false;
      render();
      if (state.page === 'people') { $('#whatsappContactsDisclosure')?.setAttribute('open', ''); bindWhatsAppContactCheckboxes(); bindWhatsAppContactImportButtons(); }
    }
  }

  function queueRecipientsForSending(result) {
    const ids = [...new Set([...(result?.imported || []), ...(result?.updated || [])].map(person => String(person.id || '')).filter(Boolean))];
    // null means "select every recipient" in the send view. After an explicit
    // import action, switch to a deliberate selection instead of accidentally
    // targeting every saved contact when the user only added one from WhatsApp.
    const previous = Array.isArray(state.pendingTargets) ? state.pendingTargets : [];
    state.pendingTargets = [...new Set([...previous, ...ids.map(id => `r:${id}`)])]; persistPendingTargets();
    return ids;
  }

  function bindWhatsAppContactImportButtons() {
    $$('[data-import-wa-contact]').forEach(button => {
      if (button.dataset.bound === '1') return;
      button.dataset.bound = '1';
      button.addEventListener('click', async () => {
        const jid = String(button.dataset.importWaContact || '').trim().toLowerCase();
        if (!/^\d{5,25}@c\.us$/.test(jid)) return notify('معرّف جهة غير صالح. أعد استدعاء قائمة WhatsApp.', 'error');
        const label = button.textContent;
        button.disabled = true; button.textContent = 'جارٍ الإضافة…';
        try {
          const result = await api('/api/whatsapp/contact/import', { method: 'POST', body: JSON.stringify({ sessionId: sid(), jid }) });
          const ids = queueRecipientsForSending({ imported: result.imported, updated: result.updated });
          state.whatsappContactsSelected.delete(jid); state.whatsappContactsOpen = true;
          notify(`${result.message || 'تمت إضافة جهة WhatsApp.'}${ids.length ? ` أصبحت ضمن قائمة الإرسال (${ids.length}).` : ''}`, 'success');
          await load(true);
          // Keep the retrieved list visible so the user can add more contacts without repeating the query.
          $('#whatsappContactsDisclosure')?.setAttribute('open', '');
          bindWhatsAppContactCheckboxes(); bindWhatsAppContactImportButtons();
        } catch (error) { notify(error.message, 'error'); button.disabled = false; button.textContent = label; }
      });
    });
  }

  function bindWhatsAppContactCheckboxes() {
    $$('[data-wa-contact-select]').forEach(box => {
      if (box.dataset.bound === '1') return;
      box.dataset.bound = '1';
      box.addEventListener('change', () => {
        const jid = String(box.dataset.waContactSelect || '');
        if (box.checked) state.whatsappContactsSelected.add(jid); else state.whatsappContactsSelected.delete(jid);
        refreshWhatsAppSelectionUI();
      });
    });
  }

  function refreshWhatsAppSelectionUI() {
    $$('[data-wa-contact-select]').forEach(box => { box.checked = state.whatsappContactsSelected.has(String(box.dataset.waContactSelect || '')); });
    const count = $('#whatsappSelectedCount'); if (count) count.textContent = String(state.whatsappContactsSelected.size);
    const button = $('#syncWhatsAppContactsBtn'); if (button) { button.disabled = state.whatsappContactsSelected.size === 0; button.textContent = `إضافة المحدد إلى قائمة الإرسال (${state.whatsappContactsSelected.size})`; }
    const photoButton = $('#syncWhatsAppProfilesBtn'); if (photoButton) photoButton.disabled = state.whatsappContactsSelected.size === 0 || state.whatsappContactsBusy;
  }

  function updatePeopleSelection() {
    const selected = state.selectedRecipientIds.size;
    const visibleBoxes = $$('.person-select');
    const visibleSelected = visibleBoxes.filter(box => box.checked).length;
    const selectAll = $('#selectVisiblePeople');
    if (selectAll) { selectAll.checked = visibleBoxes.length > 0 && visibleSelected === visibleBoxes.length; selectAll.indeterminate = visibleSelected > 0 && visibleSelected < visibleBoxes.length; selectAll.disabled = visibleBoxes.length === 0; }
    const deleteButton = $('#deleteSelectedPeopleBtn');
    if (deleteButton) { deleteButton.disabled = selected === 0; deleteButton.textContent = `حذف المحدد (${selected})`; }
    const count = $('#peopleSelectedCount'); if (count) count.textContent = String(selected);
  }

  function bindPeopleRows() {
    $$('[data-avatar-open]').forEach(button => button.addEventListener('click', () => {
      const row = button.closest('[data-person-record]'); row?.querySelector('[data-avatar-file]')?.click();
    }));
    $$('[data-avatar-file]').forEach(input => input.addEventListener('change', async () => {
      const personId = String(input.dataset.avatarFile || ''), file = input.files?.[0];
      if (!personId || !file) return;
      const form = new FormData(); form.append('file', file, file.name); form.append('sessionId', sid());
      const button = input.closest('[data-person-record]')?.querySelector('[data-avatar-open]');
      if (button) { button.disabled = true; button.textContent = 'جارٍ الرفع…'; }
      try { await api(`/api/recipient/${encodeURIComponent(personId)}/avatar`, { method:'POST', body:form }); notify('تم حفظ الصورة المحلية وعرضها لهذا الشخص.', 'success'); await load(true); }
      catch (error) { notify(error.message, 'error'); if (button) { button.disabled = false; button.textContent = 'تغيير الصورة'; } }
      finally { input.value = ''; }
    }));
    $$('[data-reset-avatar]').forEach(button => button.addEventListener('click', async () => {
      const id = String(button.dataset.resetAvatar || ''); if (!id || button.disabled) return;
      try { await api(`/api/recipient/${encodeURIComponent(id)}/avatar`, { method:'DELETE', body:JSON.stringify({ sessionId:sid() }) }); notify('تمت إزالة الصورة المحلية؛ سيظهر وجه WhatsApp إذا كانت الصورة متاحة.', 'success'); await load(true); }
      catch (error) { notify(error.message, 'error'); }
    }));
    $$('.person-select').forEach((box) => box.addEventListener('change', () => {
      const id = String(box.dataset.personSelect || '');
      if (box.checked) state.selectedRecipientIds.add(id); else state.selectedRecipientIds.delete(id);
      updatePeopleSelection();
    }));
    $$('[data-toggle-person]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/recipient/${encodeURIComponent(button.dataset.togglePerson)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-person]').forEach((button) => button.addEventListener('click', async () => { if (!confirm('حذف الشخص من هذه الجلسة وتنظيف أهدافه المرتبطة؟')) return; try { await api(`/api/recipient/${encodeURIComponent(button.dataset.deletePerson)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); state.selectedRecipientIds.delete(String(button.dataset.deletePerson)); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-add-person-rule]').forEach(button => button.addEventListener('click', () => {
      const form = button.closest('form[data-person-reply-form]'); const list = form?.querySelector('[data-person-rules]');
      if (!form || !list) return;
      const existing = list.querySelectorAll('[data-person-rule-row]');
      if (existing.length >= 30) return notify('الحد الأقصى 30 قاعدة رد لكل شخص.', 'warning');
      list.querySelector('[data-person-rules-empty]')?.remove();
      list.insertAdjacentHTML('beforeend', personalRuleEditor({ id: `pr-${Date.now()}-${Math.random().toString(16).slice(2,7)}`, name: `قاعدة ${existing.length + 1}`, match: 'contains', value: '', reply: '', enabled: true }, existing.length));
      const counter = form.querySelector('[data-person-rule-count]'); if (counter) counter.textContent = String(existing.length + 1);
      bindPersonalRuleDeletes(list);
    }));
    $$('[data-person-reply-form]').forEach(form => form.addEventListener('submit', async event => {
      event.preventDefault();
      const personId = String(form.dataset.personReplyForm || '');
      const rules = [...form.querySelectorAll('[data-person-rule-row]')].map(row => ({
        id: row.dataset.ruleId || `pr-${Date.now()}-${Math.random().toString(16).slice(2,7)}`,
        name: row.querySelector('[data-person-rule-name]')?.value.trim() || '',
        match: row.querySelector('[data-person-rule-match]')?.value || 'contains',
        value: row.querySelector('[data-person-rule-value]')?.value || '',
        reply: row.querySelector('[data-person-rule-reply]')?.value || '',
        enabled: row.querySelector('[data-person-rule-enabled]')?.checked !== false,
      }));
      const profile = {
        mode: form.querySelector('[data-person-profile-mode]')?.value || 'inherit',
        enabled: form.querySelector('[data-person-profile-enabled]')?.checked !== false,
        fallbackToGlobal: form.querySelector('[data-person-profile-fallback]')?.checked !== false,
        defaultReply: form.querySelector('[data-person-profile-default]')?.value || '',
        cooldownSec: Number(form.querySelector('[data-person-profile-cooldown]')?.value || 45),
        rules,
      };
      try {
        const result = await api(`/api/recipient/${encodeURIComponent(personId)}/reply-profile`, { method: 'PUT', body: JSON.stringify({ sessionId: sid(), profile }) });
        notify(result.message || 'تم حفظ إعداد الرد الشخصي.', 'success'); await load(true);
      } catch (error) { notify(error.message, 'error'); }
    }));
    $$('[data-person-rules]').forEach(bindPersonalRuleDeletes);
    updatePeopleSelection();
  }

  function bindPersonalRuleDeletes(list) {
    $$('[data-delete-person-rule]', list).forEach(button => {
      if (button.dataset.boundDeleteRule === '1') return;
      button.dataset.boundDeleteRule = '1';
      button.addEventListener('click', () => {
        const form = button.closest('form');
        button.closest('[data-person-rule-row]')?.remove();
        const rules = form?.querySelector('[data-person-rules]');
        const remaining = rules?.querySelectorAll('[data-person-rule-row]').length || 0;
        if (rules && remaining === 0) rules.innerHTML = '<div class="empty" data-person-rules-empty>لا توجد قواعد شخصية؛ يمكن استخدام الرد الافتراضي أو القواعد العامة.</div>';
        const counter = form?.querySelector('[data-person-rule-count]'); if (counter) counter.textContent = String(remaining);
        if (rules) bindPersonalRuleDeletes(rules);
      });
    });
  }

  function bindGroups() {
    $('#connectGroupBtn')?.addEventListener('click', async () => {
      const value = $('#groupValue').value.trim();
      if (!value) return notify('أدخل GID أو رابط دعوة.', 'error');
      $('#groupResult').textContent = 'جاري الربط والتحليل…';
      try { const result = await api('/api/groups/connect', { method: 'POST', body: JSON.stringify({ sessionId: sid(), value }) }); state.selectedGroup = result.group?.gid || null; notify(result.message || 'تم الربط.', 'success'); await load(true); } catch (error) { $('#groupResult').textContent = error.message; notify(error.message, 'error'); }
    });
    $('#discoverGroupsBtn')?.addEventListener('click', async () => {
      try { const result = await api('/api/groups/discover', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم الاكتشاف.', 'success'); await load(true); } catch (error) { notify(error.message, 'error'); }
    });
    $('#refreshGroupsBtn')?.addEventListener('click', async () => {
      try { const result = await api('/api/groups/refresh-all', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم التحديث.', result.failed?.length ? 'info' : 'success'); await load(true); } catch (error) { notify(error.message, 'error'); }
    });
    $('#groupSearch')?.addEventListener('input', (event) => { state.groupFilter = event.target.value; clearTimeout(bindGroupSearch.timer); bindGroupSearch.timer = setTimeout(() => { const list = $('.group-list'); if (list) { const filter = state.groupFilter.trim().toLocaleLowerCase('ar'); const groups = (state.data?.groups || []).filter((group) => `${group.name || ''} ${group.gid || ''}`.toLocaleLowerCase('ar').includes(filter)); const current = state.selectedGroup && (state.data?.groups || []).find((group) => group.gid === state.selectedGroup); list.innerHTML = groups.length ? groups.map((group) => groupRow(group, current?.gid === group.gid)).join('') : '<div class="empty">لا توجد نتائج.</div>'; bindGroupRows(); } }, 120); });
    bindGroupRows();
  }

  function bindGroupRows() {
    $$('[data-show-group]').forEach((button) => button.addEventListener('click', () => { state.selectedGroup = button.dataset.showGroup; render(); }));
    $$('[data-send-group]').forEach((button) => button.addEventListener('click', () => { state.pendingTargets = [`g:${button.dataset.sendGroup}`]; persistPendingTargets(); go('send'); }));
    $$('[data-copy-group]').forEach((button) => button.addEventListener('click', async () => { try { await navigator.clipboard.writeText(button.dataset.copyGroup); notify('تم نسخ GID.', 'success'); } catch { notify('تعذر النسخ من المتصفح.', 'error'); } }));
    $$('[data-toggle-group]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/groups/${encodeURIComponent(button.dataset.toggleGroup)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-group]').forEach((button) => button.addEventListener('click', async () => { if (!confirm('حذف المجموعة من هذه الجلسة؟')) return; try { await api(`/api/groups/${encodeURIComponent(button.dataset.deleteGroup)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); state.selectedGroup = null; await load(true); } catch (e) { notify(e.message, 'error'); } }));
  }

  function applyRulePreset(name) {
    const presets = {
      welcome: { name:'ترحيب جديد', event:'message', match:'contains', value:'السلام عليكم', action:'reply', reply:'وعليكم السلام {{sender}} 👋', emoji:'' },
      help: { name:'مساعدة', event:'message', match:'contains', value:'مساعدة', action:'reply', reply:'اكتب كلمة أو أمرًا وسأرد حسب القواعد التي أنشأتها.', emoji:'' },
      reaction: { name:'تفاعل بالإعجاب', event:'reaction', match:'any', value:'', action:'reaction', reply:'', emoji:'👍' },
    };
    const p = presets[name]; if (!p) return;
    if ($('#ruleEditorDisclosure')) $('#ruleEditorDisclosure').open = true;
    if ($('#ruleName')) $('#ruleName').value=p.name; if ($('#ruleEvent')) $('#ruleEvent').value=p.event; if ($('#ruleMatch')) $('#ruleMatch').value=p.match; if ($('#ruleValue')) $('#ruleValue').value=p.value; if ($('#ruleAction')) $('#ruleAction').value=p.action; if ($('#ruleReply')) $('#ruleReply').value=p.reply; if ($('#ruleEmoji')) $('#ruleEmoji').value=p.emoji;
    $('#ruleAction')?.dispatchEvent(new Event('change')); $('#ruleEvent')?.dispatchEvent(new Event('change'));
    notify('تم تحميل القالب ويمكنك تعديله قبل الحفظ.', 'info');
  }

  function fillRuleForm(rule) {
    if (!rule) return;
    state.interactionEditingRule = rule.id;
    if ($('#ruleEditorDisclosure')) $('#ruleEditorDisclosure').open = true;
    $('#ruleEditorTitle').textContent = 'تعديل القاعدة';
    $('#addRuleBtn').textContent = 'حفظ التعديلات'; $('#cancelRuleEditBtn').hidden = false;
    $('#ruleName').value = rule.name || '';
    $('#ruleEvent').value = rule.when?.type || 'message';
    $('#ruleMatch').value = rule.when?.match || 'contains';
    $('#ruleValue').value = rule.when?.value || '';
    $('#ruleScope').value = rule.scope || 'all';
    $('#ruleAction').value = rule.then?.reaction && (rule.then?.replies?.length || rule.then?.reply) ? 'both' : rule.then?.reaction ? 'reaction' : 'reply';
    $('#ruleReply').value = (Array.isArray(rule.then?.replies) && rule.then.replies.length ? rule.then.replies : [rule.then?.reply || '']).filter(Boolean).join('\n');
    $('#ruleEmoji').value = rule.then?.reaction || '';
    $('#rulePriority').value = Number(rule.priority || 0); $('#ruleCooldown').value = Number(rule.cooldownSec || 0);
    $('#ruleStop').checked = rule.then?.stopAfter !== false; $('#ruleCommandPriority').checked = rule.commandPriority === true;
    $('#ruleConflictGroup').value = rule.conflictGroup || '';
    $('#ruleScheduleEnabled').checked = rule.schedule?.enabled === true;
    $('#ruleScheduleStart').value = rule.schedule?.start || '09:00'; $('#ruleScheduleEnd').value = rule.schedule?.end || '17:00';
    $$('.rule-schedule-day').forEach((input) => { input.checked = Array.isArray(rule.schedule?.days) && rule.schedule.days.map(Number).includes(Number(input.value)); });
    $('#ruleAction').dispatchEvent(new Event('change')); $('#ruleEvent').dispatchEvent(new Event('change'));
    $('#ruleName').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  function resetRuleForm() {
    state.interactionEditingRule = '';
    if ($('#ruleEditorDisclosure')) $('#ruleEditorDisclosure').open = false;
    $('#ruleEditorTitle').textContent = 'إنشاء قاعدة رد'; $('#addRuleBtn').textContent = 'حفظ القاعدة'; $('#cancelRuleEditBtn').hidden = true;
    $('#ruleName').value = ''; $('#ruleValue').value = ''; $('#ruleReply').value = ''; $('#ruleEmoji').value = '';
    $('#rulePriority').value = '10'; $('#ruleCooldown').value = '45'; $('#ruleCommandPriority').checked = false; $('#ruleConflictGroup').value = '';
    $('#ruleStop').checked = true; $('#ruleScheduleEnabled').checked = false;
    $$('.rule-schedule-day').forEach(input => { input.checked = true; });
    $('#ruleAction').value = 'reply'; $('#ruleEvent').value = 'message'; $('#ruleMatch').value = 'contains'; $('#ruleScope').value = 'all';
    $('#ruleAction').dispatchEvent(new Event('change'));
  }
  function fillCounterForm(trigger) {
    if (!trigger) return;
    state.interactionEditingCounter = trigger.id;
    if ($('#counterEditorDisclosure')) $('#counterEditorDisclosure').open = true;
    $('#counterName').value = trigger.name || ''; $('#counterThreshold').value = Number(trigger.threshold || 100);
    $('#counterScope').value = trigger.scope || 'session'; $('#counterPriority').value = Number(trigger.priority || 0);
    $('#counterActionType').value = trigger.actionType || 'reply';
    $('#counterReplies').value = (trigger.then?.replies?.length ? trigger.then.replies : [trigger.then?.reply || '']).filter(Boolean).join('\n');
    $('#counterEmoji').value = trigger.then?.reaction || '';
    $('#saveCounterBtn').textContent = 'حفظ تعديل العداد'; $('#cancelCounterEditBtn').hidden = false;
    $('#counterActionType').dispatchEvent(new Event('change'));
    $('#counterName').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  function resetCounterForm() {
    state.interactionEditingCounter = '';
    if ($('#counterEditorDisclosure')) $('#counterEditorDisclosure').open = false;
    $('#counterName').value = ''; $('#counterThreshold').value = '100'; $('#counterScope').value = 'session'; $('#counterPriority').value = '5';
    $('#counterActionType').value = 'reply'; $('#counterReplies').value = ''; $('#counterEmoji').value = '';
    $('#saveCounterBtn').textContent = 'إضافة محفز عداد'; $('#cancelCounterEditBtn').hidden = true;
    $('#counterActionType').dispatchEvent(new Event('change'));
  }

  function bindInteraction() {
    $('#activateNaturalVoicePreset')?.addEventListener('click', async () => {
      const backend = $('#ttsBackend'), style = $('#ttsStyle');
      if (backend) backend.value = 'local';
      if (style) style.value = 'natural';
      await saveInteractionSettings();
    });
    $$('[data-rule-preset]').forEach((button) => button.addEventListener('click', () => applyRulePreset(button.dataset.rulePreset)));
    $('#saveInteractionSettings')?.addEventListener('click', saveInteractionSettings);
    $('#ttsPreviewButton')?.addEventListener('click', previewTtsInBrowser);
    $('#interactionSimilarityThreshold')?.addEventListener('input', () => { const out = $('#interactionSimilarityOutput'); if (out) out.textContent = `${Math.round(Number($('#interactionSimilarityThreshold').value) * 100)}%`; });
    $('#interactionSmartThreshold')?.addEventListener('input', () => { const out = $('#interactionSmartOutput'); if (out) out.textContent = `${Math.round(Number($('#interactionSmartThreshold').value) * 100)}%`; });
    const voiceSliderFormats = [['ttsRate','ttsRateOutput',v => `${v > 0 ? '+' : ''}${v}%`], ['ttsPitch','ttsPitchOutput',v => `${v > 0 ? '+' : ''}${v} Hz`], ['ttsVolume','ttsVolumeOutput',v => `${v > 0 ? '+' : ''}${v}%`], ['ttsNoiseScale','ttsNoiseScaleOutput',v => Number(v).toFixed(2)], ['ttsNoiseWidth','ttsNoiseWidthOutput',v => Number(v).toFixed(2)], ['ttsExaggeration','ttsExaggerationOutput',v => Number(v).toFixed(2)]];
    for (const [id, outputId, format] of voiceSliderFormats) { const slider = $(`#${id}`); slider?.addEventListener('input', () => { const out = $(`#${outputId}`); if (out) out.textContent = format(slider.value); }); }
    $('#checkSmartReplyStatus')?.addEventListener('click', async () => { const out = $('#smartReplyStatus'); if (!out) return; out.textContent = 'جارٍ فحص Ollama المحلي…'; try { const status = await api('/api/assistant/llm-status'); const names = (status.models || []).slice(0, 8).join('، '); out.textContent = `${status.message || (status.available ? 'متاح' : 'غير متاح')}${names ? ` النماذج: ${names}` : ''}`; out.classList.toggle('status-ready', status.available === true); } catch (error) { out.textContent = error.message; out.classList.remove('status-ready'); } });
    const refreshActionFields = () => {
      const action = $('#ruleAction')?.value || 'reply';
      $('#ruleReplyWrap')?.toggleAttribute('hidden', action === 'reaction');
      $('#ruleEmojiWrap')?.toggleAttribute('hidden', action === 'reply');
    };
    const refreshCounterFields = () => {
      const action = $('#counterActionType')?.value || 'reply';
      $('#counterRepliesWrap')?.toggleAttribute('hidden', action !== 'reply');
      $('#counterEmojiWrap')?.toggleAttribute('hidden', action !== 'reaction');
    };
    $('#ruleAction')?.addEventListener('change', refreshActionFields); refreshActionFields();
    $('#counterActionType')?.addEventListener('change', refreshCounterFields); refreshCounterFields();
    $('#addRuleBtn')?.addEventListener('click', async () => {
      try {
        const action = $('#ruleAction').value, scope = $('#ruleScope').value;
        const replies = action === 'reaction' ? [] : [...new Set($('#ruleReply').value.split(/\r?\n/).map(value => value.trim()).filter(Boolean))];
        const body = {
          sessionId: sid(), name: $('#ruleName').value.trim() || 'قاعدة',
          when: { type: $('#ruleEvent').value, match: $('#ruleMatch').value, value: $('#ruleValue').value },
          then: { reply: replies[0] || '', replies, reaction: action === 'reply' ? '' : $('#ruleEmoji').value.trim(), stopAfter: $('#ruleStop').checked },
          scope, chatIds: scope === 'selected' ? $$('.rule-target:checked').map((input) => input.value) : [],
          priority: Number($('#rulePriority').value) || 0, cooldownSec: Number($('#ruleCooldown').value) || 0,
          commandPriority: $('#ruleCommandPriority').checked, conflictGroup: $('#ruleConflictGroup').value.trim(),
          schedule: { enabled: $('#ruleScheduleEnabled').checked, start: $('#ruleScheduleStart').value, end: $('#ruleScheduleEnd').value, days: $$('.rule-schedule-day:checked').map(input => Number(input.value)) }
        };
        const editing = state.interactionEditingRule;
        await api(editing ? `/api/interaction/rules/${encodeURIComponent(editing)}` : '/api/interaction/rules', { method: editing ? 'PUT' : 'POST', body: JSON.stringify(body) });
        resetRuleForm(); notify(editing ? 'تم تحديث القاعدة.' : 'تم حفظ القاعدة.', 'success'); await load(true);
      } catch (error) { notify(error.message, 'error'); }
    });
    $('#cancelRuleEditBtn')?.addEventListener('click', resetRuleForm);
    $$('[data-edit-rule]').forEach((button) => button.addEventListener('click', () => fillRuleForm((state.data?.interaction?.rules || []).find(rule => rule.id === button.dataset.editRule))));
    $('#testRuleBtn')?.addEventListener('click', async () => {
      try {
        const type = $('#ruleEvent').value, replies = $('#ruleReply').value.split(/\r?\n/).map(value => value.trim()).filter(Boolean);
        const rule = { when: { type, match: $('#ruleMatch').value, value: $('#ruleValue').value, threshold: Number($('#interactionSimilarityThreshold')?.value || .68) }, then: { reply: replies[0] || '', replies, reaction: $('#ruleEmoji').value }, schedule: { enabled: $('#ruleScheduleEnabled').checked, start: $('#ruleScheduleStart').value, end: $('#ruleScheduleEnd').value, days: $$('.rule-schedule-day:checked').map(input => Number(input.value)) } };
        const result = await api('/api/interaction/test', { method: 'POST', body: JSON.stringify({ sessionId: sid(), message: $('#ruleTestMessage').value, emoji: $('#ruleTestEmoji').value, sender: 'مستخدم الاختبار', rule }) });
        const score = Number.isFinite(Number(result.score)) ? ` · دقة ${Math.round(Number(result.score) * 100)}%` : '';
        const detectedIntent = result.intent && result.intent !== 'unknown' ? ` · النية: ${result.intent}` : '';
        notify(result.matched ? `${result.rendered || 'مطابقة ناجحة'}${score}${detectedIntent}` : `${result.message || 'لا توجد مطابقة.'}${score}${detectedIntent}`, result.matched ? 'success' : 'info');
      } catch (error) { notify(error.message, 'error'); }
    });
    $$('[data-toggle-rule]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/interaction/rules/${encodeURIComponent(button.dataset.toggleRule)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-rule]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/interaction/rules/${encodeURIComponent(button.dataset.deleteRule)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); if (state.interactionEditingRule === button.dataset.deleteRule) resetRuleForm(); await load(true); } catch (e) { notify(e.message, 'error'); } }));

    $('#saveCounterBtn')?.addEventListener('click', async () => {
      try {
        const actionType = $('#counterActionType').value;
        const replies = actionType === 'reply' ? [...new Set($('#counterReplies').value.split(/\r?\n/).map(value => value.trim()).filter(Boolean))] : [];
        const body = { sessionId: sid(), name: $('#counterName').value.trim() || `عداد ${$('#counterThreshold').value}`, threshold: Number($('#counterThreshold').value), scope: $('#counterScope').value, priority: Number($('#counterPriority').value) || 0, actionType, replies, reaction: actionType === 'reaction' ? $('#counterEmoji').value.trim() : '' };
        const editing = state.interactionEditingCounter;
        await api(editing ? `/api/interaction/counters/${encodeURIComponent(editing)}` : '/api/interaction/counters', { method: editing ? 'PUT' : 'POST', body: JSON.stringify(body) });
        resetCounterForm(); notify(editing ? 'تم تحديث محفز العداد.' : 'تم حفظ محفز العداد.', 'success'); await load(true);
      } catch (error) { notify(error.message, 'error'); }
    });
    $('#cancelCounterEditBtn')?.addEventListener('click', resetCounterForm);
    $('#resetCountersBtn')?.addEventListener('click', async () => {
      if (!confirm('تصفير عدد الرسائل وإعادة تسليح جميع محفزات العدادات؟')) return;
      try { await api('/api/interaction/counters/reset', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify('تم تصفير العدادات.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $$('[data-edit-counter]').forEach(button => button.addEventListener('click', () => fillCounterForm((state.data?.interaction?.counterTriggers || []).find(trigger => trigger.id === button.dataset.editCounter))));
    $$('[data-toggle-counter]').forEach(button => button.addEventListener('click', async () => { try { await api(`/api/interaction/counters/${encodeURIComponent(button.dataset.toggleCounter)}/toggle`, { method:'POST', body:JSON.stringify({sessionId:sid()}) }); await load(true); } catch(e) { notify(e.message,'error'); } }));
    $$('[data-delete-counter]').forEach(button => button.addEventListener('click', async () => { try { await api(`/api/interaction/counters/${encodeURIComponent(button.dataset.deleteCounter)}`, { method:'DELETE', body:JSON.stringify({sessionId:sid()}) }); if (state.interactionEditingCounter === button.dataset.deleteCounter) resetCounterForm(); await load(true); } catch(e) { notify(e.message,'error'); } }));
  }

  function parseTtsPronunciationDictionary(raw) {
    return String(raw || '').split(/\r?\n/u).map((line, index) => {
      const trimmed = line.trim();
      if (!trimmed) return null;
      const separator = trimmed.indexOf('=>');
      if (separator <= 0 || !trimmed.slice(separator + 2).trim()) throw new Error(`سطر المعجم الصوتي رقم ${index + 1} يجب أن يكون: الكلمة => طريقة النطق.`);
      return { term: trimmed.slice(0, separator).trim(), pronunciation: trimmed.slice(separator + 2).trim() };
    }).filter(Boolean);
  }

  async function previewTtsInBrowser() {
    const button = $('#ttsPreviewButton'), output = $('#ttsPreviewStatus'), player = $('#ttsPreviewPlayer');
    if (!button || !output || !player) return;
    const text = String($('#ttsPreviewText')?.value || '').trim();
    if (!text) { output.textContent = 'اكتب جملة قصيرة أولًا.'; return; }
    if (text.length > 1800) { output.textContent = 'المعاينة تقبل حتى 1800 حرف.'; return; }
    button.disabled = true; output.textContent = 'جارٍ توليد المعاينة الصوتية…';
    try {
      const response = await fetch('/api/tts/preview', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sessionId: sid(), text }) });
      if (!response.ok) {
        let message = `فشلت المعاينة (HTTP ${response.status}).`;
        try { const payload = await response.json(); message = payload.message || payload.error || message; } catch {}
        throw new Error(message);
      }
      const blob = await response.blob();
      if (!blob.size) throw new Error('لم ينتج محرك النطق ملفًا صوتيًا.');
      if (state.ttsPreviewUrl) URL.revokeObjectURL(state.ttsPreviewUrl);
      state.ttsPreviewUrl = URL.createObjectURL(blob);
      player.src = state.ttsPreviewUrl; player.hidden = false;
      output.textContent = 'المعاينة جاهزة. استمع إليها هنا؛ لم يتم إرسال أي شيء إلى WhatsApp.';
      try { await player.play(); } catch {}
    } catch (error) { output.textContent = error.message || 'تعذرت معاينة الصوت.'; }
    finally { button.disabled = false; }
  }

  async function saveInteractionSettings() {
    try {
      const saved = await api('/api/settings', { method: 'POST', body: JSON.stringify({
        sessionId: sid(), interactionEnabled: $('#interactionEnabled').checked, groupAssistantEnabled: $('#groupAssistantEnabled').checked, interactionIgnoreOwn: $('#interactionIgnoreOwn').checked,
        interactionScope: $('#interactionScope').value, interactionChatIds: $$('.rule-target:checked').map((input) => input.value), interactionQuietEnabled: $('#interactionQuietEnabled').checked,
        interactionQuietStart: $('#interactionQuietStart').value, interactionQuietEnd: $('#interactionQuietEnd').value,
        interactionQuietAction: $('#interactionQuietAction').value, interactionQuietReply: $('#interactionQuietReply').value,
        interactionQuietCooldownSec: Number($('#interactionQuietCooldownSec').value || 0), maxActionsPerMinute: Number($('#maxActionsPerMinute').value || 20),
        interactionConflictMode: $('#interactionConflictMode').value, interactionSimilarityThreshold: Number($('#interactionSimilarityThreshold').value || .68),
        interactionSmartMatching: $('#interactionSmartMatching')?.checked === true, interactionSmartThreshold: Number($('#interactionSmartThreshold')?.value || .82),
        interactionFallbackEnabled: $('#interactionFallbackEnabled')?.checked === true, interactionFallbackInGroups: $('#interactionFallbackInGroups')?.checked === true,
        interactionFallbackCooldownSec: Number($('#interactionFallbackCooldownSec')?.value || 45), interactionFallbackReply: $('#interactionFallbackReply')?.value || '',
        smartReplyEnabled: $('#smartReplyEnabled')?.checked === true, smartReplyModel: $('#smartReplyModel')?.value.trim() || 'qwen3.5:4b',
        smartReplyTimeoutMs: Number($('#smartReplyTimeoutMs')?.value || 12000), smartReplySystemPrompt: $('#smartReplySystemPrompt')?.value || '',
        voiceAutoTranscribeEnabled: $('#voiceAutoTranscribeEnabled')?.checked !== false, voiceAutoTranscribeSelfChat: $('#voiceAutoTranscribeSelfChat')?.checked !== false, interactionVoiceRepliesEnabled: $('#interactionVoiceRepliesEnabled')?.checked !== false, ttsProofreadEnabled: true, ttsRequireProofread: $('#ttsRequireProofread')?.checked === true, ttsBackend: $('#ttsBackend')?.value || 'local', ttsCloudConsent: $('#ttsCloudConsent')?.checked === true, ttsVoice: $('#ttsVoice')?.value || 'ar-EG-ShakirNeural', ttsAudarVoice: $('#ttsAudarVoice')?.value || 'demo_male_1', ttsStyle: $('#ttsStyle')?.value || 'natural', ttsRate: Number($('#ttsRate')?.value || 0), ttsPitch: Number($('#ttsPitch')?.value || 0), ttsVolume: Number($('#ttsVolume')?.value || 0), ttsNoiseScale: Number($('#ttsNoiseScale')?.value || .667), ttsNoiseWidth: Number($('#ttsNoiseWidth')?.value || .8), ttsExaggeration: Number($('#ttsExaggeration')?.value ?? .55), ttsMaxReplySegments: Number($('#ttsMaxReplySegments')?.value || 6), ttsPronunciationDictionary: parseTtsPronunciationDictionary($('#ttsPronunciationDictionary')?.value || ''), voiceTranscribeLanguage: $('#voiceTranscribeLanguage')?.value || 'auto'
      }) });
      if (Array.isArray(saved.warnings) && saved.warnings.length) notify(saved.warnings.join(' — '), 'warning');
      else notify(saved.message || 'تم حفظ إعدادات التفاعل.', 'success');
      await load(true);
    } catch (error) { notify(error.message, 'error'); }
  }

  async function loadIntegrationHub(force = false) {
    const sessionId = sid();
    if (state.integrationHubLoadedSession && state.integrationHubLoadedSession !== sessionId) { state.integrationLatestRun = null; state.integrationWebhookPath = ''; state.integrationEnrollment = null; state.integrationAgentCommand = ''; state.integrationHub = null; state.integrationHealth = null; }
    if (!force && state.integrationHubLoadedSession === sessionId && state.integrationHub) return state.integrationHub;
    try {
      const hub = await api(`/api/integrations?sessionId=${encodeURIComponent(sessionId)}`);
      state.integrationHub = hub; state.integrationHubLoadedSession = sessionId;
      try { state.integrationHealth = await api(`/api/integrations/health?sessionId=${encodeURIComponent(sessionId)}`); } catch { state.integrationHealth = null; }
      const lastCatalogRun = (hub.runs || []).find(run => run.kind === 'catalog-test');
      if (lastCatalogRun && (!state.integrationLatestRun || state.integrationLatestRun.id !== lastCatalogRun.id)) {
        try { const full = await api(`/api/integrations/runs/${encodeURIComponent(lastCatalogRun.id)}?sessionId=${encodeURIComponent(sessionId)}`); state.integrationLatestRun = full.run; } catch {}
      }
      if (state.page === 'integrations') render();
      return hub;
    } catch (error) { notify(`تعذر تحميل مركز التكاملات: ${error.message}`, 'error'); return null; }
  }
  function bindIntegrations() {
    if (state.integrationHubLoadedSession !== sid() || !state.integrationHub) { loadIntegrationHub(true); return; }
    const type = $('#integrationType');
    const showTypeFields = () => {
      const t = type?.value || 'http';
      $$('.integration-field-url,.integration-field-auth').forEach(x => { x.hidden = !['http','openapi'].includes(t); });
      $$('.integration-field-folder').forEach(x => { x.hidden = t !== 'folder'; });
      $$('.integration-field-file').forEach(x => { x.hidden = t !== 'database'; });
      $$('.integration-field-command').forEach(x => { x.hidden = t !== 'command'; });
      $$('.integration-field-spec').forEach(x => { x.hidden = t !== 'openapi'; });
      const ruleTrigger = $('#integrationRuleTrigger'); if (ruleTrigger) { const option = [...ruleTrigger.options].find(o => o.value === 'webhook'); if (option) option.disabled = t !== 'webhook'; }
    };
    type?.addEventListener('change', showTypeFields); showTypeFields();
    $('#integrationSpecFile')?.addEventListener('change', event => {
      const file = event.target.files?.[0]; if (!file) return;
      if (file.size > 1024 * 1024) { notify('ملف المواصفات أكبر من 1 ميجابايت.', 'error'); event.target.value = ''; return; }
      const reader = new FileReader(); reader.onload = () => { $('#integrationSpec').value = String(reader.result || ''); notify('تم تحميل محتوى المواصفات في المربع. اضغط حفظ الاتصال لتسجيله.', 'success'); }; reader.onerror = () => notify('تعذرت قراءة الملف. جرّب نسخه ولصقه في المربع.', 'error'); reader.readAsText(file);
    });
    $('#createIntegrationBtn')?.addEventListener('click', async () => {
      const button=$('#createIntegrationBtn'); button.disabled=true;
      try {
        let headers = {};
        const headersText = String($('#integrationHeaders')?.value || '').trim();
        if (headersText) { try { headers = JSON.parse(headersText); } catch { throw new Error('بيانات الدخول ليست JSON صالحًا. مثال: {"Authorization":"Bearer YOUR_TOKEN"}'); } }
        const body={ sessionId:sid(), name:$('#integrationName')?.value.trim(), type:type?.value||'http', url:$('#integrationUrl')?.value.trim(), folderPath:$('#integrationFolderPath')?.value.trim(), filePath:$('#integrationFilePath')?.value.trim(), command:$('#integrationCommand')?.value||'node', specText:$('#integrationSpec')?.value||'', headers };
        const result=await api('/api/integrations/connections',{method:'POST',body:JSON.stringify(body)});
        state.integrationWebhookPath=result.webhookPath?`${location.origin}${result.webhookPath}`:'';
        state.integrationLatestRun=null; notify('تم حفظ الاتصال محليًا. اضغط «اكتشاف وفحص» لتأكيد القدرات.', 'success'); await loadIntegrationHub(true);
      } catch(e) { notify(e.message,'error'); } finally { if($('#createIntegrationBtn')) $('#createIntegrationBtn').disabled=false; }
    });
    $('#refreshIntegrationsBtn')?.addEventListener('click',()=>loadIntegrationHub(true));
    $('#refreshIntegrationHealthBtn')?.addEventListener('click',()=>loadIntegrationHub(true));
    $$('[data-discover-integration]').forEach(button=>button.addEventListener('click',async()=>{button.disabled=true;const t=button.textContent;button.textContent='يفحص…';try{const result=await api(`/api/integrations/connections/${encodeURIComponent(button.dataset.discoverIntegration)}/discover`,{method:'POST',body:JSON.stringify({sessionId:sid()})});notify(`اكتمل الاكتشاف. عدد القدرات المدعومة بالدليل: ${result.capabilities?.length||0}.`,'success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}finally{button.disabled=false;button.textContent=t;}}));
    $$('[data-test-integration]').forEach(button=>button.addEventListener('click',async()=>{button.disabled=true;const t=button.textContent;button.textContent='يجري الفحص…';try{const result=await api(`/api/integrations/connections/${encodeURIComponent(button.dataset.testIntegration)}/test`,{method:'POST',body:JSON.stringify({sessionId:sid()})});state.integrationLatestRun=result.run;notify(`اكتمل التقرير: ${result.summary.catalogScenarios||result.summary.total} سيناريو، ${result.summary.executedCases||0} حالة منفذة فعلًا، ${result.summary.actualTargetProbes} طلب فحص للهدف.`,'success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}finally{if(button.isConnected){button.disabled=false;button.textContent=t;}}}));
    $$('[data-delete-integration]').forEach(button=>button.addEventListener('click',async()=>{const c=state.integrationHub?.connections?.find(x=>x.id===button.dataset.deleteIntegration);if(!confirm(`حذف تعريف الاتصال «${c?.name||''}» والقواعد المرتبطة به؟ لن يحذف النظام ملفات أو بيانات الهدف.`))return;try{await api(`/api/integrations/connections/${encodeURIComponent(button.dataset.deleteIntegration)}`,{method:'DELETE',body:JSON.stringify({sessionId:sid()})});notify('تم حذف تعريف الاتصال فقط.','success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}}));
    $$('[data-edit-integration-credentials]').forEach(button=>button.addEventListener('click',async()=>{
      const raw=prompt('أدخل ترويسات الدخول بصيغة JSON. لإزالة كل الترويسات أدخل {}. لا تُعرض القيم المحفوظة لأسباب أمنية.', '');
      if(raw===null || !raw.trim())return;
      let headers;try{headers=JSON.parse(raw);}catch{notify('صيغة JSON غير صحيحة. لم تتغير بيانات الدخول.','error');return;}
      try{const result=await api(`/api/integrations/connections/${encodeURIComponent(button.dataset.editIntegrationCredentials)}/credentials`,{method:'PUT',body:JSON.stringify({sessionId:sid(),headers})});notify(result.message,'success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}
    }));
    $$('[data-add-template]').forEach(button=>button.addEventListener('click',async()=>{try{const result=await api(`/api/integrations/connections/${encodeURIComponent(button.dataset.addTemplate)}/rules/template`,{method:'POST',body:JSON.stringify({sessionId:sid(),templateId:button.dataset.templateId,triggerType:$('#integrationRuleTrigger')?.value||'manual',everyMinutes:Number($('#integrationRuleEvery')?.value||15)})});notify(result.message||'تمت إضافة القاعدة كمتوقفة.','success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}}));
    $$('[data-rotate-webhook]').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('سيُبطل هذا الرابط القديم ويولّد رابط استقبال جديدًا. متابعة؟'))return;try{const result=await api(`/api/integrations/connections/${encodeURIComponent(button.dataset.rotateWebhook)}/webhook-secret`,{method:'POST',body:JSON.stringify({sessionId:sid()})});state.integrationWebhookPath=`${location.origin}${result.webhookPath}`;notify(result.message,'success');render();}catch(e){notify(e.message,'error');}}));
    $('#copyIntegrationWebhook')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(state.integrationWebhookPath);notify('تم نسخ رابط Webhook. لا تشاركه إلا مع التطبيق الذي يرسل الأحداث.','success');}catch{notify(state.integrationWebhookPath,'warning');}});
    $('#createAgentEnrollmentBtn')?.addEventListener('click',async()=>{
      const button=$('#createAgentEnrollmentBtn'); button.disabled=true;
      try {
        let server;
        try { const u=new URL(String($('#integrationAgentServer')?.value||'').trim()); if(!['http:','https:'].includes(u.protocol)||u.username||u.password||u.search||u.hash||u.pathname!=='/') throw new Error(); server=u.origin; }
        catch { throw new Error('أدخل عنوان الخادم بصيغة http://192.168.1.20:7005 أو https://... من دون مسار إضافي.'); }
        const name=String($('#integrationAgentName')?.value||'جهاز جديد').trim().slice(0,100)||'جهاز جديد';
        const result=await api('/api/integrations/devices/enroll',{method:'POST',body:JSON.stringify({sessionId:sid(),name})});
        state.integrationEnrollment={token:result.token,expiresAt:result.expiresAt,name:result.name};
        const command=`node src/integration-agent.js --server "${server}" --session "${sid()}" --token "${result.token}"`;
        state.integrationAgentCommand=command;
        notify('أُنشئ رمز تسجيل مؤقت لمرة واحدة. شغّل الأمر على الجهاز المقصود قبل انتهاء الصلاحية.','success'); render();
      } catch(e) { notify(e.message,'error'); }
      finally { if(button.isConnected) button.disabled=false; }
    });
    $('#copyIntegrationAgentCommand')?.addEventListener('click',async()=>{
      if(!state.integrationAgentCommand)return;
      try { await navigator.clipboard.writeText(state.integrationAgentCommand); notify('تم نسخ أمر الربط. الرمز مؤقت وسينتهي خلال 10 دقائق.','success'); }
      catch { notify(state.integrationAgentCommand,'warning'); }
    });
    $('#dismissAgentEnrollment')?.addEventListener('click',()=>{state.integrationEnrollment=null;state.integrationAgentCommand='';render();});
    $$('[data-agent-info]').forEach(button=>button.addEventListener('click',async()=>{try{await api(`/api/integrations/devices/${encodeURIComponent(button.dataset.agentInfo)}/tasks`,{method:'POST',body:JSON.stringify({sessionId:sid(),action:'device.info'})});notify('أُرسلت مهمة فحص الجهاز. حدّث المركز بعد ثوانٍ لعرض النتيجة.','success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}}));
    $$('[data-agent-command]').forEach(button=>button.addEventListener('click',async()=>{const command=prompt('اختر برنامجًا للفحص من القائمة الآمنة: node, npm, python, git, ollama, curl','node');if(command===null)return;if(!['node','npm','python','git','ollama','curl'].includes(command.trim())){notify('البرنامج غير موجود في القائمة الآمنة.','error');return;}try{await api(`/api/integrations/devices/${encodeURIComponent(button.dataset.agentCommand)}/tasks`,{method:'POST',body:JSON.stringify({sessionId:sid(),action:'command.version',params:{command:command.trim()}})});notify('أُرسلت مهمة فحص البرنامج.','success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}}));
    $$('[data-agent-folder]').forEach(button=>button.addEventListener('click',async()=>{const folder=prompt('أدخل المسار الكامل على الجهاز المرتبط. يجب أن يكون داخل مجلد سمحت به عند تشغيل الوكيل عبر --allow-root.');if(folder===null||!folder.trim())return;try{await api(`/api/integrations/devices/${encodeURIComponent(button.dataset.agentFolder)}/tasks`,{method:'POST',body:JSON.stringify({sessionId:sid(),action:'folder.list',params:{path:folder.trim()}})});notify('أُرسلت مهمة عرض أسماء الملفات فقط.','success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}}));
    $$('[data-agent-db]').forEach(button=>button.addEventListener('click',async()=>{const file=prompt('أدخل المسار الكامل لملف JSON أو CSV أو SQLite على الجهاز، ضمن مجلد مسموح.');if(file===null||!file.trim())return;try{await api(`/api/integrations/devices/${encodeURIComponent(button.dataset.agentDb)}/tasks`,{method:'POST',body:JSON.stringify({sessionId:sid(),action:'database.inspect',params:{path:file.trim()}})});notify('أُرسلت مهمة فحص بنية الملف بوضع القراءة فقط.','success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}}));
    $$('[data-revoke-agent]').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('إلغاء ربط هذا الجهاز الآن؟ سيُمنع من إرسال مهام جديدة وستُلغى مهامه المعلقة.'))return;try{await api(`/api/integrations/devices/${encodeURIComponent(button.dataset.revokeAgent)}`,{method:'DELETE',body:JSON.stringify({sessionId:sid()})});notify('تم إلغاء ربط الجهاز.','success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}}));
    $('#addIntegrationPluginBtn')?.addEventListener('click',async()=>{
      const raw=String($('#integrationPluginManifest')?.value||'').trim(); if(!raw){notify('ألصق ملف الإضافة بصيغة JSON أولًا.','error');return;}
      let manifest;try{manifest=JSON.parse(raw);}catch{notify('ملف JSON غير صحيح. راجع الفواصل وعلامات الاقتباس.','error');return;}
      try{const result=await api('/api/integrations/plugins',{method:'POST',body:JSON.stringify({sessionId:sid(),manifest})});notify(`تم حفظ الإضافة «${result.plugin.name}». اختر «إنشاء اتصال» لبدء استخدامها.`, 'success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}
    });
    $$('[data-connect-plugin]').forEach(button=>button.addEventListener('click',async()=>{try{const result=await api(`/api/integrations/plugins/${encodeURIComponent(button.dataset.connectPlugin)}/connect`,{method:'POST',body:JSON.stringify({sessionId:sid()})});if(result.webhookPath)state.integrationWebhookPath=`${location.origin}${result.webhookPath}`;notify('تم إنشاء اتصال من الإضافة. افحصه للتأكد من قدراته.','success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}}));
    $$('[data-delete-plugin]').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('حذف تعريف الإضافة؟ الاتصالات التي أنشئت منها لا تُحذف تلقائيًا.'))return;try{await api(`/api/integrations/plugins/${encodeURIComponent(button.dataset.deletePlugin)}`,{method:'DELETE',body:JSON.stringify({sessionId:sid()})});notify('تم حذف تعريف الإضافة.','success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}}));
    $('#refreshIntegrationsBtn2')?.addEventListener('click',()=>loadIntegrationHub(true));
    $('#createIntegrationRuleBtn')?.addEventListener('click',async()=>{try{const body={sessionId:sid(),connectionId:$('#integrationRuleConnection')?.value,name:$('#integrationRuleText')?.value.trim(),description:$('#integrationRuleText')?.value.trim(),action:$('#integrationRuleAction')?.value||undefined,triggerType:$('#integrationRuleTrigger')?.value||'manual',everyMinutes:Number($('#integrationRuleEvery')?.value||15),endpoint:$('#integrationRuleEndpoint')?.value.trim()};const result=await api('/api/integrations/rules',{method:'POST',body:JSON.stringify(body)});notify(result.rule.supported?'أُضيفت القاعدة وهي متوقفة للمراجعة.':'أُضيفت القاعدة كمتوقفة؛ افحص الاتصال لإثبات الدعم قبل تشغيلها.','success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}});
    $$('[data-run-integration-rule]').forEach(button=>button.addEventListener('click',async()=>{button.disabled=true;try{const result=await api(`/api/integrations/rules/${encodeURIComponent(button.dataset.runIntegrationRule)}/run`,{method:'POST',body:JSON.stringify({sessionId:sid()})});notify(result.result?.summary||'اكتمل تشغيل القاعدة.','success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}finally{button.disabled=false;}}));
    $$('[data-toggle-integration-rule]').forEach(button=>button.addEventListener('click',async()=>{try{const result=await api(`/api/integrations/rules/${encodeURIComponent(button.dataset.toggleIntegrationRule)}/toggle`,{method:'POST',body:JSON.stringify({sessionId:sid(),enabled:button.dataset.enabled==='true'})});notify(result.rule.enabled?'تم تشغيل القاعدة.':'تم إيقاف القاعدة.','success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}}));
    $$('[data-delete-integration-rule]').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('حذف هذه القاعدة؟'))return;try{await api(`/api/integrations/rules/${encodeURIComponent(button.dataset.deleteIntegrationRule)}`,{method:'DELETE',body:JSON.stringify({sessionId:sid()})});await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}}));
    $('#saveIntegrationNotify')?.addEventListener('click',async()=>{try{const settings=await api('/api/integrations/settings',{method:'PUT',body:JSON.stringify({sessionId:sid(),whatsappNotificationsEnabled:$('#integrationWhatsappNotify')?.checked===true,whatsappTarget:$('#integrationWhatsappTarget')?.value||''})});notify(settings.settings?.whatsappNotificationsEnabled?'تم تفعيل التنبيهات إلى WhatsApp للجهة المحددة.':'تم حفظ التنبيهات داخل المركز فقط؛ إشعارات WhatsApp متوقفة.','success');await loadIntegrationHub(true);}catch(e){notify(e.message,'error');}});
    $('#refreshIntegrationReport')?.addEventListener('click',()=>loadIntegrationHub(true));
    $('#downloadIntegrationReport')?.addEventListener('click',()=>{const run=state.integrationLatestRun;if(!run)return;const blob=new Blob([JSON.stringify(run,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`chat-BOT-integration-test-${run.connectionId||'report'}.json`;document.body.append(a);a.click();a.remove();URL.revokeObjectURL(url);});
  }

  function bindSession() {
    const methodInput = $('#connectionMethod');
    const phoneRow = $('#pairingPhoneRow');
    const phoneInput = $('#pairingPhoneNumber');
    if (methodInput) {
      methodInput.addEventListener('change', () => {
        state.connectionMethod = ['qr','phone'].includes(methodInput.value) ? methodInput.value : 'qr';
        if (phoneRow) phoneRow.hidden = state.connectionMethod !== 'phone';
      });
    }
    if (phoneInput) phoneInput.addEventListener('input', () => { state.connectionPhoneNumber = phoneInput.value; });
    $('#copyPairingCodeBtn')?.addEventListener('click', async () => {
      const code = $('#pairingCodeValue')?.textContent?.trim() || '';
      if (!/^[A-Z0-9]{8}$/.test(code)) return;
      try { await navigator.clipboard.writeText(code); notify('تم نسخ رمز الربط. استخدمه فورًا داخل WhatsApp ولا تشاركه.', 'success'); }
      catch { notify(`رمز الربط: ${code}`, 'warning'); }
    });
    $('#requestNewPairingCodeBtn')?.addEventListener('click', async () => {
      const phone = String($('#pairingPhoneNumber')?.value || state.connectionPhoneNumber || '').trim();
      if (!phone) { notify('اكتب رقم WhatsApp بالصيغة الدولية أولًا، مثل +96891234567.', 'error'); $('#connectionMethod') && ($('#connectionMethod').value = 'phone'); if (phoneRow) phoneRow.hidden = false; $('#pairingPhoneNumber')?.focus(); return; }
      const button = $('#requestNewPairingCodeBtn'); if (button) { button.disabled = true; button.textContent = 'جارٍ طلب رمز جديد…'; }
      try {
        await api('/api/session/stop', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) });
        state.connectionMethod = 'phone'; state.connectionPhoneNumber = phone;
        if ($('#connectionMethod')) $('#connectionMethod').value = 'phone'; if (phoneRow) phoneRow.hidden = false;
        const result = await api('/api/session/connect', { method: 'POST', body: JSON.stringify({ sessionId: sid(), method: 'phone', phoneNumber: phone }) });
        notify(result.message || 'بدأ طلب رمز جديد من WhatsApp. سيظهر عند وصوله من الخدمة الرسمية.', 'info');
        await load(true); await refreshSessionRuntime();
      } catch (e) { notify(e.message, 'error'); await refreshSessionRuntime(); }
      finally { if (button?.isConnected) { button.disabled = false; button.textContent = 'طلب رمز جديد'; } }
    });
    $('#refreshSessionStatusBtn')?.addEventListener('click', () => refreshSessionRuntime());
    $('#connectSessionBtn')?.addEventListener('click', async () => {
      const button = $('#connectSessionBtn'), originalText = button?.textContent;
      if (button) { button.disabled = true; button.textContent = 'جارٍ بدء الاتصال…'; }
      const box = $('#sessionQrBox'), placeholder = $('#sessionQrPlaceholder'), img = $('#sessionQrImage');
      if (box) box.hidden = false;
      if (placeholder) placeholder.hidden = false;
      if (img) { img.hidden = true; img.removeAttribute('src'); delete img.dataset.qr; }
      const hint = $('#sessionConnectionHint'); if (hint) hint.textContent = 'تم طلب الاتصال. تظل الصفحة تحدث الحالة في الخلفية حتى يصدر QR الحقيقي أو تظهر رسالة خطأ واضحة.';
      try {
        state.connectionMethod = ['qr','phone'].includes($('#connectionMethod')?.value) ? $('#connectionMethod').value : 'qr';
        state.connectionPhoneNumber = $('#pairingPhoneNumber')?.value || state.connectionPhoneNumber || '';
        if (state.connectionMethod === 'phone' && !state.connectionPhoneNumber.trim()) throw new Error('اكتب رقم WhatsApp بالصيغة الدولية قبل طلب رمز الهاتف.');
        const currentRuntime = state.data?.whatsapp || {};
        if (['starting','qr','pairing_code','authenticated'].includes(currentRuntime.status) && ['qr','phone'].includes(currentRuntime.connectionMethod) && currentRuntime.connectionMethod !== state.connectionMethod) {
          await api('/api/session/stop', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) });
        }
        const result = await api('/api/session/connect', { method: 'POST', body: JSON.stringify({ sessionId: sid(), method: state.connectionMethod, phoneNumber: state.connectionPhoneNumber }) });
        notify(result.message || 'بدأ الاتصال في الخلفية.', result.runtime?.status === 'error' ? 'error' : 'info');
        await load(true); await refreshSessionRuntime();
      } catch (e) { notify(e.message, 'error'); await refreshSessionRuntime(); }
      finally { const current = $('#connectSessionBtn'); if (current) { current.disabled = false; current.textContent = originalText || 'ربط / تشغيل'; } }
    });
    $('#stopSessionBtn')?.addEventListener('click', async () => { try { await api('/api/session/stop', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify('تم إيقاف الجلسة.', 'info'); await load(true); await refreshSessionRuntime(); } catch (e) { notify(e.message, 'error'); } });
    $('#unlinkSessionBtn')?.addEventListener('click', async () => { if (!confirm('سيتم فصل الحساب وحذف بيانات ربط WhatsApp المحفوظة لهذه الجلسة فقط. ستحتاج لمسح QR جديد عند الاتصال. متابعة؟')) return; try { await api('/api/session/unlink', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify('تم فصل الحساب. اضغط «ربط / تشغيل» للحصول على QR جديد.', 'success'); await load(true); await refreshSessionRuntime(); } catch (e) { notify(e.message, 'error'); } });
    $('#saveSessionBtn')?.addEventListener('click', async () => { try { await api(`/api/sessions/${encodeURIComponent(sid())}`, { method: 'PUT', body: JSON.stringify({ name: $('#sessionName').value.trim() }) }); notify('تم حفظ الاسم.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#newSessionBtn')?.addEventListener('click', async () => { try { await api('/api/sessions', { method: 'POST', body: JSON.stringify({ name: 'جلسة جديدة' }) }); notify('تم إنشاء الجلسة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#deleteSessionBtn')?.addEventListener('click', async () => { if (!confirm('حذف هذه الجلسة نهائيًا؟')) return; try { await api(`/api/sessions/${encodeURIComponent(sid())}`, { method: 'DELETE' }); state.page = 'dashboard'; state.pendingTargets = null; persistPendingTargets(); notify('تم حذف الجلسة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
  }

  function applyUiPreset(name) {
    const presets = {
      mint: { accent: '#5ed6c1', accent2: '#8b7cf6', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .28 },
      ocean: { accent: '#56c9ff', accent2: '#57e5cf', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .25 },
      violet: { accent: '#9b86ff', accent2: '#e18aff', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .27 },
      sunset: { accent: '#ff9a6a', accent2: '#ff6fb1', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .24 },
    };
    const p = presets[name]; if (!p) return;
    if ($('#uiAccent')) $('#uiAccent').value = p.accent;
    if ($('#uiAccent2')) $('#uiAccent2').value = p.accent2;
    if ($('#uiPanelOpacity')) $('#uiPanelOpacity').value = p.panelOpacity;
    if ($('#uiPanelBlur')) $('#uiPanelBlur').value = p.panelBlur;
    if ($('#uiRadius')) $('#uiRadius').value = p.radius;
    if ($('#uiGlow')) $('#uiGlow').value = p.glow;
    ['uiPanelOpacity','uiPanelBlur','uiRadius','uiGlow'].forEach(updateRangeOutput);
    applyInterfaceLive();
    notify('تم تطبيق المظهر الجاهز. اضغط حفظ الواجهة لتثبيته.', 'info');
  }

  function bindAppearance() {
    const uiControls = ['uiPanelOpacity', 'uiPanelBlur', 'uiRadius', 'uiGlow'];
    uiControls.forEach((id) => $(`#${id}`)?.addEventListener('input', () => { updateRangeOutput(id); applyInterfaceLive(); }));
    $('#uiAccent')?.addEventListener('input', applyInterfaceLive);
    $('#uiAccent2')?.addEventListener('input', applyInterfaceLive);
    const syncThemeDots = () => { const a = readInterfaceForm(); if ($('#themeDot1')) $('#themeDot1').style.background = a.accent; if ($('#themeDot2')) $('#themeDot2').style.background = a.accent2; };
    syncThemeDots();
    $$('[data-ui-preset]').forEach((button) => button.addEventListener('click', () => applyUiPreset(button.dataset.uiPreset)));
    ['uiAccent','uiAccent2','uiPanelOpacity','uiPanelBlur','uiRadius','uiGlow'].forEach((id) => $(`#${id}`)?.addEventListener('input', syncThemeDots));
    $('#saveUiThemeBtn')?.addEventListener('click', async () => {
      try { await api('/api/settings', { method: 'POST', body: JSON.stringify({ sessionId: sid(), appearance: readInterfaceForm() }) }); notify('تم حفظ هوية الواجهة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#resetUiThemeBtn')?.addEventListener('click', async () => {
      const defaults = { accent: '#5ed6c1', accent2: '#8b7cf6', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .28 };
      try { await api('/api/settings', { method: 'POST', body: JSON.stringify({ sessionId: sid(), appearance: defaults }) }); notify('تمت استعادة هوية الواجهة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    const controls = ['bgSpeed', 'bgDensity', 'bgGlow', 'bgIntensity', 'bgMouse', 'bgBrightness', 'bgContrast', 'bgSaturation', 'bgHue', 'bgBlur', 'bgOpacity'];
    controls.forEach((id) => $(`#${id}`)?.addEventListener('input', () => { updateRangeOutput(id); applyBackgroundLive(); }));
    $$('[data-bg-mode]').forEach((button) => button.addEventListener('click', () => { $$('[data-bg-mode]').forEach((item) => item.classList.remove('selected')); button.classList.add('selected'); applyBackgroundLive(); }));
    $('#bgInteractive')?.addEventListener('change', applyBackgroundLive);
    $('#bgTrail')?.addEventListener('change', applyBackgroundLive);
    $('#saveBackgroundBtn')?.addEventListener('click', async () => {
      try { const payload = readBackgroundForm(); await api('/api/settings/background', { method: 'POST', body: JSON.stringify({ sessionId: sid(), ...payload }) }); notify('تم حفظ وتطبيق المظهر.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#resetBackgroundBtn')?.addEventListener('click', async () => {
      try { await api('/api/settings/background', { method: 'POST', body: JSON.stringify({ sessionId: sid(), mode: 'aurora', settings: { speed: 1, density: 1, glow: .6, intensity: 1, mouseStrength: 1, brightness: 1, contrast: 1, saturation: 1, hueRotate: 0, blur: 0, interactive: true, trail: true }, opacity: .22, removeImage: true }) }); notify('تمت استعادة المظهر الافتراضي.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#removeCustomBackgroundBtn')?.addEventListener('click', async () => {
      if (!confirm('إزالة صورة الخلفية المخصصة؟')) return;
      try { await api('/api/settings/background', { method: 'POST', body: JSON.stringify({ sessionId: sid(), mode: state.data?.background?.mode || 'aurora', settings: state.data?.background?.settings || {}, opacity: state.data?.background?.opacity ?? .22, removeImage: true }) }); notify('تمت إزالة الصورة المخصصة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#customBackground')?.addEventListener('change', async (event) => {
      const file = event.target.files?.[0]; if (!file) return;
      const form = new FormData(); form.append('file', file); form.append('sessionId', sid());
      try { const result = await api('/api/background', { method: 'POST', body: form }); notify(result.message || 'تم تطبيق الخلفية.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
      finally { event.target.value = ''; }
    });
  }

  function updateRangeOutput(id) {
    const input = $(`#${id}`), output = $(`#${id}Out`); if (!input || !output) return;
    const step = Number(input.step || 1);
    output.value = Number(input.value).toFixed(step < 1 ? 2 : 0);
  }

  function readBackgroundForm() {
    return {
      mode: $('.bg-choice.selected')?.dataset.bgMode || state.data?.background?.mode || 'aurora',
      opacity: Number($('#bgOpacity').value),
      settings: {
        speed: Number($('#bgSpeed').value), density: Number($('#bgDensity').value), glow: Number($('#bgGlow').value), intensity: Number($('#bgIntensity').value), mouseStrength: Number($('#bgMouse').value),
        brightness: Number($('#bgBrightness').value), contrast: Number($('#bgContrast').value), saturation: Number($('#bgSaturation').value), hueRotate: Number($('#bgHue').value), blur: Number($('#bgBlur').value),
        interactive: $('#bgInteractive').checked, trail: $('#bgTrail').checked
      }
    };
  }

  function applyBackgroundLive() {
    if (state.bgLivePending) return;
    state.bgLivePending = requestAnimationFrame(() => {
      state.bgLivePending = 0;
      const data = readBackgroundForm();
      if (state.bgEngine) state.bgEngine.set(data);
    });
  }

  function bindSettings() {
    $$('[data-settings-view]').forEach((button) => button.addEventListener('click', () => {
      state.settingsView = button.dataset.settingsView === 'operation' ? 'operation' : 'appearance';
      render();
    }));
  }

  function bindOperation() {
    const save = async (payload) => {
      try { await api('/api/settings', { method: 'POST', body: JSON.stringify({ sessionId: sid(), ...payload }) }); notify('تم حفظ الإعدادات.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    };
    $('#saveOperationMain')?.addEventListener('click', () => save({ timezone: $('#opTimezone').value.trim(), sendOrder: $('#opSendOrder').value, autoStartSession: $('#opAutoStart').checked, automationEnabled: $('#opAutomation').checked }));
    $('#saveOperationReliability')?.addEventListener('click', () => save({ sendTimeoutMs: Number($('#opTimeout').value || 30000), retryAttempts: Number($('#opRetryAttempts').value || 2), retryDelayMs: Number($('#opRetryDelay').value || 1600), maxImageSizeMB: Number($('#opMaxSize').value || 100), maxInboundMessageAgeSec: Number($('#opInboundAge').value || 300), maxInboundQueueWaitSec: Number($('#opQueueWait').value || 60), maxInboundQueueDepth: Number($('#opQueueDepth').value || 40) }));
    $('#saveOperationQuiet')?.addEventListener('click', () => save({ interactionQuietEnabled: $('#opQuietEnabled').checked, interactionQuietStart: $('#opQuietStart').value, interactionQuietEnd: $('#opQuietEnd').value, interactionQuietAction: $('#opQuietAction').value, interactionQuietReply: $('#opQuietReply').value, interactionQuietCooldownSec: Number($('#opQuietCooldownSec').value || 0) }));
    const backupPassword = () => String($('#backupPassword')?.value || '');
    $('#createBackupBtn')?.addEventListener('click', async (event) => {
      const button = event.currentTarget, password = backupPassword(), confirmPassword = String($('#backupPasswordConfirm')?.value || '');
      if (password.length < 12) return notify('كلمة مرور النسخة يجب أن تكون 12 محرفًا على الأقل.', 'error');
      if (password !== confirmPassword) return notify('كلمتا المرور غير متطابقتين.', 'error');
      button.disabled = true; button.classList.add('loading');
      try {
        const response = await fetch('/api/backup/export', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) });
        if (!response.ok) { let detail = {}; try { detail = await response.json(); } catch {} throw new Error(detail.error || `تعذر إنشاء النسخة (${response.status}).`); }
        const blob = await response.blob();
        if (!blob.size) throw new Error('ملف النسخة الناتج فارغ.');
        const url = URL.createObjectURL(blob), anchor = document.createElement('a');
        anchor.href = url; anchor.download = response.headers.get('content-disposition')?.match(/filename="([^"]+)"/i)?.[1] || `chat-bot-backup-${new Date().toISOString().slice(0,10)}.cbotbackup`;
        document.body.appendChild(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(url), 30000);
        $('#backupPassword').value = ''; $('#backupPasswordConfirm').value = '';
        notify(`تم إنشاء النسخة المشفرة (${(blob.size / 1024 / 1024).toFixed(2)} MB). احتفظ بكلمة المرور منفصلة عن الملف.`, 'success');
      } catch (error) { notify(error.message || 'تعذر إنشاء النسخة الاحتياطية.', 'error'); }
      finally { button.disabled = false; button.classList.remove('loading'); }
    });
    const backupInspectionKey = file => file ? `${file.name}|${file.size}|${file.lastModified}` : '';
    const resetBackupInspection = message => {
      const status = $('#backupFileStatus'), preview = $('#backupInspectionResult');
      if (status) { status.dataset.previewed = ''; status.dataset.inspectionToken = ''; if (message) status.textContent = message; }
      if (preview) { preview.hidden = true; preview.textContent = ''; }
      const file = $('#restoreBackupFile')?.files?.[0];
      if ($('#inspectBackupBtn')) $('#inspectBackupBtn').disabled = !file || backupPassword().length < 12;
      if ($('#restoreBackupBtn')) $('#restoreBackupBtn').disabled = true;
    };
    $('#chooseBackupFileBtn')?.addEventListener('click', () => $('#restoreBackupFile')?.click());
    $('#restoreBackupFile')?.addEventListener('change', () => {
      const file = $('#restoreBackupFile')?.files?.[0];
      resetBackupInspection(file ? `${file.name} — ${(file.size / 1024 / 1024).toFixed(2)} MB. أدخل كلمة المرور ثم اضغط «فحص النسخة أولًا».` : 'لم يتم اختيار ملف للاستعادة.');
    });
    ['#backupPassword', '#backupPasswordConfirm'].forEach(selector => $(selector)?.addEventListener('input', () => resetBackupInspection('تغيرت كلمة المرور؛ يجب إعادة فحص النسخة قبل الاستعادة.')));
    $('#inspectBackupBtn')?.addEventListener('click', async event => {
      const button = event.currentTarget, file = $('#restoreBackupFile')?.files?.[0], password = backupPassword();
      if (!file) return notify('اختر ملف نسخة احتياطية أولًا.', 'error');
      if (password.length < 12) return notify('أدخل كلمة مرور النسخة، بطول 12 محرفًا على الأقل.', 'error');
      button.disabled = true; button.classList.add('loading');
      try {
        const passwordBytes = new TextEncoder().encode(password);
        let passwordBinary = ''; for (const byte of passwordBytes) passwordBinary += String.fromCharCode(byte);
        const passwordHeader = btoa(passwordBinary);
        const response = await fetch('/api/backup/inspect', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream', 'X-Backup-Password-B64': passwordHeader }, body: file });
        let result = {}; try { result = await response.json(); } catch {}
        if (!response.ok || result.ok !== true) throw new Error(result.error || `فشل فحص النسخة (${response.status}).`);
        const sessions = Array.isArray(result.sessions) ? result.sessions : [];
        const lines = sessions.map(item => `${item.active ? '★ ' : ''}${item.name || item.id}: ${Number(item.recipients || 0)} شخص، ${Number(item.groups || 0)} مجموعة، ${item.hasConversationArchive ? 'لديها أرشيف محادثات' : 'لا يوجد أرشيف محادثات'}، ${Number(item.mediaFiles || 0)} ملف وسائط`).join('\n');
        const preview = $('#backupInspectionResult');
        if (preview) { preview.hidden = false; preview.textContent = `النسخة سليمة من حيث التشفير وبنية ملفات الجلسات.
الإصدار: ${result.appVersion || 'غير معروف'}
تاريخ النسخة: ${result.createdAt || 'غير معروف'}
عدد الملفات: ${Number(result.fileCount || 0)}
الحجم الأصلي: ${(Number(result.totalBytes || 0) / 1024 / 1024).toFixed(2)} MB
الجلسات: ${sessions.length}
${lines}

لم تُعدّل البيانات الحالية. الاستعادة ستستبدلها بعد إنشاء نقطة رجوع مشفرة.`; }
        const status = $('#backupFileStatus');
        if (status) { status.dataset.previewed = backupInspectionKey(file); status.dataset.inspectionToken = String(result.inspectionToken || ''); }
        $('#restoreBackupBtn').disabled = false;
        notify('اجتازت النسخة الفحص. راجع ملخصها ثم أكد الاستعادة عند الاستعداد.', 'success');
      } catch (error) {
        resetBackupInspection(`فشل فحص النسخة: ${error.message}`);
        notify(error.message || 'تعذر فحص النسخة.', 'error');
      } finally { button.disabled = !$('#restoreBackupFile')?.files?.[0] || backupPassword().length < 12; button.classList.remove('loading'); }
    });
    $('#restoreBackupBtn')?.addEventListener('click', async (event) => {
      const button = event.currentTarget, file = $('#restoreBackupFile')?.files?.[0], password = backupPassword();
      if (!file) return notify('اختر ملف نسخة احتياطية أولًا.', 'error');
      if (password.length < 12) return notify('أدخل كلمة مرور النسخة، بطول 12 محرفًا على الأقل.', 'error');
      if ($('#backupFileStatus')?.dataset?.previewed !== backupInspectionKey(file) || !$('#backupFileStatus')?.dataset?.inspectionToken) return notify('افحص النسخة أولًا. يجب إعادة الفحص إذا تغير الملف أو كلمة المرور.', 'warning');
      if (!confirm(`تم فحص النسخة. ستُستبدل بيانات المشروع الحالية بالنسخة «${file.name}»، مع إنشاء نقطة رجوع مشفرة. هل تريد المتابعة؟`)) return;
      button.disabled = true; button.classList.add('loading');
      try {
        const passwordBytes = new TextEncoder().encode(password);
        let passwordBinary = ''; for (const byte of passwordBytes) passwordBinary += String.fromCharCode(byte);
        const passwordHeader = btoa(passwordBinary);
        const response = await fetch('/api/backup/restore', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream', 'X-Backup-Password-B64': passwordHeader, 'X-Backup-Inspection-Token': String($('#backupFileStatus')?.dataset?.inspectionToken || '') }, body: file });
        let result = {}; try { result = await response.json(); } catch {}
        if (!response.ok || result.ok !== true) throw new Error(result.error || `تعذرت الاستعادة (${response.status}).`);
        $('#backupPassword').value = ''; $('#backupPasswordConfirm').value = ''; $('#restoreBackupFile').value = ''; $('#backupFileStatus').textContent = 'تمت الاستعادة بنجاح.'; $('#backupFileStatus').dataset.previewed = ''; $('#backupFileStatus').dataset.inspectionToken = ''; $('#backupInspectionResult').hidden = true; $('#inspectBackupBtn').disabled = true; $('#restoreBackupBtn').disabled = true;
        notify(`تمت استعادة ${Number(result.fileCount || 0)} ملفًا عبر ${Number(result.sessions || 0)} جلسة.`, 'success');
        await load(true);
      } catch (error) { notify(error.message || 'تعذرت استعادة النسخة.', 'error'); }
      finally { button.disabled = !$('#restoreBackupFile')?.files?.[0] || $('#backupFileStatus')?.dataset?.previewed !== backupInspectionKey($('#restoreBackupFile')?.files?.[0]); button.classList.remove('loading'); }
    });
  }

  function go(page) {
    const next = ['appearance', 'operation'].includes(page) ? 'settings' : page;
    if (page === 'appearance') state.settingsView = 'appearance';
    if (page === 'operation') state.settingsView = 'operation';
    state.page = next || 'dashboard';
    location.hash = state.page;
    render();
    const active = $$(`.navbtn[data-page=\"${String(state.page).replace(/[^a-z-]/g, '')}\"]`)[0];
    try { active?.scrollIntoView({ behavior: 'auto', inline: 'nearest', block: 'nearest' }); } catch {}
    if (state.page === 'people' || state.page === 'send') loadCountries().catch(() => {});
  }

  class BackgroundEngine {
    constructor(canvas) {
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d');
      this.mode = 'aurora';
      this.cfg = { speed: 1, density: 1, glow: .6, intensity: 1, mouseStrength: 1, brightness: 1, contrast: 1, saturation: 1, hueRotate: 0, blur: 0, interactive: true, trail: true };
      this.pointer = { x: .5, y: .5, down: false };
      this.reducedMotion = matchMedia?.('(prefers-reduced-motion: reduce)')?.matches || false;
      if (this.reducedMotion) this.cfg.interactive = false;
      this.t = 0; this.last = 0; this.lastDrawAt = 0; this.frameInterval = 100;
      this.resize = this.resize.bind(this); this.frame = this.frame.bind(this);
      addEventListener('resize', this.resize);
      this.pointerMovePending = false;
      addEventListener('pointermove', (event) => {
        if (this.pointerMovePending || !this.cfg.interactive) return;
        this.pointerMovePending = true;
        requestAnimationFrame(() => { this.pointerMovePending = false; this.pointer.x = event.clientX / innerWidth; this.pointer.y = event.clientY / innerHeight; });
      }, { passive: true });
      addEventListener('pointerdown', () => { this.pointer.down = true; });
      addEventListener('pointerup', () => { this.pointer.down = false; });
      this.resize(); requestAnimationFrame(this.frame);
    }
    resize() { const scale = 1; const w = innerWidth, h = innerHeight; if (w === this.w && h === this.h) return; this.w = w; this.h = h; this.canvas.width = Math.max(1, Math.floor(this.w * scale)); this.canvas.height = Math.max(1, Math.floor(this.h * scale)); this.ctx.setTransform(scale, 0, 0, scale, 0, 0); }
    set(data) {
      if (!data) return;
      this.mode = data.mode || this.mode;
      const scene = $('#bgScene'); if (scene) scene.dataset.mode = this.mode;
      this.cfg = { ...this.cfg, ...(data.settings || {}) };
      const filter = `brightness(${this.cfg.brightness ?? 1}) contrast(${this.cfg.contrast ?? 1}) saturate(${this.cfg.saturation ?? 1}) hue-rotate(${this.cfg.hueRotate ?? 0}deg) blur(${this.cfg.blur ?? 0}px)`;
      this.canvas.style.filter = filter;
      const image = $('#bgImageLayer');
      if (image) {
        image.style.opacity = String(data.opacity ?? .22);
        image.style.filter = filter;
        if (Object.prototype.hasOwnProperty.call(data, 'imageUrl')) image.style.backgroundImage = data.imageUrl ? `url("${String(data.imageUrl).replace(/"/g, '%22')}")` : '';
      }
    }
    frame(ms) { if (document.hidden) { requestAnimationFrame(this.frame); return; } if (ms - this.lastDrawAt >= this.frameInterval) { const dt = Math.min(50, ms - (this.last || ms)); this.last = ms; this.lastDrawAt = ms; this.t += dt * .001 * Number(this.cfg.speed || 1); this.draw(); } requestAnimationFrame(this.frame); }
    clear() { this.ctx.fillStyle = `rgba(4,8,18,${this.cfg.trail ? .13 : .25})`; this.ctx.fillRect(0, 0, this.w, this.h); }
    draw() {
      const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, px = .5 + (this.pointer.x - .5) * Number(c.mouseStrength ?? 1), py = .5 + (this.pointer.y - .5) * Number(c.mouseStrength ?? 1);
      x.save(); this.clear(); x.globalCompositeOperation = 'source-over';
      if (this.mode === 'aurora') this.aurora(px, py); else if (this.mode === 'nebula') this.nebula(px, py); else if (this.mode === 'meteor') this.meteor(px, py); else if (this.mode === 'matrix') this.matrix(px, py); else if (this.mode === 'cyber-grid') this.grid(px, py); else if (this.mode === 'plasma') this.plasma(px, py); else if (this.mode === 'starfield') this.stars(px, py); else if (this.mode === 'vortex') this.vortex(px, py); else if (this.mode === 'galaxy') this.galaxy(px, py); else this.ocean(px, py);
      if (c.interactive) { x.beginPath(); x.arc(px * w, py * h, 18 + Math.sin(t * 4) * 5, 0, Math.PI * 2); x.strokeStyle = `rgba(170,235,255,${.08 * c.intensity})`; x.lineWidth = 1.2 + c.glow * 1.4; x.stroke(); if (this.pointer.down) { x.beginPath(); x.arc(px * w, py * h, 42 + Math.sin(t * 9) * 8, 0, Math.PI * 2); x.strokeStyle = `rgba(210,160,255,${.16 * c.intensity})`; x.stroke(); } } x.restore();
    }
    aurora(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, shift = (px - .5) * 80; for (let k = 0; k < Math.max(2, Math.round(2 + c.density * 2)); k++) { x.beginPath(); for (let i = 0; i <= w; i += 12) x.lineTo(i, h * (.22 + k * .16) + (py - .5) * 45 + Math.sin(i * .008 + t * (.7 + k * .2) + shift * .003) * 35 + Math.sin(i * .002 - t * .35) * 24); x.strokeStyle = `hsla(${165 + k * 45},90%,65%,${.055 * c.intensity})`; x.lineWidth = 55; x.shadowBlur = 24 * c.glow; x.stroke(); } }
    nebula(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(34 * c.density); for (let i = 0; i < n; i++) { const a = (i * 12.9898) % 6.283, r = ((i * 37.13) % 1) * Math.min(w, h) * .48, q = t * (.2 + (i % 7) / 35), cx = w * (.5 + (px - .5) * .08), cy = h * (.5 + (py - .5) * .08), vx = cx + Math.cos(a + q) * r, vy = cy + Math.sin(a + q * .8) * r * .65, z = 2 + ((i * 17) % 8); x.fillStyle = `hsla(${205 + (i % 4) * 32},90%,70%,${.12 * c.intensity})`; x.beginPath(); x.arc(vx, vy, z, 0, Math.PI * 2); x.fill(); } }
    meteor(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(18 * c.density), bias = (px - .5) * 80; for (let i = 0; i < n; i++) { const speed = 70 + (i % 9) * 18, vx = (i * 97 + t * speed * 1.8 + bias) % (w + 300) - 150, vy = (i * 43 + t * speed * .7 + (py - .5) * 50) % (h + 120) - 60; x.beginPath(); x.moveTo(vx, vy); x.lineTo(vx - speed * .28, vy - speed * .11); x.strokeStyle = `hsla(${185 + (i % 5) * 25},95%,70%,${.18 * c.intensity})`; x.lineWidth = 1 + (i % 3); x.stroke(); } }
    matrix(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, cols = Math.floor(58 * c.density), step = Math.max(13, w / Math.max(cols, 1)); x.font = '15px monospace'; for (let i = 0; i < cols; i++) { const y = (i * 79 + t * (55 + (i % 7) * 6) + (py - .5) * 100) % (h + 220) - 220; x.fillStyle = `rgba(110,231,249,${.2 * c.intensity})`; x.fillText(String.fromCharCode(0x30a0 + (i * 13) % 90), i * step, y); } }
    grid(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, step = Math.max(38, 112 - c.density * 45), oy = (t * 35 + (py - .5) * 50) % step, ox = (t * 18 + (px - .5) * 50) % step; x.strokeStyle = `rgba(110,231,249,${.09 * c.intensity})`; for (let y = -step + oy; y < h + step; y += step) { x.beginPath(); x.moveTo(0, y); x.lineTo(w, y); x.stroke(); } for (let xx = -step + ox; xx < w + step; xx += step) { x.beginPath(); x.moveTo(xx, 0); x.lineTo(xx, h); x.stroke(); } }
    plasma(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg; for (let k = 0; k < Math.max(3, Math.round(4 + c.density * 4)); k++) { x.beginPath(); for (let i = 0; i <= w; i += 10) x.lineTo(i, h * (.15 + k * .12) + (py - .5) * 35 + Math.sin(i * .012 + t * (1 + k * .07) + (px - .5)) * 26 + Math.sin(i * .004 - t * .6) * 22); x.strokeStyle = `hsla(${190 + k * 24},85%,62%,${.07 * c.intensity})`; x.lineWidth = 18; x.stroke(); } }
    stars(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(56 * c.density); for (let i = 0; i < n; i++) { const z = ((i * 31 + t * 14) % 100) / 100, r = .3 + z * 2.5, vx = (i * 97.31 + (px - .5) * 40) % w, vy = (i * 47.21 + (py - .5) * 40) % h; x.fillStyle = `rgba(220,240,255,${.15 + z * .6})`; x.beginPath(); x.arc(vx, vy, r, 0, Math.PI * 2); x.fill(); } }
    vortex(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(52 * c.density), cx = w * (.5 + (px - .5) * .18), cy = h * (.5 + (py - .5) * .12); for (let i = 0; i < n; i++) { const p = i / n, a = p * Math.PI * 10 + t * (.3 + p), r = p * Math.min(w, h) * .42, vx = cx + Math.cos(a) * r, vy = cy + Math.sin(a) * r * .62; x.fillStyle = `hsla(${190 + p * 130},95%,68%,${.11 * c.intensity})`; x.beginPath(); x.arc(vx, vy, 1 + p * 2.5, 0, Math.PI * 2); x.fill(); } }
    galaxy(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(72 * c.density), cx = w * (.5 + (px - .5) * .14), cy = h * (.5 + (py - .5) * .1); for (let i = 0; i < n; i++) { const p = i / n, a = i * .55 + t * (.45 + p), r = p * Math.min(w, h) * .46 + Math.sin(i * 2.7) * 4, vx = cx + Math.cos(a) * r, vy = cy + Math.sin(a) * r * .42; x.fillStyle = `hsla(${190 + (i % 6) * 22},90%,72%,${.08 + c.intensity * .08})`; x.beginPath(); x.arc(vx, vy, .5 + p * 2.2, 0, Math.PI * 2); x.fill(); } }
    ocean(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg; for (let k = 0; k < 3; k++) { x.beginPath(); for (let i = 0; i <= w; i += 10) x.lineTo(i, h * (.52 + k * .07) + (py - .5) * 40 + Math.sin(i * .009 + t * (.65 + k * .05) + px * 2) * 18 + Math.sin(i * .003 - t * .45) * 10); x.strokeStyle = `hsla(${180 + k * 8},85%,65%,${.055 * c.intensity})`; x.lineWidth = 10 + c.glow * 10; x.stroke(); } }
  }

  function applyInterfaceTheme(data = state.data) {
    const a = data?.settings?.appearance || {};
    const root = document.documentElement;
    root.dataset.theme = state.uiMode || 'dark';
    root.style.setProperty('--accent', a.accent || '#5ed6c1');
    root.style.setProperty('--accent-2', a.accent2 || '#8b7cf6');
    root.style.setProperty('--panel-opacity', String(a.panelOpacity ?? .88));
    root.style.setProperty('--panel-blur', `${Number(a.panelBlur ?? 14)}px`);
    root.style.setProperty('--radius', `${Number(a.radius ?? 18)}px`);
    root.style.setProperty('--ui-glow', String(Number(a.glow ?? .55)));
  }

  function readInterfaceForm() {
    return {
      accent: $('#uiAccent')?.value || '#5ed6c1',
      accent2: $('#uiAccent2')?.value || '#8b7cf6',
      panelOpacity: Number($('#uiPanelOpacity')?.value || .88),
      panelBlur: Number($('#uiPanelBlur')?.value || 14),
      radius: Number($('#uiRadius')?.value || 18),
      glow: Number($('#uiGlow')?.value || .55),
    };
  }

  function applyInterfaceLive() { applyInterfaceTheme({ settings: { appearance: readInterfaceForm() } }); }

  function setupBackground() {
    const canvas = $('#bgCanvas'); if (!canvas) return;
    if (!state.bgEngine) state.bgEngine = new BackgroundEngine(canvas);
    if (state.data?.background) state.bgEngine.set(state.data.background);
  }

  async function boot() {
    try {
      await loadCountries().catch(() => null);
      await load();
      // QR events occur asynchronously after initialize(); keep the session panel live while it waits.
      setInterval(() => { if (state.page === 'session') refreshSessionRuntime(); }, 1400);
      addEventListener('hashchange', () => { state.page = location.hash.slice(1) || 'dashboard'; render(); if (state.page === 'session') refreshSessionRuntime(); });
    } catch (error) {
      document.body.innerHTML = `<div class="fatal"><h1>تعذر تشغيل الواجهة</h1><p>${esc(error.message)}</p><button class="btn primary" onclick="location.reload()">إعادة المحاولة</button></div>`;
    }
  }

  boot();
})();
