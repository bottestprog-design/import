'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

function safeName(value, fallback = '') {
  return String(value || '').replace(/[\u0000-\u001f<>:"/\\|?*]/g, '').trim().slice(0, 100) || fallback;
}
function digitsFromJid(jid) {
  const match = String(jid || '').toLowerCase().match(/^(\d{5,25})@c\.us$/);
  return match ? match[1] : '';
}
function isAllowedProfileUrl(value) {
  let parsed;
  try { parsed = new URL(value); } catch { return false; }
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password || !parsed.hostname) return false;
  const host = parsed.hostname.toLowerCase();
  if (/^\d+\.\d+\.\d+\.\d+$/.test(host) || host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local')) return false;
  return /(?:^|\.)(?:whatsapp\.net|fbcdn\.net|facebook\.com|fbsbx\.com)$/i.test(host);
}
function profileKey(jid) {
  return crypto.createHash('sha256').update(String(jid).toLowerCase()).digest('hex').slice(0, 24);
}
function isAvifPayload(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 16 || buffer.subarray(4, 8).toString('ascii') !== 'ftyp') return false;
  const declared = buffer.readUInt32BE(0);
  const end = declared >= 16 && declared <= buffer.length ? declared : buffer.length;
  // ISO-BMFF AVIF files may use 'mif1' as the major brand and advertise AVIF
  // only in compatible brands. Check the full ftyp brand list, not just offset 8.
  for (let offset = 8; offset + 4 <= end; offset += 4) {
    const brand = buffer.subarray(offset, offset + 4).toString('ascii');
    if (brand === 'avif' || brand === 'avis') return true;
  }
  return false;
}

function imageExtensionFromBuffer(buffer) {
  if (!Buffer.isBuffer(buffer)) return '';
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return '.jpg';
  if (buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) return '.png';
  if (buffer.length >= 12 && buffer.subarray(0, 4).toString('ascii') === 'RIFF' && buffer.subarray(8, 12).toString('ascii') === 'WEBP') return '.webp';
  if (buffer.length >= 6 && /^GIF8[79]a$/.test(buffer.subarray(0, 6).toString('ascii'))) return '.gif';
  return isAvifPayload(buffer) ? '.avif' : '';
}
function cachedProfile(profileDir, jid) {
  const base = path.join(profileDir, profileKey(jid));
  for (const ext of ['.jpg', '.jpeg', '.png', '.webp', '.gif', '.avif']) {
    const candidate = `${base}${ext}`;
    try {
      const stat = fs.statSync(candidate);
      if (!stat.isFile() || stat.size < 1 || stat.size > 5 * 1024 * 1024) { fs.rmSync(candidate, { force: true }); continue; }
      const fd = fs.openSync(candidate, 'r');
      let header;
      try { const bytes = Buffer.alloc(Math.min(stat.size, 64)); fs.readSync(fd, bytes, 0, bytes.length, 0); header = bytes; }
      finally { fs.closeSync(fd); }
      const detected = imageExtensionFromBuffer(header);
      if (detected && (detected === ext || detected === '.jpg' && ext === '.jpeg')) return path.basename(candidate);
      // A non-empty corrupt file used to poison the cache permanently. Delete only
      // the deterministic WhatsApp cache entry so the next request can refetch it.
      fs.rmSync(candidate, { force: true });
    } catch {}
  }
  return '';
}

// Follow only explicitly allowed WhatsApp/Facebook CDN redirects. Never fetch an arbitrary URL.
async function downloadProfile(url, destination) {
  if (typeof fetch !== 'function' || !isAllowedProfileUrl(url)) return false;
  let current;
  try { current = new URL(url); } catch { return false; }
  let response = null;
  for (let hop = 0; hop <= 3; hop++) {
    if (!isAllowedProfileUrl(current.href)) return false;
    try { response = await fetch(current.href, { signal: AbortSignal.timeout(12000), redirect: 'manual' }); }
    catch { return false; }
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get('location');
      if (!location || hop === 3) return false;
      try { current = new URL(location, current); } catch { return false; }
      if (!isAllowedProfileUrl(current.href)) return false;
      continue;
    }
    break;
  }
  if (!response?.ok) return false;
  // CDNs occasionally label a real avatar as application/octet-stream or omit
  // Content-Type. We validate the image's binary signature below, so MIME alone
  // must not cause valid WhatsApp profile photos to disappear.
  const declaredSize = Number(response.headers.get('content-length') || 0);
  if (declaredSize > 5 * 1024 * 1024) return false;
  let buffer;
  try {
    // Stream with a hard cap. Content-Length is often missing on CDN redirects;
    // arrayBuffer() alone could otherwise allocate an unexpectedly large response.
    if (response.body && typeof response.body.getReader === 'function') {
      const reader = response.body.getReader(), chunks = [];
      let total = 0;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        total += value.byteLength;
        if (total > 5 * 1024 * 1024) { try { await reader.cancel(); } catch {} return false; }
        chunks.push(Buffer.from(value));
      }
      buffer = Buffer.concat(chunks, total);
    } else {
      buffer = Buffer.from(await response.arrayBuffer());
    }
  } catch { return false; }
  if (!buffer.length || buffer.length > 5 * 1024 * 1024) return false;
  // Reject HTML/error pages masquerading as images and keep the actual extension
  // derived from the payload instead of trusting a remote file name.
  const actualExt = imageExtensionFromBuffer(buffer);
  if (!actualExt) return false;
  const file = `${destination}${actualExt}`;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const temp = `${file}.tmp-${process.pid}-${Date.now()}`;
  try {
    fs.writeFileSync(temp, buffer, { flag: 'wx' });
    for (const oldExt of ['.jpg', '.jpeg', '.png', '.webp', '.gif', '.avif']) {
      const old = `${destination}${oldExt}`;
      if (old !== file) { try { fs.rmSync(old, { force: true }); } catch {} }
    }
    fs.renameSync(temp, file);
    return path.basename(file);
  } catch {
    try { fs.rmSync(temp, { force: true }); } catch {}
    return false;
  }
}

async function ensureContactPictureInternal({ store, whatsapp, sessionId, jid, refresh = false }) {
  const id = store.safeSessionId(sessionId);
  const normalizedJid = String(jid || '').trim().toLowerCase();
  if (!digitsFromJid(normalizedJid)) throw new Error('معرّف جهة WhatsApp غير صالح أو غير مرتبط برقم مؤكد.');
  const paths = store.getPaths(id);
  const profileDir = paths.profiles || path.join(paths.dir, 'profiles');
  fs.mkdirSync(profileDir, { recursive: true });
  const cached = cachedProfile(profileDir, normalizedJid);
  if (cached && !refresh) return { filename: cached, cached: true };
  let url = '';
  // Only use the secondary contacts adapter when the direct profile API exists
  // but returns an empty result. Bulk sync already has a contacts snapshot; don't
  // repeatedly fetch the whole list for each item in legacy/test adapters.
  if (typeof whatsapp.getContactProfilePictureUrl === 'function') {
    try { url = await whatsapp.getContactProfilePictureUrl(id, normalizedJid); } catch {}
    if (!url && typeof whatsapp.listContacts === 'function') {
      try {
        const fallbackContacts = await whatsapp.listContacts(id, { includeProfilePictures: true, onlyJids: [normalizedJid], limit: 5 });
        url = String(fallbackContacts.find(item => String(item.jid || '').toLowerCase() === normalizedJid)?.profilePicUrl || '');
      } catch {}
    }
  }
  if (!url) return cached ? { filename: cached, cached: true } : null;
  if (!isAllowedProfileUrl(url)) return cached ? { filename: cached, cached: true } : null;
  const saved = await downloadProfile(url, path.join(profileDir, profileKey(normalizedJid)));
  if (saved) return { filename: saved, cached: false };
  if (cached) return { filename: cached, cached: true };
  // Keep the trusted URL as a fallback when downloading/caching the CDN image
  // fails (for example, a format the local decoder does not recognize). The
  // API may redirect only to this allowlisted HTTPS URL; the client never sends it.
  return isAllowedProfileUrl(url) ? { filename: '', cached: false, remoteUrl: url } : null;
}

// Multiple contact cards can request the same lazy-loaded picture at once. Share
// one lookup/download per session/JID so scrolling the list does not stampede WhatsApp.
const profilePictureInFlight = new Map();
async function ensureContactPicture(options) {
  const sid = String(options?.store?.safeSessionId?.(options.sessionId) || options?.sessionId || 'main');
  const jid = String(options?.jid || '').trim().toLowerCase();
  const key = `${sid}|${jid}|${options?.refresh === true ? 'refresh' : 'cached'}`;
  if (profilePictureInFlight.has(key)) return profilePictureInFlight.get(key);
  const pending = ensureContactPictureInternal(options);
  profilePictureInFlight.set(key, pending);
  try { return await pending; }
  finally { if (profilePictureInFlight.get(key) === pending) profilePictureInFlight.delete(key); }
}

async function refreshContactPictures({ store, whatsapp, sessionId, jids, profileUrls = {}, concurrency = 4 }) {
  const id = store.safeSessionId(sessionId);
  const selected = [...new Set((Array.isArray(jids) ? jids : []).map(x => String(x || '').trim().toLowerCase()).filter(x => digitsFromJid(x)))].slice(0, 100);
  if (!selected.length) return { photosUpdated: 0, photosCached: 0, photosRemoteFallback: 0, photosFailed: 0 };
  if (typeof store.listSessionIds === 'function' && !store.listSessionIds().includes(id)) return { photosUpdated: 0, photosCached: 0, photosRemoteFallback: 0, photosFailed: selected.length, cancelled: true };
  const profileDir = store.getPaths(id).profiles || path.join(store.getPaths(id).dir, 'profiles');
  fs.mkdirSync(profileDir, { recursive: true });
  const photoResults = new Map();
  let cursor = 0;
  const workers = Array.from({ length: Math.min(Math.max(1, Math.min(4, Number(concurrency) || 4)), selected.length) }, async () => {
    while (cursor < selected.length) {
      const jid = selected[cursor++];
      try {
        let photo = null;
        const directUrl = String(profileUrls?.[jid] || '').trim();
        if (directUrl && isAllowedProfileUrl(directUrl)) {
          const filename = await downloadProfile(directUrl, path.join(profileDir, profileKey(jid)));
          // A failed refresh must never replace a valid old photo with a broken
          // remote link. Prefer the verified cache; use the CDN URL only when no
          // usable local image exists.
          const cached = filename ? '' : cachedProfile(profileDir, jid);
          photo = filename ? { filename, cached: false } : cached ? { filename: cached, cached: true } : { filename: '', remoteUrl: directUrl };
        }
        if (!photo?.filename && !photo?.remoteUrl) photo = await ensureContactPicture({ store, whatsapp, sessionId: id, jid, refresh: true });
        photoResults.set(jid, { filename: photo?.filename || '', remoteUrl: isAllowedProfileUrl(photo?.remoteUrl) ? photo.remoteUrl : '' });
      } catch { photoResults.set(jid, { filename: '', remoteUrl: '' }); }
    }
  });
  await Promise.all(workers);
  // Load the latest session after network work so a background picture task does
  // not overwrite recipients/settings saved while the downloads were in flight.
  // If the session was deleted while a CDN request was pending, do not recreate it.
  if (typeof store.listSessionIds === 'function' && !store.listSessionIds().includes(id)) return { photosUpdated: 0, photosCached: 0, photosRemoteFallback: 0, photosFailed: selected.length, cancelled: true };
  const session = store.loadSession(id);
  let photosUpdated = 0, photosCached = 0, photosRemoteFallback = 0, photosFailed = 0, changed = false;
  for (const jid of selected) {
    const digits = digitsFromJid(jid), photo = photoResults.get(jid) || { filename: '', remoteUrl: '' };
    const person = session.recipients.find(item => String(item.whatsappJid || '').toLowerCase() === jid)
      || session.recipients.find(item => String(item.digits || item.e164 || item.phone || '').replace(/\D/g, '') === digits);
    if (photo.filename) photosCached++;
    if (photo.remoteUrl && isAllowedProfileUrl(photo.remoteUrl)) photosRemoteFallback++;
    if (!person) { if (!photo.filename && !photo.remoteUrl) photosFailed++; continue; }
    if (photo.filename) {
      if (person.whatsappProfilePhoto !== photo.filename) { person.whatsappProfilePhoto = photo.filename; changed = true; }
      if (person.whatsappAvatarUrl) { delete person.whatsappAvatarUrl; changed = true; }
      photosUpdated++;
    } else if (photo.remoteUrl && isAllowedProfileUrl(photo.remoteUrl)) {
      if (person.whatsappAvatarUrl !== photo.remoteUrl) { person.whatsappAvatarUrl = photo.remoteUrl; changed = true; }
    } else {
      photosFailed++;
    }
  }
  if (changed) store.saveSession(session);
  return { photosUpdated, photosCached, photosRemoteFallback, photosFailed };
}

async function syncContacts({ store, whatsapp, phones, sessionId, jids, importMissing = true, updateNames = false, updatePictures = true }) {
  const id = store.safeSessionId(sessionId);
  const selected = [...new Set((Array.isArray(jids) ? jids : []).map(x => String(x || '').trim().toLowerCase()).filter(x => digitsFromJid(x)))].slice(0, 1000);
  if (!selected.length) throw new Error('حدد جهة WhatsApp واحدة على الأقل للمزامنة.');
  if (updatePictures && selected.length > 100) throw new Error('مزامنة الصور محدودة بـ 100 جهة في الدفعة الواحدة. قسّم الاختيارات إلى دفعات للحفاظ على سرعة الاتصال واستقراره.');
  const liveContacts = await whatsapp.listContacts(id, { includeProfilePictures: Boolean(updatePictures), onlyJids: selected });
  const indexed = new Map(liveContacts.map(item => [item.jid, item]));
  const profileDir = store.getPaths(id).profiles || path.join(store.getPaths(id).dir, 'profiles');
  fs.mkdirSync(profileDir, { recursive: true });
  const result = { imported: [], updated: [], skipped: [], photosUpdated: 0, photosFailed: 0, unresolved: [] };

  // Download selected profile pictures with a small bounded pool. This avoids serially
  // waiting on each CDN request while keeping WhatsApp/CDN traffic under control.
  const pictureResults = new Map();
  if (updatePictures) {
    const pictureJids = selected.filter(jid => indexed.has(jid));
    let cursor = 0;
    const workers = Array.from({ length: Math.min(4, pictureJids.length) }, async () => {
      while (cursor < pictureJids.length) {
        const jid = pictureJids[cursor++];
        const contact = indexed.get(jid);
        let saved = cachedProfile(profileDir, jid), remoteUrl = '';
        try {
          if (contact?.profilePicUrl && isAllowedProfileUrl(contact.profilePicUrl)) {
            const downloaded = await downloadProfile(contact.profilePicUrl, path.join(profileDir, profileKey(jid)));
            if (downloaded) saved = downloaded; else if (!saved) remoteUrl = contact.profilePicUrl;
          } else {
            const picture = await ensureContactPicture({ store, whatsapp, sessionId: id, jid });
            if (picture?.filename) saved = picture.filename;
            else if (picture?.remoteUrl && isAllowedProfileUrl(picture.remoteUrl)) remoteUrl = picture.remoteUrl;
          }
        } catch { /* Keep the previously cached picture if a refresh fails. */ }
        pictureResults.set(jid, { filename: saved, cached: Boolean(saved), remoteUrl: saved ? '' : remoteUrl });
      }
    });
    await Promise.all(workers);
  }

  // Contact/profile lookups may wait on WhatsApp or a CDN. Re-read the current
  // session only after that I/O so changes made while syncing (names, settings,
  // recipient edits) are not overwritten by a stale snapshot.
  if (typeof store.listSessionIds === 'function' && !store.listSessionIds().includes(id)) {
    return { imported: [], updated: [], skipped: [], photosUpdated: 0, photosFailed: selected.length, unresolved: selected, cancelled: true, message: 'أُلغيت المزامنة لأن الجلسة حُذفت أثناء الاتصال؛ لم تتم كتابة أي تغييرات.' };
  }
  const session = store.loadSession(id);
  for (const jid of selected) {
    const contact = indexed.get(jid);
    if (!contact) { result.unresolved.push(jid); continue; }
    const digits = digitsFromJid(jid);
    let parsed;
    try { parsed = phones.parse(`+${digits}`); } catch (error) { result.skipped.push({ jid, reason: error.message }); continue; }
    let person = session.recipients.find(item => String(item.whatsappJid || '').toLowerCase() === jid)
      || session.recipients.find(item => String(item.digits || item.e164 || item.phone || '').replace(/\D/g, '') === parsed.digits || String(item.e164 || '') === parsed.e164);
    const preferred = safeName(contact.name || contact.pushname || contact.notifyName, `+${digits}`);
    const now = new Date().toISOString();
    if (!person) {
      if (!importMissing) { result.skipped.push({ jid, reason: 'غير موجود في القائمة المحلية' }); continue; }
      person = { id: crypto.randomUUID(), name: preferred, ...parsed, enabled: true };
      session.recipients.push(person);
      result.imported.push({ id: person.id, name: person.name, phone: parsed.international });
    } else {
      result.updated.push({ id: person.id, name: person.name, phone: parsed.international });
      if (updateNames && preferred) person.name = preferred;
      Object.assign(person, { ...parsed });
    }
    person.whatsappJid = jid;
    person.whatsappName = safeName(contact.name, '');
    person.whatsappPushname = safeName(contact.pushname || contact.notifyName, '');
    person.whatsappIsMyContact = Boolean(contact.isMyContact);
    person.whatsappSyncedAt = now;
    if (updatePictures) {
      const picture = pictureResults.get(jid);
      if (picture?.filename) { person.whatsappProfilePhoto = picture.filename; person.whatsappAvatarUrl = ''; result.photosUpdated++; }
      else if (picture?.remoteUrl && isAllowedProfileUrl(picture.remoteUrl)) { person.whatsappAvatarUrl = picture.remoteUrl; result.photosRemoteFallback = (result.photosRemoteFallback || 0) + 1; }
      else result.photosFailed++;
    }
  }
  store.saveSession(session);
  return { ...result, message: `اكتملت المزامنة: ${result.imported.length} جهة جديدة، ${result.updated.length} جهة محدّثة${updatePictures ? `، ${result.photosUpdated} صورة محفوظة${result.photosFailed ? `، وتعذر جلب ${result.photosFailed} صورة` : ''}` : ''}.` };
}

module.exports = { syncContacts, refreshContactPictures, digitsFromJid, downloadProfile, ensureContactPicture, isAllowedProfileUrl, isAvifPayload, imageExtensionFromBuffer, profileKey, cachedProfile };
