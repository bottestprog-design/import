'use strict';

const { chatIdOf } = require('./conversation-targets');

function cleanUniqueIds(value) {
  if (!Array.isArray(value)) throw new Error('يجب إرسال قائمة معرفات الأشخاص المراد حذفهم.');
  const ids = [...new Set(value.map(x => String(x || '').trim()).filter(Boolean))];
  if (ids.length > 2000) throw new Error('عدد العناصر المحددة كبير جدًا؛ احذفها على دفعات أصغر.');
  return ids;
}

function recipientChatIds(person) {
  // Keep every explicitly stored identity so delete cleanup also removes old PN
  // references when a contact has since acquired a WhatsApp LID. Never derive a
  // phone number from LID digits; only a separate saved phone field can do that.
  const ids = new Set();
  for (const value of [person?.whatsappJid, person?.chatId, person?.waChatId, person?.jid, person?.lid, person?.lidJid, person?.whatsappLid, person?.whatsappId]) {
    const jid = chatIdOf(value);
    if (/^(?:\d{5,25}@c\.us|\d{5,25}@lid)$/u.test(jid)) ids.add(jid);
  }
  const digits = String(person?.digits || person?.phone || person?.e164 || person?.number || person?.international || '').replace(/\D/g, '');
  if (digits.length >= 5) ids.add(`${digits}@c.us`);
  return [...ids];
}
function recipientChatId(person) { return recipientChatIds(person)[0] || ''; }

function deleteRecipients(session, requestedIds) {
  const ids = cleanUniqueIds(requestedIds);
  if (!ids.length) throw new Error('حدد شخصًا واحدًا على الأقل.');
  const wanted = new Set(ids);
  const removedPeople = (session.recipients || []).filter(person => wanted.has(String(person.id)));
  if (!removedPeople.length) throw new Error('لم يتم العثور على الأشخاص المحددين في هذه الجلسة.');
  const removedIds = new Set(removedPeople.map(person => String(person.id)));
  const removedKeys = new Set([...removedIds].map(id => `r:${id}`));
  const removedChats = new Set(removedPeople.flatMap(recipientChatIds));
  const hadExplicitScheduleTargets = Array.isArray(session.settings?.scheduleTargetKeys) && session.settings.scheduleTargetKeys.length > 0;

  session.recipients = (session.recipients || []).filter(person => !removedIds.has(String(person.id)));
  session.settings ||= {};
  session.settings.scheduleTargetKeys = (session.settings.scheduleTargetKeys || []).filter(key => !removedKeys.has(String(key)));
  const scheduleDisabledToPreventWidening = hadExplicitScheduleTargets && session.settings.scheduleTargetKeys.length === 0;
  if (scheduleDisabledToPreventWidening) session.settings.scheduleEnabled = false;
  session.settings.interactionChatIds = (session.settings.interactionChatIds || []).filter(chat => !removedChats.has(String(chat || '').toLowerCase()));

  session.automation ||= {};
  session.automation.tasks = (session.automation.tasks || []).map(task => ({
    ...task,
    targetKeys: (task.targetKeys || []).filter(key => !removedKeys.has(String(key))),
  }));
  session.automation.rules = (session.automation.rules || []).map(rule => ({
    ...rule,
    targetKeys: Array.isArray(rule.targetKeys) ? rule.targetKeys.filter(key => !removedKeys.has(String(key))) : rule.targetKeys,
    targetChatIds: Array.isArray(rule.targetChatIds) ? rule.targetChatIds.filter(chat => !removedChats.has(String(chat || '').toLowerCase())) : rule.targetChatIds,
  }));

  session.automation.mutes = (session.automation.mutes || []).filter(mute => !removedChats.has(String(mute.chatId || '').toLowerCase()));
  session.interaction ||= {};
  session.interaction.contextByChat ||= {};
  session.interaction.counterState ||= {};
  session.interaction.counterState.byChat ||= {};
  session.interaction.counterState.fired ||= {};
  session.interaction.counterState.pending ||= {};
  session.automation.eventState ||= { totalMessages: 0, byChat: {}, seenMessages: {}, ruleCounts: {} };
  session.automation.eventState.byChat ||= {};
  for (const chat of removedChats) {
    delete session.interaction.contextByChat[chat];
    delete session.interaction.counterState.byChat[chat];
    delete session.interaction.counterState.fired[chat];
    delete session.interaction.counterState.pending[chat];
    delete session.automation.eventState.byChat[chat];
  }

  return { deleted: removedPeople.map(person => ({ id: String(person.id), name: String(person.name || '') })), removedIds: [...removedIds], removedTargetKeys: [...removedKeys], removedChats: [...removedChats], scheduleDisabledToPreventWidening };
}

module.exports = { deleteRecipients, cleanUniqueIds, recipientChatId, recipientChatIds };
