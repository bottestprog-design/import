'use strict';

function parts(date, tz) {
  const p = new Intl.DateTimeFormat('en-US', { timeZone: tz, weekday: 'short', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(date);
  const g = key => p.find(item => item.type === key)?.value;
  const weekday = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[g('weekday')];
  return { year: +g('year'), month: +g('month'), day: +g('day'), hour: +g('hour'), minute: +g('minute'), weekday };
}
function validTime(value) {
  const match = String(value || '17:30').match(/^(\d{2}):(\d{2})$/);
  return match && +match[1] < 24 && +match[2] < 60 ? { h: +match[1], m: +match[2] } : null;
}
function zonedDateToUtc(dateText, timeText, tz) {
  const [year, month, day] = String(dateText).split('-').map(Number), time = validTime(timeText);
  if (!year || !month || !day || !time) return null;
  const calendar = new Date(Date.UTC(year, month - 1, day));
  if (calendar.getUTCFullYear() !== year || calendar.getUTCMonth() !== month - 1 || calendar.getUTCDate() !== day) return null;
  let guess = new Date(Date.UTC(year, month - 1, day, time.h, time.m, 0));
  try {
    for (let index = 0; index < 8; index++) {
      const local = parts(guess, tz);
      const actual = Date.UTC(local.year, local.month - 1, local.day, local.hour, local.minute);
      const wanted = Date.UTC(year, month - 1, day, time.h, time.m);
      const difference = wanted - actual;
      if (difference === 0) {
        const verified = parts(guess, tz);
        return verified.year === year && verified.month === month && verified.day === day && verified.hour === time.h && verified.minute === time.m ? guess : null;
      }
      guess = new Date(guess.getTime() + difference);
    }
  } catch { return null; }
  // Nonexistent local times during a daylight-saving gap must not be silently shifted.
  try {
    const final = parts(guess, tz);
    if (final.year === year && final.month === month && final.day === day && final.hour === time.h && final.minute === time.m) return guess;
  } catch {}
  return null;
}
function localDate(value) { return `${value.year}-${String(value.month).padStart(2, '0')}-${String(value.day).padStart(2, '0')}`; }
function dateAdd(year, month, day, offset) {
  const date = new Date(Date.UTC(year, month - 1, day) + offset * 86400000);
  return { year: date.getUTCFullYear(), month: date.getUTCMonth() + 1, day: date.getUTCDate() };
}
function matchesCalendar(local, item) {
  const mode = item.mode || 'weekly';
  if (mode === 'daily') return true;
  if (mode === 'weekly') return local.weekday === Number(item.day ?? 5);
  if (mode === 'monthly') return local.day === Number(item.dayOfMonth || 1) && (!item.month || Number(item.month) === local.month) && (!item.year || Number(item.year) === local.year);
  if (mode === 'yearly') return local.day === Number(item.dayOfMonth || 1) && Number(item.month) === local.month && (!item.year || Number(item.year) === local.year);
  if (mode === 'once') return true;
  return false;
}
function dueForItem(now, item) {
  const timezone = item.timezone || 'Asia/Muscat';
  let local; try { local = parts(now, timezone); } catch { return { due: false, key: '' }; }
  const time = validTime(item.time || '17:30');
  if (!time || item.enabled === false) return { due: false, key: '' };
  const minute = local.hour * 60 + local.minute, target = time.h * 60 + time.m;
  if (minute < target || minute > target + 5) return { due: false, key: '' };
  if (item.mode === 'once') {
    if (String(item.date) !== localDate(local)) return { due: false, key: '' };
  } else if (!matchesCalendar(local, item)) return { due: false, key: '' };
  const key = `${item.id || 'legacy'}|${item.mode || 'weekly'}|${localDate(local)}|${item.time || '17:30'}|${timezone}`;
  return { due: item.lastRunKey !== key, key };
}
function nextRunForItem(item, now = new Date()) {
  if (item.enabled === false) return null;
  const timezone = item.timezone || 'Asia/Muscat', mode = item.mode || 'weekly', time = String(item.time || '17:30');
  if (mode === 'once') {
    const target = zonedDateToUtc(item.date, time, timezone);
    return target && target.getTime() >= now.getTime() ? target.toISOString() : null;
  }
  let start; try { start = parts(now, timezone); } catch { return null; }
  for (let offset = 0; offset < 800; offset++) {
    const date = dateAdd(start.year, start.month, start.day, offset);
    const calendar = { ...date, weekday: new Date(Date.UTC(date.year, date.month - 1, date.day)).getUTCDay(), hour: 0, minute: 0 };
    if (!matchesCalendar(calendar, item)) continue;
    const target = zonedDateToUtc(localDate(date), time, timezone);
    if (target && target.getTime() >= now.getTime()) return target.toISOString();
  }
  return null;
}
function legacy(session) {
  const settings = session.settings || {};
  return { id: 'legacy', enabled: settings.scheduleEnabled, mode: settings.scheduleMode, time: settings.scheduleTime, date: settings.scheduleDate, day: settings.scheduleDay, dayOfMonth: settings.scheduleMonthDay, month: settings.scheduleMonth, year: settings.scheduleYear, timezone: settings.timezone, lastRunKey: session.scheduleState?.lastRunKey || '' };
}
function due(now, session) { return dueForItem(now, legacy(session)); }
function nextRun(session, now = new Date()) { return nextRunForItem(legacy(session), now); }
function resultState(result) {
  if (result?.complete === true || (result?.complete === undefined && result?.ok === true)) return { status: 'done', consume: true };
  const sent = Array.isArray(result?.sent) ? result.sent.length : Number(result?.sentCount || 0);
  const failed = Array.isArray(result?.failed) ? result.failed : [];
  if (failed.some(item => item?.code === 'SEND_UNCERTAIN' || item?.uncertain === true)) return { status: 'uncertain', consume: true };
  if (sent > 0) return { status: 'partial', consume: true };
  if (failed.length > 0 && failed.every(item => item?.retryable === true)) return { status: 'failed', consume: false };
  return { status: 'blocked', consume: true };
}

class ReliableScheduler {
  constructor({ store, run, runTask, runAutomation, log }) {
    this.store = store; this.run = run; this.runTask = runTask; this.runAutomation = runAutomation; this.log = log || (() => {});
    this.busy = new Set(); this.taskBusy = new Set(); this.lastFail = new Map(); this.paused = false; this.activeTicks = 0;
    this.timer = setInterval(() => { if (!this.paused) this.tick().catch(error => this.log(null, 'ERROR', `Scheduler: ${error.message}`)); }, 1000);
    this.timer.unref?.();
  }
  stop() { clearInterval(this.timer); }
  async pause() {
    this.paused = true;
    for (let index = 0; index < 300 && this.activeTicks > 0; index++) await new Promise(resolve => setTimeout(resolve, 50));
    if (this.activeTicks > 0) { this.paused = false; throw new Error('لم يتوقف مجدول الرسائل بأمان لأن مهمة ما زالت تعمل. أعد المحاولة بعد انتهائها.'); }
  }
  resume() { this.paused = false; }
  async tick() {
    this.activeTicks++;
    try {
      if (this.paused) return;
      for (const id of this.store.listSessionIds()) {
        try { await this.tickSession(id); }
        catch (error) { this.log(id, 'ERROR', `Scheduler: ${error.message}`); }
      }
    } finally { this.activeTicks--; }
  }
  reserve(session, location, key) {
    const previous = location.lastAttempt;
    if (location.lastRunKey === key) return false;
    if (previous?.key === key) {
      if (previous.status === 'running') {
        location.lastAttempt = { ...previous, status: 'uncertain', detail: 'توقف الخادم أثناء الإرسال؛ لم تُعد المهمة تلقائيًا لتجنب التكرار.' };
        location.lastRunKey = key;
        this.store.saveSession(session);
        return false;
      }
      if (['done','partial','uncertain','blocked'].includes(previous.status)) return false;
      if (previous.status === 'failed' && Number(previous.retryAt || 0) > Date.now()) return false;
    }
    location.lastAttempt = { key, at: Date.now(), retryAt: 0, status: 'running', detail: '' };
    this.store.saveSession(session);
    return true;
  }
  finishAttempt(sessionId, location, key, result, error = null) {
    const session = this.store.loadSession(sessionId);
    const target = location === 'legacy' ? (session.scheduleState ||= {}) : session.automation.tasks.find(task => task.id === location);
    if (!target) return;
    if (error) {
      target.lastAttempt = { key, at: Date.now(), retryAt: 0, status: 'uncertain', detail: String(error.message || error).slice(0, 300) };
      if (location === 'legacy') target.lastRunKey = key;
    } else {
      const state = resultState(result);
      target.lastAttempt = { key, at: Date.now(), retryAt: state.status === 'failed' ? Date.now() + 10000 : 0, status: state.status, detail: state.status === 'partial' ? 'نجح جزء من الإرسال؛ لم يُعد الموعد تلقائيًا لمنع تكرار المستلمين الذين وصلهم الإرسال.' : state.status === 'uncertain' ? 'نتيجة التسليم غير مؤكدة؛ لم يُعد الموعد تلقائيًا.' : '' };
      if (state.consume) target.lastRunKey = key;
      if (location !== 'legacy' && (state.status === 'done' || state.consume)) {
        const task = target;
        task.lastResult = result || null; task.updatedAt = new Date().toISOString();
        if (task.mode === 'once') task.enabled = false;
      }
    }
    if (location !== 'legacy') {
      session.automation.recent = [...(session.automation.recent || []), { at: new Date().toISOString(), taskId: location, name: target.name, ok: target.lastAttempt.status === 'done', state: target.lastAttempt.status, detail: target.lastAttempt.detail }].slice(-200);
    }
    this.store.saveSession(session);
  }
  async tickSession(id) {
    // One lock covers legacy scheduling, task scheduling and automation rules for a session.
    // This prevents two overlapping timer ticks from racing the same session snapshot.
    if (this.busy.has(id)) return;
    this.busy.add(id);
    try {
      let session = this.store.loadSession(id), now = new Date(), legacyDue = due(now, session);
      if (legacyDue.due && this.reserve(session, session.scheduleState, legacyDue.key)) {
        try {
          const result = await this.run(id, legacyDue.key);
          this.finishAttempt(id, 'legacy', legacyDue.key, result);
        } catch (error) {
          this.finishAttempt(id, 'legacy', legacyDue.key, null, error);
          this.log(id, 'ERROR', `فشل الموعد: ${error.message}`);
        }
      }
      session = this.store.loadSession(id);
      if (session.settings.automationEnabled !== false && session.automation.enabled !== false) {
        for (const taskSnapshot of session.automation.tasks || []) {
          const current = this.store.loadSession(id), task = current.automation.tasks.find(item => item.id === taskSnapshot.id);
          if (!task) continue;
          const taskDue = dueForItem(now, { ...task, timezone: current.settings.timezone });
          if (!taskDue.due || !this.reserve(current, task, taskDue.key)) continue;
          this.taskBusy.add(`${id}:${task.id}`);
          try {
            const result = await this.runTask(id, task, taskDue.key);
            this.finishAttempt(id, task.id, taskDue.key, result);
          } catch (error) {
            this.finishAttempt(id, task.id, taskDue.key, null, error);
            this.log(id, 'ERROR', `فشل الموعد ${task.name || task.id}: ${error.message}`);
          } finally { this.taskBusy.delete(`${id}:${task.id}`); }
        }
      }
      if (typeof this.runAutomation === 'function') {
        try { await this.runAutomation(id, now); }
        catch (error) { this.log(id, 'ERROR', `فشل محرك الأتمتة: ${error.message || error}`); }
      }
    } finally { this.busy.delete(id); }
  }
}

module.exports = { ReliableScheduler, parts, due, nextRun, zonedDateToUtc, dueForItem, nextRunForItem, validTime, resultState };
