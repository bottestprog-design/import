'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { assertOggOpusFile } = require('./audio-format');
const crypto = require('node:crypto');
const { spawn: nodeSpawn } = require('node:child_process');
const { execFile: nodeExecFile } = require('node:child_process');
const { promisify } = require('node:util');
const { ChatterboxRuntime } = require('./chatterbox-runtime');
const { AudarRuntime } = require('./audar-tts-runtime');
const execFileDefault = promisify(nodeExecFile);

const MAX_SPEECH_CHARS = 1800;
const MAX_PRONUNCIATION_RULES = 300;
const MAX_SPEECH_SEGMENTS = 10;
const EDGE_DEFAULT_VOICE = 'ar-EG-ShakirNeural';
function voiceLanguage(voice) { const tag = String(voice || EDGE_DEFAULT_VOICE).toLowerCase(); if (tag.startsWith('ar-')) return 'ar'; if (tag.startsWith('fr-')) return 'fr'; if (tag.startsWith('de-')) return 'de'; if (tag.startsWith('en-')) return 'en'; if (tag.startsWith('es-')) return 'es'; return 'ar'; }
function detectSpeechLanguage(text) {
  const value = String(text || '').toLowerCase();
  if (/[\u0600-\u06ff]/u.test(value)) return 'ar';
  if (/[àâçéèêëîïôûùüÿœ]/u.test(value) || /(?<!\p{L})(bonjour|merci|ceci|avec|pour|français|une|vous|nous|est)(?!\p{L})/u.test(value)) return 'fr';
  if (/[äöüß]/u.test(value) || /(?<!\p{L})(hallo|guten|morgen|danke|und|der|die|das|nicht|ist|deutsch|ein|einen|geht|ihnen|bitte|sprechen|abend|tschüss)(?!\p{L})/u.test(value)) return 'de';
  if (/[áéíóúñ¿¡]/u.test(value) || /(?<!\p{L})(hola|gracias|buenos|buenas|por favor|español|usted|ustedes|está|estoy|mañana)(?!\p{L})/u.test(value)) return 'es';
  if (/[a-z]/u.test(value)) return 'en';
  return 'ar';
}
function defaultVoiceForText(text, requestedVoice) {
  const requested = String(requestedVoice || '').trim();
  const language = detectSpeechLanguage(text);
  // Respect a custom voice only when it matches the detected text language.
  // An Arabic voice selection must not make English text appear Piper-compatible.
  if (requested && requested !== EDGE_DEFAULT_VOICE && voiceLanguage(requested) === language) return requested;
  return ({ ar: EDGE_DEFAULT_VOICE, en: 'en-US-JennyNeural', fr: 'fr-FR-DeniseNeural', de: 'de-DE-KatjaNeural', es: 'es-ES-ElviraNeural' })[language] || EDGE_DEFAULT_VOICE;
}
const VOICE_STYLE_PRESETS = Object.freeze({
  natural: { rate: 0, pitch: 0, volume: 0, noiseScale: 0, noiseWidth: 0 },
  auto: { rate: 0, pitch: 0, volume: 0, noiseScale: 0, noiseWidth: 0 },
  calm: { rate: -12, pitch: -3, volume: -3, noiseScale: -0.08, noiseWidth: -0.04 },
  warm: { rate: -5, pitch: 2, volume: 3, noiseScale: 0.04, noiseWidth: 0.03 },
  energetic: { rate: 14, pitch: 4, volume: 6, noiseScale: 0.10, noiseWidth: 0.08 },
  formal: { rate: -8, pitch: -2, volume: 0, noiseScale: -0.03, noiseWidth: 0 },
  friendly: { rate: 4, pitch: 2, volume: 3, noiseScale: 0.05, noiseWidth: 0.04 },
  empathetic: { rate: -4, pitch: -1, volume: 1, noiseScale: 0.02, noiseWidth: 0.02 },
  storytelling: { rate: -7, pitch: 1, volume: 2, noiseScale: 0.04, noiseWidth: 0.04 },
  playful: { rate: 7, pitch: 3, volume: 3, noiseScale: 0.08, noiseWidth: 0.06 },
  curious: { rate: 2, pitch: 2, volume: 1, noiseScale: 0.04, noiseWidth: 0.04 },
});
function resolveVoiceTuning({ style = 'natural', rate = 0, pitch = 0, volume = 0, noiseScale = 0.667, noiseWidth = 0.8 } = {}) {
  const preset = VOICE_STYLE_PRESETS[String(style || 'natural')] || VOICE_STYLE_PRESETS.natural;
  return {
    style: VOICE_STYLE_PRESETS[String(style || 'natural')] ? String(style) : 'natural',
    rate: Math.max(-40, Math.min(40, Math.round((Number(rate) || 0) + preset.rate))),
    pitch: Math.max(-30, Math.min(30, Math.round((Number(pitch) || 0) + preset.pitch))),
    volume: Math.max(-30, Math.min(30, Math.round((Number(volume) || 0) + preset.volume))),
    noiseScale: Math.max(0.1, Math.min(1.5, (Number(noiseScale) || 0.667) + preset.noiseScale)),
    noiseWidth: Math.max(0.1, Math.min(1.5, (Number(noiseWidth) || 0.8) + preset.noiseWidth)),
  };
}

const CHATTERBOX_STYLE_PRESETS = Object.freeze({
  natural: { exaggeration: 0.54, cfgWeight: 0.46, temperature: 0.80 },
  calm: { exaggeration: 0.34, cfgWeight: 0.52, temperature: 0.72 },
  warm: { exaggeration: 0.56, cfgWeight: 0.43, temperature: 0.82 },
  energetic: { exaggeration: 0.82, cfgWeight: 0.34, temperature: 0.96 },
  formal: { exaggeration: 0.40, cfgWeight: 0.54, temperature: 0.74 },
  friendly: { exaggeration: 0.65, cfgWeight: 0.40, temperature: 0.87 },
  empathetic: { exaggeration: 0.62, cfgWeight: 0.43, temperature: 0.82 },
  storytelling: { exaggeration: 0.73, cfgWeight: 0.36, temperature: 0.91 },
  playful: { exaggeration: 0.84, cfgWeight: 0.32, temperature: 0.98 },
  curious: { exaggeration: 0.63, cfgWeight: 0.39, temperature: 0.88 },
  whisper: { exaggeration: 0.68, cfgWeight: 0.38, temperature: 0.92 },
  sarcastic: { exaggeration: 0.76, cfgWeight: 0.35, temperature: 0.94 },
  laughing: { exaggeration: 0.86, cfgWeight: 0.30, temperature: 0.98 },
});
const CHATTERBOX_LANGUAGES = new Set(['ar', 'en', 'fr', 'de', 'es']);
function classifyExpressiveStyle(text) {
  // Deliberately use bounded, transparent lexical cues rather than sending
  // private reply text to a cloud emotion classifier. Each sentence is profiled
  // independently; more specific emotional cues win over general greetings.
  const value = String(text || '').toLowerCase();
  if (/(عاجل|فورًا|فورا|حالًا|حالا|انتبه|تحذير|خطر|الحق|بسرعة|طوارئ|احذر|كارثة|emergency|urgent|warning|watch out|right now)/u.test(value)) return 'energetic';
  if (/(آسف|اسف|أفهم|افهم|فاهم|حقك|متضايق|مضايق|حزين|قلق|تعبان|زعلان|مكسور|صعب عليك|معلش|حقك عليا|حاسس بيك|ما تقلقش|متقلقش|لا تقلق|أقدّر|اقدر|معك|i am sorry|i understand|that sounds hard|i hear you|don't worry|no worries)/u.test(value)) return 'empathetic';
  if (/(هههه|هَهَه|مضحك|نكتة|بمزح|بهزر|يا عم بقولك|😂|🤣|haha|funny|joke|kidding|just kidding)/u.test(value)) return 'playful';
  if (/(كان يا ما كان|تخيل|تخيّل|قصة|حكاية|ذات يوم|مرة من المرات|خليني احكيلك|خليني أحكيلك|اسمع الحكاية|تعالى احكيلك|once upon a time|imagine this|story time)/u.test(value)) return 'storytelling';
  if (/(يرجى|نود إحاطتكم|نحيطكم علمًا|نفيدكم|بناءً على|بناء على|وفقًا لما|وفقا لما|يرجى العلم|بالإشارة إلى|السادة الأفاضل|تحية طيبة|please note|kindly note|regarding|for your information)/u.test(value)) return 'formal';
  if (/(خد وقتك|خذ وقتك|على مهلك|براحتك|مفيش استعجال|بدون استعجال|بهدوء|بالراحة|اهدأ|اهدى|take your time|no rush|at your own pace|slow down)/u.test(value)) return 'calm';
  if (/(أهلًا|اهلا|أهلا|مرحبًا|مرحبا|صباح الخير|مساء الخير|نورت|نورتنا|تشرفت|شكرًا|شكرا|تسلم|حبيبي|حبيبتي|welcome|hello there|good morning|good evening|thank you|thanks a lot|nice to meet you)/u.test(value)) return 'warm';
  if (/(مبروك|ألف مبروك|الف مبروك|رائع|ممتاز|جميل|عظيم|نجاح|متحمس|مبسوط|فرحان|سعيد|فخور|برافو|عاش|يا سلام|واو|يستاهل|أحسنت|احسنت|😄|congratulations|amazing|wonderful|fantastic|great job|well done|so happy)/u.test(value)) return 'energetic';
  if (/[؟?]/u.test(value) || /(?<!\p{L})(طب|إزاي|ازاي|ليه|لماذا|متى|امتى|فين|أين|مين|من|هل|تفتكر|معقول|بجد|فعلا|really|why|how|what|when|where|who)(?!\p{L})/u.test(value)) return 'curious';
  return 'natural';
}
function resolveExpressiveTuning({ text = '', style = 'natural', exaggeration, cfgWeight, temperature } = {}) {
  const requested = String(style || 'natural').toLowerCase();
  const resolvedStyle = requested === 'auto' || requested === 'natural' ? classifyExpressiveStyle(text) : (CHATTERBOX_STYLE_PRESETS[requested] ? requested : 'natural');
  const preset = CHATTERBOX_STYLE_PRESETS[resolvedStyle] || CHATTERBOX_STYLE_PRESETS.natural;
  const clamp = (value, fallback, min, max) => {
    const n = Number(value);
    return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : fallback;
  };
  // The dashboard slider is a global intensity offset, not an override of
  // sentence-level emotion. Its neutral value (.55) preserves each preset's
  // distinct exaggeration/cfg/temperature profile.
  const offset = (value, neutral, fallback) => {
    const n = Number(value);
    return Number.isFinite(n) ? fallback + (n - neutral) : fallback;
  };
  return {
    style: resolvedStyle,
    exaggeration: clamp(offset(exaggeration, 0.55, preset.exaggeration), preset.exaggeration, 0.25, 1.2),
    cfgWeight: clamp(offset(cfgWeight, 0.45, preset.cfgWeight), preset.cfgWeight, 0, 1),
    temperature: clamp(offset(temperature, 0.8, preset.temperature), preset.temperature, 0.4, 1.3),
  };
}
const AUDAR_STYLE_TAGS = Object.freeze({
  curious: 'curious', energetic: 'excited', playful: 'mischievously', whisper: 'whispers',
  sarcastic: 'sarcastic', laughing: 'laughs', empathetic: 'sighs',
});
const AUDAR_ALLOWED_TAGS = new Set(['laughs','curious','excited','sighs','exhales','mischievously','whispers','sarcastic']);
function audarAutoTag(sentence) {
  const value = String(sentence || '').toLowerCase().trim();
  // The classifier runs locally. It maps intent cues to Audar's eight trained
  // inline tags; it never sends text to a remote classifier or invents emotion.
  if (/(?:هههه+|هاها+|هع هع|😂|🤣|ضحكتني|ميت من الضحك|مش قادر أمسك نفسي|بموت من الضحك|مت من الضحك|dying laughing|\blol\b|\bhaha\b|\blmao\b)/iu.test(value)) return 'laughs';
  if (/(?:خلّيها سر|خليها سر|بيننا|ما تقول لحد|ما تخبر أحد|بصوت واطي|بيني وبينك|تعال\s*،?\s*اقرب|اقتربي قليلاً|اسمعني بس|خليك قريب|همس|اهمس|بصوت منخفض|ما حدش يسمع|whisper|keep it secret|between us|don't tell anyone)/iu.test(value)) return 'whispers';
  if (/(?:بسخرية|بسخرية واضحة|بتهكم|تهكم|يا سلام على|طبعاً أكيد|طبعا أكيد|أكيد يعني|ما شاء الله عليك بقى|آه طبعاً|اه طبعا|sure, right|yeah, right|sarcastically|what a surprise|as if)/iu.test(value)) return 'sarcastic';
  if (/(?:بس ما تقول|مفاجأة|مفاجاه|سرّي|سري|تخيل المفاجأة|مش هتصدق|لن تصدق|هتعرف بعدين|خطة سرية|تعالى أقولك|تعال اقولك|عندي لك مفاجأة|عندي ليك مفاجأة|you won't believe|secret plan|guess what|wait till you hear)/iu.test(value)) return 'mischievously';
  if (/(?:آسف|اسف|أعتذر|اعتذر|معلش|حقك علي|حقك عليا|أفهم شعورك|افهم شعورك|حاسس بيك|حاسة بيك|عارف إن ده صعب|عارف ان ده صعب|أعرف أن هذا صعب|اعرف ان هذا صعب|أنا معك|انا معك|مش سهل عليك|ربنا يعينك|البقاء لله|خالص عزائي|خسارة|ده مؤلم|هذا مؤلم|أتفهمك|اتفهمك|i am sorry|i understand how you feel|that sounds difficult|my condolences|that must be hard)/iu.test(value)) return 'sighs';
  if (/(?:خد نفس|خذ نفس|اهدأ|اهدى|براحتك|على مهلك|واحدة واحدة|متستعجلش|لا تستعجل|مفيش استعجال|لا يوجد استعجال|اطمئن|اطمني|اطمن|كل شيء سيكون بخير|كل حاجه هتبقى كويسة|كل حاجة هتبقى تمام|هنحلها سوا|سنحل الأمر معًا|أنا هنا|انا هنا|خليك مطمن|take a breath|take your time|easy does it|there is no rush|we will work it out)/iu.test(value)) return 'exhales';
  if (/(?:بمزح|بهزر|بنهزر|بضحك معاك|بضحك معاكي|يا عم بهزر|يا سيدي بهزر|دعابة|على سبيل المزاح|kidding|just joking|playful|teasing you)/iu.test(value)) return 'mischievously';
  // A rising question contour is useful even when colloquial Arabic omits ?.
  if (/[؟?]\s*$/u.test(value)
      || /^(?:هل|ماذا|ما الذي|ما هو|ما هي|مين|متى|امتى|أين|اين|فين|كيف|ازاي|إزاي|ليه|لماذا|لمَ|كم|أي|ايه|إيه|تفتكر|يا ترى|معقول|بجد|حقاً|حقا|really|why|how|what|when|where|who|can you|could you|do you|did you|would you|tell me|i wonder)(?=$|\s|[؟?!,،:;])/iu.test(value)
      || /(?:عايز أعرف|عاوز أعرف|حابب أعرف|أحب أعرف|ممكن تقولي|ممكن تقول لي|ممكن توضّح|ممكن توضح|قول لي رأيك|tell me more|i would like to know)/iu.test(value)) return 'curious';
  if (/(?:يا نهار أبيض|يا خبر|مش معقول|لا أصدق|لا اصدق|إيه ده|ايه ده|واو بجد|what the heck|no way|unbelievable|مبروك|ألف مبروك|الف مبروك|رائع|ممتاز|نجحنا|أنجزنا|انجزنا|فخور|فرحان|سعيد|خبر حلو|أخيراً|اخيراً|طلعنا|واو|يا سلام|أحسنت|احسنت|برافو|جميل جداً|جميل جدا|عاش|تستاهل|مذهل|إنجاز عظيم|انجاز عظيم|الحمد لله نجحت|الحمدلله نجحت|الله يفرحك|congratulations|amazing|wonderful|fantastic|great job|awesome news|well done|we did it)/iu.test(value)) return 'excited';
  if (/(?:يا له من|يا لها من|وفجأة|وفي تلك اللحظة|تخيل المشهد|كان يا ما كان|تخيل معايا|تخيّل معي|المشهد كان|من هنا تبدأ الحكاية|once upon a time|suddenly|picture this)/iu.test(value)) return 'curious';
  return '';
}
function resolveAudarSamplingTemperature(exaggeration = 0.55, style = 'auto') {
  const value = Number(exaggeration);
  const intensity = Number.isFinite(value) ? Math.max(0.25, Math.min(1.2, value)) : 0.55;
  // Audar's reference demos use temperature=1.0. The user-facing intensity
  // gently moves around that value instead of starting from a flat/low sample.
  // Keep the model's reference default at 1.0 while making the slider useful:
  // calmer values approach 0.76; high values reach 1.08 without runaway sampling.
  const styleOffsets = { calm: -0.20, formal: -0.16, empathetic: -0.11, whisper: -0.05, warm: -0.05, friendly: 0, storytelling: 0.01, curious: 0.03, energetic: 0.05, sarcastic: 0.04, playful: 0.07, laughing: 0.08 };
  const offset = styleOffsets[String(style || 'auto').toLowerCase()] || 0;
  return Math.max(0.65, Math.min(1.12, Number((1.0 + (intensity - 0.55) * 0.82 + offset).toFixed(3))));
}
function annotateAudarExpressionTags(text, style = 'auto') {
  const clean = normalizeSpeechText(text);
  if (!clean) return { text: '', tags: [] };
  const requested = String(style || 'auto').toLowerCase();
  const forcedTag = AUDAR_STYLE_TAGS[requested] || '';
  const sentences = clean.split(/(?<=[.!?؟])\s+|\n+/u).map(part => part.trim()).filter(Boolean);
  const tags = [];
  let autoTagged = 0;
  let previousTag = '';
  const output = sentences.map((sentence) => {
    let tag = forcedTag;
    if (!tag && ['auto', 'natural', 'warm', 'calm', 'formal', 'friendly', 'storytelling', 'empathetic'].includes(requested)) {
      tag = audarAutoTag(sentence);
      if (requested === 'calm' && ['excited', 'mischievously', 'sarcastic'].includes(tag)) tag = '';
      if (requested === 'formal' && ['laughs', 'mischievously', 'sarcastic'].includes(tag)) tag = '';
      if (requested === 'empathetic' && ['excited', 'sarcastic', 'mischievously'].includes(tag)) tag = '';
    }
    // Avoid over-tagging even when the user forces a style: duplicate markers
    // on every sentence make speech theatrical rather than conversational.
    if (tag && (autoTagged >= 3 || tag === previousTag || !AUDAR_ALLOWED_TAGS.has(tag))) tag = '';
    if (tag && AUDAR_ALLOWED_TAGS.has(tag)) {
      tags.push(tag); autoTagged++; previousTag = tag;
      return `[${tag}] ${sentence}`;
    }
    return sentence;
  });
  return { text: output.join(' '), tags: [...new Set(tags)] };
}

function splitExpressiveSegments(text, { maxChars = 420, maxSegments = 8 } = {}) {
  const value = normalizeSpeechText(text);
  if (!value) return [];
  const limit = Math.max(120, Math.min(900, Number(maxChars) || 420));
  const cap = Math.max(1, Math.min(10, Number(maxSegments) || 8));
  const sentences = value.split(/(?<=[.!?؟])\s+|\n+/u).map(part => part.trim()).filter(Boolean);
  const result = [];
  for (const sentence of sentences) {
    if (Array.from(sentence).length <= limit) { result.push(sentence); continue; }
    const clauses = sentence.split(/(?<=[،,;؛:])\s*/u).filter(Boolean);
    let buffer = '';
    for (const clause of clauses) {
      const combined = buffer ? `${buffer} ${clause}` : clause;
      if (Array.from(combined).length <= limit) { buffer = combined; continue; }
      if (buffer) result.push(buffer);
      buffer = '';
      const words = clause.split(/\s+/u);
      for (const word of words) {
        const next = buffer ? `${buffer} ${word}` : word;
        if (Array.from(next).length > limit && buffer) { result.push(buffer); buffer = word; }
        else buffer = next;
      }
    }
    if (buffer) result.push(buffer);
  }
  if (!result.length) return [value];
  if (result.length > cap) {
    const head = result.slice(0, cap - 1);
    head.push(result.slice(cap - 1).join(' '));
    return head;
  }
  return result;
}

function resolveFromRoot(root, value, fallback = '') {
  const raw = String(value || fallback || '').trim();
  if (!raw) return '';
  if (path.isAbsolute(raw) || /^[A-Za-z]:[\\/]/.test(raw)) return raw;
  // Executable names such as `ffmpeg` and `piper` must remain PATH-resolved;
  // relative paths like tools/piper/piper.exe are resolved against the project.
  return /[\\/]/.test(raw) ? path.resolve(root, raw) : raw;
}
function normalizeSpeechText(value) {
  return String(value || '').normalize('NFC').replace(/\u0000/g, '').replace(/\r\n?/g, '\n')
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/!?\[[^\]]*\]\((https?:\/\/[^)]+)\)/g, 'رابط مرفق')
    .replace(/https?:\/\/\S+/giu, 'رابط')
    .replace(/[*_~>#|]/g, ' ')
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, ' ')
    .replace(/[ \t]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{3,}/g, '\n\n')
    .replace(/\s+([،؛.!؟,:])/g, '$1').replace(/([،؛:])(?=\S)/g, (match, punctuation, offset, source) => punctuation === ':' && /\d/.test(source[offset - 1] || '') && /\d/.test(source[offset + 1] || '') ? punctuation : `${punctuation} `)
    .trim();
}
function textTokensForPreservation(text) {
  return [...String(text || '').matchAll(/(?:\d{1,4}:\d{2}(?::\d{2})?|\d+(?:[.,٫٬]\d+)*|https?:\/\/\S+|[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})/g)].map(m => m[0]);
}

function validatePronunciationDictionary(value) {
  if (value == null) return [];
  if (!Array.isArray(value)) throw new Error('المعجم الصوتي يجب أن يكون قائمة من الكلمات وطريقة نطقها.');
  if (value.length > MAX_PRONUNCIATION_RULES) throw new Error(`المعجم الصوتي يقبل حتى ${MAX_PRONUNCIATION_RULES} مدخلًا.`);
  const seen = new Set(), result = [];
  for (const item of value) {
    const term = String(item?.term || '').normalize('NFC').trim();
    const pronunciation = String(item?.pronunciation || '').normalize('NFC').trim();
    if (!term && !pronunciation) continue;
    if (!term || !pronunciation) throw new Error('كل سطر في المعجم الصوتي يحتاج كلمة مكتوبة وطريقة نطق.');
    if (term.length > 80 || pronunciation.length > 120) throw new Error('الكلمة في المعجم لا تتجاوز 80 حرفًا وطريقة النطق لا تتجاوز 120 حرفًا.');
    if (/[\r\n\u0000-\u001f]/u.test(term) || /[\r\n\u0000-\u001f]/u.test(pronunciation)) throw new Error('المعجم الصوتي لا يقبل أسطرًا متعددة داخل المدخل الواحد أو محارف تحكم.');
    const key = term.toLocaleLowerCase();
    if (seen.has(key)) throw new Error(`المدخل «${term}» مكرر في المعجم الصوتي.`);
    seen.add(key);
    result.push({ term, pronunciation });
  }
  return result.sort((a, b) => b.term.length - a.term.length);
}

function applyPronunciationDictionary(text, dictionary = []) {
  let output = String(text || ''), replacements = 0;
  const rules = validatePronunciationDictionary(dictionary);
  for (const rule of rules) {
    const escaped = rule.term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    // Preserve common Arabic conjunctions attached to Latin names such as وAPI.
    const pattern = new RegExp(`(^|[^\\p{L}\\p{N}])([وف]?)(${escaped})(?=$|[^\\p{L}\\p{N}])`, 'giu');
    output = output.replace(pattern, (_match, prefix, clitic) => { replacements++; return `${prefix}${clitic || ''}${rule.pronunciation}`; });
    if (output.length > MAX_SPEECH_CHARS) throw new Error('زاد طول النص بعد تطبيق معجم النطق عن 1800 حرف؛ اختصر طريقة النطق أو قلل تكرار المصطلح. لم يُقص النص.');
  }
  return { text: output, replacements };
}

function splitSpeechText(value, { maxChars = MAX_SPEECH_CHARS, maxSegments = 6 } = {}) {
  const text = normalizeSpeechText(value);
  const limit = Math.max(100, Math.min(MAX_SPEECH_CHARS, Number(maxChars) || MAX_SPEECH_CHARS));
  const cap = Math.max(1, Math.min(MAX_SPEECH_SEGMENTS, Number(maxSegments) || 6));
  if (!text) return [];
  const atoms = text.match(/[^.!?؟؛\n]+[.!?؟؛]?|\n+/gu) || [text];
  const chunks = [];
  let current = '';
  const pushLong = (part) => {
    let remaining = Array.from(part.trim());
    while (remaining.length > limit) {
      const head = remaining.slice(0, limit);
      let cut = -1;
      // Prefer a natural pause, then whitespace; avoid splitting a word unless necessary.
      for (const marker of ['.','!','؟','?','؛','،',',',';',':',' ']) {
        const index = head.lastIndexOf(marker);
        if (index >= Math.floor(limit * 0.55)) { cut = index + (marker === ' ' ? 0 : 1); break; }
      }
      if (cut < 1) cut = limit;
      const piece = head.slice(0, cut).join('').trim();
      if (piece) chunks.push(piece);
      remaining = remaining.slice(cut);
      while (remaining[0] === ' ') remaining.shift();
    }
    const tail = remaining.join('').trim();
    if (tail) chunks.push(tail);
  };
  for (const atom of atoms) {
    const piece = atom.replace(/\s+/gu, ' ').trim();
    if (!piece) continue;
    if (Array.from(piece).length > limit) {
      if (current) { chunks.push(current); current = ''; }
      pushLong(piece);
      continue;
    }
    const combined = current ? `${current} ${piece}` : piece;
    if (Array.from(combined).length > limit) {
      if (current) chunks.push(current);
      current = piece;
    } else current = combined;
  }
  if (current) chunks.push(current);
  if (chunks.length > cap) throw new Error(`الرد طويل جدًا لإرساله صوتيًا بأمان (${chunks.length} مقاطع). خفّض طول الرد أو ارفع حد المقاطع إلى ${Math.min(MAX_SPEECH_SEGMENTS, chunks.length)}؛ لم يُقص أي جزء بصمت.`);
  return chunks;
}
function arabicSpeechTokens(value) {
  return String(value || '').normalize('NFC')
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/gu, '')
    .toLocaleLowerCase()
    .match(/[\p{L}\p{N}]+/gu) || [];
}
function normalizeArabicDiacritizedCandidate(candidate, original) {
  const clean = normalizeSpeechText(candidate);
  if (!clean || clean.length > MAX_SPEECH_CHARS) return { text: original, used: false, reason: 'empty-or-too-long' };
  const before = arabicSpeechTokens(original), after = arabicSpeechTokens(clean);
  if (before.length !== after.length || before.some((token, index) => token !== after[index])) {
    return { text: original, used: false, reason: 'arabic-lexical-content-changed' };
  }
  const beforeNumbers = textTokensForPreservation(original), afterNumbers = textTokensForPreservation(clean);
  if (beforeNumbers.length !== afterNumbers.length || beforeNumbers.some((token, index) => token !== afterNumbers[index])) {
    return { text: original, used: false, reason: 'protected-token-changed' };
  }
  return { text: clean, used: true, reason: 'arabic-diacritics-only' };
}

function normalizeGrammarCandidate(candidate, original) {
  const clean = normalizeSpeechText(candidate);
  if (!clean || clean.length > MAX_SPEECH_CHARS) return { text: original, used: false, reason: 'empty-or-too-long' };
  const before = textTokensForPreservation(original), after = textTokensForPreservation(clean);
  if (before.length !== after.length || before.some((token, i) => token !== after[i])) return { text: original, used: false, reason: 'protected-token-changed' };
  if (clean.length < original.length * 0.45 && original.length > 100) return { text: original, used: false, reason: 'content-may-have-been-omitted' };
  return { text: clean, used: true, reason: '' };
}

class TextToSpeech {
  constructor({ env = process.env, root = path.resolve(__dirname, '..'), spawnImpl = nodeSpawn, execFileImpl = execFileDefault, fetchImpl = globalThis.fetch, localLlm = null, tempRoot = os.tmpdir() } = {}) {
    this.env = env; this.root = root; this.spawn = spawnImpl; this.execFile = execFileImpl; this.fetch = fetchImpl; this.localLlm = localLlm; this.tempRoot = tempRoot; this.piperQualityCache = { at: 0, value: null }; this.chatterboxStatusCache = { at: 0, value: null }; this.audarStatusCache = { at: 0, value: null }; this.chatterboxRuntime = null; this.chatterboxRuntimeFailure = ''; this.audarRuntime = null; this.audarRuntimeTier = ''; this.audarRuntimeFailure = '';
  }
  config(backendOverride = '') {
    const exe = process.platform === 'win32' ? 'piper.exe' : 'piper';
    const rawBackend = String(backendOverride || this.env.TTS_BACKEND || 'local').trim().toLowerCase();
    const backend = ['auto', 'edge-tts', 'openai-compatible', 'local'].includes(rawBackend) ? rawBackend : 'local';
    const configuredPython = String(this.env.VOICE_PYTHON_BIN || '').trim();
    const localPython = path.join(this.root, '.voice-venv', process.platform === 'win32' ? path.join('Scripts', 'python.exe') : path.join('bin', 'python'));
    const pythonBinary = resolveFromRoot(this.root, configuredPython, fs.existsSync(localPython) ? localPython : (process.platform === 'win32' ? 'python' : 'python3'));
    const configuredFfmpeg = String(this.env.FFMPEG_BIN || '').trim();
    const localFfmpeg = path.join(this.root, 'tools', 'ffmpeg', 'bin', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');
    const ffmpegBinary = configuredFfmpeg && !['ffmpeg', 'ffmpeg.exe'].includes(configuredFfmpeg.toLowerCase())
      ? resolveFromRoot(this.root, configuredFfmpeg, 'ffmpeg')
      : (fs.existsSync(localFfmpeg) ? localFfmpeg : (configuredFfmpeg || 'ffmpeg'));
    return {
      backend,
      binary: resolveFromRoot(this.root, this.env.PIPER_BIN, path.join('tools', 'piper', exe)),
      modelPath: resolveFromRoot(this.root, this.env.PIPER_MODEL_PATH, path.join('models', 'ar_JO-kareem-medium.onnx')),
      ffmpegBinary, pythonBinary, voiceWorker: path.join(this.root, 'scripts', 'voice_worker.py'),
      chatterboxWorker: path.join(this.root, 'scripts', 'chatterbox_tts_worker.py'),
      chatterboxModelPath: resolveFromRoot(this.root, this.env.CHATTERBOX_MODEL_PATH, path.join('models', 'chatterbox-multilingual-v3')),
      chatterboxPythonBinary: resolveFromRoot(this.root, this.env.CHATTERBOX_PYTHON_BIN, path.join('.voice-tts-venv', process.platform === 'win32' ? path.join('Scripts', 'python.exe') : path.join('bin', 'python'))),
      chatterboxDevice: String(this.env.CHATTERBOX_DEVICE || 'auto').trim().toLowerCase(),
      audarWorker: path.join(this.root, 'scripts', 'audar_tts_worker.py'),
      audarModelDir: resolveFromRoot(this.root, this.env.AUDAR_TTS_MODEL_DIR, path.join('models', 'audar-tts')),
      audarModelFile: String(this.env.AUDAR_TTS_MODEL_FILE || '').trim() ? (path.isAbsolute(String(this.env.AUDAR_TTS_MODEL_FILE).trim()) ? String(this.env.AUDAR_TTS_MODEL_FILE).trim() : path.resolve(this.root, String(this.env.AUDAR_TTS_MODEL_FILE).trim())) : '',
      audarVoiceDir: resolveFromRoot(this.root, this.env.AUDAR_TTS_VOICE_DIR, path.join('models', 'audar-voices')),
      audarCacheDir: resolveFromRoot(this.root, this.env.AUDAR_TTS_CACHE_DIR, path.join('models', 'hf-cache')),
      audarCodecDir: resolveFromRoot(this.root, this.env.AUDAR_TTS_CODEC_DIR, path.join('models', 'audar-codec')),
      audarPythonBinary: resolveFromRoot(this.root, this.env.AUDAR_TTS_PYTHON_BIN, path.join('.voice-audar-venv', process.platform === 'win32' ? path.join('Scripts', 'python.exe') : path.join('bin', 'python'))),
      audarTier: ['turbo', 'flash'].includes(String(this.env.AUDAR_TTS_TIER || '').trim().toLowerCase()) ? String(this.env.AUDAR_TTS_TIER).trim().toLowerCase() : 'turbo',
      audarDefaultVoice: String(this.env.AUDAR_TTS_DEFAULT_VOICE || 'demo_male_1'), audarGpuLayers: Number(this.env.AUDAR_TTS_GPU_LAYERS || 0), root: this.root,
    };
  }
  async commandExists(command) {
    if (!command) return false;
    if (path.isAbsolute(command) || /[\\/]/.test(command)) return fs.existsSync(command) && fs.statSync(command).isFile();
    try { await this.execFile(process.platform === 'win32' ? 'where.exe' : 'which', [command], { timeout: 2500, windowsHide: true }); return true; } catch { return false; }
  }
  async piperRuntimeStatus(cfg) {
    const now = Date.now();
    if (this.piperQualityCache.value && now - this.piperQualityCache.at < 300000) return this.piperQualityCache.value;
    let value = { piperTtsVersion: '', arabicTashkeelAvailable: false, arabicTashkeelEnabledByDefault: false };
    try {
      if (await this.commandExists(cfg.pythonBinary) && fs.existsSync(cfg.voiceWorker)) {
        const result = await this.execFile(cfg.pythonBinary, [cfg.voiceWorker, 'status'], { timeout: 8000, maxBuffer: 512 * 1024, windowsHide: true });
        const line = String(result.stdout || '').trim().split(/\r?\n/).filter(Boolean).at(-1) || '{}';
        const data = JSON.parse(line);
        value = {
          piperTtsVersion: String(data.piperTtsVersion || ''),
          arabicTashkeelAvailable: data.arabicTashkeelAvailable === true,
          arabicTashkeelEnabledByDefault: data.arabicTashkeelEnabledByDefault === true,
        };
      }
    } catch {}
    this.piperQualityCache = { at: now, value };
    return value;
  }
  chatterboxFilesReady(cfg) {
    const required = [
      ['ve.pt', 1_000_000], ['t3_mtl23ls_v3.safetensors', 1_000_000_000], ['s3gen.pt', 500_000_000],
      ['grapheme_mtl_merged_expanded_v1.json', 10_000], ['conds.pt', 10_000], ['Cangjie5_TC.json', 100_000],
    ];
    try { return required.every(([name, minBytes]) => { const file = path.join(cfg.chatterboxModelPath, name); return fs.statSync(file).isFile() && fs.statSync(file).size >= minBytes; }); }
    catch { return false; }
  }
  async chatterboxRuntimeStatus(cfg) {
    const enabled = ['1', 'true', 'on', 'yes'].includes(String(this.env.CHATTERBOX_TTS_ENABLED ?? 'false').trim().toLowerCase());
    if (!enabled) return { enabled: false, packageReady: false, modelReady: false, ready: false, message: 'تم تعطيل محرك Chatterbox عبر CHATTERBOX_TTS_ENABLED.' };
    const now = Date.now();
    if (this.chatterboxStatusCache.value && now - this.chatterboxStatusCache.at < 30000) return this.chatterboxStatusCache.value;
    let packageReady = false;
    try {
      if (await this.commandExists(cfg.chatterboxPythonBinary)) {
        const probe = 'import importlib.util,json; ok=False\ntry: ok=importlib.util.find_spec("chatterbox.mtl_tts") is not None and importlib.util.find_spec("soundfile") is not None\nexcept Exception: pass\nprint(json.dumps({"ready":ok}))';
        const result = await this.execFile(cfg.chatterboxPythonBinary, ['-c', probe], { timeout: 12000, maxBuffer: 20000, windowsHide: true });
        packageReady = JSON.parse(String(result.stdout || '{}').trim().split(/\r?\n/).at(-1) || '{}').ready === true;
      }
    } catch {}
    const modelReady = this.chatterboxFilesReady(cfg);
    const value = {
      enabled, packageReady, modelReady, ready: enabled && packageReady && modelReady,
      modelPath: cfg.chatterboxModelPath, device: cfg.chatterboxDevice,
      message: !enabled ? 'محرك Chatterbox معطل.' : !packageReady ? 'حزمة Chatterbox غير مثبتة بعد.' : !modelReady ? 'ملفات نموذج Chatterbox V3 غير مكتملة.' : 'Chatterbox Multilingual V3 المحلي جاهز.',
    };
    this.chatterboxStatusCache = { at: now, value };
    return value;
  }
  audarModelFile(cfg) {
    if (cfg.audarModelFile) { try { if (fs.statSync(cfg.audarModelFile).isFile() && fs.statSync(cfg.audarModelFile).size > 250_000_000) return cfg.audarModelFile; } catch {} }
    const filename = cfg.audarTier === 'flash' ? 'Audar-TTS-V1-Flash-Q5_K_M.gguf' : 'Audar-TTS-V1-Turbo-Q5_K_M.gguf';
    const exact = path.join(cfg.audarModelDir, filename);
    try {
      if (fs.statSync(exact).isFile() && fs.statSync(exact).size > 250_000_000) return exact;
      const candidates = fs.readdirSync(cfg.audarModelDir).filter(name => name.toLowerCase().endsWith('.gguf')).map(name => path.join(cfg.audarModelDir, name)).filter(file => { try { return fs.statSync(file).isFile() && fs.statSync(file).size > 250_000_000; } catch { return false; } });
      return candidates.length === 1 ? candidates[0] : '';
    } catch { return ''; }
  }
  async audarRuntimeStatus(cfg, language = 'ar', voiceId = '') {
    const enabled = !['0', 'false', 'off', 'no'].includes(String(this.env.AUDAR_TTS_ENABLED ?? 'true').trim().toLowerCase());
    const supportedLanguage = ['ar', 'en'].includes(String(language || '').toLowerCase());
    if (!enabled) return { enabled: false, packageReady: false, modelReady: false, ready: false, tier: cfg.audarTier, message: 'تم تعطيل Audar عبر AUDAR_TTS_ENABLED.' };
    if (!supportedLanguage) return { enabled: true, packageReady: false, modelReady: Boolean(this.audarModelFile(cfg)), ready: false, tier: cfg.audarTier, message: `Audar يدعم العربية والإنجليزية؛ اللغة ${language} تستخدم محركًا اختياريًا آخر.` };
    const now = Date.now();
    const smokeTested = this.audarRuntime?.readyInfo?.smokeTest === true;
    if (this.audarStatusCache.value && this.audarStatusCache.value.tier === cfg.audarTier && this.audarStatusCache.value.voiceId === String(voiceId || this.env.AUDAR_TTS_DEFAULT_VOICE || 'demo_male_1') && now - this.audarStatusCache.at < 30000) return { ...this.audarStatusCache.value, smokeTested };
    let packageReady = false, pythonReady = false;
    try {
      pythonReady = await this.commandExists(cfg.audarPythonBinary);
      if (pythonReady && fs.existsSync(cfg.audarWorker)) {
        const probe = 'import importlib.util,json; m={x:importlib.util.find_spec(x) is not None for x in ("llama_cpp","neucodec","soundfile","torch","librosa","huggingface_hub")}; print(json.dumps({"ready":all(m.values()),"modules":m}))';
        const result = await this.execFile(cfg.audarPythonBinary, ['-c', probe], { timeout: 18000, maxBuffer: 24000, windowsHide: true });
        packageReady = JSON.parse(String(result.stdout || '{}').trim().split(/\r?\n/).at(-1) || '{}').ready === true;
      }
    } catch {}
    const modelPath = this.audarModelFile(cfg);
    const modelReady = Boolean(modelPath);
    const selectedVoice = String(voiceId || this.env.AUDAR_TTS_DEFAULT_VOICE || 'demo_male_1');
    const voicePath = path.join(cfg.audarVoiceDir, `${selectedVoice}_ar.wav`);
    const voiceReady = fs.existsSync(voicePath) && fs.statSync(voicePath).size > 100_000;
    const value = {
      enabled, packageReady, pythonReady, modelReady, voiceReady, ready: enabled && packageReady && modelReady && voiceReady, smokeTested,
      tier: cfg.audarTier, modelPath, modelPathLabel: modelPath ? path.basename(modelPath) : '', pythonPathLabel: path.basename(path.dirname(cfg.audarPythonBinary)),
      voiceId: selectedVoice, voiceCount: (() => { try { return fs.readdirSync(cfg.audarVoiceDir).filter(n => n.endsWith('_ar.wav')).length; } catch { return 0; } })(),
      message: !pythonReady ? 'بيئة Audar Python لم تُنشأ بعد.' : !packageReady ? 'مكتبات llama.cpp وNeuCodec غير مكتملة.' : !modelReady ? `ملف نموذج Audar ${cfg.audarTier.toUpperCase()} Q5_K_M غير موجود.` : !voiceReady ? `الملف المرجعي للصوت ${selectedVoice} غير موجود.` : `أوزان Audar ${cfg.audarTier.toUpperCase()} والحزم والصوت ${selectedVoice} موجودة. سيختبر العامل التوليد العربي الفعلي قبل إعلان الجاهزية.`,
    };
    this.audarStatusCache = { at: now, value };
    return value;
  }
  getAudarRuntime(cfg, voiceId = '') {
    if (!this.audarRuntime || this.audarRuntimeTier !== cfg.audarTier) {
      try { this.audarRuntime?.shutdown(); } catch {}
      this.audarRuntime = new AudarRuntime({
        python: cfg.audarPythonBinary, worker: cfg.audarWorker, modelDir: cfg.audarModelDir,
        voiceDir: cfg.audarVoiceDir, cacheDir: cfg.audarCacheDir, codecDir: cfg.audarCodecDir, modelFile: cfg.audarModelFile, tier: cfg.audarTier,
        gpuLayers: cfg.audarGpuLayers, defaultVoice: voiceId || cfg.audarDefaultVoice,
        cwd: cfg.root, startupTimeoutMs: Number(this.env.AUDAR_TTS_STARTUP_TIMEOUT_MS) || 20 * 60 * 1000,
      });
      this.audarRuntimeTier = cfg.audarTier;
    }
    return this.audarRuntime;
  }
  async piperFallbackStatus(cfg, ffmpegReady) {
    const [binaryReady] = await Promise.all([this.commandExists(cfg.binary)]);
    const modelReady = Boolean(cfg.modelPath && fs.existsSync(cfg.modelPath) && fs.statSync(cfg.modelPath).isFile() && fs.statSync(cfg.modelPath).size > 10 * 1024 * 1024);
    const piperQuality = binaryReady && modelReady ? await this.piperRuntimeStatus(cfg) : { piperTtsVersion: '', arabicTashkeelAvailable: false, arabicTashkeelEnabledByDefault: false };
    return { binaryReady, modelReady, ffmpegReady, ready: binaryReady && modelReady && ffmpegReady, ...piperQuality };
  }
  getChatterboxRuntime(cfg) {
    if (!this.chatterboxRuntime) {
      this.chatterboxRuntime = new ChatterboxRuntime({
        python: cfg.chatterboxPythonBinary, worker: cfg.chatterboxWorker, modelPath: cfg.chatterboxModelPath,
        device: cfg.chatterboxDevice, cwd: cfg.root,
        startupTimeoutMs: Number(this.env.CHATTERBOX_STARTUP_TIMEOUT_MS) || 12 * 60 * 1000,
      });
    }
    return this.chatterboxRuntime;
  }
  shutdown() {
    try { this.chatterboxRuntime?.shutdown(); } catch {}
    try { this.audarRuntime?.shutdown(); } catch {}
    this.chatterboxRuntime = null; this.audarRuntime = null; this.audarRuntimeTier = '';
  }
  async status({ backend = '', voice = '', allowCloud = false, audarVoice = '' } = {}) {
    const cfg = this.config(backend);
    const cloudAllowed = allowCloud === true;
    if (cfg.backend === 'auto') {
      const local = await this.status({ backend: 'local', voice, audarVoice });
      const language = voiceLanguage(voice || EDGE_DEFAULT_VOICE);
      const edge = cloudAllowed ? await this.status({ backend: 'edge-tts', voice, allowCloud: true }) : null;
      const active = local.ready ? 'local' : (edge?.ready ? 'edge-tts' : 'local');
      const selected = active === 'edge-tts' && edge ? edge : local;
      const ready = Boolean(local.ready || edge?.ready);
      const message = local.ready
        ? (String(local.activeEngine || '').startsWith('audar-tts-v1-')
          ? 'النطق التلقائي يستخدم Audar العربي التعبيري محليًا أولًا، ولا يرسل النص إلى الإنترنت.'
          : local.activeEngine === 'chatterbox-multilingual-v3'
            ? 'النطق التلقائي يستخدم Chatterbox المحلي كخيار احتياطي.'
            : 'النطق التلقائي يستخدم Piper المحلي الاحتياطي؛ لا ينتقل إلى خدمة الإنترنت إلا بعد موافقتك الصريحة.')
        : edge?.ready
          ? 'النطق التلقائي جاهز لهذه اللغة عبر خدمة خارجية بعد موافقتك الصريحة.'
          : `لا يوجد محرك محلي جاهز لهذه اللغة. ${local.message}`;
      return { ...selected, backend: 'auto', mode: 'auto', activeBackend: active, ready, edgeTtsReady: Boolean(edge?.ready), localReady: local.ready, cloudAllowed, cloudConsentRequired: !cloudAllowed && !local.ready, ffmpegReady: local.ffmpegReady || Boolean(edge?.ffmpegReady), language, voice: String(voice || EDGE_DEFAULT_VOICE), message };
    }
    if (['edge-tts', 'openai-compatible'].includes(cfg.backend) && !cloudAllowed) {
      return { ready: false, binaryReady: false, modelReady: false, ffmpegReady: false, language: voiceLanguage(voice), voice: String(voice || EDGE_DEFAULT_VOICE), mode: cfg.backend, backend: cfg.backend, cloudAllowed: false, cloudConsentRequired: true, privacyNotice: 'سيتم إرسال نص الرد إلى مزود خارجي عند تفعيل هذا المحرك.', message: 'تم حظر محرك الصوت الخارجي لأن موافقة إرسال النص إلى خدمة سحابية غير مفعّلة. اختر «النطق السحابي» وفعّل الموافقة صراحةً من إعدادات التفاعل.' };
    }
    const ffmpegReady = await this.commandExists(cfg.ffmpegBinary);
    if (cfg.backend === 'edge-tts') {
      let pythonReady = false, edgeTtsAvailable = false, workerMessage = '';
      try { pythonReady = await this.commandExists(cfg.pythonBinary); } catch {}
      if (pythonReady && fs.existsSync(cfg.voiceWorker)) {
        try {
          const result = await this.execFile(cfg.pythonBinary, [cfg.voiceWorker, 'status'], { timeout: 15000, maxBuffer: 512 * 1024, windowsHide: true });
          const line = String(result.stdout || '').trim().split(/\r?\n/).filter(Boolean).at(-1) || '{}';
          edgeTtsAvailable = JSON.parse(line).edgeTtsAvailable === true;
        } catch (error) { workerMessage = String(error?.message || error).slice(0, 160); }
      }
      const ready = pythonReady && edgeTtsAvailable && ffmpegReady;
      return {
        ready, binaryReady: pythonReady, modelReady: edgeTtsAvailable, ffmpegReady, language: voiceLanguage(voice),
        voice: String(voice || EDGE_DEFAULT_VOICE), mode: 'edge-tts', backend: 'edge-tts',
        edgeTtsAvailable, message: ready
          ? 'صوت عصبي عربي عبر الإنترنت جاهز. هذا الوضع يرسل نص الكلام إلى خدمة Edge TTS؛ اختره صراحةً فقط إذا كنت موافقًا على الإرسال الخارجي.'
          : `النطق العصبي عبر الإنترنت يحتاج Python وحزمة edge-tts وFFmpeg. ${!pythonReady ? 'بيئة Python غير موجودة. ' : ''}${pythonReady && !edgeTtsAvailable ? 'حزمة edge-tts غير مثبتة. ' : ''}${!ffmpegReady ? 'لم يُعثر على FFmpeg أو النسخة المرفقة. ' : ''}${workerMessage}`,
        privacyNotice: 'النص الذي سيتم نطقه يُرسل إلى خدمة Edge TTS عبر الإنترنت عندما تختار هذا الوضع.',
      };
    }
    if (cfg.backend === 'openai-compatible') {
      const endpoint = String(this.env.TTS_API_URL || 'https://api.openai.com/v1/audio/speech').trim();
      const key = String(this.env.TTS_API_KEY || this.env.OPENAI_API_KEY || '').trim();
      let endpointValid = false; try { const u = new URL(endpoint); endpointValid = u.protocol === 'https:' || ['localhost','127.0.0.1','::1'].includes(u.hostname); } catch {}
      const ready = Boolean(key && endpointValid && typeof this.fetch === 'function' && ffmpegReady);
      return { ready, binaryReady: false, modelReady: Boolean(key && endpointValid), ffmpegReady, language: 'ar', voice: String(this.env.TTS_API_VOICE || 'alloy'), mode: 'openai-compatible', message: ready ? 'النطق عبر API خارجي مفعّل صراحةً؛ سيُرسل النص إلى المزود المحدد. FFmpeg جاهز لتحويل الصوت.' : 'وضع النطق الخارجي غير مكتمل: تحقق من TTS_API_KEY/OPENAI_API_KEY ورابط HTTPS أو localhost وتوفر FFmpeg.' };
    }
    const requestedLanguage = voiceLanguage(voice || EDGE_DEFAULT_VOICE);
    const ffmpeg = await this.commandExists(cfg.ffmpegBinary);
    const audar = await this.audarRuntimeStatus(cfg, requestedLanguage, audarVoice);
    const chatterbox = CHATTERBOX_LANGUAGES.has(requestedLanguage)
      ? await this.chatterboxRuntimeStatus(cfg)
      : { enabled: false, packageReady: false, modelReady: false, ready: false, message: `لغة ${requestedLanguage} غير مدعومة في محركات Chatterbox الحالية.` };
    const piper = requestedLanguage === 'ar' ? await this.piperFallbackStatus(cfg, ffmpeg) : { binaryReady: false, modelReady: false, ffmpegReady: ffmpeg, ready: false, piperTtsVersion: '', arabicTashkeelAvailable: false, arabicTashkeelEnabledByDefault: false };
    const useAudar = audar.ready && ffmpeg && ['ar', 'en'].includes(requestedLanguage);
    const useChatterbox = !useAudar && chatterbox.ready && ffmpeg;
    const usePiper = !useAudar && !useChatterbox && requestedLanguage === 'ar' && piper.ready;
    const ready = useAudar || useChatterbox || usePiper;
    const message = useAudar
      ? `Audar-TTS-V1 ${cfg.audarTier.toUpperCase()} المحلي جاهز للغة ${requestedLanguage}. يستخدم ستة أصوات اصطناعية ووسوم انفعالية حقيقية؛ لا يغادر النص الجهاز. ${piper.ready ? 'Piper محفوظ كاحتياط.' : ''}`
      : useChatterbox
        ? `Chatterbox V3 المحلي جاهز كخيار احتياطي للغة ${requestedLanguage}.`
        : usePiper
          ? `Audar غير مكتمل (${audar.message})؛ يعمل Piper العربي كخطة طوارئ أقل تعبيرًا.`
          : !ffmpeg
            ? 'لم يُعثر على FFmpeg اللازم لتحويل WAV إلى OGG/Opus.'
            : requestedLanguage === 'ar' || requestedLanguage === 'en'
              ? `Audar غير جاهز: ${audar.message}${requestedLanguage === 'ar' && piper.ready ? ' ويتوفر Piper كبديل عربي.' : ''}`
              : `لا يوجد محرك محلي جاهز لهذه اللغة. Audar: ${audar.message} Chatterbox: ${chatterbox.message}`;
    return {
      ready, binaryReady: useAudar || useChatterbox || piper.binaryReady, modelReady: useAudar || useChatterbox || piper.modelReady,
      ffmpegReady: ffmpeg, language: requestedLanguage, voice: String(voice || EDGE_DEFAULT_VOICE), mode: 'local', backend: 'local',
      activeEngine: useAudar ? `audar-tts-v1-${cfg.audarTier}` : (useChatterbox ? 'chatterbox-multilingual-v3' : (usePiper ? 'piper-arabic-fallback' : 'unavailable')),
      audar, audarReady: useAudar, chatterbox, chatterboxReady: useChatterbox, piperFallbackReady: piper.ready,
      piperTtsVersion: piper.piperTtsVersion || '', arabicTashkeelAvailable: piper.arabicTashkeelAvailable === true,
      arabicTashkeelEnabledByDefault: piper.arabicTashkeelEnabledByDefault === true,
      privacyNotice: 'Audar وChatterbox وPiper تعمل محليًا ولا ترسل نص الرد إلى مزود خارجي.', message,
    };
  }
  async prepareText(text, { proofread = true, model = 'qwen3.5:4b', timeoutMs = 18000, pronunciationDictionary = [] } = {}) {
    const original = normalizeSpeechText(text);
    if (!original) throw new Error('لا يوجد نص صالح لتحويله إلى كلام.');
    if (original.length > MAX_SPEECH_CHARS || String(text || '').length > 10000) throw new Error('النص طويل جدًا؛ اختصر الرد إلى 1800 حرف كحد أقصى للنطق.');
    if (!proofread || !this.localLlm) { const speech = applyPronunciationDictionary(original, pronunciationDictionary); return { text: speech.text, sourceText: original, pronunciationReplacements: speech.replacements, proofreadUsed: false, proofreadReason: proofread ? 'local-llm-unavailable' : 'disabled' }; }
    try {
      const language = detectSpeechLanguage(original);
      const prompts = {
        ar: 'أنت مساعد إعداد نص عربي للنطق. أضف التشكيل العربي الضروري فقط للكلمات التي قد تُنطق خطأ أو تحتمل أكثر من قراءة، واضبط الهمزات وعلامات الترقيم البسيطة عند الحاجة. لا تستبدل أي كلمة ولا تعيد صياغة الجملة ولا تحذف أو تضف معنى أو معلومة. حافظ على ترتيب كل الكلمات والأسماء والأرقام والتواريخ والروابط كما هي تمامًا؛ المسموح به هو إضافة علامات التشكيل فقط وتعديل الترقيم. أخرج النص وحده بلا مقدمات أو Markdown.',
        en: 'You are a careful English proofreader. Correct spelling, grammar and punctuation only. Do not translate, summarize or add facts. Preserve names, numbers, dates, URLs and meaning. Return only the corrected text without a preface or Markdown.',
        fr: 'Vous êtes un correcteur français rigoureux. Corrigez uniquement l’orthographe, la grammaire et la ponctuation. Ne traduisez pas, ne résumez pas et n’ajoutez aucune information. Préservez les noms, nombres, dates, URL et le sens. Retournez seulement le texte corrigé.',
        de: 'Du bist ein sorgfältiger deutscher Korrektor. Korrigiere nur Rechtschreibung, Grammatik und Zeichensetzung. Übersetze oder fasse nicht zusammen und füge keine Fakten hinzu. Bewahre Namen, Zahlen, Daten, URLs und Bedeutung. Gib nur den korrigierten Text aus.'
      };
      const candidate = await this.localLlm.generate({ model, timeoutMs, maxTokens: 420,
        system: prompts[language] || prompts.en,
        messages: [{ role: 'user', content: original }] });
      const checked = language === 'ar'
        ? normalizeArabicDiacritizedCandidate(candidate, original)
        : normalizeGrammarCandidate(candidate, original);
      const speech = applyPronunciationDictionary(checked.text, pronunciationDictionary);
      return { text: speech.text, sourceText: checked.text, pronunciationReplacements: speech.replacements, proofreadUsed: checked.used, proofreadReason: checked.reason };
    } catch (error) {
      const speech = applyPronunciationDictionary(original, pronunciationDictionary);
      return { text: speech.text, sourceText: original, pronunciationReplacements: speech.replacements, proofreadUsed: false, proofreadReason: `local-review-unavailable: ${String(error?.message || error).slice(0, 160)}` };
    }
  }
  async generate(text, { proofread = true, model = 'qwen3.5:4b', timeoutMs = 18000, backend = '', voice = '', style = 'natural', rate = 0, pitch = 0, volume = 0, noiseScale = 0.667, noiseWidth = 0.8, exaggeration = undefined, allowCloud = false, pronunciationDictionary = [], audarVoice = '' } = {}) {
    const cfg = this.config(backend);
    const cloudAllowed = allowCloud === true;
    const tuning = resolveVoiceTuning({ style, rate, pitch, volume, noiseScale, noiseWidth });
    if (['edge-tts', 'openai-compatible'].includes(cfg.backend) && !cloudAllowed) {
      throw new Error('تم منع إرسال النص إلى مزود صوت خارجي لأن موافقة السحابة غير مفعّلة. فعّل خيار الموافقة صراحةً من إعدادات التفاعل أولًا.');
    }
    if (cfg.backend === 'local' && !CHATTERBOX_LANGUAGES.has(detectSpeechLanguage(text)) && !cloudAllowed) {
      throw new Error('هذه اللغة غير مدعومة في المحركات المحلية الحالية. استخدم لغة مدعومة أو فعّل محركًا خارجيًا بموافقة صريحة.');
    }
    if (cfg.backend === 'auto') {
      const selectedVoice = defaultVoiceForText(text, voice || this.env.TTS_API_VOICE || EDGE_DEFAULT_VOICE);
      const language = voiceLanguage(selectedVoice);
      const candidates = [];
      // Chatterbox V3 is local-first for its supported languages; Piper remains
      // the Arabic-only local fallback. Remote synthesis still requires consent.
      const localStatus = await this.status({ backend: 'local', voice: selectedVoice, audarVoice });
      if (localStatus.ready) candidates.push('local');
      if (cloudAllowed) {
        const edgeStatus = await this.status({ backend: 'edge-tts', voice: selectedVoice, allowCloud: true });
        if (edgeStatus.ready) candidates.push('edge-tts');
      }
      if (!candidates.length) {
        const reason = !cloudAllowed
          ? 'محرك Audar/Chatterbox/Piper المحلي غير جاهز لهذه اللغة؛ فعّل موافقة السحابة صراحةً فقط إذا كنت تريد استخدام خدمة خارجية.'
          : 'لم يجهز أي محرك نطق متاح لهذه اللغة.';
        throw new Error(`تعذر بدء النطق التلقائي. ${reason}`);
      }
      let lastError;
      for (const candidate of candidates) {
        try { return await this.generate(text, { proofread, model, timeoutMs, backend: candidate, voice: selectedVoice, style, rate, pitch, volume, noiseScale, noiseWidth, exaggeration, allowCloud: cloudAllowed, pronunciationDictionary, audarVoice }); }
        catch (error) { lastError = error; }
      }
      throw new Error(`فشلت محركات النطق المتاحة. ${String(lastError?.message || 'خطأ غير معروف').slice(0, 360)}`);
    }
    const statusVoice = cfg.backend === 'local' ? defaultVoiceForText(text, voice || this.env.TTS_API_VOICE || EDGE_DEFAULT_VOICE) : voice;
    const status = await this.status({ backend: cfg.backend, voice: statusVoice, allowCloud: cloudAllowed, audarVoice });
    if (!status.ready) throw new Error(status.message || 'محرك النطق غير جاهز.');
    const prepared = await this.prepareText(text, { proofread, model, timeoutMs, pronunciationDictionary });
    const dir = fs.mkdtempSync(path.join(this.tempRoot, 'chatbot-tts-'));
    const wavPath = path.join(dir, `speech-${crypto.randomUUID()}.wav`);
    try {
      if (cfg.backend === 'local') {
        const languageId = detectSpeechLanguage(prepared.text);
        const profileId = String(audarVoice || cfg.audarDefaultVoice || 'demo_male_1');
        const audar = await this.audarRuntimeStatus(cfg, languageId, profileId);
        if (audar.ready && ['ar', 'en'].includes(languageId)) {
          const annotated = annotateAudarExpressionTags(prepared.text, style);
          try {
            const result = await this.getAudarRuntime(cfg, profileId).generate({
              text: annotated.text, outputPath: wavPath, voice: profileId,
              timeoutMs: Number(this.env.AUDAR_TTS_GENERATION_TIMEOUT_MS) || 8 * 60 * 1000,
              maxNewTokens: Math.max(300, Math.min(4096, Number(this.env.AUDAR_TTS_MAX_NEW_TOKENS) || 1800)),
              temperature: resolveAudarSamplingTemperature(exaggeration, style),
              topK: Math.max(10, Math.min(80, Number(this.env.AUDAR_TTS_TOP_K) || 40)),
              topP: Math.max(0.65, Math.min(0.98, Number(this.env.AUDAR_TTS_TOP_P) || 0.90)),
            });
            this.audarRuntimeFailure = '';
            const stat = fs.statSync(wavPath);
            if (!stat.isFile() || stat.size < 128 || stat.size > 50 * 1024 * 1024) throw new Error('حجم ملف الصوت الناتج من Audar غير صالح.');
            return {
              ...prepared, wavPath, audioPath: wavPath, directory: dir, bytes: stat.size,
              voice: result.voice || profileId, language: languageId, mimeType: 'audio/wav', backend: 'local',
              engine: `audar-tts-v1-${cfg.audarTier}`, expressiveStyle: String(style || 'auto'), samplingTemperature: resolveAudarSamplingTemperature(exaggeration, style),
              expressionTags: annotated.tags, sampleRate: result.sampleRate || 24000,
              durationSeconds: result.durationSeconds, rate: 0, pitch: 0, volume: tuning.volume,
            };
          } catch (error) {
            this.audarRuntimeFailure = String(error?.message || error).slice(0, 700);
            if (languageId !== 'ar' || status.piperFallbackReady !== true) {
              const fallback = await this.chatterboxRuntimeStatus(cfg);
              if (!fallback.ready) throw new Error(`تعذر توليد الصوت عبر Audar. ${this.audarRuntimeFailure}`);
            }
          }
        }
        const chatterbox = await this.chatterboxRuntimeStatus(cfg);
        if (chatterbox.ready && CHATTERBOX_LANGUAGES.has(languageId)) {
          const expressiveSegments = splitExpressiveSegments(prepared.text).map(part => ({ text: part, languageId, ...resolveExpressiveTuning({ text: part, style, exaggeration: exaggeration ?? this.env.CHATTERBOX_EXAGGERATION, cfgWeight: this.env.CHATTERBOX_CFG_WEIGHT, temperature: this.env.CHATTERBOX_TEMPERATURE }) }));
          const expressive = resolveExpressiveTuning({ text: prepared.text, style, exaggeration: exaggeration ?? this.env.CHATTERBOX_EXAGGERATION, cfgWeight: this.env.CHATTERBOX_CFG_WEIGHT, temperature: this.env.CHATTERBOX_TEMPERATURE });
          try {
            const result = await this.getChatterboxRuntime(cfg).generate({ text: prepared.text, segments: expressiveSegments, languageId, outputPath: wavPath, exaggeration: expressive.exaggeration, cfgWeight: expressive.cfgWeight, temperature: expressive.temperature, timeoutMs: Number(this.env.CHATTERBOX_GENERATION_TIMEOUT_MS) || Math.max(600000, Number(this.env.TTS_TIMEOUT_MS) || 60000) });
            const stat = fs.statSync(wavPath);
            if (!stat.isFile() || stat.size < 128 || stat.size > 50 * 1024 * 1024) throw new Error('حجم ملف الصوت الناتج من Chatterbox غير صالح.');
            return { ...prepared, wavPath, audioPath: wavPath, directory: dir, bytes: stat.size, voice: 'Chatterbox V3 default speaker', language: languageId, mimeType: 'audio/wav', backend: 'local', engine: 'chatterbox-multilingual-v3', expressiveStyle: expressive.style, exaggeration: expressive.exaggeration, cfgWeight: expressive.cfgWeight, temperature: expressive.temperature, style: expressive.style, rate: 0, pitch: 0, volume: tuning.volume, device: result.device || 'auto' };
          } catch (error) {
            this.chatterboxRuntimeFailure = String(error?.message || error).slice(0, 500);
            if (languageId !== 'ar' || status.piperFallbackReady !== true) throw new Error(`تعذر توليد الصوت بمحرك Chatterbox V3. ${this.chatterboxRuntimeFailure}`);
          }
        } else if (languageId !== 'ar') {
          throw new Error(`لا يوجد محرك محلي جاهز لهذه اللغة. ${audar.message || chatterbox.message || ''}`);
        }
      }
      if (cfg.backend === 'edge-tts') {
        const audioPath = path.join(dir, `speech-${crypto.randomUUID()}.mp3`);
        const selectedVoice = defaultVoiceForText(text, voice || this.env.TTS_API_VOICE || EDGE_DEFAULT_VOICE);
        const args = [cfg.voiceWorker, 'edge-tts', audioPath, selectedVoice, String(tuning.rate), String(tuning.pitch), String(tuning.volume)];
        await this.runPythonWorker(cfg, args, prepared.text, Math.max(15000, Math.min(120000, Number(this.env.TTS_TIMEOUT_MS) || 60000)));
        const stat = fs.statSync(audioPath);
        if (!stat.isFile() || stat.size < 100) throw new Error('لم ينتج محرك Edge TTS ملف MP3 صالحًا.');
        return { ...prepared, wavPath: audioPath, audioPath, directory: dir, bytes: stat.size, voice: selectedVoice, language: voiceLanguage(selectedVoice), mimeType: 'audio/mpeg', backend: 'edge-tts', style: tuning.style, rate: tuning.rate, pitch: tuning.pitch, volume: tuning.volume };
      }
      if (cfg.backend === 'openai-compatible') {
        const endpoint = String(this.env.TTS_API_URL || 'https://api.openai.com/v1/audio/speech').trim();
        const key = String(this.env.TTS_API_KEY || this.env.OPENAI_API_KEY || '').trim();
        let url; try { url = new URL(endpoint); } catch { throw new Error('رابط خدمة النطق غير صالح.'); }
        if (!(url.protocol === 'https:' || ['localhost','127.0.0.1','::1'].includes(url.hostname))) throw new Error('لأمان النصوص، يجب أن يكون رابط النطق HTTPS أو localhost.');
        let response;
        try { response = await this.fetch(url, { method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: String(this.env.TTS_API_MODEL || 'tts-1').slice(0, 100), voice: String(this.env.TTS_API_VOICE || 'alloy').slice(0, 80), input: prepared.text, response_format: 'wav' }), signal: AbortSignal.timeout(Math.max(10000, Math.min(120000, Number(this.env.TTS_TIMEOUT_MS) || 45000))) }); }
        catch (error) { throw new Error(`فشل الاتصال بخدمة النطق الخارجية: ${String(error?.message || error).slice(0, 180)}.`); }
        if (!response.ok) { let detail = ''; try { detail = (await response.text()).slice(0, 240); } catch {} throw new Error(`خدمة النطق أعادت HTTP ${response.status}: ${detail.replace(/Bearer\s+\S+/gi, '[مخفي]').replace(/https?:\/\/\S+/g, '[رابط]')}`); }
        const bytes = Buffer.from(await response.arrayBuffer());
        if (bytes.length < 128 || bytes.length > 50 * 1024 * 1024) throw new Error('حجم الصوت الذي أعادته الخدمة غير صالح.');
        fs.writeFileSync(wavPath, bytes, { flag: 'wx', mode: 0o600 });
        return { ...prepared, wavPath, directory: dir, bytes: bytes.length, voice: String(this.env.TTS_API_VOICE || 'alloy'), language: voiceLanguage(voice), mimeType: 'audio/wav', backend: 'openai-compatible' };
      }
      await new Promise((resolve, reject) => {
        let settled = false;
        let timer = null;
        const finish = error => { if (settled) return; settled = true; if (timer) clearTimeout(timer); error ? reject(error) : resolve(); };
        let child;
        const ratePct = tuning.rate;
        const lengthScale = Math.max(0.714, Math.min(1.667, 1 / (1 + ratePct / 100)));
        const nScale = tuning.noiseScale;
        const nWidth = tuning.noiseWidth;
        try { child = this.spawn(cfg.binary, ['--model', cfg.modelPath, '--output_file', wavPath, '--length_scale', String(lengthScale), '--noise_scale', String(nScale), '--noise_w', String(nWidth)], { cwd: cfg.root, windowsHide: true, stdio: ['pipe', 'ignore', 'pipe'], env: { ...process.env, ...this.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' } }); }
        catch (error) { finish(error); return; }
        let stderr = '';
        child.stderr?.on('data', chunk => { stderr = (stderr + String(chunk)).slice(-4000); });
        child.once('error', error => finish(new Error(`تعذر تشغيل Piper: ${String(error?.message || error).slice(0, 200)}`)));
        child.once('close', code => {
          if (code !== 0) { const diagnostic = stderr.length <= 1400 ? stderr : `${stderr.slice(0, 700)}\n...\n${stderr.slice(-700)}`; return finish(new Error(`فشل توليد الكلام (رمز ${code}): ${diagnostic || 'Piper exited without diagnostics.'}`)); }
          try { const stat = fs.statSync(wavPath); if (stat.size < 128 || stat.size > 50 * 1024 * 1024) throw new Error('حجم ملف الصوت الناتج غير صالح.'); }
          catch (error) { return finish(error); }
          finish();
        });
        timer = setTimeout(() => { try { child.kill('SIGTERM'); } catch {} finish(new Error('انتهت مهلة تحويل النص إلى كلام. جرّب ردًا أقصر أو افحص موارد الجهاز.')); }, Math.max(5000, Math.min(120000, Number(this.env.TTS_TIMEOUT_MS) || 45000)));
        child.stdin.on('error', error => finish(new Error(`تعذر تمرير النص إلى محرك النطق: ${String(error?.message || error).slice(0, 150)}`)));
        child.stdin.end(prepared.text + '\n');
      });
      return { ...prepared, wavPath, audioPath: wavPath, directory: dir, bytes: fs.statSync(wavPath).size, voice: 'ar_JO-kareem-medium', language: 'ar', mimeType: 'audio/wav', backend: 'local', engine: 'piper-arabic-fallback', fallbackReason: this.chatterboxRuntimeFailure || '', style: tuning.style, rate: tuning.rate, pitch: tuning.pitch, volume: tuning.volume, noiseScale: tuning.noiseScale, noiseWidth: tuning.noiseWidth };
    } catch (error) {
      try { fs.rmSync(dir, { recursive: true, force: true }); } catch {}
      throw error;
    }
  }
  async runPythonWorker(cfg, args, inputText = '', timeoutMs = 60000) {
    if (!await this.commandExists(cfg.pythonBinary)) throw new Error('بيئة Python الخاصة بالصوت لم تكتمل بعد. انتظر التهيئة التلقائية عند بدء المشروع، ثم راجع حالة الصوت في لوحة التحكم إذا استمر الخطأ.');
    if (!fs.existsSync(cfg.voiceWorker)) throw new Error('scripts/voice_worker.py غير موجود؛ أعد فك المشروع كاملًا.');
    return new Promise((resolve, reject) => {
      let settled = false, stdout = '', stderr = '', timer;
      const finish = error => { if (settled) return; settled = true; if (timer) clearTimeout(timer); error ? reject(error) : resolve({ stdout, stderr }); };
      let child;
      try { child = this.spawn(cfg.pythonBinary, args, { cwd: cfg.root, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] }); }
      catch (error) { finish(new Error(`تعذر تشغيل مكتبة الصوت Python: ${String(error?.message || error).slice(0, 220)}`)); return; }
      child.stdout?.on('data', chunk => { stdout = (stdout + String(chunk)).slice(-1024 * 1024); });
      child.stderr?.on('data', chunk => { stderr = (stderr + String(chunk)).slice(-8000); });
      child.once('error', error => finish(new Error(`تعذر تشغيل محرك Python الصوتي: ${String(error?.message || error).slice(0, 220)}`)));
      child.once('close', code => {
        const line = stdout.trim().split(/\r?\n/).filter(Boolean).at(-1) || '';
        let payload = null; try { payload = JSON.parse(line); } catch {}
        if (code !== 0 || payload?.ok === false) return finish(new Error(String(payload?.error || stderr || `فشل محرك الصوت (رمز ${code}).`).replace(/https?:\/\/\S+/g, '[رابط خدمة]').slice(0, 500)));
        if (!payload?.ok) return finish(new Error('استجابة غير معروفة من محرك الصوت Python.'));
        finish();
      });
      timer = setTimeout(() => { try { child.kill('SIGTERM'); } catch {} finish(new Error('انتهت مهلة توليد الصوت. تحقق من اتصال الإنترنت أو جرّب نصًا أقصر.')); }, timeoutMs);
      child.stdin?.on('error', error => finish(new Error(`تعذر تمرير النص إلى محرك الصوت: ${String(error?.message || error).slice(0, 150)}`)));
      child.stdin?.end(String(inputText || '') + '\n');
    });
  }
  async toWhatsAppVoice(wavPath, { volume = 0, pitch = 0 } = {}) {
    const cfg = this.config();
    if (!wavPath || !fs.existsSync(wavPath) || !fs.statSync(wavPath).isFile()) throw new Error('ملف الصوت الناتج غير موجود.');
    if (!await this.commandExists(cfg.ffmpegBinary)) throw new Error('يلزم FFmpeg لتحويل WAV إلى OGG/Opus قبل إرساله كرسالة صوتية. شغّل أداة إعداد الصوت وتأكد من FFMPEG_BIN.');
    const output = path.join(path.dirname(wavPath), `voice-${crypto.randomUUID()}.ogg`);
    try {
      const volumePct = Math.max(-30, Math.min(30, Number(volume) || 0));
      const volumeScalar = Math.max(0.1, Math.min(2, 1 + volumePct / 100));
      // Piper has no native pitch argument. For the local WAV, shift pitch slightly
      // and compensate with atempo so the duration does not drift significantly.
      const pitchCents = Math.max(-30, Math.min(30, Number(pitch) || 0)) * 2;
      const pitchFactor = Math.pow(2, pitchCents / 1200);
      const filters = [];
      if (Math.abs(pitchCents) > 0.5) filters.push(`aresample=48000,asetrate=${(48000 * pitchFactor).toFixed(1)},aresample=48000,atempo=${(1 / pitchFactor).toFixed(5)}`);
      filters.push(`volume=${volumeScalar.toFixed(2)}`);
      await this.execFile(cfg.ffmpegBinary, ['-y', '-i', wavPath, '-vn', '-ac', '1', '-ar', '48000', '-af', filters.join(','), '-c:a', 'libopus', '-b:a', '48k', '-vbr', 'on', output], { timeout: 90000, maxBuffer: 1024 * 1024, windowsHide: true });
      const validation = assertOggOpusFile(output, { maxBytes: 32 * 1024 * 1024 });
      if (!validation.valid) throw new Error('لم ينتج FFmpeg ملف OGG/Opus صالحًا.');
      return output;
    } catch (error) {
      try { fs.rmSync(output, { force: true }); } catch {}
      throw new Error(`تعذر تجهيز الصوت كرسالة WhatsApp صوتية: ${String(error?.message || error).slice(0, 400)}`);
    }
  }
  cleanup(result) { const dir = String(result?.directory || (result?.wavPath ? path.dirname(result.wavPath) : '')); if (dir && path.basename(dir).startsWith('chatbot-tts-')) { try { fs.rmSync(dir, { recursive: true, force: true }); return true; } catch {} } return false; }
}

module.exports = { TextToSpeech, MAX_SPEECH_CHARS, MAX_PRONUNCIATION_RULES, normalizeSpeechText, normalizeGrammarCandidate, normalizeArabicDiacritizedCandidate, arabicSpeechTokens, textTokensForPreservation, validatePronunciationDictionary, applyPronunciationDictionary, splitSpeechText, resolveFromRoot, VOICE_STYLE_PRESETS, resolveVoiceTuning, resolveExpressiveTuning, classifyExpressiveStyle, splitExpressiveSegments, annotateAudarExpressionTags, resolveAudarSamplingTemperature, AUDAR_STYLE_TAGS, CHATTERBOX_STYLE_PRESETS, CHATTERBOX_LANGUAGES, voiceLanguage, detectSpeechLanguage, defaultVoiceForText };
