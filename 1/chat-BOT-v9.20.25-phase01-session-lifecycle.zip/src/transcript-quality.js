'use strict';

const LANGUAGE_ALIASES = Object.freeze({
  ar: 'ar', arabic: 'ar', en: 'en', english: 'en', fr: 'fr', french: 'fr', de: 'de', german: 'de',
  es: 'es', spanish: 'es', ur: 'ur', urdu: 'ur', hi: 'hi', hindi: 'hi', tr: 'tr', turkish: 'tr',
});

function finite(value) {
  if (value === null || value === undefined || value === '') return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}
function clamp(value, min = 0, max = 1) { return Math.max(min, Math.min(max, value)); }
function normalizeLanguage(value) {
  const key = String(value || '').trim().toLowerCase().split(/[-_]/)[0];
  return LANGUAGE_ALIASES[key] || (key || 'unknown');
}
function normalizeTranscriptText(value) {
  return String(value || '').replace(/\u0000/g, '').replace(/[\u200b\ufeff]/g, '').replace(/\s+/g, ' ').trim().slice(0, 12000);
}
function evaluateTranscriptQuality(result = {}, options = {}) {
  const text = normalizeTranscriptText(result.transcript || result.text || '');
  const requestedLanguage = normalizeLanguage(options.requestedLanguage ?? result.requestedLanguage ?? 'auto');
  const detectedLanguage = normalizeLanguage(result.language || 'unknown');
  const languageProbability = finite(result.languageProbability);
  const avgLogProbability = finite(result.avgLogProbability);
  const avgNoSpeechProbability = finite(result.avgNoSpeechProbability);
  const maxCompressionRatio = finite(result.maxCompressionRatio);
  const segmentCount = Math.max(0, Math.floor(finite(result.segments) ?? 0));
  const lowConfidenceSegments = Math.max(0, Math.floor(finite(result.lowConfidenceSegments) ?? 0));
  const lowConfidenceRatio = segmentCount > 0 ? clamp(lowConfidenceSegments / segmentCount) : null;
  const reasons = [];
  const warnings = [];
  let severe = false;
  let scoreParts = [];

  if (!text) {
    return { status: 'rejected', actionable: false, score: 0, metadataSufficient: false, notStatisticallyCalibrated: true, reasons: ['empty-transcript'], warnings: [], language: detectedLanguage, requestedLanguage, metrics: { languageProbability, avgLogProbability, avgNoSpeechProbability, maxCompressionRatio, segmentCount, lowConfidenceSegments } };
  }
  if (requestedLanguage !== 'auto' && detectedLanguage !== 'unknown' && detectedLanguage !== requestedLanguage) {
    severe = true;
    reasons.push('language-mismatch');
  }
  if (requestedLanguage === 'auto' && detectedLanguage === 'unknown') warnings.push('language-unknown');
  if (languageProbability !== null) {
    scoreParts.push({ value: clamp(languageProbability), weight: 0.15 });
    if (languageProbability < 0.25) { severe = true; reasons.push('language-detection-very-weak'); }
    else if (languageProbability < 0.45) warnings.push('language-detection-weak');
  } else warnings.push('language-probability-missing');

  if (avgLogProbability !== null) {
    scoreParts.push({ value: clamp((avgLogProbability + 1.5) / 1.5), weight: 0.35 });
    if (avgLogProbability < -1.25) { severe = true; reasons.push('very-low-token-probability'); }
    else if (avgLogProbability < -0.85) warnings.push('low-token-probability');
  } else warnings.push('token-probability-missing');

  if (avgNoSpeechProbability !== null) {
    scoreParts.push({ value: clamp(1 - avgNoSpeechProbability), weight: 0.15 });
    if (avgNoSpeechProbability >= 0.8 && avgLogProbability !== null && avgLogProbability < -1.0) { severe = true; reasons.push('high-no-speech-probability'); }
    else if (avgNoSpeechProbability >= 0.6) warnings.push('possible-silence-or-noise');
  } else warnings.push('no-speech-probability-missing');

  if (maxCompressionRatio !== null) {
    scoreParts.push({ value: clamp((3.5 - maxCompressionRatio) / 1.5), weight: 0.15 });
    if (maxCompressionRatio >= 3.2) { severe = true; reasons.push('repetition-or-hallucination-risk'); }
    else if (maxCompressionRatio > 2.4) warnings.push('high-compression-ratio');
  } else warnings.push('compression-ratio-missing');

  if (lowConfidenceRatio !== null) {
    scoreParts.push({ value: 1 - lowConfidenceRatio, weight: 0.2 });
    if (lowConfidenceRatio >= 0.5) { severe = true; reasons.push('many-low-quality-segments'); }
    else if (lowConfidenceRatio >= 0.25) warnings.push('some-low-quality-segments');
  }
  if (segmentCount === 0) warnings.push('segment-metadata-missing');
  if ([...text].filter(char => /[\p{L}\p{N}]/u.test(char)).length < 2) warnings.push('very-short-transcript');

  const metricsCount = [languageProbability, avgLogProbability, avgNoSpeechProbability, maxCompressionRatio].filter(value => value !== null).length;
  const metadataSufficient = metricsCount >= 3 && segmentCount > 0;
  const totalWeight = scoreParts.reduce((sum, item) => sum + item.weight, 0);
  const score = totalWeight ? Number((scoreParts.reduce((sum, item) => sum + item.value * item.weight, 0) / totalWeight).toFixed(3)) : null;
  let status = 'clear';
  if (severe) status = 'rejected';
  else if (!metadataSufficient) status = 'unverified';
  else if (warnings.length) status = 'review';

  return {
    status,
    actionable: status === 'clear',
    score,
    metadataSufficient,
    notStatisticallyCalibrated: true,
    method: 'whisper-segment-metadata-heuristic-v1',
    metricCoverage: `${metricsCount}/4`,
    reasons,
    warnings,
    language: detectedLanguage,
    requestedLanguage,
    metrics: { languageProbability, avgLogProbability, avgNoSpeechProbability, maxCompressionRatio, segmentCount, lowConfidenceSegments, lowConfidenceRatio },
  };
}

function summarizeQuality(quality) {
  if (!quality || typeof quality !== 'object') return 'لم تتوفر بيانات جودة التفريغ.';
  const labels = {
    'language-mismatch': 'اللغة المكتشفة لا تطابق اللغة المختارة',
    'language-detection-very-weak': 'ثقة تحديد اللغة منخفضة جدًا',
    'very-low-token-probability': 'احتمال الكلمات منخفض جدًا',
    'high-no-speech-probability': 'احتمال الصمت مرتفع مع ضعف احتمال الكلمات',
    'repetition-or-hallucination-risk': 'احتمال التكرار أو اختلاق كلمات',
    'many-low-quality-segments': 'عدد كبير من مقاطع الصوت منخفض الجودة',
    'language-detection-weak': 'تحديد اللغة غير مؤكد',
    'low-token-probability': 'بعض الكلمات غير مؤكدة',
    'possible-silence-or-noise': 'قد توجد مقاطع صامتة أو ضوضاء',
    'high-compression-ratio': 'قد توجد إعادة كلمات أو تكرار',
    'some-low-quality-segments': 'بعض المقاطع تحتاج مراجعة',
    'language-unknown': 'لم تُحدد اللغة بوضوح',
  };
  const items = [...(quality.reasons || []), ...(quality.warnings || [])].map(code => labels[code] || code);
  return items.length ? [...new Set(items)].join('؛ ') : 'لم تظهر مؤشرات ضعف في القياسات المتاحة.';
}

module.exports = { evaluateTranscriptQuality, summarizeQuality, normalizeTranscriptText, normalizeLanguage };
