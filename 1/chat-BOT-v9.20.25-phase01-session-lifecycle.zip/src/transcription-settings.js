'use strict';

const MODEL_SIZES = new Set(['tiny', 'base', 'small', 'medium', 'large-v3', 'large-v3-turbo']);
const DEVICES = new Set(['cpu', 'auto']);
const COMPUTE_TYPES = new Set(['int8', 'int8_float32', 'float32']);

function booleanValue(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'boolean') return value;
  const text = String(value).trim().toLowerCase();
  if (['1', 'true', 'yes', 'on'].includes(text)) return true;
  if (['0', 'false', 'no', 'off'].includes(text)) return false;
  throw new Error('قيمة منطقية غير صالحة في إعدادات التفريغ.');
}
function boundedInteger(value, fallback, min, max, label) {
  if (value === undefined || value === null || value === '') return fallback;
  const number = Number(value);
  if (!Number.isInteger(number) || number < min || number > max) throw new Error(`${label}: يجب أن تكون قيمة صحيحة بين ${min} و${max}.`);
  return number;
}
function boundedNumber(value, fallback, min, max, label) {
  if (value === undefined || value === null || value === '') return fallback;
  const number = Number(value);
  if (!Number.isFinite(number) || number < min || number > max) throw new Error(`${label}: القيمة خارج النطاق ${min}–${max}.`);
  return number;
}
function safeInteger(value, fallback, min, max) { const n = Number(value); return Number.isInteger(n) && n >= min && n <= max ? n : fallback; }
function safeNumber(value, fallback, min, max) { const n = Number(value); return Number.isFinite(n) && n >= min && n <= max ? n : fallback; }
function safeEnum(value, fallback, allowed) { const text = String(value || '').trim().toLowerCase(); return allowed.has(text) ? text : fallback; }
function safeBoolean(value, fallback) { try { return booleanValue(value, fallback); } catch { return fallback; } }
function enumValue(value, fallback, allowed, label) {
  if (value === undefined || value === null || value === '') return fallback;
  const text = String(value).trim().toLowerCase();
  if (!allowed.has(text)) throw new Error(`${label}: اختيار غير مدعوم.`);
  return text;
}

function validateTranscriptionSettings(input = {}, current = {}) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('إعدادات التفريغ يجب أن تكون كائنًا صالحًا.');
  const previousModel = safeEnum(current.modelSize, 'small', MODEL_SIZES);
  const modelSize = enumValue(input.modelSize, previousModel, MODEL_SIZES, 'حجم النموذج');
  const settings = {
    modelSize,
    device: enumValue(input.device, safeEnum(current.device, 'cpu', DEVICES), DEVICES, 'الجهاز'),
    computeType: enumValue(input.computeType, safeEnum(current.computeType, 'int8', COMPUTE_TYPES), COMPUTE_TYPES, 'نوع الحساب'),
    beamSize: boundedInteger(input.beamSize, safeInteger(current.beamSize, 5, 1, 10), 1, 10, 'Beam size'),
    vad: booleanValue(input.vad, safeBoolean(current.vad, true)),
    vadThreshold: boundedNumber(input.vadThreshold, safeNumber(current.vadThreshold, 0.5, 0.1, 0.95), 0.1, 0.95, 'VAD threshold'),
    minSilenceMs: boundedInteger(input.minSilenceMs, safeInteger(current.minSilenceMs, 450, 100, 3000), 100, 3000, 'Min silence'),
    logProbThreshold: boundedNumber(input.logProbThreshold, safeNumber(current.logProbThreshold, -1.0, -3.0, 0.0), -3.0, 0.0, 'Log probability'),
    noSpeechThreshold: boundedNumber(input.noSpeechThreshold, safeNumber(current.noSpeechThreshold, 0.6, 0.1, 0.99), 0.1, 0.99, 'No-speech threshold'),
    compressionRatioThreshold: boundedNumber(input.compressionRatioThreshold, safeNumber(current.compressionRatioThreshold, 2.4, 1.0, 5.0), 1.0, 5.0, 'Compression ratio'),
    conditionOnPreviousText: booleanValue(input.conditionOnPreviousText, safeBoolean(current.conditionOnPreviousText, false)),
  };
  const modelChanged = modelSize !== previousModel;
  const env = {
    WHISPER_PY_MODEL: settings.modelSize,
    WHISPER_PY_DEVICE: settings.device,
    WHISPER_PY_COMPUTE_TYPE: settings.computeType,
    WHISPER_PY_BEAM_SIZE: String(settings.beamSize),
    WHISPER_PY_VAD: String(settings.vad),
    WHISPER_PY_VAD_THRESHOLD: String(settings.vadThreshold),
    WHISPER_PY_MIN_SILENCE_MS: String(settings.minSilenceMs),
    WHISPER_PY_LOG_PROB_THRESHOLD: String(settings.logProbThreshold),
    WHISPER_PY_NO_SPEECH_THRESHOLD: String(settings.noSpeechThreshold),
    WHISPER_PY_COMPRESSION_RATIO_THRESHOLD: String(settings.compressionRatioThreshold),
    WHISPER_PY_CONDITION_ON_PREVIOUS_TEXT: String(settings.conditionOnPreviousText),
  };
  if (modelChanged) env.WHISPER_PY_MODEL_PATH = `models/faster-whisper-${modelSize}`;
  return { settings, modelChanged, restartRequired: modelChanged, env };
}

function readCurrentTranscriptionSettings(env = process.env) {
  return {
    modelSize: env.WHISPER_PY_MODEL || 'small',
    device: env.WHISPER_PY_DEVICE || 'cpu',
    computeType: env.WHISPER_PY_COMPUTE_TYPE || 'int8',
    beamSize: env.WHISPER_PY_BEAM_SIZE || 5,
    vad: env.WHISPER_PY_VAD ?? 'true',
    vadThreshold: env.WHISPER_PY_VAD_THRESHOLD || 0.5,
    minSilenceMs: env.WHISPER_PY_MIN_SILENCE_MS || 450,
    logProbThreshold: env.WHISPER_PY_LOG_PROB_THRESHOLD || -1.0,
    noSpeechThreshold: env.WHISPER_PY_NO_SPEECH_THRESHOLD || 0.6,
    compressionRatioThreshold: env.WHISPER_PY_COMPRESSION_RATIO_THRESHOLD || 2.4,
    conditionOnPreviousText: env.WHISPER_PY_CONDITION_ON_PREVIOUS_TEXT ?? 'false',
  };
}

module.exports = { validateTranscriptionSettings, readCurrentTranscriptionSettings, MODEL_SIZES, DEVICES, COMPUTE_TYPES };
