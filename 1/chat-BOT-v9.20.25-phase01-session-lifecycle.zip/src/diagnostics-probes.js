'use strict';

// Short-lived local filesystem probes for the diagnostics endpoint.
// The report exposes booleans only: never paths, filenames, contents or raw errors.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

function probeDirectory(directory, fsImpl = fs) {
  const result = { exists: false, isDirectory: false, readable: false, writable: false };
  if (typeof directory !== 'string' || !directory.trim()) return result;

  let stat;
  try { stat = fsImpl.statSync(directory); }
  catch { return result; }
  if (!stat || typeof stat.isDirectory !== 'function' || !stat.isDirectory()) return result;

  result.exists = true;
  result.isDirectory = true;
  let directoryReadable = false;
  try {
    fsImpl.readdirSync(directory);
    directoryReadable = true;
  } catch {
    directoryReadable = false;
  }

  let filename = '';
  let writeDescriptor = null;
  let readDescriptor = null;
  let created = false;
  let writeCompleted = false;
  let readBackCompleted = false;
  let cleanupCompleted = true;
  const payload = Buffer.from('chatbot-diagnostic-probe-v2', 'utf8');

  try {
    filename = path.join(directory, `.chatbot-diagnostic-${process.pid}-${crypto.randomBytes(8).toString('hex')}.tmp`);
    writeDescriptor = fsImpl.openSync(filename, 'wx', 0o600);
    created = true;
    let writeOffset = 0;
    while (writeOffset < payload.length) {
      const written = fsImpl.writeSync(writeDescriptor, payload, writeOffset, payload.length - writeOffset, writeOffset);
      if (!Number.isInteger(written) || written <= 0) break;
      writeOffset += written;
    }
    if (writeOffset !== payload.length) throw new Error('incomplete diagnostic write');
    fsImpl.closeSync(writeDescriptor);
    writeDescriptor = null;
    writeCompleted = true;

    // Re-open independently: a successful write alone does not prove that the
    // file can be read back or that the stored bytes match what was written.
    readDescriptor = fsImpl.openSync(filename, 'r');
    const readBuffer = Buffer.alloc(payload.length);
    let readOffset = 0;
    while (readOffset < readBuffer.length) {
      const readLength = fsImpl.readSync(readDescriptor, readBuffer, readOffset, readBuffer.length - readOffset, readOffset);
      if (!Number.isInteger(readLength) || readLength <= 0) break;
      readOffset += readLength;
    }
    if (readOffset !== payload.length || !readBuffer.equals(payload)) {
      throw new Error('diagnostic read-back mismatch');
    }
    fsImpl.closeSync(readDescriptor);
    readDescriptor = null;
    readBackCompleted = true;
  } catch {
    // Keep the public result sanitized; the raw filesystem error stays local.
  } finally {
    if (writeDescriptor !== null) {
      try { fsImpl.closeSync(writeDescriptor); } catch {}
    }
    if (readDescriptor !== null) {
      try { fsImpl.closeSync(readDescriptor); } catch {}
    }
    if (created) {
      try { fsImpl.unlinkSync(filename); }
      catch { cleanupCompleted = false; }
    }
  }

  // Readability means directory enumeration plus verified file read-back when
  // a probe file could be created. A write-denied directory can still be read.
  result.readable = directoryReadable && (!writeCompleted || readBackCompleted);
  result.writable = writeCompleted && cleanupCompleted;
  return result;
}

module.exports = { probeDirectory };
