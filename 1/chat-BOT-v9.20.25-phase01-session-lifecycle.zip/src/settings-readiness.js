'use strict';

function parseBoolean(value, fallback = false) {
  if (typeof value === 'boolean') return value;
  if (value === 1 || value === '1' || value === 'true' || value === 'yes') return true;
  if (value === 0 || value === '0' || value === 'false' || value === 'no') return false;
  return fallback;
}

function modelInstalled(status, model) {
  const requested = String(model || '').trim();
  if (!requested || !status?.available) return false;
  return (Array.isArray(status.models) ? status.models : []).some(name => {
    const actual = String(name || '').trim();
    return actual === requested || actual.split(':')[0] === requested.split(':')[0];
  });
}

/**
 * Apply runtime-dependent settings honestly. Ordinary preferences are still
 * persisted when an optional engine is unavailable, but a feature that would
 * otherwise be marked as actively working is disabled until its dependency is
 * ready. Never turns on local AI based on a UI checkbox alone.
 */
async function validateRuntimeSettings({ settings, body, localLlm, audioTranscriber }) {
  const warnings = [];
  const requestedModel = String(body.smartReplyModel || settings.smartReplyModel || 'qwen3.5:4b').trim();

  if (body.smartReplyEnabled !== undefined) {
    const requested = parseBoolean(body.smartReplyEnabled, settings.smartReplyEnabled === true);
    if (!requested) {
      settings.smartReplyEnabled = false;
    } else {
      let status = { available: false, models: [], message: 'محرك Ollama غير مربوط بالخادم.' };
      try { if (localLlm && typeof localLlm.status === 'function') status = await localLlm.status(); }
      catch { status = { available: false, models: [], message: 'تعذر فحص خدمة Ollama المحلية.' }; }
      if (!status.available) {
        settings.smartReplyEnabled = false;
        warnings.push(`لم يتم تفعيل الذكاء المحلي: ${status.message || 'Ollama غير متاح.'}`);
      } else if (!modelInstalled(status, requestedModel)) {
        settings.smartReplyEnabled = false;
        warnings.push(`Ollama يعمل لكن النموذج «${requestedModel}» غير مثبت؛ لم يتم تفعيل الرد الذكي. ثبّت النموذج محليًا ثم أعد الحفظ.`);
      } else {
        settings.smartReplyEnabled = true;
      }
    }
  }

  const wantsVoice = (body.voiceAutoTranscribeEnabled !== undefined && parseBoolean(body.voiceAutoTranscribeEnabled, false))
    || (body.voiceAutoTranscribeSelfChat !== undefined && parseBoolean(body.voiceAutoTranscribeSelfChat, false));
  if (wantsVoice) {
    let status = { ready: false, message: 'محرك Whisper غير مربوط بالخادم.' };
    try { if (audioTranscriber && typeof audioTranscriber.status === 'function') status = await audioTranscriber.status(); }
    catch { status = { ready: false, message: 'تعذر فحص محرك التفريغ الصوتي.' }; }
    if (!status.ready) warnings.push(`تم حفظ اختيار الصوتيات، لكن التفريغ لن يعمل قبل تجهيز Whisper والنموذج المحلي: ${status.message || 'المحرك غير جاهز.'}`);
  }

  return warnings;
}

module.exports = { validateRuntimeSettings, modelInstalled, parseBoolean };
