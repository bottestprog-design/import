'use strict';

const crypto = require('node:crypto');
const { spawn: defaultSpawn } = require('node:child_process');
const readline = require('node:readline');

class AudarRuntime {
  constructor({ python, worker, modelDir, voiceDir, cacheDir, codecDir = '', modelFile = '', tier = 'turbo', gpuLayers = 0, defaultVoice = 'demo_male_1', cwd = process.cwd(), spawnImpl = defaultSpawn, startupTimeoutMs = 20 * 60 * 1000, logger = () => {} } = {}) {
    this.python = python; this.worker = worker; this.modelDir = modelDir; this.voiceDir = voiceDir; this.cacheDir = cacheDir; this.codecDir = codecDir; this.modelFile = modelFile;
    this.tier = ['turbo', 'flash'].includes(String(tier)) ? String(tier) : 'turbo';
    this.gpuLayers = Math.max(-1, Math.min(999, Number(gpuLayers) || 0));
    this.defaultVoice = String(defaultVoice || 'demo_male_1'); this.cwd = cwd; this.spawn = spawnImpl; this.log = logger;
    this.startupTimeoutMs = Math.max(60_000, Math.min(45 * 60 * 1000, Number(startupTimeoutMs) || 20 * 60 * 1000));
    this.child = null; this.rl = null; this.startPromise = null; this.pending = new Map(); this.stderr = ''; this.readyInfo = null;
  }

  async ensureStarted() {
    if (this.child && this.readyInfo && !this.child.killed && this.child.exitCode == null) return this.readyInfo;
    if (this.startPromise) return this.startPromise;
    if (!this.python || !this.worker || !this.modelDir || !this.voiceDir) throw new Error('إعدادات تشغيل Audar غير مكتملة.');
    this.startPromise = new Promise((resolve, reject) => {
      let settled = false, timer;
      const finish = (error, value) => { if (settled) return; settled = true; if (timer) clearTimeout(timer); error ? reject(error) : resolve(value); };
      let child;
      try {
        child = this.spawn(this.python, [this.worker, 'serve', this.modelDir, this.voiceDir, this.cacheDir, this.tier, 'true', String(this.gpuLayers), this.defaultVoice], {
          cwd: this.cwd, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'],
          env: { ...process.env, HF_HOME: this.cacheDir, AUDAR_TTS_CODEC_DIR: this.codecDir || process.env.AUDAR_TTS_CODEC_DIR || '', AUDAR_TTS_MODEL_FILE: this.modelFile || process.env.AUDAR_TTS_MODEL_FILE || '', HF_HUB_DISABLE_TELEMETRY: '1', PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8', TOKENIZERS_PARALLELISM: 'false' },
        });
      } catch (error) { finish(new Error(`تعذر بدء Audar المحلي: ${String(error?.message || error).slice(0, 250)}`)); return; }
      this.child = child; this.readyInfo = null; this.stderr = '';
      this.rl = readline.createInterface({ input: child.stdout });
      this.rl.on('line', line => this.handleLine(line, finish));
      child.stderr?.on('data', chunk => { this.stderr = (this.stderr + String(chunk)).slice(-10000); });
      child.once('error', error => { finish(new Error(`تعطل عامل Audar: ${String(error?.message || error).slice(0, 250)}`)); this.failAll(error); });
      child.once('close', code => {
        const error = new Error(`توقف عامل Audar (رمز ${code ?? 'غير معروف'}). ${this.stderr.trim().slice(-900)}`.slice(0, 1300));
        finish(error); this.failAll(error); this.resetChild();
      });
      timer = setTimeout(() => {
        const error = new Error('انتهت مهلة تحميل Audar أو اختبار التوليد العربي. تحقق من الذاكرة المتاحة أو اختر Flash بدل Turbo.');
        try { child.kill(); } catch {} finish(error); this.failAll(error);
      }, this.startupTimeoutMs);
      timer.unref?.();
    }).finally(() => { this.startPromise = null; });
    return this.startPromise;
  }

  handleLine(line, finishStart) {
    let message;
    try { message = JSON.parse(String(line || '')); }
    catch { this.log('WARN', `[AUDAR] سطر عامل غير صالح: ${String(line).slice(0, 160)}`); return; }
    if (message.event === 'ready' || (message.ok === false && !this.readyInfo)) {
      if (message.ok !== true || message.smokeTest !== true) { finishStart(new Error(String(message.error || 'لم يجتز Audar اختبار التوليد العربي الفعلي.'))); return; }
      this.readyInfo = message; finishStart(null, message); return;
    }
    const id = String(message.requestId || ''), pending = this.pending.get(id);
    if (!pending) return;
    clearTimeout(pending.timer); this.pending.delete(id);
    if (message.ok !== true) pending.reject(new Error(String(message.error || 'فشل توليد الصوت عبر Audar.').slice(0, 700)));
    else pending.resolve(message);
  }

  async generate({ text, outputPath, voice = this.defaultVoice, timeoutMs = 360000, maxNewTokens = 1500, temperature = 1.0, topK = 40, topP = 0.90 } = {}) {
    await this.ensureStarted();
    if (!this.child || !this.readyInfo) throw new Error('محرك Audar المحلي لم يصبح جاهزًا بعد.');
    const requestId = crypto.randomUUID();
    const timeout = Math.max(30_000, Math.min(20 * 60 * 1000, Number(timeoutMs) || 360000));
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(requestId);
        reject(new Error('انتهت مهلة توليد الرد الصوتي عبر Audar.'));
      }, timeout);
      timer.unref?.();
      this.pending.set(requestId, { resolve, reject, timer });
      const payload = JSON.stringify({ requestId, text, outputPath, voice, maxNewTokens, temperature, topK, topP });
      this.child.stdin.write(`${payload}\n`, error => {
        if (!error) return;
        const item = this.pending.get(requestId);
        if (!item) return;
        clearTimeout(item.timer); this.pending.delete(requestId);
        item.reject(new Error(`تعذر إرسال طلب التوليد إلى Audar: ${String(error.message || error).slice(0, 200)}`));
      });
    });
  }

  failAll(error) {
    for (const [id, item] of this.pending) { clearTimeout(item.timer); item.reject(error instanceof Error ? error : new Error(String(error || 'توقف Audar.'))); this.pending.delete(id); }
  }
  resetChild() { try { this.rl?.close(); } catch {} this.rl = null; this.child = null; this.readyInfo = null; }
  shutdown() { const child = this.child; this.failAll(new Error('تم إيقاف Audar مع إغلاق البوت.')); this.resetChild(); try { child?.kill(); } catch {} return true; }
}

module.exports = { AudarRuntime };
