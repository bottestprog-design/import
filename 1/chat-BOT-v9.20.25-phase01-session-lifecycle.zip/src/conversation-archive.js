'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const MAX_RECORDS_PER_SESSION = 100000;
const MAX_ARCHIVE_BYTES = 80 * 1024 * 1024;
const MAX_BODY_CHARS = 20000;

function timestampMs(value) {
  const number = Number(value || 0);
  if (!Number.isFinite(number) || number <= 0) return Date.now();
  return number < 100000000000 ? Math.trunc(number * 1000) : Math.trunc(number);
}
function messageId(value, chatId, timestamp, body, fromMe) {
  const explicit = String((typeof value === 'string' || typeof value === 'number') ? value : (value?.serialized || value?._serialized || value?.id?._serialized || value?.id?.id || value?.id || '')).trim();
  if (explicit && explicit !== '[object Object]') return explicit.slice(0, 300);
  return crypto.createHash('sha256').update([chatId, timestamp, fromMe ? '1' : '0', body].join('|')).digest('hex').slice(0, 40);
}
function sanitizeRecord(record = {}) {
  const chatId = String(record.chatId || '').trim().toLowerCase();
  const targetKey = String(record.targetKey || '').trim().slice(0, 160);
  const body = String(record.body || record.caption || '').replace(/\u0000/g, '').slice(0, MAX_BODY_CHARS);
  const time = timestampMs(record.timestampMs ?? record.timestamp ?? record.at);
  const fromMe = record.fromMe === true;
  const id = messageId(record.messageId || record.id, chatId, time, body, fromMe);
  if (!chatId || !targetKey || !id) return null;
  return {
    id, messageId: id, targetKey, chatId,
    timestampMs: time, at: new Date(time).toISOString(), fromMe,
    type: String(record.type || (record.hasMedia ? 'media' : 'chat')).toLowerCase().slice(0, 32),
    body, caption: String(record.caption || '').slice(0, 2048),
    hasMedia: record.hasMedia === true,
    mimetype: String(record.mimetype || '').slice(0, 140),
    filename: path.basename(String(record.filename || '')).slice(0, 220),
    senderName: String(record.senderName || '').slice(0, 160),
    ack: Number.isFinite(Number(record.ack)) ? Number(record.ack) : null,
  };
}
function normalizeSearch(value) {
  return String(value || '').normalize('NFKC').toLocaleLowerCase('ar')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[إأآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/\s+/g, ' ').trim();
}

class ConversationArchive {
  constructor({ store, maxRecords = MAX_RECORDS_PER_SESSION, maxArchiveBytes = MAX_ARCHIVE_BYTES } = {}) {
    if (!store) throw new Error('ConversationArchive يحتاج إلى مخزن الجلسات.');
    this.store = store;
    this.maxRecords = Math.max(1000, Math.min(MAX_RECORDS_PER_SESSION, Number(maxRecords) || MAX_RECORDS_PER_SESSION));
    this.maxArchiveBytes = Math.max(1024 * 1024, Math.min(MAX_ARCHIVE_BYTES, Number(maxArchiveBytes) || MAX_ARCHIVE_BYTES));
    this.sessions = new Map();
  }
  filePath(sessionId) { return path.join(this.store.getPaths(sessionId).dir, 'conversations.jsonl'); }
  load(sessionId) {
    const sid = this.store.safeSessionId(sessionId);
    if (this.sessions.has(sid)) return this.sessions.get(sid);
    const file = this.filePath(sid), byTarget = new Map(), seen = new Set();
    let records = [];
    try {
      if (fs.existsSync(file)) {
        const stat = fs.statSync(file);
        if (stat.size > this.maxArchiveBytes) {
          // Read only the tail after a corrupt/old oversized archive; never allocate an unbounded file.
          const fd = fs.openSync(file, 'r');
          try {
            const readSize = this.maxArchiveBytes;
            const buffer = Buffer.alloc(readSize);
            fs.readSync(fd, buffer, 0, readSize, stat.size - readSize);
            const text = buffer.toString('utf8');
            records = text.slice(text.indexOf('\n') + 1).split(/\r?\n/).filter(Boolean).slice(-this.maxRecords).map(line => { try { return sanitizeRecord(JSON.parse(line)); } catch { return null; } }).filter(Boolean);
          } finally { fs.closeSync(fd); }
        } else {
          records = fs.readFileSync(file, 'utf8').split(/\r?\n/).filter(Boolean).slice(-this.maxRecords).map(line => { try { return sanitizeRecord(JSON.parse(line)); } catch { return null; } }).filter(Boolean);
        }
      }
    } catch { records = []; }
    for (const row of records) {
      const key = `${row.chatId}|${row.messageId}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const list = byTarget.get(row.targetKey) || [];
      list.push(row); byTarget.set(row.targetKey, list);
    }
    const context = { file, byTarget, seen, count: [...byTarget.values()].reduce((n, list) => n + list.length, 0), appendedSinceCompact: 0 };
    this.sessions.set(sid, context);
    return context;
  }
  record(sessionId, raw) {
    const sid = this.store.safeSessionId(sessionId), context = this.load(sid), row = sanitizeRecord(raw);
    if (!row) return { stored: false, reason: 'invalid-record' };
    const key = `${row.chatId}|${row.messageId}`;
    if (context.seen.has(key)) return { stored: false, reason: 'duplicate' };
    fs.mkdirSync(path.dirname(context.file), { recursive: true });
    const serialized = JSON.stringify(row) + '\n';
    try {
      const nextSize = (fs.existsSync(context.file) ? fs.statSync(context.file).size : 0) + Buffer.byteLength(serialized);
      if (nextSize > this.maxArchiveBytes) this.compact(sid);
      fs.appendFileSync(context.file, serialized, { encoding: 'utf8', mode: 0o600 });
    } catch (error) { return { stored: false, reason: 'write-error', error: String(error?.message || error).slice(0, 180) }; }
    context.seen.add(key);
    const list = context.byTarget.get(row.targetKey) || [];
    list.push(row); context.byTarget.set(row.targetKey, list); context.count++;
    context.appendedSinceCompact++;
    if (context.count > this.maxRecords || context.appendedSinceCompact >= 1000 || fs.statSync(context.file).size > this.maxArchiveBytes) this.compact(sid);
    return { stored: true, record: row };
  }
  recordMany(sessionId, rows) {
    const sid = this.store.safeSessionId(sessionId), context = this.load(sid);
    const input = Array.isArray(rows) ? rows : [];
    const batchSeen = new Set(), accepted = [];
    let duplicates = 0, invalid = 0;
    for (const raw of input) {
      const row = sanitizeRecord(raw);
      if (!row) { invalid++; continue; }
      const key = `${row.chatId}|${row.messageId}`;
      if (context.seen.has(key) || batchSeen.has(key)) { duplicates++; continue; }
      batchSeen.add(key); accepted.push(row);
    }
    if (!accepted.length) return { received: input.length, stored: 0, duplicates, failed: invalid, invalid };

    // Batch imports rewrite once instead of doing thousands of synchronous appends
    // and repeatedly compacting the archive. Select newest rows within both hard caps.
    const combined = [...context.byTarget.values()].flat().concat(accepted)
      .sort((a, b) => a.timestampMs - b.timestampMs);
    const pickedNewestFirst = [];
    let bytes = 0;
    for (let i = combined.length - 1; i >= 0 && pickedNewestFirst.length < this.maxRecords; i--) {
      const row = combined[i], line = `${JSON.stringify(row)}\n`, size = Buffer.byteLength(line);
      if (bytes + size > this.maxArchiveBytes) break;
      pickedNewestFirst.push(row); bytes += size;
    }
    const kept = pickedNewestFirst.reverse();
    const temp = `${context.file}.${process.pid}.batch.tmp`;
    try {
      fs.mkdirSync(path.dirname(context.file), { recursive: true });
      fs.writeFileSync(temp, kept.map(row => JSON.stringify(row)).join('\n') + (kept.length ? '\n' : ''), { encoding: 'utf8', mode: 0o600 });
      fs.renameSync(temp, context.file);
    } catch (error) {
      try { fs.rmSync(temp, { force: true }); } catch {}
      return { received: input.length, stored: 0, duplicates, failed: invalid + accepted.length, invalid, error: String(error?.message || error).slice(0, 180) };
    }
    context.byTarget = new Map(); context.seen = new Set(); context.count = 0; context.appendedSinceCompact = 0;
    for (const row of kept) {
      const key = `${row.chatId}|${row.messageId}`;
      context.seen.add(key);
      const list = context.byTarget.get(row.targetKey) || [];
      list.push(row); context.byTarget.set(row.targetKey, list); context.count++;
    }
    const keptKeys = context.seen;
    const stored = accepted.filter(row => keptKeys.has(`${row.chatId}|${row.messageId}`)).length;
    const evicted = accepted.length - stored;
    return { received: input.length, stored, duplicates, failed: invalid + evicted, invalid, skippedByArchiveLimit: evicted, archiveCount: context.count };
  }
  compact(sessionId) {
    const sid = this.store.safeSessionId(sessionId), context = this.load(sid);
    const allRows = [...context.byTarget.values()].flat().sort((a, b) => a.timestampMs - b.timestampMs);
    const newestFirst = []; let totalBytes = 0;
    for (let i = allRows.length - 1; i >= 0 && newestFirst.length < this.maxRecords; i--) {
      const row = allRows[i], size = Buffer.byteLength(`${JSON.stringify(row)}\n`);
      if (totalBytes + size > this.maxArchiveBytes) break;
      newestFirst.push(row); totalBytes += size;
    }
    const rows = newestFirst.reverse();
    const temp = `${context.file}.${process.pid}.tmp`;
    try {
      fs.writeFileSync(temp, rows.map(row => JSON.stringify(row)).join('\n') + (rows.length ? '\n' : ''), { encoding: 'utf8', mode: 0o600 });
      fs.renameSync(temp, context.file);
      context.byTarget = new Map(); context.seen = new Set(); context.count = rows.length; context.appendedSinceCompact = 0;
      for (const row of rows) {
        context.seen.add(`${row.chatId}|${row.messageId}`);
        const list = context.byTarget.get(row.targetKey) || []; list.push(row); context.byTarget.set(row.targetKey, list);
      }
      return rows.length;
    } catch (error) { try { fs.rmSync(temp, { force: true }); } catch {} throw error; }
  }
  list(sessionId, targetKey, { limit = 100, before = null, cursor = null, query = '' } = {}) {
    const context = this.load(sessionId), max = Math.max(1, Math.min(500, Number(limit) || 100));
    // WhatsApp timestamps are frequently second-granular, so multiple messages
    // may share the same timestamp. A compound cursor prevents page-boundary loss.
    let cutoff = Infinity, cutoffId = '';
    const suppliedCursor = cursor || (typeof before === 'string' && before.startsWith('c:') ? before : null);
    if (suppliedCursor) {
      try {
        const decoded = JSON.parse(Buffer.from(String(suppliedCursor).slice(2), 'base64url').toString('utf8'));
        const time = Number(decoded?.t), id = String(decoded?.id || '');
        if (Number.isFinite(time) && time > 0 && id && id.length <= 300) { cutoff = time; cutoffId = id; }
      } catch { /* malformed cursor yields the newest page, never arbitrary IDs */ }
    } else if (before != null && before !== '') {
      const legacy = Number(before);
      if (Number.isFinite(legacy) && legacy > 0) cutoff = legacy;
    }
    const targetRows = context.byTarget.get(String(targetKey || '')) || [];
    const needle = normalizeSearch(query);
    const rows = targetRows.filter(row => {
      const olderThanCursor = row.timestampMs < cutoff || (Boolean(cutoffId) && row.timestampMs === cutoff && String(row.messageId).localeCompare(cutoffId) < 0);
      return olderThanCursor && (!needle || normalizeSearch(`${row.body} ${row.caption} ${row.filename} ${row.type}`).includes(needle));
    }).sort((a, b) => b.timestampMs - a.timestampMs || String(b.messageId).localeCompare(String(a.messageId)));
    const page = rows.slice(0, max).reverse();
    const first = page[0] || null;
    const nextCursor = first ? `c:${Buffer.from(JSON.stringify({ t: first.timestampMs, id: first.messageId }), 'utf8').toString('base64url')}` : null;
    return { messages: page, totalStoredForTarget: targetRows.length, hasOlder: rows.length > page.length, nextBefore: first ? first.timestampMs : null, nextCursor, oldestTimestampMs: rows.length ? rows[rows.length - 1].timestampMs : null };
  }

  search(sessionId, query, { limit = 100, targetKey = null, targetKeys = null } = {}) {
    const context = this.load(sessionId), needle = normalizeSearch(query);
    if (!needle) return [];
    const cap = Math.max(1, Math.min(500, Number(limit) || 100));
    // Filter to the selected conversation BEFORE applying the limit. Otherwise
    // a busy contact could be hidden behind another contact's newer matches.
    const sources = targetKey != null && String(targetKey) !== ''
      ? [context.byTarget.get(String(targetKey)) || []]
      : Array.isArray(targetKeys)
        ? targetKeys.map(key => context.byTarget.get(String(key)) || [])
        : [...context.byTarget.values()];
    return sources.flat().filter(row => normalizeSearch(`${row.body} ${row.caption} ${row.filename} ${row.type}`).includes(needle)).sort((a, b) => b.timestampMs - a.timestampMs).slice(0, cap);
  }
  orphanedTargets(sessionId, registeredTargetKeys) {
    const context = this.load(sessionId), registered = registeredTargetKeys instanceof Set ? registeredTargetKeys : new Set(Array.isArray(registeredTargetKeys) ? registeredTargetKeys.map(String) : []);
    const output = [];
    for (const [key, rows] of context.byTarget) {
      if (registered.has(key) || !/^[rg]:[^\s]{1,150}$/u.test(key) || !rows.length) continue;
      const chatIds = [...new Set(rows.map(row => String(row.chatId || '').toLowerCase()).filter(Boolean))];
      const latest = rows.reduce((best, row) => !best || row.timestampMs > best.timestampMs ? row : best, null);
      output.push({ targetKey: key, chatId: chatIds.length === 1 ? chatIds[0] : '', chatIds, count: rows.length,
        mediaCount: rows.filter(row => row.hasMedia).length, lastAt: latest?.at || '',
        lastText: String(latest?.body || latest?.caption || '').slice(0, 180),
        restorable: chatIds.length === 1 && /^(?:\d{5,25}@c\.us|\d{5,25}@lid|\d{5,25}(?:-\d+)*@g\.us)$/u.test(chatIds[0]) });
    }
    return output.sort((a, b) => String(b.lastAt).localeCompare(String(a.lastAt)));
  }
  relinkTarget(sessionId, fromTargetKey, toTargetKey, expectedChatId) {
    const sid = this.store.safeSessionId(sessionId), context = this.load(sid);
    const from = String(fromTargetKey || '').trim(), to = String(toTargetKey || '').trim(), expected = String(expectedChatId || '').trim().toLowerCase();
    if (!/^[rg]:[^\s]{1,150}$/u.test(from) || from === to) throw new Error('مصدر المحادثة غير صالح أو لا يحتاج إلى ربط.');
    if (!/^(?:self|r:[^\s]{1,150}|g:[^\s]{1,150})$/u.test(to)) throw new Error('الجهة الجديدة غير صالحة.');
    const sourceRows = context.byTarget.get(from) || [];
    if (!sourceRows.length) throw new Error('لا يوجد سجل محفوظ تحت مصدر المحادثة المختار.');
    const sourceIds = [...new Set(sourceRows.map(row => String(row.chatId || '').toLowerCase()))];
    if (sourceIds.length !== 1 || !expected || sourceIds[0] !== expected) throw new Error('أُوقف الربط لأن معرّف WhatsApp في السجل لا يطابق الجهة المختارة تمامًا.');
    const migrated = [...context.byTarget.values()].flat().map(row => row.targetKey === from ? { ...row, targetKey: to } : row).sort((a, b) => a.timestampMs - b.timestampMs);
    const temp = `${context.file}.${process.pid}.relink.tmp`;
    try {
      fs.mkdirSync(path.dirname(context.file), { recursive: true });
      fs.writeFileSync(temp, migrated.map(row => JSON.stringify(row)).join('\n') + (migrated.length ? '\n' : ''), { encoding: 'utf8', mode: 0o600, flag: 'wx' });
      fs.renameSync(temp, context.file);
    } catch (error) { try { fs.rmSync(temp, { force: true }); } catch {} throw new Error(`تعذر حفظ ربط المحادثة؛ لم تُستكمل العملية: ${String(error?.message || error).slice(0, 180)}`); }
    context.byTarget = new Map(); context.seen = new Set(); context.count = migrated.length; context.appendedSinceCompact = 0;
    for (const row of migrated) {
      context.seen.add(`${row.chatId}|${row.messageId}`);
      const list = context.byTarget.get(row.targetKey) || []; list.push(row); context.byTarget.set(row.targetKey, list);
    }
    return { fromTargetKey: from, toTargetKey: to, moved: sourceRows.length, chatId: expected };
  }
  summary(sessionId, targetKey) {
    const context = this.load(sessionId), targets = targetKey ? [String(targetKey)] : [...context.byTarget.keys()];
    return targets.map(key => {
      const rows = context.byTarget.get(key) || [], last = rows.reduce((best, row) => !best || row.timestampMs > best.timestampMs ? row : best, null);
      return { targetKey: key, count: rows.length, mediaCount: rows.filter(row => row.hasMedia).length, lastAt: last?.at || '', lastText: String(last?.body || last?.caption || '').slice(0, 180), lastType: last?.type || '' };
    });
  }
}

module.exports = { ConversationArchive, MAX_RECORDS_PER_SESSION, MAX_ARCHIVE_BYTES, sanitizeRecord, normalizeSearch, timestampMs };
