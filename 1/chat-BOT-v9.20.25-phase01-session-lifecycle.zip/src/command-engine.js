"use strict";
const { randomUUID } = require('node:crypto');
const DEFAULT_PREFIXES = ['!', '/'];
const MAX_COMMAND_LENGTH = 16000;
function tokenizeArgs(input) {
  const text = String(input || ''), args = [];
  let token = '', quote = '', escaped = false, started = false;
  for (const ch of text) {
    if (escaped) { token += ch; escaped = false; started = true; continue; }
    if (quote && ch === '\\') { escaped = true; started = true; continue; }
    if (quote) {
      if (ch === quote) quote = ''; else token += ch;
      started = true; continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; started = true; continue; }
    if (/\s/u.test(ch)) {
      if (started) { args.push(token); token = ''; started = false; }
      continue;
    }
    token += ch; started = true;
  }
  if (escaped || quote) return { args: [], error: 'unclosed-quote' };
  if (started) args.push(token);
  return { args, error: '' };
}
class CommandEngine {
  constructor({ prefixes = DEFAULT_PREFIXES, ownerOnlyByDefault = true, audit = () => {} } = {}) { this.prefixes = [...prefixes].filter(p => typeof p === 'string' && p.length > 0).sort((a, b) => b.length - a.length); this.ownerOnlyByDefault = ownerOnlyByDefault; this.audit = typeof audit === 'function' ? audit : () => {}; this.commands = new Map(); }
  safeAudit(event) { try { this.audit({ ...event, error: event.error ? String(event.error).slice(0, 500) : undefined }); } catch { /* Audit failures must never re-run or reverse a command. */ } }
  register(name, definition) {
    const key = String(name || '').trim().toLowerCase();
    if (!/^[\p{L}\p{N}_-]{1,48}$/u.test(key)) throw new Error('Invalid command name');
    if (typeof definition?.handler !== 'function') throw new TypeError('Command handler required');
    this.commands.set(key, { name: key, description: String(definition.description || ''), ownerOnly: definition.ownerOnly ?? this.ownerOnlyByDefault, permission: definition.permission || null, schema: definition.schema || null, handler: definition.handler, enabled: definition.enabled !== false });
    return () => this.commands.delete(key);
  }
  parse(input) {
    const text = String(input || '').trim(); if (!text || text.length > MAX_COMMAND_LENGTH) return null;
    const prefix = this.prefixes.find(p => text.startsWith(p)); if (!prefix) return null;
    const body = text.slice(prefix.length).trim(); if (!body) return null;
    const match = body.match(/^([^\s]+)(?:\s+([\s\S]*))?$/u); if (!match) return null;
    const rawArgs = match[2] || '', tokenized = tokenizeArgs(rawArgs);
    return { id: randomUUID(), prefix, name: match[1].toLocaleLowerCase(), rawArgs, args: tokenized.args, argsError: tokenized.error, input: text };
  }
  async execute(input, context = {}) {
    const parsed = typeof input === 'string' ? this.parse(input) : input;
    if (!parsed || typeof parsed.name !== 'string') return { handled: false, reason: 'not-command' };
    const cmd = this.commands.get(parsed.name);
    if (!cmd || !cmd.enabled) return { handled: false, reason: 'unknown-command', parsed };
    const actor = context.actorId || null;
    if (cmd.ownerOnly && context.isOwner !== true) { this.safeAudit({ command: parsed.name, actor, ok: false, error: 'owner-only' }); return { handled: true, ok: false, error: 'owner-only' }; }
    if (cmd.permission && context.permissions?.includes(cmd.permission) !== true) { this.safeAudit({ command: parsed.name, actor, ok: false, error: 'permission-denied' }); return { handled: true, ok: false, error: 'permission-denied' }; }
    if (parsed.argsError) { this.safeAudit({ command: parsed.name, actor, ok: false, error: 'invalid-arguments' }); return { handled: true, ok: false, error: 'invalid-arguments' }; }
    try {
      if (cmd.schema && !(await cmd.schema(parsed.args, context))) { this.safeAudit({ command: parsed.name, actor, ok: false, error: 'invalid-arguments' }); return { handled: true, ok: false, error: 'invalid-arguments' }; }
      const result = await cmd.handler({ ...context, command: parsed, args: parsed.args, rawArgs: parsed.rawArgs });
      this.safeAudit({ command: parsed.name, actor, ok: true });
      return { handled: true, ok: true, result };
    } catch (error) {
      const message = String(error?.message || error || 'command-failed').slice(0, 500);
      this.safeAudit({ command: parsed.name, actor, ok: false, error: message });
      return { handled: true, ok: false, error: message };
    }
  }
  list() { return [...this.commands.values()].map(({ handler, schema, ...x }) => x); }
}
module.exports = { CommandEngine, tokenizeArgs, MAX_COMMAND_LENGTH };
