'use strict';
function normalizeForComparison(value) {
  return String(value || '').normalize('NFKD').toLocaleLowerCase()
    .replace(/\p{M}/gu, '')
    .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي')
    .replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}
function scoreTranscript(expected, actual) {
  const wanted = normalizeForComparison(expected).split(/\s+/u).filter(Boolean);
  const got = normalizeForComparison(actual).split(/\s+/u).filter(Boolean);
  if (!wanted.length || !got.length) return { expectedWords: wanted.length, recognizedWords: got.length, matchedWords: 0, recall: 0, precision: 0, score: 0 };
  const remaining = new Map();
  for (const word of got) remaining.set(word, (remaining.get(word) || 0) + 1);
  let matched = 0;
  for (const word of wanted) {
    const count = remaining.get(word) || 0;
    if (count > 0) { matched++; remaining.set(word, count - 1); }
  }
  const recall = matched / wanted.length;
  const precision = matched / got.length;
  const score = (recall + precision) ? 2 * recall * precision / (recall + precision) : 0;
  return { expectedWords: wanted.length, recognizedWords: got.length, matchedWords: matched, recall: Number(recall.toFixed(3)), precision: Number(precision.toFixed(3)), score: Number(score.toFixed(3)) };
}
module.exports = { normalizeForComparison, scoreTranscript };
