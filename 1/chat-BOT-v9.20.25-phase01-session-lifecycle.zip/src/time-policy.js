'use strict';

function parseClock(value) {
  const match = String(value ?? '').match(/^(\d{2}):(\d{2})$/);
  if (!match) return null;
  const hour = Number(match[1]), minute = Number(match[2]);
  return hour < 24 && minute < 60 ? hour * 60 + minute : null;
}

function validTimeZone(value, fallback = 'Asia/Muscat') {
  const requested = String(value || '').trim() || fallback;
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: requested }).format(new Date(0));
    return requested;
  } catch {
    try {
      new Intl.DateTimeFormat('en-US', { timeZone: fallback }).format(new Date(0));
      return fallback;
    } catch {
      return 'UTC';
    }
  }
}

function isQuietHours(settings = {}, now = new Date()) {
  if (settings?.interactionQuietEnabled !== true) return false;
  const start = parseClock(settings.interactionQuietStart);
  const end = parseClock(settings.interactionQuietEnd);
  // Equal or malformed bounds are treated as disabled, never as an all-day lock.
  if (start == null || end == null || start === end) return false;
  let parts;
  try {
    parts = new Intl.DateTimeFormat('en-GB', {
      timeZone: validTimeZone(settings.timezone),
      hour: '2-digit',
      minute: '2-digit',
      hourCycle: 'h23',
    }).formatToParts(now);
  } catch {
    return false;
  }
  const hour = Number(parts.find(item => item.type === 'hour')?.value);
  const minute = Number(parts.find(item => item.type === 'minute')?.value);
  if (!Number.isInteger(hour) || !Number.isInteger(minute)) return false;
  const current = hour * 60 + minute;
  return start < end ? current >= start && current < end : current >= start || current < end;
}

function quietAction(settings = {}) {
  return ['silence', 'reply', 'rules'].includes(settings.interactionQuietAction)
    ? settings.interactionQuietAction
    : 'silence';
}

function automationAllowedDuringQuiet(settings = {}, now = new Date()) {
  return !isQuietHours(settings, now) || quietAction(settings) === 'rules';
}

module.exports = { parseClock, validTimeZone, isQuietHours, quietAction, automationAllowedDuringQuiet };
