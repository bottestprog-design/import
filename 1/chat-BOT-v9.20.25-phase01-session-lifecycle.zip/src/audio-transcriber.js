'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFile: nodeExecFile } = require('node:child_process');
const { promisify } = require('node:util');
const { evaluateTranscriptQuality, summarizeQuality } = require('./transcript-quality');
const execFileDefault = promisify(nodeExecFile);
const MAX_AUDIO_BYTES = 25 * 1024 * 1024;
const AUDIO_EXTENSIONS = new Set(['.ogg', '.opus', '.mp3', '.m4a', '.mp4', '.wav', '.webm', '.aac', '.flac']);
const MIME_EXT = { 'audio/ogg': '.ogg', 'audio/opus': '.opus', 'audio/mpeg': '.mp3', 'audio/mp3': '.mp3', 'audio/mp4': '.m4a', 'audio/x-m4a': '.m4a', 'audio/wav': '.wav', 'audio/x-wav': '.wav', 'audio/webm': '.webm', 'audio/aac': '.aac', 'audio/flac': '.flac' };
const langNames = { ar: 'Arabic', en: 'English', fr: 'French', de: 'German', es: 'Spanish', ur: 'Urdu', hi: 'Hindi', tr: 'Turkish' };
const execErrorText = error => String(error?.message || error || 'خطأ تشغيل غير معروف').replace(/https?:\/\/\S+/gi, '[رابط خدمة]').replace(/(?:[A-Za-z]:\\(?:[^\\\s]+\\)*[^\s,;]*)/g, '[مسار محلي]').replace(/(?:\/[^\s,;]+){2,}/g, '[مسار محلي]').slice(0, 240);

function allowedLanguage(value) {
  const raw = String(value || 'auto').toLowerCase().trim();
  const lang = ['auto', 'detect', 'automatic'].includes(raw) ? 'auto' : raw;
  if (lang !== 'auto' && !Object.prototype.hasOwnProperty.call(langNames, lang)) throw new Error('لغة التفريغ غير مدعومة. اختر التلقائي أو العربية أو الإنجليزية أو الفرنسية أو الألمانية أو إحدى اللغات الموجودة في القائمة.');
  return lang;
}
function safeAudioExtension(name, mimetype = '') {
  const fromName = path.extname(String(name || '')).toLowerCase();
  if (AUDIO_EXTENSIONS.has(fromName)) return fromName;
  const mime = String(mimetype || '').split(';')[0].trim().toLowerCase();
  return MIME_EXT[mime] || '';
}
function loopbackSafeEnvPath(value, fallback) { return String(value || fallback).trim() || fallback; }

class AudioTranscriber {
  constructor({ env = process.env, execFileImpl = execFileDefault, fetchImpl = globalThis.fetch, logger = () => {}, tempDir = os.tmpdir(), maxAudioBytes = MAX_AUDIO_BYTES } = {}) {
    this.env = env;
    this.execFile = execFileImpl;
    this.fetch = fetchImpl;
    this.log = logger;
    this.tempDir = tempDir;
    this.maxAudioBytes = Math.max(1024 * 1024, Math.min(50 * 1024 * 1024, Number(maxAudioBytes) || MAX_AUDIO_BYTES));
    this.latestBySession = new Map();
    // Whisper loads large models; serialize local inference by default to avoid
    // simultaneous model loads exhausting RAM/VRAM when several voice notes arrive.
    this.transcriptionQueue = Promise.resolve();
    this.pendingTranscriptions = 0;
    this.maxPendingTranscriptions = Math.max(1, Math.min(32, Number(this.env.WHISPER_MAX_PENDING) || 8));
    this.messageTranscriptions = new Map();
  }
  withQuality(result, requestedLanguage = 'auto') {
    const normalized = { ...result, requestedLanguage: result.requestedLanguage || requestedLanguage };
    normalized.quality = evaluateTranscriptQuality(normalized, { requestedLanguage });
    normalized.quality.summary = summarizeQuality(normalized.quality);
    return normalized;
  }
  config() {
    const backend = String(this.env.WHISPER_BACKEND || 'python-faster-whisper').trim().toLowerCase();
    const root = path.resolve(__dirname, '..');
    const platformExe = process.platform === 'win32' ? '.exe' : '';
    const resolveConfigured = value => {
      const text = String(value || '').trim();
      if (!text) return '';
      return path.isAbsolute(text) ? text : path.resolve(root, text);
    };
    const resolveCommand = value => {
      const text = String(value || '').trim();
      if (!text) return '';
      if (path.isAbsolute(text) || text.includes('/') || text.includes('\\')) return path.isAbsolute(text) ? text : path.resolve(root, text);
      return text; // bare executable names are searched on PATH
    };
    const firstExisting = candidates => candidates.find(candidate => {
      try { return fs.existsSync(candidate) && fs.statSync(candidate).isFile(); } catch { return false; }
    }) || '';
    const localBinaries = [
      path.join(root, 'tools', 'whisper', `whisper-cli${platformExe}`),
      path.join(root, 'tools', 'whisper', 'bin', `whisper-cli${platformExe}`),
      path.join(root, 'whisper.cpp', 'build', 'bin', `whisper-cli${platformExe}`),
      path.join(root, 'build', 'bin', `whisper-cli${platformExe}`),
      path.join(root, 'tools', 'whisper', `main${platformExe}`),
    ];
    const configuredBinaryText = String(this.env.WHISPER_CPP_BIN || '').trim();
    let binary = resolveCommand(configuredBinaryText);
    const knownBareExecutables = ['whisper-cli', 'whisper', 'whisper-cli.exe', 'main', 'main.exe'];
    // A stale absolute/relative path from a previous setup must not hide a valid
    // executable installed under this project. If none exists, retain the configured
    // path so status() can report the missing executable clearly.
    if (!binary) {
      binary = firstExisting(localBinaries) || (backend === 'whisper' ? 'whisper' : `whisper-cli${platformExe}`);
    } else if (knownBareExecutables.includes(configuredBinaryText.toLowerCase())) {
      binary = firstExisting(localBinaries) || binary;
    } else if ((path.isAbsolute(binary) || /[\\/]/.test(binary)) && !fs.existsSync(binary)) {
      binary = firstExisting(localBinaries) || binary;
    }
    const configuredModelCandidate = resolveConfigured(this.env.WHISPER_MODEL_PATH);
    const configuredModel = configuredModelCandidate && fs.existsSync(configuredModelCandidate) && fs.statSync(configuredModelCandidate).isFile() ? configuredModelCandidate : '';
    const modelCandidates = [
      path.join(root, 'models', 'ggml-large-v3-turbo.bin'),
      path.join(root, 'models', 'ggml-small.bin'),
      path.join(root, 'models', 'ggml-base.bin'),
      path.join(root, 'tools', 'whisper', 'models', 'ggml-base.bin'),
    ];
    const modelPath = configuredModel || firstExisting(modelCandidates) || path.join(root, 'models', 'ggml-small.bin');
    const voiceWorker = path.join(root, 'scripts', 'voice_worker.py');
    const localPython = process.platform === 'win32' ? path.join(root, '.voice-venv', 'Scripts', 'python.exe') : path.join(root, '.voice-venv', 'bin', 'python');
    const rawPython = String(this.env.VOICE_PYTHON_BIN || '').trim();
    const configuredPython = rawPython ? resolveCommand(rawPython) : '';
    const configuredPythonIsStale = Boolean(configuredPython && (path.isAbsolute(configuredPython) || /[\\/]/.test(configuredPython)) && !fs.existsSync(configuredPython));
    // A stale .env path from an older manual setup must not hide the bundled project venv.
    const pythonBinary = (!configuredPythonIsStale && configuredPython) ? configuredPython : (fs.existsSync(localPython) ? localPython : (process.platform === 'win32' ? 'python' : 'python3'));
    const configuredWhisperSize = String(this.env.WHISPER_PY_MODEL || 'small').trim().toLowerCase();
    const supportedWhisperSizes = new Set(['tiny', 'base', 'small', 'medium', 'large-v3', 'large-v3-turbo']);
    const pyModelSize = supportedWhisperSizes.has(configuredWhisperSize) ? configuredWhisperSize : 'small';
    const defaultWhisperPath = path.join('models', `faster-whisper-${pyModelSize}`);
    const pyModelCandidate = resolveConfigured(this.env.WHISPER_PY_MODEL_PATH || defaultWhisperPath);
    const pyModelPath = pyModelCandidate || path.join(root, 'models', `faster-whisper-${pyModelSize}`);
    const configuredFfmpegCandidate = resolveConfigured(this.env.FFMPEG_BIN);
    const configuredFfmpeg = configuredFfmpegCandidate && fs.existsSync(configuredFfmpegCandidate) && fs.statSync(configuredFfmpegCandidate).isFile() ? configuredFfmpegCandidate : '';
    const localFfmpeg = firstExisting([
      path.join(root, 'tools', 'ffmpeg', 'bin', `ffmpeg${platformExe}`),
      path.join(root, 'tools', 'ffmpeg', `ffmpeg${platformExe}`),
    ]);
    const rawFfmpeg = String(this.env.FFMPEG_BIN || '').trim();
    const ffmpegBinary = (configuredFfmpeg && !(rawFfmpeg.toLowerCase() === 'ffmpeg' || rawFfmpeg.toLowerCase() === 'ffmpeg.exe'))
      ? configuredFfmpeg : (localFfmpeg || rawFfmpeg || 'ffmpeg');
    return { backend: ['whisper.cpp', 'whisper', 'openai-compatible', 'python-faster-whisper', 'faster-whisper'].includes(backend) ? (backend === 'faster-whisper' ? 'python-faster-whisper' : backend) : 'whisper.cpp', binary, modelPath, ffmpegBinary, pythonBinary, voiceWorker, pyModelPath, pyModelSize };
  }
  async commandExists(binary) {
    if (path.isAbsolute(binary) || binary.includes(path.sep)) return fs.existsSync(binary);
    try { await this.execFile(process.platform === 'win32' ? 'where.exe' : 'which', [binary], { timeout: 2000, maxBuffer: 64 * 1024 }); return true; } catch { return false; }
  }
  async status() {
    const cfg = this.config();
    if (cfg.backend === 'python-faster-whisper') {
      let pythonAvailable = false, fasterWhisperAvailable = false, avCompatible = false, avVersion = '', modelAvailable = false, workerMessage = '';
      try { pythonAvailable = await this.commandExists(cfg.pythonBinary); } catch {}
      try { modelAvailable = fs.existsSync(path.join(cfg.pyModelPath, 'model.bin')) && fs.existsSync(path.join(cfg.pyModelPath, 'config.json')); } catch {}
      if (pythonAvailable && fs.existsSync(cfg.voiceWorker)) {
        try {
          const result = await this.execFile(cfg.pythonBinary, [cfg.voiceWorker, 'status'], {
            timeout: 15000, maxBuffer: 512 * 1024, windowsHide: true,
            env: { ...process.env, ...this.env, WHISPER_PY_MODEL_PATH: cfg.pyModelPath },
          });
          const line = String(result.stdout || '').trim().split(/\r?\n/).filter(Boolean).at(-1) || '{}';
          const details = JSON.parse(line);
          fasterWhisperAvailable = details.fasterWhisperAvailable === true;
          avCompatible = details.avCompatible === true;
          avVersion = String(details.avVersion || '');
          if (fasterWhisperAvailable && !avCompatible) workerMessage = details.compatibilityError || `PyAV ${avVersion || 'غير معروف'} غير متوافق؛ يلزم إصدار >=11 و<19.`;
        } catch (error) { workerMessage = execErrorText(error); }
      }
      const ready = pythonAvailable && fasterWhisperAvailable && avCompatible && modelAvailable;
      const message = ready
        ? `محرك Faster-Whisper المحلي جاهز (${cfg.pyModelSize})؛ يتعامل مع OGG/OPUS وM4A وWAV عبر مكتبات Python، ولا يحتاج FFmpeg خارجيًا للتفريغ.`
        : `التفريغ يحتاج بيئة Python وحزمة faster-whisper ونموذجًا محليًا. ${!pythonAvailable ? 'لم أعثر على Python/بيئة الصوت. ' : ''}${pythonAvailable && !fasterWhisperAvailable ? 'حزمة faster-whisper غير مثبتة أو لم تستطع بيئة Python تحميلها. ' : ''}${pythonAvailable && fasterWhisperAvailable && !avCompatible ? `توافق PyAV غير سليم (${avVersion || 'غير معروف'}؛ المطلوب >=11 و<19). ` : ''}${!modelAvailable ? `ملفات النموذج غير موجودة (${path.basename(cfg.pyModelPath)}). ` : ''}${workerMessage ? `تفصيل الفحص: ${workerMessage}. ` : ''}سيكمل البوت إعداد البيئة تلقائيًا عند التشغيل؛ راجع حالة الصوت في لوحة التحكم إذا انتهت محاولات الإعداد. لا تُرفع الصوتيات إلى خدمة خارجية في هذا الوضع.`;
      return {
        ready, engineModelReady: ready, voiceNotesReady: ready, backend: cfg.backend, avCompatible, avVersion,
        binaryLabel: path.basename(cfg.pythonBinary), binaryAvailable: pythonAvailable,
        modelSize: cfg.pyModelSize, modelLabel: path.basename(cfg.pyModelPath), modelAvailable,
        inference: {
          device: String(this.env.WHISPER_PY_DEVICE || 'cpu'), computeType: String(this.env.WHISPER_PY_COMPUTE_TYPE || 'int8'),
          beamSize: Math.max(1, Math.min(10, Number(this.env.WHISPER_PY_BEAM_SIZE) || 5)),
          vad: !['0','false','off','no'].includes(String(this.env.WHISPER_PY_VAD ?? 'true').toLowerCase()),
          vadThreshold: Math.max(0.1, Math.min(0.95, Number(this.env.WHISPER_PY_VAD_THRESHOLD) || 0.5)),
          minSilenceMs: Math.max(100, Math.min(3000, Number(this.env.WHISPER_PY_MIN_SILENCE_MS) || 450)),
          logProbThreshold: Number(this.env.WHISPER_PY_LOG_PROB_THRESHOLD ?? -1.0),
          noSpeechThreshold: Number(this.env.WHISPER_PY_NO_SPEECH_THRESHOLD ?? 0.6),
          compressionRatioThreshold: Number(this.env.WHISPER_PY_COMPRESSION_RATIO_THRESHOLD ?? 2.4),
          conditionOnPreviousText: ['1','true','yes','on'].includes(String(this.env.WHISPER_PY_CONDITION_ON_PREVIOUS_TEXT || '').toLowerCase()),
        },
        modelConfigured: modelAvailable, fasterWhisperAvailable, avCompatible, avVersion, ffmpegAvailable: false,
        setupCommand: 'تهيئة تلقائية عند تشغيل البوت؛ أدوات BAT مخصصة للإصلاح اليدوي فقط',
        maxAudioBytes: this.maxAudioBytes,
        recentAudioCount: [...this.latestBySession.values()].filter(item => Date.now() - item.at < 86400000).length,
        message,
      };
    }
    if (cfg.backend === 'openai-compatible') {
      const endpoint = String(this.env.WHISPER_API_URL || 'https://api.openai.com/v1/audio/transcriptions').trim();
      const key = String(this.env.WHISPER_API_KEY || this.env.OPENAI_API_KEY || '').trim();
      let endpointValid = false;
      try { const u = new URL(endpoint); endpointValid = u.protocol === 'https:' || ['localhost','127.0.0.1','::1'].includes(u.hostname); } catch {}
      const ready = Boolean(key && endpointValid && typeof this.fetch === 'function');
      return { ready, engineModelReady: ready, voiceNotesReady: ready, backend: cfg.backend, binaryAvailable: false, modelAvailable: false, ffmpegAvailable: false, modelConfigured: Boolean(this.env.WHISPER_API_MODEL || 'whisper-1'), maxAudioBytes: this.maxAudioBytes, recentAudioCount: [...this.latestBySession.values()].filter(item => Date.now() - item.at < 86400000).length, message: ready ? 'التفريغ عبر واجهة API خارجية مفعّل صراحةً؛ ستُرسل الملفات الصوتية إلى المزود المحدد.' : 'وضع التفريغ السحابي اختير لكن الإعداد غير مكتمل. حدّد WHISPER_API_KEY وWHISPER_API_URL صالحًا (HTTPS أو localhost). لا يُرسل أي صوت قبل اكتمال الإعداد.' };
    }
    let binaryAvailable = false, modelAvailable = false, ffmpegAvailable = false;
    try { binaryAvailable = await this.commandExists(cfg.binary); } catch {}
    try { modelAvailable = Boolean(cfg.modelPath && fs.existsSync(cfg.modelPath) && fs.statSync(cfg.modelPath).isFile()); } catch { modelAvailable = false; }
    try { ffmpegAvailable = cfg.backend === 'whisper.cpp' ? await this.commandExists(cfg.ffmpegBinary) : false; } catch { ffmpegAvailable = false; }
    const engineModelReady = binaryAvailable && modelAvailable;
    const voiceNotesReady = engineModelReady && (cfg.backend !== 'whisper.cpp' || ffmpegAvailable);
    const statusMessage = !binaryAvailable || !modelAvailable
      ? `التفريغ الصوتي المحلي غير مهيأ بالكامل. ${!binaryAvailable ? `لم أعثر على البرنامج ${path.basename(cfg.binary)}. ` : ''}${!modelAvailable ? `ملف النموذج غير موجود (${path.basename(cfg.modelPath)}). ` : ''}${process.platform === 'win32' ? 'سيحاول المشروع تهيئة Faster-Whisper تلقائيًا عند التشغيل. ' : 'تحتاج الأنظمة غير Windows إلى Python متوافق لتتم التهيئة التلقائية. '}لا تُرفع الملفات الصوتية إلى خدمة خارجية.`
      : !voiceNotesReady
        ? `المحرك والنموذج موجودان، لكن تفريغ فويسات WhatsApp غير جاهز لأن FFmpeg غير موجود. ثبّت FFmpeg أو شغّل أداة إعداد الصوت؛ لن أعتبر الصوتيات جاهزة قبل نجاح التحويل المحلي. لا تُرسل الصوتيات إلى خدمة سحابية.`
        : `محرك التفريغ المحلي جاهز (${cfg.backend}). ${ffmpegAvailable ? 'تحويل OGG/OPUS جاهز عبر FFmpeg.' : 'قد لا تعمل صوتيات OGG/OPUS.'} لا يُرسل الصوت إلى أي خدمة سحابية.`;
    return {
      ready: voiceNotesReady,
      engineModelReady,
      voiceNotesReady,
      backend: cfg.backend,
      modelConfigured: Boolean(String(this.env.WHISPER_MODEL_PATH || '').trim() || modelAvailable),
      binaryAvailable,
      modelAvailable,
      ffmpegAvailable,
      binaryLabel: path.basename(cfg.binary),
      modelLabel: path.basename(cfg.modelPath),
      ffmpegLabel: path.basename(cfg.ffmpegBinary),
      setupCommand: 'تهيئة تلقائية عند بدء المشروع؛ استخدم أداة الإعداد اليدوية فقط كحل إصلاح عند فشل التهيئة التلقائية',
      formatSupportNotice: cfg.backend === 'whisper.cpp' && !ffmpegAvailable ? 'FFmpeg غير موجود؛ صوتيات WhatsApp بصيغة OGG/OPUS تحتاج عادةً تحويلًا إلى WAV محليًا. شغّل أداة إعداد الصوت أو ثبّت FFmpeg.' : '',
      maxAudioBytes: this.maxAudioBytes,
      recentAudioCount: [...this.latestBySession.values()].reduce((sum, item) => sum + (Date.now() - item.at < 24 * 60 * 60 * 1000 ? 1 : 0), 0),
      message: statusMessage,
    };
  }
  rememberIncoming(sessionId, msg) {
    if (!msg || msg.fromMe === true && msg.__chatBotProgrammatic) return false;
    const type = String(msg.type || '').toLowerCase();
    const mime = String(msg?._data?.mimetype || msg?.mimetype || msg?._data?.mediaData?.mimetype || '').toLowerCase();
    const hasAudio = ['audio', 'ptt', 'voice'].includes(type) || mime.startsWith('audio/');
    if (!hasAudio || msg.hasMedia === false || typeof msg.downloadMedia !== 'function') return false;
    const sid = String(sessionId || 'main');
    this.latestBySession.set(sid, { message: msg, at: Date.now(), type, mime });
    if (this.latestBySession.size > 200) {
      for (const [key, item] of this.latestBySession) if (Date.now() - item.at > 24 * 60 * 60 * 1000 || this.latestBySession.size > 180) this.latestBySession.delete(key);
    }
    return true;
  }
  async transcribeLatest(sessionId, { language = 'auto' } = {}) {
    const item = this.latestBySession.get(String(sessionId || 'main'));
    if (!item || Date.now() - item.at > 24 * 60 * 60 * 1000) throw new Error('لم أعثر على صوتية حديثة محفوظة في الذاكرة. أرسل الصوتية إلى محادثة WhatsApp التي يتصل بها البوت، ثم اطلب «فرّغ آخر صوتية».');
    return this.transcribeMessage(item.message, { language, source: 'whatsapp' });
  }
  async transcribeMessage(message, options = {}) {
    const language = allowedLanguage(options.language ?? 'auto');
    const source = options.source || 'whatsapp';
    if (typeof message?.downloadMedia !== 'function') throw new Error('هذه الرسالة لا توفر ملفًا صوتيًا قابلًا للتنزيل من WhatsApp.');
    const rawId = message?.id?._serialized || message?.id?.id || message?.id?.$1 || message?.id || '';
    const chatId = message?.from || message?.to || message?._data?.from || message?._data?.to || '';
    // A message requested in different language modes must not reuse another mode's transcript.
    const key = rawId ? `${String(chatId).toLowerCase()}|${String(rawId)}|lang:${language}` : '';
    if (key) {
      const prior = this.messageTranscriptions.get(key);
      if (prior && (prior.promise || prior.expiresAt > Date.now())) return prior.promise || Promise.resolve({ ...prior.result, cached: true });
      const entry = { promise: null, result: null, expiresAt: 0 };
      const promise = this._transcribeMessage(message, { language, source });
      entry.promise = promise;
      this.messageTranscriptions.set(key, entry);
      // Keep the small successful-result cache bounded; failed jobs are immediately retryable.
      while (this.messageTranscriptions.size > 200) this.messageTranscriptions.delete(this.messageTranscriptions.keys().next().value);
      promise.then(result => {
        if (this.messageTranscriptions.get(key) !== entry) return;
        entry.promise = null; entry.result = result; entry.expiresAt = Date.now() + 5 * 60 * 1000;
      }, () => { if (this.messageTranscriptions.get(key) === entry) this.messageTranscriptions.delete(key); });
      return promise;
    }
    return this._transcribeMessage(message, { language, source });
  }
  async _transcribeMessage(message, { language = 'auto', source = 'whatsapp' } = {}) {
    if (typeof message?.downloadMedia !== 'function') throw new Error('هذه الرسالة لا توفر ملفًا صوتيًا قابلًا للتنزيل من WhatsApp.');
    let media;
    try { media = await message.downloadMedia(); } catch { throw new Error('تعذر تحميل الصوت من WhatsApp. تحقق من الاتصال وأعد إرسال الصوتية إذا انتهت صلاحيتها.'); }
    if (!media?.data || typeof media.data !== 'string') throw new Error('لم يوفر WhatsApp محتوى الصوتية؛ قد تكون غير متاحة أو منتهية الصلاحية.');
    const mime = String(media.mimetype || message?._data?.mimetype || 'audio/ogg').split(';')[0].toLowerCase();
    const ext = safeAudioExtension(`voice${path.extname(String(media.filename || ''))}`, mime) || '.ogg';
    // Avoid allocating a decoded buffer for an oversized/corrupt data URL or
    // arbitrary string that only happens to be present in the media payload.
    const encoded = media.data.replace(/\s+/g, '');
    if (!/^[A-Za-z0-9+/]*={0,2}$/.test(encoded) || encoded.length % 4 === 1) throw new Error('WhatsApp أعاد بيانات صوت غير صالحة؛ أعد إرسال الصوتية ثم حاول مجددًا.');
    if (encoded.length > Math.ceil(this.maxAudioBytes * 4 / 3) + 8) throw new Error(`حجم الصوت يتجاوز الحد (${Math.round(this.maxAudioBytes / 1024 / 1024)} MB).`);
    const bytes = Buffer.from(encoded, 'base64');
    if (!bytes.length || bytes.length > this.maxAudioBytes) throw new Error(`حجم الصوت غير صالح أو تجاوز الحد (${Math.round(this.maxAudioBytes / 1024 / 1024)} MB).`);
    return this.transcribeBuffer(bytes, { extension: ext, language, source });
  }
  async transcribeFile(filePath, { originalName = '', mimetype = '', language = 'auto' } = {}) {
    const ext = safeAudioExtension(originalName || filePath, mimetype);
    if (!ext) throw new Error('صيغة الصوت غير مدعومة. استخدم OGG/OPUS أو MP3 أو M4A أو WAV أو WEBM أو FLAC.');
    const stat = fs.statSync(filePath);
    if (!stat.isFile() || stat.size < 1 || stat.size > this.maxAudioBytes) throw new Error(`حجم الملف الصوتي يجب أن يكون بين 1 بايت و${Math.round(this.maxAudioBytes / 1024 / 1024)} MB.`);
    return this.transcribeBuffer(fs.readFileSync(filePath), { extension: ext, language, source: 'upload' });
  }
  async transcribeRemote(buffer, { extension = '.ogg', language = 'auto', source = 'upload' } = {}) {
    const endpoint = String(this.env.WHISPER_API_URL || 'https://api.openai.com/v1/audio/transcriptions').trim();
    const key = String(this.env.WHISPER_API_KEY || this.env.OPENAI_API_KEY || '').trim();
    let url;
    try { url = new URL(endpoint); } catch { throw new Error('رابط خدمة التفريغ غير صالح.'); }
    if (!(url.protocol === 'https:' || ['localhost','127.0.0.1','::1'].includes(url.hostname))) throw new Error('لأمان بيانات الصوت، يجب أن يكون رابط التفريغ HTTPS أو localhost.');
    if (!key) throw new Error('وضع التفريغ السحابي يحتاج WHISPER_API_KEY أو OPENAI_API_KEY.');
    if (typeof this.fetch !== 'function' || typeof FormData === 'undefined' || typeof Blob === 'undefined') throw new Error('إصدار Node الحالي لا يدعم رفع الصوت لخدمة التفريغ. استخدم Node 20 أو أحدث.');
    const ext = AUDIO_EXTENSIONS.has(String(extension).toLowerCase()) ? String(extension).toLowerCase() : '.ogg';
    const form = new FormData();
    form.append('file', new Blob([buffer]), `voice${ext}`);
    form.append('model', String(this.env.WHISPER_API_MODEL || 'whisper-1').trim().slice(0, 100));
    if (language !== 'auto') form.append('language', language);
    let response;
    try { response = await this.fetch(url, { method: 'POST', headers: { Authorization: `Bearer ${key}` }, body: form, signal: AbortSignal.timeout(Math.max(10000, Math.min(180000, Number(this.env.WHISPER_API_TIMEOUT_MS) || 90000))) }); }
    catch (error) { throw new Error(`فشل الاتصال بخدمة التفريغ الخارجية: ${String(error?.message || error).slice(0, 180)}. لم تُحفظ بيانات الدخول في السجلات.`); }
    if (!response.ok) { let detail = ''; try { detail = (await response.text()).slice(0, 250); } catch {} throw new Error(`خدمة التفريغ أعادت HTTP ${response.status}: ${detail.replace(/Bearer\s+\S+/gi, '[مخفي]').replace(/https?:\/\/\S+/g, '[رابط]')}`); }
    let payload; try { payload = await response.json(); } catch { throw new Error('خدمة التفريغ أعادت استجابة غير مفهومة.'); }
    const transcript = String(payload?.text || payload?.transcript || '').replace(/\s+/g, ' ').trim().slice(0, 12000);
    if (!transcript) throw new Error('خدمة التفريغ لم تُرجع نصًا واضحًا.');
    const detectedLanguage = String(payload?.language || (language === 'auto' ? 'unknown' : language)).toLowerCase();
    return this.withQuality({ ok: true, transcript, text: transcript, language: detectedLanguage, requestedLanguage: language, source, backend: 'openai-compatible', bytes: buffer.length, createdAt: new Date().toISOString(), message: 'اكتمل التفريغ عبر خدمة خارجية؛ راجع إعدادات الخصوصية لدى المزود.' }, language);
  }
  transcribeBuffer(buffer, options = {}) {
    if (this.pendingTranscriptions >= this.maxPendingTranscriptions) {
      return Promise.reject(new Error(`طابور التفريغ ممتلئ (${this.maxPendingTranscriptions} مهام). انتظر انتهاء الصوتيات الحالية ثم أعد المحاولة.`));
    }
    this.pendingTranscriptions += 1;
    const execute = () => this._transcribeBuffer(buffer, options);
    const task = this.transcriptionQueue.then(execute, execute);
    this.transcriptionQueue = task.then(() => undefined, () => undefined);
    return task.finally(() => { this.pendingTranscriptions = Math.max(0, this.pendingTranscriptions - 1); });
  }
  async _transcribeBuffer(buffer, { extension = '.ogg', language = 'auto', source = 'upload' } = {}) {
    const lang = allowedLanguage(language);
    const cfg = this.config();
    if (!Buffer.isBuffer(buffer) || !buffer.length || buffer.length > this.maxAudioBytes) throw new Error('بيانات الصوت فارغة أو تتجاوز الحد المسموح.');
    if (cfg.backend === 'openai-compatible') return this.transcribeRemote(buffer, { extension, language: lang, source });
    if (cfg.backend === 'python-faster-whisper') {
      if (!await this.commandExists(cfg.pythonBinary)) throw new Error('لم تكتمل بيئة Python الصوتية بعد؛ انتظر التهيئة التلقائية عند بدء المشروع ثم راجع حالة الصوت في لوحة التحكم.');
      if (!fs.existsSync(cfg.voiceWorker)) throw new Error('ملف voice_worker.py غير موجود؛ أعد فك حزمة المشروع كاملة.');
      if (!fs.existsSync(path.join(cfg.pyModelPath, 'model.bin')) || !fs.existsSync(path.join(cfg.pyModelPath, 'config.json'))) throw new Error(`نموذج Faster-Whisper غير موجود (${path.basename(cfg.pyModelPath)}). سيعيد المشروع محاولة تهيئته تلقائيًا؛ راجع حالة الصوت ثم أعد المحاولة.`);
      const work = fs.mkdtempSync(path.join(this.tempDir, 'chatbot-faster-whisper-'));
      const input = path.join(work, `input${AUDIO_EXTENSIONS.has(String(extension).toLowerCase()) ? String(extension).toLowerCase() : '.ogg'}`);
      try {
        fs.writeFileSync(input, buffer, { flag: 'wx', mode: 0o600 });
        let execution;
        try {
          execution = await this.execFile(cfg.pythonBinary, [cfg.voiceWorker, 'transcribe', input, lang, cfg.pyModelPath], {
            timeout: Math.max(60000, Math.min(600000, Number(this.env.WHISPER_PY_TIMEOUT_MS) || 300000)),
            maxBuffer: 3 * 1024 * 1024, windowsHide: true, cwd: path.dirname(cfg.voiceWorker),
            env: { ...process.env, ...this.env, WHISPER_PY_MODEL_PATH: cfg.pyModelPath },
          });
        } catch (error) {
          const output = String(error?.stdout || '').trim().split(/\r?\n/).filter(Boolean).at(-1) || '';
          try { const payload = JSON.parse(output); if (payload?.error) throw new Error(payload.error); } catch (parseError) { if (parseError instanceof Error && !/JSON|Unexpected|position/i.test(parseError.message)) throw parseError; }
          throw new Error(`فشل التفريغ عبر مكتبات Python: ${execErrorText(error)}. افتح تقرير الإعداد وتأكد من وجود النموذج محليًا.`);
        }
        const output = String(execution?.stdout || '').trim().split(/\r?\n/).filter(Boolean).at(-1) || '{}';
        let payload; try { payload = JSON.parse(output); } catch { throw new Error('أعاد محرك Python استجابة غير مفهومة.'); }
        if (payload?.ok !== true || !String(payload.transcript || payload.text || '').trim()) throw new Error(String(payload?.error || 'لم يستخرج Faster-Whisper نصًا واضحًا من التسجيل.'));
        const transcript = String(payload.transcript || payload.text).replace(/\u0000/g, '').replace(/\s+/g, ' ').trim().slice(0, 12000);
        return this.withQuality({ ok: true, transcript, text: transcript, language: String(payload.language || lang), requestedLanguage: lang, languageProbability: payload.languageProbability, avgLogProbability: payload.avgLogProbability, avgNoSpeechProbability: payload.avgNoSpeechProbability, maxCompressionRatio: payload.maxCompressionRatio, segments: payload.segments, lowConfidenceSegments: payload.lowConfidenceSegments, duration: payload.duration, transcriptionConfig: payload.transcriptionConfig, source, backend: cfg.backend, bytes: buffer.length, createdAt: new Date().toISOString(), message: 'اكتمل التفريغ محليًا باستخدام مكتبة Faster-Whisper في Python.' }, lang);
      } finally { try { fs.rmSync(work, { recursive: true, force: true }); } catch {} }
    }
    if (!await this.commandExists(cfg.binary)) throw new Error(`محرك التفريغ غير موجود (${cfg.binary}). ثبّت whisper.cpp ثم حدّد WHISPER_CPP_BIN في .env.`);
    if (!cfg.modelPath || !fs.existsSync(cfg.modelPath) || !fs.statSync(cfg.modelPath).isFile()) throw new Error('ملف نموذج Whisper المحلي غير محدد أو غير موجود. حدّد WHISPER_MODEL_PATH في .env.');
    if (!Buffer.isBuffer(buffer) || !buffer.length || buffer.length > this.maxAudioBytes) throw new Error('بيانات الصوت فارغة أو تتجاوز الحد المسموح.');
    const ffmpegReady = cfg.backend === 'whisper.cpp' && await this.commandExists(cfg.ffmpegBinary);
    if (cfg.backend === 'whisper.cpp' && ['.ogg', '.opus', '.webm', '.m4a', '.mp4', '.aac'].includes(String(extension).toLowerCase()) && !ffmpegReady) {
      throw new Error('تعذر تفريغ صوتية WhatsApp لأن FFmpeg غير موجود أو غير جاهز. ينتظر المشروع التهيئة التلقائية؛ راجع حالة الصوت في لوحة التحكم إذا استمر الخطأ.');
    }
    const work = fs.mkdtempSync(path.join(this.tempDir, 'chatbot-whisper-'));
    const input = path.join(work, `input${AUDIO_EXTENSIONS.has(extension) ? extension : '.ogg'}`);
    const outputBase = path.join(work, 'transcript');
    const outputTxt = cfg.backend === 'whisper' ? path.join(work, 'input.txt') : `${outputBase}.txt`;
    try {
      fs.writeFileSync(input, buffer, { flag: 'wx', mode: 0o600 });
      let effectiveInput = input;
      // WhatsApp voice notes are commonly OGG/OPUS. whisper.cpp installations
      // without FFmpeg support may accept only 16-bit WAV, so transcode locally
      // whenever FFmpeg is available. If the whisper.cpp binary was built with
      // its own FFmpeg support, falling back to the original input is still valid.
      if (cfg.backend === 'whisper.cpp' && ffmpegReady) {
        const wavInput = path.join(work, 'input-16khz-mono.wav');
        try {
          await this.execFile(cfg.ffmpegBinary, ['-y', '-i', input, '-ar', '16000', '-ac', '1', '-c:a', 'pcm_s16le', wavInput], { timeout: 120000, maxBuffer: 1024 * 1024, windowsHide: true, cwd: work });
          const wavStat = fs.statSync(wavInput);
          if (!wavStat.isFile() || wavStat.size <= 44) throw new Error('لم ينتج FFmpeg ملف WAV صالحًا.');
          effectiveInput = wavInput;
        } catch (error) {
          if (!['.wav'].includes(extension.toLowerCase())) {
            throw new Error(`تعذر تحويل الصوت محليًا بواسطة FFmpeg: ${execErrorText(error)}. ثبّت FFmpeg أو شغّل أداة SETUP-VOICE-WINDOWS.bat (Windows)، أو استخدم ملف WAV بصيغة PCM 16-bit.`);
          }
          this.log('WARN', `تعذر تحويل WAV؛ ستتم محاولة قراءة الملف الأصلي: ${execErrorText(error)}`);
        }
      }
      let args;
      if (cfg.backend === 'whisper') {
        args = [effectiveInput, '--model', cfg.modelPath, '--task', 'transcribe', '--output_format', 'txt', '--output_dir', work, '--fp16', 'False']
        if (lang !== 'auto') args.push('--language', langNames[lang]);;
      } else {
        args = ['-m', cfg.modelPath, '-f', effectiveInput, '-nt', '-np', '-otxt', '-oj', '-of', outputBase]
        if (lang !== 'auto') args.push('-l', lang);
      }
      let execution = { stdout: '' };
      try { execution = await this.execFile(cfg.binary, args, { timeout: 180000, maxBuffer: 3 * 1024 * 1024, windowsHide: true, cwd: work }); }
      catch (error) {
        if (fs.existsSync(outputTxt)) this.log('WARN', `عاد محرك التفريغ برمز خطأ لكن ملف النص موجود: ${execErrorText(error)}`);
        else throw new Error(`فشل التفريغ الصوتي المحلي: ${execErrorText(error)}. تحقق من توافق النموذج والبرنامج.`);
      }
      let transcript = '';
      try { transcript = fs.readFileSync(outputTxt, 'utf8').trim(); } catch {}
      if (!transcript) transcript = String(execution.stdout || '').trim();
      transcript = transcript.replace(/\[BLANK_AUDIO\]/g, '').replace(/\s+/g, ' ').trim().slice(0, 12000);
      if (!transcript) throw new Error('لم يستطع Whisper استخراج كلمات واضحة من الصوت. جرّب صوتًا أوضح أو نموذجًا أدق.');
      let detectedLanguage = '';
      if (cfg.backend === 'whisper.cpp') {
        try {
          const jsonPath = `${outputBase}.json`;
          if (fs.existsSync(jsonPath)) {
            const metadata = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
            detectedLanguage = String(metadata?.result?.language || metadata?.language || '').toLowerCase().split(/[-_]/)[0];
          }
        } catch { detectedLanguage = ''; }
      }
      const resultLanguage = detectedLanguage || (lang === 'auto' ? 'unknown' : lang);
      return this.withQuality({ ok: true, transcript, text: transcript, language: resultLanguage, requestedLanguage: lang, source, backend: cfg.backend, bytes: buffer.length, createdAt: new Date().toISOString(), message: 'اكتمل التفريغ داخل الجهاز المحلي.' }, lang);
    } finally {
      try { fs.rmSync(work, { recursive: true, force: true }); } catch {}
    }
  }
}

module.exports = { AudioTranscriber, MAX_AUDIO_BYTES, AUDIO_EXTENSIONS, safeAudioExtension, allowedLanguage };
