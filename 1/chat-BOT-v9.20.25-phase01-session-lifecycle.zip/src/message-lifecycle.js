'use strict';

const crypto = require('node:crypto');

function firstValue(...values) {
  return values.find(value => value !== undefined && value !== null && value !== '');
}

function messageTimestampMs(message) {
  const raw = firstValue(
    message?.timestamp,
    message?._data?.t,
    message?._data?.timestamp,
    message?.t,
    message?.msgTimestamp,
  );
  if (raw === undefined) return null;
  if (typeof raw === 'string' && !/^\d+(?:\.\d+)?$/.test(raw.trim())) {
    const parsed = Date.parse(raw);
    return Number.isFinite(parsed) ? parsed : null;
  }
  const numeric = Number(raw);
  if (!Number.isFinite(numeric) || numeric <= 0) return null;
  return numeric < 1e12 ? Math.trunc(numeric * 1000) : Math.trunc(numeric);
}

function messageAgeMs(message, now = Date.now()) {
  const timestamp = messageTimestampMs(message);
  return timestamp === null ? null : now - timestamp;
}

function isStaleMessage(message, maxAgeSec = 300, now = Date.now(), futureToleranceSec = 300) {
  const age = messageAgeMs(message, now);
  if (age === null) return false;
  const limit = Math.max(1, Math.min(86400, Number(maxAgeSec) || 300)) * 1000;
  const futureTolerance = Math.max(0, Math.min(1800, Number(futureToleranceSec) || 0)) * 1000;
  return age > limit || age < -futureTolerance;
}

function messageId(message) {
  const id = message?.id ?? message?._data?.id ?? message?.msgId ?? message?.messageId;
  if (typeof id === 'string' || typeof id === 'number') return String(id);
  return String(id?._serialized || id?.$1 || id?.id || id?.id?._serialized || '');
}

function messageEventKey(sessionId, chatId, message, event = 'message') {
  const id = messageId(message);
  const stamp = messageTimestampMs(message);
  const identity = id
    ? `id:${id}`
    : `fallback:${stamp || 'unknown'}:${String(message?.body || message?._data?.body || '').slice(0, 500)}:${String(message?.type || 'chat')}`;
  const material = [String(sessionId || ''), String(chatId || '').toLowerCase(), String(event || ''), message?.fromMe ? 'out' : 'in', identity].join('|');
  return crypto.createHash('sha256').update(material).digest('hex');
}

function pruneEventLedger(ledger, { now = Date.now(), maxEntries = 3000, maxAgeMs = 86400000 } = {}) {
  const source = ledger && typeof ledger === 'object' ? ledger : {};
  for (const [key, value] of Object.entries(source)) {
    const at = Number(value?.at ?? value);
    if (!Number.isFinite(at) || at <= 0 || now - at > maxAgeMs || at > now + 300000) delete source[key];
  }
  const entries = Object.entries(source);
  if (entries.length > maxEntries) {
    entries.sort((a, b) => Number(a[1]?.at ?? a[1]) - Number(b[1]?.at ?? b[1]));
    for (const [key] of entries.slice(0, entries.length - maxEntries)) delete source[key];
  }
  return source;
}

module.exports = { messageTimestampMs, messageAgeMs, isStaleMessage, messageId, messageEventKey, pruneEventLedger };
