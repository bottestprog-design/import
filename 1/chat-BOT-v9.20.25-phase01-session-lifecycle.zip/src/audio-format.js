'use strict';
const fs = require('node:fs');

const OGG_MAGIC = Buffer.from('OggS', 'ascii');
const OPUS_HEAD = Buffer.from('OpusHead', 'ascii');
const MAX_PROBE_BYTES = 256 * 1024;

function inspectOggOpusBuffer(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 100) {
    return { valid: false, reason: 'too-small', container: '', codec: '' };
  }
  if (!buffer.subarray(0, 4).equals(OGG_MAGIC)) {
    return { valid: false, reason: 'not-ogg', container: '', codec: '' };
  }
  // Parse the first Ogg page instead of searching the file for marker strings.
  // OpusHead must be the first complete packet in a beginning-of-stream page.
  if (buffer.length < 28) return { valid: false, reason: 'truncated-ogg-page', container: 'ogg', codec: '' };
  if (buffer[4] !== 0) return { valid: false, reason: 'unsupported-ogg-version', container: 'ogg', codec: '' };
  if ((buffer[5] & 0x02) === 0) return { valid: false, reason: 'ogg-bos-flag-missing', container: 'ogg', codec: '' };
  const segmentCount = buffer[26];
  if (segmentCount < 1) return { valid: false, reason: 'ogg-segments-missing', container: 'ogg', codec: '' };
  const tableEnd = 27 + segmentCount;
  if (tableEnd > buffer.length) return { valid: false, reason: 'truncated-ogg-segment-table', container: 'ogg', codec: '' };
  let pagePayloadLength = 0;
  let firstPacketLength = 0;
  let firstPacketComplete = false;
  for (let i = 0; i < segmentCount; i++) {
    const lace = buffer[27 + i];
    pagePayloadLength += lace;
    if (!firstPacketComplete) {
      firstPacketLength += lace;
      if (lace < 255) firstPacketComplete = true;
    }
  }
  if (!firstPacketComplete) return { valid: false, reason: 'truncated-first-ogg-packet', container: 'ogg', codec: '' };
  const pageEnd = tableEnd + pagePayloadLength;
  if (pageEnd > buffer.length) return { valid: false, reason: 'truncated-ogg-page', container: 'ogg', codec: '' };
  if (firstPacketLength < 19) return { valid: false, reason: 'opus-head-too-small', container: 'ogg', codec: '' };
  const packet = buffer.subarray(tableEnd, tableEnd + firstPacketLength);
  if (!packet.subarray(0, 8).equals(OPUS_HEAD)) return { valid: false, reason: 'opus-head-missing', container: 'ogg', codec: '' };
  // OpusHead: version, channel count, pre-skip, input sample rate, gain, mapping.
  if (packet[8] > 15) return { valid: false, reason: 'unsupported-opus-head-version', container: 'ogg', codec: 'opus' };
  if (packet[9] < 1 || packet[9] > 255) return { valid: false, reason: 'invalid-opus-channel-count', container: 'ogg', codec: 'opus' };
  const probe = buffer.subarray(0, Math.min(buffer.length, MAX_PROBE_BYTES));
  return { valid: true, reason: '', container: 'ogg', codec: 'opus', channels: packet[9], bytesProbed: probe.length, firstPageBytes: pageEnd };
}

function inspectOggOpusFile(filePath, { maxBytes = 32 * 1024 * 1024 } = {}) {
  let fd;
  try {
    const stat = fs.statSync(filePath);
    if (!stat.isFile()) return { valid: false, reason: 'not-a-file', size: 0 };
    if (stat.size < 100) return { valid: false, reason: 'too-small', size: stat.size };
    if (stat.size > maxBytes) return { valid: false, reason: 'too-large', size: stat.size };
    const probeSize = Math.min(stat.size, MAX_PROBE_BYTES);
    const probe = Buffer.alloc(probeSize);
    fd = fs.openSync(filePath, 'r');
    const read = fs.readSync(fd, probe, 0, probeSize, 0);
    const result = inspectOggOpusBuffer(probe.subarray(0, read));
    return { ...result, size: stat.size };
  } catch (error) {
    return { valid: false, reason: 'unreadable', size: 0, error: String(error?.message || error).slice(0, 180) };
  } finally {
    if (fd !== undefined) { try { fs.closeSync(fd); } catch {} }
  }
}

function assertOggOpusFile(filePath, options = {}) {
  const result = inspectOggOpusFile(filePath, options);
  if (!result.valid) {
    const reason = result.reason === 'not-ogg' ? 'الملف لا يحتوي على ترويسة OGG صالحة'
      : result.reason === 'opus-head-missing' ? 'أول حزمة OGG ليست ترويسة ترميز Opus'
      : result.reason.startsWith('truncated-') ? 'ملف OGG مبتور أو ترويسة الصفحة غير مكتملة'
      : result.reason === 'ogg-bos-flag-missing' ? 'صفحة OGG الأولى لا تحمل علامة بدء التدفق'
      : result.reason === 'unsupported-opus-head-version' ? 'إصدار ترويسة Opus غير مدعوم'
      : result.reason === 'invalid-opus-channel-count' ? 'عدد قنوات Opus غير صالح'
      : result.reason === 'too-small' ? 'ملف الصوت قصير جدًا أو فارغ'
      : result.reason === 'too-large' ? 'حجم ملف الصوت تجاوز الحد المسموح'
      : result.reason === 'not-a-file' ? 'مسار الصوت ليس ملفًا عاديًا'
      : 'تعذر قراءة ملف الصوت والتحقق منه';
    throw new Error(`${reason}${result.error ? `: ${result.error}` : ''}. لم يُرسل الملف كرسالة صوتية.`);
  }
  return result;
}

module.exports = { inspectOggOpusBuffer, inspectOggOpusFile, assertOggOpusFile, MAX_PROBE_BYTES };
