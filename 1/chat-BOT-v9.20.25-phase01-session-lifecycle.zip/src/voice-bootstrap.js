'use strict';

// One-time, project-owned voice runtime provisioning. It is intentionally
// non-blocking for the HTTP server; the normal bot UI remains available while
// Python packages and local models are prepared.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const { pipeline } = require('node:stream/promises');
const { Readable } = require('node:stream');

const PYTHON_VERSION = '3.13.17';
const PYTHON_INSTALLER_URL = `https://www.python.org/ftp/python/${PYTHON_VERSION}/python-${PYTHON_VERSION}-amd64.exe`;
const PYTHON_INSTALLER_SHA256 = '5da012101ba2e17113a9a1cd901e9ce1441086f2b7ecb5de06ec94163899a190';
const PIPER_MODEL_URL = 'https://huggingface.co/rhasspy/piper-voices/resolve/main/ar/ar_JO/kareem/medium/ar_JO-kareem-medium.onnx';
const PIPER_MODEL_SHA256 = '9e95cab07b679da603bba17c4dec7ab3111320571964ee95c0379603c086491e';
const VOICE_REQUIREMENTS_FILE = path.join(__dirname, '..', 'scripts', 'voice-requirements.txt');
const CHATTERBOX_REQUIREMENTS_FILE = path.join(__dirname, '..', 'scripts', 'voice-tts-requirements.txt');
const AUDAR_REQUIREMENTS_FILE = path.join(__dirname, '..', 'scripts', 'voice-audar-requirements.txt');
const AUDAR_CPU_WHEEL_INDEX = 'https://abetlen.github.io/llama-cpp-python/whl/cpu';
const REQUIRED_PACKAGES = fs.readFileSync(VOICE_REQUIREMENTS_FILE, 'utf8').split(/\r?\n/).map(line => line.trim()).filter(line => line && !line.startsWith('#'));
if (!REQUIRED_PACKAGES.some(item => /^av>=11,<19$/i.test(item))) throw new Error('ملف اعتماديات الصوت يجب أن يثبت PyAV بإصدار >=11 و<19.');

function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function isCompatiblePyAv(version) {
  const match = /^\s*(\d+)(?:\.|$)/.exec(String(version || ''));
  if (!match) return false;
  const major = Number(match[1]);
  return Number.isInteger(major) && major >= 11 && major < 19;
}
function normalizeTtsBackend(value) {
  const backend = String(value || '').trim().toLowerCase();
  return ['auto', 'local', 'edge-tts', 'openai-compatible'].includes(backend) ? backend : 'local';
}
function safeError(error) { return String(error?.message || error || 'فشل إعداد الصوت').replace(/https?:\/\/\S+/g, '[رابط خدمة]').replace(/(?:[A-Za-z]:\\(?:[^\\\s]+\\)*[^\s,;]*)/g, '[مسار محلي]').slice(0, 420); }
function sha256File(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256'); const stream = fs.createReadStream(filePath);
    stream.on('data', chunk => hash.update(chunk)); stream.on('error', reject); stream.on('end', () => resolve(hash.digest('hex')));
  });
}
function run(command, args, { cwd, timeout = 120000, env = process.env, input = undefined, onOutput = () => {}, maxOutput = 1_000_000 } = {}) {
  return new Promise((resolve, reject) => {
    let stdout = ''; let stderr = ''; let done = false; let timer;
    let child;
    try { child = spawn(command, args, { cwd, env, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] }); }
    catch (error) { reject(error); return; }
    const finish = (error, code = 0) => { if (done) return; done = true; clearTimeout(timer); error ? reject(error) : (code === 0 ? resolve({ stdout, stderr, code }) : reject(new Error(`${path.basename(command)} انتهى برمز ${code}: ${safeError(stderr || stdout)}`))); };
    child.stdout.on('data', chunk => { const value = String(chunk); stdout = (stdout + value).slice(-maxOutput); onOutput(value, 'stdout'); });
    child.stderr.on('data', chunk => { const value = String(chunk); stderr = (stderr + value).slice(-maxOutput); onOutput(value, 'stderr'); });
    child.once('error', error => finish(new Error(`تعذر تشغيل ${path.basename(command)}: ${safeError(error)}`)));
    child.once('close', code => finish(null, code ?? 1));
    timer = setTimeout(() => { try { child.kill('SIGTERM'); } catch {} finish(new Error(`انتهت مهلة ${path.basename(command)}.`)); }, timeout);
    timer.unref?.();
    if (input !== undefined) child.stdin.end(input); else child.stdin.end();
  });
}

class VoiceBootstrap {
  constructor({ root = path.resolve(__dirname, '..'), env = process.env, logger = () => {}, fetchImpl = globalThis.fetch } = {}) {
    this.root = path.resolve(root); this.env = env; this.log = logger; this.fetch = fetchImpl;
    this.venvDir = path.join(this.root, '.voice-venv');
    this.ttsVenvDir = path.join(this.root, '.voice-tts-venv');
    this.audarVenvDir = path.join(this.root, '.voice-audar-venv');
    this.audarModelDir = path.resolve(this.root, String(this.env.AUDAR_TTS_MODEL_DIR || path.join('models', 'audar-tts')));
    this.audarVoiceDir = path.resolve(this.root, String(this.env.AUDAR_TTS_VOICE_DIR || path.join('models', 'audar-voices')));
    this.audarCacheDir = path.resolve(this.root, String(this.env.AUDAR_TTS_CACHE_DIR || path.join('models', 'hf-cache')));
    this.audarCodecDir = path.resolve(this.root, String(this.env.AUDAR_TTS_CODEC_DIR || path.join('models', 'audar-codec')));
    this.audarTier = ['turbo', 'flash'].includes(String(this.env.AUDAR_TTS_TIER || '').toLowerCase()) ? String(this.env.AUDAR_TTS_TIER).toLowerCase() : 'turbo';
    this.audarState = { enabled: true, ready: false, state: 'pending', tier: this.audarTier, model: `Audar-TTS-V1-${this.audarTier.toUpperCase()} Q5_K_M`, modelPathLabel: path.basename(this.audarModelDir), pythonPathLabel: '', message: 'سيتم تجهيز Audar العربي المحلي تلقائيًا عند بدء المشروع.' };
    const configuredTtsModelPath = String(this.env.CHATTERBOX_MODEL_PATH || '').trim();
    this.chatterboxModelDir = configuredTtsModelPath ? (path.isAbsolute(configuredTtsModelPath) ? configuredTtsModelPath : path.resolve(this.root, configuredTtsModelPath)) : path.join(this.root, 'models', 'chatterbox-multilingual-v3');
    this.chatterboxState = { enabled: false, ready: false, state: 'disabled', model: 'Chatterbox Multilingual V3', modelPathLabel: path.basename(this.chatterboxModelDir), device: String(this.env.CHATTERBOX_DEVICE || 'auto'), message: 'Chatterbox اختياري؛ لا يُنزّل تلقائيًا لتجنب عدة جيجابايت إضافية.' };
    this.modelSize = String(this.env.WHISPER_PY_MODEL || 'small').trim().toLowerCase();
    if (!['tiny','base','small','medium','large-v3','large-v3-turbo'].includes(this.modelSize)) throw new Error(`حجم نموذج Whisper غير مدعوم: ${this.modelSize}`);
    const configuredModelPath = String(this.env.WHISPER_PY_MODEL_PATH || '').trim();
    this.modelDir = configuredModelPath ? (path.isAbsolute(configuredModelPath) ? configuredModelPath : path.resolve(this.root, configuredModelPath)) : path.join(this.root, 'models', `faster-whisper-${this.modelSize}`);
    this.piperModel = path.join(this.root, 'models', 'ar_JO-kareem-medium.onnx');
    this.state = { state: 'idle', stage: 'لم يبدأ', progress: 0, message: 'سيتم إعداد محركات الصوت تلقائيًا عند تشغيل البوت.', startedAt: null, updatedAt: new Date().toISOString(), attempts: 0, restartRequired: false };
    this.promise = null;
    this.retryTimer = null;
    this.maxAttempts = 4;
    this.piperRepairAttempted = false;
  }
  update(state, stage, progress, message, error = '') {
    this.state = { ...this.state, state, stage, progress: Math.max(0, Math.min(100, Number(progress) || 0)), message: String(message || '').slice(0, 500), error: String(error || '').slice(0, 500), updatedAt: new Date().toISOString() };
    try { this.log(state === 'failed' ? 'WARN' : 'INFO', `[VOICE_BOOTSTRAP] ${stage}: ${this.state.message}`); } catch {}
  }
  publicStatus() {
    return { ...this.state, startedAt: this.state.startedAt, updatedAt: this.state.updatedAt, ready: this.state.state === 'ready', retryScheduled: Boolean(this.retryTimer), modelSize: this.modelSize, modelPathLabel: path.basename(this.modelDir), languages: ['ar', 'en', 'fr', 'de', 'es'], localTranscription: this.state.state === 'ready', audar: { ...this.audarState }, chatterbox: { ...this.chatterboxState }, networkSpeech: 'النطق العربي والإنجليزي محلي عبر Audar؛ Piper بديل عربي. Chatterbox اختياري للغات الإضافية، ولا تُرسل النصوص إلى مزود خارجي دون موافقة صريحة.' };
  }
  async waitUntilReady({ timeoutMs = 45 * 60 * 1000, pollMs = 1000 } = {}) {
    const timeout = Math.max(60_000, Math.min(60 * 60 * 1000, Number(timeoutMs) || 45 * 60 * 1000));
    const poll = Math.max(250, Math.min(5000, Number(pollMs) || 1000));
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const status = this.publicStatus();
      if (status.ready) return status;
      if (status.state === 'failed' && !status.retryScheduled && Number(status.attempts || 0) >= this.maxAttempts) return status;
      if (status.state === 'idle' && !this.promise && !this.retryTimer) {
        const autoStart = !['0', 'false', 'off', 'no'].includes(String(this.env.VOICE_AUTOSTART || 'true').trim().toLowerCase());
        if (!autoStart) return status;
        this.start().catch(() => {});
      }
      await delay(Math.min(poll, Math.max(1, deadline - Date.now())));
    }
    return { ...this.publicStatus(), timedOut: true, message: 'انتهت مهلة انتظار تهيئة الصوت؛ لم يتم تفريغ هذه الصوتية بعد.' };
  }
  start() {
    if (this.state.state === 'ready') return Promise.resolve(this.publicStatus());
    if (this.promise) return this.promise;
    if (this.retryTimer) { clearTimeout(this.retryTimer); this.retryTimer = null; }
    this.state.startedAt = this.state.startedAt || new Date().toISOString();
    this.state.attempts = Number(this.state.attempts || 0) + 1;
    this.promise = this.runSetup().then(() => this.publicStatus()).catch(error => {
      const message = safeError(error);
      const retryDelays = [30_000, 120_000, 300_000];
      const attempt = Number(this.state.attempts || 1);
      if (attempt < this.maxAttempts) {
        const retryDelay = retryDelays[Math.min(attempt - 1, retryDelays.length - 1)];
        this.update('failed', `فشلت المحاولة ${attempt} من ${this.maxAttempts} — ستتم إعادة المحاولة تلقائيًا`, this.state.progress, `تعذر إكمال إعداد الصوت: ${message}. سيعيد المشروع المحاولة تلقائيًا بعد ${Math.round(retryDelay / 1000)} ثانية؛ لا تحتاج إلى تشغيل مثبت.`, message);
        this.retryTimer = setTimeout(() => { this.retryTimer = null; this.start(); }, retryDelay);
        this.retryTimer.unref?.();
      } else {
        this.update('failed', 'تعذر إكمال التهيئة التلقائية بعد عدة محاولات', this.state.progress, `ظلّ البوت يعمل، لكن الصوت غير جاهز: ${message}. راجع تقرير الصوت داخل لوحة التحكم.`, message);
      }
      return this.publicStatus();
    }).finally(() => { this.promise = null; });
    return this.promise;
  }
  async download(url, destination, { maxBytes = 1024 * 1024 * 1024, expectedSha256 = '', progressBase = 0, progressSpan = 1 } = {}) {
    if (typeof this.fetch !== 'function') throw new Error('بيئة Node لا تحتوي fetch لتنزيل محركات الصوت.');
    const response = await this.fetch(url, { redirect: 'follow', signal: AbortSignal.timeout(600000) });
    if (!response.ok || !response.body) throw new Error(`فشل تنزيل مكون الصوت (HTTP ${response.status}).`);
    const finalUrl = new URL(response.url || url);
    if (finalUrl.protocol !== 'https:') throw new Error('تم رفض تنزيل مكون صوت من رابط غير مشفر.');
    const length = Number(response.headers.get('content-length') || 0);
    if (length > maxBytes) throw new Error('حجم ملف الصوت أكبر من الحد المسموح.');
    fs.mkdirSync(path.dirname(destination), { recursive: true });
    const temp = `${destination}.download-${process.pid}-${Date.now()}`;
    let received = 0; let lastReportedMiB = -1; const hash = crypto.createHash('sha256');
    const source = Readable.fromWeb(response.body);
    const meter = new (require('node:stream').Transform)({ transform: (chunk, _encoding, callback) => {
      received += chunk.length;
      if (received > maxBytes) return callback(new Error('تجاوز تنزيل مكون الصوت الحد المسموح.'));
      hash.update(chunk);
      if (length > 0) {
        const receivedMiB = Math.round(received / 1024 / 1024);
        if (receivedMiB !== lastReportedMiB) {
          lastReportedMiB = receivedMiB;
          this.update('preparing', 'تنزيل مكونات الصوت', progressBase + Math.min(progressSpan, (received / length) * progressSpan), `تم تنزيل ${receivedMiB} من ${Math.max(1, Math.round(length / 1024 / 1024))} ميجابايت.`);
        }
      }
      callback(null, chunk);
    }});
    try {
      await pipeline(source, meter, fs.createWriteStream(temp, { flags: 'wx', mode: 0o600 }));
      const digest = hash.digest('hex');
      if (expectedSha256 && digest.toLowerCase() !== expectedSha256.toLowerCase()) throw new Error('فشل التحقق من بصمة ملف الصوت؛ حُذف الملف غير المطابق.');
      fs.rmSync(destination, { force: true }); fs.renameSync(temp, destination);
      return { bytes: received, sha256: digest };
    } catch (error) { fs.rmSync(temp, { force: true }); throw error; }
  }
  async commandExists(command) {
    if (!command) return false;
    if (path.isAbsolute(command) || /[\\/]/.test(command)) return fs.existsSync(command) && fs.statSync(command).isFile();
    try { await run(process.platform === 'win32' ? 'where.exe' : 'which', [command], { timeout: 5000, maxOutput: 20000 }); return true; } catch { return false; }
  }
  pythonCommand(exe, prefix = []) { return { exe, prefix }; }
  async pythonWorks(command) {
    try {
      const result = await run(command.exe, [...command.prefix, '-c', 'import sys;print("%d.%d.%d" % sys.version_info[:3]);raise SystemExit(0 if (3,10) <= sys.version_info[:2] < (3,14) else 2)'], { timeout: 10000, maxOutput: 20000 });
      return { ok: true, version: result.stdout.trim().split(/\r?\n/).at(-1) };
    } catch { return { ok: false, version: '' }; }
  }
  async findBasePython() {
    const candidates = [];
    if (process.platform === 'win32') {
      for (const version of ['-3.13', '-3.12', '-3.11', '-3.10']) candidates.push(this.pythonCommand('py.exe', [version]));
      candidates.push(this.pythonCommand('python.exe'), this.pythonCommand('python'));
    } else {
      candidates.push(this.pythonCommand('python3.13'), this.pythonCommand('python3.12'), this.pythonCommand('python3.11'), this.pythonCommand('python3.10'), this.pythonCommand('python3'), this.pythonCommand('python'));
    }
    for (const candidate of candidates) { if ((await this.pythonWorks(candidate)).ok) return candidate; }
    return null;
  }
  async ensurePython() {
    const local = process.platform === 'win32' ? path.join(this.venvDir, 'Scripts', 'python.exe') : path.join(this.venvDir, 'bin', 'python');
    if (fs.existsSync(local) && (await this.pythonWorks(this.pythonCommand(local))).ok) return local;
    this.update('preparing', 'البحث عن Python المتوافق', 3, 'يتم فحص بيئة المشروع وPython المتوافق تلقائيًا.');
    let base = await this.findBasePython();
    if (!base && process.platform === 'win32' && process.arch === 'x64') {
      this.update('preparing', 'تجهيز Python داخل المشروع', 5, 'لا يوجد Python متوافق؛ سيتم تنزيل المثبت الرسمي والتحقق من بصمته وتثبيته داخل مجلد المشروع.');
      const installer = path.join(this.root, '.runtime-downloads', `python-${PYTHON_VERSION}-amd64.exe`);
      if (!fs.existsSync(installer) || await sha256File(installer).catch(() => '') !== PYTHON_INSTALLER_SHA256) {
        await this.download(PYTHON_INSTALLER_URL, installer, { maxBytes: 80 * 1024 * 1024, expectedSha256: PYTHON_INSTALLER_SHA256, progressBase: 5, progressSpan: 4 });
      }
      const installDir = path.join(this.root, '.voice-python');
      const installArgs = ['/quiet', `TargetDir=${installDir}`, 'Include_launcher=0', 'Include_test=0', 'Include_doc=0', 'Include_tcltk=0', 'Include_dev=0', 'Include_pip=1', 'Shortcuts=0', 'PrependPath=0'];
      await run(installer, installArgs, { cwd: this.root, timeout: 240000, maxOutput: 60000 });
      const exe = path.join(installDir, 'python.exe');
      if (!(await this.pythonWorks(this.pythonCommand(exe))).ok) throw new Error('تم تشغيل مثبت Python لكن لم يجتز فحص الإصدار.');
      base = this.pythonCommand(exe);
    }
    if (!base) throw new Error('لم يُعثر على Python 3.10–3.13 متوافق. على Windows x64 سيحاول المشروع تنزيل Python رسميًا تلقائيًا؛ على الأنظمة الأخرى ثبّت Python متوافقًا مرة واحدة ثم أعد تشغيل البوت.');
    this.update('preparing', 'إنشاء بيئة Python خاصة بالمشروع', 10, 'تُعزل مكتبات الصوت داخل .voice-venv ولا تغيّر مكتبات Python العامة.');
    fs.rmSync(this.venvDir, { recursive: true, force: true });
    fs.mkdirSync(path.dirname(this.venvDir), { recursive: true });
    await run(base.exe, [...base.prefix, '-m', 'venv', this.venvDir], { cwd: this.root, timeout: 90000, maxOutput: 100000 });
    if (!(await this.pythonWorks(this.pythonCommand(local))).ok) throw new Error('لم تُنشأ بيئة Python الصوتية بنجاح.');
    return local;
  }
  async packagesAvailable(python) {
    try {
      const probe = [
        'import importlib.util,json',
        'def available(name, load=False):',
        ' try:',
        '  if importlib.util.find_spec(name) is None: return False',
        '  if load: __import__(name)',
        '  return True',
        ' except Exception:',
        '  return False',
        'def av_version():',
        ' try:',
        '  import av',
        '  return str(getattr(av,"__version__",""))',
        ' except Exception:',
        '  return ""',
        'print(json.dumps({"whisper":available("faster_whisper"),"avVersion":av_version(),"piper":available("piper"),"piperBridge":available("piper.espeakbridge",True),"edge":available("edge_tts"),"ffmpeg":available("imageio_ffmpeg"),"hub":available("huggingface_hub")}))',
      ].join('\n');
      const result = await run(python, ['-c', probe], { cwd: this.root, timeout: 25000, maxOutput: 20000, env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' } });
      const packages = JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1));
      packages.avCompatible = isCompatiblePyAv(packages.avVersion);
      return packages;
    } catch { return { avCompatible: false, avVersion: '' }; }
  }
  async ensurePackages(python) {
    let required = await this.packagesAvailable(python);
    const piper = path.join(this.venvDir, process.platform === 'win32' ? 'Scripts/piper.exe' : 'bin/piper');
    // A package directory can exist while its native espeak bridge is missing/broken.
    // Detect that state and reinstall Piper instead of retrying the same broken install forever.
    if (required.whisper && !required.avCompatible && required.avVersion) {
      this.update('preparing', 'إصلاح توافق Whisper وPyAV', 16, `إصدار PyAV ${required.avVersion} لا يتوافق مع نسخة Faster-Whisper الحالية؛ سيُثبت إصدار متوافق تلقائيًا بدل تكرار فشل تفريغ الصوت.`);
    }
    if (required.piper && !required.piperBridge) {
      if (this.piperRepairAttempted) throw new Error('جسر espeakbridge غير قابل للتحميل حتى بعد إعادة تثبيت Piper مرة واحدة؛ أُوقفت إعادة التنزيل المتكررة لحماية الوقت والبيانات.');
      this.piperRepairAttempted = true;
      this.update('preparing', 'إصلاح مكوّن Piper', 17, 'تم العثور على مكتبة Piper لكن جسر نطق النص غير قابل للتحميل؛ ستتم إعادة تثبيت الحزمة تلقائيًا.');
      await run(python, ['-m', 'pip', 'install', '--disable-pip-version-check', '--force-reinstall', 'piper-tts>=1.8,<2'], { cwd: this.root, timeout: 12 * 60 * 1000, maxOutput: 500000, env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' } });
      required = await this.packagesAvailable(python);
      if (!required.piper || !required.piperBridge) throw new Error('أُعيد تثبيت Piper لكن جسر espeakbridge ما زال غير قابل للتحميل؛ لن يعلن الصوت المحلي جاهزًا.');
    }
    if (required.whisper && required.avCompatible && required.piper && required.piperBridge && required.edge && required.ffmpeg && required.hub && fs.existsSync(piper)) { this.update('preparing', 'المكتبات الصوتية جاهزة', 30, 'تم العثور على Faster-Whisper وPiper وجسر espeakbridge وEdge TTS وFFmpeg.'); return piper; }
    this.update('preparing', 'تثبيت المكتبات الصوتية', 15, 'يتم تثبيت محركات التفريغ والنطق والتحويل تلقائيًا؛ لا يلزم تشغيل مثبت منفصل.');
    let lastError;
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        await run(python, ['-m', 'pip', 'install', '--disable-pip-version-check', '--upgrade', 'pip<27', '-r', VOICE_REQUIREMENTS_FILE], {
          cwd: this.root, timeout: 12 * 60 * 1000, maxOutput: 500000,
          env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' },
          onOutput: (chunk) => { if (/Installing collected packages|Successfully installed|Downloading|Collecting/i.test(chunk)) this.update('preparing', 'تثبيت المكتبات الصوتية', 18, 'جارٍ تنزيل وتثبيت مكتبات الصوت اللازمة.'); }
        });
        const after = await this.packagesAvailable(python);
        if (!(after.whisper && after.avCompatible && after.piper && after.piperBridge && after.edge && after.ffmpeg && after.hub && fs.existsSync(piper))) throw new Error('اكتمل أمر pip لكن فحص مكتبات الصوت أو جسر espeakbridge لم ينجح.');
        return piper;
      } catch (error) { lastError = error; if (attempt < 2) await delay(3000); }
    }
    throw new Error(`تعذر تثبيت مكتبات الصوت تلقائيًا: ${safeError(lastError)}`);
  }
  async ensureChatterboxPython(basePython) {
    const python = path.join(this.ttsVenvDir, process.platform === 'win32' ? 'Scripts' : 'bin', process.platform === 'win32' ? 'python.exe' : 'python');
    if (fs.existsSync(python) && (await this.pythonWorks(this.pythonCommand(python))).ok) return python;
    fs.rmSync(this.ttsVenvDir, { recursive: true, force: true });
    this.update('preparing', 'إنشاء بيئة مستقلة لمحرك Chatterbox', 75, 'يُنشئ المشروع بيئة معزولة لمحرك الصوت التعبيري حتى لا تتعارض مكتباته مع Whisper وPiper.');
    fs.mkdirSync(path.dirname(this.ttsVenvDir), { recursive: true });
    await run(basePython, ['-m', 'venv', this.ttsVenvDir], { cwd: this.root, timeout: 120000, maxOutput: 100000 });
    if (!(await this.pythonWorks(this.pythonCommand(python))).ok) throw new Error('لم تُنشأ بيئة Python المستقلة لمحرك Chatterbox.');
    return python;
  }
  async chatterboxPackageReady(python) {
    try {
      const probe = [
        'import importlib.metadata,inspect,json',
        'ready=False; supports_v3=False; version=""',
        'try:',
        ' from chatterbox.mtl_tts import ChatterboxMultilingualTTS, MULTILINGUAL_T3_MODELS',
        ' import soundfile',
        ' version=importlib.metadata.version("chatterbox-tts")',
        ' supports_v3=("t3_model" in inspect.signature(ChatterboxMultilingualTTS.from_local).parameters and MULTILINGUAL_T3_MODELS.get("v3")=="t3_mtl23ls_v3.safetensors")',
        ' ready=bool(supports_v3)',
        'except Exception: pass',
        'print(json.dumps({"ready":ready,"supportsV3":supports_v3,"version":version}))',
      ].join('\n');
      const result = await run(python, ['-c', probe], { cwd: this.root, timeout: 30000, maxOutput: 20000 });
      return JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1) || '{}').ready === true;
    } catch { return false; }
  }
  async ensureChatterbox(basePython) {
    const enabled = ['1', 'true', 'on', 'yes'].includes(String(this.env.CHATTERBOX_TTS_ENABLED ?? 'false').trim().toLowerCase());
    if (!enabled) {
      this.chatterboxState = { ...this.chatterboxState, enabled: false, ready: false, state: 'disabled', message: 'تم تعطيل محرك Chatterbox عبر CHATTERBOX_TTS_ENABLED=false؛ سيظل Piper المحلي متاحًا.' };
      return this.chatterboxState;
    }
    try {
      if (!fs.existsSync(CHATTERBOX_REQUIREMENTS_FILE)) throw new Error('ملف اعتماديات Chatterbox غير موجود داخل scripts.');
      const python = await this.ensureChatterboxPython(basePython);
      this.chatterboxState = { ...this.chatterboxState, enabled: true, state: 'installing', pythonPathLabel: path.basename(path.dirname(python)), message: 'يتم تثبيت Chatterbox في بيئة مستقلة.' };
      let installed = await this.chatterboxPackageReady(python);
      if (!installed) {
        this.update('preparing', 'تثبيت محرك Chatterbox V3', 78, 'يتم تثبيت نسخة المصدر الرسمية التي تحتوي على محمّل V3 فعلًا. إذا كانت بيئة قديمة تحتوي على حزمة PyPI سابقة، سيستبدلها المشروع تلقائيًا بدل الاكتفاء برقم إصدار متطابق.');
        await run(python, ['-m', 'pip', 'install', '--disable-pip-version-check', '--upgrade', 'pip<27'], { cwd: this.root, timeout: 5 * 60 * 1000, maxOutput: 200000 });
        // Remove a legacy PyPI 0.1.7 build when it lacks the later V3 loader.
        // The isolated Chatterbox environment is project-owned; shared Piper/Whisper packages are untouched.
        await run(python, ['-m', 'pip', 'uninstall', '-y', 'chatterbox-tts'], { cwd: this.root, timeout: 120000, maxOutput: 100000 }).catch(() => {});
        await run(python, ['-m', 'pip', 'install', '--disable-pip-version-check', '-r', CHATTERBOX_REQUIREMENTS_FILE], {
          cwd: this.root, timeout: 35 * 60 * 1000, maxOutput: 600000,
          env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' },
          onOutput: chunk => { if (/Installing collected packages|Successfully installed|Downloading|Collecting|torch/i.test(chunk)) this.update('preparing', 'تثبيت مكتبات Chatterbox وPyTorch', 80, 'جارٍ تنزيل المكتبات الكبيرة داخل البيئة المستقلة للمحرك التعبيري.'); },
        });
        installed = await this.chatterboxPackageReady(python);
      }
      if (!installed) throw new Error('اكتمل تثبيت Chatterbox لكن فحص المكتبة لم ينجح.');
      const autoDownload = !['0', 'false', 'off', 'no'].includes(String(this.env.CHATTERBOX_AUTO_DOWNLOAD ?? 'true').trim().toLowerCase());
      const configuredDevice = String(this.env.CHATTERBOX_DEVICE || 'auto').trim().toLowerCase();
      this.update('preparing', 'تنزيل نموذج الصوت التعبيري', 83, autoDownload ? 'يتم تنزيل أوزان Chatterbox Multilingual V3 إلى مجلد models داخل المشروع (نحو 3.2 جيجابايت للملفات الأساسية).' : 'يتم التحقق من ملفات النموذج المضافة يدويًا.');
      const worker = path.join(this.root, 'scripts', 'chatterbox_tts_worker.py');
      const result = await run(python, [worker, 'prepare', this.chatterboxModelDir, configuredDevice, autoDownload ? 'true' : 'false'], {
        cwd: this.root, timeout: 60 * 60 * 1000, maxOutput: 200000,
        env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8', HF_HUB_DISABLE_TELEMETRY: '1' },
        onOutput: chunk => { if (/Downloading|Fetching|\.safetensors|\.pt|Loading checkpoint/i.test(chunk)) this.update('preparing', 'تنزيل/فحص أوزان Chatterbox V3', 87, 'يجري تنزيل أوزان النموذج أو تحميلها للتحقق من سلامتها.'); },
      });
      const payload = JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1) || '{}');
      if (payload.ok !== true) throw new Error(payload.error || 'لم يجتز نموذج Chatterbox فحص التحميل.');
      const sizeGiB = (Number(payload.totalBytes || 0) / (1024 ** 3)).toFixed(2);
      this.chatterboxState = { enabled: true, ready: true, state: 'ready', model: 'Chatterbox Multilingual V3', modelPathLabel: path.basename(this.chatterboxModelDir), device: payload.device || configuredDevice, totalBytes: Number(payload.totalBytes || 0), sizeGiB, pythonPathLabel: path.basename(path.dirname(python)), message: `النموذج التعبيري جاهز محليًا (${sizeGiB} جيجابايت من الملفات الأساسية) على ${payload.device || configuredDevice}.` };
      return this.chatterboxState;
    } catch (error) {
      this.chatterboxState = { ...this.chatterboxState, enabled: true, ready: false, state: 'unavailable', message: `لم يكتمل محرك Chatterbox: ${safeError(error)}. لم تتوقف تهيئة Whisper/Piper؛ سيستخدم البوت Piper العربي عند توفره.` };
      try { this.log('WARN', `[CHATTERBOX_BOOTSTRAP] ${this.chatterboxState.message}`); } catch {}
      return this.chatterboxState;
    }
  }
  async ensureAudarPython(basePython) {
    const python = path.join(this.audarVenvDir, process.platform === 'win32' ? 'Scripts' : 'bin', process.platform === 'win32' ? 'python.exe' : 'python');
    if (fs.existsSync(python) && (await this.pythonWorks(this.pythonCommand(python))).ok) return python;
    fs.rmSync(this.audarVenvDir, { recursive: true, force: true });
    this.update('preparing', 'إنشاء بيئة Audar مستقلة', 75, 'إنشاء Python منفصل لمحرك Audar وllama.cpp وNeuCodec حتى لا تتعارض مكتباته مع Whisper/Piper.');
    fs.mkdirSync(path.dirname(this.audarVenvDir), { recursive: true });
    await run(basePython, ['-m', 'venv', this.audarVenvDir], { cwd: this.root, timeout: 120000, maxOutput: 100000 });
    if (!(await this.pythonWorks(this.pythonCommand(python))).ok) throw new Error('لم تُنشأ بيئة Python المستقلة لمحرك Audar.');
    return python;
  }
  async audarPackagesReady(python) {
    const probe = [
      'import importlib.util,json',
      'mods={name: importlib.util.find_spec(name) is not None for name in ("llama_cpp","neucodec","soundfile","torch","librosa","huggingface_hub")}',
      'print(json.dumps({"ready":all(mods.values()),"modules":mods}))',
    ].join('\n');
    try {
      const result = await run(python, ['-c', probe], { cwd: this.root, timeout: 30000, maxOutput: 20000 });
      return JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1) || '{}');
    } catch { return { ready: false, modules: {} }; }
  }
  async runAudarWorker(python, action, autoDownload = true) {
    const worker = path.join(this.root, 'scripts', 'audar_tts_worker.py');
    if (!fs.existsSync(worker)) throw new Error('scripts/audar_tts_worker.py غير موجود داخل المشروع.');
    const args = [worker, action, this.audarModelDir, this.audarVoiceDir, this.audarCacheDir, this.audarTier, autoDownload ? 'true' : 'false', String(this.env.AUDAR_TTS_GPU_LAYERS || '0'), String(this.env.AUDAR_TTS_DEFAULT_VOICE || 'demo_male_1')];
    const result = await run(python, args, {
      cwd: this.root, timeout: action === 'prepare' ? 90 * 60 * 1000 : 30 * 60 * 1000, maxOutput: 250000,
      env: { ...process.env, ...this.env, HF_HOME: this.audarCacheDir, AUDAR_TTS_CODEC_DIR: this.audarCodecDir, AUDAR_TTS_MODEL_FILE: String(this.env.AUDAR_TTS_MODEL_FILE || ''), HF_HUB_DISABLE_TELEMETRY: '1', PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' },
      onOutput: chunk => {
        if (/Downloading|Fetching|\.gguf|neucodec|\.wav/i.test(chunk)) this.update('preparing', 'تنزيل أوزان Audar والأصوات المرجعية', 90, 'يتم تنزيل نموذج الكلام العربي وNeuCodec وستة أصوات اصطناعية محليًا إلى مجلد models.');
      },
    });
    const payload = JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1) || '{}');
    if (payload.ok !== true) throw new Error(String(payload.error || `فشل تجهيز Audar (${action}).`));
    return payload;
  }
  async ensureAudar(basePython) {
    const enabled = !['0', 'false', 'off', 'no'].includes(String(this.env.AUDAR_TTS_ENABLED ?? 'true').trim().toLowerCase());
    if (!enabled) {
      this.audarState = { ...this.audarState, enabled: false, ready: false, state: 'disabled', message: 'تم تعطيل Audar عبر AUDAR_TTS_ENABLED=false؛ سيظل Piper المحلي متاحًا.' };
      return this.audarState;
    }
    try {
      if (!fs.existsSync(AUDAR_REQUIREMENTS_FILE)) throw new Error('ملف اعتماديات Audar غير موجود.');
      const python = await this.ensureAudarPython(basePython);
      this.audarState = { ...this.audarState, enabled: true, state: 'installing', pythonPathLabel: path.basename(path.dirname(python)), message: 'تجهيز مكتبات Audar وllama.cpp داخل بيئة مستقلة.' };
      let packages = await this.audarPackagesReady(python);
      if (!packages.ready) {
        this.update('preparing', 'تثبيت مكتبات Audar', 78, 'تثبيت PyTorch وNeuCodec ومكتبات معالجة الصوت محليًا.');
        await run(python, ['-m', 'pip', 'install', '--disable-pip-version-check', '--upgrade', 'pip<27'], { cwd: this.root, timeout: 5 * 60 * 1000, maxOutput: 200000 });
        await run(python, ['-m', 'pip', 'install', '--disable-pip-version-check', '-r', AUDAR_REQUIREMENTS_FILE], {
          cwd: this.root, timeout: 35 * 60 * 1000, maxOutput: 600000,
          env: { ...process.env, HF_HUB_DISABLE_TELEMETRY: '1', PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' },
          onOutput: chunk => { if (/Installing collected packages|Successfully installed|Downloading|Collecting|torch/i.test(chunk)) this.update('preparing', 'تثبيت PyTorch وNeuCodec', 81, 'جارٍ تنزيل مكتبات Audar داخل البيئة المعزولة.'); },
        });
        // Official CPU wheels avoid requiring Visual Studio/CMake on Windows.
        await run(python, ['-m', 'pip', 'install', '--disable-pip-version-check', '--only-binary=llama-cpp-python', '--extra-index-url', AUDAR_CPU_WHEEL_INDEX, 'llama-cpp-python>=0.3.32,<0.4'], {
          cwd: this.root, timeout: 25 * 60 * 1000, maxOutput: 500000,
          env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' },
          onOutput: chunk => { if (/Installing collected packages|Successfully installed|Downloading|Collecting/i.test(chunk)) this.update('preparing', 'تثبيت llama.cpp CPU', 83, 'تجهيز محرك GGUF المحلي دون الحاجة إلى مترجم C++ على Windows عند توفر wheel متوافق.'); },
        });
        packages = await this.audarPackagesReady(python);
      }
      if (!packages.ready) throw new Error('حزم Audar لم تجتز فحص الاستيراد: ' + JSON.stringify(packages.modules || {}));
      const autoDownload = !['0', 'false', 'off', 'no'].includes(String(this.env.AUDAR_TTS_AUTO_DOWNLOAD ?? 'true').trim().toLowerCase());
      this.update('preparing', 'تجهيز نموذج Audar العربي', 87, autoDownload ? 'تنزيل ملف Audar-TTS Q5_K_M والأصوات الستة وNeuCodec؛ حجم Turbo نحو 1.2 جيجابايت للأوزان وحدها.' : 'فحص النموذج الذي أضفته يدويًا داخل مجلد models/audar-tts.');
      const payload = await this.runAudarWorker(python, 'prepare', autoDownload);
      const sizeGiB = (Number(payload.modelBytes || 0) / (1024 ** 3)).toFixed(2);
      this.audarState = { enabled: true, ready: true, state: 'ready', tier: payload.tier, model: `Audar-TTS-V1-${String(payload.tier).toUpperCase()} Q5_K_M`, modelPathLabel: path.basename(payload.modelPath || this.audarModelDir), modelBytes: Number(payload.modelBytes || 0), sizeGiB, voiceCount: Number(payload.voiceCount || 0), pythonPathLabel: path.basename(path.dirname(python)), message: `تم تجهيز أوزان Audar (${sizeGiB} جيجابايت) و${Number(payload.voiceCount || 0)} أصوات مرجعية وNeuCodec. سيختبر عامل التوليد الاستدلال العربي فعليًا قبل قبول أول طلب صوتي.` };
      return this.audarState;
    } catch (error) {
      this.audarState = { ...this.audarState, enabled: true, ready: false, state: 'unavailable', message: `لم يكتمل Audar تلقائيًا: ${safeError(error)}. أضف ملف GGUF يدويًا حسب AUDAR_TTS_SETUP_AR.md أو استخدم Piper الاحتياطي.` };
      try { this.log('WARN', `[AUDAR_BOOTSTRAP] ${this.audarState.message}`); } catch {}
      return this.audarState;
    }
  }
  async ensurePiperModel() {
    const target = this.piperModel; const config = `${target}.json`;
    let modelValid = false;
    if (fs.existsSync(target) && fs.statSync(target).size > 10_000_000) modelValid = (await sha256File(target).catch(() => '')) === PIPER_MODEL_SHA256;
    let configValid = false;
    try { const json = JSON.parse(fs.readFileSync(config, 'utf8')); configValid = Boolean(json?.audio && json?.phoneme_type); } catch {}
    if (modelValid && configValid) return;
    this.update('preparing', 'تنزيل الصوت العربي المحلي', 43, 'يتم تنزيل نموذج Piper العربي والتحقق من بصمته.');
    await this.download(PIPER_MODEL_URL, target, { maxBytes: 120 * 1024 * 1024, expectedSha256: PIPER_MODEL_SHA256, progressBase: 43, progressSpan: 12 });
    await this.download(`${PIPER_MODEL_URL}.json`, config, { maxBytes: 4 * 1024 * 1024, progressBase: 55, progressSpan: 2 });
    const parsed = JSON.parse(fs.readFileSync(config, 'utf8'));
    if (!parsed?.audio || !parsed?.phoneme_type) throw new Error('نموذج الصوت العربي نُزّل لكن ملف إعداداته غير صالح.');
  }
  async runWorker(python, action, args = [], timeout = 30000) {
    const worker = path.join(this.root, 'scripts', 'voice_worker.py');
    const result = await run(python, [worker, action, ...args], { cwd: this.root, timeout, maxOutput: 150000, env: { ...process.env, ...this.env, WHISPER_PY_MODEL: this.modelSize, WHISPER_PY_MODEL_PATH: this.modelDir, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' } });
    const line = result.stdout.trim().split(/\r?\n/).filter(Boolean).at(-1) || '{}';
    const payload = JSON.parse(line);
    if (payload.ok !== true) throw new Error(String(payload.error || `فشل عامل الصوت: ${action}`));
    return payload;
  }
  writeEnv(values) {
    const envFile = path.join(this.root, '.env');
    let source = fs.existsSync(envFile) ? fs.readFileSync(envFile, 'utf8') : '';
    const lines = source.split(/\r?\n/);
    for (const [key, value] of Object.entries(values)) {
      this.env[key] = String(value);
      let found = false;
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim().replace(/^export\s+/, '');
        const equalsAt = line.indexOf('=');
        if (equalsAt > 0 && line.slice(0, equalsAt).trim() === key) { lines[i] = `${key}=${JSON.stringify(String(value))}`; found = true; }
      }
      if (!found) lines.push(`${key}=${JSON.stringify(String(value))}`);
    }
    source = lines.join('\n').replace(/\n+$/, '') + '\n';
    const temp = `${envFile}.voice-${process.pid}.tmp`;
    fs.writeFileSync(temp, source, { mode: 0o600 }); fs.renameSync(temp, envFile);
  }
  async runSetup() {
    this.update('preparing', 'بدء التهيئة التلقائية', 1, 'ستُجهز المكتبات والنماذج داخل المشروع. أول تشغيل يحتاج اتصال إنترنت ومساحة تخزين.');
    const python = await this.ensurePython();
    const piper = await this.ensurePackages(python);
    this.update('preparing', 'تجهيز نموذج التفريغ المحلي', 32, 'إذا لم يكن نموذج Faster-Whisper موجودًا فسيتم تنزيله الآن.');
    const whisperReady = fs.existsSync(path.join(this.modelDir, 'model.bin')) && fs.existsSync(path.join(this.modelDir, 'config.json'));
    if (!whisperReady) await this.runWorker(python, 'prepare', [this.modelSize, this.modelDir], 45 * 60 * 1000);
    this.update('preparing', 'فحص نموذج التفريغ', 60, 'يتم تحميل النموذج المحلي للتأكد من اكتماله.');
    // Reuse the worker status and FFmpeg bundled by imageio-ffmpeg.
    const status = await this.runWorker(python, 'status', [], 30000);
    const ffmpegPath = status.ffmpegPath;
    if (!ffmpegPath || !fs.existsSync(ffmpegPath)) throw new Error('تعذر العثور على FFmpeg من حزمة imageio-ffmpeg.');
    await this.ensurePiperModel();
    const envValues = {
      VOICE_PYTHON_BIN: python,
      WHISPER_BACKEND: ['openai-compatible'].includes(String(this.env.WHISPER_BACKEND || '').toLowerCase()) ? this.env.WHISPER_BACKEND : 'python-faster-whisper',
      WHISPER_PY_MODEL: this.modelSize,
      WHISPER_PY_MODEL_PATH: this.modelDir,
      WHISPER_PY_BEAM_SIZE: String(this.env.WHISPER_PY_BEAM_SIZE || '5'),
      WHISPER_PY_VAD: String(this.env.WHISPER_PY_VAD || 'true'),
      WHISPER_PY_VAD_THRESHOLD: String(this.env.WHISPER_PY_VAD_THRESHOLD || '0.5'),
      WHISPER_PY_MIN_SILENCE_MS: String(this.env.WHISPER_PY_MIN_SILENCE_MS || '450'),
      WHISPER_PY_LOG_PROB_THRESHOLD: String(this.env.WHISPER_PY_LOG_PROB_THRESHOLD || '-1.0'),
      WHISPER_PY_NO_SPEECH_THRESHOLD: String(this.env.WHISPER_PY_NO_SPEECH_THRESHOLD || '0.6'),
      WHISPER_PY_COMPRESSION_RATIO_THRESHOLD: String(this.env.WHISPER_PY_COMPRESSION_RATIO_THRESHOLD || '2.4'),
      WHISPER_PY_CONDITION_ON_PREVIOUS_TEXT: String(this.env.WHISPER_PY_CONDITION_ON_PREVIOUS_TEXT || 'false'),
      TTS_BACKEND: normalizeTtsBackend(this.env.TTS_BACKEND || 'local'),
      PIPER_BIN: piper,
      PIPER_MODEL_PATH: this.piperModel,
      FFMPEG_BIN: ffmpegPath,
    };
    this.writeEnv(envValues);
    this.update('preparing', 'اختبار النطق والتحويل والتفريغ', 72, 'يتم توليد صوت عربي فعلي وتحويله إلى OGG/Opus ثم تفريغه محليًا قبل إعلان الجاهزية.');
    const smoke = await this.runWorker(python, 'voice-smoke-test', [piper, this.piperModel, ffmpegPath, this.modelDir], 7 * 60 * 1000);
    if (smoke.piper !== true || smoke.ffmpegOpus !== true || smoke.fasterWhisper !== true || !String(smoke.transcript || '').trim()) throw new Error('اختبار الصوت الفعلي لم يؤكد نجاح جميع مراحل التوليد والتحويل والتفريغ.');
    // Audar is the default expressive Arabic/English engine; its setup is best-effort
    // so Whisper/Piper remain usable if a wheel/model download is unavailable.
    await this.ensureAudar(python);
    // Chatterbox is a genuinely optional multilingual extra, never an automatic 3+ GB download.
    if (['1', 'true', 'on', 'yes'].includes(String(this.env.CHATTERBOX_TTS_ENABLED || 'false').trim().toLowerCase())) {
      await this.ensureChatterbox(python);
    } else {
      this.chatterboxState = { ...this.chatterboxState, enabled: false, ready: false, state: 'disabled', message: 'Chatterbox معطل افتراضيًا؛ Audar هو المحرك المحلي الأساسي للعربية والإنجليزية.' };
    }
    const audarPython = path.join(this.audarVenvDir, process.platform === 'win32' ? 'Scripts' : 'bin', process.platform === 'win32' ? 'python.exe' : 'python');
    const ttsPython = path.join(this.ttsVenvDir, process.platform === 'win32' ? 'Scripts' : 'bin', process.platform === 'win32' ? 'python.exe' : 'python');
    const envExtras = {
      AUDAR_TTS_ENABLED: String(this.env.AUDAR_TTS_ENABLED ?? 'true'),
      AUDAR_TTS_AUTO_DOWNLOAD: String(this.env.AUDAR_TTS_AUTO_DOWNLOAD ?? 'true'),
      AUDAR_TTS_TIER: this.audarTier,
      AUDAR_TTS_PYTHON_BIN: fs.existsSync(audarPython) ? audarPython : '',
      AUDAR_TTS_MODEL_DIR: this.audarModelDir,
      AUDAR_TTS_MODEL_FILE: String(this.env.AUDAR_TTS_MODEL_FILE || ''),
      AUDAR_TTS_VOICE_DIR: this.audarVoiceDir,
      AUDAR_TTS_CACHE_DIR: this.audarCacheDir,
      AUDAR_TTS_CODEC_DIR: this.audarCodecDir,
      AUDAR_TTS_GPU_LAYERS: String(this.env.AUDAR_TTS_GPU_LAYERS || '0'),
      AUDAR_TTS_DEFAULT_VOICE: String(this.env.AUDAR_TTS_DEFAULT_VOICE || 'demo_male_1'),
      CHATTERBOX_TTS_ENABLED: String(this.env.CHATTERBOX_TTS_ENABLED ?? 'false'),
      CHATTERBOX_AUTO_DOWNLOAD: String(this.env.CHATTERBOX_AUTO_DOWNLOAD ?? 'false'),
      CHATTERBOX_PYTHON_BIN: fs.existsSync(ttsPython) ? ttsPython : '',
      CHATTERBOX_MODEL_PATH: this.chatterboxModelDir,
      CHATTERBOX_DEVICE: String(this.env.CHATTERBOX_DEVICE || 'auto'),
    };
    this.writeEnv(envExtras);
    const finalMessage = this.audarState.ready
      ? `تم إعداد Whisper وPiper، وتجهيز Audar ${String(this.audarState.tier).toUpperCase()} محليًا. ${this.audarState.message}`
      : `تم إعداد Whisper/Piper، لكن Audar غير جاهز. سيعمل Piper العربي احتياطيًا عند توفره. ${this.audarState.message}`;
    this.update('ready', 'اكتمل إعداد الصوت تلقائيًا', 100, finalMessage);
    return this.publicStatus();
  }
}

module.exports = { VoiceBootstrap, REQUIRED_PACKAGES, PYTHON_VERSION, PYTHON_INSTALLER_SHA256, PIPER_MODEL_SHA256, normalizeTtsBackend, isCompatiblePyAv };
