'use strict';

function canExecuteTranscript(result) {
  const quality = result?.quality;
  return quality?.status === 'clear' && quality?.actionable === true && quality?.metadataSufficient === true && Boolean(String(result?.transcript || result?.text || '').trim());
}

function transcriptReviewRequired(result) {
  return !canExecuteTranscript(result);
}

module.exports = { canExecuteTranscript, transcriptReviewRequired };
