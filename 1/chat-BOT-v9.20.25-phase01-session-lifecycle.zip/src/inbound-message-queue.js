'use strict';

class InboundMessageQueue {
  constructor({ maxConcurrentSessions = 3, maxPendingPerSession = 40, dedupeTtlMs = 600000, now = Date.now, onError = () => {} } = {}) {
    this.maxConcurrentSessions = Math.max(1, Math.min(16, Number(maxConcurrentSessions) || 3));
    this.maxPendingPerSession = Math.max(1, Math.min(500, Number(maxPendingPerSession) || 40));
    this.dedupeTtlMs = Math.max(1000, Number(dedupeTtlMs) || 600000);
    this.now = now;
    this.onError = onError;
    this.queues = new Map();
    this.activeSessions = new Set();
    this.keys = new Map();
    this.activeCount = 0;
    this.closed = false;
    this.pumpQueued = false;
  }

  enqueue(sessionId, key, run, { maxWaitMs = 60000, maxPendingPerSession = this.maxPendingPerSession } = {}) {
    const sid = String(sessionId || 'main');
    if (this.closed) return Promise.resolve({ accepted: false, reason: 'closed' });
    if (typeof run !== 'function') return Promise.resolve({ accepted: false, reason: 'invalid-task' });
    this.pruneKeys();
    const eventKey = key ? `${sid}|${String(key)}` : '';
    if (eventKey && this.keys.has(eventKey)) return Promise.resolve({ accepted: false, reason: 'duplicate' });
    const queue = this.queues.get(sid) || [];
    const cap = Math.max(1, Math.min(500, Number(maxPendingPerSession) || this.maxPendingPerSession));
    if (queue.length + (this.activeSessions.has(sid) ? 1 : 0) >= cap) return Promise.resolve({ accepted: false, reason: 'queue-full' });

    const enqueuedAt = this.now();
    return new Promise((resolve, reject) => {
      const item = { run, resolve, reject, key: eventKey, enqueuedAt, maxWaitMs: Math.max(1000, Number(maxWaitMs) || 60000) };
      if (eventKey) this.keys.set(eventKey, { at: enqueuedAt, status: 'queued' });
      queue.push(item);
      this.queues.set(sid, queue);
      this.schedulePump();
    });
  }

  pruneKeys() {
    const cutoff = this.now() - this.dedupeTtlMs;
    for (const [key, record] of this.keys) if (!record || Number(record.at) < cutoff) this.keys.delete(key);
    while (this.keys.size > 10000) this.keys.delete(this.keys.keys().next().value);
  }

  schedulePump() {
    if (this.pumpQueued) return;
    this.pumpQueued = true;
    queueMicrotask(() => { this.pumpQueued = false; this.pump(); });
  }

  pump() {
    if (this.activeCount >= this.maxConcurrentSessions) return;
    for (const [sid, queue] of this.queues) {
      if (this.activeCount >= this.maxConcurrentSessions) break;
      if (this.activeSessions.has(sid) || !queue.length) continue;
      const item = queue.shift();
      if (!queue.length) this.queues.delete(sid);
      this.activeSessions.add(sid);
      this.activeCount++;
      if (item.key) this.keys.set(item.key, { at: item.enqueuedAt, status: 'running' });
      Promise.resolve().then(async () => {
        const waitedMs = this.now() - item.enqueuedAt;
        if (waitedMs > item.maxWaitMs) {
          item.resolve({ accepted: false, reason: 'queue-expired', waitedMs });
          return;
        }
        const result = await item.run({ waitedMs, enqueuedAt: item.enqueuedAt });
        item.resolve({ accepted: true, reason: 'processed', waitedMs, result });
      }).catch(error => {
        try { this.onError(sid, error); } catch {}
        item.reject(error);
      }).finally(() => {
        if (item.key) this.keys.set(item.key, { at: this.now(), status: 'done' });
        this.activeSessions.delete(sid);
        this.activeCount = Math.max(0, this.activeCount - 1);
        this.schedulePump();
      });
    }
  }

  async close({ drain = true, timeoutMs = 15000 } = {}) {
    this.closed = true;
    if (!drain) {
      for (const [sid, queue] of this.queues) for (const item of queue) item.resolve({ accepted: false, reason: 'closed' });
      this.queues.clear();
      return { drained: false, active: this.activeCount, dropped: true };
    }
    const deadline = this.now() + Math.max(0, Number(timeoutMs) || 0);
    while ((this.activeCount > 0 || [...this.queues.values()].some(queue => queue.length)) && this.now() < deadline) {
      this.schedulePump();
      await new Promise(resolve => setTimeout(resolve, 20));
    }
    const drained = this.activeCount === 0 && [...this.queues.values()].every(queue => queue.length === 0);
    if (!drained) {
      for (const queue of this.queues.values()) for (const item of queue) item.resolve({ accepted: false, reason: 'close-timeout' });
      this.queues.clear();
    }
    return { drained, active: this.activeCount, dropped: !drained };
  }

  stats() {
    return { activeSessions: this.activeCount, queuedSessions: this.queues.size, queued: [...this.queues.values()].reduce((sum, queue) => sum + queue.length, 0), dedupeKeys: this.keys.size, closed: this.closed };
  }
}

module.exports = { InboundMessageQueue };
