'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

function isPidAlive(pid) {
  const value = Number(pid);
  if (!Number.isInteger(value) || value <= 0) return false;
  try { process.kill(value, 0); return true; }
  catch (error) { return error?.code === 'EPERM'; }
}

function readLock(filePath) {
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    const value = JSON.parse(raw);
    return value && typeof value === 'object' ? value : null;
  } catch { return null; }
}

function lockOwnerAlive(value) {
  return isPidAlive(value?.pid) || isPidAlive(value?.browserPid);
}

function canRecoverLock(filePath, owner, { corruptGraceMs = 15000 } = {}) {
  if (owner) return !lockOwnerAlive(owner);
  // A freshly created lock may be between the exclusive open and its metadata write.
  // Never steal an unreadable young lock: it may belong to a process currently starting.
  try {
    const ageMs = Date.now() - fs.statSync(filePath).mtimeMs;
    return ageMs >= Math.max(1000, Number(corruptGraceMs) || 15000);
  } catch (error) {
    return error?.code === 'ENOENT';
  }
}

function lockError(filePath, owner) {
  const error = new Error(`جلسة WhatsApp محجوزة بالفعل بواسطة عملية أخرى (PID ${Number(owner?.pid) || 'غير معروف'}). لا يمكن فتح ملف LocalAuth نفسه من نسختين متزامنتين. أوقف النسخة الأخرى أو انتظر تحرير القفل.`);
  error.code = 'WHATSAPP_SESSION_PROCESS_LOCKED';
  error.lockPath = filePath;
  error.ownerPid = Number(owner?.pid) || null;
  return error;
}

function recoveryGatePath(filePath) { return `${filePath}.recovery`; }

function recoveryGateError(filePath) {
  const gatePath = recoveryGatePath(filePath);
  const owner = readLock(path.join(gatePath, 'owner.json'));
  const error = new Error(`تجري عملية استعادة قفل جلسة WhatsApp أو توقفت أثناءها. لن أغيّر ملف LocalAuth بالتوازي. تحقق من توقف PID ${Number(owner?.pid) || 'غير معروف'}، ثم افحص مجلد الاستعادة ${gatePath} قبل إزالته يدويًا.`);
  error.code = 'WHATSAPP_SESSION_RECOVERY_LOCKED';
  error.lockPath = filePath;
  error.recoveryPath = gatePath;
  error.ownerPid = Number(owner?.pid) || null;
  return error;
}

function acquireRecoveryGate(filePath) {
  const gatePath = recoveryGatePath(filePath);
  try { fs.mkdirSync(gatePath, { mode: 0o700 }); }
  catch (error) {
    if (error?.code === 'EEXIST') throw recoveryGateError(filePath);
    throw error;
  }
  const owner = {
    version: 1,
    pid: process.pid,
    token: crypto.randomUUID(),
    acquiredAt: new Date().toISOString(),
  };
  try {
    fs.writeFileSync(path.join(gatePath, 'owner.json'), JSON.stringify(owner), { encoding: 'utf8', flag: 'wx', mode: 0o600 });
  } catch (error) {
    try { fs.rmSync(gatePath, { recursive: true, force: true }); } catch {}
    throw error;
  }
  let released = false;
  return {
    release() {
      if (released) return false;
      released = true;
      const current = readLock(path.join(gatePath, 'owner.json'));
      if (current?.token !== owner.token) return false;
      try { fs.rmSync(gatePath, { recursive: true, force: true }); return true; }
      catch (error) { return error?.code === 'ENOENT'; }
    },
  };
}

function writeLockFile(filePath, metadata, { allowRecoveryGate = false } = {}) {
  const token = crypto.randomUUID();
  const initial = {
    version: 1,
    token,
    pid: process.pid,
    browserPid: null,
    sessionId: String(metadata.sessionId || '').slice(0, 100),
    acquiredAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  const fd = fs.openSync(filePath, 'wx', 0o600);
  try {
    fs.writeFileSync(fd, JSON.stringify(initial), 'utf8');
    fs.fsyncSync(fd);
    // A process may have passed the first gate check just before a stale-lock
    // recovery began. Such an in-flight claimant must yield to the recovery owner.
    if (!allowRecoveryGate && fs.existsSync(recoveryGatePath(filePath))) {
      try { fs.closeSync(fd); } catch {}
      const current = readLock(filePath);
      if (current?.token === token) { try { fs.unlinkSync(filePath); } catch {} }
      throw recoveryGateError(filePath);
    }
  } catch (error) {
    try { fs.closeSync(fd); } catch {}
    const current = readLock(filePath);
    if (current?.token === token) { try { fs.unlinkSync(filePath); } catch {} }
    throw error;
  }

  let released = false;
  const current = { ...initial };
  return {
    filePath,
    token,
    update(patch = {}) {
      if (released) return false;
      Object.assign(current, patch, { updatedAt: new Date().toISOString() });
      try {
        fs.ftruncateSync(fd, 0);
        fs.writeSync(fd, JSON.stringify(current), 0, 'utf8');
        fs.fsyncSync(fd);
        return true;
      } catch { return false; }
    },
    release() {
      if (released) return false;
      released = true;
      try { fs.closeSync(fd); } catch {}
      const owner = readLock(filePath);
      if (owner?.token !== token) return false;
      try { fs.unlinkSync(filePath); return true; }
      catch (error) { return error?.code === 'ENOENT'; }
    },
    get released() { return released; },
  };
}

function acquireSessionProcessLock(filePath, metadata = {}) {
  const target = path.resolve(filePath);
  fs.mkdirSync(path.dirname(target), { recursive: true });

  for (let attempt = 0; attempt < 4; attempt++) {
    if (fs.existsSync(recoveryGatePath(target))) throw recoveryGateError(target);
    try {
      return writeLockFile(target, metadata);
    } catch (error) {
      if (error?.code !== 'EEXIST') throw error;
    }

    const owner = readLock(target);
    if (!canRecoverLock(target, owner)) throw lockError(target, owner || {});

    // Serialize stale-lock recovery. All regular claims check this gate before and
    // after creating their lock file; a claimant racing the gate therefore yields.
    const gate = acquireRecoveryGate(target);
    try {
      const currentOwner = readLock(target);
      if (fs.existsSync(target) && !canRecoverLock(target, currentOwner)) {
        throw lockError(target, currentOwner || {});
      }
      try { fs.unlinkSync(target); }
      catch (error) { if (error?.code !== 'ENOENT') throw error; }

      // A claimant that passed its first gate check just before the gate was created
      // may win the wx race. It will notice the gate and remove only its own token.
      let lastError = null;
      for (let recoveryAttempt = 0; recoveryAttempt < 20; recoveryAttempt++) {
        try { return writeLockFile(target, metadata, { allowRecoveryGate: true }); }
        catch (error) {
          if (error?.code !== 'EEXIST') throw error;
          lastError = error;
          const inFlightOwner = readLock(target);
          if (inFlightOwner && !lockOwnerAlive(inFlightOwner)) {
            try { fs.unlinkSync(target); } catch (unlinkError) { if (unlinkError?.code !== 'ENOENT') throw unlinkError; }
          } else {
            // Give an already-running claimant a short opportunity to observe the gate
            // and yield. Do not remove a live owner's file.
            Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 10);
          }
        }
      }
      throw lockError(target, readLock(target) || (lastError ? {} : {}));
    } finally {
      gate.release();
    }
  }
  throw recoveryGateError(target);
}

module.exports = { acquireSessionProcessLock, isPidAlive, readLock, lockOwnerAlive, canRecoverLock, recoveryGatePath };
