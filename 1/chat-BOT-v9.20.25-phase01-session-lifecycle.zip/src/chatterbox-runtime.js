'use strict';

const path = require('node:path');
const crypto = require('node:crypto');
const { spawn: defaultSpawn } = require('node:child_process');
const readline = require('node:readline');

class ChatterboxRuntime {
  constructor({ python, worker, modelPath, device = 'auto', cwd = process.cwd(), spawnImpl = defaultSpawn, startupTimeoutMs = 12 * 60 * 1000, logger = () => {} } = {}) {
    this.python = python;
    this.worker = worker;
    this.modelPath = modelPath;
    this.device = device;
    this.cwd = cwd;
    this.spawn = spawnImpl;
    this.startupTimeoutMs = Math.max(30_000, Math.min(20 * 60 * 1000, Number(startupTimeoutMs) || 12 * 60 * 1000));
    this.log = logger;
    this.child = null;
    this.rl = null;
    this.startPromise = null;
    this.pending = new Map();
    this.stderr = '';
    this.readyInfo = null;
  }

  async ensureStarted() {
    if (this.child && this.readyInfo && !this.child.killed && this.child.exitCode == null) return this.readyInfo;
    if (this.startPromise) return this.startPromise;
    if (!this.python || !this.worker || !this.modelPath) throw new Error('إعدادات تشغيل Chatterbox غير مكتملة.');

    this.startPromise = new Promise((resolve, reject) => {
      let settled = false;
      let timer;
      const finish = (error, value) => {
        if (settled) return;
        settled = true;
        if (timer) clearTimeout(timer);
        if (error) reject(error); else resolve(value);
      };
      let child;
      try {
        child = this.spawn(this.python, [this.worker, 'serve', this.modelPath, this.device], {
          cwd: this.cwd,
          windowsHide: true,
          stdio: ['pipe', 'pipe', 'pipe'],
          env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8', TOKENIZERS_PARALLELISM: 'false' },
        });
      } catch (error) {
        finish(new Error(`تعذر بدء محرك Chatterbox المحلي: ${String(error?.message || error).slice(0, 220)}`));
        return;
      }
      this.child = child;
      this.readyInfo = null;
      this.stderr = '';
      this.rl = readline.createInterface({ input: child.stdout });
      this.rl.on('line', line => this.handleLine(line, finish));
      child.stderr?.on('data', chunk => {
        this.stderr = (this.stderr + String(chunk)).slice(-8000);
      });
      child.once('error', error => {
        finish(new Error(`تعطل عامل Chatterbox: ${String(error?.message || error).slice(0, 220)}`));
        this.failAll(error);
      });
      child.once('close', code => {
        const detail = this.stderr.trim().slice(-900);
        const error = new Error(`توقف عامل Chatterbox (رمز ${code ?? 'غير معروف'}). ${detail}`.slice(0, 1200));
        finish(error);
        this.failAll(error);
        this.resetChild();
      });
      timer = setTimeout(() => {
        const error = new Error('انتهت مهلة تحميل نموذج Chatterbox داخل الذاكرة. تحقق من الذاكرة وذاكرة GPU، وسيعود البوت إلى Piper عند توفره.');
        try { child.kill(); } catch {}
        finish(error);
        this.failAll(error);
      }, this.startupTimeoutMs);
      timer.unref?.();
    }).finally(() => { this.startPromise = null; });
    return this.startPromise;
  }

  handleLine(line, finishStart) {
    let message;
    try { message = JSON.parse(String(line || '')); }
    catch { this.log('WARN', `[CHATTERBOX] تجاهلت سطرًا غير JSON: ${String(line).slice(0, 180)}`); return; }
    if (message.event === 'ready' || (message.ok === false && !this.readyInfo)) {
      if (message.ok !== true) {
        const error = new Error(String(message.error || 'تعذر تحميل نموذج Chatterbox.'));
        finishStart(error);
        return;
      }
      this.readyInfo = message;
      finishStart(null, message);
      return;
    }
    const id = String(message.requestId || '');
    const pending = this.pending.get(id);
    if (!pending) return;
    clearTimeout(pending.timer);
    this.pending.delete(id);
    if (message.ok !== true) pending.reject(new Error(String(message.error || 'فشل توليد الصوت عبر Chatterbox.').slice(0, 600)));
    else pending.resolve(message);
  }

  async generate({ text, segments = [], languageId = 'ar', outputPath, exaggeration = 0.55, cfgWeight = 0.45, temperature = 0.8, timeoutMs = 240000 } = {}) {
    await this.ensureStarted();
    if (!this.child || !this.readyInfo) throw new Error('عامل Chatterbox ليس جاهزًا بعد.');
    const requestId = crypto.randomUUID();
    const timeout = Math.max(15_000, Math.min(15 * 60 * 1000, Number(timeoutMs) || 240_000));
    const response = new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(requestId);
        const error = new Error('انتهت مهلة توليد الصوت عبر Chatterbox. سيحاول البوت استخدام محرك Piper الاحتياطي إن كان جاهزًا.');
        reject(error);
        try { this.child?.kill(); } catch {}
      }, timeout);
      timer.unref?.();
      this.pending.set(requestId, { resolve, reject, timer });
      const payload = JSON.stringify({ requestId, text, segments, languageId, outputPath, exaggeration, cfgWeight, temperature });
      this.child.stdin.write(`${payload}\n`, error => {
        if (!error) return;
        const pending = this.pending.get(requestId);
        if (!pending) return;
        clearTimeout(pending.timer);
        this.pending.delete(requestId);
        pending.reject(new Error(`تعذر إرسال طلب إلى Chatterbox: ${String(error.message || error).slice(0, 180)}`));
      });
    });
    return response;
  }

  failAll(error) {
    for (const [id, pending] of this.pending) {
      clearTimeout(pending.timer);
      pending.reject(error instanceof Error ? error : new Error(String(error || 'توقف عامل Chatterbox.')));
      this.pending.delete(id);
    }
  }

  resetChild() {
    try { this.rl?.close(); } catch {}
    this.rl = null;
    this.child = null;
    this.readyInfo = null;
  }

  shutdown() {
    const child = this.child;
    this.failAll(new Error('تم إيقاف محرك Chatterbox مع إغلاق البوت.'));
    this.resetChild();
    try { child?.kill(); } catch {}
    return true;
  }
}

module.exports = { ChatterboxRuntime };
