# إعداد Chatterbox Multilingual V3 يدويًا (Windows / Linux)

## الطريقة الافتراضية

عند أول تشغيل لـ Chat BOT، يحاول المشروع تلقائيًا إنشاء البيئة المعزولة `.voice-tts-venv`، تثبيت اعتماديات `chatterbox-tts`، ثم تنزيل أوزان Chatterbox V3 إلى:

`models/chatterbox-multilingual-v3`

لا يحتاج المستخدم إلى تشغيل ملف صوت مساعد. يبقى البوت متاحًا أثناء التهيئة. يُعاد استخدام البيئة والملفات في التشغيل التالي ولا يُعاد تنزيل النموذج إذا اكتملت الملفات. إذا تعذر تشغيل المحرك أو كانت الذاكرة غير كافية، يحتفظ المشروع بمحرك Piper العربي كخطة احتياطية.

**المساحة:** أوزان النموذج الأساسية تقارب 3.2 جيجابايت، بخلاف مكتبات Python وPyTorch ومساحة الكاش. يلزم الإنترنت للتنزيل الأول فقط، وبعدها يكون توليد الصوت محليًا. يفضّل وجود GPU متوافق وذاكرة كافية؛ على CPU قد يكون التوليد بطيئًا.

## رابط النموذج الرسمي

- صفحة النموذج والملفات: https://huggingface.co/ResembleAI/chatterbox
- الكود الرسمي: https://github.com/resemble-ai/chatterbox
- نسخة محمّل V3 المثبتة في المشروع: https://github.com/resemble-ai/chatterbox/commit/3f35dfc8fbe63e5b29793289dc68f1875bb317a5
- نسخة ملفات النموذج المثبتة: https://huggingface.co/ResembleAI/chatterbox/commit/5bb1f6ee58e50c3b8d408bc82a6d3740c2db6e18

**تنبيه توافق:** لا تثبّت `chatterbox-tts==0.1.7` من PyPI يدويًا لهذه النسخة. ملف PyPI بهذا الرقم نُشر في 26 مارس 2026، بينما دعم محمّل Multilingual V3 أُضيف إلى كود المصدر الرسمي في 1 مايو 2026، مع بقاء رقم الحزمة في `pyproject.toml` كما هو. لذلك يستخدم المشروع commit المصدر المحدد أعلاه، ويتحقق من وجود وسيط `t3_model` ودعم `v3` فعليًا قبل إعلان المحرك جاهزًا.

**لماذا `s3gen.pt` وليس `s3gen_v3.pt`؟** نسخة محمّل Python المثبتة حاليًا (`3f35dfc`) تستدعي صراحةً `S3Gen` وتحمل `s3gen.pt`. وجود `s3gen_v3.pt` في مستودع الأوزان لا يعني أن هذا المحمّل يستخدمه؛ لا تستبدل الملف ولا تعِد تسميته يدويًا.

## التنزيل اليدوي

أوقف البوت، ثم أنشئ مجلد النموذج:

```powershell
New-Item -ItemType Directory -Force models/chatterbox-multilingual-v3
```

عند تشغيل المشروع مرة واحدة سابقًا وإنشاء البيئة، استخدم Python الخاص بها لتثبيت الحزمة (إذا لم ينجح التثبيت التلقائي):

```powershell
.voice-tts-venv\Scripts\python.exe -m pip install --upgrade pip
.voice-tts-venv\Scripts\python.exe -m pip install "chatterbox-tts @ git+https://github.com/resemble-ai/chatterbox.git@3f35dfc8fbe63e5b29793289dc68f1875bb317a5"
```

ثبّت أداة Hugging Face CLI ثم نزّل الملفات المطلوبة:

```powershell
.voice-tts-venv\Scripts\python.exe -m pip install -U huggingface_hub
.voice-tts-venv\Scripts\hf.exe download ResembleAI/chatterbox t3_mtl23ls_v3.safetensors s3gen.pt ve.pt grapheme_mtl_merged_expanded_v1.json conds.pt Cangjie5_TC.json --revision 5bb1f6ee58e50c3b8d408bc82a6d3740c2db6e18 --local-dir models/chatterbox-multilingual-v3
```

إذا لم يظهر أمر `hf.exe` بعد تثبيت `huggingface_hub`، افتح PowerShell جديدًا أو أعد إنشاء البيئة المعزولة، ثم استخدم `python -m pip install -U huggingface_hub` مرة أخرى. لا تستبدل الملفات بأسماء مختلفة.

ثم أضف إلى `.env`:

```dotenv
CHATTERBOX_TTS_ENABLED=true
CHATTERBOX_AUTO_DOWNLOAD=false
CHATTERBOX_MODEL_PATH=models/chatterbox-multilingual-v3
CHATTERBOX_DEVICE=auto
```

شغّل البوت مجددًا. يفحص المشروع الملفات ويحمّل النموذج للتحقق قبل استخدامه. لا تنسخ ملفًا جزئيًا أو تعِد تسمية أوزان النموذج؛ يجب أن تبقى الأسماء كما هي.

## Linux

بعد أن ينشئ المشروع `.voice-tts-venv`، استخدم:

```bash
.voice-tts-venv/bin/python -m pip install --upgrade pip
.voice-tts-venv/bin/python -m pip install "chatterbox-tts @ git+https://github.com/resemble-ai/chatterbox.git@3f35dfc8fbe63e5b29793289dc68f1875bb317a5" huggingface_hub
.voice-tts-venv/bin/hf download ResembleAI/chatterbox t3_mtl23ls_v3.safetensors s3gen.pt ve.pt grapheme_mtl_merged_expanded_v1.json conds.pt Cangjie5_TC.json --revision 5bb1f6ee58e50c3b8d408bc82a6d3740c2db6e18 --local-dir models/chatterbox-multilingual-v3
```

واجعل `CHATTERBOX_AUTO_DOWNLOAD=false` في `.env` قبل إعادة تشغيل التطبيق.

## الضبط والتعبير

- `CHATTERBOX_DEVICE=auto`: يختار CUDA أو Apple MPS عند توفره، وإلا CPU.
- `CHATTERBOX_CPU_THREADS=4`: عدد خيوط CPU عند استخدام المعالج.
- `CHATTERBOX_EXAGGERATION=0.55`: شدة التعبير الافتراضية، ويمكن تغييرها من لوحة إعدادات الصوت.
- `CHATTERBOX_CFG_WEIGHT=0.45` و`CHATTERBOX_TEMPERATURE=0.8`: معاملات التوليد المتقدمة؛ لا تغيّرها إلا عند اختبار نماذجك.
- أنماط «متعاطف / حكائي / مرح / فضولي / حيوي» تتحكم في توجيه التعبير، ويختار النمط التلقائي تقديرًا سياقيًا بسيطًا لكل جملة.

**ملاحظة مهمة:** النموذج يصنع الصوت ولا يكتب الرد من تلقاء نفسه. تنوع المفردات والمعرفة وطريقة صياغة الإجابة مصدرها نظام المحادثة (مثل Ollama/قواعد الرد)، وليس محرك النطق. كما أن التوجيه العاطفي الآلي تقريبي وليس ضمانًا لانفعال بشري واقعي.
