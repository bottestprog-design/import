# خط أساس الاختبارات والبيئة — المرحلة 00 / V10

## 1) بيئة التنفيذ الفعلية

| العنصر | القيمة المرصودة |
|---|---|
| نظام البناء | Linux x86_64 (بيئة المراجعة) |
| Node.js | v22.16.0 |
| npm | 10.9.2 |
| Python | 3.13.5 |
| package engines | `node >=20.0.0` |
| package-lock | lockfileVersion 3، package 9.20.24 |
| `node_modules` | غير موجود في حزمة المصدر النظيفة عند بدء الاختبار |
| Chromium | موجود في بيئة الفحص Linux (`/usr/bin/chromium`) |
| FFmpeg/FFprobe | موجودان في بيئة الفحص Linux |
| `.env` وبيانات جلسات المستخدم | غير موجودة في ZIP |

**تنبيه:** هذه ليست بيئة Windows الخاصة بالمستخدم. لا تعادل اختبار التثبيت أو Chromium أو قفل الملفات أو TTS على Windows.

## 2) أوامر الاختبار المنفذة والنتائج

| الاختبار | الأمر | النتيجة | حدود التفسير |
|---|---|---|---|
| حزمة التحقق الرئيسية | `node scripts/verify.js` | PASS WITH LIMITATIONS | 166 syntax checks؛ 98 test files passed؛ 1 skipped؛ 0 failed |
| اختبار HTTP endpoint | داخل verify: `settings-endpoint-integration.js` | SKIPPED | Express/npm dependencies غير مثبتة في بيئة الفحص؛ لا يتم تسجيله PASS |
| فحص اعتماديات المشغّل | `python test_launcher_dependencies.py` | PASS | فحص توافق package.json وpackage-lock وإعلانات الاعتماديات فقط |
| فحص syntax إضافي | `node --check` لكل ملفات JS ضمن server/src/scripts/test/public | 166/166 PASS | لا يثبت صحة منطق التشغيل أو الاتصالات الحية |
| Python compile | `python -m py_compile scripts/*.py run.py test/*.py test_launcher_dependencies.py` | PASS | Syntax فقط؛ لا يثبت توافر المكتبات أو inference |
| سلامة أرشيف v9.20.24 الأصلي | `ZipFile.testzip()` | PASS | لم يُكتشف عضو تالف داخل الأرشيف |
| مقارنة المصدر v9.20.20 | مقارنة path + SHA256 | PASS للمحافظة | 306 أصلية موجودة؛ 0 مفقود؛ 44 معدّل؛ 20 جديد |

## 3) ملخص حزمة التحقق الرئيسية

- JavaScript syntax: **166/166**.
- ملفات اختبار JavaScript: **99** ضمن `test/` (98 ناجحًا + واحد متخطّى).
- ملف Python ضمن `test/`: `voice-worker-quality.py`، ويُفحص compile بصورة منفصلة.
- فشل: **0** في الجولة الحالية.
- تخطٍ معلن: **1** (`settings-endpoint-integration.js`).
- `npm ci` لم يُنفذ بنجاح في هذه البيئة، ولا توجد `node_modules` في حزمة المصدر؛ لذلك لم نعتبر اختبار HTTP غير المنفذ نجاحًا.

## 4) اختبارات لم تنفذ بعد

1. تسجيل دخول QR فعلي على WhatsApp بحساب اختبار.
2. إلغاء ربط الهاتف ثم إعادة الربط على Windows.
3. تشغيل نسختين على نفس LocalAuth من عمليتين Windows.
4. اختبار جلسة WhatsApp طويلة/انقطاع الشبكة مع Puppeteer/Chromium المستهدف.
5. إرسال واستقبال حي لكل نوع وسائط وتفاعل.
6. اختبار WABA/Cloud API/Flows/قوالب بحساب Meta مؤهل.
7. تنزيل Audar/NeuCodec وSTT models وتشغيل inference والاستماع.
8. اختبار أداء الذاكرة/المعالج والمهام المتوازية على جهاز المستخدم.
9. إجراء استعادة من نسخة بيانات جلسة حقيقية إلى نسخة نظيفة بعد التأكد من سلامة التشفير والملفات.

## 5) قرار baseline

النتائج تثبت أن مجموعة الاختبارات المحلية المتاحة نجحت مع تخطٍ واحد معلن، وتثبت سلامة ZIP ومقارنة ملفات المصدر. لا تثبت اعتماد الإصدار إنتاجيًا أو سلامة كل بيئة أو نجاح WhatsApp حي أو جودة الصوت.
