# اختلاف الملفات بين v9.20.20 وv9.20.24

طريقة الحساب: مقارنة مسارات الملفات وبصمة SHA-256 من أرشيف v9.20.24 مع شجرة المصدر v9.20.20، واستبعاد ملفات runtime/الكاش والبيئات والنماذج.

- أصلية: 306
- أصلية مفقودة: 0
- دون تغيير: 262
- معدلة: 44
- جديدة: 20

## ملفات مضافة

- `AUDAR_TTS_SETUP_AR.md`
- `CHATTERBOX_V3_SETUP_AR.md`
- `FULL_REVIEW_V9_20_21_EXPRESSIVE_TTS_AR.md`
- `FULL_REVIEW_V9_20_23_AR.md`
- `FULL_REVIEW_V9_20_24_AR.md`
- `docs/BUILD_STATUS_V10_AR.md`
- `docs/ENGINEERING_MASTER_BUILD_PLAN_V10_AR.md`
- `docs/PHASE00_BASELINE_REVIEW_V10_AR.md`
- `docs/PHASE01_SESSION_LIFECYCLE_REVIEW_V9_20_24_AR.md`
- `docs/WHATSAPP_CAPABILITY_MATRIX_V10_AR.md`
- `scripts/audar_tts_worker.py`
- `scripts/chatterbox_tts_worker.py`
- `scripts/voice-audar-requirements.txt`
- `scripts/voice-tts-requirements.txt`
- `src/audar-tts-runtime.js`
- `src/chatterbox-runtime.js`
- `src/session-process-lock.js`
- `test/audar-expressive-voice.js`
- `test/chatterbox-expressive-tts.js`
- `test/session-process-lock.js`

## ملفات معدلة

- `.env.example`
- `.gitignore`
- `README.md`
- `RELEASES_AR.md`
- `package-lock.json`
- `package.json`
- `public/app.js`
- `scripts/setup-local-ai.ps1`
- `server.js`
- `src/interaction.js`
- `src/local-llm.js`
- `src/operational-diagnostics.js`
- `src/owner-assistant.js`
- `src/settings-readiness.js`
- `src/smart-reply.js`
- `src/store.js`
- `src/text-to-speech.js`
- `src/tts-delivery.js`
- `src/voice-bootstrap.js`
- `src/whatsapp.js`
- `test/conversation-archive-ui.js`
- `test/interaction-persistence.js`
- `test/live-conversation-ui.js`
- `test/local-llm.js`
- `test/media-gallery.js`
- `test/phase1-connection-lifecycle.js`
- `test/phase3-media-workflow.js`
- `test/phase3-message-reliability.js`
- `test/phase4-contact-recovery.js`
- `test/phase4-release-gate.js`
- `test/phase4-voice-quality.js`
- `test/phase5-speech-quality.js`
- `test/phase6-contact-refresh-ui.js`
- `test/phase7-diagnostics-hardening.js`
- `test/python-voice-adapters.js`
- `test/reference-restoration.js`
- `test/smart-reply.js`
- `test/static.js`
- `test/text-to-speech.js`
- `test/tts-privacy-defaults.js`
- `test/voice-autostart-multilang.js`
- `test/voice-repair-release.js`
- `test/whatsapp-connection.js`
- `test/whatsapp-restoration-ui.js`

## ملفات مفقودة

لا توجد ملفات أصلية مفقودة.
