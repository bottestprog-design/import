# جرد البنية الفعلية — المرحلة 00 / V10

**المصدر:** أرشيف `v9.20.24-engineering-foundation.zip` كما تم تسليمه في المحادثة.
**الغرض:** تسجيل ما هو موجود في المصدر الحالي، لا ما تنص عليه الخطة المستهدفة.

## 1) قياسات الشجرة

| المجموعة | العدد داخل الأرشيف | ما تعنيه |
|---|---:|---|
| جذر المشروع | 140 | README وإعدادات ومراجعات وسجلات إصدارات ومشغّل |
| `src/` | 62 | وحدات منطق الأعمال والخدمات |
| `test/` | 100 | 99 ملف JavaScript وملف Python واحد |
| `scripts/` | 14 | مشغلات وإعداد وتحقق وعمال صوت |
| `public/` | 3 | صفحة HTML وCSS وJavaScript للواجهة |
| `docs/` | 7 | خطة V10 ومراجعات المرحلة |
| **الإجمالي** | **326** | ملفات فعلية؛ لا تشمل مجلدات runtime غير المعبأة |

## 2) مسار التشغيل والحدود الحالية

- **مشغّل محلي:** `run.py` يساعد في تهيئة/تشغيل التطبيق؛ نقطة Node الأساسية هي `server.js`.
- **HTTP/API:** مسارات Express معرفة في `server.js`، وجرد المسارات الحرفية المباشرة في `PHASE00_API_ROUTE_CATALOG_V10.csv`.
- **واجهة المستخدم:** `public/index.html` و`public/app.js` و`public/styles.css`. هي واجهة SPA/صفحة واحدة وظيفيًا، وليست مجموعة تطبيقات frontend منفصلة.
- **موصل WhatsApp:** `src/whatsapp.js` يستخدم `whatsapp-web.js` وPuppeteer/Chromium مع LocalAuth.
- **التخزين الحالي:** `src/store.js` يحفظ بيانات الجلسات في ملفات `data/sessions/<sessionId>/session.json`، ومخطط الجلسة الحالي `schemaVersion=13`. لا توجد تبعية SQLite في `package.json`، ولا يوجد migration framework علائقي ضمن المصدر الحالي.
- **الرسائل/الأتمتة:** `src/delivery.js` و`src/interaction.js` و`src/automation-engine.js` و`src/scheduler.js` و`src/inbound-message-queue.js`. الطابور الحالي محدود داخل العملية؛ لا يعادل Inbound Journal دائمًا أو Outbox عامًا.
- **المحادثات/المستلمون:** `conversation-archive.js`, `conversation-recall.js`, `conversation-targets.js`, `recipient-management.js`, `whatsapp-contacts.js`. هذا يوفر أرشيف/قوائم مستلمين، وليس CRM فريق كاملًا.
- **الوسائط:** `src/media.js` ومسارات media في `server.js`، مع gallery في الواجهة. لا توجد خدمة أصل موحد تشمل فحصًا/تحويلًا/توقيع روابط لكل أنواع 3D/AR.
- **الذكاء المحلي:** `src/local-llm.js` مع تكامل محلي مقيد إلى loopback في الاختبار، بالإضافة إلى command understanding/smart reply/owner assistant. لا يوجد RAG ingestion/index عام.
- **الصوت:** `audio-transcriber.js`, `text-to-speech.js`, `audar-tts-runtime.js`, `chatterbox-runtime.js`, `voice-bootstrap.js` مع Python workers. وجود هذه الملفات لا يثبت inference أو جودة سمعية على جهاز المستخدم.
- **التكاملات:** `integration-hub.js` و`integration-agent.js` و`local-command-bridge.js`; هذا أساس تكاملات، وليس إثبات وجود sandbox عام لتشغيل Plugins غير موثوقة.
- **النسخ الاحتياطي:** `local-backup.js` ومسارات export/inspect/restore موجودة واختبارات محلية لها. لم تُنفذ في هذه الدفعة تجربة استعادة بيانات جلسة مستخدم حقيقية.

## 3) API surface

تم العثور على **129 تعريف route حرفي** مباشر في `server.js`: 31 GET و73 POST و10 PUT و15 DELETE. هذا count ثابت لما التقطه نمط `app.method('/literal')`؛ لا يدعي حصر كل mounted middleware أو dynamic route.

أكبر المجالات الظاهرة من بادئات المسارات: health/diagnostics، integrations/agents/plugins، assistant/LLM، voice/STT/TTS، conversations/archive، sessions/WhatsApp، recipients/groups، media/delivery، interaction/automation/scheduler، settings/background/profile.

## 4) أحجام/نقاط تركيز تحتاج مراجعة معمارية لاحقة

- `server.js` حجمه 183723 بايت، ويضم 129 تعريف API مباشرًا؛ التجزئة domain-by-domain مطلوبة عند بدء مرحلة Provider/API، لا إعادة كتابة دفعة واحدة.
- `src/whatsapp.js` حجمه 103909 بايت؛ هو محور دورة حياة القناة، لذا أي فك ارتباط يجب أن يمر بعقود واختبارات مرحلية.
- `src/owner-assistant.js` حجمه 122045 بايت، و`src/integration-hub.js` حجمه 78681 بايت؛ حجم الوحدة لا يثبت ضعفها، لكنه يرفع كلفة المراجعة ويجعل فصل الحدود خطرًا إن تم بلا اختبارات.
- `src/event-bus.js` يعلن أنه in-process bounded bus، وتعليقه يقول إن durable delivery مسؤولية outbox adapter. لا يوجد ملف `src/outbox*.js` مستقل في قائمة المصدر الحالية؛ يجب عدم تفسير التعليق على أنه Outbox دائم موجود.

## 5) ما لا يوجد كدليل في الشجرة الحالية

- لا يظهر adapter مستقل لـWhatsApp Cloud API.
- لا يوجد RAG ingestion/index/retrieval service عام.
- لا يظهر DAG runtime عام مع versioning/checkpoint/replay.
- لا يوجد generic Tool/Agent Runtime sandboxed.
- لا يوجد CRM/Inbox متعدد المستخدمين مع assignments/SLA/RBAC موحد.
- لا توجد خدمة 3D/AR viewer أو asset validation في التطبيق.
- لا يوجد registry عام يثبت capabilities لكل provider/account/chat type.

غياب ملفات مخصصة لا يثبت أن أي مثال جزئي غير ممكن؛ إنما يعني أن النظام العام المطلوب لم يثبت وجوده في هذه الشجرة.

## 6) حدود دقة الجرد

تصنيفات المسؤوليات في `PHASE00_MODULE_CATALOG_V10.csv` مستنتجة من أسماء الملفات، والاستيرادات/التصديرات، ومراجعة سريعة للرموز؛ وهي خريطة أولية وليست توثيقًا كاملًا لكل side effect أو dependency. وجرد المسارات يلتقط تعريفات `app.get/post/put/delete` ذات المسار النصي المباشر فقط، ولا يدعي التقاط كل middleware أو المسارات المولدة ديناميكيًا. أي إعادة هندسة لاحقة يجب أن تتحقق من هذه العقود من المصدر قبل نقلها.
