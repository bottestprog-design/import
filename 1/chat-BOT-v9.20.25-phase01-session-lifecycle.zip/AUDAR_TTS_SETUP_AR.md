# إعداد محرك Audar-TTS-V1 في Chat BOT v9.20.23

## المحرك الافتراضي

يستخدم المشروع **Audar-TTS-V1 Turbo Q5_K_M** محليًا للعربية والإنجليزية. حجم ملف Turbo Q5 قرابة 1.21 GB، وتوجد نسخة Flash الأخف بحجم يقارب 0.48 GB. انتبه أن NeuCodec الإضافي يقارب 2.52 GB، كما أن بيئة PyTorch وحزم الصوت تحتاج تنزيلًا ومساحة إضافية؛ إجمالي التنزيل الأول أكبر من حجم ملف GGUF وحده. يدعم Turbo وسوم الأداء الثمانية: `[laughs]` و`[curious]` و`[excited]` و`[sighs]` و`[exhales]` و`[mischievously]` و`[whispers]` و`[sarcastic]`. يجب استخدامها في المواضع التي يناسبها المعنى لا في كل جملة.

## التنزيل التلقائي (الموصى به)

اترك القيم التالية في `.env`. ولأن مستودع NeuCodec محمي بشروط Hugging Face، يلزم تنفيذ الموافقة مرة واحدة: افتح [صفحة NeuCodec](https://huggingface.co/neuphonic/neucodec)، سجّل الدخول واقبل شروط الوصول، ثم أنشئ رمز Access Token بصلاحية Read في [إعدادات الرموز](https://huggingface.co/settings/tokens). ضع الرمز في `HF_TOKEN` داخل `.env`. لا ترسل الرمز لأحد ولا ترفق ملف `.env` عند مشاركة المشروع. لا يبدأ المثبت تنزيل GGUF الكبير قبل التحقق من إمكانية الوصول إلى NeuCodec.

```dotenv
AUDAR_TTS_ENABLED=true
AUDAR_TTS_AUTO_DOWNLOAD=true
AUDAR_TTS_TIER=turbo
AUDAR_TTS_MODEL_DIR=models/audar-tts
AUDAR_TTS_VOICE_DIR=models/audar-voices
AUDAR_TTS_CODEC_DIR=models/audar-codec
AUDAR_TTS_CACHE_DIR=models/hf-cache
AUDAR_TTS_MODEL_FILE=
HF_TOKEN=ضع_رمز_Hugging_Face_الخاص_بك_هنا
AUDAR_TTS_GPU_LAYERS=0
CHATTERBOX_TTS_ENABLED=false
```

بعد قبول NeuCodec وضبط `HF_TOKEN`، ابدأ Chat BOT كالمعتاد. سيقوم إعداد الصوت المدمج بإنشاء `.voice-audar-venv` وتثبيت PyTorch وNeuCodec و`llama-cpp-python` وحزم الصوت، ثم تنزيل GGUF والأصوات والـcodec. لا يحتاج المستخدم إلى تشغيل `audar_tts_worker.py` يدويًا. أول مرة تحتاج اتصالًا بالإنترنت ومساحة تخزين إضافية كبيرة (Turbo Q5 + NeuCodec + مكتبات PyTorch). بعد اكتمال الإعداد يتم التوليد محليًا.

عامل Audar يبقى في الذاكرة أثناء عمل البوت. قبل إعلان جاهزيته ينفّذ توليدًا عربيًا تجريبيًا ويتحقق من أن ملف WAV غير فارغ وصالح. تنزيل النموذج وحده لا يعني نجاح المحرك؛ إذا فشل الاختبار يظهر سبب الفشل ويظل Piper بديلًا عربيًا.

## تنزيل النموذج يدويًا

**Turbo (الموصى به):**

- [تحميل ملف Audar-TTS-V1-Turbo-Q5_K_M.gguf مباشرة](https://huggingface.co/audarai/Audar-TTS-V1-Turbo/resolve/main/Audar-TTS-V1-Turbo-Q5_K_M.gguf)
- [صفحة Turbo الرسمية — الملفات والترخيص](https://huggingface.co/audarai/Audar-TTS-V1-Turbo)

ضع الملف كما هو داخل:

```text
models/audar-tts/Audar-TTS-V1-Turbo-Q5_K_M.gguf
```

**Flash للأجهزة الأقل مواردًا:**

- [تحميل Audar-TTS-V1-Flash-Q5_K_M.gguf](https://huggingface.co/audarai/Audar-TTS-V1-Flash/resolve/main/Audar-TTS-V1-Flash-Q5_K_M.gguf)
- [صفحة Flash الرسمية](https://huggingface.co/audarai/Audar-TTS-V1-Flash)

ضعه داخل `models/audar-tts/` ثم اضبط `AUDAR_TTS_TIER=flash` في `.env`.

### ملفات الأصوات المرجعية

ضع ملفات WAV الستة في جذر `models/audar-voices/` بالأسماء التالية. روابط الملفات تتبع مجلد `samples` الخاص بصفحة Turbo:

| الاسم المطلوب | رابط الملف |
|---|---|
| `demo_male_1_ar.wav` | [male 1](https://huggingface.co/audarai/Audar-TTS-V1-Turbo/resolve/main/samples/demo_male_1_ar.wav) |
| `demo_male_2_ar.wav` | [male 2](https://huggingface.co/audarai/Audar-TTS-V1-Turbo/resolve/main/samples/demo_male_2_ar.wav) |
| `demo_male_3_ar.wav` | [male 3](https://huggingface.co/audarai/Audar-TTS-V1-Turbo/resolve/main/samples/demo_male_3_ar.wav) |
| `demo_female_1_ar.wav` | [female 1](https://huggingface.co/audarai/Audar-TTS-V1-Turbo/resolve/main/samples/demo_female_1_ar.wav) |
| `demo_female_2_ar.wav` | [female 2](https://huggingface.co/audarai/Audar-TTS-V1-Turbo/resolve/main/samples/demo_female_2_ar.wav) |
| `demo_female_3_ar.wav` | [female 3](https://huggingface.co/audarai/Audar-TTS-V1-Turbo/resolve/main/samples/demo_female_3_ar.wav) |

هذه الملفات أصوات اصطناعية جاهزة، وليست استنساخًا لشخص حقيقي. يجب أن تكون كل عينة 5–15 ثانية، لأن ملف المرجع القصير جدًا قد يفسد شرط التكييف الصوتي. نصوص المرجع العربية في العامل مضبوطة لتطابق النصوص والعلامات المنشورة مع العينات.

### NeuCodec للتثبيت اليدوي

لإعداد دون الحاجة إلى رمز Hugging Face في وقت التشغيل، اقبل شروط المستودع ثم نزّل snapshot كاملة داخل `models/audar-codec/`. يجب أن يحتوي المجلد على `config.json` وملف وزن كامل مثل `model.safetensors` (أو `pytorch_model.bin`)؛ لا يعتبر وجود مجلد فارغ أو ملف إعداد وحده كافيًا. أوزان NeuCodec المنشورة تقارب 2.52 GB. [صفحة المستودع والملفات](https://huggingface.co/neuphonic/neucodec/tree/main).

بعد تجهيز نسخة codec كاملة، ضع أيضًا ملفات الصوت الستة الموضحة أعلاه وملف GGUF داخل مجلداتهما ثم أوقف التنزيل التلقائي. ملفات Python wheel يجب أن تكون موجودة في `.voice-audar-venv` إذا كان التشغيل الأول دون إنترنت تمامًا.

### تعطيل تنزيل أصول النموذج

بعد وضع GGUF والأصوات وNeuCodec محليًا، اضبط:

```dotenv
AUDAR_TTS_AUTO_DOWNLOAD=false
AUDAR_TTS_MODEL_DIR=models/audar-tts
AUDAR_TTS_VOICE_DIR=models/audar-voices
AUDAR_TTS_CODEC_DIR=models/audar-codec
```

ثم أعد تشغيل Chat BOT. هذا الخيار يمنع عامل Audar من تنزيل GGUF أو ملفات الأصوات أو NeuCodec؛ لكنه لا يمنع `VoiceBootstrap` من تثبيت حزم Python إذا لم تكن بيئتها موجودة. لذلك يلزم اتصال أول مرة لتثبيت الحزم، أو توفير الحزم مسبقًا في `.voice-audar-venv` لإعداد دون إنترنت بالكامل.

## إعداد CPU وGPU

```dotenv
# الافتراضي المتوافق على أجهزة أكثر
AUDAR_TTS_GPU_LAYERS=0

# ضع عدد الطبقات الذي تريد نقله إلى GPU عند وجود نسخة llama.cpp مدعومة
# AUDAR_TTS_GPU_LAYERS=-1
AUDAR_TTS_TOP_K=40
AUDAR_TTS_TOP_P=0.90
```

يُستخدم CPU افتراضيًا. لا تفترض أن وجود بطاقة NVIDIA يعني أن تثبيت CUDA جاهز؛ تسريع GPU يحتاج بناء/عجلة `llama-cpp-python` مطابقة لنظامك ونسخة CUDA. توثيق المكتبة الرسمية يشرح خيارات CPU وCUDA وVulkan وHIP:

https://github.com/abetlen/llama-cpp-python

## الأصوات واللهجات والنطق

من لوحة Chat BOT اختر الصوت المحلي من إعدادات التفاعل. ستجد ثلاثة أصوات رجالية وثلاثة نسائية. هذه الملفات مراجع لصوت/خامّة/لهجة؛ لا يعني اختيار الملف أن جميع كلمات اللهجة ستنطق دون خطأ. أضف أسماء الأشخاص والعلامات التجارية والمصطلحات إلى «معجم النطق» حتى 300 قاعدة.

وسوم Audar الثمانية توجّه الأداء الذي دُرّب عليه النموذج، لكنها لا تحوّل كل جملة إلى أداء تمثيلي ولا تضمن صوتًا بشريًا مطابقًا. يختار المصنّف المحلي وسمًا عندما يلتقط سؤالًا أو تهنئة أو مواساة أو مزاحًا أو همسًا واضحًا؛ ويترك الجملة العادية بلا وسم بدل اختراع شعور لا يناسبها. عندما يكون Ollama ونموذج المحادثة متاحين، يحاول إعداد نص العربية للنطق بإضافة التشكيل الضروري دون تغيير الكلمات؛ إذا غيّر المدقق مفردات النص، تُرفض النتيجة ويُستخدم النص الأصلي. معجم النطق اليدوي يبقى المرجع الأدق للأسماء النادرة والأرقام والاختصارات. تجنب وضع أكثر من وسم متراكب على الجملة. اختبر المعاينة بصوتك ولهجتك، فلم يتم إجراء تقييم سمعي بشري على جهازك ضمن عملية بناء هذه الحزمة؛ استخدم المعاينة قبل إرسال الردود الفعلية.

## المفردات ليست من مهمة TTS

محرك الصوت يحوّل النص الموجود إلى موجة صوتية، ولا يقرر ماذا يقول البوت. لتوسيع مفرداته وصياغة الردود بصورة أكثر حيوية، فعّل «استخدام نموذج محلي للمحادثة» في إعدادات التفاعل وثبّت Ollama ونموذجًا محليًا مثل `qwen3.5:4b`. في غياب نموذج المحادثة يستخدم البوت ردودًا احتياطية ثابتة متعددة الصيغ، لكنها ستظل محدودة في المعرفة والسياق. نموذج المحادثة لا يُنزّل تلقائيًا عند تشغيل البوت حتى لا يبدأ تنزيلًا إضافيًا بحجم 3.3–4.0 GB دون موافقتك؛ شغّل `scripts/setup-local-ai.ps1`، وافق على تنزيل Ollama والنموذج، ثم فعّل خيار «استخدام نموذج محلي للمحادثة» واضبط الاسم `qwen3.5:4b`.

## الترخيص والخصوصية

Turbo يُنشر بموجب **AudarAI Community License v1.0**، وهي ليست ترخيصًا بلا قيود: الاستخدام البحثي والتعليمي والنمذجة الأولية مسموح وفق شروطه، أما الاستخدام التجاري فينحصر في كيانات تستوفي حدود الترخيص؛ الاستخدام المؤسسي/الواسع أو تجاوز الحدود يتطلب ترخيصًا من AudarAI. اقرأ الشروط الكاملة قبل التوزيع أو الاستخدام التجاري. Flash له ترخيص AudarAI Open v1.0 الأكثر تساهلًا، لكنه نموذج أصغر وقد يكون أقل fidelity من Turbo. لا تتضمن الحزمة أي أوزان؛ المستخدم ينزّلها من مستودعها الرسمي.

التنزيل الأول يتصل بمستودعات Hugging Face لجلب الملفات فقط. نصوص المحادثة المُراد نطقها لا تُرسل إلى Hugging Face أو مزود TTS في المسار المحلي. Edge TTS وOpenAI-compatible يظلان معطلين دون موافقة صريحة في إعدادات كل جلسة.
