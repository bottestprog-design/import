@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo إعداد الصوت الكامل يجهّز النطق والتفريغ معًا لتجنب تضارب نسخ Python.
call "%~dp0SETUP-PYTHON-VOICE-WINDOWS.bat"
exit /b %errorlevel%
