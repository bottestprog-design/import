@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title chat BOT - إعداد Python Voice Stack
echo ============================================================
echo  chat BOT - Faster-Whisper + Piper + Edge TTS
echo ============================================================
echo أول مرة يحتاج اتصالًا بالإنترنت لتنزيل الحزم والنماذج.
echo التشغيل المعتاد يجهز الصوت تلقائيًا؛ هذا الملف للإصلاح اليدوي فقط. الوضع التلقائي يجرب Edge TTS ثم بديل Piper العربي.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup-python-voice.ps1"
if errorlevel 1 goto :failed
echo.
echo اكتمل إعداد الصوت. يمكنك الرجوع للتشغيل المعتاد؛ افحص حالة الصوت إذا أردت التحقق من النتيجة.
pause
exit /b 0
:failed
echo.
echo لم يكتمل إعداد الصوت. راجع رسالة الخطأ بالأعلى.
pause
exit /b 1
