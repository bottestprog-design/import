$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Write-Host 'يشغّل هذا الملف إعداد Python/Piper/Edge TTS الموحّد، ولا يفرض وجود Ollama أو التدقيق اللغوي.' -ForegroundColor Cyan
& (Join-Path $Root 'scripts\setup-python-voice.ps1')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
