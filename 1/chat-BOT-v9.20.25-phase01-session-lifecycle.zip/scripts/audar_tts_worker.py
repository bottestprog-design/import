#!/usr/bin/env python3
"""Local Audar-TTS-V1 runtime for WhatsApp voice replies.

The worker keeps llama.cpp + NeuCodec alive for multiple requests. Model weights,
codec and voice references are downloaded from Hugging Face into project-owned
folders; inference itself is local and never uploads message text.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import tempfile
import traceback
from pathlib import Path

import numpy as np

MODEL_CONFIG = {
    "turbo": {
        "repo": "audarai/Audar-TTS-V1-Turbo",
        "file": "Audar-TTS-V1-Turbo-Q5_K_M.gguf",
        "min_bytes": 850_000_000,
    },
    "flash": {
        "repo": "audarai/Audar-TTS-V1-Flash",
        "file": "Audar-TTS-V1-Flash-Q5_K_M.gguf",
        "min_bytes": 300_000_000,
    },
}

# Official Arabic demo clips and their corresponding reference transcripts.
# The files are synthetic voice profiles; no real person's identity is cloned.
VOICE_PROFILES = {
    "demo_male_1": {
        "file": "demo_male_1_ar.wav",
        "text": "لا يمكنني الانتظار لأخبرك — [excited] لقد أنجزنا المشروع أخيراً بعد كلّ هذا التعب، [laughs] وصدّقني، إنه أجمل شعورٍ على الإطلاق!",
        "label": "رجل — دافئ وواثق",
    },
    "demo_male_2": {
        "file": "demo_male_2_ar.wav",
        "text": "تعال، اقترب قليلاً — [whispers] لقد خطّطتُ لمفاجأةٍ رائعة طوال الأسبوع، [mischievously] وأنا واثقٌ تماماً أنّها ستُدهشك حقاً!",
        "label": "رجل — هادئ وقريب",
    },
    "demo_male_3": {
        "file": "demo_male_3_ar.wav",
        "text": "لحظة، حقاً؟ [curious] هل بنيتَ كلّ هذا بنفسك في يومين فقط؟ [excited] هذا مذهلٌ فعلاً — احكِ لي كلّ التفاصيل الآن!",
        "label": "رجل — مشرق وفضولي",
    },
    "demo_female_1": {
        "file": "demo_female_1_ar.wav",
        "text": "خمّن ماذا وصل في البريد للتوّ — [excited] رسالة القبول التي انتظرناها طويلاً، [laughs] لقد صرختُ من شدّة الفرح!",
        "label": "امرأة — حيوية ومرحة",
    },
    "demo_female_2": {
        "file": "demo_female_2_ar.wav",
        "text": "حسناً، اقتربي قليلاً — [whispers] وجدتُ مقهىً صغيراً رائعاً في وسط المدينة، [mischievously] وسيكون مكاننا السريّ الجديد!",
        "label": "امرأة — ناعمة ومرحة",
    },
    "demo_female_3": {
        "file": "demo_female_3_ar.wav",
        "text": "لن تصدّقي هذا المنظر من هنا — [excited] المدينة كلّها تتلألأ عند الغروب، [laughs] وكأنّها لوحةٌ من حلمٍ جميل!",
        "label": "امرأة — رقيقة وحالمة",
    },
}

EXPRESSION_TAGS = {
    "laughs", "curious", "excited", "sighs", "exhales", "mischievously", "whispers", "sarcastic"
}
SPEECH_RE = re.compile(r"<\|speech_(\d+)\|>")


def emit(payload: dict) -> None:
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def log(message: str) -> None:
    sys.stderr.write(str(message) + "\n")
    sys.stderr.flush()


def safe_voice(voice_id: str) -> str:
    return voice_id if voice_id in VOICE_PROFILES else "demo_male_1"


def model_file(model_dir: Path, tier: str) -> Path:
    expected = MODEL_CONFIG[tier]["file"]
    configured = os.environ.get("AUDAR_TTS_MODEL_FILE", "").strip()
    if configured:
        candidate = Path(configured)
        if not candidate.is_absolute():
            in_model_dir = model_dir / candidate
            candidate = in_model_dir if in_model_dir.is_file() else (model_dir.parent.parent / candidate)
        if candidate.is_file():
            return candidate
    exact = model_dir / expected
    if exact.is_file():
        return exact
    candidates = sorted(model_dir.glob("*.gguf"), key=lambda p: p.stat().st_size, reverse=True)
    if len(candidates) == 1:
        return candidates[0]
    return exact


def codec_directory_is_complete(directory: Path) -> bool:
    """Accept a complete local NeuCodec snapshot, not merely an empty folder."""
    if not directory.is_dir() or not (directory / "config.json").is_file():
        return False
    weight_candidates = ("model.safetensors", "pytorch_model.bin", "model.bin")
    return any((directory / name).is_file() and (directory / name).stat().st_size > 100_000_000 for name in weight_candidates)


def download_assets(args) -> dict:
    from huggingface_hub import hf_hub_download

    tier = args.tier if args.tier in MODEL_CONFIG else "turbo"
    config = MODEL_CONFIG[tier]
    model_dir = Path(args.model_dir).resolve()
    voice_dir = Path(args.voice_dir).resolve()
    cache_dir = Path(args.cache_dir).resolve()
    model_dir.mkdir(parents=True, exist_ok=True)
    voice_dir.mkdir(parents=True, exist_ok=True)
    cache_dir.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("HF_HOME", str(cache_dir))
    os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")

    target = model_file(model_dir, tier)
    auto_download = str(args.auto_download).lower() not in {"0", "false", "off", "no"}

    # Check the gated codec repository before pulling the much smaller GGUF or
    # the six voice clips, so an unaccepted HF gate fails fast and clearly.
    codec_dir = Path(os.environ.get("AUDAR_TTS_CODEC_DIR", "models/audar-codec")).resolve()
    codec_local_ready = codec_directory_is_complete(codec_dir)
    if not codec_local_ready and not auto_download:
        raise RuntimeError(
            f"مجلد NeuCodec المحلي غير مكتمل: {codec_dir}. يلزم config.json وmodel.safetensors "
            "(أو pytorch_model.bin) بحجم صحيح. فعّل التنزيل أو جهّز المجلد يدويًا بعد قبول شروط Hugging Face."
        )
    if not codec_local_ready and auto_download:
        try:
            # The repo is gated. Downloading only config.json verifies that the
            # account accepted access before the large codec weights are fetched.
            hf_hub_download(
                repo_id="neuphonic/neucodec", filename="config.json",
                token=os.environ.get("HF_TOKEN") or None,
            )
        except Exception as exc:
            message = str(exc)
            if "gated" in message.lower() or "401" in message or "403" in message or "restricted" in message.lower():
                raise RuntimeError(
                    "NeuCodec محمي بشروط Hugging Face. افتح https://huggingface.co/neuphonic/neucodec، "
                    "سجّل الدخول واقبل الوصول، ثم أنشئ Access Token بصلاحية قراءة وضعه في HF_TOKEN داخل .env، "
                    "أو نزّل snapshot كاملة يدويًا إلى AUDAR_TTS_CODEC_DIR. لن يُنزّل المشروع الأوزان الكبيرة قبل هذا التحقق."
                ) from exc
            raise

    if not target.is_file():
        if not auto_download:
            raise RuntimeError(
                f"لم يُعثر على ملف {config['file']}. ضع ملف GGUF الصحيح داخل {model_dir} "
                "أو فعّل AUDAR_TTS_AUTO_DOWNLOAD=true."
            )
        log(f"Downloading {tier} GGUF model from {config['repo']} ...")
        downloaded = hf_hub_download(
            repo_id=config["repo"], filename=config["file"],
            local_dir=str(model_dir), token=os.environ.get("HF_TOKEN") or None,
        )
        target = Path(downloaded)

    if not target.is_file() or target.stat().st_size < config["min_bytes"]:
        raise RuntimeError(
            f"ملف النموذج غير مكتمل أو ليس إصدار Q5_K_M المتوقع: {target} "
            f"({target.stat().st_size if target.exists() else 0} bytes)."
        )

    # Pre-fetch all bundled profiles so switching a voice later works offline.
    missing_voices = []
    for voice_id, profile in VOICE_PROFILES.items():
        voice_file = voice_dir / profile["file"]
        if not voice_file.is_file() or voice_file.stat().st_size < 100_000:
            if not auto_download:
                missing_voices.append(voice_id)
                continue
            log(f"Downloading synthetic voice profile: {voice_id}")
            downloaded = hf_hub_download(
                repo_id=config["repo"],
                filename=f"samples/{profile['file']}",
                local_dir=str(voice_dir), token=os.environ.get("HF_TOKEN") or None,
            )
            # HF local_dir preserves the repository's samples/ subfolder.
            downloaded_path = Path(downloaded)
            if downloaded_path.is_file() and downloaded_path != voice_file:
                voice_file.parent.mkdir(parents=True, exist_ok=True)
                voice_file.write_bytes(downloaded_path.read_bytes())
    if missing_voices:
        raise RuntimeError("التثبيت اليدوي يحتاج ملفات الصوت المرجعية داخل مجلد الأصوات: " + ", ".join(missing_voices))

    # Codec may be pre-populated in a local folder for a fully offline manual setup.
    if codec_local_ready:
        codec_source = str(codec_dir)
    else:
        codec_source = "neuphonic/neucodec"
    from neucodec import NeuCodec
    try:
        codec = NeuCodec.from_pretrained(codec_source, token=os.environ.get("HF_TOKEN") or None).eval()
    except Exception as exc:
        message = str(exc)
        if "gated" in message.lower() or "401" in message or "403" in message or "restricted" in message.lower():
            raise RuntimeError(
                "تعذر تنزيل NeuCodec لأن مستودعه يتطلب قبول شروط Hugging Face أولًا. "
                "افتح https://huggingface.co/neuphonic/neucodec، سجّل الدخول واقبل الوصول، "
                "ثم ضع HF_TOKEN في .env وأعد تشغيل المشروع، أو أضف snapshot كاملة إلى AUDAR_TTS_CODEC_DIR."
            ) from exc
        raise
    del codec

    return {
        "tier": tier,
        "modelPath": str(target),
        "modelBytes": target.stat().st_size,
        "voiceCount": len(VOICE_PROFILES),
        "voices": [{"id": key, "label": value["label"]} for key, value in VOICE_PROFILES.items()],
        "codec": codec_source,
    }


class Synthesizer:
    def __init__(self, model_path: Path, voice_dir: Path, tier: str, gpu_layers: int):
        import torch
        import soundfile as sf
        from llama_cpp import Llama
        from neucodec import NeuCodec

        self.torch = torch
        self.sf = sf
        self.model_path = model_path
        self.voice_dir = voice_dir
        self.tier = tier
        threads = max(2, (os.cpu_count() or 4) - 1)
        log(f"Loading Audar {tier} model: {model_path.name}")
        self.llm = Llama(
            model_path=str(model_path), n_ctx=4096, n_gpu_layers=gpu_layers,
            n_threads=threads, verbose=False,
        )
        log("Loading NeuCodec...")
        codec_dir = Path(os.environ.get("AUDAR_TTS_CODEC_DIR", "models/audar-codec")).resolve()
        codec_source = str(codec_dir) if codec_directory_is_complete(codec_dir) else "neuphonic/neucodec"
        self.codec = NeuCodec.from_pretrained(codec_source, token=os.environ.get("HF_TOKEN") or None).eval()
        self.reference_cache = {}

    def reference(self, voice_id: str):
        import librosa
        voice_id = safe_voice(voice_id)
        if voice_id in self.reference_cache:
            return self.reference_cache[voice_id]
        profile = VOICE_PROFILES[voice_id]
        ref_path = self.voice_dir / profile["file"]
        if not ref_path.is_file():
            raise RuntimeError(f"الملف المرجعي للصوت {voice_id} غير موجود: {ref_path}")
        wav, _ = librosa.load(str(ref_path), sr=16000, mono=True)
        if wav.size < 16000 * 5:
            raise RuntimeError(f"الملف المرجعي للصوت {voice_id} يجب أن تكون مدته 5 إلى 15 ثانية.")
        if wav.size > 16000 * 15:
            wav = wav[:16000 * 15]
        tensor = self.torch.from_numpy(np.asarray(wav, dtype=np.float32))[None, None, :]
        with self.torch.no_grad():
            codes = self.codec.encode_code(tensor).squeeze().tolist()
        if not isinstance(codes, list):
            codes = [int(codes)]
        self.reference_cache[voice_id] = (profile["text"], [int(x) for x in codes])
        return self.reference_cache[voice_id]

    def synthesize(self, text: str, output_path: str, voice_id: str = "demo_male_1", max_new_tokens: int = 1500, temperature: float = 1.0, top_k: int = 40, top_p: float = 0.90) -> dict:
        if not text or not text.strip():
            raise RuntimeError("النص المنطوق فارغ.")
        if len(text) > 2200:
            raise RuntimeError("النص المرسل إلى Audar تجاوز حد 2200 حرفًا.")
        ref_text, ref_codes = self.reference(voice_id)
        ref = "".join(f"<|speech_{code}|>" for code in ref_codes)
        prompt = (
            "user: Convert the text to speech:"
            f"<|REF_TEXT_START|>{ref_text}<|REF_TEXT_END|>"
            f"<|REF_SPEECH_START|>{ref}<|REF_SPEECH_END|>"
            f"<|TARGET_TEXT_START|>{text}<|TARGET_TEXT_END|>"
            "\nassistant:<|TARGET_CODES_START|>"
        )
        tokens = self.llm.tokenize(prompt.encode("utf-8"), add_bos=False, special=True)
        stop_tokens = self.llm.tokenize(b"<|TARGET_CODES_END|>", add_bos=False, special=True)
        if not stop_tokens:
            raise RuntimeError("تعذر قراءة رمز نهاية الصوت الخاص بنموذج Audar.")
        generated = []
        # Sampling is intentionally lively but bounded. Expression is primarily
        # controlled by the first-class inline tags; sampling adds natural variation
        # without making each reply sound randomly excited.
        temperature = max(0.60, min(1.05, float(temperature)))
        top_k = max(10, min(80, int(top_k)))
        top_p = max(0.65, min(0.98, float(top_p)))
        for token in self.llm.generate(
            tokens, temp=temperature, top_k=top_k, top_p=top_p, repeat_penalty=1.1,
        ):
            if token == stop_tokens[0] or len(generated) >= max_new_tokens:
                break
            generated.append(token)
        generated_text = "".join(
            self.llm.detokenize([token], special=True).decode("utf-8", "ignore")
            for token in generated
        )
        speech_codes = [int(value) for value in SPEECH_RE.findall(generated_text)]
        if not speech_codes:
            raise RuntimeError("لم ينتج Audar رموزًا صوتية. راجع ملف النموذج والذاكرة المتاحة.")
        codes = self.torch.tensor(speech_codes)[None, None, :]
        with self.torch.no_grad():
            waveform = self.codec.decode_code(codes).cpu().numpy()[0, 0, :]
        if waveform.size < 2400 or not np.isfinite(waveform).all():
            raise RuntimeError("الموجة الصوتية الناتجة من Audar فارغة أو غير صالحة.")
        output = Path(output_path).resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        self.sf.write(str(output), waveform.astype(np.float32), 24000, subtype="PCM_16")
        size = output.stat().st_size
        if size < 128 or size > 50 * 1024 * 1024:
            output.unlink(missing_ok=True)
            raise RuntimeError("حجم ملف WAV الناتج من Audar غير صالح.")
        return {"bytes": size, "durationSeconds": round(waveform.size / 24000, 2), "voice": safe_voice(voice_id), "sampleRate": 24000}


def serve(args):
    tier = args.tier if args.tier in MODEL_CONFIG else "turbo"
    path = model_file(Path(args.model_dir).resolve(), tier)
    if not path.is_file():
        raise RuntimeError(f"ملف النموذج المحلي غير موجود: {path}")
    synth = Synthesizer(path, Path(args.voice_dir).resolve(), tier, int(args.gpu_layers))

    # A true Arabic warm-up inference is required before the runtime reports ready.
    # This prevents a package/weight-only check from falsely advertising speech readiness.
    with tempfile.TemporaryDirectory(prefix="audar-smoke-") as temp_dir:
        smoke_path = str(Path(temp_dir) / "smoke.wav")
        smoke = synth.synthesize("مرحباً بك، يسعدني التحدث معك اليوم. [curious]", smoke_path, args.default_voice, 320, temperature=0.85)
        if smoke["bytes"] < 128:
            raise RuntimeError("اختبار توليد الصوت العربي الفعلي لم ينجح.")
    emit({"event": "ready", "ok": True, "tier": tier, "device": "CPU" if int(args.gpu_layers) == 0 else "GPU offload", "smokeTest": True, "voiceCount": len(VOICE_PROFILES)})

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
            request_id = str(request.get("requestId") or "")
            result = synth.synthesize(
                str(request.get("text") or ""),
                str(request.get("outputPath") or ""),
                safe_voice(str(request.get("voice") or args.default_voice)),
                int(request.get("maxNewTokens") or 1500),
                float(request.get("temperature", 1.0)),
                int(request.get("topK", 40)),
                float(request.get("topP", 0.90)),
            )
            emit({"ok": True, "requestId": request_id, **result})
        except Exception as exc:
            request_id = str(locals().get("request", {}).get("requestId") or "")
            emit({"ok": False, "requestId": request_id, "error": str(exc)[:900]})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["prepare", "serve"])
    parser.add_argument("model_dir")
    parser.add_argument("voice_dir")
    parser.add_argument("cache_dir")
    parser.add_argument("tier", choices=["turbo", "flash"])
    parser.add_argument("auto_download", nargs="?", default="true")
    parser.add_argument("gpu_layers", nargs="?", default="0")
    parser.add_argument("default_voice", nargs="?", default="demo_male_1")
    args = parser.parse_args()
    try:
        if args.action == "prepare":
            result = download_assets(args)
            emit({"ok": True, **result})
        else:
            serve(args)
    except Exception as exc:
        emit({"ok": False, "error": f"{exc.__class__.__name__}: {exc}"[:1200]})
        sys.exit(2)


if __name__ == "__main__":
    main()
