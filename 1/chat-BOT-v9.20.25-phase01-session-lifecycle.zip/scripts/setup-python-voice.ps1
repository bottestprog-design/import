$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$VoiceDir = Join-Path $Root '.voice-venv'
$ModelsDir = Join-Path $Root 'models'
$ModelPath = Join-Path $ModelsDir 'ar_JO-kareem-medium.onnx'
$ModelConfig = "$ModelPath.json"
$ModelUrl = 'https://huggingface.co/rhasspy/piper-voices/resolve/main/ar/ar_JO/kareem/medium/ar_JO-kareem-medium.onnx'
$ConfigUrl = "$ModelUrl.json"
$ExpectedPiperSha256 = '9e95cab07b679da603bba17c4dec7ab3111320571964ee95c0379603c086491e'
$EnvPath = Join-Path $Root '.env'
$WhisperModelSize = ''
$WhisperModelDir = ''
$Worker = Join-Path $Root 'scripts\voice_worker.py'
$Requirements = Join-Path $Root 'scripts\voice-requirements.txt'
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'

Write-Host '=== chat BOT: إصلاح وتجهيز الصوت الكامل باستخدام Python ===' -ForegroundColor Cyan
Write-Host 'المكونات: Faster-Whisper للتفريغ المحلي، وPiper المحلي، وEdge TTS الاختياري بعد موافقة سحابية صريحة.'
Write-Host 'التفريغ والنطق الافتراضيان محليان بعد التنزيل. الخدمات الصوتية الخارجية لا تستخدم إلا بعد تفعيل الموافقة من لوحة التحكم.'
Write-Host 'سيُنزل نموذج التفريغ المتعدد اللغات (قرابة 500 MB) ونموذج Piper العربي (قرابة 63 MB).'

function Find-PythonLauncher {
  $py = Get-Command 'py.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($py) { return $py.Source }
  return ''
}
function Set-EnvValue([string]$Key, [string]$Value) {
  $lines = @()
  if (Test-Path -LiteralPath $EnvPath) { $lines = @(Get-Content -LiteralPath $EnvPath -ErrorAction Stop) }
  $pattern = '^\s*' + [regex]::Escape($Key) + '\s*='
  $newLines = New-Object 'System.Collections.Generic.List[string]'
  foreach ($existing in $lines) { if ($existing -notmatch $pattern) { $newLines.Add([string]$existing) } }
  $safe = $Value.Replace('"', '\"')
  $newLines.Add("$Key=`"$safe`"")
  Set-Content -LiteralPath $EnvPath -Value $newLines -Encoding UTF8
}

function Get-EnvValue([string]$Key) {
  if (-not (Test-Path -LiteralPath $EnvPath)) { return '' }
  $pattern = '^\s*' + [regex]::Escape($Key) + '\s*=(.*)$'
  $match = Select-String -Path $EnvPath -Pattern $pattern | Select-Object -Last 1
  if (-not $match) { return '' }
  $value = $match.Matches[0].Groups[1].Value.Trim()
  if ($value.Length -ge 2 -and (($value.StartsWith('"') -and $value.EndsWith('"')) -or ($value.StartsWith("'") -and $value.EndsWith("'")))) {
    $value = $value.Substring(1, $value.Length - 2)
  }
  return $value.Trim()
}

function Set-EnvDefault([string]$Key, [string]$Value) {
  if (-not (Get-EnvValue $Key)) { Set-EnvValue $Key $Value }
}

try {
  $WhisperModelSize = (Get-EnvValue 'WHISPER_PY_MODEL').ToLowerInvariant()
  if (-not $WhisperModelSize) { $WhisperModelSize = 'small' }
  $allowedWhisperModels = @('tiny', 'base', 'small', 'medium', 'large-v3', 'large-v3-turbo')
  if ($WhisperModelSize -notin $allowedWhisperModels) { throw "قيمة WHISPER_PY_MODEL غير مدعومة: $WhisperModelSize" }
  $configuredWhisperPath = Get-EnvValue 'WHISPER_PY_MODEL_PATH'
  if (-not $configuredWhisperPath) { $configuredWhisperPath = Join-Path 'models' "faster-whisper-$WhisperModelSize" }
  if ([System.IO.Path]::IsPathRooted($configuredWhisperPath)) { $WhisperModelDir = [System.IO.Path]::GetFullPath($configuredWhisperPath) }
  else { $WhisperModelDir = [System.IO.Path]::GetFullPath((Join-Path $Root $configuredWhisperPath)) }
  $Python = Join-Path $VoiceDir 'Scripts\python.exe'
  $validExisting = $false
  if (Test-Path -LiteralPath $Python -PathType Leaf) {
    try {
      $ver = (& $Python -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")').Trim()
      if ($LASTEXITCODE -eq 0 -and $ver -match '^(3\.(10|11|12|13))$') { $validExisting = $true }
      else { Write-Warning "بيئة الصوت الموجودة تستخدم Python $ver؛ سأعيد إنشاءها بإصدار متوافق." }
    } catch {}
  }
  if (-not $validExisting) {
    if (Test-Path -LiteralPath $VoiceDir) { Remove-Item -LiteralPath $VoiceDir -Recurse -Force -ErrorAction SilentlyContinue }
    $created = $false
    $launcher = Find-PythonLauncher
    if ($launcher) {
      foreach ($version in @('3.12', '3.11', '3.13', '3.10')) {
        try {
          & $launcher "-$version" -m venv $VoiceDir 2>$null
          if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $Python -PathType Leaf)) { $created = $true; break }
        } catch {}
        if (Test-Path -LiteralPath $VoiceDir) { Remove-Item -LiteralPath $VoiceDir -Recurse -Force -ErrorAction SilentlyContinue }
      }
    }
    if (-not $created) {
      $winget = Get-Command 'winget.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($winget) {
        $answer = Read-Host 'لم أعثر على Python 3.10–3.13 متوافق. هل تريد تثبيت Python 3.12 للمستخدم الحالي عبر winget؟ (Y/N)'
        if ($answer -match '(?i)^(y|yes)$') {
          & $winget.Source install --id Python.Python.3.12 --exact --scope user --silent --accept-package-agreements --accept-source-agreements
          if ($LASTEXITCODE -ne 0) { throw 'تعذر تثبيت Python 3.12 عبر winget.' }
          $launcher = Find-PythonLauncher
          if (-not $launcher) { throw 'تم طلب تثبيت Python لكن لم يظهر py.exe؛ أعد فتح الطرفية ثم شغّل الأداة مجددًا.' }
          & $launcher '-3.12' -m venv $VoiceDir
          if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $Python -PathType Leaf)) { $created = $true }
        }
      }
    }
    if (-not $created) { throw 'لم أستطع إنشاء بيئة Python 3.10–3.13. ثبّت Python 3.12 من python.org ثم أعد تشغيل هذا الملف.' }
  }

  New-Item -ItemType Directory -Force -Path $ModelsDir | Out-Null
  Write-Host '[1/4] تثبيت حزم الصوت داخل بيئة معزولة…' -ForegroundColor Yellow
  & $Python -m pip install --upgrade pip
  if ($LASTEXITCODE -ne 0) { throw 'تعذر تحديث pip في بيئة الصوت.' }
  if (-not (Test-Path -LiteralPath $Requirements -PathType Leaf)) { throw 'ملف scripts/voice-requirements.txt غير موجود؛ لا يمكن ضمان تطابق الاعتماديات.' }
  & $Python -m pip install --disable-pip-version-check --upgrade -r $Requirements
  if ($LASTEXITCODE -ne 0) { throw 'فشل تثبيت حزم الصوت. تحقق من الإنترنت والمساحة ثم أعد تشغيل الإعداد.' }
  $compat = (& $Python -c 'import av, piper.espeakbridge, faster_whisper; print(av.__version__)').Trim()
  if ($LASTEXITCODE -ne 0 -or $compat -notmatch '^(1[1-8])\.') { throw "إصدار PyAV غير متوافق مع Faster-Whisper أو جسر Piper: $compat. يلزم av>=11,<19." }

  Write-Host '[2/4] تنزيل نموذج Faster-Whisper والتحقق منه…' -ForegroundColor Yellow
  & $Python $Worker prepare $WhisperModelSize $WhisperModelDir
  if ($LASTEXITCODE -ne 0) { throw 'فشل تجهيز نموذج Faster-Whisper. لم يتم إعلان التفريغ جاهزًا.' }
  if (-not (Test-Path -LiteralPath (Join-Path $WhisperModelDir 'model.bin') -PathType Leaf) -or -not (Test-Path -LiteralPath (Join-Path $WhisperModelDir 'config.json') -PathType Leaf)) { throw 'ملفات نموذج Faster-Whisper غير مكتملة بعد التنزيل.' }

  Write-Host '[3/4] تجهيز نموذج Piper العربي والتحقق من بصمته…' -ForegroundColor Yellow
  $downloadModel = $true
  if ((Test-Path -LiteralPath $ModelPath -PathType Leaf) -and (Get-Item -LiteralPath $ModelPath).Length -gt 10000000) {
    $currentHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $ModelPath).Hash.ToLowerInvariant()
    if ($currentHash -eq $ExpectedPiperSha256) { $downloadModel = $false }
    else { Write-Warning 'نموذج Piper الموجود لا يطابق البصمة المعتمدة؛ سيتم تنزيل نسخة سليمة.' }
  }
  if ($downloadModel) { Invoke-WebRequest -Uri $ModelUrl -OutFile $ModelPath -UseBasicParsing -TimeoutSec 1200 }
  $actualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $ModelPath).Hash.ToLowerInvariant()
  if ($actualHash -ne $ExpectedPiperSha256) { Remove-Item -LiteralPath $ModelPath -Force -ErrorAction SilentlyContinue; throw "فشل تحقق بصمة نموذج Piper. المتوقع $ExpectedPiperSha256 والموجود $actualHash." }
  if (-not (Test-Path -LiteralPath $ModelConfig -PathType Leaf) -or (Get-Item -LiteralPath $ModelConfig).Length -lt 100) { Invoke-WebRequest -Uri $ConfigUrl -OutFile $ModelConfig -UseBasicParsing -TimeoutSec 120 }
  try { $null = Get-Content -Raw -LiteralPath $ModelConfig | ConvertFrom-Json } catch { throw 'ملف إعداد نموذج Piper ليس JSON صالحًا.' }

  Write-Host '[4/4] تحديد FFmpeg واختبار مسار الصوت الكامل وضبط ملف .env…' -ForegroundColor Yellow
  $ffmpeg = ''
  try {
    $ffmpegInfo = (& $Python $Worker ffmpeg-path | Select-Object -Last 1) | ConvertFrom-Json
    if ($ffmpegInfo.ok -eq $true -and (Test-Path -LiteralPath $ffmpegInfo.path -PathType Leaf)) { $ffmpeg = $ffmpegInfo.path }
  } catch {}
  if (-not $ffmpeg) {
    $systemFfmpeg = Get-Command 'ffmpeg.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $systemFfmpeg) { $systemFfmpeg = Get-Command 'ffmpeg' -ErrorAction SilentlyContinue | Select-Object -First 1 }
    if ($systemFfmpeg) { $ffmpeg = $systemFfmpeg.Source }
  }
  if (-not $ffmpeg) { throw 'تعذر العثور على FFmpeg، حتى النسخة المرفقة مع imageio-ffmpeg. لن أعتبر إرسال الصوتيات جاهزًا.' }
  $PiperBinary = Join-Path $VoiceDir 'Scripts\piper.exe'
  if (-not (Test-Path -LiteralPath $PiperBinary -PathType Leaf)) { throw 'لم يتم العثور على piper.exe بعد تثبيت piper-tts؛ لن أعلن النطق المحلي جاهزًا.' }
  Write-Host 'اختبار عملي: توليد صوت عربي محلي، وتحويله إلى OGG/Opus، ثم تفريغه عبر Faster-Whisper…' -ForegroundColor Yellow
  & $Python $Worker voice-smoke-test $PiperBinary $ModelPath $ffmpeg $WhisperModelDir
  if ($LASTEXITCODE -ne 0) { throw 'فشل الاختبار العملي المتكامل للصوت؛ راجع رسالة عامل Python أعلاه قبل استخدام البوت.' }

  if (-not (Test-Path -LiteralPath $EnvPath)) { New-Item -ItemType File -Path $EnvPath | Out-Null }
  Set-EnvValue 'VOICE_PYTHON_BIN' $Python
  Set-EnvValue 'WHISPER_BACKEND' 'python-faster-whisper'
  Set-EnvValue 'WHISPER_PY_MODEL' $WhisperModelSize
  Set-EnvValue 'WHISPER_PY_MODEL_PATH' $WhisperModelDir
  Set-EnvDefault 'WHISPER_PY_DEVICE' 'cpu'
  Set-EnvDefault 'WHISPER_PY_COMPUTE_TYPE' 'int8'
  Set-EnvDefault 'WHISPER_PY_BEAM_SIZE' '5'
  Set-EnvDefault 'WHISPER_PY_VAD' 'true'
  Set-EnvDefault 'WHISPER_PY_VAD_THRESHOLD' '0.5'
  Set-EnvDefault 'WHISPER_PY_MIN_SILENCE_MS' '450'
  Set-EnvDefault 'WHISPER_PY_LOG_PROB_THRESHOLD' '-1.0'
  Set-EnvDefault 'WHISPER_PY_NO_SPEECH_THRESHOLD' '0.6'
  Set-EnvDefault 'WHISPER_PY_COMPRESSION_RATIO_THRESHOLD' '2.4'
  Set-EnvDefault 'WHISPER_PY_CONDITION_ON_PREVIOUS_TEXT' 'false'
  Set-EnvValue 'PIPER_BIN' (Join-Path $VoiceDir 'Scripts\piper.exe')
  Set-EnvValue 'PIPER_MODEL_PATH' $ModelPath
  Set-EnvValue 'FFMPEG_BIN' $ffmpeg
  # Keep an explicitly chosen backend during repair; new setups default to local.
  $existingTtsBackend = ''
  if (Test-Path -LiteralPath $EnvPath) {
    $match = Select-String -Path $EnvPath -Pattern '^\s*TTS_BACKEND\s*=(.*)$' | Select-Object -Last 1
    if ($match) { $existingTtsBackend = $match.Matches[0].Groups[1].Value.Trim().Trim('"').Trim("'") }
  }
  if (-not $existingTtsBackend) { Set-EnvValue 'TTS_BACKEND' 'local' }
  Set-EnvValue 'TTS_REQUIRE_PROOFREAD' 'false'

  Write-Host ''
  Write-Host 'تم إعداد التفريغ والنطق المحليين، واجتاز اختبار التوليد وOGG/Opus والتفريغ العملي؛ النطق العصبي الاختياري متاح عند توفر الاتصال.' -ForegroundColor Green
  Write-Host "التفريغ: Faster-Whisper $WhisperModelSize محلي، بما في ذلك OGG/OPUS عبر PyAV؛ لم يعد FFmpeg شرطًا لمسار التفريغ هذا." -ForegroundColor Green
  Write-Host 'النطق المحلي: Piper هو الافتراضي. لا تُرسل نصوص إلى Edge/API إلا بعد تفعيل الموافقة السحابية من لوحة التحكم.' -ForegroundColor Green
  Write-Host 'اشتراط التدقيق اللغوي مُعطل افتراضيًا حتى لا يمنع إرسال الصوت عند غياب Ollama؛ يمكنك تشغيله اختياريًا من لوحة التحكم.' -ForegroundColor Yellow
  Write-Host 'أعد تشغيل chat BOT بعد إغلاقه، ثم اضغط «فحص حالة التفريغ» و«فحص حالة النطق» في لوحة المحركات الذكية.' -ForegroundColor Cyan
} catch {
  Write-Host "فشل إعداد الصوت: $($_.Exception.Message)" -ForegroundColor Red
  Write-Host 'لم يتم تأكيد جاهزية الصوت. عالج الخطأ الظاهر ثم أعد تشغيل SETUP-PYTHON-VOICE-WINDOWS.bat.' -ForegroundColor Yellow
  exit 1
}
