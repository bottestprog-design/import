$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Write-Host 'يشغّل هذا الملف إعداد Python/Faster-Whisper الموحّد لتفادي تضارب البيئات.' -ForegroundColor Cyan
& (Join-Path $Root 'scripts\setup-python-voice.ps1')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
