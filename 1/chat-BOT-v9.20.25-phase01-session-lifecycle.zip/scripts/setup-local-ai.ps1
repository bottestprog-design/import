$ErrorActionPreference = 'Stop'
$Model = 'qwen3.5:4b'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$EnvFile = Join-Path $Root '.env'
$LocalHost = 'http://127.0.0.1:11434'

function Set-EnvValue([string]$Key, [string]$Value) {
  $lines = @()
  if (Test-Path -LiteralPath $EnvFile) { $lines = @(Get-Content -LiteralPath $EnvFile -ErrorAction Stop) }
  $pattern = '^\s*' + [regex]::Escape($Key) + '\s*='
  $replacement = "$Key=$Value"
  $updated = New-Object 'System.Collections.Generic.List[string]'
  foreach ($line in $lines) { if ($line -notmatch $pattern) { $updated.Add([string]$line) } }
  $updated.Add($replacement)
  Set-Content -LiteralPath $EnvFile -Value $updated -Encoding UTF8
}
function Find-Ollama {
  $command = Get-Command 'ollama.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($command) { return $command.Source }
  $candidates = @(
    (Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'),
    (Join-Path $env:LOCALAPPDATA 'Ollama\ollama.exe'),
    (Join-Path $env:ProgramFiles 'Ollama\ollama.exe')
  )
  foreach ($candidate in $candidates) { if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) { return $candidate } }
  return ''
}
function Test-OllamaApi {
  try { $null = Invoke-RestMethod -Uri "$LocalHost/api/tags" -TimeoutSec 3; return $true } catch { return $false }
}

Write-Host '=== تجهيز مدقق عربي محلي للصوت والردود ===' -ForegroundColor Cyan
Write-Host 'يعمل النموذج على هذا الجهاز. التنزيل الأول كبير، ولا يستخدم هذا الإعداد API سحابية للمحادثة.'
$Ollama = Find-Ollama
if (-not $Ollama) {
  $Winget = Get-Command 'winget.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $Winget) {
    Write-Warning 'Ollama غير مثبت ولا يتوفر winget. ثبّته من https://ollama.com/download/windows ثم أعد تشغيل SETUP-ALL-VOICE-WINDOWS.bat.'
    exit 0
  }
  $answer = Read-Host 'Ollama غير مثبت. هل تريد تثبيته للمستخدم الحالي عبر winget؟ (Y/N)'
  if ($answer -notmatch '(?i)^(y|yes)$') {
    Write-Warning 'تم تخطي Ollama. سيبقى تحويل الصوت إلى نص متاحًا بعد إعداد Whisper، لكن إرسال الصوت مع التدقيق الإلزامي لن يعمل حتى تثبّت Ollama والنموذج المحلي.'
    exit 0
  }
  Write-Host 'جارٍ تثبيت Ollama للمستخدم الحالي…' -ForegroundColor Yellow
  & $Winget.Source install --id Ollama.Ollama --exact --scope user --silent --accept-package-agreements --accept-source-agreements
  if ($LASTEXITCODE -ne 0) {
    Write-Warning "لم يكتمل تثبيت Ollama (exit=$LASTEXITCODE). ثبّته يدويًا من https://ollama.com/download/windows ثم أعد تشغيل هذا الملف."
    exit 0
  }
  $Ollama = Find-Ollama
}
if (-not $Ollama) {
  Write-Warning 'لم أعثر على ollama.exe بعد التثبيت. أغلق نافذة الإعداد، افتح Terminal جديدًا، ثم أعد تشغيل SETUP-ALL-VOICE-WINDOWS.bat.'
  exit 0
}
Set-EnvValue 'OLLAMA_HOST' $LocalHost
if (-not (Test-OllamaApi)) {
  try { Start-Process -FilePath $Ollama -ArgumentList 'serve' -WindowStyle Hidden -ErrorAction Stop | Out-Null } catch {}
  $available = $false
  for ($i = 0; $i -lt 20; $i++) {
    Start-Sleep -Seconds 2
    if (Test-OllamaApi) { $available = $true; break }
  }
  if (-not $available) {
    Write-Warning 'عثرت على Ollama لكن الخدمة المحلية لم تستجب على 127.0.0.1:11434. شغّل Ollama من قائمة Start ثم أعد تشغيل إعداد الصوت.'
    exit 0
  }
}
$modelList = (& $Ollama list 2>$null | Out-String)
if ($modelList -notmatch '(?im)^\s*qwen3\.5:4b(?:\s|$)') {
  $answer = Read-Host 'نموذج المحادثة qwen3.5:4b غير موجود (تنزيل إضافي نحو 3.3–4.0 GB). هل تريد تنزيله محليًا الآن؟ (Y/N)'
  if ($answer -notmatch '(?i)^(y|yes)$') {
    Write-Warning 'لم يُنزّل النموذج. ستبقى ميزة الصوت مع التدقيق الإلزامي متوقفة حتى تنفّذ: ollama pull qwen3.5:4b'
    exit 0
  }
  Write-Host "جارٍ تنزيل $Model؛ قد يحتاج وقتًا ومساحة كبيرة حسب اتصالك." -ForegroundColor Yellow
  & $Ollama pull $Model
  if ($LASTEXITCODE -ne 0) {
    Write-Warning "فشل تنزيل $Model. أعد المحاولة لاحقًا بالأمر: ollama pull $Model"
    exit 0
  }
  $modelList = (& $Ollama list 2>$null | Out-String)
}
if ($modelList -match '(?im)^\s*qwen3\.5:4b(?:\s|$)') {
  Write-Host 'Ollama والنموذج المحلي جاهزان؛ التدقيق اللغوي العربي متاح على هذا الجهاز.' -ForegroundColor Green
  Write-Host 'في واجهة التفاعل، اجعل اسم النموذج qwen3.5:4b واضغط «فحص نموذج الذكاء المحلي».' -ForegroundColor Green
} else {
  Write-Warning "الخدمة متصلة لكن لم يتم تأكيد تثبيت $Model. راجع ollama list."
}
Write-Host 'تأكد من إعادة تشغيل chat BOT بعد انتهاء الإعداد.'
