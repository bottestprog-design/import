#!/usr/bin/env python3
"""Chatterbox Multilingual V3 worker for the local Chat BOT runtime.

Commands:
  prepare MODEL_DIR DEVICE [AUTO_DOWNLOAD]
  serve MODEL_DIR DEVICE

`serve` keeps the model loaded and speaks a JSON-lines protocol on stdin/stdout.
All diagnostic logs go to stderr; stdout is reserved for machine-readable JSON.
"""
from __future__ import annotations

import contextlib
import json
import logging
import os
import numpy as np
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MODEL_REPO = "ResembleAI/chatterbox"
# Pin the official HF snapshot that includes the published multilingual V3 weights.
MODEL_REVISION = "5bb1f6ee58e50c3b8d408bc82a6d3740c2db6e18"
MODEL_FILES = (
    "ve.pt",
    "t3_mtl23ls_v3.safetensors",
    "s3gen.pt",
    "grapheme_mtl_merged_expanded_v1.json",
    "conds.pt",
    "Cangjie5_TC.json",
)
MIN_SIZES = {
    "ve.pt": 1_000_000,
    "t3_mtl23ls_v3.safetensors": 1_000_000_000,
    "s3gen.pt": 500_000_000,
    "grapheme_mtl_merged_expanded_v1.json": 10_000,
    "conds.pt": 10_000,
    "Cangjie5_TC.json": 100_000,
}
SUPPORTED_LANGUAGES = {
    "ar", "da", "de", "el", "en", "es", "fi", "fr", "he", "hi", "it", "ja", "ko",
    "ms", "nl", "no", "pl", "pt", "ru", "sv", "sw", "tr", "zh",
}


def emit(payload: dict) -> None:
    sys.stdout.write(json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def resolve_device(requested: str, torch) -> str:
    name = (requested or "auto").strip().lower()
    if name == "auto":
        if torch.cuda.is_available():
            return "cuda"
        if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            return "mps"
        return "cpu"
    if name == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("تم اختيار CUDA لكن PyTorch لا يرى بطاقة NVIDIA متاحة.")
    if name == "mps" and not (getattr(torch.backends, "mps", None) and torch.backends.mps.is_available()):
        raise RuntimeError("تم اختيار MPS لكن جهاز Apple لا يوفر دعمًا متاحًا.")
    if name not in {"cpu", "cuda", "mps"}:
        raise ValueError("CHATTERBOX_DEVICE يجب أن يكون auto أو cpu أو cuda أو mps.")
    return name


def check_model_files(directory: Path) -> dict:
    missing = []
    details = {}
    for name in MODEL_FILES:
        item = directory / name
        size = item.stat().st_size if item.is_file() else 0
        details[name] = size
        if size < MIN_SIZES[name]:
            missing.append(name)
    if missing:
        raise RuntimeError("ملفات Chatterbox V3 ناقصة أو غير مكتملة: " + ", ".join(missing))
    return details


def download_model(directory: Path) -> None:
    from huggingface_hub import snapshot_download

    directory.mkdir(parents=True, exist_ok=True)
    logging.info("Downloading Chatterbox Multilingual V3 from %s into %s", MODEL_REPO, directory)
    snapshot_download(
        repo_id=MODEL_REPO,
        repo_type="model",
        revision=MODEL_REVISION,
        local_dir=str(directory),
        allow_patterns=list(MODEL_FILES),
        max_workers=4,
    )


def load_engine(directory: Path, requested_device: str):
    import torch
    from chatterbox.mtl_tts import ChatterboxMultilingualTTS

    try:
        threads = int(os.environ.get("CHATTERBOX_CPU_THREADS", "4"))
    except ValueError:
        threads = 4
    torch.set_num_threads(max(1, min(16, threads)))
    device = resolve_device(requested_device, torch)
    engine = ChatterboxMultilingualTTS.from_local(str(directory), device=device, t3_model="v3")
    if engine.conds is None:
        raise RuntimeError("النموذج لا يحتوي على conds.pt؛ لا يوجد صوت افتراضي مهيأ للتوليد.")
    return engine, device


def prepare(directory_arg: str, device_arg: str, auto_download_arg: str = "true") -> None:
    directory = Path(directory_arg).expanduser().resolve()
    auto_download = auto_download_arg.strip().lower() not in {"0", "false", "off", "no"}
    try:
        check_model_files(directory)
    except Exception:
        if not auto_download:
            raise RuntimeError(
                f"لم يُعثر على ملفات النموذج الكاملة داخل {directory}. "
                "نزّل ملفات V3 يدويًا أو فعّل CHATTERBOX_AUTO_DOWNLOAD."
            )
        download_model(directory)
    file_sizes = check_model_files(directory)
    # Load every checkpoint into the selected device once at bootstrap time. This
    # validates compatibility before advertising the expressive engine as ready.
    with contextlib.redirect_stdout(sys.stderr):
        engine, device = load_engine(directory, device_arg)
    del engine
    try:
        import torch
        if device == "cuda":
            torch.cuda.empty_cache()
    except Exception:
        pass
    emit({
        "ok": True,
        "model": "Chatterbox Multilingual V3",
        "modelPath": str(directory),
        "modelRevision": MODEL_REVISION,
        "runtimeSourceCommit": "3f35dfc8fbe63e5b29793289dc68f1875bb317a5",
        "device": device,
        "files": file_sizes,
        "totalBytes": sum(file_sizes.values()),
        "message": "تم تنزيل ملفات V3 والتحقق من تحميل جميع أوزان النموذج محليًا.",
    })


def serve(directory_arg: str, device_arg: str) -> None:
    directory = Path(directory_arg).expanduser().resolve()
    check_model_files(directory)
    # Third-party libraries occasionally print banners. Keep the protocol clean.
    with contextlib.redirect_stdout(sys.stderr):
        engine, device = load_engine(directory, device_arg)
    emit({"event": "ready", "ok": True, "model": "Chatterbox Multilingual V3", "device": device, "sampleRate": int(engine.sr)})

    for raw in sys.stdin:
        line = raw.strip()
        if not line:
            continue
        request_id = None
        try:
            request = json.loads(line)
            if not isinstance(request, dict):
                raise ValueError("طلب الصوت غير صالح.")
            request_id = str(request.get("requestId") or "")[:80]
            text = str(request.get("text") or "").strip()
            language = str(request.get("languageId") or "ar").lower().strip()
            if not request_id:
                raise ValueError("معرّف طلب الصوت مفقود.")
            if not text or len(text) > 1800:
                raise ValueError("النص فارغ أو تجاوز حد 1800 حرف.")
            if language not in SUPPORTED_LANGUAGES:
                raise ValueError(f"لغة Chatterbox غير مدعومة: {language}")
            output = Path(str(request.get("outputPath") or "")).expanduser().resolve()
            if output.suffix.lower() != ".wav":
                raise ValueError("امتداد ملف الصوت المطلوب يجب أن يكون WAV.")
            output.parent.mkdir(parents=True, exist_ok=True)
            exaggeration = max(0.25, min(1.2, float(request.get("exaggeration", 0.55))))
            cfg_weight = max(0.0, min(1.0, float(request.get("cfgWeight", 0.45))))
            temperature = max(0.4, min(1.3, float(request.get("temperature", 0.8))))
            requested_segments = request.get("segments")
            if requested_segments is not None and not isinstance(requested_segments, list):
                raise ValueError("قائمة مقاطع التعبير غير صالحة.")
            if requested_segments:
                if len(requested_segments) > 10:
                    raise ValueError("عدد مقاطع التعبير تجاوز الحد الآمن (10).")
                audio_parts = []
                total_chars = 0
                for index, part in enumerate(requested_segments):
                    if not isinstance(part, dict):
                        raise ValueError("أحد مقاطع التعبير غير صالح.")
                    part_text = str(part.get("text") or "").strip()
                    part_language = str(part.get("languageId") or language).lower().strip()
                    if not part_text or len(part_text) > 1800 or part_language not in SUPPORTED_LANGUAGES:
                        raise ValueError("نص أو لغة أحد مقاطع التعبير غير صالح.")
                    total_chars += len(part_text)
                    if total_chars > 1800:
                        raise ValueError("إجمالي نص المقاطع تجاوز 1800 حرف.")
                    part_exaggeration = max(0.25, min(1.2, float(part.get("exaggeration", exaggeration))))
                    part_cfg = max(0.0, min(1.0, float(part.get("cfgWeight", cfg_weight))))
                    part_temperature = max(0.4, min(1.3, float(part.get("temperature", temperature))))
                    with contextlib.redirect_stdout(sys.stderr):
                        audio = engine.generate(
                            text=part_text,
                            language_id=part_language,
                            exaggeration=part_exaggeration,
                            cfg_weight=part_cfg,
                            temperature=part_temperature,
                        )
                    samples = audio.squeeze(0).detach().float().cpu().numpy().reshape(-1)
                    if samples.size == 0:
                        raise RuntimeError(f"لم ينتج النموذج صوتًا للمقطع رقم {index + 1}.")
                    audio_parts.append(samples.astype(np.float32, copy=False))
                    if index < len(requested_segments) - 1:
                        pause = 0.24 if part_text.endswith(("؟", "?", "!")) else 0.17
                        audio_parts.append(np.zeros(int(engine.sr * pause), dtype=np.float32))
                samples = np.concatenate(audio_parts)
            else:
                with contextlib.redirect_stdout(sys.stderr):
                    audio = engine.generate(
                        text=text,
                        language_id=language,
                        exaggeration=exaggeration,
                        cfg_weight=cfg_weight,
                        temperature=temperature,
                    )
                samples = audio.squeeze(0).detach().float().cpu().numpy().reshape(-1)
            import soundfile as sf
            sf.write(str(output), samples, int(engine.sr), subtype="PCM_16")
            size = output.stat().st_size
            if size < 128:
                raise RuntimeError("ملف WAV الناتج فارغ أو غير مكتمل.")
            emit({"requestId": request_id, "ok": True, "outputPath": str(output), "sampleRate": int(engine.sr), "bytes": size, "device": device})
        except Exception as exc:
            emit({"requestId": request_id, "ok": False, "error": f"{type(exc).__name__}: {str(exc)[:420]}"})


def main() -> int:
    logging.basicConfig(level=logging.INFO, stream=sys.stderr, format="[chatterbox] %(levelname)s %(message)s")
    if len(sys.argv) < 2:
        emit({"ok": False, "error": "حدد prepare أو serve."})
        return 2
    action = sys.argv[1].strip().lower()
    try:
        if action == "prepare":
            if len(sys.argv) < 4:
                raise ValueError("الاستخدام: prepare MODEL_DIR DEVICE [AUTO_DOWNLOAD]")
            prepare(sys.argv[2], sys.argv[3], sys.argv[4] if len(sys.argv) > 4 else "true")
            return 0
        if action == "serve":
            if len(sys.argv) < 4:
                raise ValueError("الاستخدام: serve MODEL_DIR DEVICE")
            serve(sys.argv[2], sys.argv[3])
            return 0
        raise ValueError(f"أمر غير مدعوم: {action}")
    except Exception as exc:
        emit({"ok": False, "error": f"{type(exc).__name__}: {str(exc)[:600]}"})
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
