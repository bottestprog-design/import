#!/usr/bin/env python3
"""Local/online voice worker for chat BOT.

Commands:
  status
  prepare [tiny|base|small|medium|large-v3|large-v3-turbo] [MODEL_DIR]
  transcribe INPUT LANGUAGE MODEL_DIR
  edge-tts OUTPUT VOICE RATE_PCT PITCH_HZ VOLUME_PCT  (text via stdin)
  ffmpeg-path
  voice-smoke-test PIPER_BIN PIPER_MODEL FFMPEG_BIN WHISPER_MODEL_DIR

All machine-readable results are emitted as one JSON object on stdout. Details go to stderr.
"""
from __future__ import annotations
import asyncio
import importlib.util
import json
import os
import sys
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MODELS = ROOT / "models"
DEFAULT_MODEL_DIR = MODELS / "faster-whisper-small"
ALLOWED_WHISPER_MODELS = {"tiny", "base", "small", "medium", "large-v3", "large-v3-turbo"}
ALLOWED_DEVICES = {"cpu", "cuda", "auto"}
ALLOWED_COMPUTE_TYPES = {"int8", "int8_float32", "float32"}
ALLOWED_EDGE_VOICES = set({'ar-SY-LaithNeural', 'ar-MA-JamalNeural', 'ar-DZ-IsmaelNeural', 'ar-YE-MaryamNeural', 'ar-LY-ImanNeural', 'ar-SA-HamedNeural', 'ar-BH-LailaNeural', 'ar-EG-SalmaNeural', 'ar-SA-ZariyahNeural', 'ar-MA-MounaNeural', 'ar-LB-RamiNeural', 'ar-SY-AmanyNeural', 'ar-JO-SanaNeural', 'ar-TN-HediNeural', 'ar-TN-ReemNeural', 'ar-YE-SalehNeural', 'ar-BH-AliNeural', 'ar-QA-MoazNeural', 'ar-EG-ShakirNeural', 'ar-IQ-RanaNeural', 'ar-AE-FatimaNeural', 'ar-IQ-BasselNeural', 'ar-KW-FahedNeural', 'ar-JO-TaimNeural', 'ar-OM-AyshaNeural', 'ar-DZ-AminaNeural', 'ar-OM-AbdullahNeural', 'ar-KW-NouraNeural', 'ar-QA-AmalNeural', 'ar-AE-HamdanNeural', 'ar-LY-OmarNeural', 'ar-LB-LaylaNeural', 'en-US-JennyNeural', 'en-US-GuyNeural', 'en-US-AriaNeural', 'fr-FR-DeniseNeural', 'fr-FR-HenriNeural', 'de-DE-KatjaNeural', 'de-DE-ConradNeural', 'es-ES-ElviraNeural', 'es-ES-AlvaroNeural'})


def emit(value: dict) -> None:
    print(json.dumps(value, ensure_ascii=False, separators=(",", ":")))


def module_available(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ValueError, ModuleNotFoundError):
        return False


def ffmpeg_path() -> str:
    try:
        import imageio_ffmpeg
        candidate = imageio_ffmpeg.get_ffmpeg_exe()
        if candidate and Path(candidate).is_file():
            return str(Path(candidate).resolve())
    except Exception:
        pass
    return ""


def model_dir_from_arg(arg: str | None = None) -> Path:
    return Path(arg).expanduser().resolve() if arg else Path(os.environ.get("WHISPER_PY_MODEL_PATH", str(DEFAULT_MODEL_DIR))).expanduser().resolve()


def whisper_model_available(directory: Path) -> bool:
    return directory.is_dir() and (directory / "model.bin").is_file() and (directory / "config.json").is_file()


def runtime_compatibility() -> dict:
    result = {"fasterWhisperAvailable": False, "fasterWhisperVersion": "", "avAvailable": False, "avVersion": "", "avCompatible": False, "compatibilityError": ""}
    try:
        import av
        result["avAvailable"] = True
        result["avVersion"] = str(getattr(av, "__version__", ""))
        try:
            major = int(result["avVersion"].split(".", 1)[0])
            result["avCompatible"] = 11 <= major < 19
        except (TypeError, ValueError):
            result["avCompatible"] = False
    except Exception as exc:
        result["compatibilityError"] = f"PyAV: {type(exc).__name__}: {str(exc)[:180]}"
    try:
        import faster_whisper
        result["fasterWhisperAvailable"] = True
        result["fasterWhisperVersion"] = str(getattr(faster_whisper, "__version__", ""))
    except Exception as exc:
        result["compatibilityError"] = (result["compatibilityError"] + "; " if result["compatibilityError"] else "") + f"Faster-Whisper: {type(exc).__name__}: {str(exc)[:180]}"
    return result

def piper_tashkeel_info() -> dict:
    result = {"piperTtsVersion": "", "arabicTashkeelAvailable": False, "arabicTashkeelEnabledByDefault": False}
    try:
        from importlib import metadata
        version = metadata.version("piper-tts")
        result["piperTtsVersion"] = version
        try:
            major_minor = tuple(int(part) for part in version.split(".")[:2])
        except (TypeError, ValueError):
            major_minor = (0, 0)
        if major_minor < (1, 8):
            return result
        from piper.voice import PiperVoice
        import dataclasses
        fields = {field.name: field for field in dataclasses.fields(PiperVoice)} if dataclasses.is_dataclass(PiperVoice) else {}
        tashkeel_field = fields.get("use_tashkeel")
        result["arabicTashkeelAvailable"] = tashkeel_field is not None
        result["arabicTashkeelEnabledByDefault"] = bool(tashkeel_field is not None and tashkeel_field.default is True)
    except Exception:
        pass
    return result


def do_status() -> None:
    target = model_dir_from_arg()
    runtime = runtime_compatibility()
    piper_info = piper_tashkeel_info()
    emit({
        "ok": True,
        "python": sys.version.split()[0],
        **runtime,
        "piperAvailable": module_available("piper"),
        **piper_info,
        "edgeTtsAvailable": module_available("edge_tts"),
        "imageioFfmpegAvailable": module_available("imageio_ffmpeg"),
        "ffmpegPath": ffmpeg_path(),
        "whisperModelAvailable": whisper_model_available(target),
        "whisperModelPath": str(target),
    })


def do_prepare(model_size: str, model_dir: str | None = None) -> None:
    size = (model_size or "small").strip().lower()
    if size not in ALLOWED_WHISPER_MODELS:
        raise ValueError("حجم نموذج Whisper غير مدعوم.")
    from huggingface_hub import snapshot_download
    from faster_whisper import WhisperModel
    target = Path(model_dir).expanduser().resolve() if model_dir else MODELS / f"faster-whisper-{size}"
    target.mkdir(parents=True, exist_ok=True)
    repo = f"Systran/faster-whisper-{size}"
    # A local directory makes subsequent transcription independent of network access.
    snapshot_download(repo_id=repo, local_dir=str(target))
    model = WhisperModel(str(target), device="cpu", compute_type="int8")
    del model
    if not whisper_model_available(target):
        raise RuntimeError("تم التنزيل لكن ملفات نموذج Faster-Whisper لم تجتز فحص الجاهزية.")
    emit({"ok": True, "model": size, "modelPath": str(target), "message": "تم تنزيل نموذج Faster-Whisper والتحقق من ملفات النموذج محليًا."})


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}

def _env_int(name: str, default: int, minimum: int, maximum: int) -> int:
    try:
        value = int(os.environ.get(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(maximum, value))

def _env_float(name: str, default: float, minimum: float, maximum: float) -> float:
    try:
        value = float(os.environ.get(name, str(default)))
    except (TypeError, ValueError):
        value = default
    if not (value == value and abs(value) != float("inf")):
        value = default
    return max(minimum, min(maximum, value))

def _transcription_options() -> dict:
    device = os.environ.get("WHISPER_PY_DEVICE", "cpu").strip().lower()
    compute_type = os.environ.get("WHISPER_PY_COMPUTE_TYPE", "int8").strip().lower()
    if device not in ALLOWED_DEVICES:
        raise ValueError(f"WHISPER_PY_DEVICE غير مدعوم: {device}")
    if compute_type not in ALLOWED_COMPUTE_TYPES:
        raise ValueError(f"WHISPER_PY_COMPUTE_TYPE غير مدعوم: {compute_type}")
    return {
        "device": device, "compute_type": compute_type,
        "beam_size": _env_int("WHISPER_PY_BEAM_SIZE", 5, 1, 10),
        "vad_filter": _env_bool("WHISPER_PY_VAD", True),
        "vad_parameters": {
            "threshold": _env_float("WHISPER_PY_VAD_THRESHOLD", 0.5, 0.1, 0.95),
            "min_silence_duration_ms": _env_int("WHISPER_PY_MIN_SILENCE_MS", 450, 100, 3000),
        },
        "condition_on_previous_text": _env_bool("WHISPER_PY_CONDITION_ON_PREVIOUS_TEXT", False),
        "compression_ratio_threshold": _env_float("WHISPER_PY_COMPRESSION_RATIO_THRESHOLD", 2.4, 1.0, 5.0),
        "log_prob_threshold": _env_float("WHISPER_PY_LOG_PROB_THRESHOLD", -1.0, -3.0, 0.0),
        "no_speech_threshold": _env_float("WHISPER_PY_NO_SPEECH_THRESHOLD", 0.6, 0.1, 0.99),
    }

def do_transcribe(input_file: str, language: str, model_dir: str) -> None:
    source = Path(input_file).expanduser().resolve()
    target = model_dir_from_arg(model_dir)
    if not source.is_file() or source.stat().st_size <= 0:
        raise ValueError("ملف الصوت فارغ أو غير موجود.")
    if not whisper_model_available(target):
        raise RuntimeError(f"نموذج Faster-Whisper المحلي غير مكتمل ({target.name}). شغّل التهيئة التلقائية ثم أعد المحاولة.")
    compatibility = runtime_compatibility()
    if not compatibility["fasterWhisperAvailable"]:
        raise RuntimeError(compatibility["compatibilityError"] or "تعذر تحميل Faster-Whisper.")
    if not compatibility["avCompatible"]:
        raise RuntimeError(f"إصدار PyAV غير متوافق مع Faster-Whisper: {compatibility['avVersion'] or 'غير معروف'}؛ يلزم إصدار من 11 إلى أقل من 19. أعد تشغيل إصلاح مكتبات الصوت.")
    from faster_whisper import WhisperModel
    options = _transcription_options()
    model = WhisperModel(str(target), device=options.pop("device"), compute_type=options.pop("compute_type"))
    selected_language = None if str(language).lower() in {"auto", "detect", ""} else str(language).lower()
    segments, info = model.transcribe(
        str(source), language=selected_language, task="transcribe",
        beam_size=options["beam_size"],
        vad_filter=options["vad_filter"],
        vad_parameters=options["vad_parameters"] if options["vad_filter"] else None,
        condition_on_previous_text=options["condition_on_previous_text"],
        compression_ratio_threshold=options["compression_ratio_threshold"],
        log_prob_threshold=options["log_prob_threshold"],
        no_speech_threshold=options["no_speech_threshold"],
    )
    text_parts = []
    weighted_logprob_sum, weighted_token_count = 0.0, 0
    no_speech_probs, compression_ratios = [], []
    low_confidence_segments = 0
    segment_count = 0
    for segment in segments:
        segment_count += 1
        chunk = str(getattr(segment, "text", "") or "").strip()
        if chunk:
            text_parts.append(chunk)
        segment_logprob = None
        try:
            segment_logprob = float(segment.avg_logprob)
            token_count = max(1, len(getattr(segment, 'tokens', []) or []))
            weighted_logprob_sum += segment_logprob * token_count
            weighted_token_count += token_count
        except (AttributeError, TypeError, ValueError):
            pass
        try:
            no_speech = float(segment.no_speech_prob)
            no_speech_probs.append(no_speech)
        except (AttributeError, TypeError, ValueError):
            no_speech = None
        try:
            compression = float(segment.compression_ratio)
            compression_ratios.append(compression)
        except (AttributeError, TypeError, ValueError):
            compression = None
        weak_log_probability = segment_logprob is None or segment_logprob < options["log_prob_threshold"]
        likely_silence = no_speech is not None and no_speech >= options["no_speech_threshold"] and weak_log_probability
        weak_repetition = compression is not None and compression >= options["compression_ratio_threshold"]
        if likely_silence or weak_repetition or (segment_logprob is not None and segment_logprob < options["log_prob_threshold"]):
            low_confidence_segments += 1
    transcript = " ".join(text_parts).replace("\u0000", "").strip()
    if not transcript:
        raise RuntimeError("لم يتمكن Faster-Whisper من استخراج كلمات واضحة من التسجيل. جرّب تسجيلًا أوضح.")
    def mean(values):
        return round(sum(values) / len(values), 4) if values else None
    emit({
        "ok": True, "transcript": transcript[:12000], "text": transcript[:12000],
        "language": str(getattr(info, "language", selected_language or "unknown")),
        "languageProbability": round(float(getattr(info, "language_probability", 0.0) or 0.0), 4),
        "segments": segment_count,
        "avgLogProbability": round(weighted_logprob_sum / weighted_token_count, 4) if weighted_token_count else None,
        "avgNoSpeechProbability": mean(no_speech_probs),
        "maxCompressionRatio": round(max(compression_ratios), 4) if compression_ratios else None,
        "lowConfidenceSegments": low_confidence_segments,
        "duration": round(float(getattr(info, "duration", 0.0) or 0.0), 3),
        "transcriptionConfig": {key: value for key, value in options.items()},
        "backend": "python-faster-whisper",
    })


async def do_edge_tts(output_file: str, voice: str, rate_pct: str, pitch_hz: str, volume_pct: str) -> None:
    target = Path(output_file).expanduser().resolve()
    text = sys.stdin.read().strip()
    if not text:
        raise ValueError("لا يوجد نص صالح للنطق.")
    if len(text) > 1800:
        raise ValueError("النص أطول من الحد المسموح للنطق (1800 حرف).")
    if voice not in ALLOWED_EDGE_VOICES:
        raise ValueError("الصوت العربي المحدد غير موجود في القائمة الآمنة.")
    def signed_number(raw: str, minimum: int, maximum: int, suffix: str) -> str:
        value = int(float(raw))
        value = max(minimum, min(maximum, value))
        return f"{value:+d}{suffix}"
    rate = signed_number(rate_pct, -40, 40, "%")
    pitch = signed_number(pitch_hz, -30, 30, "Hz")
    volume = signed_number(volume_pct, -30, 30, "%")
    target.parent.mkdir(parents=True, exist_ok=True)
    import edge_tts
    await edge_tts.Communicate(text=text, voice=voice, rate=rate, volume=volume, pitch=pitch).save(str(target))
    if not target.is_file() or target.stat().st_size < 100:
        raise RuntimeError("خدمة النطق لم تنتج ملف صوت صالحًا.")
    emit({"ok": True, "path": str(target), "bytes": target.stat().st_size, "voice": voice, "rate": rate, "pitch": pitch, "volume": volume, "backend": "edge-tts"})



def do_voice_smoke_test(piper_bin: str, piper_model: str, ffmpeg_bin: str, whisper_model_dir: str) -> None:
    """Exercise local speech generation, WhatsApp Opus packaging and transcription."""
    piper = Path(piper_bin).expanduser().resolve()
    model = Path(piper_model).expanduser().resolve()
    ffmpeg = Path(ffmpeg_bin).expanduser().resolve()
    whisper_dir = Path(whisper_model_dir).expanduser().resolve()
    model_cfg = Path(str(model) + ".json")
    if not piper.is_file():
        raise RuntimeError(f"Piper executable not found: {piper}")
    if not model.is_file() or model.stat().st_size < 10_000_000 or not model_cfg.is_file():
        raise RuntimeError("Piper Arabic model/config is missing or incomplete.")
    if not ffmpeg.is_file():
        raise RuntimeError(f"FFmpeg executable not found: {ffmpeg}")
    if not whisper_model_available(whisper_dir):
        raise RuntimeError("Faster-Whisper model is missing or incomplete.")
    sample = "مرحبا هذا اختبار صوت عربي"
    with tempfile.TemporaryDirectory(prefix="chatbot-voice-smoke-") as temp_dir:
        temp = Path(temp_dir)
        wav = temp / "sample.wav"
        ogg = temp / "sample.ogg"
        tts = subprocess.run(
            [str(piper), "--model", str(model), "--output_file", str(wav), "--length_scale", "1.0", "--noise_scale", "0.667", "--noise_w", "0.8"],
            input=(sample + "\n").encode("utf-8"), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            timeout=120, check=False,
            # Piper's Windows console entry point reads stdin as Python text.
            # Force UTF-8 because the voice text is Arabic and stdin is a pipe.
            env={**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"},
        )
        if tts.returncode != 0 or not wav.is_file() or wav.stat().st_size < 128:
            raw_detail = (tts.stderr or b"").decode("utf-8", errors="replace").strip()
            # The wave module can raise "# channels not specified" while unwinding
            # and hide an earlier phonemizer/import exception. Keep both ends so
            # diagnostics retain the original cause as well as the final traceback.
            detail = raw_detail if len(raw_detail) <= 1400 else raw_detail[:700] + "\n... traceback truncated ...\n" + raw_detail[-700:]
            raise RuntimeError(f"Piper smoke test failed ({tts.returncode}): {detail or 'Piper returned no diagnostic output.'}")
        conversion = subprocess.run(
            [str(ffmpeg), "-y", "-v", "error", "-i", str(wav), "-vn", "-ac", "1", "-ar", "48000", "-c:a", "libopus", "-b:a", "32k", "-f", "ogg", str(ogg)],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=90, check=False,
        )
        if conversion.returncode != 0 or not ogg.is_file() or ogg.stat().st_size < 100:
            detail = (conversion.stderr or b"").decode("utf-8", errors="replace")[-500:]
            raise RuntimeError(f"FFmpeg OGG/Opus smoke test failed ({conversion.returncode}): {detail}")
        audio_header = ogg.read_bytes()[:262144]
        if not audio_header.startswith(b"OggS") or b"OpusHead" not in audio_header:
            raise RuntimeError("FFmpeg created a file, but the output is not a valid OGG/Opus voice-note container.")
        from faster_whisper import WhisperModel
        options = _transcription_options()
        whisper = WhisperModel(str(whisper_dir), device=options["device"], compute_type=options["compute_type"])
        segments, info = whisper.transcribe(
            str(ogg), language="ar", task="transcribe", beam_size=options["beam_size"],
            vad_filter=options["vad_filter"],
            vad_parameters=options["vad_parameters"] if options["vad_filter"] else None,
            condition_on_previous_text=options["condition_on_previous_text"],
            compression_ratio_threshold=options["compression_ratio_threshold"],
            log_prob_threshold=options["log_prob_threshold"],
            no_speech_threshold=options["no_speech_threshold"],
        )
        chunks, no_speech, compression = [], [], []
        weighted_logprob_sum, weighted_token_count = 0.0, 0
        for segment in segments:
            text = str(getattr(segment, "text", "") or "").strip()
            if text: chunks.append(text)
            try:
                token_count = max(1, len(getattr(segment, 'tokens', []) or []))
                weighted_logprob_sum += float(segment.avg_logprob) * token_count
                weighted_token_count += token_count
            except (AttributeError, TypeError, ValueError): pass
            try: no_speech.append(float(segment.no_speech_prob))
            except (AttributeError, TypeError, ValueError): pass
            try: compression.append(float(segment.compression_ratio))
            except (AttributeError, TypeError, ValueError): pass
        transcript = " ".join(chunks).strip()
        del whisper
        if not transcript:
            raise RuntimeError("Faster-Whisper smoke test produced no transcript from the generated Arabic audio.")
        detected = str(getattr(info, "language", "unknown"))
        language_probability = float(getattr(info, "language_probability", 0.0) or 0.0)
        avg_log = weighted_logprob_sum / weighted_token_count if weighted_token_count else None
        avg_no_speech = sum(no_speech) / len(no_speech) if no_speech else None
        max_compression = max(compression) if compression else None
        if detected.split("-")[0].lower() != "ar" or language_probability < 0.2:
            raise RuntimeError(f"Arabic smoke test detected unexpected language/confidence: {detected} ({language_probability:.2f}).")
        if avg_log is not None and avg_log < -1.5:
            raise RuntimeError(f"Arabic smoke test token probability is too low ({avg_log:.2f}).")
        if avg_no_speech is not None and avg_no_speech >= 0.8:
            raise RuntimeError(f"Arabic smoke test appears to contain silence/noise ({avg_no_speech:.2f}).")
        emit({"ok": True, "piper": True, "ffmpegOpus": True, "fasterWhisper": True, "transcript": transcript[:500], "detectedLanguage": detected, "languageProbability": round(language_probability, 4), "avgLogProbability": round(avg_log, 4) if avg_log is not None else None, "avgNoSpeechProbability": round(avg_no_speech, 4) if avg_no_speech is not None else None, "maxCompressionRatio": round(max_compression, 4) if max_compression is not None else None, "oggBytes": ogg.stat().st_size, "message": "Local Arabic speech generation, OGG/Opus conversion, and quality-aware transcription smoke test passed."})

def main() -> int:
    if len(sys.argv) < 2:
        emit({"ok": False, "error": "لم يُحدد أمر لمحرك الصوت."})
        return 2
    action = sys.argv[1].strip().lower()
    try:
        if action == "status":
            do_status()
        elif action == "prepare":
            do_prepare(sys.argv[2] if len(sys.argv) > 2 else "small", sys.argv[3] if len(sys.argv) > 3 else None)
        elif action == "transcribe":
            if len(sys.argv) < 5:
                raise ValueError("بيانات التفريغ غير مكتملة.")
            do_transcribe(sys.argv[2], sys.argv[3], sys.argv[4])
        elif action == "edge-tts":
            if len(sys.argv) < 7:
                raise ValueError("إعدادات النطق العصبي غير مكتملة.")
            asyncio.run(do_edge_tts(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6]))
        elif action == "ffmpeg-path":
            path = ffmpeg_path()
            if not path:
                raise RuntimeError("لم تُثبت حزمة imageio-ffmpeg ولم يُعثر على FFmpeg محلي.")
            emit({"ok": True, "path": path})
        elif action == "voice-smoke-test":
            if len(sys.argv) < 6:
                raise ValueError("مسارات اختبار الصوت غير مكتملة.")
            do_voice_smoke_test(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
        else:
            raise ValueError("أمر محرك الصوت غير معروف.")
        return 0
    except Exception as exc:
        # Keep diagnostics concise and never print environment variables or keys.
        print(f"voice-worker: {type(exc).__name__}: {str(exc)[:700]}", file=sys.stderr)
        emit({"ok": False, "error": str(exc)[:700], "errorType": type(exc).__name__})
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
