'use strict';

/**
 * Bounded FIFO queue. Ordering is guaranteed per (session, conversation), while
 * different conversations may progress concurrently. Keys are retained briefly
 * in memory; durable idempotency belongs to InboundEventJournal.
 */
class InboundMessageQueue {
  constructor({ maxConcurrentSessions = 3, maxConcurrentConversations = maxConcurrentSessions, maxPendingPerSession = 40, dedupeTtlMs = 600000, now = Date.now, onError = () => {} } = {}) {
    this.maxConcurrentConversations = Math.max(1, Math.min(32, Number(maxConcurrentConversations) || 3));
    // Backwards-compatible public name used by earlier diagnostics/tests.
    this.maxConcurrentSessions = this.maxConcurrentConversations;
    this.maxPendingPerSession = Math.max(1, Math.min(500, Number(maxPendingPerSession) || 40));
    this.dedupeTtlMs = Math.max(1000, Number(dedupeTtlMs) || 600000);
    this.now = now;
    this.onError = onError;
    this.queues = new Map();
    this.activeConversations = new Set();
    this.activeSessions = this.activeConversations;
    this.pendingBySession = new Map();
    this.keys = new Map();
    this.activeCount = 0;
    this.closed = false;
    this.pumpQueued = false;
  }

  queueId(sessionId, conversationId) {
    return `${String(sessionId || 'main')}|${String(conversationId || 'default').toLowerCase()}`;
  }

  enqueue(sessionId, key, run, { conversationId = 'default', maxWaitMs = 60000, maxPendingPerSession = this.maxPendingPerSession } = {}) {
    const sid = String(sessionId || 'main');
    if (this.closed) return Promise.resolve({ accepted: false, reason: 'closed' });
    if (typeof run !== 'function') return Promise.resolve({ accepted: false, reason: 'invalid-task' });
    this.pruneKeys();
    const eventKey = key ? `${sid}|${String(key)}` : '';
    if (eventKey && this.keys.has(eventKey)) return Promise.resolve({ accepted: false, reason: 'duplicate' });
    const queueKey = this.queueId(sid, conversationId);
    const queue = this.queues.get(queueKey) || [];
    const pending = Number(this.pendingBySession.get(sid) || 0);
    const cap = Math.max(1, Math.min(500, Number(maxPendingPerSession) || this.maxPendingPerSession));
    if (pending >= cap) return Promise.resolve({ accepted: false, reason: 'queue-full' });

    const enqueuedAt = this.now();
    return new Promise((resolve, reject) => {
      const item = { run, resolve, reject, key: eventKey, sessionId: sid, conversationId: String(conversationId || 'default'), queueKey, enqueuedAt, maxWaitMs: Math.max(1000, Number(maxWaitMs) || 60000) };
      if (eventKey) this.keys.set(eventKey, { at: enqueuedAt, status: 'queued' });
      queue.push(item);
      this.queues.set(queueKey, queue);
      this.pendingBySession.set(sid, pending + 1);
      this.schedulePump();
    });
  }

  pruneKeys() {
    const cutoff = this.now() - this.dedupeTtlMs;
    for (const [key, record] of this.keys) if (!record || Number(record.at) < cutoff) this.keys.delete(key);
    while (this.keys.size > 10000) this.keys.delete(this.keys.keys().next().value);
  }

  schedulePump() {
    if (this.pumpQueued) return;
    this.pumpQueued = true;
    queueMicrotask(() => { this.pumpQueued = false; this.pump(); });
  }

  pump() {
    if (this.activeCount >= this.maxConcurrentConversations) return;
    for (const [queueKey, queue] of this.queues) {
      if (this.activeCount >= this.maxConcurrentConversations) break;
      if (this.activeConversations.has(queueKey) || !queue.length) continue;
      const item = queue.shift();
      if (!queue.length) this.queues.delete(queueKey);
      this.activeConversations.add(queueKey);
      this.activeCount++;
      if (item.key) this.keys.set(item.key, { at: item.enqueuedAt, status: 'running' });
      Promise.resolve().then(async () => {
        const waitedMs = this.now() - item.enqueuedAt;
        if (waitedMs > item.maxWaitMs) {
          item.resolve({ accepted: false, reason: 'queue-expired', waitedMs });
          return;
        }
        const result = await item.run({ waitedMs, enqueuedAt: item.enqueuedAt, conversationId: item.conversationId });
        item.resolve({ accepted: true, reason: 'processed', waitedMs, result });
      }).catch(error => {
        try { this.onError(item.sessionId, error); } catch {}
        item.reject(error);
      }).finally(() => {
        if (item.key) this.keys.set(item.key, { at: this.now(), status: 'done' });
        this.activeConversations.delete(queueKey);
        this.activeCount = Math.max(0, this.activeCount - 1);
        const pending = Math.max(0, Number(this.pendingBySession.get(item.sessionId) || 1) - 1);
        if (pending) this.pendingBySession.set(item.sessionId, pending); else this.pendingBySession.delete(item.sessionId);
        this.schedulePump();
      });
    }
  }

  async close({ drain = true, timeoutMs = 15000 } = {}) {
    this.closed = true;
    if (!drain) {
      let dropped = 0;
      for (const queue of this.queues.values()) for (const item of queue) { item.resolve({ accepted: false, reason: 'closed' }); dropped++; }
      this.queues.clear(); this.pendingBySession.clear();
      return { drained: false, active: this.activeCount, dropped: dropped > 0 };
    }
    const deadline = this.now() + Math.max(0, Number(timeoutMs) || 0);
    while ((this.activeCount > 0 || [...this.queues.values()].some(queue => queue.length)) && this.now() < deadline) {
      this.schedulePump();
      await new Promise(resolve => setTimeout(resolve, 20));
    }
    const drained = this.activeCount === 0 && [...this.queues.values()].every(queue => queue.length === 0);
    if (!drained) {
      for (const [queueKey, queue] of this.queues) for (const item of queue) {
        item.resolve({ accepted: false, reason: 'close-timeout' });
        const pending = Math.max(0, Number(this.pendingBySession.get(item.sessionId) || 1) - 1);
        if (pending) this.pendingBySession.set(item.sessionId, pending); else this.pendingBySession.delete(item.sessionId);
      }
      this.queues.clear();
    }
    return { drained, active: this.activeCount, dropped: !drained };
  }

  stats() {
    return {
      activeSessions: this.activeCount, activeConversations: this.activeCount,
      queuedSessions: this.queues.size,
      queued: [...this.queues.values()].reduce((sum, queue) => sum + queue.length, 0),
      pendingBySession: Object.fromEntries(this.pendingBySession),
      dedupeKeys: this.keys.size, closed: this.closed,
    };
  }
}

module.exports = { InboundMessageQueue };
