'use strict';

const crypto = require('node:crypto');
const { ChannelProvider, channelError, normalizeCapability } = require('./channel-provider');

const sleep = ms => new Promise(resolve => setTimeout(resolve, Math.max(0, Number(ms) || 0)));
function safeString(value, max = 4096) { return String(value ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').slice(0, max); }
function idSerialized(value) { if (!value) return ''; if (typeof value === 'string') return value; if (value._serialized) return String(value._serialized); if (value.$1) return String(value.$1); if (value.remote) return idSerialized(value.remote); return value.id !== undefined ? String(value.id) : ''; }
function chatIdFromMessage(message) { const fromMe = Boolean(message?.fromMe || message?._data?.id?.fromMe); const values = [message?.id?.remote, message?._data?.id?.remote, message?._data?.chatId, message?.chatId, fromMe ? message?.to : message?.from, message?.from, message?.to]; for (const value of values) { const id = idSerialized(value).trim().toLowerCase(); if (id.endsWith('@g.us') || id.endsWith('@c.us') || id.endsWith('@lid')) return id; } return ''; }
function messageKind(message) {
  const raw = String(message?.type || message?.rawType || 'unknown').toLowerCase();
  const map = {
    chat: 'text', text: 'text', image: 'image', video: 'video', audio: 'audio', ptt: 'audio', voice: 'audio',
    document: 'document', sticker: 'sticker', location: 'location', vcard: 'contact', multi_vcard: 'contact',
    poll_creation: 'poll', poll_update: 'poll_vote', scheduled_event_creation: 'event', reaction: 'reaction',
    order: 'order', product: 'product', revoked: 'revoked',
  };
  return map[raw] || 'unknown';
}

class WhatsAppWebAdapter extends ChannelProvider {
  constructor({ manager, Poll = null, ScheduledEvent = null, version = '1.34.7', env = process.env } = {}) {
    super({ id: 'whatsapp-web', name: 'WhatsApp Web (whatsapp-web.js)', version });
    if (!manager) throw new TypeError('WhatsAppWebAdapter requires a WhatsAppManager.');
    this.manager = manager;
    this.Poll = Poll;
    this.ScheduledEvent = ScheduledEvent;
    this.env = env;
  }
  async connect(sessionId, options = {}) { return this.manager.start(sessionId, options); }
  async disconnect(sessionId, options = {}) { return this.manager.stop(sessionId, options); }
  async getStatus(sessionId) { return this.manager.listRuntime(sessionId); }
  async validateTarget(sessionId, target) {
    const chatId = String(typeof target === 'string' ? target : (target?.chatId || target?.jid || target?.waChatId || target?.whatsappJid || '')).trim().toLowerCase();
    if (!/^(?:\d{5,25}(?:-\d+)*@g\.us|\d{5,25}@c\.us|\d{5,25}@lid)$/i.test(chatId)) {
      throw channelError('CHANNEL_TARGET_INVALID', 'معرّف محادثة WhatsApp غير صالح.', { providerId: this.id });
    }
    const access = this.manager.assertChatAuthorized(sessionId, chatId);
    return { ok: true, providerId: this.id, chatId, chatType: chatId.endsWith('@g.us') ? 'group' : 'individual', access };
  }
  async withTypingIndicator(sessionId, chatId, operation) {
    if (String(this.env.OUTBOX_TYPING_INDICATOR || '').trim().toLowerCase() !== 'true') return operation();
    let chat = null;
    try {
      const client = await this.manager.ensureReady(sessionId);
      chat = await client.getChatById(chatId);
      if (typeof chat?.sendStateTyping === 'function') {
        await chat.sendStateTyping();
        const duration = Math.max(0, Math.min(5000, Number(this.env.OUTBOX_TYPING_DURATION_MS) || 700));
        if (duration) await sleep(duration);
      }
    } catch (error) {
      this.manager.log?.(sessionId, 'DEBUG', `تعذر إظهار مؤشر الكتابة؛ سيستمر الإرسال دون المؤشر. ${String(error?.message || error).slice(0, 120)}`);
    }
    try { return await operation(); }
    finally { try { if (typeof chat?.clearState === 'function') await chat.clearState(); } catch {} }
  }
  async sendText(sessionId, target, text, options = {}) {
    const verified = await this.validateTarget(sessionId, target);
    return this.withTypingIndicator(sessionId, verified.chatId, () => this.manager._sendTextViaWeb(sessionId, verified.chatId, text, options));
  }
  async sendMedia(sessionId, target, file, options = {}) {
    const verified = await this.validateTarget(sessionId, target);
    return this.manager._sendMediaViaWeb(sessionId, verified.chatId, file, options);
  }
  async sendVoice(sessionId, target, file, options = {}) {
    const verified = await this.validateTarget(sessionId, target);
    return this.manager._sendVoiceViaWeb(sessionId, verified.chatId, file, options);
  }
  async sendPoll(sessionId, target, input = {}) {
    const verified = await this.validateTarget(sessionId, target);
    if (verified.chatType !== 'group') {
      throw channelError('CHANNEL_CAPABILITY_UNAVAILABLE', 'إنشاء استطلاعات WhatsApp Web مفعّل في هذه المنصة للمجموعات فقط إلى أن ينجح اختبار حي منفصل للمحادثات الفردية.', { providerId: this.id, capability: 'sendPoll' });
    }
    if (String(this.env.WHATSAPP_WEB_ENABLE_EXPERIMENTAL_POLLS || '').toLowerCase() !== 'true') {
      throw channelError('CHANNEL_CAPABILITY_EXPERIMENTAL', 'ميزة الاستطلاعات تجريبية ومغلقة افتراضيًا. يلزم تفعيلها صراحةً بعد اختبار حساب المجموعة.', { providerId: this.id, capability: 'sendPoll' });
    }
    if (typeof this.Poll !== 'function') throw channelError('CHANNEL_CAPABILITY_UNAVAILABLE', 'بنية Poll غير متاحة في إصدار مكتبة WhatsApp المثبت.', { providerId: this.id, capability: 'sendPoll' });
    const question = safeString(input.question || input.name, 255).trim();
    const pollOptions = [...new Set((Array.isArray(input.options) ? input.options : []).map(value => safeString(value, 100).trim()).filter(Boolean))];
    if (!question || pollOptions.length < 2 || pollOptions.length > 12) throw channelError('CHANNEL_INPUT_INVALID', 'الاستطلاع يحتاج سؤالًا وخيارين إلى 12 خيارًا مختلفًا.', { providerId: this.id, capability: 'sendPoll' });
    const poll = new this.Poll(question, pollOptions, { allowMultipleAnswers: input.allowMultipleAnswers === true });
    const client = await this.manager.ensureReady(sessionId);
    const result = await this.manager.sendConfirmed(this.manager.store.safeSessionId(sessionId), verified.chatId,
      () => client.sendMessage(verified.chatId, poll), Number(input.timeoutMs) || 30000, 'إنشاء استطلاع', question);
    this.manager.entry(sessionId).lastSent = { at: new Date().toISOString(), chatId: verified.chatId, kind: 'poll' };
    return result;
  }
  async sendEvent(sessionId, target, input = {}) {
    const verified = await this.validateTarget(sessionId, target);
    if (String(this.env.WHATSAPP_WEB_ENABLE_EXPERIMENTAL_EVENTS || '').toLowerCase() !== 'true') {
      throw channelError('CHANNEL_CAPABILITY_EXPERIMENTAL', 'الأحداث المجدولة تجريبية ومغلقة افتراضيًا إلى حين اختبارها على الحساب ونوع المحادثة.', { providerId: this.id, capability: 'sendEvent' });
    }
    if (typeof this.ScheduledEvent !== 'function') throw channelError('CHANNEL_CAPABILITY_UNAVAILABLE', 'ScheduledEvent غير متاحة في إصدار مكتبة WhatsApp المثبت.', { providerId: this.id, capability: 'sendEvent' });
    const name = safeString(input.name || input.title, 120).trim();
    const startTime = input.startTime instanceof Date ? input.startTime : new Date(input.startTime);
    const endTime = input.endTime ? (input.endTime instanceof Date ? input.endTime : new Date(input.endTime)) : null;
    if (!name || !Number.isFinite(startTime.getTime()) || startTime.getTime() <= Date.now() + 30000) {
      throw channelError('CHANNEL_INPUT_INVALID', 'الحدث يحتاج اسمًا وموعد بداية صالحًا في المستقبل بأكثر من 30 ثانية.', { providerId: this.id, capability: 'sendEvent' });
    }
    if (endTime && (!Number.isFinite(endTime.getTime()) || endTime <= startTime)) throw channelError('CHANNEL_INPUT_INVALID', 'موعد نهاية الحدث يجب أن يأتي بعد موعد بدايته.', { providerId: this.id, capability: 'sendEvent' });
    const callType = ['video', 'voice', 'none'].includes(String(input.callType || 'none')) ? String(input.callType || 'none') : 'none';
    const event = new this.ScheduledEvent(name, startTime, {
      description: safeString(input.description, 1000), endTime,
      location: safeString(input.location, 300), callType,
    });
    const client = await this.manager.ensureReady(sessionId);
    const result = await this.manager.sendConfirmed(this.manager.store.safeSessionId(sessionId), verified.chatId,
      () => client.sendMessage(verified.chatId, event), Number(input.timeoutMs) || 30000, 'إنشاء حدث WhatsApp', name);
    this.manager.entry(sessionId).lastSent = { at: new Date().toISOString(), chatId: verified.chatId, kind: 'scheduled_event' };
    return result;
  }
  async sendReaction(sessionId, messageId, emoji) { return this.manager._reactToMessageViaWeb(sessionId, messageId, emoji); }
  normalizeInbound(sessionId, message) {
    const chatId = chatIdFromMessage(message);
    const messageId = idSerialized(message?.id || message?._data?.id).trim();
    const timestamp = Number(message?.timestamp || message?._data?.t || Date.now() / 1000);
    const senderId = idSerialized(message?.author || (message?.fromMe ? message?.to : message?.from) || message?._data?.author).toLowerCase();
    const fromMe = Boolean(message?.fromMe || message?._data?.id?.fromMe);
    const fallbackKey = [this.id, sessionId, chatId, timestamp, senderId, safeString(message?.body, 256)].join('|');
    const stableId = messageId || crypto.createHash('sha256').update(fallbackKey).digest('hex').slice(0, 32);
    return {
      eventId: `${this.id}:${String(sessionId)}:${stableId}`,
      provider: this.id, providerVersion: this.version, accountId: String(sessionId),
      conversationId: chatId, messageId: stableId, providerMessageId: messageId || null,
      senderId, senderType: fromMe ? 'account' : (chatId.endsWith('@g.us') ? 'group_member' : 'contact'),
      fromMe, quotedMessageId: idSerialized(message?.hasQuotedMsg && message?._data?.quotedStanzaID || message?._data?.quotedMsg?.id).trim() || null,
      kind: messageKind(message), text: safeString(message?.body, 10000),
      caption: safeString(message?.caption, 2048), mimeType: safeString(message?.mimetype || message?._data?.mimetype, 120),
      sizeBytes: Number(message?.size || message?._data?.size) || null,
      mediaAssetId: null, sentAt: timestamp > 0 ? new Date(timestamp * 1000).toISOString() : null,
      receivedAt: new Date().toISOString(), providerTimestamp: timestamp,
      ackState: Number.isFinite(Number(message?.ack)) ? Number(message.ack) : null,
      rawProviderType: safeString(message?.type, 80), correlationId: `${this.id}:${String(sessionId)}:${stableId}`,
    };
  }
  async getCapabilities(sessionId, context = {}) {
    const sid = String(sessionId || 'main');
    const runtime = this.manager.listRuntime(sid);
    const entry = this.manager.entry(sid);
    const chatType = ['group', 'individual', 'status', 'channel'].includes(context.chatType) ? context.chatType : 'unknown';
    const at = new Date().toISOString();
    const base = {
      sendText: { status: 'available', reason: 'يتوفر عبر Client.sendMessage بعد جاهزية الجلسة.' },
      sendMedia: { status: 'available', reason: 'يتوفر عبر MessageMedia وClient.sendMessage؛ قيود الحجم والنوع تُفحص قبل الإرسال.' },
      voiceNote: { status: 'available', reason: 'يتطلب OGG/Opus صالحًا؛ نجاح الإرسال الحي يحتاج اختبار الحساب.' },
      sendReaction: { status: typeof this.manager._reactToMessageViaWeb === 'function' ? 'available' : 'unavailable', reason: 'يعتمد على البحث عن الرسالة ثم Message.react؛ يتطلب جلسة جاهزة عند التنفيذ.' },
      sendPoll: !this.Poll || typeof this.manager.ensureReady !== 'function'
        ? { status: 'unavailable', reason: 'بنية Poll أو مسار إرسال الموصل غير متاح.' }
        : chatType === 'individual' ? { status: 'unavailable', reason: 'سياسة V10 تمنع تشغيل Poll في المحادثات الفردية قبل اختبار حي مخصص.' }
          : { status: 'experimental', reason: 'متاح على مستوى المكتبة؛ يتطلب مجموعة واختبارًا حيًا وتفعيل WHATSAPP_WEB_ENABLE_EXPERIMENTAL_POLLS.' , constraints: { allowedChatTypes: ['group'], maxOptions: 12 } },
      sendEvent: !this.ScheduledEvent || typeof this.manager.ensureReady !== 'function'
        ? { status: 'unavailable', reason: 'بنية ScheduledEvent أو مسار إرسال الموصل غير متاح.' }
        : { status: 'experimental', reason: 'تتطلب اختبارًا حيًا حسب نوع المحادثة وتفعيل WHATSAPP_WEB_ENABLE_EXPERIMENTAL_EVENTS.' },
      buttons: { status: 'deprecated', reason: 'Buttons قديمة ومعلّمة Deprecated في whatsapp-web.js؛ استخدم رسالة نصية بديلة.' },
      lists: { status: 'deprecated', reason: 'Lists قديمة ومعلّمة Deprecated في whatsapp-web.js؛ استخدم رسالة نصية بديلة.' },
      flows: { status: 'unavailable', reason: 'WhatsApp Flows ليست قدرة موثقة لهذا الموصل.' },
      catalog: { status: 'unavailable', reason: 'Catalog/Commerce لا تُنقل من Cloud API إلى WhatsApp Web.' },
    };
    return {
      providerId: this.id, providerName: this.name, providerVersion: this.version,
      accountId: sid, chatType, observedAt: at, sessionStatus: runtime.status, sessionReady: Boolean(runtime.ready),
      unofficial: true, capabilities: Object.fromEntries(Object.entries(base).map(([id, value]) => [id, normalizeCapability(id, { ...value, testedAt: null }, { providerId: this.id, providerVersion: this.version, accountId: sid, chatType })])),
    };
  }
}

module.exports = { WhatsAppWebAdapter, messageKind };
