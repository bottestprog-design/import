'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { createReadStream } = require('node:fs');

const STATUSES = new Set(['queued', 'validating', 'sending', 'accepted', 'created', 'delivered', 'read', 'failed', 'uncertain', 'cancelled', 'dead-letter']);
const FINAL_STATUSES = new Set(['delivered', 'read', 'failed', 'cancelled', 'dead-letter']);
const AMBIGUOUS_CODES = new Set(['SEND_UNCERTAIN', 'SEND_TIMEOUT', 'ECONNRESET', 'ETIMEDOUT', 'EPIPE', 'ECONNABORTED', 'UND_ERR_SOCKET', 'UND_ERR_CONNECT_TIMEOUT']);

function safeSessionId(value) {
  const id = String(value || 'main').trim();
  if (!/^[a-zA-Z0-9_-]{1,80}$/.test(id)) throw new TypeError('Invalid outbox session id.');
  return id;
}
function clean(value, max = 500) { return String(value ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').slice(0, max); }
function serializeId(value) {
  if (!value) return '';
  if (typeof value === 'string') return value;
  if (value._serialized) return String(value._serialized);
  if (value.$1) return String(value.$1);
  if (value.remote) return serializeId(value.remote);
  return value.id !== undefined ? String(value.id) : '';
}
function messageChatId(message) {
  const fromMe = Boolean(message?.fromMe || message?._data?.id?.fromMe);
  const values = [message?.id?.remote, message?._data?.id?.remote, message?._data?.chatId, message?.chatId, fromMe ? message?.to : message?.from, message?.from, message?.to];
  for (const value of values) {
    const id = serializeId(value).trim().toLowerCase();
    if (id.endsWith('@g.us') || id.endsWith('@c.us') || id.endsWith('@lid')) return id;
  }
  return '';
}
function hashFile(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = createReadStream(filePath);
    stream.on('error', reject);
    stream.on('data', chunk => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}
function extractProviderMessageId(result) {
  return clean(
    result?.__chatBotAck?.id || result?.messageId || result?.messages?.[0]?.id ||
    result?.result?.id?._serialized || result?.result?.id || result?.id?._serialized || result?.id || '', 240,
  );
}
function ackStatus(ack) {
  const n = Number(ack);
  if (!Number.isFinite(n)) return null;
  if (n >= 3) return 'read';
  if (n >= 2) return 'delivered';
  if (n >= 1) return 'accepted';
  if (n < 0) return 'failed';
  return null;
}
function statusFromResult(result) {
  const status = String(result?.__chatBotAck?.status || '').toLowerCase();
  if (status === 'confirmed') return 'delivered';
  if (status === 'created') return extractProviderMessageId(result) ? 'created' : 'uncertain';
  if (status === 'accepted') return extractProviderMessageId(result) ? 'accepted' : 'uncertain';
  return extractProviderMessageId(result) ? 'created' : 'uncertain';
}

class OutboundOutbox {
  constructor({ rootDir, minIntervalMs = 250, retryBaseMs = 500, dedupeWindowMs = 90000, maxAttempts = 3, maxJournalBytes = 32 * 1024 * 1024, maxRecords = 50000, now = Date.now, logger = () => {}, allowedRoots = [] } = {}) {
    if (!rootDir) throw new TypeError('OutboundOutbox requires rootDir.');
    this.rootDir = path.resolve(rootDir);
    fs.mkdirSync(this.rootDir, { recursive: true, mode: 0o700 });
    try { fs.chmodSync(this.rootDir, 0o700); } catch {}
    this.minIntervalMs = Math.max(0, Math.min(10000, Number(minIntervalMs) || 0));
    this.maxAttempts = Math.max(1, Math.min(10, Number(maxAttempts) || 3));
    this.retryBaseMs = Math.max(100, Math.min(30000, Number(retryBaseMs) || 500));
    this.dedupeWindowMs = Math.max(1000, Math.min(24 * 60 * 60 * 1000, Number(dedupeWindowMs) || 90000));
    this.maxJournalBytes = Math.max(1024 * 1024, Number(maxJournalBytes) || 32 * 1024 * 1024);
    this.maxRecords = Math.max(1000, Number(maxRecords) || 50000);
    this.now = now;
    this.logger = logger;
    this.allowedRoots = allowedRoots.map(value => { try { return fs.realpathSync(path.resolve(value)); } catch { return path.resolve(value); } });
    this.sessions = new Map();
    this.recovered = new Set();
    this.queues = new Map();
    this.submissionQueues = new Map();
    this.active = new Map();
    this.lastDispatchAt = new Map();
    this.pendingAcks = new Map();
    this.pendingStatuses = new Map();
    this.closed = false;
  }

  file(sessionId) { return path.join(this.rootDir, `${safeSessionId(sessionId)}.ndjson`); }
  state(sessionId) {
    const sid = safeSessionId(sessionId);
    if (this.sessions.has(sid)) return this.sessions.get(sid);
    const state = { records: new Map(), idempotency: new Map(), corruptLines: 0, sequence: 0 };
    const file = this.file(sid);
    if (fs.existsSync(file)) {
      const raw = fs.readFileSync(file, 'utf8');
      for (const line of raw.split(/\r?\n/)) {
        if (!line.trim()) continue;
        let row;
        try { row = JSON.parse(line); } catch { state.corruptLines++; continue; }
        if (row?.op === 'record' && row.record?.id) {
          const record = row.record;
          state.records.set(record.id, record);
          if (record.idempotencyKey) state.idempotency.set(record.idempotencyKey, record.id);
          state.sequence = Math.max(state.sequence, Number(record.sequence) || 0);
        } else if (row?.op === 'transition' && row.id && STATUSES.has(row.status)) {
          const prior = state.records.get(row.id);
          if (prior) state.records.set(row.id, { ...prior, ...(row.patch || {}), status: row.status, updatedAt: row.at || prior.updatedAt });
        }
      }
    }
    this.sessions.set(sid, state);
    return state;
  }

  append(sessionId, row) {
    const file = this.file(sessionId);
    fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
    // A process can be terminated during an append. Repair only the final torn
    // line before adding another record so NDJSON framing remains recoverable.
    if (fs.existsSync(file)) {
      const repairFd = fs.openSync(file, 'r+');
      try {
        const size = fs.fstatSync(repairFd).size;
        if (size > 0) {
          const last = Buffer.alloc(1);
          fs.readSync(repairFd, last, 0, 1, size - 1);
          if (last[0] !== 0x0a) {
            const raw = fs.readFileSync(file);
            const newline = raw.lastIndexOf(0x0a);
            const tail = raw.subarray(newline + 1).toString('utf8');
            let validTail = false;
            try { JSON.parse(tail); validTail = true; } catch {}
            if (validTail) fs.writeSync(repairFd, Buffer.from('\n'), 0, 1, size);
            else {
              fs.ftruncateSync(repairFd, newline >= 0 ? newline + 1 : 0);
              const state = this.sessions.get(safeSessionId(sessionId));
              if (state) state.corruptLines++;
            }
            fs.fsyncSync(repairFd);
          }
        }
      } finally { fs.closeSync(repairFd); }
    }
    const fd = fs.openSync(file, 'a', 0o600);
    try {
      const line = Buffer.from(`${JSON.stringify(row)}\n`, 'utf8');
      let offset = 0;
      while (offset < line.length) {
        const written = fs.writeSync(fd, line, offset, line.length - offset, null);
        if (!written) throw new Error('Outbound outbox append returned zero bytes.');
        offset += written;
      }
      fs.fsyncSync(fd);
    } finally { fs.closeSync(fd); }
    try { fs.chmodSync(file, 0o600); } catch {}
  }

  transition(sessionId, id, status, patch = {}) {
    if (!STATUSES.has(status)) throw new TypeError(`Invalid outbox status: ${status}`);
    const sid = safeSessionId(sessionId), state = this.state(sid), prior = state.records.get(String(id));
    if (!prior) return null;
    const allowed = {};
    for (const key of ['providerMessageId','ackState','lastError','retryable','safeToRetry','sideEffectAbsent','nextAttemptAt','cancelledAt','completedAt','acceptedAt','createdAtProvider','deliveredAt','readAt','reconciledAt','correlationId','retryOf','manualRetry','duplicateRiskAccepted','lastProviderStatus']) {
      if (patch[key] !== undefined) allowed[key] = typeof patch[key] === 'string' ? clean(patch[key], 500) : patch[key];
    }
    if (status === 'sending') allowed.attempts = Math.min(100, Number(prior.attempts || 0) + 1);
    const at = new Date(this.now()).toISOString();
    this.append(sid, { op: 'transition', id: String(id), status, at, patch: allowed });
    const next = { ...prior, ...allowed, status, updatedAt: at };
    state.records.set(String(id), next);
    return this.publicRecord(next);
  }

  async normalizePayload(input) {
    const payload = input.payload && typeof input.payload === 'object' ? structuredClone(input.payload) : {};
    if (payload.filePath) {
      const absolute = path.resolve(String(payload.filePath));
      let real;
      try { real = await fs.promises.realpath(absolute); } catch { throw Object.assign(new Error('ملف الإرسال غير موجود؛ لم يُضف إلى صندوق الصادر.'), { code: 'OUTBOX_FILE_MISSING', retryable: false }); }
      if (this.allowedRoots.length && !this.allowedRoots.some(root => real === root || real.startsWith(`${root}${path.sep}`))) {
        throw Object.assign(new Error('مسار ملف الإرسال خارج مجلدات بيانات التطبيق المسموحة.'), { code: 'OUTBOX_FILE_PATH_DENIED', retryable: false });
      }
      const stat = await fs.promises.stat(real);
      if (!stat.isFile() || stat.size <= 0) throw Object.assign(new Error('ملف الإرسال فارغ أو ليس ملفًا عاديًا.'), { code: 'OUTBOX_FILE_INVALID', retryable: false });
      payload.filePath = real;
      payload.fileSize = stat.size;
      payload.fileMtimeMs = stat.mtimeMs;
      payload.fileSha256 = await hashFile(real);
    }
    return payload;
  }

  async submit(input, handlers = {}) {
    if (this.closed) throw Object.assign(new Error('صندوق الصادر مغلق.'), { code: 'OUTBOX_CLOSED' });
    if (typeof handlers.dispatch !== 'function') throw new TypeError('OutboundOutbox.submit requires dispatch.');
    const sid = safeSessionId(input.sessionId), queueKey = `${sid}|${clean(input.conversationId || input.target || 'unknown', 180).toLowerCase()}`;
    const previous = this.submissionQueues.get(queueKey) || Promise.resolve();
    // Serialize only preparation/persistence, not the network wait. This reserves
    // FIFO order at invocation time while allowing later intents to be durably queued.
    const preparation = previous.catch(() => {}).then(() => this.submitOrdered(input, handlers));
    const tail = preparation.then(() => undefined, () => undefined);
    this.submissionQueues.set(queueKey, tail);
    try {
      const prepared = await preparation;
      return prepared && prepared.promise ? await prepared.promise : prepared?.result;
    } finally { if (this.submissionQueues.get(queueKey) === tail) this.submissionQueues.delete(queueKey); }
  }

  async submitOrdered(input, { validate = async () => true, dispatch } = {}) {
    if (this.closed) throw Object.assign(new Error('صندوق الصادر مغلق.'), { code: 'OUTBOX_CLOSED' });
    if (typeof dispatch !== 'function') throw new TypeError('OutboundOutbox.submit requires dispatch.');
    const sid = safeSessionId(input.sessionId), state = this.state(sid);
    const idempotencyKey = clean(input.idempotencyKey || crypto.randomUUID(), 180);
    if (!idempotencyKey) throw new TypeError('idempotencyKey is required.');
    const payload = await this.normalizePayload(input);
    const fingerprint = crypto.createHash('sha256').update(JSON.stringify({ providerId: input.providerId, conversationId: input.conversationId, kind: input.kind, target: input.target, payload })).digest('hex');
    let priorId = state.idempotency.get(idempotencyKey);
    if (priorId) {
      const prior = state.records.get(priorId);
      if (!prior || prior.fingerprint !== fingerprint) throw Object.assign(new Error('استُخدم idempotencyKey نفسه مع هدف أو محتوى مختلف.'), { code: 'OUTBOX_IDEMPOTENCY_CONFLICT' });
      const ageMs = this.now() - (Date.parse(prior.createdAt) || this.now());
      if (prior.status === 'cancelled' || (['accepted','created','delivered','read'].includes(prior.status) && ageMs >= this.dedupeWindowMs)) priorId = null;
      if (priorId && this.active.has(prior.id)) return { promise: this.active.get(prior.id) };
      if (priorId && prior.status === 'sending') {
        this.transition(sid, prior.id, 'uncertain', { lastError: 'orphaned-sending-record-detected-during-idempotent-submit; automatic retry suppressed' });
        throw Object.assign(new Error('وجد النظام محاولة إرسال سابقة انقطعت بعد بدء الإرسال؛ نتيجتها غير مؤكدة ولن تُكرر تلقائيًا.'), { code: 'SEND_UNCERTAIN', outboxId: prior.id });
      }
      if (priorId && prior.status === 'validating') this.transition(sid, prior.id, 'queued', { lastError: 'orphaned-validation-record-safe-to-resume' });
      if (priorId && prior.status === 'queued') return { promise: this.enqueueRecord(sid, this.state(sid).records.get(prior.id), { validate, dispatch }) };
      if (priorId && prior.status === 'failed' && prior.safeToRetry === true && prior.sideEffectAbsent === true && Number(prior.attempts || 0) < this.maxAttempts) {
        this.transition(sid, prior.id, 'queued', { lastError: '', retryable: false, safeToRetry: false, sideEffectAbsent: false, nextAttemptAt: null });
        return { promise: this.enqueueRecord(sid, this.state(sid).records.get(prior.id), { validate, dispatch }) };
      }
      if (priorId && prior.status === 'uncertain') throw Object.assign(new Error('نتيجة الإرسال السابق غير مؤكدة؛ لا تعِد المحاولة تلقائيًا. استخدم المصالحة أو إعادة المحاولة اليدوية مع إقرار مخاطر التكرار.'), { code: 'SEND_UNCERTAIN', outboxId: prior.id });
      if (priorId && (prior.status === 'failed' || prior.status === 'dead-letter')) throw Object.assign(new Error('محاولة الإرسال السابقة فشلت ولم يُسمح بإعادة تلقائية.'), { code: 'OUTBOX_PREVIOUS_FAILURE', outboxId: prior.id });
      if (priorId) return { result: { __chatBotAck: { status: prior.status, mode: 'outbox-deduplicated', id: prior.providerMessageId || '' }, __chatBotOutbox: { id: prior.id, idempotencyKey, duplicate: true, status: prior.status } } };
    }
    const now = new Date(this.now()).toISOString();
    const record = {
      id: crypto.randomUUID(), sequence: ++state.sequence, idempotencyKey, fingerprint,
      sessionId: sid, providerId: clean(input.providerId || 'unknown', 80),
      conversationId: clean(input.conversationId || input.target || 'unknown', 180).toLowerCase(),
      target: clean(typeof input.target === 'string' ? input.target : JSON.stringify(input.target || ''), 240),
      kind: clean(input.kind || 'text', 40), payload,
      correlationId: clean(input.correlationId || crypto.randomUUID(), 180),
      status: 'queued', attempts: 0, createdAt: now, updatedAt: now,
      providerMessageId: '', ackState: null, lastError: '', retryable: false, safeToRetry: false, sideEffectAbsent: false,
      nextAttemptAt: null, retryOf: input.retryOf || null,
    };
    this.append(sid, { op: 'record', record });
    state.records.set(record.id, record);
    state.idempotency.set(idempotencyKey, record.id);
    this.compactIfNeeded(sid);
    return { promise: this.enqueueRecord(sid, record, { validate, dispatch }) };
  }

  enqueueRecord(sessionId, record, handlers = {}) {
    handlers = { validate: typeof handlers.validate === 'function' ? handlers.validate : async () => true, dispatch: handlers.dispatch };
    if (typeof handlers.dispatch !== 'function') throw new TypeError('Outbox dispatch handler is required.');
    if (this.active.has(record.id)) return this.active.get(record.id);
    const queueKey = `${sessionId}|${record.conversationId}`;
    const previous = this.queues.get(queueKey) || Promise.resolve();
    const execution = previous.catch(() => {}).then(() => this.processRecord(sessionId, record.id, handlers));
    const tracked = execution.finally(() => {
      if (this.active.get(record.id) === tracked) this.active.delete(record.id);
      if (this.queues.get(queueKey) === queueTail) this.queues.delete(queueKey);
    });
    const queueTail = tracked.catch(() => {});
    this.active.set(record.id, tracked);
    this.queues.set(queueKey, queueTail);
    return tracked;
  }

  async verifyPayloadFile(record) {
    const payload = record?.payload || {};
    if (!payload.filePath) return true;
    let stat;
    try { stat = await fs.promises.stat(payload.filePath); } catch { throw Object.assign(new Error('ملف Outbox لم يعد موجودًا؛ أوقف الإرسال بدل اختيار ملف بديل.'), { code: 'OUTBOX_FILE_MISSING' }); }
    if (!stat.isFile() || stat.size !== Number(payload.fileSize) || stat.mtimeMs !== Number(payload.fileMtimeMs)) throw Object.assign(new Error('تغير ملف Outbox بعد تسجيله؛ أوقف الإرسال لتجنب إرسال محتوى مختلف.'), { code: 'OUTBOX_FILE_CHANGED' });
    const digest = await hashFile(payload.filePath);
    if (digest !== payload.fileSha256) throw Object.assign(new Error('بصمة ملف Outbox لا تطابق النسخة التي تم تسجيلها.'), { code: 'OUTBOX_FILE_CHANGED' });
    return true;
  }

  async processRecord(sessionId, id, handlers) {
    const { validate, dispatch } = handlers;
    let record = this.state(sessionId).records.get(id);
    if (!record || record.status !== 'queued') return this.resultFor(record, true);
    try {
      this.transition(sessionId, id, 'validating');
      await validate(record);
      await this.verifyPayloadFile(record);
      const latest = this.state(sessionId).records.get(id);
      if (!latest || latest.status === 'cancelled') return this.resultFor(latest, true);
      const queueKey = `${sessionId}|${latest.conversationId}`;
      const waitMs = Math.max(0, this.minIntervalMs - (this.now() - (this.lastDispatchAt.get(queueKey) || 0)));
      if (waitMs) await new Promise(resolve => setTimeout(resolve, waitMs));
      this.transition(sessionId, id, 'sending');
      this.lastDispatchAt.set(queueKey, this.now());
      const result = await dispatch(latest);
      const providerMessageId = extractProviderMessageId(result);
      const mapped = statusFromResult(result);
      if (mapped === 'uncertain' && !providerMessageId) {
        this.transition(sessionId, id, 'uncertain', { lastError: 'provider-returned-without-message-id-or-delivery-proof; automatic retry suppressed' });
        throw Object.assign(new Error('لم يُرجع موصل القناة معرف رسالة أو دليل قبول؛ نتيجة الإرسال غير مؤكدة ولن تُكرر تلقائيًا.'), { code: 'SEND_UNCERTAIN' });
      }
      const current = this.state(sessionId).records.get(id);
      const nextStatus = ['delivered','read','failed','uncertain'].includes(current?.status) ? current.status : mapped;
      this.transition(sessionId, id, nextStatus, {
        providerMessageId: providerMessageId || current?.providerMessageId || '',
        acceptedAt: mapped === 'accepted' ? new Date(this.now()).toISOString() : current?.acceptedAt,
        createdAtProvider: ['created','delivered','read'].includes(mapped) ? new Date(this.now()).toISOString() : current?.createdAtProvider,
        completedAt: ['delivered','read'].includes(nextStatus) ? new Date(this.now()).toISOString() : current?.completedAt,
        lastError: '',
      });
      if (providerMessageId) { this.applyPendingAck(sessionId, providerMessageId); this.applyPendingStatus(sessionId, providerMessageId); }
      const saved = this.state(sessionId).records.get(id);
      return this.decorateResult(result, saved, false);
    } catch (error) {
      const code = String(error?.code || '').toUpperCase();
      const errorText = String(error?.message || error || '').toLowerCase();
      const uncertain = AMBIGUOUS_CODES.has(code) || code.includes('UNCERTAIN') || code.includes('TIMEOUT') || error?.possibleSideEffect === true || /timeout|timed out|econnreset|econnrefused|eai_again|network|fetch failed|protocol error|target closed|connection closed|socket hang up|temporarily unavailable|temporary failure/.test(errorText);
      const safe429 = code === 'CLOUD_API_REJECTED' && Number(error?.statusCode) === 429;
      const current = this.state(sessionId).records.get(id);
      if (safe429 && Number(current?.attempts || 0) < this.maxAttempts) {
        this.transition(sessionId, id, 'queued', { lastError: clean(error?.message || error, 360), retryable: true, safeToRetry: true, sideEffectAbsent: true, nextAttemptAt: new Date(this.now() + this.retryBaseMs * Math.min(8, 2 ** Math.max(0, Number(current?.attempts || 1) - 1))).toISOString() });
        await new Promise(resolve => setTimeout(resolve, this.retryBaseMs * Math.min(8, 2 ** Math.max(0, Number(current?.attempts || 1) - 1))));
        return this.processRecord(sessionId, id, handlers);
      }
      const status = uncertain ? 'uncertain' : (safe429 ? 'dead-letter' : 'failed');
      this.transition(sessionId, id, status, {
        lastError: clean(error?.message || error, 360), retryable: safe429,
        safeToRetry: safe429, sideEffectAbsent: safe429,
      });
      if (uncertain) {
        error.code = 'SEND_UNCERTAIN';
        error.outboxId = id;
        error.retryable = false;
      } else error.outboxId = id;
      throw error;
    }
  }

  decorateResult(result, record, duplicate) {
    const outbox = { id: record?.id || '', idempotencyKey: record?.idempotencyKey || '', status: record?.status || 'unknown', duplicate: Boolean(duplicate), correlationId: record?.correlationId || '' };
    if (result && typeof result === 'object' && !Array.isArray(result)) return { ...result, __chatBotOutbox: outbox };
    return { value: result, __chatBotOutbox: outbox };
  }
  resultFor(record, duplicate) {
    if (!record) return null;
    return { __chatBotAck: { status: record.status, mode: 'outbox-recovered', id: record.providerMessageId || '' }, __chatBotOutbox: { id: record.id, idempotencyKey: record.idempotencyKey, status: record.status, duplicate: Boolean(duplicate), correlationId: record.correlationId } };
  }

  recover(sessionId) {
    const sid = safeSessionId(sessionId), state = this.state(sid);
    if (this.recovered.has(sid)) return { recovered: false, queued: [...state.records.values()].filter(row => row.status === 'queued').length, uncertain: 0 };
    let queued = 0, uncertain = 0;
    for (const record of state.records.values()) {
      if (record.status === 'sending') { this.transition(sid, record.id, 'uncertain', { lastError: 'worker-interrupted-after-send-start; automatic retry suppressed', retryable: false, safeToRetry: false }); uncertain++; }
      else if (record.status === 'validating') { this.transition(sid, record.id, 'queued', { lastError: 'worker-interrupted-before-provider-call; safe to resume' }); queued++; }
      else if (record.status === 'queued') queued++;
    }
    this.recovered.add(sid);
    return { recovered: true, queued, uncertain };
  }

  resumeQueued(sessionId, dispatchFactory, { providerId = null } = {}) {
    const sid = safeSessionId(sessionId), recovery = this.recover(sid);
    const queued = [...this.state(sid).records.values()].filter(record => record.status === 'queued' && (!providerId || record.providerId === providerId));
    const tasks = queued.map(record => this.enqueueRecord(sid, record, dispatchFactory(record)));
    return { ...recovery, resumed: tasks.length, promise: Promise.allSettled(tasks) };
  }

  reconcileAck(sessionId, event = {}) {
    const sid = safeSessionId(sessionId), providerMessageId = serializeId(event.id || event.messageId);
    if (!providerMessageId) return { matched: false, reason: 'message-id-missing' };
    const state = this.state(sid);
    const record = [...state.records.values()].find(row => row.providerMessageId === providerMessageId);
    if (!record) { this.prunePending(); this.pendingAcks.set(`${sid}|${providerMessageId}`, { ...event, receivedAt: this.now() }); return { matched: false, reason: 'pending-provider-id' }; }
    const status = ackStatus(event.ack ?? event.ackState);
    if (!status) return { matched: true, unchanged: true, record: this.publicRecord(record) };
    const rank = { queued: 0, validating: 1, sending: 2, accepted: 3, created: 3, delivered: 4, read: 5, uncertain: 2, failed: 2, cancelled: 6, 'dead-letter': 6 };
    if ((rank[record.status] ?? 0) > (rank[status] ?? 0) && !['uncertain','failed'].includes(record.status)) return { matched: true, unchanged: true, record: this.publicRecord(record) };
    const patch = { ackState: Number(event.ack ?? event.ackState), reconciledAt: new Date(this.now()).toISOString() };
    if (status === 'delivered') patch.deliveredAt = new Date(this.now()).toISOString();
    if (status === 'read') patch.readAt = new Date(this.now()).toISOString();
    this.transition(sid, record.id, status, patch);
    return { matched: true, record: this.publicRecord(this.state(sid).records.get(record.id)) };
  }

  reconcileMessageCreate(sessionId, message) {
    const sid = safeSessionId(sessionId), providerMessageId = serializeId(message?.id || message?._data?.id);
    const conversationId = messageChatId(message);
    if (!providerMessageId || !conversationId) return { matched: false, reason: 'message-identity-missing' };
    const state = this.state(sid);
    const body = String(message?.body || '').trim();
    const candidates = [...state.records.values()].filter(row => row.conversationId === conversationId && row.status === 'sending' && !row.providerMessageId).sort((a,b) => Number(a.sequence)-Number(b.sequence));
    const record = candidates.find(row => {
      const p = row.payload || {};
      if (['text','reply','poll','event'].includes(row.kind)) {
        const expected = String(p.text || p.question || p.name || '').trim();
        return expected ? body === expected || body.includes(expected.slice(0, Math.min(30, expected.length))) : false;
      }
      if (row.kind === 'media' || row.kind === 'voice') return Boolean(message?.hasMedia || message?._data?.mimetype || ['image','video','audio','document','sticker'].includes(String(message?.type || '').toLowerCase()));
      return false;
    });
    if (!record) return { matched: false, reason: 'no-inflight-outbox-record' };
    this.transition(sid, record.id, 'created', { providerMessageId, createdAtProvider: new Date(this.now()).toISOString() });
    this.applyPendingAck(sid, providerMessageId);
    this.applyPendingStatus(sid, providerMessageId);
    return { matched: true, record: this.publicRecord(this.state(sid).records.get(record.id)) };
  }

  reconcileProviderStatus(sessionId, event = {}) {
    const sid = safeSessionId(sessionId), providerMessageId = serializeId(event.providerMessageId || event.messageId || event.id);
    if (!providerMessageId) return { matched: false, reason: 'provider-message-id-missing' };
    const state = this.state(sid), record = [...state.records.values()].find(row => row.providerMessageId === providerMessageId);
    if (!record) { this.prunePending(); this.pendingStatuses.set(`${sid}|${providerMessageId}`, { ...event, receivedAt: this.now() }); return { matched: false, reason: 'pending-provider-id' }; }
    const raw = String(event.status || event.providerStatus || '').toLowerCase();
    const status = raw === 'read' ? 'read' : raw === 'delivered' ? 'delivered' : raw === 'sent' ? 'accepted' : raw === 'failed' ? 'failed' : null;
    if (!status) return { matched: true, unchanged: true, record: this.publicRecord(record) };
    const rank = { queued: 0, validating: 1, sending: 2, accepted: 3, created: 3, delivered: 4, read: 5, uncertain: 2, failed: 2, cancelled: 6, 'dead-letter': 6 };
    if ((rank[record.status] ?? 0) > (rank[status] ?? 0) && !['uncertain','failed'].includes(record.status)) return { matched: true, unchanged: true, record: this.publicRecord(record) };
    const patch = { lastProviderStatus: raw, ackState: Number.isFinite(Number(event.ackState)) ? Number(event.ackState) : record.ackState, reconciledAt: new Date(this.now()).toISOString() };
    if (status === 'failed') patch.lastError = clean(JSON.stringify(event.statusErrors || event.errors || 'provider-reported-failure'), 360);
    if (status === 'delivered') patch.deliveredAt = new Date(this.now()).toISOString();
    if (status === 'read') patch.readAt = new Date(this.now()).toISOString();
    this.transition(sid, record.id, status, patch);
    return { matched: true, record: this.publicRecord(this.state(sid).records.get(record.id)) };
  }

  applyPendingAck(sessionId, providerMessageId) {
    const key = `${safeSessionId(sessionId)}|${providerMessageId}`;
    const event = this.pendingAcks.get(key);
    if (!event) return false;
    this.pendingAcks.delete(key);
    this.reconcileAck(sessionId, event);
    return true;
  }
  applyPendingStatus(sessionId, providerMessageId) {
    const key = `${safeSessionId(sessionId)}|${providerMessageId}`;
    const event = this.pendingStatuses.get(key);
    if (!event) return false;
    this.pendingStatuses.delete(key);
    this.reconcileProviderStatus(sessionId, event);
    return true;
  }
  prunePending() {
    const cutoff = this.now() - 10 * 60 * 1000;
    for (const map of [this.pendingAcks, this.pendingStatuses]) {
      for (const [key, row] of map) if (!row || Number(row.receivedAt || 0) < cutoff) map.delete(key);
      while (map.size > 10000) map.delete(map.keys().next().value);
    }
  }

  get(sessionId, id) { const row = this.state(sessionId).records.get(String(id || '')); return row ? this.publicRecord(row) : null; }
  list(sessionId, { status = null, limit = 100 } = {}) {
    return [...this.state(sessionId).records.values()].filter(row => !status || row.status === status)
      .sort((a,b) => String(b.createdAt).localeCompare(String(a.createdAt)))
      .slice(0, Math.max(1, Math.min(500, Number(limit) || 100))).map(row => this.publicRecord(row));
  }
  stats(sessionId) {
    const rows = [...this.state(sessionId).records.values()], counts = {};
    for (const row of rows) counts[row.status] = (counts[row.status] || 0) + 1;
    return { total: rows.length, counts, corruptLines: this.state(sessionId).corruptLines, active: rows.filter(row => ['queued','validating','sending','accepted','created','uncertain'].includes(row.status)).length };
  }
  publicRecord(row) {
    const payload = row.payload || {};
    const preview = clean(payload.text || payload.question || payload.name || payload.caption || '', 160);
    return {
      id: row.id, idempotencyKey: row.idempotencyKey, providerId: row.providerId, conversationId: row.conversationId,
      target: row.target, kind: row.kind, status: row.status, attempts: Number(row.attempts || 0),
      providerMessageId: row.providerMessageId || '', ackState: row.ackState ?? null,
      correlationId: row.correlationId, createdAt: row.createdAt, updatedAt: row.updatedAt,
      acceptedAt: row.acceptedAt || null, deliveredAt: row.deliveredAt || null, readAt: row.readAt || null,
      lastError: row.lastError || '', retryable: row.retryable === true, safeToRetry: row.safeToRetry === true,
      preview, file: payload.filePath ? { name: path.basename(payload.filePath), sizeBytes: payload.fileSize || null, sha256: payload.fileSha256 || '' } : null,
      retryOf: row.retryOf || null,
    };
  }

  cancel(sessionId, id) {
    const row = this.get(sessionId, id);
    if (!row) return { ok: false, reason: 'not-found' };
    if (!['queued','validating'].includes(row.status)) return { ok: false, reason: 'already-started-or-final', record: row };
    const updated = this.transition(sessionId, id, 'cancelled', { cancelledAt: new Date(this.now()).toISOString() });
    return { ok: true, record: updated };
  }

  async retry(sessionId, id, { acknowledgeDuplicateRisk = false, dispatchFactory } = {}) {
    const original = this.get(sessionId, id);
    if (!original) return { ok: false, reason: 'not-found' };
    if (!['failed','dead-letter','uncertain'].includes(original.status)) return { ok: false, reason: 'state-not-retryable', record: original };
    const raw = this.state(sessionId).records.get(String(id));
    const safe = ['failed','dead-letter'].includes(raw.status) && raw.sideEffectAbsent === true;
    if (!safe && acknowledgeDuplicateRisk !== true) return { ok: false, reason: 'explicit-risk-acknowledgement-required', record: original };
    if (typeof dispatchFactory !== 'function') throw new TypeError('retry requires dispatchFactory.');
    const clone = {
      ...raw, id: crypto.randomUUID(), sequence: ++this.state(sessionId).sequence,
      idempotencyKey: crypto.randomUUID(), fingerprint: crypto.randomUUID(), status: 'queued', attempts: 0,
      createdAt: new Date(this.now()).toISOString(), updatedAt: new Date(this.now()).toISOString(),
      providerMessageId: '', ackState: null, lastError: '', retryable: false, safeToRetry: false, sideEffectAbsent: false,
      retryOf: raw.id, manualRetry: true, duplicateRiskAccepted: !safe && acknowledgeDuplicateRisk === true,
    };
    this.append(sessionId, { op: 'record', record: clone });
    const state = this.state(sessionId); state.records.set(clone.id, clone); state.idempotency.set(clone.idempotencyKey, clone.id);
    const handlers = dispatchFactory(clone);
    const result = await this.enqueueRecord(safeSessionId(sessionId), clone, handlers);
    return { ok: true, result, record: this.get(sessionId, clone.id) };
  }

  compactIfNeeded(sessionId) {
    const sid = safeSessionId(sessionId), file = this.file(sid), state = this.state(sid);
    let size = 0; try { size = fs.statSync(file).size; } catch {}
    if (size < this.maxJournalBytes && state.records.size < this.maxRecords) return false;
    const rows = [...state.records.values()].sort((a,b) => Number(a.sequence)-Number(b.sequence));
    const active = rows.filter(row => !FINAL_STATUSES.has(row.status));
    const terminal = rows.filter(row => FINAL_STATUSES.has(row.status)).slice(-Math.max(100, Math.floor(this.maxRecords * 0.25)));
    const kept = [...active, ...terminal].sort((a,b) => Number(a.sequence)-Number(b.sequence));
    const temp = `${file}.compact-${process.pid}-${this.now()}`;
    const fd = fs.openSync(temp, 'w', 0o600);
    try {
      for (const record of kept) {
        const line = Buffer.from(`${JSON.stringify({ op: 'record', record })}\n`, 'utf8');
        let offset = 0;
        while (offset < line.length) { const n = fs.writeSync(fd, line, offset, line.length - offset, null); if (!n) throw new Error('Outbox compaction returned zero bytes.'); offset += n; }
      }
      fs.fsyncSync(fd);
    } finally { fs.closeSync(fd); }
    fs.renameSync(temp, file); try { fs.chmodSync(file, 0o600); } catch {}
    state.records = new Map(kept.map(row => [row.id, row]));
    state.idempotency = new Map(kept.map(row => [row.idempotencyKey, row.id]));
    return true;
  }

  async close({ timeoutMs = 15000 } = {}) {
    this.closed = true;
    const deadline = this.now() + Math.max(0, Number(timeoutMs) || 0);
    while (this.active.size && this.now() < deadline) await new Promise(resolve => setTimeout(resolve, 25));
    return { drained: this.active.size === 0, active: this.active.size, queued: [...this.sessions.values()].reduce((sum,state)=>sum+[...state.records.values()].filter(row=>row.status==='queued').length,0) };
  }
}

module.exports = { OutboundOutbox, STATUSES, ackStatus, statusFromResult, extractProviderMessageId };
