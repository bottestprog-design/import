'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const STATUSES = new Set(['received', 'queued', 'processing', 'processed', 'retry_wait', 'quarantined', 'dead_letter', 'interrupted', 'uncertain', 'replay_requested']);
const TERMINAL = new Set(['processed', 'quarantined', 'dead_letter', 'uncertain']);

function safeSessionId(value) { return String(value || 'main').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 80) || 'main'; }
function safeText(value, max = 10000) { return String(value ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').slice(0, max); }
function stableEventId(event = {}) {
  const explicit = safeText(event.eventId, 240).trim();
  if (explicit) return explicit;
  const seed = [event.provider, event.accountId, event.conversationId, event.messageId, event.rawProviderType, event.providerTimestamp, event.receivedAt].map(x => String(x ?? '')).join('|');
  return `derived:${crypto.createHash('sha256').update(seed).digest('hex')}`;
}
function normalizeEnvelope(input = {}) {
  const event = {
    eventId: stableEventId(input), provider: safeText(input.provider || 'unknown', 80),
    providerVersion: safeText(input.providerVersion || 'unknown', 80), accountId: safeText(input.accountId || 'default', 120),
    conversationId: safeText(input.conversationId, 180), messageId: safeText(input.messageId || input.providerMessageId, 240),
    providerMessageId: safeText(input.providerMessageId || input.messageId, 240) || null,
    senderId: safeText(input.senderId, 180), senderType: safeText(input.senderType || 'unknown', 40),
    fromMe: input.fromMe === true, quotedMessageId: safeText(input.quotedMessageId, 240) || null,
    kind: safeText(input.kind || 'unknown', 60), text: safeText(input.text, 10000), caption: safeText(input.caption, 2048),
    mimeType: safeText(input.mimeType, 160), sizeBytes: Number.isFinite(Number(input.sizeBytes)) && Number(input.sizeBytes) >= 0 ? Number(input.sizeBytes) : null,
    mediaAssetId: safeText(input.mediaAssetId, 240) || null, sentAt: safeText(input.sentAt, 80) || null,
    receivedAt: safeText(input.receivedAt || new Date().toISOString(), 80),
    providerTimestamp: Number.isFinite(Number(input.providerTimestamp)) && Number(input.providerTimestamp) > 0 ? Number(input.providerTimestamp) : null,
    ackState: Number.isFinite(Number(input.ackState)) ? Number(input.ackState) : null,
    rawProviderType: safeText(input.rawProviderType || input.kind || 'unknown', 80),
    correlationId: safeText(input.correlationId || input.eventId || '', 240) || null,
    eventType: safeText(input.eventType || 'message', 80),
    providerStatus: safeText(input.providerStatus || input.status || '', 40) || null,
    recipientId: safeText(input.recipientId, 120) || null,
    statusErrors: Array.isArray(input.statusErrors) ? input.statusErrors.slice(0, 4).map(item => ({ code: safeText(item?.code, 40), title: safeText(item?.title, 180) })) : [],
    eventData: input.eventData && typeof input.eventData === 'object' ? {
      emoji: safeText(input.eventData.emoji, 24), pollId: safeText(input.eventData.pollId, 240),
      voterId: safeText(input.eventData.voterId, 180), parentMessageId: safeText(input.eventData.parentMessageId, 240),
      selectedOptions: Array.isArray(input.eventData.selectedOptions) ? input.eventData.selectedOptions.slice(0, 12).map(item => ({ id: safeText(item?.id, 120), name: safeText(item?.name, 100) })) : [],
      actorId: safeText(input.eventData.actorId, 180),
    } : {},
  };
  if (!event.conversationId && event.kind !== 'system' && event.kind !== 'delivery_status') throw Object.assign(new Error('Inbound event has no conversation identifier.'), { code: 'INBOUND_EVENT_INVALID' });
  if (!event.provider || !event.eventId) throw Object.assign(new Error('Inbound event is missing provider identity.'), { code: 'INBOUND_EVENT_INVALID' });
  return event;
}

class InboundEventJournal {
  constructor({ rootDir, maxJournalBytes = 32 * 1024 * 1024, maxEvents = 50000, now = Date.now } = {}) {
    if (!rootDir) throw new TypeError('InboundEventJournal requires rootDir.');
    this.rootDir = path.resolve(rootDir);
    this.maxJournalBytes = Math.max(1024 * 1024, Number(maxJournalBytes) || 32 * 1024 * 1024);
    this.maxEvents = Math.max(1000, Number(maxEvents) || 50000);
    this.now = now;
    this.cache = new Map();
    fs.mkdirSync(this.rootDir, { recursive: true, mode: 0o700 });
    try { fs.chmodSync(this.rootDir, 0o700); } catch {}
  }
  file(sessionId) { return path.join(this.rootDir, `${safeSessionId(sessionId)}.jsonl`); }
  ensureLoaded(sessionId) {
    const sid = safeSessionId(sessionId);
    if (this.cache.has(sid)) return this.cache.get(sid);
    const file = this.file(sid), records = new Map(); let corruptLines = 0, sequence = 0;
    if (fs.existsSync(file)) {
      let source = fs.readFileSync(file, 'utf8');
      // A process may stop during the final append. Repair that tail before any
      // future append, otherwise the next valid JSON record would join the torn line.
      if (source && !source.endsWith('\n')) {
        const lastNewline = source.lastIndexOf('\n');
        const tail = source.slice(lastNewline + 1);
        let tailIsValid = false;
        try { JSON.parse(tail); tailIsValid = true; } catch {}
        if (tailIsValid) {
          const fd = fs.openSync(file, 'a');
          try { fs.writeSync(fd, Buffer.from('\n')); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
          source += '\n';
        } else {
          source = lastNewline >= 0 ? source.slice(0, lastNewline + 1) : '';
          fs.truncateSync(file, Buffer.byteLength(source, 'utf8'));
          corruptLines++;
        }
      }
      for (const line of source.split('\n')) {
        if (!line.trim()) continue;
        try {
          const row = JSON.parse(line);
          if (row?.op === 'event' && row.record?.event?.eventId) { records.set(row.record.event.eventId, row.record); sequence = Math.max(sequence, Number(row.record.sequence) || 0); }
          else if (row?.op === 'transition' && row.eventId && records.has(row.eventId)) records.set(row.eventId, { ...records.get(row.eventId), ...row.patch, status: row.status, updatedAt: row.at });
          else corruptLines++;
        } catch { corruptLines++; }
      }
    }
    const state = { records, corruptLines, sequence };
    this.cache.set(sid, state);
    return state;
  }
  appendLine(sessionId, value) {
    const file = this.file(sessionId); fs.mkdirSync(path.dirname(file), { recursive: true });
    const line = `${JSON.stringify(value)}\n`;
    const fd = fs.openSync(file, 'a', 0o600);
    try {
      const buffer = Buffer.from(line, 'utf8');
      let offset = 0;
      while (offset < buffer.length) { const written = fs.writeSync(fd, buffer, offset, buffer.length - offset, null); if (!written) throw new Error('Unable to persist inbound journal record.'); offset += written; }
      fs.fsyncSync(fd);
    } finally { fs.closeSync(fd); }
    try { fs.chmodSync(file, 0o600); } catch {}
  }
  receive(sessionId, input, meta = {}) {
    const sid = safeSessionId(sessionId), event = normalizeEnvelope(input), state = this.ensureLoaded(sid);
    const prior = state.records.get(event.eventId);
    if (prior) return { accepted: false, reason: 'duplicate', record: this.publicRecord(prior) };
    const now = new Date(this.now()).toISOString();
    const record = {
      event, sequence: ++state.sequence,
      status: meta.status && STATUSES.has(meta.status) ? meta.status : 'received',
      receivedAt: now, updatedAt: now, attempts: 0, transport: safeText(meta.transport || 'provider', 60),
      rawType: safeText(meta.rawType || event.rawProviderType, 100),
      lastError: '', nextAttemptAt: null, replayRequestedAt: null,
      replayRiskAccepted: false,
    };
    this.appendLine(sid, { op: 'event', record });
    state.records.set(event.eventId, record);
    this.maybeCompact(sid);
    return { accepted: true, reason: 'received', record: this.publicRecord(record) };
  }
  transition(sessionId, eventId, status, patch = {}) {
    const sid = safeSessionId(sessionId), id = safeText(eventId, 240);
    if (!STATUSES.has(status)) throw new TypeError(`Invalid inbound event status: ${status}`);
    const state = this.ensureLoaded(sid), prior = state.records.get(id);
    if (!prior) return null;
    const allowedPatch = {};
    for (const key of ['lastError','nextAttemptAt','replayRequestedAt','replayRiskAccepted','quarantineReason','processedAt','workerId','correlationId']) {
      if (patch[key] !== undefined) allowedPatch[key] = typeof patch[key] === 'string' ? safeText(patch[key], 500) : patch[key];
    }
    if (status === 'processing') allowedPatch.attempts = Math.min(100, Number(prior.attempts || 0) + 1);
    const at = new Date(this.now()).toISOString();
    const row = { op: 'transition', eventId: id, status, at, patch: allowedPatch };
    this.appendLine(sid, row);
    const next = { ...prior, ...allowedPatch, status, updatedAt: at };
    state.records.set(id, next);
    this.maybeCompact(sid);
    return this.publicRecord(next);
  }
  get(sessionId, eventId) { const record = this.ensureLoaded(sessionId).records.get(String(eventId || '')); return record ? this.publicRecord(record) : null; }
  list(sessionId, { status = null, limit = 100, before = null } = {}) {
    const rows = [...this.ensureLoaded(sessionId).records.values()]
      .filter(record => (!status || record.status === status) && (!before || record.receivedAt < before))
      .sort((a, b) => String(b.receivedAt).localeCompare(String(a.receivedAt)));
    return rows.slice(0, Math.max(1, Math.min(500, Number(limit) || 100))).map(record => this.publicRecord(record));
  }
  recover(sessionId) {
    const sid = safeSessionId(sessionId), state = this.ensureLoaded(sid), replayable = [], uncertain = [];
    for (const record of state.records.values()) {
      if (['received','queued','retry_wait','replay_requested'].includes(record.status)) {
        const retryAt = record.nextAttemptAt ? Date.parse(record.nextAttemptAt) : 0;
        if (!Number.isFinite(retryAt) || retryAt <= this.now()) replayable.push(this.publicRecord(record));
      }
      else if (record.status === 'processing') {
        const changed = this.transition(sid, record.event.eventId, 'uncertain', { lastError: 'worker-interrupted-during-processing; automatic replay suppressed to avoid duplicate side effects' });
        uncertain.push(changed);
      }
    }
    return { replayable, uncertain, corruptLines: state.corruptLines };
  }
  requestReplay(sessionId, eventId, { acknowledgeDuplicateRisk = false } = {}) {
    const current = this.get(sessionId, eventId);
    if (!current) return { accepted: false, reason: 'not-found' };
    if (current.status === 'processed') return { accepted: false, reason: 'already-processed' };
    if (['processing','queued','received','retry_wait','replay_requested'].includes(current.status)) return { accepted: false, reason: 'already-active' };
    if (!['dead_letter','uncertain','interrupted','quarantined'].includes(current.status)) return { accepted: false, reason: 'state-not-replayable' };
    if (!acknowledgeDuplicateRisk) return { accepted: false, reason: 'explicit-risk-acknowledgement-required' };
    const record = this.transition(sessionId, eventId, 'replay_requested', { replayRequestedAt: new Date(this.now()).toISOString(), replayRiskAccepted: true, lastError: 'manual-replay-requested; operator acknowledged possible duplicate side effects' });
    return { accepted: true, record };
  }
  stats(sessionId) {
    const state = this.ensureLoaded(sessionId), counts = {};
    for (const row of state.records.values()) counts[row.status] = (counts[row.status] || 0) + 1;
    return { total: state.records.size, counts, corruptLines: state.corruptLines };
  }
  publicRecord(record) {
    return { ...record, event: { ...record.event } };
  }
  maybeCompact(sessionId) {
    const sid = safeSessionId(sessionId), file = this.file(sid), state = this.ensureLoaded(sid);
    let size = 0; try { size = fs.statSync(file).size; } catch {}
    if (size < this.maxJournalBytes && state.records.size < this.maxEvents) return false;

    const records = [...state.records.values()].sort((a, b) => String(b.receivedAt).localeCompare(String(a.receivedAt)));
    const active = records.filter(record => !TERMINAL.has(record.status));
    const terminal = records.filter(record => TERMINAL.has(record.status));
    const kept = [];
    let used = 0;
    const budget = Math.floor(this.maxJournalBytes * 0.82);
    const maxCount = this.maxEvents;

    // Never discard a pending/processing event during compaction.
    for (const record of active) {
      const bytes = Buffer.byteLength(JSON.stringify(record)) + 24;
      kept.push(record); used += bytes;
    }

    for (const original of terminal) {
      if (kept.length >= maxCount) break;
      let record = original;
      // Processed items only need a small tombstone to reject duplicate delivery.
      // Keep the full envelope for DLQ/uncertain/quarantined items so operators can inspect them.
      if (original.status === 'processed') {
        record = {
          ...original,
          event: { ...original.event, text: '', caption: '', mimeType: '', sizeBytes: null, mediaAssetId: null, eventData: {}, statusErrors: [] },
          compacted: true,
        };
      }
      const bytes = Buffer.byteLength(JSON.stringify(record)) + 24;
      if (used + bytes > budget) continue;
      kept.push(record); used += bytes;
    }

    // Preserve original receive ordering in the compacted snapshot.
    kept.sort((a, b) => Number(a.sequence || 0) - Number(b.sequence || 0));
    const temp = `${file}.compact-${process.pid}-${this.now()}`;
    const fd = fs.openSync(temp, 'w', 0o600);
    try {
      for (const record of kept) {
        const line = Buffer.from(`${JSON.stringify({ op: 'event', record })}\n`, 'utf8');
        let offset = 0;
        while (offset < line.length) { const written = fs.writeSync(fd, line, offset, line.length - offset, null); if (!written) throw new Error('Unable to compact inbound journal.'); offset += written; }
      }
      fs.fsyncSync(fd);
    } finally { fs.closeSync(fd); }
    fs.renameSync(temp, file);
    try { fs.chmodSync(file, 0o600); } catch {}
    state.records = new Map(kept.map(record => [record.event.eventId, record]));
    state.corruptLines = 0;
    return true;
  }

}

module.exports = { InboundEventJournal, STATUSES, TERMINAL, normalizeEnvelope, stableEventId, safeSessionId };
