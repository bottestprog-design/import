'use strict';

const DEFAULT_ENDPOINT = 'http://127.0.0.1:11434';

function isLoopbackHost(hostname) {
  const host = String(hostname || '').toLowerCase().replace(/^\[|\]$/g, '');
  return host === 'localhost' || host === 'localhost.localdomain' || host === '127.0.0.1' || host === '::1' || host.startsWith('127.');
}

function normalizeEndpoint(value = process.env.OLLAMA_HOST || DEFAULT_ENDPOINT) {
  let url;
  try { url = new URL(String(value || DEFAULT_ENDPOINT)); } catch { throw new Error('عنوان Ollama غير صالح. استخدم عنوانًا محليًا مثل http://127.0.0.1:11434.'); }
  if (!['http:', 'https:'].includes(url.protocol) || !isLoopbackHost(url.hostname) || url.username || url.password) {
    throw new Error('لحماية خصوصية المحادثات، يسمح المساعد الذكي بالاتصال بخدمة Ollama على الجهاز المحلي فقط (localhost أو 127.0.0.1 أو ::1).');
  }
  url.pathname = url.pathname.replace(/\/$/, '');
  url.search = '';
  url.hash = '';
  return url.toString().replace(/\/$/, '');
}

class LocalLLM {
  constructor({ endpoint = process.env.OLLAMA_HOST || DEFAULT_ENDPOINT, fetchImpl = global.fetch } = {}) {
    this.endpoint = normalizeEndpoint(endpoint);
    this.fetch = fetchImpl;
  }
  async status() {
    if (typeof this.fetch !== 'function') return { available: false, endpoint: this.endpoint, models: [], message: 'إصدار Node الحالي لا يوفر fetch؛ استخدم Node 22 أو أحدث.' };
    try {
      const response = await this.fetch(`${this.endpoint}/api/tags`, { signal: AbortSignal.timeout(1800) });
      if (!response.ok) return { available: false, endpoint: this.endpoint, models: [], message: `Ollama المحلي رد بالحالة ${response.status}.` };
      const data = await response.json();
      return { available: true, endpoint: this.endpoint, models: (Array.isArray(data.models) ? data.models : []).map(x => String(x.name || '')).filter(Boolean).slice(0, 100), message: 'خدمة الذكاء المحلي متاحة على هذا الجهاز.' };
    } catch {
      return { available: false, endpoint: this.endpoint, models: [], message: 'Ollama غير متصل. شغّله محليًا وثبّت نموذجًا قبل تفعيل الرد الذكي.' };
    }
  }
  async generate({ model = 'qwen3.5:4b', system = '', messages = [], timeoutMs = 18000, maxTokens = 320, temperature = 0.68 } = {}) {
    if (!/^[\w.:-]{1,100}$/.test(String(model || ''))) throw new Error('اسم نموذج Ollama غير صالح.');
    if (typeof this.fetch !== 'function') throw new Error('استخدم Node 22 أو أحدث لتفعيل Ollama المحلي.');
    const conversation = (Array.isArray(messages) ? messages : []).slice(-10).map(item => ({
      role: item?.role === 'assistant' ? 'assistant' : 'user',
      content: String(item?.content || '').slice(0, 1200),
    })).filter(item => item.content);
    if (!conversation.length) throw new Error('لا توجد رسالة لإرسالها إلى النموذج المحلي.');
    const response = await this.fetch(`${this.endpoint}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: AbortSignal.timeout(Math.max(1500, Math.min(60000, Number(timeoutMs) || 12000))),
      body: JSON.stringify({
        model: String(model), stream: false,
        messages: [{ role: 'system', content: String(system || '').slice(0, 4000) }, ...conversation],
        options: { temperature: Math.max(0.1, Math.min(1.1, Number(temperature) || 0.68)), top_p: 0.9, repeat_penalty: 1.12, num_predict: Math.max(80, Math.min(900, Number(maxTokens) || 320)) },
      }),
    });
    if (!response.ok) throw new Error(response.status === 404 ? 'نموذج Ollama غير موجود؛ ثبّت النموذج المحدد محليًا ثم أعد المحاولة.' : `تعذر على Ollama المحلي إنشاء رد (الحالة ${response.status}).`);
    const data = await response.json();
    const answer = String(data?.message?.content || '').trim().slice(0, 4000);
    if (!answer) throw new Error('أعاد النموذج المحلي ردًا فارغًا.');
    return answer;
  }
}

module.exports = { LocalLLM, DEFAULT_ENDPOINT, isLoopbackHost, normalizeEndpoint };
