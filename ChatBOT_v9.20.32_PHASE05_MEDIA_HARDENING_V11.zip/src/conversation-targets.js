'use strict';

function digits(value) { return String(value || '').replace(/\D/g, ''); }
function chatIdOf(value) {
  if (!value) return '';
  if (typeof value === 'string') return value.trim().toLowerCase();
  return String(value._serialized || value.$1 || value.serialized || value.id?._serialized || value.id?.$1 || value.id || '').trim().toLowerCase();
}
function targetIsEnabled(item) {
  return Boolean(item && item.enabled !== false && item.paused !== true && item.stopped !== true);
}
function explicitIds(item, fields) {
  return [...new Set(fields.map(field => chatIdOf(item?.[field])).filter(Boolean))];
}
function recipientIds(item) {
  return explicitIds(item, ['chatId', 'waChatId', 'whatsappJid', 'jid', 'lid', 'lidJid', 'whatsappLid', 'whatsappId']);
}
function groupIds(item) {
  return explicitIds(item, ['gid', 'chatId', 'waChatId', 'whatsappJid', 'jid', 'whatsappId']);
}
function recipientMatches(item, chatId) {
  if (recipientIds(item).includes(chatId)) return true;
  // LIDs are opaque identifiers: never attempt to convert them to phone numbers.
  if (!chatId.endsWith('@c.us')) return false;
  const number = digits(chatId.slice(0, -5));
  if (number.length < 5) return false;
  return [item.e164, item.phone, item.digits, item.number, item.international].some(value => digits(value) === number);
}
function targetKeyForChat(session, rawChatId, selfChatId = '') {
  const chatId = chatIdOf(rawChatId), self = chatIdOf(selfChatId);
  if (!chatId) return '';
  if (self && (chatId === self || (chatId.endsWith('@c.us') && self.endsWith('@c.us') && digits(chatId) === digits(self)))) return 'self';
  const groups = Array.isArray(session?.groups) ? session.groups : [];
  const group = groups.find(item => groupIds(item).includes(chatId));
  if (group) return `g:${String(group.id)}`;
  const recipients = Array.isArray(session?.recipients) ? session.recipients : [];
  const recipient = recipients.find(item => recipientMatches(item, chatId));
  return recipient ? `r:${String(recipient.id)}` : '';
}
function allowedTarget(session, key, selfChatId = '') {
  const wanted = String(key || '').trim();
  if (wanted === 'self') return { key: 'self', label: 'محادثة البوت معك', type: 'self', id: '', chatId: chatIdOf(selfChatId), enabled: true, interactionEnabled: true, registered: true };
  if (wanted.startsWith('r:')) {
    const id = wanted.slice(2), recipients = Array.isArray(session?.recipients) ? session.recipients : [];
    const person = recipients.find(item => String(item.id) === id);
    if (!person) return null;
    const ids = recipientIds(person);
    const jid = ids.find(value => /^(?:\d{5,25}@c\.us|\d{5,25}@lid)$/i.test(value)) || '';
    const number = digits(person.e164 || person.phone || person.digits || person.number || person.international);
    const chatId = jid || (number.length >= 5 ? `${number}@c.us` : '');
    return { key: wanted, id, label: String(person.name || person.international || person.phone || 'شخص بدون اسم').slice(0, 160), type: 'recipient', chatId, enabled: targetIsEnabled(person), interactionEnabled: person.interactionEnabled === true, registered: true, person };
  }
  if (wanted.startsWith('g:')) {
    const id = wanted.slice(2), groups = Array.isArray(session?.groups) ? session.groups : [];
    const group = groups.find(item => String(item.id) === id);
    if (!group) return null;
    const chatId = groupIds(group).find(value => /^\d+(?:-\d+)*@g\.us$/i.test(value)) || '';
    return { key: wanted, id, label: String(group.name || group.gid || 'مجموعة').slice(0, 160), type: 'group', chatId, enabled: targetIsEnabled(group), interactionEnabled: group.interactionEnabled === true, registered: true, group };
  }
  return null;
}
function resolveChatAccess(session, rawChatId, selfChatId = '') {
  const chatId = chatIdOf(rawChatId);
  if (!chatId) return { allowed: false, reason: 'invalid-chat', key: '', chatId: '' };
  const key = targetKeyForChat(session, chatId, selfChatId);
  if (!key) return { allowed: false, reason: 'unregistered', key: '', chatId };
  const target = allowedTarget(session, key, selfChatId);
  if (!target) return { allowed: false, reason: 'unregistered', key: '', chatId };
  if (!target.enabled) return { allowed: false, reason: 'disabled', key, chatId, target, type: target.type };
  return { allowed: true, reason: 'allowed', key, chatId, target, type: target.type };
}
function resolveInteractionAccess(session, rawChatId, selfChatId = '') {
  const access = resolveChatAccess(session, rawChatId, selfChatId);
  if (!access.allowed) return { ...access, interactionAllowed: false };
  // The verified self-chat is the only implicit command/rule scope.
  if (access.key === 'self' && access.type === 'self') return { ...access, interactionAllowed: true, reason: 'owner-self-chat' };
  if (access.target?.interactionEnabled !== true) {
    return { ...access, allowed: false, interactionAllowed: false, reason: 'interaction-not-enabled' };
  }
  return { ...access, interactionAllowed: true, reason: 'explicit-interaction-grant' };
}

function listRegisteredTargets(session, selfChatId = '') {
  const rows = [{ key: 'self', id: '', label: 'محادثة البوت معك', type: 'self', chatId: chatIdOf(selfChatId), enabled: true, registered: true }];
  for (const person of session?.recipients || []) rows.push(allowedTarget(session, `r:${person.id}`, selfChatId));
  for (const group of session?.groups || []) rows.push(allowedTarget(session, `g:${group.id}`, selfChatId));
  return rows.filter(Boolean);
}
function registeredChatFromList(session, chat, selfChatId = '') {
  const chatId = chatIdOf(chat?.id || chat?.chatId);
  const key = targetKeyForChat(session, chatId, selfChatId);
  if (!key) return null;
  const target = allowedTarget(session, key, selfChatId);
  if (!target) return null;
  return { ...target, chatId, name: String(chat?.name || chat?.formattedTitle || target.label).slice(0, 160), isGroup: Boolean(chat?.isGroup || target.type === 'group') };
}
module.exports = { digits, chatIdOf, targetIsEnabled, targetKeyForChat, allowedTarget, resolveChatAccess, resolveInteractionAccess, listRegisteredTargets, registeredChatFromList };
