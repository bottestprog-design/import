'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const media = require('./media');

const INDEX_NAME = '.asset-index.json';
const MAX_INDEX_BYTES = 8 * 1024 * 1024;
const MAX_PROBE_OUTPUT = 256 * 1024;
const hashIndexes = new Map();
const directoryQueues = new Map();

function withDirectoryLock(directory, operation) {
  const key = path.resolve(directory), previous = directoryQueues.get(key) || Promise.resolve();
  let release;
  const gate = new Promise(resolve => { release = resolve; });
  const tail = previous.catch(() => {}).then(() => gate);
  directoryQueues.set(key, tail);
  return previous.catch(() => {}).then(operation).finally(() => {
    release();
    if (directoryQueues.get(key) === tail) directoryQueues.delete(key);
  });
}

function ensureDirectory(directory) {
  fs.mkdirSync(directory, { recursive: true });
  const stat = fs.lstatSync(directory);
  if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error('مجلد الوسائط غير آمن.');
  return path.resolve(directory);
}

function atomicWriteJson(file, value) {
  const directory = path.dirname(file);
  const temp = path.join(directory, `.asset-index-${process.pid}-${crypto.randomBytes(8).toString('hex')}.tmp`);
  const bytes = Buffer.from(`${JSON.stringify(value, null, 2)}\n`, 'utf8');
  if (bytes.length > MAX_INDEX_BYTES) throw new Error('فهرس الوسائط تجاوز الحد الآمن.');
  let fd;
  try {
    fd = fs.openSync(temp, 'wx', 0o600);
    fs.writeFileSync(fd, bytes);
    fs.fsyncSync(fd);
    fs.closeSync(fd); fd = null;
    fs.renameSync(temp, file);
    try { fs.chmodSync(file, 0o600); } catch {}
    try {
      const dirFd = fs.openSync(directory, 'r');
      try { fs.fsyncSync(dirFd); } finally { fs.closeSync(dirFd); }
    } catch {}
  } catch (error) {
    if (fd !== null && fd !== undefined) try { fs.closeSync(fd); } catch {}
    try { fs.rmSync(temp, { force: true }); } catch {}
    throw error;
  }
}

function readIndex(directory) {
  const file = path.join(directory, INDEX_NAME);
  if (!fs.existsSync(file)) return { version: 1, updatedAt: new Date().toISOString(), assets: {} };
  const stat = fs.lstatSync(file);
  if (!stat.isFile() || stat.isSymbolicLink() || stat.size > MAX_INDEX_BYTES) throw new Error('فهرس الوسائط غير آمن أو أكبر من الحد المسموح.');
  let parsed;
  try { parsed = JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { throw new Error('فهرس الوسائط تالف؛ لم يتم تعديل الملفات لتجنب فقد بياناتها.'); }
  if (!parsed || parsed.version !== 1 || !parsed.assets || typeof parsed.assets !== 'object' || Array.isArray(parsed.assets)) throw new Error('بنية فهرس الوسائط غير معروفة.');
  return parsed;
}

function updateIndex(directory, filename, metadata) {
  const root = ensureDirectory(directory), index = readIndex(root);
  index.assets[filename] = {
    id: metadata.id || crypto.randomUUID(),
    sha256: metadata.sha256,
    sizeBytes: metadata.sizeBytes,
    mimeType: metadata.mimeType,
    format: metadata.format,
    mediaKind: metadata.mediaKind,
    originalName: String(metadata.originalName || filename).slice(0, 240),
    createdAt: metadata.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    probe: metadata.probe || null,
    malwareScan: metadata.malwareScan || { status: 'not-configured' },
  };
  index.updatedAt = new Date().toISOString();
  atomicWriteJson(path.join(root, INDEX_NAME), index);
  return index.assets[filename];
}

function removeIndexEntry(directory, filename) {
  const root = ensureDirectory(directory), index = readIndex(root);
  const prior = index.assets[filename];
  const hasEntry = Object.prototype.hasOwnProperty.call(index.assets, filename);
  if (hasEntry) {
    delete index.assets[filename];
    index.updatedAt = new Date().toISOString();
    atomicWriteJson(path.join(root, INDEX_NAME), index);
  }
  if (hashIndexes.has(root)) {
    const cached = hashIndexes.get(root);
    if (prior) cached.delete(hashKey(prior.sizeBytes, prior.sha256));
    for (const [key, value] of cached) if (value === filename) cached.delete(key);
  }
  return hasEntry;
}

function runProcess(binary, args, { timeoutMs = 8000, maxBytes = MAX_PROBE_OUTPUT } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(binary, args, { shell: false, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    const stdout = [], stderr = [];
    let outSize = 0, errSize = 0, settled = false;
    const finish = (error, result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (error) reject(error); else resolve(result);
    };
    const timer = setTimeout(() => {
      try { child.kill('SIGKILL'); } catch {}
      finish(Object.assign(new Error(`${path.basename(binary)} timeout`), { code: 'ETIMEDOUT' }));
    }, timeoutMs);
    child.stdout.on('data', chunk => {
      outSize += chunk.length;
      if (outSize > maxBytes) { try { child.kill('SIGKILL'); } catch {}; finish(new Error('Tool output exceeded the safe limit.')); return; }
      stdout.push(chunk);
    });
    child.stderr.on('data', chunk => {
      errSize += chunk.length;
      if (errSize <= 8192) stderr.push(chunk);
    });
    child.once('error', error => finish(error));
    child.once('close', (code, signal) => finish(null, {
      code, signal, stdout: Buffer.concat(stdout).toString('utf8'), stderr: Buffer.concat(stderr).toString('utf8'),
    }));
  });
}

async function probeMedia(filePath, detected, { enabled = process.env.MEDIA_FFPROBE_ENABLED !== 'false', binary = process.env.FFPROBE_PATH || 'ffprobe' } = {}) {
  if (!enabled || !(String(detected.mimeType || '').startsWith('video/') || String(detected.mimeType || '').startsWith('audio/'))) return { status: 'not-requested' };
  try {
    const result = await runProcess(binary, [
      '-v', 'error', '-show_entries', 'format=format_name,duration,size:stream=codec_type,codec_name,width,height,sample_rate,channels',
      '-of', 'json', filePath,
    ], { timeoutMs: 10000, maxBytes: MAX_PROBE_OUTPUT });
    if (result.code !== 0) return { status: 'invalid', error: result.stderr.slice(0, 600) || `ffprobe exited ${result.code}` };
    let payload;
    try { payload = JSON.parse(result.stdout); } catch { return { status: 'invalid', error: 'ffprobe returned malformed metadata.' }; }
    const streams = Array.isArray(payload.streams) ? payload.streams.slice(0, 16) : [];
    const expectedStream = String(detected.mimeType || '').startsWith('audio/') ? 'audio' : 'video';
    const hasExpectedStream = streams.some(stream => String(stream.codec_type || '').toLowerCase() === expectedStream);
    const duration = Number(payload.format?.duration);
    return {
      status: hasExpectedStream ? 'verified' : 'invalid',
      formatName: String(payload.format?.format_name || '').slice(0, 120),
      durationSeconds: Number.isFinite(duration) && duration >= 0 ? Math.min(duration, 7 * 24 * 3600) : null,
      expectedStream,
      streams: streams.map(stream => ({
        type: String(stream.codec_type || '').slice(0, 20), codec: String(stream.codec_name || '').slice(0, 40),
        width: Number.isFinite(Number(stream.width)) ? Math.max(0, Math.min(100000, Number(stream.width))) : null,
        height: Number.isFinite(Number(stream.height)) ? Math.max(0, Math.min(100000, Number(stream.height))) : null,
        sampleRate: Number.isFinite(Number(stream.sample_rate)) ? Math.max(0, Math.min(768000, Number(stream.sample_rate))) : null,
        channels: Number.isFinite(Number(stream.channels)) ? Math.max(0, Math.min(64, Number(stream.channels))) : null,
      })),
    };
  } catch (error) {
    if (error?.code === 'ENOENT') return { status: 'unavailable', reason: 'ffprobe-not-installed' };
    if (error?.code === 'ETIMEDOUT') return { status: 'timeout' };
    return { status: 'unavailable', reason: String(error?.message || error).slice(0, 300) };
  }
}

async function scanForMalware(filePath, { enabled = process.env.MEDIA_CLAMSCAN_ENABLED === 'true', binary = process.env.MEDIA_CLAMSCAN_PATH || 'clamscan' } = {}) {
  if (!enabled) return { status: 'not-configured' };
  let result;
  try {
    result = await runProcess(binary, ['--no-summary', '--', filePath], { timeoutMs: 30000, maxBytes: 8192 });
  } catch (error) {
    // A configured scanner is a policy requirement: absence, crash or timeout blocks ingestion.
    throw new Error(`فشل فحص الملف الأمني الإلزامي: ${String(error?.message || error).slice(0, 250)}`);
  }
  if (result.code === 0) return { status: 'clean', engine: 'ClamAV' };
  if (result.code === 1) throw new Error('تم رفض الملف لأن ClamAV اكتشف محتوى ضارًا.');
  throw new Error(`لم يكتمل فحص ClamAV (exit ${result.code}). تم رفض الملف حفاظًا على الأمان.`);
}

async function inspectFile(filePath, { originalName = path.basename(filePath), maxBytes = 100 * 1024 * 1024, runProbe = true, scannerOptions } = {}) {
  const stat = fs.lstatSync(filePath);
  if (!stat.isFile() || stat.isSymbolicLink()) throw new Error('يجب أن يكون المصدر ملفًا عاديًا وليس رابطًا رمزيًا.');
  if (stat.size <= 0) throw new Error('الملف فارغ.');
  if (!Number.isSafeInteger(maxBytes) || maxBytes < 1 || stat.size > maxBytes) throw new Error(`حجم الملف يتجاوز الحد المسموح (${Math.round(maxBytes / 1024 / 1024)} MB).`);
  const safeOriginalName = media.safeName(originalName);
  const extension = path.extname(safeOriginalName).toLowerCase();
  if (!media.MEDIA_EXT.has(extension)) throw new Error('امتداد الملف غير مدعوم.');
  const detected = media.detectContent(filePath, extension);
  if (!detected.valid) throw new Error(detected.reason || 'تعذر التحقق من بنية الملف.');
  const sha256 = media.hashFile(filePath);
  const malwareScan = await scanForMalware(filePath, scannerOptions);
  const probe = runProbe ? await probeMedia(filePath, detected) : { status: 'not-requested' };
  if (probe.status === 'invalid' || probe.status === 'no-streams') throw new Error('نوع تدفق الملف لا يطابق تصنيفه الصوتي/المرئي أو لا يحتوي تدفقًا صالحًا.');
  return {
    id: crypto.randomUUID(), originalName: safeOriginalName, sha256, sizeBytes: stat.size,
    mimeType: detected.mimeType, format: detected.format, mediaKind: detected.mediaKind,
    detected, probe, malwareScan,
  };
}

function hashKey(sizeBytes, sha256) { return `${Number(sizeBytes)}:${String(sha256)}`; }
function buildHashIndex(directory, { refresh = false } = {}) {
  const root = ensureDirectory(directory);
  if (!refresh && hashIndexes.has(root)) return hashIndexes.get(root);
  const index = new Map();
  for (const item of media.scan(root, 250).files) {
    try { index.set(hashKey(item.size, media.hashFile(media.safePath(root, item.filename))), item.filename); } catch {}
  }
  hashIndexes.set(root, index);
  return index;
}
function findDuplicate(directory, sizeBytes, sha256, existingByHash) {
  const index = existingByHash instanceof Map ? existingByHash : buildHashIndex(directory);
  return index.get(hashKey(sizeBytes, sha256)) || '';
}

function commitStagedFile(stagedFile, directory, filename) {
  const root = ensureDirectory(directory), target = media.safePath(root, filename);
  if (fs.existsSync(target)) throw new Error('اسم الملف موجود بالفعل؛ لم يتم استبدال أي ملف دون قصد.');
  try { fs.renameSync(stagedFile, target); }
  catch (error) {
    if (error.code !== 'EXDEV') throw error;
    const tempTarget = path.join(root, `.asset-commit-${crypto.randomBytes(10).toString('hex')}.tmp`);
    try {
      fs.copyFileSync(stagedFile, tempTarget, fs.constants.COPYFILE_EXCL);
      const sourceStat = fs.statSync(stagedFile), targetStat = fs.statSync(tempTarget);
      if (sourceStat.size !== targetStat.size) throw new Error('لم يكتمل نسخ الملف إلى مكتبة الوسائط.');
      fs.renameSync(tempTarget, target);
      fs.rmSync(stagedFile, { force: true });
    } catch (copyError) {
      try { fs.rmSync(tempTarget, { force: true }); } catch {}
      throw copyError;
    }
  }
  try { fs.chmodSync(target, 0o600); } catch {}
  return target;
}

async function ingestStagedFile(stagedFile, {
  directory, originalName, filename, maxBytes = 100 * 1024 * 1024, replaceDuplicates = false,
  runProbe = true, scannerOptions, onBeforeCommit, existingByHash,
} = {}) {
  if (!directory) throw new Error('مجلد حفظ الوسائط غير محدد.');
  const root = ensureDirectory(directory);
  let committedPath = '';
  try {
    const metadata = await inspectFile(stagedFile, { originalName, maxBytes, runProbe, scannerOptions });
    const result = await withDirectoryLock(root, async () => {
      if (typeof onBeforeCommit === 'function') await onBeforeCommit();
      const hashIndex = buildHashIndex(root);
      const duplicateName = findDuplicate(root, metadata.sizeBytes, metadata.sha256, hashIndex);
      if (duplicateName) {
        fs.rmSync(stagedFile, { force: true });
        const index = readIndex(root);
        if (!index.assets[duplicateName]) updateIndex(root, duplicateName, { ...metadata, originalName: duplicateName });
        return { duplicate: true, replaced: replaceDuplicates, filename: duplicateName, metadata };
      }
      let finalName = filename ? media.safeName(filename) : '';
      if (!finalName) {
        const ext = path.extname(metadata.originalName).toLowerCase();
        finalName = media.IMAGE_EXT.has(ext)
          ? media.nextImageName(root, ext)
          : media.uniqueFileName(root, path.basename(metadata.originalName, ext), ext);
      }
      if (path.extname(finalName).toLowerCase() !== path.extname(metadata.originalName).toLowerCase()) throw new Error('اسم الملف النهائي لا يطابق امتداد الملف الذي تم التحقق منه.');
      committedPath = commitStagedFile(stagedFile, root, finalName);
      if (typeof onBeforeCommit === 'function') await onBeforeCommit();
      const recorded = updateIndex(root, finalName, metadata);
      hashIndex.set(hashKey(metadata.sizeBytes, metadata.sha256), finalName);
      if (existingByHash instanceof Map && existingByHash !== hashIndex) existingByHash.set(hashKey(metadata.sizeBytes, metadata.sha256), finalName);
      committedPath = '';
      return { duplicate: false, filename: finalName, path: media.safePath(root, finalName), metadata: recorded };
    });
    return result;
  } catch (error) {
    if (committedPath) {
      try { fs.rmSync(committedPath, { force: true }); } catch {}
      try { removeIndexEntry(root, path.basename(committedPath)); } catch {}
    }
    try { fs.rmSync(stagedFile, { force: true }); } catch {}
    throw error;
  }
}

async function removeAssetFile(directory, filename) {
  const root = ensureDirectory(directory), full = media.safePath(root, filename);
  return withDirectoryLock(root, async () => {
    const priorMetadata = readIndex(root).assets[filename] || null;
    const tombstone = path.join(root, `.asset-delete-${crypto.randomBytes(12).toString('hex')}.tmp`);
    let moved = false;
    try {
      let stat = null;
      try { stat = fs.lstatSync(full); } catch (error) { if (error.code !== 'ENOENT') throw error; }
      if (stat) {
        if (!stat.isFile() || stat.isSymbolicLink()) throw new Error('لا يمكن حذف عنصر ليس ملفًا عاديًا من مكتبة الوسائط.');
        fs.renameSync(full, tombstone);
        moved = true;
      }
      try { removeIndexEntry(root, filename); }
      catch (error) {
        if (moved) { try { fs.renameSync(tombstone, full); moved = false; } catch {} }
        throw error;
      }
      try { if (moved) fs.rmSync(tombstone, { force: true }); }
      catch (error) {
        if (moved) {
          try { fs.renameSync(tombstone, full); moved = false; if (priorMetadata) updateIndex(root, filename, priorMetadata); } catch {}
        }
        throw error;
      }
      return { removed: true, filename };
    } finally {
      if (moved) { try { fs.rmSync(tombstone, { force: true }); } catch {} }
    }
  });
}

async function ingestBuffer(buffer, options = {}) {
  if (!Buffer.isBuffer(buffer) || !buffer.length) throw new Error('محتوى الملف الصوتي/المرئي فارغ أو غير صالح.');
  const tempDir = ensureDirectory(options.tempDirectory || path.join(options.directory || process.cwd(), '.staging'));
  const stagePath = path.join(tempDir, `.incoming-${process.pid}-${crypto.randomBytes(12).toString('hex')}.tmp`);
  const maxBytes = Number.isSafeInteger(options.maxBytes) ? options.maxBytes : 100 * 1024 * 1024;
  if (buffer.length > maxBytes) throw new Error('الملف يتجاوز حد الحجم المسموح.');
  try {
    const fd = fs.openSync(stagePath, 'wx', 0o600);
    try { fs.writeFileSync(fd, buffer); fs.fsyncSync(fd); }
    finally { fs.closeSync(fd); }
    return await ingestStagedFile(stagePath, { ...options, filename: undefined, replaceDuplicates: false });
  } catch (error) {
    try { fs.rmSync(stagePath, { force: true }); } catch {}
    throw error;
  }
}

module.exports = {
  INDEX_NAME, ensureDirectory, readIndex, updateIndex, removeIndexEntry, removeAssetFile, withDirectoryLock,
  runProcess, probeMedia, scanForMalware, inspectFile, hashKey, buildHashIndex, findDuplicate,
  ingestStagedFile, ingestBuffer,
};
