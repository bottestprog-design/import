"use strict";
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const IMAGE_EXT = new Set(['.jpg', '.jpeg', '.png', '.webp', '.gif', '.avif', '.heic', '.heif']);
const VIDEO_EXT = new Set(['.mp4', '.webm', '.mov', '.mkv', '.avi', '.3gp', '.m4v', '.mpeg', '.mpg']);
const VIDEO_PREVIEW_EXT = new Set(['.mp4', '.webm']);
const AUDIO_EXT = new Set(['.mp3', '.m4a', '.ogg', '.opus', '.wav', '.aac', '.flac']);
const MEDIA_EXT = new Set([
  ...IMAGE_EXT, ...VIDEO_EXT, ...AUDIO_EXT,
  '.pdf', '.txt', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.zip', '.csv', '.json', '.xml', '.html', '.htm', '.md', '.rtf',
  '.odt', '.ods', '.odp', '.7z', '.rar', '.tar', '.gz', '.log', '.yaml', '.yml', '.js', '.ts', '.py', '.java', '.c', '.cpp', '.sql',
  '.epub', '.apk', '.bin', '.heic', '.heif'
]);
const MIME = {
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp', '.gif': 'image/gif', '.avif': 'image/avif', '.heic': 'image/heic', '.heif': 'image/heif',
  '.pdf': 'application/pdf', '.txt': 'text/plain', '.doc': 'application/msword', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.xls': 'application/vnd.ms-excel', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', '.ppt': 'application/vnd.ms-powerpoint',
  '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation', '.zip': 'application/zip', '.csv': 'text/csv', '.json': 'application/json',
  '.xml': 'application/xml', '.html': 'text/html', '.htm': 'text/html', '.md': 'text/markdown', '.rtf': 'application/rtf',
  '.odt': 'application/vnd.oasis.opendocument.text', '.ods': 'application/vnd.oasis.opendocument.spreadsheet', '.odp': 'application/vnd.oasis.opendocument.presentation',
  '.7z': 'application/x-7z-compressed', '.rar': 'application/vnd.rar', '.tar': 'application/x-tar', '.gz': 'application/gzip', '.log': 'text/plain',
  '.yaml': 'application/yaml', '.yml': 'application/yaml', '.js': 'text/javascript', '.ts': 'text/plain', '.py': 'text/x-python', '.java': 'text/plain',
  '.c': 'text/plain', '.cpp': 'text/plain', '.sql': 'application/sql', '.epub': 'application/epub+zip', '.apk': 'application/vnd.android.package-archive',
  '.bin': 'application/octet-stream', '.mp4': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.mkv': 'video/x-matroska',
  '.avi': 'video/x-msvideo', '.3gp': 'video/3gpp', '.m4v': 'video/x-m4v', '.mpeg': 'video/mpeg', '.mpg': 'video/mpeg',
  '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.ogg': 'audio/ogg', '.opus': 'audio/opus', '.wav': 'audio/wav', '.aac': 'audio/aac', '.flac': 'audio/flac'
};
const TEXT_EXT = new Set(['.txt', '.csv', '.json', '.xml', '.html', '.htm', '.md', '.rtf', '.log', '.yaml', '.yml', '.js', '.ts', '.py', '.java', '.c', '.cpp', '.sql']);
const ZIP_EXT = new Set(['.zip', '.docx', '.xlsx', '.pptx', '.odt', '.ods', '.odp', '.epub', '.apk']);
const RESERVED_NAMES = new Set(['.asset-index.json']);

function safeName(value) {
  const base = path.basename(String(value || '').replace(/\\/g, '/'));
  if (!base || base === '.' || base === '..' || base.startsWith('.') || RESERVED_NAMES.has(base.toLowerCase())) throw new Error('اسم ملف غير صالح.');
  if (/[\u0000-\u001f\u007f]/u.test(base)) throw new Error('اسم ملف غير صالح.');
  return base;
}
function safePath(dir, name) {
  const n = safeName(name), root = path.resolve(dir), p = path.resolve(root, n);
  if (p === root || !p.startsWith(root + path.sep)) throw new Error('مسار ملف غير آمن.');
  return p;
}
function imageNumber(name) { const match = String(name).match(/^img\.(\d+)(\.[A-Za-z0-9]+)$/i); return match ? Number(match[1]) : 0; }
function nextImageName(dir, ext) {
  fs.mkdirSync(dir, { recursive: true });
  const used = new Set(fs.readdirSync(dir).map(imageNumber).filter(Boolean));
  let number = 1; while (used.has(number)) number++;
  return `img.${number}${String(ext || '.png').toLowerCase()}`;
}
function uniqueFileName(dir, base, ext) {
  fs.mkdirSync(dir, { recursive: true });
  const clean = String(base || 'file').replace(/[^\w\-.\u0600-\u06ff ]/g, '_').trim().slice(0, 70) || 'file';
  const stamp = `${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
  let name = `${clean}_${stamp}${ext}`, index = 2;
  while (fs.existsSync(safePath(dir, name))) name = `${clean}_${stamp}_${index++}${ext}`;
  return name;
}
function hashFile(file) {
  const hash = crypto.createHash('sha256'), fd = fs.openSync(file, 'r'), chunk = Buffer.allocUnsafe(1024 * 1024);
  try { let bytes; while ((bytes = fs.readSync(fd, chunk, 0, chunk.length, null)) > 0) hash.update(chunk.subarray(0, bytes)); return hash.digest('hex'); }
  finally { fs.closeSync(fd); }
}
function isInlineBrowserMedia(name) { const ext = path.extname(String(name || '')).toLowerCase(); return IMAGE_EXT.has(ext) || VIDEO_EXT.has(ext) || AUDIO_EXT.has(ext); }
function contentDisposition(name) {
  const base = path.basename(String(name || 'download')).replace(/[\u0000-\u001f\u007f"\\]/g, '_').slice(0, 180) || 'download';
  const ascii = base.replace(/[^\x20-\x7e]/g, '_').replace(/["\\]/g, '_') || 'download';
  const encoded = encodeURIComponent(base).replace(/['()*]/g, ch => `%${ch.charCodeAt(0).toString(16).toUpperCase()}`);
  return `attachment; filename="${ascii}"; filename*=UTF-8''${encoded}`;
}
function readAt(fd, position, length) {
  const buffer = Buffer.alloc(Math.max(0, length));
  const count = fs.readSync(fd, buffer, 0, buffer.length, position);
  return buffer.subarray(0, count);
}
function zipDirectory(file, stat) {
  const fd = fs.openSync(file, 'r');
  try {
    const tailLength = Math.min(stat.size, 65557), tail = readAt(fd, stat.size - tailLength, tailLength);
    let eocd = -1;
    for (let i = tail.length - 22; i >= Math.max(0, tail.length - 65557); i--) {
      if (i + 22 > tail.length || tail.readUInt32LE(i) !== 0x06054b50) continue;
      const commentLength = tail.readUInt16LE(i + 20);
      if (i + 22 + commentLength === tail.length) { eocd = i; break; }
    }
    if (eocd < 0 || eocd + 22 > tail.length) return { valid: false, entries: [], reason: 'ZIP directory is missing or has a malformed comment.' };
    const diskNumber = tail.readUInt16LE(eocd + 4), directoryDisk = tail.readUInt16LE(eocd + 6);
    const entriesOnDisk = tail.readUInt16LE(eocd + 8), count = tail.readUInt16LE(eocd + 10);
    const directoryBytes = tail.readUInt32LE(eocd + 12), directoryOffset = tail.readUInt32LE(eocd + 16);
    const eocdAbsolute = stat.size - tailLength + eocd;
    if (diskNumber !== 0 || directoryDisk !== 0 || entriesOnDisk !== count) return { valid: false, entries: [], reason: 'Multi-disk ZIP archives are not supported.' };
    if (count === 0xffff || directoryBytes === 0xffffffff || directoryOffset === 0xffffffff
        || count > 10000 || directoryBytes > 8 * 1024 * 1024
        || directoryOffset + directoryBytes > eocdAbsolute) return { valid: false, entries: [], reason: 'ZIP directory exceeds safe inspection limits or uses unsupported ZIP64 offsets.' };
    const directory = readAt(fd, directoryOffset, directoryBytes), entries = [];
    let offset = 0, totalUncompressed = 0, totalCompressed = 0;
    while (offset + 46 <= directory.length && entries.length < count) {
      if (directory.readUInt32LE(offset) !== 0x02014b50) return { valid: false, entries: [], reason: 'ZIP directory is malformed.' };
      const flags = directory.readUInt16LE(offset + 8);
      const compressed = directory.readUInt32LE(offset + 20), uncompressed = directory.readUInt32LE(offset + 24);
      const nameLength = directory.readUInt16LE(offset + 28), extraLength = directory.readUInt16LE(offset + 30), commentLength = directory.readUInt16LE(offset + 32);
      const madeBy = directory.readUInt16LE(offset + 4) >>> 8;
      const externalAttributes = directory.readUInt32LE(offset + 38);
      const end = offset + 46 + nameLength + extraLength + commentLength;
      if (!nameLength || end > directory.length || (flags & 0x0001)) return { valid: false, entries: [], reason: 'ZIP entry is truncated or encrypted.' };
      const name = directory.subarray(offset + 46, offset + 46 + nameLength).toString('utf8').replace(/\\/g, '/');
      const unixMode = externalAttributes >>> 16, unixType = unixMode & 0xf000;
      if (name.startsWith('/') || name.startsWith('//') || /^[a-z]:/i.test(name) || name.split('/').includes('..')
          || (madeBy === 3 && unixType && ![0x8000, 0x4000].includes(unixType))) return { valid: false, entries: [], reason: 'ZIP contains an unsafe path or special filesystem entry.' };
      entries.push(name); totalUncompressed += uncompressed; totalCompressed += compressed; offset = end;
    }
    if (entries.length !== count) return { valid: false, entries: [], reason: 'ZIP directory count does not match.' };
    const ratio = totalCompressed > 0 ? totalUncompressed / totalCompressed : (totalUncompressed ? Infinity : 1);
    if (totalUncompressed > 1024 * 1024 * 1024 || ratio > 1000) return { valid: false, entries: [], reason: 'ZIP has an unsafe expansion ratio or uncompressed size.' };
    return { valid: true, entries, totalUncompressed, totalCompressed, expansionRatio: ratio };
  } finally { fs.closeSync(fd); }
}
function validateUtf8(file) {
  const decoder = new TextDecoder('utf-8', { fatal: true });
  let bytes = 0, suspicious = 0;
  const fd = fs.openSync(file, 'r'), buffer = Buffer.alloc(64 * 1024);
  try {
    let count;
    while ((count = fs.readSync(fd, buffer, 0, buffer.length, null)) > 0) {
      bytes += count;
      const text = decoder.decode(buffer.subarray(0, count), { stream: true });
      if (text.includes('\u0000')) return { valid: false, reason: 'Binary data is not accepted as a text document.' };
      for (let i = 0; i < text.length; i++) {
        const code = text.charCodeAt(i);
        if (code < 9 || (code > 13 && code < 32)) suspicious++;
      }
      if (suspicious > Math.max(16, bytes * 0.01)) return { valid: false, reason: 'Text file contains too many control characters.' };
    }
    decoder.decode();
    return { valid: true };
  } catch {
    return { valid: false, reason: 'Text file is not valid UTF-8.' };
  } finally {
    fs.closeSync(fd);
  }
}
function detectContent(file, extension = path.extname(file).toLowerCase()) {
  const stat = fs.statSync(file);
  if (!stat.isFile() || stat.size <= 0) return { valid: false, reason: 'الملف فارغ أو ليس ملفًا عاديًا.' };
  const fd = fs.openSync(file, 'r');
  let sample;
  try { sample = readAt(fd, 0, Math.min(stat.size, 8192)); }
  finally { fs.closeSync(fd); }
  const ext = String(extension || '').toLowerCase();
  let mimeType = '', mediaKind = 'document', container = '', format = '';
  const starts = (...values) => values.some(value => sample.subarray(0, value.length).equals(value));
  if (sample.length >= 3 && sample[0] === 0xff && sample[1] === 0xd8 && sample[2] === 0xff && stat.size >= 4) {
    const tailFd = fs.openSync(file, 'r'); let tail;
    try { tail = readAt(tailFd, Math.max(0, stat.size - 2), 2); } finally { fs.closeSync(tailFd); }
    if (tail.length === 2 && tail[0] === 0xff && tail[1] === 0xd9) { mimeType = 'image/jpeg'; mediaKind = 'media'; format = 'jpeg'; }
  }
  else if (sample.length >= 33 && starts(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a])) && sample.readUInt32BE(8) === 13 && sample.toString('ascii', 12, 16) === 'IHDR') { mimeType = 'image/png'; mediaKind = 'media'; format = 'png'; }
  else if (sample.length >= 14 && starts(Buffer.from('GIF87a'), Buffer.from('GIF89a'))) {
    const tailFd = fs.openSync(file, 'r'); let tail;
    try { tail = readAt(tailFd, stat.size - 1, 1); } finally { fs.closeSync(tailFd); }
    if (tail[0] === 0x3b) { mimeType = 'image/gif'; mediaKind = 'media'; format = 'gif'; }
  }
  else if (sample.length >= 20 && sample.toString('ascii', 0, 4) === 'RIFF' && sample.toString('ascii', 8, 12) === 'WEBP' && sample.readUInt32LE(4) + 8 <= stat.size && ['VP8 ', 'VP8L', 'VP8X'].includes(sample.toString('ascii', 12, 16))) { mimeType = 'image/webp'; mediaKind = 'media'; format = 'webp'; }
  else if (sample.length >= 16 && sample.toString('ascii', 4, 8) === 'ftyp' && sample.readUInt32BE(0) >= 16 && sample.readUInt32BE(0) <= stat.size) {
    const brand = sample.toString('ascii', 8, 12).toLowerCase();
    if (['avif','avis'].includes(brand)) { mimeType = 'image/avif'; mediaKind = 'media'; format = 'avif'; }
    else if (['heic','heix','hevc','hevx','mif1','msf1'].includes(brand)) { mimeType = ext === '.heif' ? 'image/heif' : 'image/heic'; mediaKind = 'media'; format = 'heif'; }
    else if (['3gp4','3gp5','3gp6','3ge6','3gg6'].includes(brand)) { mimeType = 'video/3gpp'; mediaKind = 'media'; format = '3gp'; }
    else if (['qt  '].includes(brand)) { mimeType = 'video/quicktime'; mediaKind = 'media'; format = 'quicktime'; }
    else if (['m4a ','m4b ','f4a ','f4b '].includes(brand)) { mimeType = 'audio/mp4'; mediaKind = 'audio'; format = 'm4a'; }
    else if (['m4v ','m4vh','m4vp'].includes(brand)) { mimeType = 'video/x-m4v'; mediaKind = 'media'; format = 'm4v'; }
    else { mimeType = 'video/mp4'; mediaKind = 'media'; format = 'mp4'; }
    container = 'iso-bmff';
  }
  else if (sample.length >= 8 && sample.toString('ascii', 0, 4) === 'fLaC') { mimeType = 'audio/flac'; mediaKind = 'audio'; format = 'flac'; }
  else if (sample.length >= 12 && sample.toString('ascii', 0, 4) === 'RIFF' && sample.readUInt32LE(4) + 8 <= stat.size && sample.toString('ascii', 8, 12) === 'WAVE' && sample.indexOf(Buffer.from('fmt '), 12) >= 12 && sample.indexOf(Buffer.from('data'), 12) >= 12) { mimeType = 'audio/wav'; mediaKind = 'audio'; format = 'wav'; }
  else if (sample.length >= 4 && sample.toString('ascii', 0, 4) === 'OggS') {
    const opus = sample.indexOf(Buffer.from('OpusHead')) >= 0;
    mimeType = opus ? 'audio/opus' : 'audio/ogg'; mediaKind = 'audio'; format = opus ? 'opus' : 'ogg';
  }
  else if (sample.length >= 2 && sample[0] === 0xff && [0xf1,0xf9].includes(sample[1] & 0xf9) && (sample[1] & 0x06) === 0) { mimeType = 'audio/aac'; mediaKind = 'audio'; format = 'aac'; }
  else if ((sample.length >= 3 && sample.toString('ascii', 0, 3) === 'ID3') || (sample.length >= 2 && sample[0] === 0xff && (sample[1] & 0xe0) === 0xe0 && (sample[1] & 0x06) !== 0)) { mimeType = 'audio/mpeg'; mediaKind = 'audio'; format = 'mp3'; }
  else if (sample.length >= 12 && sample.toString('ascii', 0, 4) === 'RIFF' && ['AVI ','AVIX'].includes(sample.toString('ascii', 8, 12))) { mimeType = 'video/x-msvideo'; mediaKind = 'media'; format = 'avi'; }
  else if (sample.length >= 16 && sample[0] === 0x1a && sample[1] === 0x45 && sample[2] === 0xdf && sample[3] === 0xa3) {
    const text = sample.toString('latin1');
    const webm = text.includes('webm'); mimeType = webm ? 'video/webm' : 'video/x-matroska'; mediaKind = 'media'; format = webm ? 'webm' : 'matroska'; container = 'ebml';
  }
  else if (sample.length >= 8 && /^%PDF-[12]\.[0-9]/.test(sample.toString('ascii', 0, 8))) {
    const tailFd = fs.openSync(file, 'r'); let tail;
    try { tail = readAt(tailFd, Math.max(0, stat.size - 2048), Math.min(stat.size, 2048)); } finally { fs.closeSync(tailFd); }
    if (tail.lastIndexOf(Buffer.from('%%EOF')) >= 0) { mimeType = 'application/pdf'; format = 'pdf'; }
  }
  else if (stat.size >= 512 && sample.length >= 8 && starts(Buffer.from([0xd0,0xcf,0x11,0xe0,0xa1,0xb1,0x1a,0xe1])) && ['.doc','.xls','.ppt'].includes(ext)) { mimeType = MIME[ext]; format = 'ole-office'; }
  else if (sample.length >= 2 && starts(Buffer.from('PK\x03\x04'), Buffer.from('PK\x05\x06'), Buffer.from('PK\x07\x08'))) {
    const zip = zipDirectory(file, stat);
    if (!zip.valid) return { valid: false, reason: zip.reason || 'ZIP archive is malformed.' };
    const names = new Set(zip.entries.map(name => name.toLowerCase()));
    if (ext === '.docx' && names.has('word/document.xml')) mimeType = MIME[ext];
    else if (ext === '.xlsx' && names.has('xl/workbook.xml')) mimeType = MIME[ext];
    else if (ext === '.pptx' && names.has('ppt/presentation.xml')) mimeType = MIME[ext];
    else if (ext === '.epub' && names.has('mimetype') && names.has('meta-inf/container.xml')) mimeType = MIME[ext];
    else if (ext === '.apk' && names.has('androidmanifest.xml')) mimeType = MIME[ext];
    else if (['.odt','.ods','.odp'].includes(ext) && names.has('meta-inf/manifest.xml') && names.has('mimetype')) mimeType = MIME[ext];
    else if (ext === '.zip') mimeType = 'application/zip';
    else return { valid: false, reason: 'بنية الأرشيف لا تطابق نوع المستند المحدد.' };
    format = 'zip-container'; container = 'zip';
    if (zip.totalUncompressed > 1024 * 1024 * 1024 || zip.expansionRatio > 1000) return { valid: false, reason: 'الأرشيف يتجاوز حدود فك الضغط الآمن.' };
  }
  else if (sample.length >= 32 && starts(Buffer.from([0x37,0x7a,0xbc,0xaf,0x27,0x1c]))) { mimeType = 'application/x-7z-compressed'; format = '7z'; }
  else if (sample.length >= 8 && sample.toString('ascii', 0, 7) === 'Rar!\x1a\x07') { mimeType = 'application/vnd.rar'; format = 'rar'; }
  else if (sample.length >= 10 && sample[0] === 0x1f && sample[1] === 0x8b && sample[2] === 8 && (sample[3] & 0xe0) === 0) { mimeType = 'application/gzip'; format = 'gzip'; }
  else if (stat.size > 262 && sample.length >= 4) {
    const headerFd = fs.openSync(file, 'r'); let tar;
    try { tar = readAt(headerFd, 257, 5); } finally { fs.closeSync(headerFd); }
    if (tar.toString('ascii') === 'ustar') { mimeType = 'application/x-tar'; format = 'tar'; }
  }
  if (!mimeType && VIDEO_EXT.has(ext) && sample.length >= 4 && (sample.readUInt32BE(0) === 0x000001b3 || sample.readUInt32BE(0) === 0x000001ba)) { mimeType = 'video/mpeg'; mediaKind = 'media'; format = 'mpeg'; }
  if (!mimeType && TEXT_EXT.has(ext)) {
    const checked = validateUtf8(file);
    if (!checked.valid) return { valid: false, reason: checked.reason };
    mimeType = MIME[ext] || 'text/plain'; format = 'text';
  }
  if (!mimeType && ext === '.bin') { mimeType = 'application/octet-stream'; format = 'binary'; }
  if (!mimeType) return { valid: false, reason: 'تعذر التحقق من توقيع الملف؛ لا يُقبل اعتمادًا على الامتداد أو MIME المرسل من المتصفح.' };
  const compatible = {
    '.jpg':['image/jpeg'],'.jpeg':['image/jpeg'],'.png':['image/png'],'.webp':['image/webp'],'.gif':['image/gif'],'.avif':['image/avif'],'.heic':['image/heic','image/heif'],'.heif':['image/heif','image/heic'],
    '.mp4':['video/mp4'],'.webm':['video/webm'],'.mov':['video/quicktime'],'.mkv':['video/x-matroska'],'.avi':['video/x-msvideo'],'.3gp':['video/3gpp'],'.m4v':['video/x-m4v','video/mp4'],'.mpeg':['video/mpeg'],'.mpg':['video/mpeg'],
    '.mp3':['audio/mpeg'],'.m4a':['audio/mp4'],'.ogg':['audio/ogg','audio/opus'],'.opus':['audio/opus','audio/ogg'],'.wav':['audio/wav'],'.aac':['audio/aac'],'.flac':['audio/flac'],
    '.pdf':['application/pdf'],'.doc':['application/msword'],'.xls':['application/vnd.ms-excel'],'.ppt':['application/vnd.ms-powerpoint'],'.zip':['application/zip'],'.docx':[MIME['.docx']],'.xlsx':[MIME['.xlsx']],'.pptx':[MIME['.pptx']],'.odt':[MIME['.odt']],'.ods':[MIME['.ods']],'.odp':[MIME['.odp']],'.epub':[MIME['.epub']],'.apk':[MIME['.apk']],'.7z':['application/x-7z-compressed'],'.rar':['application/vnd.rar'],'.tar':['application/x-tar'],'.gz':['application/gzip'],'.bin':['application/octet-stream']
  };
  const isCompatible = Array.isArray(compatible[ext])
    ? compatible[ext].includes(mimeType)
    : TEXT_EXT.has(ext) && (mimeType.startsWith('text/') || ['application/json', 'application/xml', 'application/yaml', 'application/sql'].includes(mimeType));
  if (!isCompatible) return { valid: false, reason: `توقيع المحتوى (${mimeType}) لا يطابق الامتداد ${ext || '(بدون امتداد)'}.`, detectedMime: mimeType };
  return { valid: true, mimeType, mediaKind: IMAGE_EXT.has(ext) || VIDEO_EXT.has(ext) ? 'media' : AUDIO_EXT.has(ext) ? 'audio' : mediaKind, format, container: container || null, sizeBytes: stat.size };
}

function detectAudioBuffer(input, extension) {
  const buffer = Buffer.isBuffer(input) ? input : Buffer.from(input || []);
  const ext = String(extension || '').toLowerCase();
  if (!buffer.length) return { valid: false, reason: 'الملف الصوتي فارغ.' };
  const starts = value => buffer.length >= value.length && buffer.subarray(0, value.length).equals(value);
  let mimeType = '', format = '';
  if (['.ogg', '.opus'].includes(ext) && starts(Buffer.from('OggS')) && buffer.length >= 32 && buffer[4] === 0) {
    const opus = buffer.indexOf(Buffer.from('OpusHead')) >= 0;
    if (ext === '.opus' && !opus) return { valid: false, reason: 'ملف OPUS لا يحتوي على ترويسة OpusHead.' };
    mimeType = opus ? 'audio/opus' : 'audio/ogg'; format = opus ? 'opus' : 'ogg';
  } else if (ext === '.mp3' && ((buffer.length >= 3 && starts(Buffer.from('ID3')))
      || (buffer.length >= 4 && buffer[0] === 0xff && (buffer[1] & 0xe0) === 0xe0 && (buffer[1] & 0x06) !== 0))) {
    mimeType = 'audio/mpeg'; format = 'mp3';
  } else if (ext === '.flac' && starts(Buffer.from('fLaC')) && buffer.length >= 8) {
    mimeType = 'audio/flac'; format = 'flac';
  } else if (ext === '.wav' && buffer.length >= 44 && starts(Buffer.from('RIFF')) && buffer.toString('ascii', 8, 12) === 'WAVE'
      && buffer.readUInt32LE(4) + 8 <= buffer.length && buffer.indexOf(Buffer.from('fmt '), 12) >= 12
      && buffer.indexOf(Buffer.from('data'), 12) >= 12) {
    mimeType = 'audio/wav'; format = 'wav';
  } else if (ext === '.aac' && buffer.length >= 7 && buffer[0] === 0xff && [0xf1, 0xf9].includes(buffer[1] & 0xf9) && (buffer[1] & 0x06) === 0) {
    mimeType = 'audio/aac'; format = 'aac';
  } else if (['.m4a', '.mp4'].includes(ext) && buffer.length >= 16 && buffer.toString('ascii', 4, 8) === 'ftyp'
      && buffer.readUInt32BE(0) >= 16 && buffer.readUInt32BE(0) <= buffer.length) {
    const brand = buffer.toString('ascii', 8, 12).toLowerCase();
    if (['m4a ', 'm4b ', 'f4a ', 'f4b ', 'mp42', 'isom', 'iso2', 'mp41'].includes(brand)) {
      mimeType = ext === '.m4a' ? 'audio/mp4' : 'video/mp4'; format = 'mp4';
    }
  } else if (ext === '.webm' && buffer.length >= 16 && buffer[0] === 0x1a && buffer[1] === 0x45 && buffer[2] === 0xdf && buffer[3] === 0xa3
      && buffer.toString('latin1').toLowerCase().includes('webm')) {
    mimeType = 'audio/webm'; format = 'webm';
  }
  if (!mimeType) return { valid: false, reason: 'توقيع الملف لا يطابق صيغة الصوت المعلنة.' };
  return { valid: true, mimeType, format, mediaKind: 'audio' };
}

function quickSummary(dir) {
  fs.mkdirSync(dir, { recursive: true }); let images = 0, files = 0;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) { if (!entry.isFile() || entry.name.startsWith('.')) continue; files++; if (IMAGE_EXT.has(path.extname(entry.name).toLowerCase())) images++; }
  return { files, images };
}
function scan(dir, maxMB = 20) {
  fs.mkdirSync(dir, { recursive: true }); const all = [], bad = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.')) continue;
    if (entry.isSymbolicLink()) { bad.push({ filename: entry.name, error: 'روابط الملفات غير مسموح بها داخل مكتبة الوسائط.' }); continue; }
    if (!entry.isFile()) continue;
    const ext = path.extname(entry.name).toLowerCase(), full = safePath(dir, entry.name); let stat;
    try { stat = fs.lstatSync(full); } catch { continue; }
    if (!MEDIA_EXT.has(ext)) { bad.push({ filename: entry.name, error: 'نوع غير مدعوم' }); continue; }
    if (!stat.isFile() || stat.size <= 0) { bad.push({ filename: entry.name, error: 'الملف فارغ أو غير عادي.' }); continue; }
    if (stat.size > maxMB * 1024 * 1024) { bad.push({ filename: entry.name, error: 'الحجم أكبر من الحد' }); continue; }
    let detected; try { detected = detectContent(full, ext); } catch (error) { detected = { valid: false, reason: String(error?.message || error) }; }
    if (!detected.valid) { bad.push({ filename: entry.name, error: detected.reason || 'تعذر التحقق من محتوى الملف.' }); continue; }
    const isImage = IMAGE_EXT.has(ext), isVideo = VIDEO_EXT.has(ext), isAudio = AUDIO_EXT.has(ext);
    all.push({ id: entry.name, filename: entry.name, ext, size: stat.size, updatedAt: stat.mtime.toISOString(), mimeType: detected.mimeType, format: detected.format, isImage, isVideo, isAudio, isVisualMedia: isImage || isVideo, mediaKind: isImage || isVideo ? 'media' : isAudio ? 'audio' : 'document' });
  }
  all.sort((a, b) => { const an = imageNumber(a.filename), bn = imageNumber(b.filename); return an || bn ? an - bn : a.filename.localeCompare(b.filename); });
  return { files: all, images: all.filter(item => item.isImage), invalid: bad, duplicates: [] };
}
module.exports = { IMAGE_EXT, VIDEO_EXT, VIDEO_PREVIEW_EXT, AUDIO_EXT, MEDIA_EXT, MIME, TEXT_EXT, ZIP_EXT, RESERVED_NAMES, safeName, safePath, nextImageName, uniqueFileName, hashFile, isInlineBrowserMedia, contentDisposition, quickSummary, detectContent, detectAudioBuffer, zipDirectory, scan, scanImages: scan };
