"use strict";
const crypto = require('node:crypto');
const { regexIsRisky } = require('./trigger-engine');
const conversationTargets = require('./conversation-targets');
const { isStaleMessage } = require('./message-lifecycle');
const { automationAllowedDuringQuiet } = require('./time-policy');
function idSerialized(id) { if (!id) return ''; if (typeof id === 'string') return id; if (id._serialized) return String(id._serialized); if (id.$1) return String(id.$1); if (id.remote) return idSerialized(id.remote); return id.id !== undefined ? String(id.id) : ''; }
function chatIdFromMessage(msg) { const candidates = [msg?.id?.remote, msg?._data?.id?.remote, msg?.msgId?.remote, msg?._data?.chatId, msg?.chatId, msg?.fromMe ? msg?.to : msg?.from, msg?.from, msg?.to]; for (const value of candidates) { const v = idSerialized(value).trim().toLowerCase(); if (v.endsWith('@g.us') || v.endsWith('@c.us') || v.endsWith('@lid')) return v; } return ''; }

const TRIGGERS = new Set(['message', 'group-message', 'message-count', 'time', 'message-age']);
const ACTIONS = new Set(['delete-message', 'delete-chat', 'archive-chat', 'mute-notifications', 'unmute-notifications', 'cleanup-old-messages', 'log']);
const MATCHES = new Set(['any', 'contains', 'exact', 'starts', 'ends', 'regex']);
const MODES = new Set(['daily', 'weekly', 'monthly', 'yearly', 'once']);
const GROUP_ACTION_SETTINGS = {
  'delete-message': 'allowDeleteMessage',
  'delete-chat': 'allowDeleteChat',
  'archive-chat': 'allowArchive',
  'mute-notifications': 'allowMute',
  'unmute-notifications': 'allowMute',
  'cleanup-old-messages': 'allowDeleteMessage',
};
const clean = v => String(v ?? '').normalize('NFKC').trim();
function isRealCalendarDate(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value || ''));
  if (!match) return false;
  const year = Number(match[1]), month = Number(match[2]), day = Number(match[3]);
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}
function jid(v) { return String(v || '').trim().toLowerCase(); }
function safePattern(rule) {
  const rawMode = rule.matchMode == null || String(rule.matchMode).trim() === '' ? 'any' : String(rule.matchMode);
  if (!MATCHES.has(rawMode)) throw new Error('نوع مطابقة الأتمتة غير مدعوم.');
  const mode = rawMode;
  const value = String(rule.pattern || '');
  if (mode === 'regex' && value) {
    if (value.length > 240) throw new Error('نمط Regex طويل جدًا؛ الحد 240 حرفًا.');
    if (regexIsRisky(value) || /\([^)]{1,120}\)[+*{]/u.test(value)) throw new Error('نمط Regex قد يكون مكلفًا جدًا؛ بسّطه لتجنب تجميد معالجة الرسائل.');
    try { new RegExp(value, 'iu'); } catch { throw new Error('صيغة Regex غير صالحة.'); }
  }
  return { mode, value };
}
function normalizeAutomationRule(input, session) {
  const x = input || {}, triggerType = TRIGGERS.has(String(x.triggerType)) ? String(x.triggerType) : 'message';
  let action = ACTIONS.has(String(x.action)) ? String(x.action) : 'log';
  if (triggerType === 'message-age') action = 'cleanup-old-messages';
  const match = safePattern(x);
  const time = /^([01]\d|2[0-3]):[0-5]\d$/.test(String(x.time || '22:00')) ? String(x.time || '22:00') : '22:00';
  const mode = MODES.has(String(x.mode || 'daily')) ? String(x.mode || 'daily') : 'daily';
  if (mode === 'once' && !isRealCalendarDate(String(x.date || ''))) throw new Error('تاريخ القاعدة لمرة واحدة غير صالح؛ استخدم تاريخًا حقيقيًا بصيغة YYYY-MM-DD.');
  if (triggerType === 'message-count' && (!Number.isInteger(Number(x.threshold)) || Number(x.threshold) < 1)) throw new Error('حدّ الرسائل يجب أن يكون رقمًا موجبًا.');
  if (['delete-message', 'delete-chat', 'cleanup-old-messages'].includes(action) && x.confirmDestructive !== true) throw new Error('فعّل تأكيد الإجراء المدمر قبل حفظ القاعدة.');
  const allowedKeys = new Set([
    ...(session?.recipients || []).map(r => `r:${r.id}`),
    ...(session?.groups || []).map(g => `g:${g.id}`),
  ]);
  const targetKeys = [...new Set((Array.isArray(x.targetKeys) ? x.targetKeys : []).map(String).filter(k => allowedKeys.has(k)))].slice(0, 2000);
  const rawIds = Array.isArray(x.targetChatIds) ? x.targetChatIds : String(x.targetChatIds || '').split(/[\n,;\s]+/);
  // Keep explicit IDs only when they resolve to a saved recipient/group; arbitrary
  // syntactically-valid JIDs are not an authorization mechanism.
  const targetChatIds = [...new Set(rawIds.map(jid).filter(v => {
    if (!/^(?:\d{5,25}(?:-\d+)*@g\.us|\d{5,25}@c\.us|\d{5,25}@lid)$/i.test(v)) return false;
    const access = conversationTargets.resolveChatAccess(session || {}, v, '');
    return access.allowed || access.reason === 'disabled';
  }))].slice(0, 2000);
  const targetMode = ['current', 'selected', 'all'].includes(x.targetMode) ? x.targetMode : 'current';
  if (targetMode === 'selected' && !targetKeys.length && !targetChatIds.length) throw new Error('اختر أهدافًا أو أدخل معرّفات محادثات صحيحة.');
  const threshold = Math.max(1, Math.min(100000000, Number(x.threshold) || 50));
  const ageHours = Math.max(1, Math.min(8760, Number(x.ageHours) || 24));
  const permission = x.groupPermissions && typeof x.groupPermissions === 'object' ? x.groupPermissions : {};
  return {
    id: String(x.id || crypto.randomUUID()), name: clean(x.name || 'قاعدة أتمتة').slice(0, 100) || 'قاعدة أتمتة', enabled: x.enabled !== false,
    priority: Math.max(-1000, Math.min(1000, Number(x.priority) || 0)), triggerType, matchMode: match.mode, pattern: match.value.slice(0, 500),
    threshold, countScope: x.countScope === 'session' ? 'session' : 'chat', repeatCount: x.repeatCount === true,
    time, mode, date: String(x.date || '').slice(0, 10), day: Math.max(0, Math.min(6, Number(x.day) || 0)), dayOfMonth: Math.max(1, Math.min(31, Number(x.dayOfMonth) || 1)), month: Math.max(1, Math.min(12, Number(x.month) || 1)), timezone: String(x.timezone || session?.settings?.timezone || 'Asia/Muscat').slice(0, 100),
    action, targetMode, targetKeys, targetChatIds, ageHours, deleteForEveryone: x.deleteForEveryone === true, confirmDestructive: x.confirmDestructive === true,
    groupOnly: triggerType === 'group-message' || x.groupOnly === true, requireGroupAdmin: x.requireGroupAdmin === true,
    cooldownSec: Math.max(0, Math.min(86400, Number(x.cooldownSec) || 0)),
    minMessageCount: Math.max(0, Number(x.minMessageCount) || 0), maxMessageCount: Math.max(0, Number(x.maxMessageCount) || 0),
    conditionContains: String(x.conditionContains || '').slice(0, 300),
    enabledAt: x.enabledAt || new Date().toISOString(), lastRunKey: String(x.lastRunKey || ''), lastFiredAt: String(x.lastFiredAt || ''),
    groupPermissions: { ...permission }, mutePermanent: x.mutePermanent === true, muteMinutes: Math.max(1, Math.min(525600, Number(x.muteMinutes) || 60)), createdAt: x.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString(), lastResult: x.lastResult || null,
  };
}
function matchText(rule, text) {
  let parsed; try { parsed = safePattern(rule); } catch { return false; }
  const { mode, value } = parsed, body = clean(text), pattern = clean(value);
  if (mode === 'any') return true;
  if (!pattern) return false;
  if (mode === 'exact') return body.toLocaleLowerCase() === pattern.toLocaleLowerCase();
  if (mode === 'contains') return body.toLocaleLowerCase().includes(pattern.toLocaleLowerCase());
  if (mode === 'starts') return body.toLocaleLowerCase().startsWith(pattern.toLocaleLowerCase());
  if (mode === 'ends') return body.toLocaleLowerCase().endsWith(pattern.toLocaleLowerCase());
  try { return new RegExp(pattern, 'iu').test(body); } catch { return false; }
}
function validDateTimeZone(tz) { try { new Intl.DateTimeFormat('en-US', { timeZone: tz }).format(); return true; } catch { return false; } }
function messageTimestamp(msg) {
  const raw = Number(msg?.timestamp || msg?._data?.t || msg?.t || 0);
  if (!raw) return 0;
  return raw > 1e12 ? raw : raw * 1000;
}
function senderId(msg) { return jid(idSerialized(msg?.author || msg?._data?.author || msg?.from || msg?.id?.participant)); }
function isGroupChat(chatId) { return jid(chatId).endsWith('@g.us'); }
function isAdmin(session, chatId, sender) {
  const group = (session.groups || []).find(g => jid(g.gid) === jid(chatId));
  if (!group || !sender) return false;
  const values = [...(group.admins || []), ...(group.participants || []).filter(p => p.admin)];
  return values.some(p => { const id = jid(typeof p === 'string' ? p : p.id); return id && (id === sender || id.split('@')[0] === sender.split('@')[0]); });
}
function conditionMatches(rule, msg, counts) {
  const n = rule.countScope === 'session' ? counts.total : counts.chat;
  if (rule.minMessageCount && n < rule.minMessageCount) return false;
  if (rule.maxMessageCount && n > rule.maxMessageCount) return false;
  if (rule.conditionContains && !String(msg?.body || '').toLocaleLowerCase().includes(rule.conditionContains.toLocaleLowerCase())) return false;
  return true;
}
function dedupeMessageKey(chatId, msg, body) {
  const serialized = idSerialized(msg?.id || msg?._data?.id || msg?.msgId);
  const timestamp = Number(msg?.timestamp || msg?._data?.t || msg?.t || 0);
  let material = '';
  if (serialized) material = `id|${jid(chatId)}|${serialized}`;
  else if (timestamp > 0) material = `fallback|${jid(chatId)}|${timestamp}|${String(body || '').slice(0, 5000)}`;
  return material ? crypto.createHash('sha256').update(material).digest('hex') : '';
}
function seenAtMillis(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  const number = Number(value); if (Number.isFinite(number) && number > 0) return number;
  const parsed = Date.parse(String(value || '')); return Number.isFinite(parsed) ? parsed : 0;
}
function pruneMemorySeen(seen, now = Date.now(), maxEntries = 8000, maxAgeMs = 86400000) {
  for (const [key, at] of seen) if (!Number.isFinite(Number(at)) || now - Number(at) > maxAgeMs || Number(at) > now + 300000) seen.delete(key);
  if (seen.size > maxEntries) {
    const oldest = [...seen.entries()].sort((a, b) => Number(a[1]) - Number(b[1]));
    for (const [key] of oldest.slice(0, seen.size - maxEntries)) seen.delete(key);
  }
  return seen;
}
function pruneSeenMessages(seenMessages, now = Date.now(), maxEntries = 6000, maxAgeMs = 86400000) {
  for (const [key, value] of Object.entries(seenMessages || {})) {
    const at = seenAtMillis(value);
    if (!at || now - at > maxAgeMs || at > now + 300000) delete seenMessages[key];
  }
  const keys = Object.keys(seenMessages || {});
  if (keys.length > maxEntries) {
    keys.sort((a, b) => seenAtMillis(seenMessages[a]) - seenAtMillis(seenMessages[b]));
    for (const key of keys.slice(0, keys.length - maxEntries)) delete seenMessages[key];
  }
  return seenMessages;
}
function countKeys(s, chatId) {
  const state = s.automation.eventState ||= { totalMessages: 0, byChat: {}, seenMessages: {}, ruleCounts: {} };
  state.byChat ||= {}; state.seenMessages ||= {}; state.ruleCounts ||= {};
  return { state, total: Number(state.totalMessages || 0), chat: Number(state.byChat[chatId] || 0) };
}
function getTargets(session, rule, currentChatId) {
  const isActiveRegistered = value => {
    const access = conversationTargets.resolveChatAccess(session || {}, value, '');
    return access.allowed;
  };
  if (rule.targetMode === 'current') return currentChatId && isActiveRegistered(currentChatId) ? [jid(currentChatId)] : [];
  let keys = rule.targetKeys || [];
  if (rule.targetMode === 'all') keys = [
    ...(session.recipients || []).map(r => `r:${r.id}`),
    ...(session.groups || []).map(g => `g:${g.id}`),
  ];
  const targets = [];
  for (const key of keys) {
    const target = conversationTargets.allowedTarget(session || {}, String(key), '');
    if (!target?.enabled || !target.chatId || !isActiveRegistered(target.chatId)) continue;
    targets.push(jid(target.chatId));
  }
  // Legacy raw IDs survive only if they still map to an active saved target.
  if (rule.targetMode === 'selected') {
    for (const raw of rule.targetChatIds || []) if (isActiveRegistered(raw)) targets.push(jid(raw));
  }
  return [...new Set(targets.filter(v => /(?:@g\.us|@c\.us|@lid)$/i.test(v)))].slice(0, 2000);
}

class AutomationEngine {
  constructor({ store, whatsapp, log }) { this.store = store; this.whatsapp = whatsapp; this.log = log || (() => {}); this.inFlight = new Set(); this.cooldowns = new Map(); this.seen = new Map(); this.muteApplied = new Map(); this.muteSweepAt = new Map(); this.lastRuleFail = new Map(); }
  record(s, rule, ok, detail = {}) {
    const item = { at: new Date().toISOString(), ruleId: rule?.id || '', name: rule?.name || 'إجراء يدوي', ok: Boolean(ok), action: rule?.action || detail.action || '', ...detail };
    s.automation.recent = [...(s.automation.recent || []), item].slice(-200);
    s.stats ||= {}; s.stats.automationActions = Number(s.stats.automationActions || 0) + (ok ? 1 : 0); s.stats.automationErrors = Number(s.stats.automationErrors || 0) + (ok ? 0 : 1);
    this.store.saveSession(s); return item;
  }
  async handleMessage(id, msg) {
    const s = this.store.loadSession(id);
    if (s.settings?.automationEnabled === false || s.automation?.enabled === false) return { handled: false, reason: 'disabled' };
    const chatId = chatIdFromMessage(msg), body = String(msg?.body || '').slice(0, 5000);
    if (!chatId || (msg?.fromMe && msg?.__chatBotSelfInput !== true)) return { handled: false, reason: 'ignored' };
    if (isStaleMessage(msg, s.settings?.maxInboundMessageAgeSec || 300)) return { handled: false, reason: 'stale-message' };
    if (!automationAllowedDuringQuiet(s.settings || {})) return { handled: false, reason: 'quiet-hours' };
    const access = conversationTargets.resolveInteractionAccess(s, chatId, this.whatsapp.selfChatId?.(id) || '');
    if (!access.allowed) return { handled: false, reason: access.reason === 'disabled' ? 'recipient-disabled' : access.reason === 'interaction-not-enabled' ? 'interaction-not-enabled' : 'unregistered-chat' };
    // The owner automation engine is a control plane, not an external-contact
    // autoresponder. It accepts only messages explicitly attested by the self-chat router.
    if (access.key !== 'self' || msg?.__chatBotSelfInput !== true) return { handled: false, reason: 'owner-automation-self-only' };
    const cs = countKeys(s, chatId), nowMs = Date.now();
    pruneSeenMessages(cs.state.seenMessages, nowMs);
    const messageKey = dedupeMessageKey(chatId, msg, body);
    const duplicateKey = messageKey ? `${s.id}|${messageKey}` : '';
    if (messageKey && (cs.state.seenMessages[messageKey] || this.seen.has(duplicateKey))) return { handled: false, reason: 'duplicate' };
    if (messageKey) {
      cs.state.seenMessages[messageKey] = nowMs;
      this.seen.set(duplicateKey, nowMs);
    }
    if (this.seen.size > 8000) pruneMemorySeen(this.seen, nowMs);
    cs.state.totalMessages = Number(cs.state.totalMessages || 0) + 1; cs.state.byChat[chatId] = Number(cs.state.byChat[chatId] || 0) + 1;
    if (Object.keys(cs.state.byChat).length > 3000) for (const k of Object.keys(cs.state.byChat).slice(0, Object.keys(cs.state.byChat).length - 3000)) delete cs.state.byChat[k];
    const counts = { total: cs.state.totalMessages, chat: cs.state.byChat[chatId] };
    const group = isGroupChat(chatId), sender = senderId(msg), rules = (s.automation.rules || []).filter(r => r.enabled !== false && ['message','group-message','message-count'].includes(r.triggerType)).sort((a,b) => Number(b.priority || 0) - Number(a.priority || 0));
    const candidates = [];
    for (const rule of rules) {
      if ((rule.groupOnly || rule.triggerType === 'group-message') && !group) continue;
      if (rule.triggerType === 'group-message' && !group) continue;
      if (rule.targetMode === 'selected' && !(getTargets(s, rule, chatId).includes(chatId))) continue;
      if (rule.triggerType === 'message' || rule.triggerType === 'group-message') { if (!matchText(rule, body)) continue; }
      let countStateUpdate = null;
      if (rule.triggerType === 'message-count') {
        const scope = rule.countScope === 'session' ? 'session' : chatId;
        const count = rule.countScope === 'session' ? counts.total : counts.chat;
        const stKey = `${rule.id}|${scope}`, lastBucket = Number(cs.state.ruleCounts[stKey] || 0), bucket = Math.floor(count / Math.max(1, Number(rule.threshold) || 50));
        if (rule.repeatCount ? bucket <= lastBucket : (count < Number(rule.threshold) || lastBucket > 0)) continue;
        countStateUpdate = [stKey, rule.repeatCount ? bucket : 1];
      }
      if (!conditionMatches(rule, msg, counts)) continue;
      if (rule.requireGroupAdmin && !isAdmin(s, chatId, sender)) continue;
      if (group && s.settings?.automationGroupPermissions?.adminsOnly === true && !isAdmin(s, chatId, sender)) continue;
      if (!validDateTimeZone(rule.timezone || s.settings.timezone)) continue;
      if (Number(rule.cooldownSec) > 0 && Date.now() - (this.cooldowns.get(`${s.id}|${rule.id}|${chatId}`) || 0) < Number(rule.cooldownSec) * 1000) continue;
      candidates.push({ rule, countStateUpdate });
    }
    // Save the count even when no rule matches, so thresholds are durable between restarts.
    this.store.saveSession(s);
    const executed = [];
    for (const candidate of candidates.slice(0, 5)) {
      const { rule, countStateUpdate } = candidate;
      const lock = `${s.id}|${rule.id}|${chatId}`; if (this.inFlight.has(lock)) continue;
      this.inFlight.add(lock);
      try {
        const result = await this.executeRule(s.id, rule, { event: 'message', message: msg, chatId, counts });
        if (result?.ok === true) {
          this.cooldowns.set(lock, Date.now());
          // Count thresholds are consumed only after the action actually succeeds.
          // A transient failure therefore remains eligible for a later retry.
          if (countStateUpdate) {
            const fresh = this.store.loadSession(s.id);
            fresh.automation.eventState ||= { totalMessages: 0, byChat: {}, seenMessages: {}, ruleCounts: {} };
            fresh.automation.eventState.ruleCounts ||= {};
            fresh.automation.eventState.ruleCounts[countStateUpdate[0]] = countStateUpdate[1];
            this.store.saveSession(fresh);
          }
        } else {
          this.log(s.id, 'WARN', `لم يكتمل إجراء قاعدة الأتمتة ${rule.name}; لم تُستهلك عتبة العدّاد ولم يُفعّل التهدئة.`);
        }
        executed.push({ ruleId: rule.id, result });
      } catch (error) {
        const fresh = this.store.loadSession(s.id); this.record(fresh, rule, false, { error: String(error?.message || error).slice(0, 500), chatId });
        this.log(s.id, 'ERROR', `فشلت قاعدة الأتمتة ${rule.name}: ${error.message || error}`);
      } finally { this.inFlight.delete(lock); }
    }
    return { handled: executed.length > 0, counts, executed };
  }
  groupActionAllowed(session, chatId, action) {
    if (!isGroupChat(chatId)) return true;
    const p = session.settings?.automationGroupPermissions || {};
    const key = GROUP_ACTION_SETTINGS[action];
    return key ? p[key] === true : true;
  }
  async executeRule(sessionId, rule, context = {}) {
    const s = this.store.loadSession(sessionId);
    if (!ACTIONS.has(rule.action)) throw new Error('نوع الإجراء غير مدعوم.');
    if (['delete-message','delete-chat','cleanup-old-messages'].includes(rule.action) && rule.confirmDestructive !== true) throw new Error('الإجراء المدمر غير مؤكد من المالك.');
    const currentChatId = context.chatId || (context.message && chatIdFromMessage(context.message)) || '';
    let targets = getTargets(s, rule, currentChatId);
    if (rule.targetMode === 'current' && !currentChatId && context.chatId) targets = [context.chatId];
    if (rule.action === 'delete-message' && !context.message) throw new Error('إجراء حذف رسالة يحتاج إلى رسالة محددة؛ استخدم «تنظيف الرسائل القديمة» إذا أردت حذفًا بحسب العمر.');
    if (rule.action === 'delete-message' && context.message) {
      if (!currentChatId) throw new Error('تعذر تحديد المحادثة التي تحتوي على الرسالة؛ لم يتم حذف شيء.');
      if (!this.groupActionAllowed(s, currentChatId, rule.action)) throw new Error('صلاحية حذف رسائل المجموعات متوقفة في إعدادات المالك.');
      if (rule.requireGroupAdmin && isGroupChat(currentChatId) && !isAdmin(s, currentChatId, senderId(context.message))) throw new Error('المرسل ليس مشرفًا مسجلًا في المجموعة.');
      const result = await this.whatsapp.deleteMessage(sessionId, context.message, { everyone: rule.deleteForEveryone === true });
      const fresh = this.store.loadSession(sessionId); return this.record(fresh, rule, true, { action: rule.action, chatId: currentChatId, messageId: idSerialized(context.message?.id), result: String(result || 'ok') });
    }
    if (!targets.length && rule.action !== 'log') throw new Error('لا توجد محادثات مستهدفة متاحة لهذه القاعدة.');
    const results = [];
    if (rule.action === 'log') results.push({ ok: true, note: `تم تشغيل القاعدة: ${rule.name}` });
    else if (rule.action === 'cleanup-old-messages') {
      const cutoff = Date.now() - Math.max(1, Number(rule.ageHours) || 24) * 3600000;
      for (const target of targets) {
        if (!this.groupActionAllowed(s, target, rule.action)) { results.push({ chatId: target, ok: false, error: 'صلاحية المجموعة متوقفة' }); continue; }
        try { const out = await this.whatsapp.deleteMessagesOlderThan(sessionId, target, cutoff, { everyone: rule.deleteForEveryone === true, limit: 1000 }); results.push({ chatId: target, ok: true, ...out }); }
        catch (error) { results.push({ chatId: target, ok: false, error: error.message || String(error) }); }
      }
    } else {
      for (const target of targets) {
        if (!this.groupActionAllowed(s, target, rule.action)) { results.push({ chatId: target, ok: false, error: 'صلاحية المجموعة متوقفة' }); continue; }
        try {
          let result;
          if (rule.action === 'delete-chat') result = await this.whatsapp.actOnChat(sessionId, target, 'delete');
          else if (rule.action === 'archive-chat') result = await this.whatsapp.actOnChat(sessionId, target, 'archive');
          else if (rule.action === 'mute-notifications') result = await this.whatsapp.actOnChat(sessionId, target, 'mute', { permanent: rule.mutePermanent === true, minutes: rule.muteMinutes });
          else if (rule.action === 'unmute-notifications') result = await this.whatsapp.actOnChat(sessionId, target, 'unmute');
          results.push({ chatId: target, ok: true, result: result ?? true });
        } catch (error) { results.push({ chatId: target, ok: false, error: String(error?.message || error).slice(0, 400) }); }
      }
    }
    const ok = results.every(x => x.ok);
    const fresh = this.store.loadSession(sessionId);
    return this.record(fresh, rule, ok, { action: rule.action, targets: targets.length, results: results.slice(0, 200) });
  }
  async runDueRules(sessionId, now = new Date(), dueForItem) {
    const s = this.store.loadSession(sessionId);
    if (s.settings?.automationEnabled === false || s.automation?.enabled === false) { await this.reconcileMutes(sessionId, now); return; }
    const rules = (s.automation.rules || []).filter(r => r.enabled !== false && ['time','message-age'].includes(r.triggerType));
    for (const rule of rules) {
      const lock = `${sessionId}|scheduled|${rule.id}`; if (this.inFlight.has(lock) || now.getTime() - (this.lastRuleFail.get(lock) || 0) < 15000) continue;
      const item = { ...rule, mode: rule.triggerType === 'message-age' ? (rule.mode || 'daily') : rule.mode, timezone: rule.timezone || s.settings.timezone };
      const due = dueForItem(now, item); if (!due.due) continue;
      this.inFlight.add(lock);
      try {
        const result = await this.executeRule(sessionId, rule, { event: 'scheduled', scheduledAt: now.toISOString() });
        const fresh = this.store.loadSession(sessionId), saved = (fresh.automation.rules || []).find(x => x.id === rule.id);
        if (saved) { const success = result?.ok === true; if (success) { saved.lastRunKey = due.key; this.lastRuleFail.delete(lock); } else this.lastRuleFail.set(lock, Date.now()); saved.lastResult = { ok: success, at: new Date().toISOString(), result }; saved.updatedAt = new Date().toISOString(); this.store.saveSession(fresh); }
      } catch (error) {
        this.lastRuleFail.set(lock, Date.now()); const fresh = this.store.loadSession(sessionId); this.record(fresh, rule, false, { error: String(error?.message || error).slice(0, 500), scheduledAt: now.toISOString() });
        this.log(sessionId, 'ERROR', `فشلت الأتمتة المجدولة ${rule.name}: ${error.message || error}`);
      } finally { this.inFlight.delete(lock); }
    }
    await this.reconcileMutes(sessionId, now);
  }
  async reconcileMutes(sessionId, now = new Date()) {
    if (Date.now() - (this.muteSweepAt.get(sessionId) || 0) < 10000) return;
    this.muteSweepAt.set(sessionId, Date.now());
    const s = this.store.loadSession(sessionId);
    const mutes = s.automation.mutes || [];
    let changed = false;
    for (const m of mutes) {
      if (m.enabled === false || !m.chatId) continue;
      if (m.expiresAt && new Date(m.expiresAt).getTime() <= now.getTime()) {
        try { await this.whatsapp.actOnChat(sessionId, m.chatId, 'unmute'); m.enabled = false; m.expiredAt = now.toISOString(); m.updatedAt = now.toISOString(); changed = true; this.muteApplied.delete(`${sessionId}|${m.id}`); } catch (error) { this.log(sessionId, 'WARN', `تعذر إلغاء كتم ${m.chatId}: ${error.message || error}`); }
        continue;
      }
      const fingerprint = `${m.chatId}|${m.expiresAt || 'permanent'}`;
      if (this.muteApplied.get(`${sessionId}|${m.id}`) === fingerprint) continue;
      try { await this.whatsapp.actOnChat(sessionId, m.chatId, 'mute', { permanent: !m.expiresAt, until: m.expiresAt ? new Date(m.expiresAt) : null }); this.muteApplied.set(`${sessionId}|${m.id}`, fingerprint); m.lastAppliedAt = now.toISOString(); changed = true; } catch (error) { this.log(sessionId, 'WARN', `تعذر تطبيق كتم ${m.chatId}: ${error.message || error}`); }
    }
    if (changed) this.store.saveSession(s);
  }
}
function normalizeMute(input) {
  const x = input || {}, chatId = jid(x.chatId);
  if (!/^(?:\d{5,25}(?:-\d+)*@g\.us|\d{5,25}@c\.us|\d{5,25}@lid)$/i.test(chatId)) throw new Error('معرّف المحادثة غير صالح. استخدم رقمًا بصيغة @c.us أو GID مجموعة بصيغة @g.us.');
  const permanent = x.mode === 'permanent' || x.permanent === true;
  const minutes = Math.max(1, Math.min(525600, Number(x.minutes) || 60));
  return { id: String(x.id || crypto.randomUUID()), chatId, chatName: clean(x.chatName || chatId).slice(0, 120), chatType: isGroupChat(chatId) ? 'group' : 'contact', mode: permanent ? 'permanent' : 'temporary', expiresAt: permanent ? '' : new Date(Date.now() + minutes * 60000).toISOString(), minutes: permanent ? 0 : minutes, enabled: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
}
module.exports = { AutomationEngine, normalizeAutomationRule, normalizeMute, matchText, messageTimestamp, isAdmin, getTargets, dedupeMessageKey, pruneSeenMessages, pruneMemorySeen, isRealCalendarDate, TRIGGERS, ACTIONS, MATCHES, MODES };
