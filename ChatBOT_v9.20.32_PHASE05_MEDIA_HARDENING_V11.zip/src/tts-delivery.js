'use strict';

const { splitSpeechText } = require('./text-to-speech');

function optionsForSegment(settings, segment) {
  return {
    proofread: settings.ttsProofreadEnabled !== false,
    model: String(settings.smartReplyModel || 'qwen3.5:4b'),
    timeoutMs: Math.max(1500, Math.min(60000, Number(settings.smartReplyTimeoutMs) || 12000)),
    backend: settings.ttsBackend || 'local',
    allowCloud: settings.ttsCloudConsent === true,
    voice: settings.ttsVoice || 'ar-EG-ShakirNeural',
    audarVoice: settings.ttsAudarVoice || 'demo_male_1',
    arabicMode: settings.ttsArabicMode || 'expressive',
    style: settings.ttsStyle || 'natural',
    rate: Number(settings.ttsRate) || 0,
    pitch: Number(settings.ttsPitch) || 0,
    volume: Number(settings.ttsVolume) || 0,
    noiseScale: Number(settings.ttsNoiseScale) || .667,
    noiseWidth: Number(settings.ttsNoiseWidth) || .8,
    exaggeration: Number(settings.ttsExaggeration ?? .55),
    pronunciationDictionary: Array.isArray(settings.ttsPronunciationDictionary) ? settings.ttsPronunciationDictionary : [],
    segment,
  };
}

async function sendSpeechInSegments({ synthesizer, text, settings = {}, getLatestSettings = () => settings, assertAllowed = () => {}, sendVoice }) {
  if (!synthesizer || typeof synthesizer.generate !== 'function' || typeof synthesizer.toWhatsAppVoice !== 'function') {
    throw new Error('محرك النطق غير مربوط أو غير مكتمل.');
  }
  if (typeof sendVoice !== 'function') throw new Error('مسار إرسال الرسائل الصوتية غير مربوط.');
  const maxSegments = Math.max(1, Math.min(10, Number(settings.ttsMaxReplySegments) || 6));
  const segments = splitSpeechText(text, { maxSegments });
  if (!segments.length) throw new Error('لا يوجد نص صالح لتحويله إلى صوت.');

  let sentSegments = 0;
  let proofreadSegments = 0;
  let activeBackend = '';
  for (const segment of segments) {
    let generated = null;
    try {
      assertAllowed();
      const latestBefore = getLatestSettings() || settings;
      const allowCloud = latestBefore.ttsCloudConsent === true;
      generated = await synthesizer.generate(segment, optionsForSegment(latestBefore, segment));
      activeBackend = generated.backend || activeBackend;
      if (latestBefore.ttsRequireProofread === true && generated.proofreadUsed !== true) {
        throw new Error('لم ينجح التدقيق اللغوي المحلي المطلوب؛ أُوقف إرسال هذا المقطع الصوتي.');
      }
      if (generated.proofreadUsed === true) proofreadSegments++;
      const voiceFile = await synthesizer.toWhatsAppVoice(generated.audioPath || generated.wavPath, {
        volume: generated.backend === 'local' ? Number(generated.volume) || 0 : 0,
        pitch: generated.backend === 'local' ? Number(generated.pitch) || 0 : 0,
      });
      assertAllowed();
      const latestBeforeSend = getLatestSettings() || latestBefore;
      if (generated.backend !== 'local' && latestBeforeSend.ttsCloudConsent !== true) {
        throw new Error('أُلغيت موافقة الصوت الخارجي أثناء التوليد؛ لم يُرسل هذا المقطع.');
      }
      await sendVoice(voiceFile, { index: sentSegments + 1, total: segments.length, backend: generated.backend || '' });
      sentSegments++;
    } catch (error) {
      if (sentSegments === 0 && (error?.code === 'SEND_UNCERTAIN' || error?.uncertain === true)) {
        const uncertain = new Error(`لم يصل تأكيد موثوق لنتيجة أول مقطع صوتي. افحص محادثة WhatsApp قبل أي إعادة إرسال لتجنب التكرار. السبب: ${String(error?.message || error).slice(0, 180)}`);
        uncertain.code = 'VOICE_REPLY_UNCERTAIN';
        uncertain.sentSegments = 0;
        uncertain.totalSegments = segments.length;
        throw uncertain;
      }
      if (sentSegments > 0) {
        const partial = new Error(`أُرسل ${sentSegments} من ${segments.length} مقاطع صوتية قبل تعذر إكمال البقية. بقي الرد النصي كاملًا. لا تعِد إرسال المجموعة كاملة تلقائيًا لتجنب التكرار. السبب: ${String(error?.message || error).slice(0, 220)}`);
        partial.code = 'VOICE_REPLY_PARTIAL';
        partial.sentSegments = sentSegments;
        partial.totalSegments = segments.length;
        throw partial;
      }
      throw error;
    } finally {
      if (generated) synthesizer.cleanup?.(generated);
    }
  }
  return { sent: true, sentSegments, totalSegments: segments.length, proofreadSegments, backend: activeBackend };
}

module.exports = { sendSpeechInSegments, optionsForSegment };
