# Chat BOT v9.20.32 — أساس Media Asset Pipeline (Stage 05)

**التاريخ:** 4 نوفمبر 2026

## ما تغير في هذه الدفعة

- توحيد upload في لوحة التحكم مع تنزيل مرفقات WhatsApp عبر `src/media-assets.js`؛ يُكتب الملف أولًا في staging ثم يفحص ويُلتزم به ذريًا.
- رفض المسارات الخفية/الاسم المحجوز، الروابط الرمزية، الملفات الفارغة، الامتدادات غير المدعومة، وتعارض توقيع المحتوى مع الامتداد. لا يعتمد الخادم على MIME المتصفح أو WhatsApp.
- كشف تواقيع JPEG/PNG/GIF/WebP/AVIF/HEIF/HEIC/MP4/MOV/3GP/WebM/Matroska/AVI/MP3/AAC/FLAC/OGG/Opus/WAV/PDF/OLE Office/ZIP وOpenDocument وEPUB/APK/7z/RAR/GZip/TAR والنص UTF-8، مع عدم فك أو تشغيل الأرشيفات.
- SHA-256 dedupe، Asset ID، فهرس `.asset-index.json` مخفي، atomic index replacement، قفل تسلسلي لكل مجلد، وحذف/تراجع متسق عند إلغاء التفويض أو فشل حفظ الفهرس.
- عند توفر ffprobe يتم التحقق من وجود تدفقات وسحب metadata محدودة؛ عدم توفره يظل حالة منفصلة. تفعيل ClamAV اختياري من البيئة؛ عند تفعيله يكون fail-closed.
- إعادة التحقق من صلاحية الجهة قبل وبعد التزام مرفق WhatsApp بالمكتبة.
- تحقق توقيع الصوت نفسه في تفريغ رسائل WhatsApp ورفع ملفات التفريغ؛ لا يكفي أن يعلن المرسل `audio/ogg` أو يختار امتدادًا صوتيًا لتمرير محتوى عشوائي إلى محرك Whisper/FFmpeg.

## المتبقي قبل إغلاق المرحلة 05

الدفعة لا تنشئ thumbnails ولا تحوّل أو تضغط الملفات، ولا تستخرج keyframes أو waveform/loudness، ولا تنفذ OCR/استخراج PDF/Office أو retention cleanup تلقائي. فهرس الأصول موجود لكن لا توجد واجهة إدارة metadata مستقلة بعد.

## التحقق

أضيف `test/media-assets.js` لاختبار تزوير الامتداد، empty/oversize، التكرار، IDs، صلاحيات الملفات، التزامن، سحب التفويض والتراجع، فشل الماسح وحذف metadata. تم تحديث fixtures القديمة لتستخدم تواقيع فعلية بدل محتوى وهمي. بيئة الفحص Node.js 22.16.0 وnpm 10.9.2. اجتاز FFprobe ملف OGG/Opus وصوتًا حقيقيًا وفيديو MP4 حقيقيًا وأبلغ عن التدفقات المتوقعة؛ لم يُستدعَ على PNG. رفضت اختبارات ZIP عينات traversal والتوسع المفرط والروابط الرمزية وقبلت عينة آمنة. `npm ci --ignore-scripts` لم يكتمل بسبب DNS `EAI_AGAIN` من npm registry، لذلك اختبار تكامل Express بقي غير قابل للتنفيذ. لا يوجد تشغيل Windows أو جلسة WhatsApp حقيقية في هذه البيئة.

## مراجع التقنية

- FFprobe الرسمي: https://www.ffmpeg.org/ffprobe.html
- ClamAV usage: https://docs.clamav.net/manual/Usage
- whatsapp-web.js Message / downloadMedia: https://docs.wwebjs.dev/Message.html
- Node.js release schedule: https://github.com/nodejs/Release/blob/main/README.md
