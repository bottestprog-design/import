# مراجعة المرحلة 04 — Outbound Outbox ومصالحة التسليم

**الإصدار:** 9.20.30  
**المرجع:** `docs/ENGINEERING_MASTER_BUILD_PLAN_V10_AR.md` — المرحلة 04.  
**الحالة:** اكتملت بوابة التنفيذ والاختبار المحلي؛ لم تُجرَ شهادة WhatsApp/Meta حية أو اختبار Windows.

## التنفيذ داخل ملفات المشروع

- `src/outbound-outbox.js`: سجل NDJSON دائم لكل جلسة، append مع `fsync`، إصلاح السطر النهائي المبتور، حالات lifecycle، compaction محدود يحافظ على الأعمال غير النهائية، idempotency مع نافذة dedupe، FIFO لكل محادثة، pacing، إلغاء قبل بدء الإرسال، manual retry، وفصل `created/accepted` عن `delivered/read`.
- `src/whatsapp.js`: مرّر إرسال النص والوسائط وVoice Note وPoll وEvent والرد المقتبس عبر Outbox واحد؛ حفظ `providerId` و`conversationId` وpayload reference وcorrelation ID؛ استعادة العناصر `queued` بعد جاهزية WhatsApp Web، وعدم إعادة `sending` بعد انقطاع العامل.
- `src/whatsapp-web-adapter.js`: مؤشر كتابة اختياري عبر قدرة الموصل الفعلية، مع fallback إذا لم يدعمه إصدار المكتبة؛ معطّل افتراضيًا.
- `src/whatsapp-cloud-api-adapter.js`: خطأ HTTP 429 رفض صريح قابل لإعادة المحاولة المحدودة؛ أخطاء 5xx/انقطاع الشبكة تبقى `uncertain` ولا تُعاد تلقائيًا.
- `server.js`: تخزين Outbox تحت `data/outbox`، مصالحة ACK و`message_create` من WhatsApp Web، مصالحة حالات Cloud حسب `providerMessageId`، استعادة حالات Cloud المحفوظة من inbound journal عند بدء الخادم، وواجهات محلية لعرض السجل والإلغاء وإعادة المحاولة مع إقرار المخاطر.
- `src/delivery.js`: مفاتيح idempotency مستقرة لمراحل النص/الوسائط/النص الختامي في الإرسال اليدوي والمجدول، حتى لا تتحول إعادة تشغيل المهمة إلى إرسال جديد بلا تمييز.
- `.env.example`: إعدادات pacing والمحاولات ومؤشر الكتابة الاختياري.

## قواعد السلامة المطبقة

- لا تُكتب محاولة الإرسال إلى الموصل قبل حفظ سجل `queued` محليًا.
- `sending` عند توقف العامل يصبح `uncertain` ولا يُعاد تلقائيًا؛ `validating` فقط يمكن إعادته إلى الطابور بأمان.
- لا تُعاد المحاولة تلقائيًا إلا بعد رفض Cloud API الصريح HTTP 429؛ 5xx وtimeouts وانقطاع الشبكة لا تُعامل كدليل على عدم الإرسال.
- ACK المتأخر يحدّث السجل بواسطة معرف رسالة الموصل. حالة Cloud التي تصل قبل استجابة الإرسال تُحفظ في inbound journal وتُعاد مصالحتها عند بدء التشغيل.
- الوسائط تُحفظ كمرجع ملف محلي مع SHA-256 والحجم ووقت التعديل؛ يُعاد فحصها قبل الإرسال، ويُرفض الملف إذا تغير أو خرج عن مجلد بيانات التطبيق.
- الإلغاء مسموح قبل بدء استدعاء الموصل فقط. إعادة `uncertain` يدويًا تتطلب `acknowledgeDuplicateRisk=true`.
- واجهات Outbox تخضع لحاجز المصادقة المحلي نفسه الخاص باللوحة؛ لا توجد نقطة عامة جديدة.
- لا تحتوي حزمة الإصدار على `data/` أو جلسات WhatsApp أو ملفات `.env` أو مسار متصفح الجهاز أو `node_modules`.

## نتائج التحقق المحلي

نتيجة `node scripts/verify.js` على شجرة الإصدار 9.20.30 النهائية، ثم بعد استخراج ZIP مستقلًا وتشغيل الاختبارات عليه مرة أخرى: JavaScript syntax ‏180/180؛ ‏107 اختبارًا ناجحًا؛ اختبار واحد متخطى؛ صفر إخفاقات؛ فحص متطلبات المشغّل PASS في التشغيلين. سبب التخطي الوحيد: `settings-endpoint-integration.js` يحتاج Express/npm غير مثبتين في بيئة الفحص.

الاختبارات تشمل: durability وtorn-line recovery، idempotency/conflict/dedupe window، ACK قبل/بعد provider response، Cloud status race، worker crash، manual retry، 429 bounded retry، FIFO مع hashing بطيء، توازي محادثات مختلفة، cancellation، file integrity، wiring، ومؤشر الكتابة الاختياري.

## الحدود المفتوحة

- **NOT TESTED:** إرسال/ACK حي عبر WhatsApp Web أو Meta Cloud API؛ لم تُستخدم credentials أو أرقام حقيقية.
- **NOT TESTED:** Windows/Chrome/Edge الفعلي؛ لا توجد بيئة Windows ضمن هذا التشغيل.
- **NOT TESTED:** تكامل HTTP الكامل لواجهات Outbox؛ اختبار `settings-endpoint-integration.js` يتخطى عند غياب Express/npm في بيئة الفحص.
- Cloud API ما زال موصلًا اختياريًا غير محدد افتراضيًا للجلسات؛ لم أفعّل تحويل أي جلسة إليه. رسائل Cloud الواردة تبقى معزولة حتى استكمال صلاحيات الأهداف ومسار الرد.
- Reaction لا يمر عبر Outbox في هذه المرحلة؛ يبقى ضمن مجال التفاعلات الأصلي في المرحلة 06. Poll/Event يمران عبر executor لكنهما يظلان مقيدين بحواجز القدرة التجريبية الحالية.
- مؤشر الكتابة اختياري ومعطّل افتراضيًا، ولا يُعرض كقدرة للقنوات التي لا تدعمه.

**نقطة الاستئناف التالية:** المرحلة 05 — Media Asset Pipeline. لا تبدأ قبل استخدام هذه الحزمة وتقريرها كخط أساس.
