# حالة بناء V10 — سجل المراحل القابل للتتبع

**آخر تحديث:** 4 نوفمبر 2026 — إصدار العمل v9.20.32 (المرحلة 05 بدأت؛ دفعة إدخال الوسائط وفهرستها منفذة محليًا، وبقية التحويلات والاستخراج ما زالت مفتوحة).

> الحالة تصف أدلة موجودة في ملفات المصدر أو الاختبارات؛ لا تعني أن أي ميزة مخططة موجودة لمجرد ورود اسمها في الخطة.

| المرحلة | المجال | الحالة | الدليل أو شرط الإغلاق |
|---:|---|---|---|
| 00 | تثبيت خط الأساس وجرد المصدر | **اكتملت المراجعة المحلية مع قيود بيئة معلنة** | مقارنة 306 ملفًا أصليًا؛ لا فقد؛ 44 تعديلًا و20 إضافة في v9.20.24؛ 98 اختبارًا ناجحًا واختبار واحد skipped؛ لا Windows/WhatsApp live |
| 01 | سلامة الجلسات ومنع ازدواج العمليات | **تغييرات محلية واختبارات محاكاة؛ الاعتماد الحي معلق** | هوية PID أدق، تتبع إطلاق Chromium، قفل fail-closed للحالة غير المحسومة، حالة reconnecting، واختبار 100 دورة محاكاة؛ يلزم QR/Logout/Re-pair حي واختبار Windows فعلي |
| 02 | Channel Provider Abstraction | **اكتملت محليًا؛ الاعتماد الحي لكل موصل معلق** | `src/channel-provider.js` وموصلا Web/Cloud واختبارات contract؛ Cloud غير مفعّل افتراضيًا |
| 03 | Inbound Event Journal | **اكتملت محليًا؛ اختبار Webhook/WhatsApp حي غير منفذ** | NDJSON durable journal، FIFO لكل محادثة، quarantine وreplay guard وCloud webhook HMAC |
| 04 | Durable Outbox | **اكتملت محليًا في v9.20.30؛ الاعتماد الحي معلق** | `src/outbound-outbox.js`، fsync، idempotency، FIFO/pacing، ACK reconciliation، uncertain guard، cancellation/manual retry؛ انظر تقرير المرحلة 04 |
| 05 | Media Asset Pipeline | **بدأت جزئيًا في v9.20.32؛ غير مغلقة** | `src/media.js` + `src/media-assets.js`: staging، sniffing ومطابقة MIME/امتداد، SHA-256، Asset ID وفهرس مخفي، حفظ ذري، قفل تزامن، فحص ZIP محدود، ffprobe عند توفره، ClamAV اختياري fail-closed، وإعادة تفويض تنزيل WhatsApp قبل/بعد الالتزام، والتحقق من توقيع الصوت الوارد/المرفوع قبل تمريره إلى STT. المتبقي: thumbnails/preview، تحويل/ضغط FFmpeg، keyframes/waveforms/loudness، OCR واستخراج PDF/Office، cleanup/retention، واختبار Windows/حقيقي |
| 06 | WhatsApp native interactions | دعم مكتبة جزئي؛ domain services غير منفذة | Poll/Event/RSVP/Reaction adapters واختبارات حية |
| 07 | Cloud API Flows/Catalog/Carousel | لم يُنفذ | WABA credentials وقوالب/أهلية/موافقات |
| 08 | 3D/AR assets | لم يُنفذ | validator/viewer/signed links/device tests |
| 09 | Conversation Core/model routing | أساس NLU/LLM موجود؛ orchestration عامة غير مكتملة | intent/entity/planner/model registry benchmark |
| 10 | Memory | أرشيف وسياق موجودان؛ نظام memory general غير منفذ | provenance/isolation/expiry/delete |
| 11 | Knowledge Base/RAG | لم يُنفذ | ingestion/index/retrieval/citations |
| 12 | Voice Platform | وحدات STT/TTS موجودة؛ اعتماد الجودة الحي معلق | inference حقيقي وتقييم سمعي/لهجات/Windows |
| 13 | Tool/Agent Runtime | أوامر ومساعد وتكاملات موجودة؛ runtime عام غير منفذ | registry/sandbox/permissions/approvals |
| 14 | Workflow Runtime | محرك قواعد/أتمتة محدود موجود؛ DAG غير منفذ | versioned DAG/checkpoint/replay |
| 15 | CRM/Inbox domain | جهات وأرشيف موجودان؛ CRM team domain غير مكتمل | assignments/SLA/notes/RBAC/domain APIs |
| 16 | Campaigns/Scheduling/Events | جدولة/أتمتة جزئية موجودة | consent/frequency caps/durable jobs/native events |
| 17 | Integrations & Plugins | Integration Hub موجود؛ sandbox/contract عام غير مكتمل | manifest/signature/isolation/versioning |
| 18 | Security/Privacy/RBAC | حمايات محلية موجودة؛ RBAC/consent registry عام غير مكتمل | threat model/RBAC/secret store/data policies |
| 19 | Observability/Operations | diagnostics موجودة؛ metrics/tracing الشاملة غير مكتملة | metrics/tracing/alerts/restore drills |
| 20 | Admin UI | واجهة موجودة لوظائف حالية؛ ربط المجالات الجديدة غير منفذ | كل عنصر UI يتصل بخدمة حقيقية ولا يكون mock |
| 21 | Test/Chaos/Live certification | اختبارات محلية واسعة؛ live certification غير منفذ | CI/chaos/Windows live smoke/audio evaluation |
| 22 | Packaging/Release | ZIP مصدر قابل للتحقق؛ installer/migration matrix لم تكتمل | clean install/upgrade/rollback/security scan |

## نطاق الدفعة 05 الحالية v9.20.32

تم توحيد رفع ملفات لوحة التحكم وتنزيل مرفقات WhatsApp في مسار إدخال واحد. لا يُقبل الملف بناءً على الامتداد أو `Content-Type` وحدهما؛ يتم فحص توقيع المحتوى، ومنع الملف الفارغ والروابط الرمزية، والتحقق من امتداد النوع المكتشف، وإنشاء بصمة SHA-256. تُحفظ الأصول ذريًا بصلاحيات ملف محلية خاصة ويُحدّث فهرس `.asset-index.json` المخفي بعد التحقق. التزامن لكل مكتبة يمنع تعارض أسماء الصور وفقد تحديثات الفهرس. لا يتم استخراج أو تشغيل محتوى الأرشيفات.

الماسح `ffprobe` يُستدعى فقط عند توافره، ويُحفظ وضعه بدقة (`verified`/`unavailable`/`timeout`) بدل الادعاء بأن الملف اجتاز فحصًا غير منفذ. فحص ClamAV اختياري؛ عند تفعيله لا يسمح النظام بالمتابعة إذا غاب الماسح أو انتهى بمهلة/خطأ أو وجد تهديدًا. لا توجد مكتبة ClamAV مثبتة في بيئة الفحص الحالية.

**حدود الإغلاق:** لم تُنفذ بعد الصور المصغرة والتحويل/الضغط واستخراج الإطارات/الموجات الصوتية وOCR وتحليل PDF/Office وسياسة الاحتفاظ والتنظيف التلقائي. كذلك لا يوجد اختبار Windows فعلي أو تنزيل مرفقات من WhatsApp حي؛ اختبارات تنزيل المرفقات الحالية تعتمد على المحاكاة. الدفعة الحالية أساس أمني/تخزيني، وليست اكتمال منصة الوسائط.

## قاعدة التسليم

كل مرحلة لاحقة تستلم نسخة المشروع السابقة كاملة. قبل التعديل تُراجع الملفات التابعة للنطاق سريعًا، وقبل التسليم تُقارن شجرة الملفات ويُعاد تشغيل الاختبارات المتأثرة والعامة. لا يُسجل أي اختبار حي دون حساب/جهاز حي، ولا يُسجل اختبار صوتي دون inference واستماع/تقييم.
