'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { AudioTranscriber, safeAudioExtension, allowedLanguage } = require('../src/audio-transcriber');
assert.equal(safeAudioExtension('voice.ogg', ''), '.ogg');
assert.equal(safeAudioExtension('voice.bin', 'audio/opus'), '.opus');
assert.equal(safeAudioExtension('payload.exe', 'application/octet-stream'), '');
assert.equal(allowedLanguage('ar'), 'ar');
assert.equal(allowedLanguage('auto'), 'auto');
assert.equal(allowedLanguage('detect'), 'auto');
assert.throws(() => allowedLanguage('xx'), /لغة التفريغ غير مدعومة/);
// A stale .env path must not mask a working local model installed by the setup script.
{ const root = path.resolve(__dirname, '..'); const small = path.join(root, 'models', 'ggml-small.bin'); const base = path.join(root, 'models', 'ggml-base.bin'); const originalSmall = fs.existsSync(small) ? fs.readFileSync(small) : null; const originalBase = fs.existsSync(base) ? fs.readFileSync(base) : null; const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'whisper-stale-model-')); try { fs.mkdirSync(path.dirname(small), { recursive: true }); fs.writeFileSync(small, 'small'); fs.writeFileSync(base, 'base'); const t = new AudioTranscriber({ env: { WHISPER_MODEL_PATH: path.join(temp, 'missing-ggml-base.bin') }, execFileImpl: async () => ({ stdout: '' }) }); assert.equal(t.config().modelPath, small, 'missing configured model should fall back to installed higher-accuracy local model'); } finally { if (originalSmall) fs.writeFileSync(small, originalSmall); else fs.rmSync(small, { force: true }); if (originalBase) fs.writeFileSync(base, originalBase); else fs.rmSync(base, { force: true }); fs.rmSync(temp, { recursive: true, force: true }); } }
// A stale configured executable path must not mask a local whisper-cli installed by the setup script.
{ const root = path.resolve(__dirname, '..'); const relative = path.join('tools', 'whisper', `whisper-cli${process.platform === 'win32' ? '.exe' : ''}`); const binary = path.join(root, relative); const dir = path.dirname(binary); const hadDir = fs.existsSync(dir); const hadFile = fs.existsSync(binary); const original = hadFile ? fs.readFileSync(binary) : null; const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'whisper-stale-bin-')); try { fs.mkdirSync(dir, { recursive: true }); if (!hadFile) fs.writeFileSync(binary, 'test executable'); const t = new AudioTranscriber({ env: { WHISPER_CPP_BIN: path.join(temp, 'missing-whisper-cli.exe') } }); assert.equal(t.config().binary, binary, 'missing configured binary should fall back to the installed project-local executable'); } finally { if (original) fs.writeFileSync(binary, original); else fs.rmSync(binary, { force: true }); if (!hadDir && fs.existsSync(dir)) { try { fs.rmdirSync(dir); fs.rmdirSync(path.dirname(dir)); } catch {} } fs.rmSync(temp, { recursive: true, force: true }); } }

(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'whisper-transcriber-test-'));
  const modelPath = path.join(dir, 'model.bin'); fs.writeFileSync(modelPath, 'test model');
  const invocations = [];
  const fakeExec = async (binary, args, opts = {}) => {
    invocations.push({ binary, args, opts });
    if (binary === 'which' || binary === 'where.exe') return { stdout: 'whisper-cli' };
    if (binary === 'ffmpeg') { fs.writeFileSync(args.at(-1), Buffer.concat([Buffer.alloc(44), Buffer.from('mock PCM audio')])); return { stdout: '' }; }
    const at = args.indexOf('-of');
    if (at >= 0) { fs.writeFileSync(`${args[at + 1]}.txt`, 'مرحبا بك، هذا نص تجريبي.'); if (args.includes('-oj')) { const fixed = args.indexOf('-l'); const language = fixed >= 0 ? args[fixed + 1] : 'fr'; fs.writeFileSync(`${args[at + 1]}.json`, JSON.stringify({ result: { language } })); } }
    return { stdout: '' };
  };
  try {
    const transcriber = new AudioTranscriber({ env: { WHISPER_BACKEND: 'whisper.cpp', WHISPER_CPP_BIN: 'whisper-cli', WHISPER_MODEL_PATH: modelPath }, execFileImpl: fakeExec, tempDir: dir });
    const status = await transcriber.status();
    assert.equal(status.ready, true);
    const result = await transcriber.transcribeBuffer(Buffer.from('mock audio'), { extension: '.ogg', language: 'ar' });
    assert.equal(result.transcript, 'مرحبا بك، هذا نص تجريبي.');
    assert.equal(result.backend, 'whisper.cpp');
    assert.ok(invocations.some(x => x.args.includes('-l') && x.args[x.args.indexOf('-l') + 1] === 'ar'));
    const autoCpp = await transcriber.transcribeBuffer(Buffer.from('auto language test'), { extension: '.ogg', language: 'auto' });
    assert.equal(autoCpp.language, 'fr', 'whisper.cpp automatic mode should return detected language metadata, not the literal auto token');
    assert.equal(autoCpp.requestedLanguage, 'auto');
    assert.ok(invocations.some(x => x.args.includes('-oj')), 'whisper.cpp must emit JSON metadata for detected-language reporting');
    assert.ok(invocations.some(x => x.binary === 'ffmpeg' && x.args.includes('-ar') && x.args.includes('16000')), 'WhatsApp-style OGG/OPUS should be normalized locally for whisper.cpp');

    assert.ok(invocations.some(x => x.args.includes('-f') && String(x.args[x.args.indexOf('-f') + 1]).endsWith('input-16khz-mono.wav')), 'whisper.cpp should receive the normalized PCM WAV when FFmpeg is available');
    const noFfmpeg = new AudioTranscriber({ env: { WHISPER_BACKEND: 'whisper.cpp', WHISPER_CPP_BIN: 'whisper-cli', WHISPER_MODEL_PATH: modelPath }, execFileImpl: async (binary, args) => {
      if ((binary === 'which' || binary === 'where.exe') && args[0] === 'whisper-cli') return { stdout: 'whisper-cli' };
      if ((binary === 'which' || binary === 'where.exe') && args[0] === 'ffmpeg') throw new Error('not found');
      throw new Error(`unexpected command ${binary}`);
    }, tempDir: dir });
    const noFfmpegStatus = await noFfmpeg.status();
    assert.equal(noFfmpegStatus.engineModelReady, true);
    assert.equal(noFfmpegStatus.voiceNotesReady, false, 'WhatsApp voice-notes readiness requires local FFmpeg conversion');
    assert.equal(noFfmpegStatus.ready, false);
    await assert.rejects(() => noFfmpeg.transcribeBuffer(Buffer.from('mock audio'), { extension: '.ogg', language: 'ar' }), /FFmpeg غير موجود/);

    const { createOggOpusFixture } = require('./ogg-opus-fixture');
    const validVoice = createOggOpusFixture(1024);
    const spoofedUpload = path.join(dir, 'spoof.ogg'); fs.writeFileSync(spoofedUpload, 'not an audio file');
    await assert.rejects(() => transcriber.transcribeFile(spoofedUpload, { originalName: 'spoof.ogg', mimetype: 'audio/ogg' }), /توقيع الملف/);
    assert.equal(require('../src/media').detectAudioBuffer(validVoice, '.ogg').valid, true);
    assert.equal(require('../src/media').detectAudioBuffer(Buffer.from('plain text'), '.ogg').valid, false);
    const message = { type: 'ptt', hasMedia: true, downloadMedia: async () => ({ data: validVoice.toString('base64'), mimetype: 'audio/ogg' }) };
    assert.equal(transcriber.rememberIncoming('session', message), true);
    const latest = await transcriber.transcribeLatest('session', { language: 'ar' });
    assert.equal(latest.source, 'whatsapp');
    assert.equal(latest.transcript, 'مرحبا بك، هذا نص تجريبي.');
    // Same message arriving through two event paths must share one in-flight/result entry.
    let mediaDownloads = 0;
    const duplicateMessage = { id: { _serialized: 'voice-duplicate-1' }, from: '11111@c.us', type: 'ptt', hasMedia: true, downloadMedia: async () => { mediaDownloads++; await new Promise(resolve => setTimeout(resolve, 15)); return { data: validVoice.toString('base64'), mimetype: 'audio/ogg' }; } };
    const first = transcriber.transcribeMessage(duplicateMessage, { language: 'auto' });
    const second = transcriber.transcribeMessage(duplicateMessage, { language: 'auto' });
    const [firstResult, secondResult] = await Promise.all([first, second]);
    assert.equal(mediaDownloads, 1, 'concurrent duplicate message events should download media only once');
    const explicitLanguage = await transcriber.transcribeMessage(duplicateMessage, { language: 'ar' });
    assert.equal(explicitLanguage.requestedLanguage, 'ar', 'different language modes must not incorrectly reuse the auto-language cached result');
    assert.equal(firstResult.transcript, secondResult.transcript);
    assert.equal((await transcriber.transcribeMessage(duplicateMessage, { language: 'auto' })).cached, true, 'recent successful result should be reused');

    // Queue limits prevent uncontrolled simultaneous model loads and make overload explicit.
    const queued = new AudioTranscriber({ env: { WHISPER_MAX_PENDING: '2' }, tempDir: dir });
    let active = 0, maxActive = 0;
    queued._transcribeBuffer = async buffer => { active++; maxActive = Math.max(maxActive, active); await new Promise(resolve => setTimeout(resolve, 20)); active--; return { transcript: String(buffer), backend: 'test' }; };
    const q1 = queued.transcribeBuffer(Buffer.from('one'));
    const q2 = queued.transcribeBuffer(Buffer.from('two'));
    await assert.rejects(() => queued.transcribeBuffer(Buffer.from('three')), /طابور التفريغ ممتلئ/);
    await Promise.all([q1, q2]);
    assert.equal(maxActive, 1, 'transcription should be serialized to protect model memory');
    assert.equal(transcriber.rememberIncoming('session', { type: 'image', hasMedia: true, downloadMedia: async () => ({}) }), false);
    await assert.rejects(() => transcriber.transcribeMessage({ downloadMedia: async () => ({ data: Buffer.from('not an audio file').toString('base64'), mimetype: 'audio/ogg' }) }), /توقيع الملف/);
    await assert.rejects(() => transcriber.transcribeLatest('missing'), /لم أعثر على صوتية/);
    const remoteFormFields = [];
    const remote = new AudioTranscriber({ env: { WHISPER_BACKEND: 'openai-compatible', WHISPER_API_KEY: 'test-key', WHISPER_API_URL: 'https://example.invalid/transcriptions' }, fetchImpl: async (_url, options) => { for (const [key, value] of options.body.entries()) remoteFormFields.push(key); return { ok: true, json: async () => ({ text: 'Bonjour tout le monde', language: 'fr' }) }; }, tempDir: dir });
    const autoRemote = await remote.transcribeBuffer(Buffer.from('mock audio'), { extension: '.ogg', language: 'auto' });
    assert.equal(autoRemote.language, 'fr');
    assert.ok(!remoteFormFields.includes('language'), 'auto mode must omit provider-specific fixed language instead of sending language=auto');
    console.log('audio-transcriber: ok (automatic language detection, local Whisper command, bounded queue, message deduplication/cache, remote auto mode, uploads and latest voice memo)');
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
})().catch(error => { console.error(error); process.exitCode = 1; });
