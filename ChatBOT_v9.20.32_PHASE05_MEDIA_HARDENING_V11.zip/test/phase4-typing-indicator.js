'use strict';
const assert = require('node:assert/strict');
const { WhatsAppWebAdapter } = require('../src/whatsapp-web-adapter');

(async () => {
  const calls = [];
  const chat = {
    async sendStateTyping() { calls.push('typing'); },
    async clearState() { calls.push('clear'); },
  };
  const manager = {
    assertChatAuthorized() { return { allowed: true }; },
    async ensureReady() { return { async getChatById() { return chat; } }; },
    async _sendTextViaWeb(_sid, _chatId, text) { calls.push(`send:${text}`); return { ok: true }; },
  };
  const adapter = new WhatsAppWebAdapter({ manager, env: { OUTBOX_TYPING_INDICATOR: 'true', OUTBOX_TYPING_DURATION_MS: '1' } });
  const result = await adapter.sendText('main', '12345@c.us', 'hello');
  assert.equal(result.ok, true);
  assert.deepEqual(calls, ['typing', 'send:hello', 'clear']);

  const fallbackCalls = [];
  const fallback = new WhatsAppWebAdapter({ manager: {
    assertChatAuthorized() { return { allowed: true }; },
    async ensureReady() { return { async getChatById() { return { async sendStateTyping() { throw new Error('typing unavailable'); } }; } }; },
    async _sendTextViaWeb() { fallbackCalls.push('sent'); return { ok: true }; },
  }, env: { OUTBOX_TYPING_INDICATOR: 'true' } });
  assert.equal((await fallback.sendText('main', '12345@c.us', 'fallback')).ok, true);
  assert.deepEqual(fallbackCalls, ['sent']);
  console.log('phase4-typing-indicator: ok (optional provider capability, fallback on unsupported/error, clear state)');
})().catch(error => { console.error(error); process.exitCode = 1; });
