'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { WhatsAppCloudApiAdapter } = require('../src/whatsapp-cloud-api-adapter');

const secret = 'phase3-test-app-secret';
const body = Buffer.from(JSON.stringify({ object: 'whatsapp_business_account', entry: [{ id: '123', changes: [{ value: {
  metadata: { phone_number_id: '1234567890' },
  messages: [{ id: 'wamid.abc', from: '96890000000', timestamp: '1793550000', type: 'text', text: { body: 'hello' } }],
  statuses: [{ id: 'wamid.sent', recipient_id: '96890000001', timestamp: '1793550001', status: 'delivered' }],
} }] }] }));
const signature = `sha256=${crypto.createHmac('sha256', secret).update(body).digest('hex')}`;
const adapter = new WhatsAppCloudApiAdapter({ env: { WHATSAPP_CLOUD_APP_SECRET: secret, WHATSAPP_CLOUD_API_VERSION: '', WHATSAPP_CLOUD_PHONE_NUMBER_ID: '' } });
assert.equal(adapter.verifyWebhookSignature(body, signature), true);
assert.equal(adapter.verifyWebhookSignature(body, `${signature.slice(0, -1)}0`), false);
assert.equal(adapter.verifyWebhookSignature(body, signature, ''), false);
const events = adapter.normalizeWebhookEvents(JSON.parse(body.toString('utf8')));
assert.equal(events.length, 2);
assert.equal(events[0].kind, 'text');
assert.equal(events[0].conversationId, '96890000000');
assert.equal(events[0].eventId, 'whatsapp-cloud-api:1234567890:wamid.abc');
assert.equal(events[1].kind, 'delivery_status');
assert.equal(events[1].providerStatus, 'delivered');
assert.equal(events[1].ackState, 3);
console.log('phase3-cloud-webhook: ok (HMAC-SHA256 verification, invalid-signature rejection, message/status normalization)');
