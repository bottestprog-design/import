'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const media = require('../src/media');
const { normalizeAutomationTask } = require('../src/store');
const { DeliveryService } = require('../src/delivery');

(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-media-options-'));
  try {
    const fixtures = {
      'share.webm': Buffer.concat([Buffer.from([0x1a, 0x45, 0xdf, 0xa3]), Buffer.from([0x42, 0x82, 0x84]), Buffer.from('webm'), Buffer.alloc(16)]),
      'voice.opus': Buffer.concat([Buffer.from('OggS'), Buffer.alloc(20), Buffer.from('OpusHead')]),
      'clip.aac': Buffer.from([0xff, 0xf1, 0x50, 0x80, 0x00, 0x1f, 0xfc]),
      'mix.flac': Buffer.concat([Buffer.from('fLaC'), Buffer.alloc(4)]),
      'clip.mov': Buffer.concat([Buffer.from([0, 0, 0, 20]), Buffer.from('ftypqt  '), Buffer.alloc(8)]),
      'archive.heic': Buffer.concat([Buffer.from([0, 0, 0, 20]), Buffer.from('ftypheic'), Buffer.alloc(8)]),
    };
    for (const [name, bytes] of Object.entries(fixtures)) fs.writeFileSync(path.join(dir, name), bytes);
    const scan = media.scan(dir);
    const map = Object.fromEntries(scan.files.map(item => [item.filename, item]));
    assert.equal(map['share.webm'].isVideo, true);
    assert.equal(map['share.webm'].mediaKind, 'media');
    assert.equal(map['voice.opus'].isAudio, true);
    assert.equal(map['clip.aac'].isAudio, true);
    assert.equal(map['mix.flac'].isAudio, true);
    assert.ok(media.MEDIA_EXT.has('.mov') && media.MEDIA_EXT.has('.heic'), 'less common WhatsApp formats must remain downloadable instead of silently becoming .bin');
    assert.equal(map['clip.mov'].isVideo, true, 'recognized video extensions are classified as video for WhatsApp delivery');
    assert.equal(map['clip.mov'].mediaKind, 'media', 'video files should use the media delivery path even when the browser only offers a download link');
    for (const ext of ['.avi', '.3gp', '.m4v', '.mpeg', '.mpg']) assert.ok(media.VIDEO_EXT.has(ext), `${ext} should be recognized as a video file`);
    assert.equal(map['archive.heic'].mediaKind, 'media');
    assert.equal(map['archive.heic'].mimeType, 'image/heic');
    assert.equal(media.MIME['.webm'], 'video/webm');
    assert.equal(media.MIME['.opus'], 'audio/opus');

    const normalized = normalizeAutomationTask({ id: 'task-media', targetKeys: ['r:p1'], mediaIds: ['image.jpg'], deliveryMediaMode: 'document', captionWithMedia: true });
    assert.equal(normalized.deliveryMediaMode, 'document', 'scheduled media mode must survive persistence');
    assert.equal(normalized.captionWithMedia, true, 'caption option must survive persistence');
    const stickerNormalized = normalizeAutomationTask({ id: 'task-sticker', targetKeys: ['r:p1'], mediaIds: ['sticker.webp'], deliveryMediaMode: 'sticker' });
    assert.equal(stickerNormalized.deliveryMediaMode, 'sticker', 'sticker delivery mode must survive persistence');

    const saved = { id: 'main', recipients: [], groups: [], settings: {}, automation: { tasks: [] }, cycle: { round: 1, currentIndex: 0, imageOrder: [], delivery: {}, manualGuard: {} }, stats: {} };
    const store = { safeSessionId: value => String(value || 'main'), loadSession: () => saved, getPaths: () => ({ dir, media: dir, images: dir }) };
    const service = new DeliveryService({ store, whatsapp: {}, log: () => {} });
    let captured = null;
    service.sendNow = async (_id, options) => { captured = options; return { ok: true, sent: [], failed: [] }; };
    await service.scheduledTaskRun('main', { id: 'task-media', targetKeys: ['r:p1'], mediaIds: ['image.jpg'], mediaMode: 'selected', deliveryMediaMode: 'document', captionWithMedia: true, preText: 'تعليق', postText: '' });
    assert.equal(captured.mediaMode, 'document');
    assert.equal(captured.captionWithMedia, true);
    console.log('media-options: ok (signature-verified audio/video/image formats, MIME types, and persisted scheduled delivery controls including sticker mode)');
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
})().catch(error => { console.error(error); process.exitCode = 1; });
