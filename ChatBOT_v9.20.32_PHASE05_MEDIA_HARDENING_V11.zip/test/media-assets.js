'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const media = require('../src/media');
const assets = require('../src/media-assets');

const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+nmN8AAAAASUVORK5CYII=', 'base64');
const write = (directory, filename, bytes) => {
  const full = path.join(directory, filename);
  fs.writeFileSync(full, bytes, { mode: 0o600 });
  return full;
};

(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-media-assets-'));
  const staging = path.join(root, 'staging'), library = path.join(root, 'library');
  fs.mkdirSync(staging); fs.mkdirSync(library);
  try {
    const valid = write(staging, 'valid.png', png);
    const inspected = await assets.inspectFile(valid, { originalName: 'valid.png', maxBytes: 1024 * 1024, runProbe: false, scannerOptions: { enabled: false } });
    assert.equal(inspected.mimeType, 'image/png');
    assert.equal(inspected.mediaKind, 'media');
    assert.equal(inspected.sha256, media.hashFile(valid));

    const fixtureDir = path.join(__dirname, 'fixtures');
    const safeZip = media.detectContent(path.join(fixtureDir, 'zip-safe.zip'), '.zip');
    assert.equal(safeZip.valid, true, 'a normal ZIP central directory should be accepted');
    for (const [name, why] of [['zip-traversal.zip', /مسار/], ['zip-expansion.zip', /توسع/], ['zip-symlink.zip', /مسار|special filesystem/]]) {
      const result = media.detectContent(path.join(fixtureDir, name), '.zip');
      assert.equal(result.valid, false, `${name} must be rejected`);
    }

    const mismatch = write(staging, 'spoof.jpg', png);
    await assert.rejects(assets.inspectFile(mismatch, { originalName: 'spoof.jpg', runProbe: false }), /لا يطابق الامتداد/);
    const empty = write(staging, 'empty.png', Buffer.alloc(0));
    await assert.rejects(assets.inspectFile(empty, { originalName: 'empty.png', runProbe: false }), /فارغ/);
    await assert.rejects(assets.inspectFile(valid, { originalName: 'valid.png', maxBytes: 8, runProbe: false }), /يتجاوز الحد/);
    assert.throws(() => media.safeName('../.asset-index.json'), /غير صالح/);
    assert.equal(media.safePath(library, '../escape.png'), path.join(path.resolve(library), 'escape.png'), 'untrusted traversal is reduced to a basename inside the media directory');

    const hashIndex = assets.buildHashIndex(library);
    const first = await assets.ingestStagedFile(valid, {
      directory: library, originalName: 'first.png', maxBytes: 1024 * 1024,
      runProbe: false, scannerOptions: { enabled: false }, existingByHash: hashIndex,
    });
    assert.equal(first.duplicate, false);
    assert.equal(first.filename, 'img.1.png');
    assert.ok(fs.existsSync(path.join(library, first.filename)));
    assert.equal(fs.statSync(path.join(library, first.filename)).mode & 0o777, 0o600);
    const index = assets.readIndex(library);
    assert.equal(index.assets[first.filename].sha256, inspected.sha256);
    assert.ok(index.assets[first.filename].id, 'every saved asset has a stable generated asset ID');

    const duplicateStage = write(staging, 'duplicate.png', png);
    const duplicate = await assets.ingestStagedFile(duplicateStage, {
      directory: library, originalName: 'copy.png', maxBytes: 1024 * 1024,
      runProbe: false, scannerOptions: { enabled: false }, existingByHash: hashIndex,
    });
    assert.equal(duplicate.duplicate, true);
    assert.equal(duplicate.filename, first.filename);
    assert.equal(fs.existsSync(duplicateStage), false, 'duplicate staging file is removed');
    assert.equal(media.scan(library).files.length, 1);
    assert.equal(media.scan(library).invalid.length, 0);

    let authChecks = 0;
    const cancelledStage = write(staging, 'cancelled.png', Buffer.concat([png, Buffer.from([0]) ]));
    await assert.rejects(assets.ingestStagedFile(cancelledStage, {
      directory: library, originalName: 'cancelled.png', maxBytes: 1024 * 1024,
      runProbe: false, scannerOptions: { enabled: false },
      onBeforeCommit: () => { authChecks++; if (authChecks > 1) throw new Error('authorization-revoked'); },
    }), /authorization-revoked/);
    assert.equal(fs.readdirSync(library).filter(name => !name.startsWith('.')).length, 1, 'revoked authorization rolls back committed file');
    assert.equal(fs.existsSync(cancelledStage), false);

    const concurrentA = write(staging, 'concurrent-a.png', Buffer.concat([png, Buffer.from([1])]));
    const concurrentB = write(staging, 'concurrent-b.png', Buffer.concat([png, Buffer.from([2])]));
    const concurrent = await Promise.all([concurrentA, concurrentB].map((stage, i) => assets.ingestStagedFile(stage, {
      directory: library, originalName: `concurrent-${i}.png`, maxBytes: 1024 * 1024,
      runProbe: false, scannerOptions: { enabled: false },
    })));
    assert.equal(new Set(concurrent.map(row => row.filename)).size, 2, 'concurrent files receive unique names');
    assert.equal(assets.readIndex(library).assets && Object.keys(assets.readIndex(library).assets).length, 3, 'concurrent manifest updates are not lost');

    const bufferSaved = await assets.ingestBuffer(png, {
      directory: path.join(root, 'buffer-library'), tempDirectory: staging, originalName: 'buffer.png',
      maxBytes: 1024 * 1024, runProbe: false, scannerOptions: { enabled: false },
    });
    assert.equal(bufferSaved.duplicate, false);
    assert.equal(fs.readdirSync(staging).filter(name => name.startsWith('.incoming-')).length, 0, 'buffer staging files are cleaned');

    await assert.rejects(assets.scanForMalware(valid, { enabled: true, binary: path.join(root, 'missing-clamscan') }), /فشل فحص الملف الأمني/);
    await assets.removeAssetFile(library, first.filename);
    assert.equal(fs.existsSync(path.join(library, first.filename)), false);
    assert.equal(assets.readIndex(library).assets[first.filename], undefined);

    console.log('media-assets: ok (signature/MIME validation, size and empty-file guards, atomic staging, stable asset IDs, SHA-256 dedupe, serialized concurrent commits, authorization rollback, scanner fail-closed and deletion metadata)');
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
