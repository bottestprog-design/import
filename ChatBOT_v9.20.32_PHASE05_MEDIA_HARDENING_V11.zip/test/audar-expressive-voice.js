'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {
  annotateAudarExpressionTags,
  resolveAudarSamplingTemperature,
  MAX_PRONUNCIATION_RULES,
} = require('../src/text-to-speech');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

const cases = [
  ['هههه ضحكتني جدًا', 'laughs'],
  ['خلّيها سر بيننا، لا تخبر أحدًا.', 'whispers'],
  ['هل أنت متأكد من هذا؟', 'curious'],
  ['مبروك، لقد نجحنا أخيرًا!', 'excited'],
  ['أنا آسف لما حدث معك.', 'sighs'],
  ['خذ نفسًا عميقًا ولا تستعجل.', 'exhales'],
  ['هذه مفاجأة، لا تخبر أحدًا الآن.', 'mischievously'],
  ['هذا تعليق بسخرية واضحة.', 'sarcastic'],
  ['إيه رأيك في الفكرة', 'curious'],
  ['ازاي حصل كده', 'curious'],
  ['ممكن تقولي السبب', 'curious'],
  ['أنا معاك وهنحلها سوا', 'exhales'],
  ['يا نهار أبيض، مش معقول!', 'excited'],
];
for (const [text, tag] of cases) {
  const result = annotateAudarExpressionTags(text, 'natural');
  assert.ok(result.tags.includes(tag), `expected ${tag} for ${text}`);
  assert.ok(result.text.includes(`[${tag}]`), `expression tag must be present in actual speech prompt: ${tag}`);
}
assert.equal(annotateAudarExpressionTags('اختبار الصوت', 'whisper').text, '[whispers] اختبار الصوت');
assert.equal(annotateAudarExpressionTags('اختبار الصوت', 'energetic').text, '[excited] اختبار الصوت');
const multi = annotateAudarExpressionTags('مبروك، لقد نجحنا! هل أنت متأكد؟ أنا آسف لما حدث.', 'natural');
assert.ok(multi.tags.includes('excited') && multi.tags.includes('curious') && multi.tags.includes('sighs'));
assert.ok(multi.tags.length <= 3, 'short replies must not be saturated with emotion tags');
const repeated = annotateAudarExpressionTags('إيه رأيك؟ ما رأيك؟', 'natural');
assert.equal((repeated.text.match(/\[curious\]/g) || []).length, 1, 'do not repeat identical emotional tags across adjacent questions');
const forcedMulti = annotateAudarExpressionTags('مرحبًا. كيف حالك؟ أخبرني المزيد.', 'curious');
assert.equal((forcedMulti.text.match(/\[curious\]/g) || []).length, 1, 'forced styles should still avoid theatrical repeated tags');
assert.equal(resolveAudarSamplingTemperature(0.55), 1);
assert.equal(resolveAudarSamplingTemperature(0.25), 0.754);
assert.equal(resolveAudarSamplingTemperature(1.2), 1.12);
assert.equal(resolveAudarSamplingTemperature(0.55, 'calm'), 0.8, 'calm delivery must use a lower sampling temperature');
assert.equal(resolveAudarSamplingTemperature(0.55, 'playful'), 1.07, 'playful delivery must allow more expressive sampling');
assert.equal(MAX_PRONUNCIATION_RULES, 300);

const worker = read('scripts/audar_tts_worker.py');
for (const voice of ['demo_male_1','demo_male_2','demo_male_3','demo_female_1','demo_female_2','demo_female_3']) {
  assert.ok(worker.includes(voice), `worker should support ${voice}`);
}
assert.ok(worker.includes('Audar-TTS-V1-Turbo-Q5_K_M.gguf'));
assert.ok(worker.includes('temperature: float = 1.0'));
assert.ok(worker.includes('smokeTest'));
assert.ok(worker.includes('codec_directory_is_complete'), 'manual codec directory must contain config and full weights');
assert.ok(worker.includes('HF_TOKEN'), 'gated NeuCodec download must accept a private HF token');
assert.ok(worker.includes('hf_hub_download') && !worker.includes('resume_download'), 'downloads must remain compatible with huggingface_hub 1.x');
assert.ok(worker.indexOf('filename="config.json"') < worker.indexOf('Downloading {tier} GGUF model'), 'NeuCodec access must be preflighted before the large GGUF download');
const runtime = read('src/audar-tts-runtime.js');
assert.ok(runtime.includes('smokeTest !== true'), 'runtime must reject readiness before actual Arabic smoke inference');
assert.ok(runtime.includes('AUDAR_TTS_CODEC_DIR') && runtime.includes('AUDAR_TTS_MODEL_FILE'), 'runtime must pass manually configured codec/model paths to the child worker');
const source = read('src/text-to-speech.js');
assert.ok(source.includes('voice: statusVoice, allowCloud: cloudAllowed, audarVoice, arabicMode'), 'selected voice, explicit cloud consent and Arabic mode must reach the readiness check');
assert.ok(source.includes('codecDir: cfg.audarCodecDir, modelFile: cfg.audarModelFile'), 'configured local codec and model files must reach the running worker');
assert.ok(source.includes('const smokeTested = this.audarRuntime?.readyInfo?.smokeTest === true') && /voiceReady, ready: enabled && packageReady && modelReady && voiceReady, smokeTested/.test(source), 'status must distinguish installed assets from a passed real speech inference smoke test');
assert.ok(source.includes("normalizeArabicDiacritizedCandidate(candidate, original)"), 'Arabic pronunciation prep must use guarded diacritization');
const setup = read('scripts/setup-local-ai.ps1');
assert.ok(setup.includes('qwen3.5:4b') && !setup.includes('qwen2.5:3b'));
const bootstrap = read('src/voice-bootstrap.js');
assert.ok(bootstrap.includes('AUDAR_TTS_MODEL_FILE') && bootstrap.includes('AUDAR_TTS_CODEC_DIR'), 'bootstrap must persist explicit local asset paths');
const docs = read('AUDAR_TTS_SETUP_AR.md');
assert.ok(docs.includes('HF_TOKEN') && docs.includes('neuphonic/neucodec'), 'setup guide must explain the gated codec prerequisite');
console.log('audar-expressive-voice: ok (eight expression cues, broader colloquial Arabic tagging, style-aware sampling, six selected voices, gated codec/manual path checks, current Hub API compatibility, verified speech smoke test, guarded Arabic diacritization, and Qwen 3.5 setup)');
