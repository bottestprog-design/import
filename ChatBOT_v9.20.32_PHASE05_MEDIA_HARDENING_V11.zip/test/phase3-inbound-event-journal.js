'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { InboundEventJournal } = require('../src/inbound-event-journal');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-inbound-journal-'));
try {
  const event = {
    eventId: 'whatsapp-web:s-1:message-1', provider: 'whatsapp-web', providerVersion: 'test', accountId: 's-1',
    conversationId: '123456789@c.us', messageId: 'message-1', providerMessageId: 'message-1',
    kind: 'text', text: 'hello', receivedAt: new Date().toISOString(), eventType: 'incoming',
    correlationId: 'corr-1',
  };
  const first = new InboundEventJournal({ rootDir: root });
  const accepted = first.receive('s-1', event, { transport: 'test' });
  assert.equal(accepted.accepted, true);
  assert.equal(accepted.record.status, 'received');
  assert.equal(accepted.record.sequence, 1);
  assert.equal(first.receive('s-1', event).reason, 'duplicate');
  first.transition('s-1', event.eventId, 'queued');
  first.transition('s-1', event.eventId, 'processing');

  const afterRestart = new InboundEventJournal({ rootDir: root });
  assert.equal(afterRestart.receive('s-1', event).reason, 'duplicate', 'durable dedupe survives a new process instance');
  const recovery = afterRestart.recover('s-1');
  assert.equal(recovery.uncertain.length, 1, 'processing event is not blindly replayed after a crash');
  assert.equal(afterRestart.get('s-1', event.eventId).status, 'uncertain');
  assert.equal(afterRestart.requestReplay('s-1', event.eventId).reason, 'explicit-risk-acknowledgement-required');
  const replay = afterRestart.requestReplay('s-1', event.eventId, { acknowledgeDuplicateRisk: true });
  assert.equal(replay.accepted, true);
  assert.equal(replay.record.status, 'replay_requested');

  const file = afterRestart.file('s-1');
  fs.appendFileSync(file, '{truncated-json-line');
  const recoveredAgain = new InboundEventJournal({ rootDir: root });
  assert.equal(recoveredAgain.list('s-1').length, 1);
  assert.equal(recoveredAgain.stats('s-1').corruptLines, 1, 'a torn final line is ignored without losing earlier records');
  assert.equal(recoveredAgain.list('s-1')[0].event.correlationId, 'corr-1');
  const afterTornTail = { ...event, eventId: 'after-torn-tail', messageId: 'message-after-torn-tail' };
  assert.equal(recoveredAgain.receive('s-1', afterTornTail).accepted, true, 'new writes remain readable after repairing a torn final line');
  const finalReload = new InboundEventJournal({ rootDir: root });
  assert.ok(finalReload.get('s-1', event.eventId));
  assert.ok(finalReload.get('s-1', afterTornTail.eventId), 'a later append is not concatenated to the damaged JSONL tail');

  // Compaction must retain a small dedupe tombstone for processed events.
  const compactRoot = path.join(root, 'compact');
  const compacting = new InboundEventJournal({ rootDir: compactRoot, maxJournalBytes: 1024 * 1024, maxEvents: 5000 });
  const bulkyEvent = (index) => ({ ...event, eventId: `compact:${index}`, messageId: `compact-message-${index}`, text: 'x'.repeat(9500), receivedAt: new Date(Date.now() + index).toISOString() });
  for (let index = 0; index < 125; index++) compacting.receive('s-1', bulkyEvent(index), { status: 'processed', transport: 'test' });
  const compactState = compacting.ensureLoaded('s-1');
  assert.ok(fs.statSync(compacting.file('s-1')).size < 1024 * 1024, 'journal compacts to its configured byte limit');
  const compactedFirst = compacting.get('s-1', 'compact:0');
  assert.ok(compactedFirst, 'recent dedupe record is retained across compaction');
  assert.equal(compactedFirst.compacted, true);
  assert.equal(compactedFirst.event.text, '');
  assert.equal(compacting.receive('s-1', bulkyEvent(0)).reason, 'duplicate', 'compacted tombstones still prevent duplicate delivery');
  console.log('phase3-inbound-event-journal: ok (durable dedupe, crash uncertainty, guarded replay, torn-line recovery, bounded compaction)');
} finally { fs.rmSync(root, { recursive: true, force: true }); }
