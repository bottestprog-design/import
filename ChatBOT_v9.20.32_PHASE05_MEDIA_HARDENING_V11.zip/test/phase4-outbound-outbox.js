'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { OutboundOutbox } = require('../src/outbound-outbox');

const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-outbox-'));
const root = path.join(temp, 'outbox');
const sessionRoot = path.join(temp, 'data');
fs.mkdirSync(sessionRoot, { recursive: true });
const make = (options = {}) => new OutboundOutbox({ rootDir: root, allowedRoots: [sessionRoot], minIntervalMs: 0, retryBaseMs: 100, ...options });
const ok = (id, ack = 'created') => ({ messageId: id, __chatBotAck: { status: ack, id } });
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

(async () => {
  try {
    // Durable write + idempotency: a repeated key never creates a second provider call.
    let outbox = make();
    let calls = 0;
    const base = { sessionId: 'main', providerId: 'whatsapp-web', conversationId: '12345@c.us', target: '12345@c.us', kind: 'text', payload: { text: 'hello' }, idempotencyKey: 'send-1' };
    const first = await outbox.submit(base, { dispatch: async () => { calls++; return ok('wamid-1'); } });
    assert.equal(first.__chatBotOutbox.status, 'created');
    assert.equal(outbox.stats('main').counts.created, 1);
    const duplicate = await outbox.submit(base, { dispatch: async () => { calls++; return ok('wamid-duplicate'); } });
    assert.equal(duplicate.__chatBotOutbox.duplicate, true);
    assert.equal(calls, 1);
    await assert.rejects(() => outbox.submit({ ...base, payload: { text: 'different' } }, { dispatch: async () => ok('bad') }), error => error.code === 'OUTBOX_IDEMPOTENCY_CONFLICT');
    outbox = make();
    assert.equal(outbox.get('main', first.__chatBotOutbox.id).providerMessageId, 'wamid-1');
    assert.equal(outbox.recover('main').uncertain, 0);

    // A torn final NDJSON append is repaired before the next durable write.
    const torn = make();
    await torn.submit({ ...base, idempotencyKey: 'before-torn' }, { dispatch: async () => ok('before-torn-id') });
    fs.appendFileSync(torn.file('main'), '{"op":"record"');
    const afterTorn = make();
    await afterTorn.submit({ ...base, idempotencyKey: 'after-torn' }, { dispatch: async () => ok('after-torn-id') });
    const journalLines = fs.readFileSync(afterTorn.file('main'), 'utf8').trim().split(/\r?\n/);
    assert.ok(journalLines.length >= 3);
    for (const line of journalLines) assert.doesNotThrow(() => JSON.parse(line));

    // Idempotency is bounded by a dedupe window for intentional later repeats.
    let fakeNow = Date.now();
    const windowOutbox = make({ now: () => fakeNow, dedupeWindowMs: 1000 });
    let windowCalls = 0;
    const windowInput = { ...base, idempotencyKey: 'windowed-repeat' };
    const windowFirst = await windowOutbox.submit(windowInput, { dispatch: async () => { windowCalls++; return ok('window-1'); } });
    const windowDuplicate = await windowOutbox.submit(windowInput, { dispatch: async () => { windowCalls++; return ok('window-duplicate'); } });
    assert.equal(windowDuplicate.__chatBotOutbox.duplicate, true);
    fakeNow += 1001;
    const windowSecond = await windowOutbox.submit(windowInput, { dispatch: async () => { windowCalls++; return ok('window-2'); } });
    assert.notEqual(windowSecond.__chatBotOutbox.id, windowFirst.__chatBotOutbox.id);
    assert.equal(windowCalls, 2);

    // ACK can arrive before the provider response gives the message ID.
    const earlyAckOutbox = make();
    const ackPromise = earlyAckOutbox.submit({ ...base, idempotencyKey: 'send-early-ack' }, {
      dispatch: async () => { earlyAckOutbox.reconcileAck('main', { id: 'wamid-early', ack: 2 }); return ok('wamid-early'); },
    });
    const ackResult = await ackPromise;
    assert.equal(ackResult.__chatBotOutbox.status, 'delivered');
    assert.equal(earlyAckOutbox.get('main', ackResult.__chatBotOutbox.id).ackState, 2);
    earlyAckOutbox.reconcileAck('main', { id: 'wamid-early', ack: 3 });
    assert.equal(earlyAckOutbox.get('main', ackResult.__chatBotOutbox.id).status, 'read');

    // A lost ACK after send start becomes uncertain on process restart, never auto-replayed.
    const crashOutbox = make();
    let release;
    const gate = new Promise(resolve => { release = resolve; });
    const hanging = crashOutbox.submit({ ...base, idempotencyKey: 'send-crash' }, { dispatch: () => gate });
    await wait(20);
    const crashRecord = crashOutbox.list('main').find(row => row.idempotencyKey === 'send-crash');
    assert.equal(crashOutbox.get('main', crashRecord.id).status, 'sending');
    const restarted = make();
    const recovered = restarted.recover('main');
    assert.equal(recovered.uncertain, 1);
    await assert.rejects(() => restarted.submit({ ...base, idempotencyKey: 'send-crash' }, { dispatch: async () => { throw new Error('must not dispatch'); } }), error => error.code === 'SEND_UNCERTAIN');
    release(ok('late-wamid'));
    await hanging;

    // Manual retry of uncertain work requires explicit duplicate-risk acknowledgement.
    const manual = make();
    let manualCalls = 0;
    await assert.rejects(() => manual.submit({ ...base, idempotencyKey: 'manual-uncertain' }, { dispatch: async () => { manualCalls++; throw Object.assign(new Error('uncertain'), { code: 'SEND_UNCERTAIN' }); } }), error => error.code === 'SEND_UNCERTAIN');
    const uncertainRecord = manual.list('main').find(row => row.idempotencyKey === 'manual-uncertain');
    const denied = await manual.retry('main', uncertainRecord.id, { dispatchFactory: () => ({ dispatch: async () => ok('never') }) });
    assert.equal(denied.reason, 'explicit-risk-acknowledgement-required');
    const retried = await manual.retry('main', uncertainRecord.id, { acknowledgeDuplicateRisk: true, dispatchFactory: () => ({ dispatch: async () => { manualCalls++; return ok('manual-retry-id'); } }) });
    assert.equal(retried.ok, true);
    assert.equal(manualCalls, 2);
    assert.equal(retried.record.retryOf, uncertainRecord.id);

    // Only a definitive Cloud API 429 is retried automatically; a 5xx/network timeout is uncertain.
    const rate = make({ maxAttempts: 3 });
    let rateCalls = 0;
    const rateResult = await rate.submit({ ...base, providerId: 'whatsapp-cloud-api', idempotencyKey: 'rate-429' }, { dispatch: async () => {
      rateCalls++;
      if (rateCalls < 3) throw Object.assign(new Error('rate limited'), { code: 'CLOUD_API_REJECTED', statusCode: 429, retryable: true });
      return { messageId: 'cloud-id', __chatBotAck: { status: 'accepted', id: 'cloud-id' } };
    } });
    assert.equal(rateCalls, 3);
    assert.equal(rateResult.__chatBotOutbox.status, 'accepted');
    const cloudStatus = rate.reconcileProviderStatus('main', { providerMessageId: 'cloud-id', status: 'delivered', ackState: 3 });
    assert.equal(cloudStatus.record.status, 'delivered');
    const statusRace = make();
    assert.equal(statusRace.reconcileProviderStatus('main', { providerMessageId: 'cloud-race-id', status: 'read', ackState: 4 }).reason, 'pending-provider-id');
    const racedResult = await statusRace.submit({ ...base, providerId: 'whatsapp-cloud-api', idempotencyKey: 'cloud-status-race' }, { dispatch: async () => ({ messageId: 'cloud-race-id', __chatBotAck: { status: 'accepted', id: 'cloud-race-id' } }) });
    assert.equal(racedResult.__chatBotOutbox.status, 'read');

    const uncertainNetwork = make();
    await assert.rejects(() => uncertainNetwork.submit({ ...base, idempotencyKey: 'network-timeout' }, { dispatch: async () => { throw Object.assign(new Error('socket hang up'), { code: 'ECONNRESET', retryable: true }); } }), error => error.code === 'SEND_UNCERTAIN');
    assert.equal(uncertainNetwork.list('main').find(row => row.idempotencyKey === 'network-timeout').status, 'uncertain');

    // FIFO per conversation; a different conversation may progress concurrently.
    const fifo = make();
    const order = [];
    let unblock;
    const block = new Promise(resolve => { unblock = resolve; });
    const one = fifo.submit({ ...base, idempotencyKey: 'fifo-1' }, { dispatch: async () => { order.push('one-start'); await block; order.push('one-end'); return ok('fifo-1'); } });
    const two = fifo.submit({ ...base, idempotencyKey: 'fifo-2' }, { dispatch: async () => { order.push('two'); return ok('fifo-2'); } });
    const other = fifo.submit({ ...base, conversationId: '99999@c.us', target: '99999@c.us', idempotencyKey: 'fifo-other' }, { dispatch: async () => { order.push('other'); return ok('fifo-other'); } });
    await wait(30);
    assert.ok(order.includes('other'));
    assert.ok(!order.includes('two'));
    unblock();
    await Promise.all([one, two, other]);
    assert.ok(order.indexOf('one-end') < order.indexOf('two'));

    // Slow media hashing must not let a later text intent overtake it.
    const ordered = make();
    const largeFile = path.join(sessionRoot, 'ordered.bin');
    fs.writeFileSync(largeFile, Buffer.alloc(8 * 1024 * 1024, 7));
    const orderedCalls = [];
    const mediaFirst = ordered.submit({ ...base, kind: 'media', idempotencyKey: 'ordered-media', payload: { filePath: largeFile } }, { dispatch: async () => { orderedCalls.push('media'); return ok('ordered-media-id'); } });
    const textSecond = ordered.submit({ ...base, idempotencyKey: 'ordered-text', payload: { text: 'second' } }, { dispatch: async () => { orderedCalls.push('text'); return ok('ordered-text-id'); } });
    await Promise.all([mediaFirst, textSecond]);
    assert.deepEqual(orderedCalls, ['media', 'text']);

    // Queued work can be cancelled before the provider call starts.
    const cancelOutbox = make();
    let unlock;
    const hold = new Promise(resolve => { unlock = resolve; });
    const holdSend = cancelOutbox.submit({ ...base, idempotencyKey: 'hold' }, { dispatch: () => hold });
    await wait(20);
    const queuedPromise = cancelOutbox.submit({ ...base, idempotencyKey: 'cancel-me' }, { dispatch: async () => { throw new Error('cancelled record must not dispatch'); } });
    await wait(10);
    const queuedRecord = cancelOutbox.list('main').find(row => row.idempotencyKey === 'cancel-me');
    assert.equal(cancelOutbox.cancel('main', queuedRecord.id).ok, true);
    unlock(ok('hold-id'));
    await Promise.all([holdSend, queuedPromise]);
    assert.equal(cancelOutbox.get('main', queuedRecord.id).status, 'cancelled');

    // File payload is hashed at enqueue and rechecked before dispatch.
    const mediaFile = path.join(sessionRoot, 'media.bin');
    fs.writeFileSync(mediaFile, Buffer.from('original-media'));
    const mediaOutbox = make();
    let mediaCalls = 0;
    const blocker = mediaOutbox.submit({ ...base, idempotencyKey: 'media-blocker' }, { dispatch: async () => { await wait(40); return ok('blocker-id'); } });
    const mediaPromise = mediaOutbox.submit({ ...base, kind: 'media', idempotencyKey: 'media-hash', payload: { filePath: mediaFile } }, { dispatch: async () => { mediaCalls++; return ok('media-id'); } });
    await wait(10);
    fs.writeFileSync(mediaFile, Buffer.from('changed-media'));
    await blocker;
    await assert.rejects(() => mediaPromise, error => error.code === 'OUTBOX_FILE_CHANGED');
    assert.equal(mediaCalls, 0);

    console.log('phase4-outbound-outbox: ok (durability, idempotency, ACK reconciliation, crash uncertainty, manual retry, 429 retry, FIFO, cancel, file integrity)');
  } finally {
    fs.rmSync(temp, { recursive: true, force: true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
