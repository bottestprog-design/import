'use strict';
const assert = require('node:assert/strict');
const trigger = require('../src/trigger-engine');
const replies = require('../src/reply-engine');
const priority = require('../src/command-priority');
const antiConflict = require('../src/anti-conflict');
const { InteractionEngine } = require('../src/interaction');

function makeSession(overrides = {}) {
  return {
    id: 'advanced-test', name: 'Advanced test', timezone: 'Asia/Muscat',
    settings: { timezone: 'Asia/Muscat', interactionEnabled: true, interactionIgnoreOwn: true, interactionScope: 'all', interactionChatIds: [], interactionQuietEnabled: false, interactionQuietAction: 'silence', maxActionsPerMinute: 100, interactionCooldownCapSec: 86400, interactionConflictMode: 'first-match', interactionSimilarityThreshold: .68, ...overrides.settings },
    recipients: [{ id: 'test-contact', name: 'Test', chatId: 'test@c.us', enabled: true, interactionEnabled: true }],
    groups: [],
    interaction: { enabled: true, rules: [], counterTriggers: [], counterState: { totalCount: 0, byChat: {}, fired: {}, pending: {} }, variantState: {}, contextByChat: {}, recent: [] },
    stats: { interactionActions: 0, interactionErrors: 0 },
  };
}
function message(id, body, chatId = 'test@c.us') {
  return { fromMe: false, body, notifyName: 'سارة أحمد', id: { _serialized: id, remote: { _serialized: chatId } }, from: chatId, to: chatId, getChat: async () => ({ id: { _serialized: chatId }, name: 'Test chat' }) };
}
function rig(session) {
  const sent = [];
  const store = { loadSession: () => session, saveSession: value => Object.assign(session, value) };
  const whatsapp = { replyToMessage: async (id, msg, text) => { sent.push({ text, chatId: msg.id.remote._serialized }); return { __chatBotAck: { status: 'created' } }; }, sendText: async (id, chatId, text) => { sent.push({ text, chatId }); return { __chatBotAck: { status: 'created' } }; }, reactToMessage: async () => ({}) };
  return { engine: new InteractionEngine({ store, whatsapp, log: () => {} }), session, sent };
}

(async () => {
  const samples = [
    [{ when: { type: 'message', match: 'contains', value: 'مرحبا' } }, 'message', 'أهلًا مرحبا بك', true],
    [{ when: { type: 'message', match: 'starts', value: 'السلام' } }, 'message', 'السلام عليكم', true],
    [{ when: { type: 'message', match: 'ends', value: 'بخير' } }, 'message', 'أنا بخير', true],
    [{ when: { type: 'message', match: 'exact', value: 'مرحبا' } }, 'message', 'مرحبا بك', false],
    [{ when: { type: 'message', match: 'regex', value: '^سعر\\s+\u0645\u0646\u062a\u062c' } }, 'message', 'سعر منتج', true],
    [{ when: { type: 'message', match: 'intent', value: 'greeting' } }, 'message', 'السلام عليكم ورحمة الله', true],
  ];
  for (const [rule, event, text, expected] of samples) assert.equal(trigger.matchTrigger(rule, event, text).matched, expected);
  assert.equal(trigger.inferIntent('السلام عليكم ورحمة الله'), 'greeting');
  assert.equal(trigger.inferIntent('كم السعر؟'), 'price');
  assert.equal(trigger.inferIntent('شكرا لك'), 'thanks');
  assert.ok(trigger.similarityScore('مراحبا', 'مرحبا') >= .68, 'similarity should tolerate a common misspelling');
  assert.equal(trigger.matchTrigger({ when: { type: 'message', match: 'similarity', value: 'مرحبا', threshold: .68 } }, 'message', 'ممكن مراحبا').matched, true);
  assert.throws(() => trigger.validateTrigger({ when: { type: 'message', match: 'regex', value: '[' } }), /Invalid regular expression|unterminated|unterminated character class/i);
  assert.throws(() => trigger.validateTrigger({ when: { type: 'message', match: 'regex', value: '(a+)+$' } }), /مكلفًا/);
  assert.equal(trigger.matchTrigger({ when: { type: 'message', match: 'regex', value: '(a+)+$' } }, 'message', 'aaaaab').matched, false, 'unsafe regex must be rejected even in a test request');

  const state = {};
  const item = { id: 'welcome', then: { reply: 'أهلًا', replies: ['أهلًا', 'مرحبًا', 'نورت'] } };
  const output = Array.from({ length: 3 }, () => replies.pickReply(item, state, 'welcome|chat'));
  assert.equal(new Set(output).size, 3, 'all variants should be used before the next shuffle bag');
  const rendered = replies.renderTemplate('أهلًا {{firstName}}: {{message}} · {{intent}} · {{count}}', { sender: 'سارة أحمد', message: 'مرحبا', intent: 'greeting', count: 15 });
  assert.equal(rendered, 'أهلًا سارة: مرحبا · greeting · 15');

  const command = { kind: 'rule', order: 3, priority: 0, rule: { when: { type: 'message', value: '!help', match: 'exact' }, priority: 0 } };
  const normalHigh = { kind: 'rule', order: 0, priority: 1000, rule: { when: { type: 'message', value: 'help', match: 'contains' }, priority: 1000 } };
  assert.equal(priority.rankCandidates([normalHigh, command], 'first-match')[0], command, 'commands should beat non-command rules');
  const ordered = antiConflict.resolveCandidates([normalHigh, { ...normalHigh, order: 1, rule: { ...normalHigh.rule, id: 'second' } }], 'first-match');
  assert.equal(ordered.length, 2, 'single-action mode preserves fallback candidates when the first action fails');
  assert.equal(antiConflict.resolveCandidates([{ ...normalHigh, item: { then: { reply: 'one' } } }, { ...normalHigh, order: 1, item: { then: { reply: 'two' } } }], 'allow-multiple').length, 1, 'same action type conflict is deduplicated');
  assert.equal(antiConflict.resolveCandidates([{ ...normalHigh, item: { then: { reply: 'one', reaction: '👍' } } }, { ...normalHigh, order: 1, item: { then: { reply: 'two' } } }], 'allow-multiple').length, 1, 'a combined action conflicts with later replies');
  assert.equal(antiConflict.resolveCandidates([{ ...normalHigh, item: { then: { reply: 'one' } } }, { ...normalHigh, order: 1, item: { actionType: 'log' } }], 'allow-multiple').length, 2, 'independent log and reply channels can coexist');

  const session = makeSession();
  session.interaction.counterTriggers.push({ id: 'counter-two', name: 'عند رسالتين', enabled: true, threshold: 2, priority: 10, scope: 'session', actionType: 'reply', then: { reply: 'وصلنا {{count}}', replies: ['وصلنا {{count}}'] }, armedAtCount: 0 });
  const counterRig = rig(session);
  await counterRig.engine.onMessage(session.id, message('counter-1', 'رسالة أولى'));
  assert.equal(counterRig.sent.length, 0, 'counter should not run before its threshold');
  const fired = await counterRig.engine.onMessage(session.id, message('counter-2', 'رسالة ثانية'));
  assert.equal(counterRig.sent.length, 1);
  assert.equal(counterRig.sent[0].text, 'وصلنا 2');
  assert.equal(fired.action, 'counter');
  assert.equal(session.stats.interactionActions, 1, 'successful counter actions should persist statistics');
  await counterRig.engine.onMessage(session.id, message('counter-3', 'رسالة ثالثة'));
  assert.equal(counterRig.sent.length, 1, 'counter should fire only once per threshold');

  const prioritized = makeSession({ settings: { interactionConflictMode: 'first-match' } });
  prioritized.interaction.rules.push({ id: 'ordinary', name: 'قاعدة عامة', enabled: true, priority: 100, cooldownSec: 0, when: { type: 'message', match: 'contains', value: 'help' }, then: { reply: 'ordinary reply', replies: ['ordinary reply'], stopAfter: true }, scope: 'all' });
  prioritized.interaction.rules.push({ id: 'command', name: 'أمر', enabled: true, priority: -100, commandPriority: true, cooldownSec: 0, when: { type: 'message', match: 'exact', value: '!help' }, then: { reply: 'command reply', replies: ['command reply'], stopAfter: true }, scope: 'all' });
  const priorityRig = rig(prioritized);
  await priorityRig.engine.onMessage(prioritized.id, message('priority-1', '!help'));
  assert.equal(priorityRig.sent.length, 1);
  assert.equal(priorityRig.sent[0].text, 'command reply', 'command rule should take precedence over general reply rules');

  console.log('advanced-reply-engine: ok (trigger modes, intent, similarity, variants, templates, command priority, conflict fallback, counter threshold)');
})().catch(error => { console.error(error); process.exitCode = 1; });
