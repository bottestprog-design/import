'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const pkg = JSON.parse(read('package.json'));
const lock = JSON.parse(read('package-lock.json'));
const version = pkg.version;

assert.equal(version, '9.20.32', 'phase-four Outbox release must publish a new integrated version');
assert.equal(lock.version, version);
assert.equal(lock.packages[''].version, version);
assert.equal(read('src/store.js').includes(`const APP_VERSION = '${version}'`), true);
assert.equal(read('public/app.js').includes(`version: 'v${version}'`), true);
assert.equal(read('RELEASES_AR.md').startsWith(`## v${version}`), true);
assert.equal(read('README.md').startsWith(`# chat BOT v${version}`), true);
assert.equal(lock.packages[''].name, pkg.name);
for (const [name, pinned] of Object.entries(pkg.dependencies)) assert.equal(lock.packages[''].dependencies[name], pinned, `lock file must pin ${name}`);

// Confirm the final bundle retains all four ordered work phases.
for (const token of ['v9.16.5', 'v9.16.6', 'v9.16.7', 'v9.16.8']) assert.ok(read('RELEASES_AR.md').includes(token), `historical phase ${token} must be retained`);
for (const file of [
  'test/owner-scope-and-restore.js',
  'test/voice-reply-delivery.js', 'test/tts-delivery-segments.js', 'test/phase5-speech-quality.js',
  'test/tts-privacy-defaults.js',
  'test/cloud-voice-adapters.js',
  'test/phase3-media-workflow.js',
  'test/transcript-quality.js', 'test/voice-worker-quality.js', 'test/voice-worker-quality.py',
  'test/transcription-settings.js', 'test/phase4-voice-quality.js',
  'test/python-voice-adapters.js', 'test/faster-whisper-pyav-compat.js', 'src/transcript-quality.js', 'src/voice-transcript-guard.js',
  'test/phase4-contact-recovery.js',
  'test/command-engine.js',
  'test/automation-engine.js',
  'test/media-serving-security.js',
  'test/local-backup.js',
  'test/conversation-archive.js',
  'test/remote-access.js',
  'test/operational-diagnostics.js',
  'test/faster-whisper-pyav-compat.js',
  'test/connection-method-contract.js',
  'src/operational-diagnostics.js',
  'CHANGELOG_V9_20_14_PHASE4_AR.md', 'CHANGELOG_V9_20_13_PHASE3_AR.md', 'CHANGELOG_V9_20_12_PHASE2_AR.md',
  'PHASE2_REVIEW_AR.md',
  'PHASE2_VERIFICATION_AR.md',
  'test/phase2-conversation-authorization.js',
  'CHANGELOG_V9_20_11_PHASE1_AR.md',
  'CHANGELOG_V9_20_7_PHASE7_AR.md',
]) assert.equal(fs.existsSync(path.join(root, file)), true, `required regression suite missing: ${file}`);

assert.match(read('scripts/verify.js'), /Test files: \$\{passed\} passed, \$\{skipped\} skipped, \$\{failed\} failed/);
assert.match(read('scripts/verify.js'), /STRICT && skipped/);
assert.equal(fs.existsSync(path.join(root, 'CHANGELOG_V9_20_5_PHASE5_AR.md')), true, 'phase-five changelog must remain included');
assert.match(read('.gitignore'), /node_modules\//);
assert.match(read('.gitignore'), /data\//);
assert.match(read('.gitignore'), /\.env/);
assert.match(read('.gitignore'), /__pycache__\//);
assert.equal(fs.existsSync(path.join(root, '.env')), false, 'private environment file must never be in the source project');
console.log('release-gate: ok (ordered phases, release identity, dependency lock consistency, security/recovery/voice regression suites and local-data exclusions)');
