'use strict';
const assert = require('node:assert/strict');
const { InteractionEngine } = require('../src/interaction');
const { matchTrigger } = require('../src/trigger-engine');
function makeSession(chat = {}) {
  return {
    id: 'local-session', name: 'Test', settings: {
      timezone: 'Asia/Muscat', interactionEnabled: true, interactionIgnoreOwn: true,
      interactionScope: 'all', interactionChatIds: [], interactionQuietEnabled: false,
      interactionFallbackEnabled: true, interactionFallbackInGroups: false, interactionFallbackCooldownSec: 45,
      interactionSmartMatching: true, interactionSmartThreshold: .78, smartReplyEnabled: false,
      maxActionsPerMinute: 30, ...chat,
    },
    interaction: { enabled: true, rules: [], recent: [], contextByChat: {}, counterState: {}, variantState: {} },
    automation: { tasks: [], rules: [] }, recipients: [{ id: 'contact', chatId: 'contact@c.us', enabled: true, interactionEnabled: true }], groups: [{ id: 'group', gid: '120000@g.us', enabled: true, interactionEnabled: true }], logs: [], stats: { interactionActions: 0, interactionErrors: 0 },
  };
}
function message(id, body, chatId = 'contact@c.us') {
  return { body, from: chatId, to: 'bot@c.us', fromMe: false, notifyName: 'عميل', id: { _serialized: id, remote: { _serialized: chatId } }, getChat: async () => ({ id: { _serialized: chatId }, name: 'محادثة' }) };
}
function rig(session, localLlm = null, selfChatId = '') {
  const sent = [];
  const store = { loadSession: () => session, saveSession: x => Object.assign(session, x) };
  const whatsapp = { selfChatId: () => selfChatId, replyToMessage: async (_id, msg, text) => { sent.push({ chatId: msg.id.remote._serialized, text }); return { __chatBotAck: { status: 'created' } }; }, reactToMessage: async () => ({}) };
  const engine = new InteractionEngine({ store, whatsapp, log: () => {}, localLlm });
  return { engine, sent, session };
}
(async () => {
  const near = matchTrigger({ when: { type: 'message', match: 'contains', value: 'مرحبا' } }, 'message', 'مرهبا بك', '', { smartContains: true, smartThreshold: .72 });
  assert.equal(near.matched, true, 'typo-tolerant Arabic matching should pass a permissive configured threshold');
  const exactOnly = matchTrigger({ when: { type: 'message', match: 'contains', value: 'مرحبا' } }, 'message', 'مرهبا بك', '', { smartContains: false, smartThreshold: .72 });
  assert.equal(exactOnly.matched, false, 'smart matching switch should actually disable fuzzy matching');

  const s = makeSession(); const local = rig(s);
  const result = await local.engine.onMessage(s.id, message('m1', 'كم السعر؟'));
  assert.equal(result.handled, false);
  assert.equal(result.reason, 'no-rule-matched');
  assert.equal(local.sent.length, 0, 'an explicitly granted contact still cannot use the owner smart fallback');

  const group = makeSession(); const groupRig = rig(group);
  const groupResult = await groupRig.engine.onMessage(group.id, message('g1', 'السلام عليكم', '120000@g.us'));
  assert.equal(groupResult.reason, 'no-rule-matched');
  assert.equal(groupRig.sent.length, 0, 'group fallback is opt-in and owner-only, preventing noisy replies');

  const smart = makeSession({ smartReplyEnabled: true, smartReplyModel: 'tiny-local', smartReplySystemPrompt: 'أجب بالعربية', smartReplyTimeoutMs: 2500 });
  const modelCalls = []; const llm = { generate: async args => { modelCalls.push(args); return 'رد من النموذج المحلي'; } };
  const ownerId = 'owner@c.us';
  const ownerMessage = (id, body) => message(id, body, ownerId);
  const smartRig = rig(smart, llm, ownerId);
  const one = await smartRig.engine.onMessage(smart.id, ownerMessage('s1', 'سؤال محادثة غير مصنف عن المشكلة'));
  assert.equal(one.source, 'ollama-local'); assert.equal(smartRig.sent[0].text, 'رد من النموذج المحلي');
  const two = await smartRig.engine.onMessage(smart.id, ownerMessage('s2', 'متابعة السؤال نفسه'));
  assert.equal(two.reason, 'smart-fallback-cooldown');
  assert.equal(modelCalls.length, 1);
  assert.match(modelCalls[0].system, /أجب بالعربية/);
  console.log('interaction-smart-reply: ok (fuzzy switch, owner-only safe fallback, private cooldown, group opt-in and optional local model)');
})().catch(error => { console.error(error); process.exitCode = 1; });
