'use strict';
const assert = require('node:assert/strict');
const { InboundMessageQueue } = require('../src/inbound-message-queue');

(async () => {
  const queue = new InboundMessageQueue({ maxConcurrentConversations: 2, maxPendingPerSession: 10 });
  let releaseSlow;
  const slowGate = new Promise(resolve => { releaseSlow = resolve; });
  const order = [];
  let slowStartedResolve;
  const slowStarted = new Promise(resolve => { slowStartedResolve = resolve; });
  const first = queue.enqueue('s1', 'a1', async () => { order.push('a1-start'); slowStartedResolve(); await slowGate; order.push('a1-end'); }, { conversationId: 'a' });
  await slowStarted;
  const second = queue.enqueue('s1', 'a2', async () => { order.push('a2'); }, { conversationId: 'a' });
  const other = queue.enqueue('s1', 'b1', async () => { order.push('b1'); }, { conversationId: 'b' });
  await other;
  assert.deepEqual(order, ['a1-start', 'b1'], 'a slow conversation must not block another conversation');
  releaseSlow();
  await Promise.all([first, second]);
  assert.deepEqual(order, ['a1-start', 'b1', 'a1-end', 'a2'], 'FIFO is retained within the same conversation');
  const result = await queue.close({ drain: true, timeoutMs: 1000 });
  assert.equal(result.drained, true);
  console.log('phase3-conversation-queue: ok (per-conversation FIFO, cross-conversation parallelism, graceful drain)');
})().catch(error => { console.error(error); process.exitCode = 1; });
