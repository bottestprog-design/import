@echo off
setlocal
cd /d "%~dp0"
title DUAL Audit Lab v2.14 - Model diagnostics
echo Build expected: v2.14
echo Running checker from: %CD%
echo If the Python output does not show Build version 2.14, stop: this is not the updated package.
where py >nul 2>nul
if not errorlevel 1 (
  py -3 check_model_setup.py
) else (
  python check_model_setup.py
)
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo MODEL SETUP FAILED. Read each individual diagnostic check above.
if "%RESULT%"=="0" echo MODEL SETUP PASSED. This confirms connectivity, not model accuracy.
pause
exit /b %RESULT%
