from __future__ import annotations

import hashlib
import sys
from pathlib import Path

SOURCE_REVISION = "76ad17f2fe3f23190f39e256c1add514fa8c8762"
SOURCE_URL = "https://huggingface.co/mattjoyce/antares-1b-GGUF"
EXPECTED_SHA256 = "e51582e2c4b1f796aff3a8318b372bd46e2efab0fb4b31a6d01f53f05dd71687"
EXPECTED_SIZE_BYTES = 1_139_251_360
DEFAULT_FILE = Path(__file__).resolve().parent / "models" / "verified" / "antares-1b-Q4_K_M-imat.gguf"
CHUNK_SIZE = 8 * 1024 * 1024


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(CHUNK_SIZE), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    if len(sys.argv) > 2:
        print("Usage: py -3 verify_ant_model.py [path-to-gguf]")
        return 2
    file_path = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv) == 2 else DEFAULT_FILE
    if not file_path.is_file():
        print(f"File missing: {file_path}")
        return 2
    size = file_path.stat().st_size
    print("File:    ", file_path)
    print("Size:    ", f"{size:,} bytes ({size / (1024 ** 3):.3f} GiB)")
    print("Expected size:", f"{EXPECTED_SIZE_BYTES:,} bytes")
    actual = sha256_file(file_path)
    print("Source:  ", f"{SOURCE_URL} @ {SOURCE_REVISION}")
    print("Expected SHA-256:", EXPECTED_SHA256)
    print("Actual SHA-256:  ", actual)
    size_ok = size == EXPECTED_SIZE_BYTES
    hash_ok = actual == EXPECTED_SHA256
    if not size_ok:
        print("Size mismatch. Do NOT import or load this file.")
    if not hash_ok:
        print("SHA-256 mismatch. Do NOT import or load this file.")
    if not size_ok:
        return 4
    if not hash_ok:
        return 3
    print("SHA-256 verified. File bytes match the published Q4_K_M-imat artifact.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
