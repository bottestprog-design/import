@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title DUAL Audit Lab v2.14 - Install verified Antares

set "MODEL=models\verified\antares-1b-Q4_K_M-imat.gguf"
set "PART=models\verified\antares-1b-Q4_K_M-imat.gguf.part"
set "REJECTED=models\verified\antares-1b-Q4_K_M-imat.rejected-%RANDOM%.gguf"
set "URL=https://huggingface.co/mattjoyce/antares-1b-GGUF/resolve/76ad17f2fe3f23190f39e256c1add514fa8c8762/antares-1b-Q4_K_M-imat.gguf"
set "OLLAMA_TAG=antares-1b-raw-e51582e2-v214"

echo ======================================================
echo   DUAL Audit Lab v2.14 - Verified Antares 1.8B localizer
echo ======================================================
echo Expected size: 1,139,251,360 bytes
echo Expected SHA-256: e51582e2c4b1f796aff3a8318b372bd46e2efab0fb4b31a6d01f53f05dd71687
echo Existing legacy tags are preserved and are NOT reused.
echo.
where ollama >nul 2>nul
if errorlevel 1 (
  echo ERROR: Ollama was not found in PATH.
  echo Install: https://ollama.com/download/windows
  pause
  exit /b 2
)
where curl.exe >nul 2>nul
if errorlevel 1 (
  echo ERROR: curl.exe was not found.
  pause
  exit /b 3
)
where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python Launcher (py) was not found. Python 3.11+ is required.
  pause
  exit /b 4
)

if not exist "models\verified" mkdir "models\verified"

if exist "%MODEL%" (
  echo Checking existing local GGUF before any import...
  call :verify "%MODEL%"
  if errorlevel 1 (
    echo Existing GGUF failed size or SHA-256. It will NOT be imported.
    echo Preserving the rejected file for inspection: %REJECTED%
    move /y "%MODEL%" "%REJECTED%" >nul
    if errorlevel 1 (
      echo ERROR: Could not move the mismatched file safely.
      pause
      exit /b 5
    )
  ) else (
    echo Existing GGUF is verified.
    goto :create_model
  )
)

if exist "%PART%" del /q "%PART%" >nul 2>nul
echo Downloading a fresh complete file. This deliberately does NOT resume an old partial download.
echo Source revision: 76ad17f2fe3f23190f39e256c1add514fa8c8762
echo Downloading to a temporary .part file; no partial file is resumed.
curl.exe -L --fail --retry 5 --retry-delay 4 --connect-timeout 45 --max-time 7200 --output "%PART%" "%URL%"
if errorlevel 1 (
  echo ERROR: Download failed. The partial file was not imported.
  if exist "%PART%" echo Partial file left at %PART% for inspection; a retry will discard it and download from zero.
  pause
  exit /b 6
)

echo.
echo Verifying exact byte count and SHA-256 before replacing the model file...
call :verify "%PART%"
if errorlevel 1 (
  echo ERROR: Verification failed. The downloaded file will NOT be imported.
echo Keep the printed actual size and SHA-256 in your support report; never edit the expected hash.
  move /y "%PART%" "%REJECTED%" >nul
  echo Rejected download preserved at %REJECTED%
  pause
  exit /b 7
)
move /y "%PART%" "%MODEL%" >nul
if errorlevel 1 (
  echo ERROR: Could not place the verified GGUF file.
  pause
  exit /b 8
)

:create_model
echo.
echo Rebuilding the DUAL-specific model tag from the verified GGUF...
rem This is a fresh versioned tag. Never delete older tags or models before the new one is created.
ollama create %OLLAMA_TAG% -f Modelfile_Antares
if errorlevel 1 (
  echo ERROR: Ollama could not import the verified GGUF.
  echo The verified source file remains at %MODEL%
  pause
  exit /b 9
)
ollama show %OLLAMA_TAG% >nul 2>nul
if errorlevel 1 (
  echo ERROR: Ollama did not register the new tag after creation.
  echo The verified source file remains at %MODEL%. Do not start an audit.
  pause
  exit /b 11
)
py -3 set_auditor_model.py
if errorlevel 1 (
  echo ERROR: The model was created but config.json could not be updated.
  echo Run py -3 set_auditor_model.py after fixing the config file.
  pause
  exit /b 10
)
echo.
echo Verified Antares model installed as %OLLAMA_TAG%.
echo Next: run check_model_setup.bat. The diagnostic must pass before scanning.
pause
exit /b 0

:verify
py -3 verify_ant_model.py "%~1"
exit /b %errorlevel%
