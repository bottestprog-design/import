from __future__ import annotations

import html.parser
import re
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INDEX = ROOT / "index.html"


class IdParser(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if values.get("id"):
            self.ids.append(values["id"])


class UiSourceTests(unittest.TestCase):
    def setUp(self):
        self.html = INDEX.read_text(encoding="utf-8")

    def test_html_ids_are_unique(self):
        parser = IdParser()
        parser.feed(self.html)
        duplicates = sorted({item for item in parser.ids if parser.ids.count(item) > 1})
        self.assertEqual(duplicates, [])

    def test_simple_getelementbyid_references_exist(self):
        parser = IdParser()
        parser.feed(self.html)
        present = set(parser.ids)
        refs = set(re.findall(r"\$\(['\"]([A-Za-z][A-Za-z0-9_-]*)['\"]\)", self.html))
        self.assertEqual(sorted(refs - present), [])

    @unittest.skipUnless(shutil.which("node"), "Node.js is not installed in the test environment")
    def test_embedded_javascript_syntax(self):
        scripts = re.findall(r"<script>([\s\S]*?)</script>", self.html, re.I)
        self.assertTrue(scripts)
        with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8", delete=False) as stream:
            stream.write(scripts[-1])
            path = Path(stream.name)
        try:
            result = subprocess.run([shutil.which("node"), "--check", str(path)], capture_output=True, text=True, timeout=20)
            self.assertEqual(result.returncode, 0, result.stderr or result.stdout)
        finally:
            path.unlink(missing_ok=True)

    @unittest.skipUnless(shutil.which("node"), "Node.js is not installed in the test environment")
    def test_model_status_renderer_executes_without_temporal_reference_errors(self):
        start = self.html.index("function setModelDetails(data) {")
        end = self.html.index("\nasync function refreshStatus()", start)
        renderer = self.html[start:end]
        harness = (
            'const nodes=new Map();\n'
            'function $(id){if(!nodes.has(id))nodes.set(id,{textContent:"",className:"",style:{}});return nodes.get(id)}\n'
            'function setTag(id,text,kind){const n=$(id);n.textContent=text;n.className="state-tag"+(kind?" "+kind:"")}\n'
            + renderer + '\n'
            'setModelDetails({ollama:{online:true,version:"0.40.11",coder_installed:true,auditor_installed:true,coder_active_model:"qwen2.5-coder:1.5b",auditor_model:"antares-1b-raw-e51582e2-v214",loaded_models:[]},model_tests:{coder_test:{ok:true},auditor_test:{ok:true}},model_tests_current:true});\n'
            'if($("coderState").textContent!=="اختبار الاستدلال ناجح")throw Error("coder status wrong");\n'
            'if($("auditorState").textContent!=="اختبار الأداة ناجح")throw Error("auditor status wrong");\n'
            'setModelDetails({ollama:{online:true,version:"0.40.11",coder_installed:true,auditor_installed:true,coder_active_model:"qwen2.5-coder:1.5b",loaded_models:[]},model_tests:{coder_test:{ok:true},auditor_test:{ok:false,message:"parser gate failed",checks:{transport:true,tool_call_parsed:false,terminal_safe:false,terminal_executed:false}}},model_tests_current:true});\n'
            'if(!$("auditorDetail").textContent.includes("النقل ✓"))throw Error("auditor gate detail missing");\n'
            'if(!$("auditorDetail").textContent.includes("تحليل الأداة —"))throw Error("auditor parser gate missing");\n'
            'console.log("UI renderer PASS");\n'
        )
        with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8", delete=False) as stream:
            stream.write(harness)
            path = Path(stream.name)
        try:
            result = subprocess.run([shutil.which("node"), str(path)], capture_output=True, text=True, timeout=20)
            self.assertEqual(result.returncode, 0, result.stderr or result.stdout)
            self.assertIn("UI renderer PASS", result.stdout)
        finally:
            path.unlink(missing_ok=True)


if __name__ == "__main__":
    unittest.main(verbosity=2)
