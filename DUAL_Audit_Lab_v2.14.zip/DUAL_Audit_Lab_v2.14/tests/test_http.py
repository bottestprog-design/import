from __future__ import annotations

import http.client
import json
import threading
import unittest
from http.server import ThreadingHTTPServer
from unittest.mock import patch

import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import server


class LocalHttpSmokeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.old_port = server.CONFIG["bind_port"]
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        cls.port = cls.httpd.server_address[1]
        server.CONFIG["bind_port"] = cls.port
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.thread.join(timeout=2)
        server.CONFIG["bind_port"] = cls.old_port

    def request(self, method, path, *, body=None, headers=None):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        conn.request(method, path, body=body, headers=headers or {})
        response = conn.getresponse()
        data = response.read()
        status, response_headers = response.status, dict(response.getheaders())
        conn.close()
        return status, response_headers, data

    def test_home_serves_local_html_with_security_headers(self):
        status, headers, body = self.request("GET", "/")
        self.assertEqual(status, 200)
        self.assertIn(b"DUAL", body)
        self.assertIn("Content-Security-Policy", headers)
        self.assertEqual(headers.get("X-Frame-Options"), "DENY")

    def test_status_endpoint_returns_json(self):
        with patch.object(server, "ollama_status", return_value={"online": False, "models": []}):
            status, headers, body = self.request("GET", "/api/status")
        self.assertEqual(status, 200)
        self.assertIn("application/json", headers.get("Content-Type", ""))
        self.assertFalse(json.loads(body)["ollama"]["online"])

    def test_unknown_get_route_is_404(self):
        status, _, _ = self.request("GET", "/api/not-real")
        self.assertEqual(status, 404)

    def test_untrusted_host_is_rejected(self):
        status, _, _ = self.request("GET", "/api/status", headers={"Host": "attacker.example"})
        self.assertEqual(status, 403)

    def test_untrusted_origin_is_rejected(self):
        status, _, _ = self.request("GET", "/api/status", headers={"Origin": "https://attacker.example"})
        self.assertEqual(status, 403)

    def test_invalid_json_post_is_400(self):
        status, _, _ = self.request("POST", "/api/start", body=b"{bad", headers={"Content-Type": "application/json"})
        self.assertEqual(status, 400)

    def test_unknown_post_route_is_404(self):
        status, _, _ = self.request("POST", "/api/nope", body=b"{}", headers={"Content-Type": "application/json"})
        self.assertEqual(status, 404)


    def test_model_test_endpoint_refuses_running_job(self):
        old_job = server.JOB
        server.JOB = {"running": True, "status": "running"}
        try:
            with patch.object(server, "refresh_active_coder_model") as refresh, \
                 patch.object(server, "ollama_status") as ollama_status, \
                 patch.object(server, "test_coder") as test_coder:
                status, _, response = self.request(
                    "POST", "/api/test-models", body=b"{}",
                    headers={"Content-Type": "application/json"}
                )
            self.assertEqual(status, 400)
            self.assertIn("دورة فحص", json.loads(response)["error"])
            refresh.assert_called_once()
            ollama_status.assert_not_called()
            test_coder.assert_not_called()
        finally:
            server.JOB = old_job

    def test_model_test_endpoint_refuses_busy_model_lock(self):
        acquired = server.MODEL_LOCK.acquire(blocking=False)
        self.assertTrue(acquired, "test requires a free model lock")
        try:
            with patch.object(server, "refresh_active_coder_model"), \
                 patch.object(server, "ollama_status") as ollama_status:
                status, _, response = self.request(
                    "POST", "/api/test-models", body=b"{}",
                    headers={"Content-Type": "application/json"}
                )
            self.assertEqual(status, 400)
            self.assertIn("تستخدم النماذج", json.loads(response)["error"])
            ollama_status.assert_not_called()
        finally:
            server.MODEL_LOCK.release()

    def test_start_requires_successful_model_tests(self):
        old_tests = dict(server.MODEL_TESTS)
        server.MODEL_TESTS.clear()
        try:
            with patch.object(server, "ollama_status", return_value={"online": True, "auditor_installed": True, "coder_installed": True}):
                body = json.dumps({"project": str(ROOT), "auto_fix": True}).encode()
                status, _, response = self.request("POST", "/api/start", body=body, headers={"Content-Type": "application/json"})
            self.assertEqual(status, 400)
            self.assertIn("اختبار النموذجين", json.loads(response)["error"])
        finally:
            server.MODEL_TESTS.clear()
            server.MODEL_TESTS.update(old_tests)

    def test_report_download_formats(self):
        import tempfile
        with tempfile.TemporaryDirectory() as temp:
            old_dir = server.REPORTS_DIR
            server.REPORTS_DIR = Path(temp)
            report_id = "abc123def456"
            try:
                (Path(temp) / f"{report_id}.json").write_text('{"ok":true}', encoding="utf-8")
                (Path(temp) / f"{report_id}.md").write_text("# report", encoding="utf-8")
                (Path(temp) / f"{report_id}.sarif.json").write_text('{"version":"2.1.0"}', encoding="utf-8")
                status, headers, body = self.request("GET", f"/api/report/{report_id}?format=markdown")
                self.assertEqual(status, 200)
                self.assertIn("text/markdown", headers.get("Content-Type", ""))
                self.assertIn(b"# report", body)
                status, headers, body = self.request("GET", f"/api/report/{report_id}?format=sarif")
                self.assertEqual(status, 200)
                self.assertIn("application/sarif+json", headers.get("Content-Type", ""))
                self.assertIn(b"2.1.0", body)
            finally:
                server.REPORTS_DIR = old_dir

    def test_report_rejects_unknown_format(self):
        status, _, body = self.request("GET", "/api/report/abc123def456?format=exe")
        self.assertEqual(status, 400)
        self.assertIn("صيغة التقرير", json.loads(body)["error"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
