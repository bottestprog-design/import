# جرد الحزمة — DUAL Audit Lab v2.14

- `server.py` — الخادم المحلي وسير الفحص والمراجعة والإصلاح والتقارير.
- `index.html` — واجهة عربية RTL.
- `config.json` — الإعدادات ونماذج Ollama.
- `install_coder_light.bat` — تثبيت/اختيار Qwen2.5-Coder 1.5B.
- `install_coder.bat` — خيار Qwen2.5-Coder 3B (غير موصى به للجهاز المشخّص).
- `install_auditor.bat` — تنزيل Antares المثبت والتحقق من الملف وإنشاء tag جديد.
- `verify_ant_model.py` — التحقق من الحجم وSHA-256.
- `Modelfile_Antares` — قالب Granite الخام في Ollama.
- `set_coder_model.py`, `set_auditor_model.py` — تحديث config بأمان.
- `check_model_setup.py` و`check_model_setup.bat` — اختبارات استدلال حقيقية وبوابات بروتوكول Antares.
- `start.bat` — تشغيل واجهة الخادم المحلي.
- `run_tests.bat` و`tests/` — اختبارات المشروع الآلية.
- `agents/` — تعليمات المنسق والمبرمج والفاحص.
- `reports/`, `backups/`, `state/`, `models/` — مجلدات البيانات المحلية.
- ملفات `*_AR.md` — التقارير والدليل وسجل التنفيذ والقيود والخطوات التالية.
- `TEST_RESULTS.json` — نتائج الاختبار الآلي.
- `FILES_SHA256.txt` — بصمات ملفات الحزمة.

لا تحتوي الحزمة على أوزان النموذجين؛ تُنزّل عند تشغيل المثبتات.
