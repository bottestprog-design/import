@echo off
setlocal
cd /d "%~dp0"
title DUAL Audit Lab v2.14 - Install Qwen Coder 3B

echo ======================================================
echo   DUAL Audit Lab - Qwen2.5-Coder 3B (optional)
echo ======================================================
echo This download is about 1.9 GB. It may be slow on an 8 GB RAM CPU-only PC.
echo The 1.5B model is recommended for your diagnosed hardware.
echo.
choice /C YN /N /M "Continue with the larger 3B model? [Y/N] "
if errorlevel 2 exit /b 0
where ollama >nul 2>nul
if errorlevel 1 (
  echo ERROR: Ollama was not found in PATH.
  pause
  exit /b 2
)
ollama pull qwen2.5-coder:3b
if errorlevel 1 (
  echo ERROR: Ollama could not download qwen2.5-coder:3b.
  pause
  exit /b 3
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 set_coder_model.py qwen2.5-coder:3b
) else (
  python set_coder_model.py qwen2.5-coder:3b
)
if errorlevel 1 (
  echo ERROR: Could not update the active model in config.json.
  pause
  exit /b 4
)
echo.
echo Qwen2.5-Coder 3B installed and selected.
echo If the PC becomes slow, run install_coder_light.bat to switch back.
pause
exit /b 0
