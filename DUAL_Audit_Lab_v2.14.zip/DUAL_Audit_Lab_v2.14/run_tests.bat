@echo off
setlocal
cd /d "%~dp0"
title DUAL Audit Lab v2.14 - Test suite
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -m unittest discover -s tests -v
) else (
  python -m unittest discover -s tests -v
)
set "RESULT=%ERRORLEVEL%"
echo.
if "%RESULT%"=="0" echo All automated tests passed. This does NOT test model accuracy.
if not "%RESULT%"=="0" echo One or more tests failed. Review the output above.
pause
exit /b %RESULT%
