from __future__ import annotations
import json
import os
import tempfile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / "config.json"
ALLOWED = {"qwen2.5-coder:1.5b", "qwen2.5-coder:3b"}

def main() -> int:
    if len(sys.argv) != 2 or sys.argv[1] not in ALLOWED:
        print("Usage: py set_coder_model.py qwen2.5-coder:1.5b|qwen2.5-coder:3b")
        return 2
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("config.json must contain a JSON object")
        data["coder_model"] = sys.argv[1]
        encoded = (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
        fd, temp_name = tempfile.mkstemp(prefix="config.json.", suffix=".tmp", dir=str(ROOT))
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp_name, CONFIG)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)
    except Exception as exc:
        print(f"Could not update config.json safely: {exc}")
        return 3
    print(f"Active coder model set to: {sys.argv[1]}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
