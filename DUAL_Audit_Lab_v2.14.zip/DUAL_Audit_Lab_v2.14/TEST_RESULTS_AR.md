# نتائج الاختبارات — DUAL Audit Lab v2.14

**النتيجة:** 97/97 ناجحة في بيئة البناء.

| الفئة | ما تم فحصه | النتيجة |
|---|---|---:|
| سلامة المثبت | الهاش، الحجم، revision ثابت، منع الاستكمال، التحقق قبل الاستيراد | ناجح |
| مسارات وخصوصية | منع traversal، ملفات الأسرار، الروابط، تجاوز حدود القراءة | ناجح |
| بروتوكول Granite | serialization، escaping، JSON tool-call، وسم مفتوح/مقتطع | ناجح |
| تشخيص Antares | done=true والعدادات، parse، allowlist، terminal آمن وتنفيذه | ناجح (باستخدام mock للاستجابة) |
| تدفق الفحص | إيقاف المهمة، حدود الأدوات، الحالات، نتائج جزئية | ناجح |
| تطبيق التعديلات | بصمات baseline/latest، تعديلات متتابعة، restore، التغير الخارجي | ناجح |
| تقارير | JSON وMarkdown وSARIF وحالات review | ناجح |
| HTTP | local Host/Origin، المسارات، JSON، تنزيل التقارير | ناجح |
| UI | JavaScript syntax، IDs فريدة، renderer runtime | ناجح |

## أوامر الفحص التي أُجريت

```text
python -m unittest discover -s tests -v
python -m compileall -q server.py check_model_setup.py verify_ant_model.py set_coder_model.py set_auditor_model.py
node --check /tmp/dual-inline-v214.js
HTMLParser: 52 IDs, 0 duplicates
```

## ما لا تثبته النتيجة

- لا تثبت دقة النموذجين أو خلو نتائجها من الهلوسة.
- لا تثبت سرعة التشغيل على CPU المستخدم.
- لا تثبت تشغيل BAT أو Ollama والنماذج الحقيقية على Windows المستخدم.
- اختبار Antares في الوحدة يستخدم استجابة نموذجية محاكية، ويختبر parser والمفسر والبوابات المحيطة به.

شغّل `check_model_setup.bat` على جهازك بعد التثبيت للحصول على اختبار inference حقيقي.
