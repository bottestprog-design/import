from __future__ import annotations
import json, os, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / "config.json"
MODEL = "antares-1b-raw-e51582e2-v214"

def main() -> int:
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8"))
        if not isinstance(data, dict): raise ValueError("config.json must be a JSON object")
        data["auditor_model"] = MODEL
        encoded = (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
        fd, temp_name = tempfile.mkstemp(prefix="config.json.", suffix=".tmp", dir=str(ROOT))
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(encoded); stream.flush(); os.fsync(stream.fileno())
            os.replace(temp_name, CONFIG)
        finally:
            if os.path.exists(temp_name): os.unlink(temp_name)
        print(f"Active verified auditor model set to: {MODEL}")
        return 0
    except Exception as exc:
        print(f"Could not update config.json safely: {exc}")
        return 2

if __name__ == "__main__":
    raise SystemExit(main())
