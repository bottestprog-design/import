@echo off
setlocal
cd /d "%~dp0"
title DUAL Audit Lab v2.14 - Local server
echo DUAL Audit Lab build 2.14
echo Project directory: %CD%
where py >nul 2>nul
if not errorlevel 1 (
  py -3 server.py
) else (
  python server.py
)
if errorlevel 1 (
  echo.
  echo DUAL Audit Lab stopped with an error.
  pause
)
