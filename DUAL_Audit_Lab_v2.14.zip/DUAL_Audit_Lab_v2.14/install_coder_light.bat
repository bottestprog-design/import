@echo off
setlocal
cd /d "%~dp0"
title DUAL Audit Lab v2.14 - Install Qwen Coder 1.5B
echo ======================================================
echo   DUAL Audit Lab v2.14 - Qwen2.5-Coder 1.5B
echo ======================================================
where ollama >nul 2>nul
if errorlevel 1 (
  echo ERROR: Ollama was not found in PATH. Install: https://ollama.com/download/windows
  pause
  exit /b 2
)
ollama show qwen2.5-coder:1.5b >nul 2>nul
if errorlevel 1 (
  echo Downloading Qwen2.5-Coder 1.5B (~986 MB)...
  ollama pull qwen2.5-coder:1.5b
  if errorlevel 1 (
    echo ERROR: Download failed.
    pause
    exit /b 3
  )
) else (
  echo Qwen2.5-Coder 1.5B is already installed; download skipped.
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 set_coder_model.py qwen2.5-coder:1.5b
) else (
  python set_coder_model.py qwen2.5-coder:1.5b
)
if errorlevel 1 (
  echo ERROR: Could not update config.json.
  pause
  exit /b 4
)
echo Coder model selected: qwen2.5-coder:1.5b
echo Next: install the verified Antares model, then run check_model_setup.bat.
pause
exit /b 0
