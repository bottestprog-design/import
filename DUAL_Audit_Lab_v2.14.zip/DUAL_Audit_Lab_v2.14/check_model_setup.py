from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import server  # noqa: E402

VERSION_FILE = ROOT / "VERSION.txt"
EXPECTED_BUILD = "2.14"


def _yes(value: object) -> str:
    return "PASS" if value is True else "FAIL"


def main() -> int:
    version = VERSION_FILE.read_text(encoding="utf-8").strip() if VERSION_FILE.exists() else "unknown"
    print("DUAL_DIAGNOSTIC_SIGNATURE=DUAL-AUDIT-LAB-2.14")
    print("DUAL Audit Lab - local model diagnostics")
    print(f"Build version: {version}")
    print(f"Checker file: {Path(__file__).resolve()}")
    print(f"Server module: {Path(server.__file__).resolve()}")
    print(f"Project directory: {ROOT}")
    if version != EXPECTED_BUILD:
        print(f"FAIL: expected build {EXPECTED_BUILD}, found {version}. Extract and run the newest ZIP folder.")
        return 10
    if Path(server.__file__).resolve() != (ROOT / "server.py").resolve():
        print("FAIL: imported server.py is not from this project directory.")
        return 11
    print(f"Configured coder: {server.CONFIG.get('coder_model')}")
    print(f"Configured auditor: {server.CONFIG.get('auditor_model')}")

    status = server.ollama_status()
    if not status.get("online"):
        print("FAIL: Ollama is offline:", status.get("error", "unknown"))
        print("Open Ollama and re-run this checker.")
        return 2
    print("Ollama version:", status.get("version"))
    print("Installed models:", ", ".join(status.get("models", [])) or "none")
    if not status.get("coder_installed"):
        print("FAIL: coder model missing:", server.CONFIG["coder_model"])
        return 3
    if not status.get("auditor_installed"):
        print("FAIL: verified Antares model missing:", server.CONFIG["auditor_model"])
        stale_tags = [name for name in status.get("models", []) if name.startswith("antares-1b-raw") and name.split(":", 1)[0] != server.CONFIG["auditor_model"]]
        if stale_tags:
            print("Untrusted/older Antares tags are present and will NOT be reused or deleted:", ", ".join(stale_tags))
        print("Run install_auditor.bat from THIS v2.14 folder. It downloads the pinned GGUF, checks exact size + SHA-256, then creates a new versioned DUAL tag.")
        return 4

    print("\n[1/2] Testing coder inference. This loads and unloads the coder model...")
    coder = server.test_coder()
    print(_yes(coder.get("ok")), coder.get("message", coder.get("error", "")))
    if coder.get("stats"):
        stats = coder["stats"]
        print(
            "Coder completion:",
            f"done={stats.get('done')} | prompt_eval_count={stats.get('prompt_eval_count')} "
            f"| eval_count={stats.get('eval_count')} | reason={stats.get('done_reason') or 'not supplied'}",
        )
    if coder.get("response"):
        print("Coder response:", coder["response"][:220].replace("\n", " "))

    print("\n[2/2] Testing Antares raw Granite tool-call protocol on a synthetic folder...")
    auditor = server.test_auditor()
    checks = auditor.get("checks", {})
    print(_yes(checks.get("transport")), "Ollama completion: done=true and token counters are positive")
    print(_yes(checks.get("tool_call_parsed")), f"Parsed tool calls: {auditor.get('parsed_tool_calls', 0)}")
    print(_yes(checks.get("terminal_safe")), "A terminal call passed the local allowlist")
    print(_yes(checks.get("terminal_executed")), "The safe command ran against the synthetic in-memory inventory")
    print("Antares result:", auditor.get("message", auditor.get("error", "unknown")))
    if auditor.get("diagnostic_command"):
        print("Accepted command:", auditor["diagnostic_command"])
    if auditor.get("tool_output"):
        print("Safe tool output:", auditor["tool_output"][:300].replace("\n", " | "))
    if auditor.get("tool_validation_errors"):
        print("Tool validation details:", " | ".join(auditor["tool_validation_errors"][:3]))
    if auditor.get("stats"):
        stats = auditor["stats"]
        print(
            "Antares completion:",
            f"done={stats.get('done')} | prompt_eval_count={stats.get('prompt_eval_count')} "
            f"| eval_count={stats.get('eval_count')} | reason={stats.get('done_reason') or 'not supplied'}",
        )
    if auditor.get("response"):
        print("Antares response excerpt:", auditor["response"][:500].replace("\n", " "))

    if not coder.get("ok") or not auditor.get("ok"):
        print("\nMODEL SETUP FAILED. Read the individual PASS/FAIL checks above; do not start an audit.")
        return 5
    print("\nMODEL SETUP PASSED. This confirms connectivity and tool execution only, not vulnerability-detection accuracy.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
