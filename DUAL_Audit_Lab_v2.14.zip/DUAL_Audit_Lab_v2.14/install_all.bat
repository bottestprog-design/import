@echo off
setlocal
cd /d "%~dp0"
title DUAL Audit Lab v2.14 - Install both local models
call install_coder_light.bat
if errorlevel 1 exit /b %errorlevel%
call install_auditor.bat
if errorlevel 1 exit /b %errorlevel%
echo.
echo Both installers returned success.
echo Now run check_model_setup.bat before starting the application.
pause
exit /b 0
