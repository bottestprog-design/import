(() => {
  'use strict';

  const state = {
    data: null,
    countries: null,
    uiMode: (() => { try { return localStorage.getItem('chatbot-ui-mode') === 'light' ? 'light' : 'dark'; } catch { return 'dark'; } })(),
    companionNotice: null,
    assistantMessages: (() => { try { const value = JSON.parse(localStorage.getItem('chatbot-local-assistant-history') || '[]'); return Array.isArray(value) ? value.filter(x => x && ['user','assistant'].includes(x.role) && typeof x.text === 'string').slice(-80) : []; } catch { return []; } })(),
    assistantBusy: false,
    page: location.hash.slice(1) || 'dashboard',
    bgEngine: null,
    selectedGroup: null,
    pendingTargets: null,
    peopleFilter: '',
    selectedRecipientIds: new Set(),
    groupFilter: '',
    settingsView: 'appearance',
    loadPromise: null,
    loadController: null,
    bgLivePending: 0,
    interactionEditingRule: '',
    interactionEditingCounter: '',
    editingAutomationRuleId: '',
    whatsappContacts: null,
    whatsappContactsBusy: false,
    whatsappContactsOpen: false,
    whatsappContactsSession: '',
    whatsappContactsSelected: new Set(),
    whatsappContactFilter: '',
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function robotSvgMarkup(className = 'robot-svg') {
    return `<svg class="${className}" viewBox="0 0 96 104" role="img" aria-label="روبوت chat BOT" focusable="false">
      <ellipse cx="48" cy="96" rx="29" ry="5" fill="#06101e" opacity=".24"/>
      <path d="M29 70Q21 73 20 84V91Q20 95 25 95H71Q76 95 76 91V84Q75 73 67 70Z" fill="#172b46" stroke="#70e8de" stroke-width="2"/>
      <path d="M36 71 34 86Q48 92 62 86L60 71Z" fill="#26496c"/><path d="M48 8V17" stroke="#7ff6df" stroke-width="3.5" stroke-linecap="round"/><circle cx="48" cy="6" r="5" fill="#72f6dc" stroke="#d7fff7" stroke-width="1.5"/>
      <path d="M22 30Q22 20 33 20H63Q74 20 74 30V57Q74 68 63 68H33Q22 68 22 57Z" fill="#14243b" stroke="#78e8e0" stroke-width="2.4"/><path d="M28 31Q28 25 36 25H60Q68 25 68 31V53Q68 60 60 60H36Q28 60 28 53Z" fill="#1d3955" stroke="#375e7d" stroke-width="1.2"/>
      <rect x="34" y="36" width="10" height="12" rx="4" fill="#68f4dc"/><rect x="52" y="36" width="10" height="12" rx="4" fill="#68f4dc"/><circle cx="37" cy="39" r="2" fill="#effffb"/><circle cx="55" cy="39" r="2" fill="#effffb"/><path d="M40 54Q48 60 56 54" stroke="#b4fff0" stroke-width="2.8" fill="none" stroke-linecap="round"/><path d="M18 39Q12 44 18 50M78 39Q84 44 78 50" stroke="#84eddf" stroke-width="3" fill="none" stroke-linecap="round"/>
      <path d="M33 80 40 76H56L63 80 60 91H36Z" fill="#32718a" stroke="#83f4dc" stroke-width="1.3"/><circle cx="48" cy="83" r="4" fill="#8c8aff" stroke="#d7d0ff" stroke-width="1.2"/><path d="M26 76 21 82M70 76 75 82" stroke="#a3fff0" stroke-width="4" stroke-linecap="round"/>
    </svg>`;
  }
  const sid = () => $('#sessionSelect')?.value || state.data?.session?.id || '';

  function activeTargets(data) {
    return [
      ...(data.recipients || []).map((x) => ({ ...x, key: `r:${x.id}`, type: 'recipient' })),
      ...(data.groups || []).map((x) => ({ ...x, key: `g:${x.id}`, type: 'group' })),
    ];
  }

  function chatIdForTarget(target) {
    if (!target) return '';
    if (target.type === 'group') return String(target.gid || '').toLowerCase();
    const digits = String(target.digits || target.phone || '').replace(/\D/g, '');
    return digits ? `${digits}@c.us` : String(target.chatId || '').toLowerCase();
  }

  function typeLabel(target) {
    return target?.type === 'group' ? 'مجموعة' : 'شخص';
  }

  async function api(url, options = {}) {
    const isForm = options.body instanceof FormData;
    const headers = { ...(isForm ? {} : { 'Content-Type': 'application/json' }), ...(options.headers || {}) };
    const response = await fetch(url, { ...options, headers });
    const raw = await response.text();
    let body = {};
    try { body = raw ? JSON.parse(raw) : {}; } catch { body = { raw }; }
    if (!response.ok || body.ok === false) throw new Error(body.error || body.raw || `HTTP ${response.status}`);
    return body;
  }

  function notify(message, type = 'info') {
    const toast = $('#toast');
    if (toast) {
      toast.className = `toast ${type}`;
      toast.textContent = message;
      toast.hidden = false;
      clearTimeout(notify.timer);
      notify.timer = setTimeout(() => { toast.hidden = true; }, 4200);
    }
    // The robot is a visual helper for real status messages, not an AI claim.
    const speech = $('#assistantSpeech');
    const speechText = $('#assistantSpeechText');
    const robot = $('#assistantRobotButton');
    if (speech && speechText && message) {
      speechText.textContent = String(message);
      speech.className = `assistant-speech activity-${['success','error','warning'].includes(type) ? type : 'info'}`;
      speech.hidden = false;
      if (robot) { robot.dataset.mood = ['success','error','warning'].includes(type) ? type : 'neutral'; robot.classList.remove('robot-talk'); void robot.offsetWidth; robot.classList.add('robot-talk'); }
      clearTimeout(notify.speechTimer);
      notify.speechTimer = setTimeout(() => { if (speech && speechText.textContent === String(message)) speech.hidden = true; }, 9000);
    }
  }

  async function load(force = false) {
    if (state.loadPromise) return state.loadPromise;
    state.loadPromise = (async () => {
      state.loadController?.abort();
      const controller = new AbortController();
      state.loadController = controller;
      const current = sid();
      const query = current ? `?sessionId=${encodeURIComponent(current)}${force ? '&fresh=1' : ''}` : '';
      try {
        state.data = await api(`/api/state${query}`, { signal: controller.signal });
        if (!controller.signal.aborted) render();
      } finally {
        if (state.loadController === controller) state.loadController = null;
      }
    })();
    try { return await state.loadPromise; }
    finally { state.loadPromise = null; }
  }

  async function loadCountries() {
    if (!state.countries) state.countries = await api('/api/countries');
    return state.countries;
  }

  function countryOptions(selected = 'OM') {
    return (state.countries?.countries || []).map((country) => `<option value="${esc(country.code)}" ${country.code === selected ? 'selected' : ''}>+${esc(country.callingCode)} · ${esc(country.code)}</option>`).join('');
  }

  function nav() {
    const groups = [
      { title: 'مساحة العمل', items: [['dashboard', '⌂', 'الرئيسية'], ['send', '➜', 'الإرسال'], ['owner-center', '◉', 'مركز المساعد'], ['assistant', '✧', 'المساعد المحلي']] },
      { title: 'جهات الإرسال', items: [['people', '●', 'الأشخاص'], ['groups', '◆', 'المجموعات']] },
      { title: 'التحكم', items: [['interaction', '✦', 'التفاعل'], ['automation', '⏱', 'الأتمتة'], ['session', '◉', 'الجلسة'], ['settings', '⚙', 'الإعدادات']] },
      { title: 'الإضافات الجديدة', items: [['tools', '⌘', 'المحركات الذكية'], ['guide', '▤', 'الدليل والمساعدة'], ['updates', '↗', 'التعديلات والإصدارات']] },
    ];
    return groups.map((group) => `<div class="nav-group"><span class="nav-group-label">${group.title}</span>${group.items.map(([id, icon, label]) => `<button class="navbtn ${state.page === id ? 'active' : ''}" data-page="${id}" aria-current="${state.page === id ? 'page' : 'false'}"><span class="nav-icon" aria-hidden="true">${icon}</span><span>${label}</span>${state.page === id ? '<span class="nav-active-mark" aria-hidden="true"></span>' : ''}</button>`).join('')}</div>`).join('');
  }

  function shell(content) {
    const data = state.data || { session: {}, sessions: [], whatsapp: {} };
    const ready = !!data.whatsapp?.ready;
    const connectionText = ready ? 'متصل' : (data.whatsapp?.status === 'qr' ? 'بانتظار QR' : 'غير متصل');
    const defaultNotice = state.companionNotice?.message || 'أهلًا بك. افتح «المساعد المحلي» للسؤال عن حالة النظام أو الانتقال إلى صفحات البرنامج. يستخدم المساعد قواعد محلية ولا ينفّذ إرسالًا أو حذفًا من المحادثة.';
    return `<div class="app-shell">
      <header class="topbar">
        <div class="brand"><span class="brand-mark" aria-hidden="true">${robotSvgMarkup('brand-robot-svg')}</span><div><strong>chat BOT</strong><small>مركز إدارة الرسائل</small></div></div>
        <div class="top-actions">
          <label class="session-picker"><span>الجلسة الحالية</span><select id="sessionSelect" aria-label="اختر الجلسة">${(data.sessions || []).map((session) => `<option value="${esc(session.id)}" ${session.id === data.session.id ? 'selected' : ''}>${esc(session.name || session.id)}</option>`).join('')}</select></label>
          <span class="status-pill ${ready ? 'ready' : ''}" title="حالة اتصال WhatsApp"><span class="status-dot"></span><span>${connectionText}</span></span>
          <button class="mode-btn" id="modeToggleBtn" type="button" aria-label="${state.uiMode === 'dark' ? 'التبديل إلى الوضع الفاتح' : 'التبديل إلى الوضع الداكن'}"><span class="mode-icon" aria-hidden="true">${state.uiMode === 'dark' ? '☼' : '☾'}</span><span>${state.uiMode === 'dark' ? 'الوضع الفاتح' : 'الوضع الداكن'}</span></button>
          <button class="icon-btn" id="refreshBtn" title="تحديث البيانات" aria-label="تحديث البيانات">↻</button>
          <div class="more-settings-wrap"><button class="btn more-settings-btn" id="moreSettingsBtn" type="button" aria-expanded="false" aria-controls="moreSettingsMenu">⚙ إعدادات إضافية <span aria-hidden="true">▾</span></button>
            <div class="more-settings-menu" id="moreSettingsMenu" hidden>
              <button type="button" data-go="operation"><b>إعدادات التشغيل المتقدمة</b><small>الموثوقية والمحاولات وفترة الهدوء</small></button>
              <button type="button" data-go="appearance"><b>المظهر والخلفيات</b><small>ألوان الواجهة وتأثيرات الخلفية</small></button>
              <button type="button" data-go="tools"><b>المحركات الذكية</b><small>فحص البنية والقاموس وتحليل الأوامر</small></button>
              <button type="button" data-go="updates"><b>التعديلات والإصدارات</b><small>الميزات المضافة والقيود المعروفة</small></button>
              <button type="button" data-go="guide"><b>الدليل والخصوصية</b><small>طريقة التشغيل والمساعدة</small></button>
            </div>
          </div>
        </div>
      </header>
      <div class="workspace-layout">
        <aside class="sidebar" aria-label="التنقل الرئيسي">
          <div class="sidebar-heading"><span>القائمة الرئيسية</span><small>تنقّل واضح وسريع</small></div>
          <nav class="navrow" aria-label="صفحات chat BOT">${nav()}</nav>
          <div class="sidebar-foot"><span class="sidebar-foot-icon" aria-hidden="true">✓</span><div><b>إدارة محلية</b><small>البيانات محفوظة على جهازك</small></div></div>
        </aside>
        <main class="main" id="mainContent" tabindex="-1">${content}</main>
      </div>
      <div class="assistant-companion" id="assistantCompanion" aria-label="مساعد chat BOT">
        <section id="assistantSpeech" class="assistant-speech" hidden role="status" aria-live="polite">
          <div class="assistant-speech-top"><span class="assistant-speech-origin">${robotSvgMarkup('speech-mini-robot')}<span>مساعد chat BOT</span></span><button id="assistantSpeechClose" class="assistant-speech-close" type="button" aria-label="إغلاق الرسالة" title="إغلاق الرسالة">×</button></div>
          <p id="assistantSpeechText">${esc(defaultNotice)}</p><button id="assistantSpeechOpen" class="assistant-speech-link" type="button">فتح المساعد المحلي ↗</button><span class="assistant-speech-tail" aria-hidden="true"></span>
        </section>
        <button id="assistantRobotButton" class="assistant-robot-button" type="button" aria-label="افتح المساعد المحلي في chat BOT" title="افتح المساعد المحلي" data-mood="neutral">${robotSvgMarkup('assistant-robot-svg')}<span class="assistant-robot-status" aria-hidden="true"></span></button><div class="assistant-robot-caption" aria-hidden="true">مساعدك</div>
      </div>
      <div id="toast" class="toast sr-only" hidden role="status" aria-live="polite"></div>
    </div>`;
  }

  function pageDashboard(data) {
    const targets = activeTargets(data);
    const stats = data.stats || {};
    const logs = (data.logs || []).slice(0, 12);
    const runtime = data.whatsapp || {};
    return `<section class="hero-card">
      <div><p class="eyebrow">لوحة الجلسة الحالية</p><h1>${esc(data.session?.name || 'الجلسة الرئيسية')}</h1><p>كل شيء واضح من هنا: الإرسال، الأشخاص، المجموعات، التفاعل والسجل.</p></div>
      <div class="hero-actions"><button class="btn primary" data-go="send">إرسال الآن</button><button class="btn" data-go="interaction">التفاعل</button></div>
    </section>
    <section class="stats-grid">
      <article class="stat-card"><span>الحالة</span><b>${runtime.ready ? 'جاهز' : 'غير متصل'}</b><small>${runtime.info?.wid?.user ? '+' + esc(runtime.info.wid.user) : 'اربط الحساب من الجلسة'}</small></article>
      <article class="stat-card"><span>الأشخاص</span><b>${(data.recipients || []).length}</b><small>هذه الجلسة</small></article>
      <article class="stat-card"><span>المجموعات</span><b>${(data.groups || []).length}</b><small>هذه الجلسة</small></article>
      <article class="stat-card"><span>الإرسال</span><b>${Number(stats.sentMessages || 0) + Number(stats.sentImages || 0) + Number(stats.sentFiles || 0)}</b><small>عمليات تم تسجيلها</small></article>
    </section>
    <section class="content-grid two-col">
      <article class="panel"><div class="panel-head"><div><h2>الوصول السريع</h2><p>اختصر الطريق إلى المهمة التي تريدها.</p></div></div>
        <div class="quick-list">
          <button class="quick-item" data-go="send"><span class="quick-icon">➜</span><span><b>رسالة جديدة</b><small>حدد الأهداف والملفات ثم أرسل.</small></span></button>
          <button class="quick-item" data-go="people"><span class="quick-icon">＋</span><span><b>إضافة أشخاص</b><small>أرقام دولية وقوائم متعددة.</small></span></button>
          <button class="quick-item" data-go="groups"><span class="quick-icon">◆</span><span><b>المجموعات</b><small>اكتشاف، ربط، تحليل وحفظ.</small></span></button>
          <button class="quick-item" data-go="settings"><span class="quick-icon">⚙</span><span><b>الإعدادات</b><small>المظهر والخلفيات والتشغيل.</small></span></button>
        </div>
      </article>
      <article class="panel"><div class="panel-head"><div><h2>آخر نشاط</h2><p>السجل محفوظ لهذه الجلسة فقط.</p></div><button class="btn small" id="dashboardRefresh">تحديث</button></div>
        <div class="log-list">${logs.length ? logs.map(logRow).join('') : '<div class="empty">لا يوجد نشاط بعد.</div>'}</div>
      </article>
    </section>`;
  }

  function logRow(log) {
    const at = log.at || log.time || log.timestamp || '';
    const date = at ? new Date(at) : null;
    const when = date && !Number.isNaN(date.getTime()) ? date.toLocaleString('ar-OM') : '';
    const level = String(log.level || 'INFO').toLowerCase();
    return `<div class="log-row"><span class="log-time">${esc(when)}</span><span class="log-level ${esc(level)}">${esc(log.level || 'INFO')}</span><span class="log-message">${esc(log.message || '')}</span></div>`;
  }

  function targetList(data, selected = state.pendingTargets) {
    const useAll = !Array.isArray(selected);
    const chosen = new Set(useAll ? [] : selected.map(String));
    const targets = activeTargets(data);
    return targets.length ? targets.map((target) => `<label class="target-row">
      <input type="checkbox" class="target" value="${esc(target.key)}" ${(useAll || chosen.has(target.key)) ? 'checked' : ''}>
      <span class="target-mark ${target.type}">${target.type === 'group' ? '◆' : '●'}</span>
      <span class="target-main"><b>${esc(target.name || target.phone || target.gid || 'بدون اسم')}</b><small>${typeLabel(target)}${target.type === 'group' ? ` · ${esc(target.gid || '')}` : ` · ${esc(target.international || target.e164 || '')}`}</small></span>
      <span class="target-state ${target.enabled === false ? 'off' : ''}">${target.enabled === false ? 'متوقف' : 'جاهز'}</span>
    </label>`).join('') : '<div class="empty">لا توجد أهداف. أضف شخصًا أو اربط مجموعة أولًا.</div>';
  }

  function pageOwnerCenter(data) {
    const stats = data.stats || {};
    const runtime = data.whatsapp || {};
    const status = runtime.ready ? 'متصل' : runtime.status === 'qr' ? 'بانتظار QR' : runtime.status || 'غير متصل';
    const recent = (data.logs || []).slice(0, 12);
    const personalReplies = (data.recipients || []).filter(person => person.replyProfile?.mode === 'custom').length;
    const statsRows = [
      ['رسائل أُرسلت', Number(stats.sentMessages || 0)],
      ['ملفات أُرسلت', Number(stats.sentFiles || 0) + Number(stats.sentImages || 0)],
      ['إجراءات التفاعل', Number(stats.interactionActions || 0)],
      ['أخطاء التفاعل', Number(stats.interactionErrors || 0)],
    ];
    return `<section class="page-title"><p class="eyebrow">OWNER CENTER • LOCAL STATUS</p><h1>مركز المساعد</h1><p>لوحة متابعة للجلسة الحالية، والأشخاص والمجموعات والإرسال والتفاعل. هذه الشاشة تقرأ البيانات المحلية ولا تدّعي تنفيذ إجراءات من دون طلبك.</p></section>
      <section class="hero-card owner-center-hero"><div><span class="eyebrow">حالة الحساب</span><h2>${esc(status)}</h2><p>${runtime.info?.wid?.user ? `الحساب المتصل: +${esc(runtime.info.wid.user)}` : 'اربط WhatsApp من صفحة الجلسة لمتابعة الاتصال.'}</p></div><div class="hero-actions"><button class="btn primary" data-go="assistant">افتح المساعد المحلي</button><button class="btn" data-go="session">إدارة الاتصال</button></div></section>
      <section class="stats-grid owner-center-stats">${statsRows.map(([label,value]) => `<article class="stat-card"><span>${esc(label)}</span><b>${value.toLocaleString('ar-OM')}</b><small>مجمّع لهذه الجلسة فقط</small></article>`).join('')}</section>
      <section class="content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>ملخص الجلسة</h2><p>عدد العناصر المحفوظة وحالتها.</p></div><button class="btn small" id="ownerCenterRefresh">تحديث</button></div><div class="owner-metric-list">
        <div><span>الأشخاص المحفوظون</span><b>${(data.recipients || []).length}</b><button class="btn small" data-go="people">عرض</button></div>
        <div><span>ردود شخصية مخصصة</span><b>${personalReplies}</b><button class="btn small" data-go="people">إدارة</button></div>
        <div><span>المجموعات المحفوظة</span><b>${(data.groups || []).length}</b><button class="btn small" data-go="groups">عرض</button></div>
        <div><span>قواعد التفاعل المفعّلة</span><b>${(data.interaction?.rules || []).filter(rule => rule.enabled !== false).length}</b><button class="btn small" data-go="interaction">عرض</button></div>
        <div><span>مهام الأتمتة المفعّلة</span><b>${(data.automation?.tasks || []).filter(task => task.enabled !== false).length}</b><button class="btn small" data-go="automation">عرض</button></div>
      </div><div class="action-bar"><button class="btn" data-go="send">الذهاب إلى الإرسال</button><button class="btn" data-go="tools">فحص المحركات</button><button class="btn" data-go="updates">التعديلات الجديدة</button></div></article>
      <article class="panel"><div class="panel-head"><div><h2>آخر النشاطات</h2><p>السجل المخزن في الجلسة الحالية.</p></div></div><div class="log-list tall">${recent.map(logRow).join('') || '<div class="empty">لا توجد نشاطات مسجلة بعد.</div>'}</div><div class="action-bar"><button class="btn" data-go="session">سجل الجلسة الكامل</button></div></article></section>`;
  }

  function pageAssistant(data) {
    const messages = state.assistantMessages.length ? state.assistantMessages : [{ role: 'assistant', text: 'أهلًا بك. أنا المساعد المحلي في chat BOT. أستطيع قراءة حالة النظام والعناصر المحفوظة والتنقل إلى صفحات البرنامج باستخدام قواعد محلية. لا أستخدم خدمة ذكاء اصطناعي خارجية ولا أنفّذ حذفًا أو إرسالًا من المحادثة.', at: '' }];
    return `<section class="page-title"><p class="eyebrow">ASSISTANTS • LOCAL CONTROL</p><h1>المساعد ومحادثة WhatsApp</h1><p>استخدم المحادثة هنا للأسئلة والتنقل، أو افتح WhatsApp واكتب للبوت داخل محادثة «الرسائل إلى نفسك» لتنفيذ الحوارات التفاعلية خطوة بخطوة.</p></section>
      <section class="panel self-chat-guide-panel"><div class="panel-head"><div><h2>محادثة البوت داخل WhatsApp</h2><p>هذه هي قناة الأوامر الفعلية، منفصلة عن دردشة المتصفح.</p></div><span class="mini-tag ${data.whatsapp?.ready ? 'connected' : ''}">${data.whatsapp?.ready ? 'WhatsApp متصل' : 'يلزم الاتصال'}</span></div>
        <div class="self-chat-guide-grid"><div><b>1. اربط حساب WhatsApp</b><small>من صفحة الجلسة، ابدأ الاتصال وامسح QR عند ظهوره.</small></div><div><b>2. افتح «الرسائل إلى نفسك»</b><small>اكتب طلبك كما تكتبه لشخص؛ سيرشدك البوت سؤالًا بعد سؤال.</small></div><div><b>3. راجع ثم أكّد</b><small>لن يرسل رسالة أو يحفظ موعدًا أو قاعدة إلا بعد تأكيد واضح منك.</small></div></div>
        <div class="self-chat-examples"><span>جرّب في WhatsApp:</span><code>مساعدة</code><code>عايز أضيف شخص جديد</code><code>أرسل رسالة</code><code>أنشئ موعد</code><code>أنشئ رد تلقائي</code><code>استدعاء جهات واتساب</code></div>
        <div class="action-bar"><button class="btn primary" data-go="session">ربط WhatsApp</button><button class="btn" data-go="people">استدعاء ومزامنة جهات WhatsApp</button><button class="btn" data-go="guide">دليل الاستخدام</button></div>
        <details class="advanced-panel"><summary>تعليمات محادثة النفس بالتفصيل</summary><p>بعد نجاح الاتصال يرسل البوت رسالة دليل مرة واحدة لكل جلسة. يمكنك استعادتها بكتابة «مساعدة». أثناء إضافة شخص، يطلب الاسم ثم الدولة ثم الرقم ويتعامل مع التكرار. إرسال الرسائل يمرّ باختيار المستلم ثم نص الرسالة ثم التأكيد. المواعيد والردود التلقائية لها خطوات مراجعة وتأكيد. اكتب «إلغاء» لإيقاف أي حوار جارٍ.</p></details>
      </section>
      <section class="content-grid assistant-content-grid"><article class="panel local-assistant-panel"><div class="panel-head"><div><h2>محادثة محلية</h2><p>يتم حفظ سجل الواجهة في المتصفح على هذا الجهاز، بحد أقصى 80 رسالة.</p></div><span class="mini-tag">محلي</span></div>
        <div id="localAssistantMessages" class="local-assistant-messages" role="log" aria-live="polite" aria-relevant="additions text">${messages.map(message => `<div class="local-assistant-message ${message.role === 'user' ? 'user' : 'assistant'}"><span>${message.role === 'user' ? 'أنت' : 'مساعد chat BOT'}</span><p>${esc(message.text).replace(/\n/g, '<br>')}</p></div>`).join('')}${state.assistantBusy ? '<div class="local-assistant-message assistant"><span>مساعد chat BOT</span><p>أفحص البيانات المحلية…</p></div>' : ''}</div>
        <form id="localAssistantForm" class="local-assistant-form"><label class="sr-only" for="localAssistantPrompt">اكتب سؤالًا أو أمرًا</label><textarea id="localAssistantPrompt" maxlength="1000" rows="2" placeholder="مثال: الحالة، قائمة الأشخاص، افتح الإعدادات" ${state.assistantBusy ? 'disabled' : ''}></textarea><div class="local-assistant-form-footer"><small>الأوامر الحساسة لا تُنفّذ من هنا.</small><button class="btn primary" type="submit" ${state.assistantBusy ? 'disabled' : ''}>${state.assistantBusy ? 'جارٍ الفحص…' : 'إرسال السؤال'}</button></div></form>
        <div class="local-assistant-quick">${['الحالة','قائمة الأشخاص','قائمة المجموعات','قواعد التفاعل','الأتمتة','افتح الإرسال','مساعدة'].map(prompt => `<button type="button" class="btn small" data-assistant-prompt="${esc(prompt)}">${esc(prompt)}</button>`).join('')}</div>
        <div class="action-bar"><button class="btn" id="clearLocalAssistantHistory">مسح سجل المحادثة</button><button class="btn" data-go="tools">المحركات الذكية</button><button class="btn" data-go="guide">الدليل</button></div>
      </article><aside class="panel"><div class="panel-head"><div><h2>ما يستطيع المساعد فعله</h2><p>نطاق واضح من دون ادعاء ذكاء عام.</p></div></div><div class="engine-list">
        <div class="engine-row"><span class="engine-icon">✓</span><div><b>قراءة الحالة</b><small>حالة WhatsApp، عدد الأشخاص والمجموعات والقواعد.</small></div></div>
        <div class="engine-row"><span class="engine-icon">↗</span><div><b>التنقل بين الصفحات</b><small>افتح الإرسال أو الأشخاص أو الإعدادات بالكلام.</small></div></div>
        <div class="engine-row"><span class="engine-icon">⌕</span><div><b>السجل المحلي</b><small>عرض آخر النشاطات المحفوظة في الجلسة.</small></div></div>
        <div class="engine-row"><span class="engine-icon">!</span><div><b>تأكيد الإجراءات الحساسة</b><small>تحليل الأمر لا يعني تنفيذه على حساب WhatsApp.</small></div></div>
      </div><div class="privacy-box"><p>المساعد لا يرسل رسائل ولا يحذف جهات اتصال ولا يكتم محادثات. استخدم صفحة الوظيفة نفسها لمراجعة الإجراء وتنفيذه يدويًا.</p></div></aside></section>`;
  }

  function persistAssistantMessages() {
    try { localStorage.setItem('chatbot-local-assistant-history', JSON.stringify(state.assistantMessages.slice(-80))); } catch { /* Local history is optional if browser storage is unavailable. */ }
  }

  async function submitAssistantPrompt(value) {
    const prompt = String(value || '').trim().slice(0, 1000);
    if (!prompt || state.assistantBusy) return;
    state.assistantMessages.push({ role: 'user', text: prompt, at: new Date().toISOString() });
    state.assistantMessages = state.assistantMessages.slice(-80);
    state.assistantBusy = true;
    persistAssistantMessages();
    render();
    try {
      const result = await api('/api/assistant/local', { method: 'POST', body: JSON.stringify({ sessionId: sid(), prompt }) });
      state.assistantMessages.push({ role: 'assistant', text: String(result.reply || 'لم تُرجع المحركات ردًا.'), at: new Date().toISOString() });
      state.assistantMessages = state.assistantMessages.slice(-80);
      state.assistantBusy = false;
      persistAssistantMessages();
      if (result.navigate) {
        const target = result.navigate;
        render();
        go(target);
      } else render();
    } catch (error) {
      state.assistantMessages.push({ role: 'assistant', text: `تعذر إكمال السؤال المحلي: ${error.message}`, at: new Date().toISOString() });
      state.assistantMessages = state.assistantMessages.slice(-80);
      state.assistantBusy = false;
      persistAssistantMessages();
      render();
    }
  }

  async function bindAssistant() {
    $('#localAssistantForm')?.addEventListener('submit', async event => {
      event.preventDefault();
      const input = $('#localAssistantPrompt'); const prompt = input?.value || '';
      await submitAssistantPrompt(prompt);
    });
    $$('[data-assistant-prompt]').forEach(button => button.addEventListener('click', () => submitAssistantPrompt(button.dataset.assistantPrompt)));
    $('#clearLocalAssistantHistory')?.addEventListener('click', () => {
      if (!confirm('مسح سجل محادثة المساعد المحلي المحفوظ في هذا المتصفح؟')) return;
      state.assistantMessages = []; persistAssistantMessages(); render();
    });
  }

  function pageSend(data) {
    const media = data.media || [];
    const tasks = data.automation?.tasks || [];
    const selectedTargets = state.pendingTargets;
    const groupsCount = (data.groups || []).length;
    return `<section class="page-title"><p class="eyebrow">إرسال</p><h1>أرسل بسهولة</h1><p>حدد الأهداف، اكتب الرسالة، ارفع الملفات، ثم نفّذ الآن أو احفظ موعدًا مستقلًا.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>من سيرسل إليه؟</h2><p>كل الاختيارات تخص الجلسة الحالية.</p></div><div class="panel-actions"><button class="btn small" id="selectAllTargets">الكل</button><button class="btn small" id="clearTargets">مسح</button></div></div>
          <div class="target-summary"><b>${selectedTargets === null ? 'الكل' : selectedTargets.length}</b><span>${selectedTargets === null ? 'كل الأهداف' : 'أهداف محددة'}</span><span>· ${groupsCount} مجموعة محفوظة</span></div>
          <div class="target-list">${targetList(data, selectedTargets)}</div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الرسالة والملفات</h2><p>ارفع مرة واحدة واختر ما يدخل في الإرسال.</p></div></div>
          <label>نص الرسالة<textarea id="sendText" rows="6" placeholder="اكتب الرسالة هنا..."></textarea></label>
          <div class="form-grid two"><label>قبل الملف<input id="sendPreText" placeholder="اختياري"></label><label>بعد الملف<input id="sendPostText" placeholder="اختياري"></label></div>
          <div class="upload-box"><input id="mediaFiles" type="file" multiple><label for="mediaFiles"><span>＋</span> اختر الملفات</label><small>صور، GIF، PDF، مستندات، صوت وفيديو حسب الأنواع المدعومة.</small><label class="upload-option"><input id="replaceDuplicates" type="checkbox"><span>استبدال الملف المكرر تلقائيًا</span></label></div>
          <div class="file-list">${media.length ? media.map(mediaChip).join('') : '<div class="empty">لا توجد ملفات مرفوعة.</div>'}</div>
          <details class="advanced-panel"><summary>خيارات الإرسال</summary><div class="form-grid three"><label>الترتيب<select id="sendOrder"><option value="target-first">كل هدف ثم ملفاته</option><option value="image-first">كل ملف ثم جميع الأهداف</option></select></label><label>منع التكرار<select id="repeatGuard"><option value="on">مفعّل (موصى به)</option><option value="off">متوقف لهذا الإرسال</option></select></label><label>النص الافتراضي<input id="defaultPreText" value="${esc(data.settings?.preText || '')}" placeholder="اختياري"></label><label class="toggle-row send-repeat-override"><input id="replaceSendDuplicate" type="checkbox"><span><b>السماح بتكرار إرسال موجود</b><small>خيار منفصل عن استبدال الملفات المكررة؛ استخدمه فقط عندما تريد إعادة الإرسال عمدًا.</small></span></label></div></details>
          <div class="action-bar"><button class="btn primary large" id="sendNowBtn">إرسال الآن</button></div>
        </article>
      </section>
      <section class="panel"><div class="panel-head"><div><h2>الإرسال التلقائي</h2><p>المواعيد المحفوظة تظهر هنا. افتح المحرر فقط عند إنشاء موعد أو تعديله.</p></div><span class="release-pill">${tasks.length} موعد</span></div>
        <details class="section-editor" id="sendScheduleDisclosure" ${state.editingTaskId ? 'open' : ''}><summary>${state.editingTaskId ? 'تعديل الموعد المحدد' : '＋ إنشاء موعد إرسال جديد'}</summary>
          <div class="form-grid four"><label>اسم الموعد<input id="scheduleName" placeholder="مثال: تذكير يومي"></label><label>الوقت<input id="scheduleTime" type="time" value="17:30"></label><label>التكرار<select id="scheduleMode"><option value="once">مرة واحدة</option><option value="daily">يوميًا</option><option value="weekly">أسبوعيًا</option><option value="monthly">شهريًا</option><option value="yearly">سنويًا</option></select></label><label class="schedule-date">التاريخ<input id="scheduleDate" type="date"></label></div>
          <div class="form-grid four"><label class="schedule-day" hidden>اليوم<select id="scheduleDay"><option value="0">الأحد</option><option value="1">الاثنين</option><option value="2">الثلاثاء</option><option value="3">الأربعاء</option><option value="4">الخميس</option><option value="5">الجمعة</option><option value="6">السبت</option></select></label><label class="schedule-dom" hidden>يوم الشهر<input id="scheduleDayOfMonth" type="number" min="1" max="31" value="1"></label><label class="schedule-month" hidden>الشهر<select id="scheduleMonth">${Array.from({ length: 12 }, (_, index) => `<option value="${index + 1}">${index + 1}</option>`).join('')}</select></label><label>نوع الملفات<select id="scheduleMediaMode"><option value="selected">الملفات المحددة فقط</option><option value="cycle">دورة الصور تلقائيًا</option></select></label><label class="toggle-box"><input id="scheduleGroupsEnabled" type="checkbox" checked><span>تشغيل على المجموعات</span></label></div>
          <div class="form-grid two"><label>نص الموعد<input id="scheduleText" placeholder="إن كان فارغًا سيستخدم نص الإرسال"></label><label>نص بعد الملف<input id="schedulePostText" placeholder="اختياري"></label></div>
          <div class="action-bar"><button class="btn primary" id="scheduleBtn">${state.editingTaskId ? 'حفظ تعديل الموعد' : 'حفظ الموعد'}</button><button class="btn" id="cancelScheduleEditBtn" type="button" ${state.editingTaskId ? '' : 'hidden'}>إلغاء التعديل</button></div>
        </details>
        <div class="schedule-list">${tasks.length ? tasks.map(taskRow).join('') : '<div class="empty">لا توجد مواعيد محفوظة بعد. افتح «إنشاء موعد إرسال جديد» لإضافة أول موعد.</div>'}</div>
      </section>`;
  }

  function mediaChip(media) {
    const id = media.id || media.filename;
    return `<div class="file-chip"><label><input class="send-media" type="checkbox" value="${esc(id)}" checked><span>${esc(media.name || media.filename || 'ملف')}</span></label><button type="button" class="chip-delete" data-delete-media="${esc(id)}" aria-label="حذف الملف">×</button></div>`;
  }

  function taskRow(task) {
    const next = task.nextRun ? `التالي: ${new Date(task.nextRun).toLocaleString('ar-OM')}` : 'لا يوجد موعد قادم';
    return `<div class="schedule-row"><div><b>${esc(task.name || 'موعد')}</b><small>${esc(scheduleLabel(task))} · ${esc(next)}</small></div><div class="row-actions"><button class="btn small" data-run-task="${esc(task.id)}">تشغيل</button><button class="btn small" data-edit-task="${esc(task.id)}">تعديل</button><button class="btn small" data-toggle-task="${esc(task.id)}">${task.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-task="${esc(task.id)}">حذف</button></div></div>`;
  }

  function scheduleLabel(task) {
    return ({ once: 'مرة واحدة', daily: 'يوميًا', weekly: 'أسبوعيًا', monthly: 'شهريًا', yearly: 'سنويًا' }[task.mode] || task.mode) + ` · ${task.time || ''}`;
  }

  function pageAutomation(data) {
    const a = data.automation || {}, rules = a.rules || [], mutes = a.mutes || [], targets = activeTargets(data);
    const edited = state.editingAutomationRuleId ? rules.find(r => r.id === state.editingAutomationRuleId) : null;
    const rule = edited || {};
    const selectedKeys = new Set(rule.targetKeys || []), perms = a.groupPermissions || {};
    const actionLabels = { 'delete-message':'حذف الرسالة الحالية / القديمة عند الجدولة', 'delete-chat':'حذف المحادثة', 'archive-chat':'أرشفة المحادثة', 'mute-notifications':'كتم الإشعارات', 'unmute-notifications':'إلغاء كتم الإشعارات', 'cleanup-old-messages':'تنظيف الرسائل الأقدم من مدة محددة', log:'تسجيل إجراء فقط' };
    const triggerLabels = { message:'عند وصول رسالة مطابقة', 'group-message':'عند وصول رسالة في مجموعة', 'message-count':'عند تجاوز عدّاد الرسائل', time:'في وقت محدد', 'message-age':'تنظيف الرسائل حسب عمرها' };
    const fmt = value => { try { return new Date(value).toLocaleString('ar-OM'); } catch { return String(value || ''); } };
    const targetSelectOptions = targets.map(t => { const id = chatIdForTarget(t); return id ? `<option value="${esc(id)}">${esc(t.name || id)} · ${esc(typeLabel(t))}</option>` : ''; }).filter(Boolean).join('');
    return `<section class="page-title"><p class="eyebrow">Automation Control Center</p><h1>الأتمتة والتحكم بالوقت والقواعد</h1><p>قواعد زمنية وشرطية، إجراءات للمحادثات والرسائل، كتم مؤقت أو دائم، ومحفزات خاصة بالمجموعات. كل القواعد محفوظة داخل الجلسة الحالية.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>${edited ? 'تعديل قاعدة أتمتة' : 'إنشاء قاعدة أتمتة'}</h2><p>اختر الحدث والشرط والإجراء بدقة. القواعد مرتبة حسب الأولوية.</p></div></div>
          <details class="section-editor" id="automationRuleDisclosure" ${edited ? 'open' : ''}><summary>${edited ? 'تعديل قاعدة الأتمتة' : '＋ إنشاء قاعدة أتمتة'}</summary><form id="automationRuleForm">
            <div class="form-grid two"><label>اسم القاعدة<input id="autoRuleName" maxlength="100" required value="${esc(rule.name || '')}" placeholder="مثال: تنظيف نهاية اليوم"></label><label>الأولوية<input id="autoRulePriority" type="number" min="-1000" max="1000" value="${Number(rule.priority || 0)}"></label>
              <label>المحفّز<select id="autoRuleTrigger"><option value="message" ${rule.triggerType === 'message' || !rule.triggerType ? 'selected' : ''}>رسالة جديدة</option><option value="group-message" ${rule.triggerType === 'group-message' ? 'selected' : ''}>رسالة مجموعة</option><option value="message-count" ${rule.triggerType === 'message-count' ? 'selected' : ''}>عداد الرسائل</option><option value="time" ${rule.triggerType === 'time' ? 'selected' : ''}>وقت / تكرار</option><option value="message-age" ${rule.triggerType === 'message-age' ? 'selected' : ''}>عمر الرسائل (تنظيف مجدول)</option></select></label>
              <label>نوع المطابقة<select id="autoRuleMatch"><option value="any" ${rule.matchMode === 'any' || !rule.matchMode ? 'selected' : ''}>أي رسالة</option><option value="contains" ${rule.matchMode === 'contains' ? 'selected' : ''}>تحتوي العبارة</option><option value="starts" ${rule.matchMode === 'starts' ? 'selected' : ''}>تبدأ بالعبارة</option><option value="ends" ${rule.matchMode === 'ends' ? 'selected' : ''}>تنتهي بالعبارة</option><option value="exact" ${rule.matchMode === 'exact' ? 'selected' : ''}>مطابقة تامة</option><option value="regex" ${rule.matchMode === 'regex' ? 'selected' : ''}>Regex</option></select></label>
            </div>
            <label>العبارة أو النمط<input id="autoRulePattern" maxlength="500" value="${esc(rule.pattern || '')}" placeholder="مثال: مرحبا"></label>
            <div class="form-grid three"><label>الإجراء<select id="autoRuleAction">${Object.entries(actionLabels).map(([k,v]) => `<option value="${k}" ${rule.action === k || (!rule.action && k === 'log') ? 'selected' : ''}>${v}</option>`).join('')}</select></label><label>نطاق الأهداف<select id="autoRuleTargetMode"><option value="current" ${rule.targetMode === 'current' || !rule.targetMode ? 'selected' : ''}>المحادثة الحالية</option><option value="selected" ${rule.targetMode === 'selected' ? 'selected' : ''}>أهداف محددة</option><option value="all" ${rule.targetMode === 'all' ? 'selected' : ''}>كل الأشخاص والمجموعات</option></select></label><label>مهلة منع التكرار (ثانية)<input id="autoRuleCooldown" type="number" min="0" max="86400" value="${Number(rule.cooldownSec || 0)}"></label></div>
            <div class="form-grid three"><label>حدّ الرسائل<input id="autoRuleThreshold" type="number" min="1" max="100000000" value="${Number(rule.threshold || 50)}"></label><label>نطاق العدّاد<select id="autoRuleCountScope"><option value="chat" ${rule.countScope !== 'session' ? 'selected' : ''}>لكل محادثة</option><option value="session" ${rule.countScope === 'session' ? 'selected' : ''}>كل الجلسة</option></select></label><label>عمر الرسائل (ساعة)<input id="autoRuleAgeHours" type="number" min="1" max="8760" value="${Number(rule.ageHours || 24)}"></label></div>
            <div class="form-grid four"><label>وقت التشغيل<input id="autoRuleTime" type="time" required value="${esc(rule.time || '22:00')}"></label><label>التكرار<select id="autoRuleMode"><option value="daily" ${rule.mode === 'daily' || !rule.mode ? 'selected' : ''}>يومي</option><option value="weekly" ${rule.mode === 'weekly' ? 'selected' : ''}>أسبوعي</option><option value="monthly" ${rule.mode === 'monthly' ? 'selected' : ''}>شهري</option><option value="yearly" ${rule.mode === 'yearly' ? 'selected' : ''}>سنوي</option><option value="once" ${rule.mode === 'once' ? 'selected' : ''}>مرة واحدة</option></select></label><label>تاريخ مرة واحدة<input id="autoRuleDate" type="date" value="${esc(rule.date || '')}"></label><label>اليوم الأسبوعي<select id="autoRuleDay">${['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'].map((v,i)=>`<option value="${i}" ${Number(rule.day ?? 5) === i ? 'selected' : ''}>${v}</option>`).join('')}</select></label></div>
            <div class="form-grid four"><label>يوم الشهر<input id="autoRuleDayOfMonth" type="number" min="1" max="31" value="${Number(rule.dayOfMonth || 1)}"></label><label>الشهر السنوي<input id="autoRuleMonth" type="number" min="1" max="12" value="${Number(rule.month || 1)}"></label><label>الحد الأدنى للرسائل<input id="autoRuleMinCount" type="number" min="0" value="${Number(rule.minMessageCount || 0)}"></label><label>الحد الأقصى للرسائل<input id="autoRuleMaxCount" type="number" min="0" value="${Number(rule.maxMessageCount || 0)}"></label></div>
            <div class="form-grid two"><label>شرط إضافي: تحتوي الرسالة<input id="autoRuleConditionContains" value="${esc(rule.conditionContains || '')}" placeholder="اختياري"></label><label>محادثات إضافية (JID، كل سطر معرّف)<textarea id="autoRuleChatIds" rows="2" placeholder="120363...@g.us">${esc((rule.targetChatIds || []).join('\n'))}</textarea></label></div>
            <div class="automation-target-picker"><b>الأهداف المحفوظة</b><small>تُستخدم عندما يكون نطاق الأهداف «أهداف محددة» أو «كل الأهداف».</small><div class="target-list">${targets.length ? targets.map(t => `<label class="target-row"><input type="checkbox" class="automation-target" value="${esc(t.key)}" ${selectedKeys.has(t.key) ? 'checked' : ''}><span class="target-mark ${t.type === 'group' ? 'group' : 'recipient'}">${t.type === 'group' ? '◆' : '●'}</span><span class="target-main"><b>${esc(t.name || t.gid || t.phone || 'هدف')}</b><small>${esc(typeLabel(t))} · ${esc(chatIdForTarget(t) || '')}</small></span></label>`).join('') : '<div class="empty">أضف أشخاصًا أو مجموعات أولًا.</div>'}</div></div>
            <div class="form-grid two"><label class="toggle-box"><input id="autoRuleMutePermanent" type="checkbox" ${rule.mutePermanent ? 'checked' : ''}><span>كتم دائم عند تنفيذ القاعدة</span></label><label>مدة الكتم بالدقائق<input id="autoRuleMuteMinutes" type="number" min="1" max="525600" value="${Number(rule.muteMinutes || 60)}"></label></div>
            <div class="toggle-list"><label class="toggle-row"><input id="autoRuleRepeatCount" type="checkbox" ${rule.repeatCount ? 'checked' : ''}><span><b>إعادة التشغيل عند كل مضاعف للحد</b><small>مثل 50 و100 و150 رسالة بدل تشغيلها مرة واحدة.</small></span></label><label class="toggle-row"><input id="autoRuleRequireAdmin" type="checkbox" ${rule.requireGroupAdmin ? 'checked' : ''}><span><b>اشتراط أن يكون المرسل مشرف مجموعة</b><small>يعتمد على بيانات المشرفين التي حصل عليها WhatsApp.</small></span></label><label class="toggle-row"><input id="autoRuleDeleteEveryone" type="checkbox" ${rule.deleteForEveryone ? 'checked' : ''}><span><b>طلب الحذف لدى الجميع</b><small>قد يرفض WhatsApp الطلب بسبب الصلاحيات أو القيود الزمنية؛ الافتراضي حذف من حسابك فقط.</small></span></label><label class="toggle-row"><input id="autoRuleConfirmDestructive" type="checkbox" ${rule.confirmDestructive ? 'checked' : ''}><span><b>أؤكد تنفيذ الحذف أو تنظيف الرسائل</b><small>مطلوب صراحة للإجراءات التي قد تزيل بيانات.</small></span></label></div>
            <div class="action-bar"><button class="btn primary" type="submit">${edited ? 'حفظ التعديلات' : 'إنشاء القاعدة'}</button>${edited ? '<button class="btn" id="cancelAutoRuleEdit" type="button">إلغاء التعديل</button>' : ''}</div>
          </form></details>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>صلاحيات الأتمتة في المجموعات</h2><p>العمليات الحساسة متوقفة افتراضيًا. اضبطها حسب إدارة المالك.</p></div></div><div class="toggle-list">
          ${[['allowDeleteMessage','السماح بحذف الرسائل من المجموعات'],['allowDeleteChat','السماح بحذف محادثات المجموعات من القائمة'],['allowArchive','السماح بأرشفة المجموعات'],['allowMute','السماح بكتم مجموعات'],['adminsOnly','تطبيق محفزات رسائل المجموعة على المشرفين فقط']].map(([k,label]) => `<label class="toggle-row"><input type="checkbox" class="automation-permission" data-permission="${k}" ${perms[k] ? 'checked' : ''}><span><b>${label}</b></span></label>`).join('')}
          </div><div class="action-bar"><button id="saveAutomationPermissions" class="btn primary">حفظ الصلاحيات</button></div>
          <div class="divider-line"></div><div class="panel-head"><div><h2>قواعد الأتمتة</h2><p>${rules.length} قاعدة محفوظة · ${rules.filter(r=>r.enabled !== false).length} مفعّلة</p></div></div>
          <div class="schedule-list">${rules.length ? rules.map(r => `<div class="schedule-row"><div><b>${esc(r.name)}</b><small>${esc(triggerLabels[r.triggerType] || r.triggerType)} · ${esc(actionLabels[r.action] || r.action)} · أولوية ${Number(r.priority || 0)}${['time','message-age'].includes(r.triggerType) ? ` · ${esc(r.time || '')} · ${esc(r.mode || 'daily')}` : ''}${r.lastRunKey ? ` · آخر تشغيل: ${esc(r.lastRunKey.split('|').slice(-2).join(' '))}` : ''}</small><small class="mini-state ${r.enabled === false ? 'off' : ''}">${r.enabled === false ? 'متوقفة' : 'مفعّلة'}</small></div><div class="row-actions">${['time','message-age'].includes(r.triggerType) ? `<button class="btn small" data-run-auto-rule="${esc(r.id)}">تشغيل</button>` : ''}<button class="btn small" data-edit-auto-rule="${esc(r.id)}">تعديل</button><button class="btn small" data-toggle-auto-rule="${esc(r.id)}">${r.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-auto-rule="${esc(r.id)}">حذف</button></div></div>`).join('') : '<div class="empty">لم تنشئ قواعد أتمتة بعد.</div>'}</div>
        </article>
      </section>
      <section class="content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>كتم الإشعارات</h2><p>كتم جهة اتصال أو مجموعة لمدة محددة أو بلا مدة حتى تلغيها يدويًا.</p></div></div><form id="automationMuteForm"><label>هدف محفوظ<select id="muteSavedTarget"><option value="">اختر جهة اتصال أو مجموعة (اختياري)</option>${targetSelectOptions}</select></label><label>معرّف المحادثة<input id="muteChatId" required placeholder="رقم@c.us أو GID@ g.us"></label><div class="form-grid two"><label>المدة<select id="muteMode"><option value="temporary">مؤقت</option><option value="permanent">دائم حتى الإلغاء اليدوي</option></select></label><label>الدقائق<input id="muteMinutes" type="number" min="1" max="525600" value="60"></label></div><div class="action-bar"><button class="btn primary" type="submit">كتم المحادثة</button></div></form>
          <div class="schedule-list">${mutes.length ? mutes.slice().reverse().map(m => `<div class="schedule-row"><div><b>${esc(m.chatName || m.chatId)}</b><small>${m.chatType === 'group' ? 'مجموعة' : 'محادثة خاصة'} · ${m.mode === 'permanent' ? 'دائم' : `حتى ${esc(fmt(m.expiresAt))}`}</small><small class="mini-state ${m.enabled === false ? 'off' : ''}">${m.enabled === false ? 'منتهٍ أو ملغى' : 'مفعّل'}</small></div><div class="row-actions">${m.enabled !== false ? `<button class="btn small" data-unmute-record="${esc(m.id)}">إلغاء الكتم</button>` : ''}<button class="btn danger small" data-delete-mute="${esc(m.id)}">حذف السجل</button></div></div>`).join('') : '<div class="empty">لا توجد سجلات كتم محفوظة.</div>'}</div>
        </article><article class="panel"><div class="panel-head"><div><h2>سجل التنفيذ</h2><p>عمليات الأتمتة ونتائجها الأخيرة.</p></div></div><div class="schedule-list">${(a.recent || []).slice().reverse().slice(0,30).map(x => `<div class="schedule-row"><div><b>${esc(x.name || x.action || 'إجراء آلي')}</b><small>${esc(fmt(x.at))} · ${esc(x.action || '')}</small><small class="mini-state ${x.ok ? '' : 'off'}">${x.ok ? 'نجح' : 'تعذر'}</small>${x.error ? `<small>${esc(x.error)}</small>` : ''}</div></div>`).join('') || '<div class="empty">لا توجد عمليات مسجلة بعد.</div>'}</div><div class="action-bar"><button id="refreshAutomationBtn" class="btn">تحديث السجل</button></div></article></section>`;
  }

  function whatsappContactRows() {
    const contacts = Array.isArray(state.whatsappContacts) ? state.whatsappContacts : [];
    const needle = String(state.whatsappContactFilter || '').trim().toLocaleLowerCase('ar');
    const visible = contacts.filter(contact => `${contact.name || ''} ${contact.pushname || ''} ${contact.notifyName || ''} ${contact.digits || ''} ${contact.jid || ''}`.toLocaleLowerCase('ar').includes(needle));
    if (!visible.length) return `<div class="empty">${contacts.length ? 'لا توجد جهات تطابق البحث.' : 'لم يتم العثور على جهات رقمية قابلة للمزامنة.'}</div>`;
    return visible.map(contact => {
      const displayName = contact.name || contact.pushname || contact.notifyName || `+${contact.digits}`;
      const pictureUrl = contact.pictureUrl || `/api/whatsapp/contact-picture?sessionId=${encodeURIComponent(sid())}&jid=${encodeURIComponent(contact.jid)}`;
      const initial = Array.from(String(displayName).trim())[0] || '•';
      const profileName = String(contact.pushname || contact.notifyName || '').trim();
      const nameCaption = contact.isMyContact
        ? (profileName && profileName !== displayName ? `اسم دفتر العناوين · اسم ملف الحساب: ${profileName}` : 'اسم محفوظ في دفتر عناوين WhatsApp')
        : 'الاسم الظاهر في ملف WhatsApp';
      const digits = String(contact.digits || '').replace(/\D/g, '');
      const existing = (state.data?.recipients || []).find(person => String(person.whatsappJid || '').toLowerCase() === String(contact.jid).toLowerCase() || digits && String(person.digits || person.e164 || person.phone || '').replace(/\D/g, '') === digits);
      const actionLabel = existing ? 'تحديث الصورة والبيانات' : 'إضافة إلى الإرسال';
      return `<div class="wa-contact-option"><input type="checkbox" aria-label="تحديد ${esc(displayName)}" data-wa-contact-select="${esc(contact.jid)}" ${state.whatsappContactsSelected.has(contact.jid) ? 'checked' : ''}><span class="wa-contact-avatar-wrap"><span class="wa-contact-avatar">${esc(initial)}</span><img class="wa-contact-photo" src="${esc(pictureUrl)}" alt="صورة ${esc(displayName)}" loading="lazy" decoding="async" onerror="if(this.dataset.photoRetry!=='1'){this.dataset.photoRetry='1';const u=new URL(this.src,location.href);u.searchParams.set('refresh','1');u.searchParams.set('retry',String(Date.now()));setTimeout(()=>{this.src=u.href;},650);}else{this.hidden=true;}"></span><span class="wa-contact-main"><b>${esc(displayName)}</b><small>${esc(nameCaption)} · +${esc(contact.digits)}</small></span><button type="button" class="btn small wa-contact-import" data-import-wa-contact="${esc(contact.jid)}">${actionLabel}</button></div>`;
    }).join('');
  }

  function pagePeople(data) {
    const filter = state.peopleFilter.trim().toLocaleLowerCase('ar');
    const allRecipients = data.recipients || [];
    const validIds = new Set(allRecipients.map(person => String(person.id)));
    for (const id of state.selectedRecipientIds) if (!validIds.has(String(id))) state.selectedRecipientIds.delete(id);
    const recipients = allRecipients.filter((item) => `${item.name || ''} ${item.international || ''} ${item.e164 || ''}`.toLocaleLowerCase('ar').includes(filter));
    const selectedVisible = recipients.filter(person => state.selectedRecipientIds.has(String(person.id))).length;
    return `<section class="page-title"><p class="eyebrow">الأشخاص</p><h1>جهات الإرسال</h1><p>الأرقام منفصلة حسب الجلسة الحالية، وتدعم رموز الدول تلقائيًا. يمكنك تحديد عدة أشخاص وحذفهم دفعة واحدة أو ضبط رد مستقل لكل شخص.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>إضافة شخص</h2><p>اختر الدولة أو اكتب الرقم بصيغة دولية مباشرة.</p></div></div>
          <div class="form-grid three"><label>الاسم<input id="recipientName" placeholder="اسم الشخص"></label><label>الدولة<select id="recipientCountry">${countryOptions('OM')}</select></label><label>رقم الهاتف<input id="recipientPhone" inputmode="tel" placeholder="+968 9xxxxxxx"></label></div>
          <div id="phonePreview" class="inline-status">اكتب الرقم لمراجعته.</div>
          <div class="action-bar"><button class="btn primary" id="addRecipientBtn">إضافة الشخص</button></div>
          <details class="advanced-panel"><summary>إضافة قائمة أرقام</summary><p>سطر لكل رقم: الاسم|الرقم</p><textarea id="bulkRecipients" rows="5" placeholder="أحمد|+96890000000\nSara|+966500000000"></textarea><button class="btn" id="bulkAddBtn">إضافة القائمة</button></details>
          <details class="advanced-panel whatsapp-sync-panel" id="whatsappContactsDisclosure" ${state.whatsappContactsOpen ? 'open' : ''}><summary>استدعاء ومزامنة جهات WhatsApp</summary>
            <p>استدعِ الأسماء الحالية وصور الحساب المتاحة، ثم اضغط «إضافة إلى الإرسال» بجانب أي شخص أو حدّد عدة أشخاص واضغط زر الإضافة أسفل القائمة. تُحفظ الجهة فورًا في المشروع وقائمة الإرسال؛ ولا تتغير الأسماء المحلية الحالية افتراضيًا.</p>
            <div class="action-bar"><button type="button" class="btn primary" id="loadWhatsAppContactsBtn" ${state.whatsappContactsBusy ? 'disabled' : ''}>${state.whatsappContactsBusy ? 'جارٍ الاستدعاء…' : state.whatsappContacts ? 'تحديث جهات WhatsApp' : 'استدعاء جهات WhatsApp'}</button><span class="sync-connection-note">${state.data?.whatsapp?.ready ? 'متصل' : 'اتصل بواتساب أولًا'}</span></div>
            <div id="whatsappContactsStatus" class="inline-status">${state.whatsappContactsBusy ? 'يتم استدعاء جهات الاتصال…' : state.whatsappContacts ? `تم العثور على ${state.whatsappContacts.length} جهة رقمية.` : 'اضغط «استدعاء جهات WhatsApp» لتحميل جهات الحساب المتصل.'}</div>
            ${Array.isArray(state.whatsappContacts) ? `<div class="wa-contact-tools"><input id="whatsappContactFilter" value="${esc(state.whatsappContactFilter)}" placeholder="ابحث في جهات WhatsApp…"><div class="action-bar"><button type="button" id="selectAllWhatsAppContacts" class="btn small">تحديد الظاهر</button><button type="button" id="clearWhatsAppContacts" class="btn small">إلغاء التحديد</button><span class="release-pill">محدد: <b id="whatsappSelectedCount">${state.whatsappContactsSelected.size}</b></span></div></div>
              <div class="wa-contact-list" id="whatsappContactsList">${whatsappContactRows()}</div>
              <div class="wa-sync-options"><div class="inline-status">سيتم إضافة الجهات الجديدة تلقائيًا إلى قائمة الإرسال، وتحديث بيانات الجهات الموجودة دون إنشاء تكرار.</div><label class="toggle-row"><input id="syncWhatsAppUpdateNames" type="checkbox"><span><b>تحديث الأسماء المحلية بأسماء WhatsApp</b><small>اتركه مغلقًا للمحافظة على الأسماء التي كتبتها في المشروع.</small></span></label><label class="toggle-row"><input id="syncWhatsAppUpdatePictures" type="checkbox" checked><span><b>مزامنة صور الملف الشخصي</b><small>حتى 100 جهة في كل دفعة؛ الصور تحفظ محليًا داخل الجلسة الحالية.</small></span></label></div>
              <div class="action-bar"><button type="button" id="syncWhatsAppContactsBtn" class="btn primary" ${state.whatsappContactsSelected.size ? '' : 'disabled'}>إضافة المحدد إلى قائمة الإرسال (${state.whatsappContactsSelected.size})</button></div>` : ''}
          </details>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الأشخاص المحفوظون</h2><p>${recipients.length} من ${allRecipients.length} شخص · محدد ${state.selectedRecipientIds.size}</p></div><span class="release-pill">${allRecipients.length} محفوظ</span></div>
          <input id="peopleSearch" value="${esc(state.peopleFilter)}" placeholder="بحث بالاسم أو الرقم...">
          <div class="people-selection-bar"><label class="people-select-all"><input id="selectVisiblePeople" type="checkbox" ${recipients.length && selectedVisible === recipients.length ? 'checked' : ''} ${recipients.length ? '' : 'disabled'}><span>تحديد الأشخاص الظاهرين (${selectedVisible}/${recipients.length})</span></label><button class="btn danger small" id="deleteSelectedPeopleBtn" ${state.selectedRecipientIds.size ? '' : 'disabled'}>حذف المحدد (${state.selectedRecipientIds.size})</button></div>
          <div class="people-list">${recipients.length ? recipients.map(personRow).join('') : '<div class="empty">لا توجد نتائج.</div>'}</div>
        </article>
      </section>`;
  }

  function personalRuleEditor(rule = {}, index = 0) {
    const modes = [['contains','تحتوي على'],['exact','تطابق تمامًا'],['startsWith','تبدأ بـ'],['endsWith','تنتهي بـ'],['any','أي رسالة']];
    return `<div class="personal-rule-row" data-person-rule-row data-rule-id="${esc(rule.id || '')}">
      <div class="personal-rule-heading"><b>قاعدة شخصية ${index + 1}</b><button type="button" class="btn danger small" data-delete-person-rule>حذف القاعدة</button></div>
      <div class="form-grid two"><label>اسم القاعدة<input data-person-rule-name maxlength="100" value="${esc(rule.name || `قاعدة ${index + 1}`)}" required></label><label>نوع المطابقة<select data-person-rule-match>${modes.map(([value,label]) => `<option value="${value}" ${String(rule.match || 'contains') === value ? 'selected' : ''}>${label}</option>`).join('')}</select></label></div>
      <label>نص المطابقة<input data-person-rule-value maxlength="500" value="${esc(rule.value || '')}" placeholder="مثال: سعر المنتج"></label>
      <label>الرد الذي سيُرسل<textarea data-person-rule-reply rows="3" maxlength="4000" required placeholder="اكتب الرد، ويمكنك استخدام {{sender}} و{{message}} و{{chat}} و{{time}}">${esc(rule.reply || '')}</textarea></label>
      <label class="toggle-box"><input data-person-rule-enabled type="checkbox" ${rule.enabled === false ? '' : 'checked'}><span>القاعدة مفعّلة</span></label>
    </div>`;
  }

  function personRow(person) {
    const profile = person.replyProfile || {};
    const mode = ['inherit', 'custom', 'disabled'].includes(profile.mode) ? profile.mode : 'inherit';
    const rules = Array.isArray(profile.rules) ? profile.rules.slice(0, 30) : [];
    const pictureUrl = person.whatsappJid
      ? `/api/whatsapp/contact-picture?sessionId=${encodeURIComponent(sid())}&jid=${encodeURIComponent(person.whatsappJid)}`
      : (person.whatsappProfilePhoto ? `/profile/${encodeURIComponent(person.whatsappProfilePhoto)}?sessionId=${encodeURIComponent(sid())}` : '');
    const waName = person.whatsappPushname || person.whatsappName || '';
    const waBookName = person.whatsappName || ''; 
    const initial = Array.from(String(person.name || waName || '•').trim())[0] || '•';
    return `<article class="person-record" data-person-record="${esc(person.id)}"><div class="person-row"><label class="person-select-label" aria-label="تحديد ${esc(person.name || 'الشخص')}"><input type="checkbox" class="person-select" data-person-select="${esc(person.id)}" ${state.selectedRecipientIds.has(String(person.id)) ? 'checked' : ''}><span class="sr-only">تحديد الشخص</span></label><div class="person-main"><span class="person-avatar-wrap"><span class="person-avatar-fallback">${esc(initial)}</span>${pictureUrl ? `<img class="person-profile-photo" src="${esc(pictureUrl)}" alt="صورة ${esc(waName || person.name || 'الشخص')}" loading="lazy" decoding="async" onerror="if(this.dataset.photoRetry!=='1'){this.dataset.photoRetry='1';const u=new URL(this.src,location.href);u.searchParams.set('refresh','1');u.searchParams.set('retry',String(Date.now()));setTimeout(()=>{this.src=u.href;},650);}else{this.hidden=true;}">` : ''}</span><b>${esc(person.name || waName || 'بدون اسم')}</b><small>${esc(person.international || person.e164 || person.phone || '')} · ${esc(person.country || '')}</small>${waName && waName !== person.name ? `<small class="whatsapp-live-name">اسم ملف WhatsApp: ${esc(waName)}</small>` : ''}${waBookName && waBookName !== person.name && waBookName !== waName ? `<small class="whatsapp-live-name">اسم دفتر العناوين: ${esc(waBookName)}</small>` : ''}<small class="personal-reply-status">${mode === 'custom' ? `ردود شخصية (${rules.length} قاعدة)` : mode === 'disabled' || profile.enabled === false ? 'الرد الشخصي متوقف' : 'يرث القواعد العامة'}</small></div><span class="mini-state ${person.enabled === false ? 'off' : ''}">${person.enabled === false ? 'متوقف' : 'مفعّل'}</span><div class="row-actions"><button class="btn small" data-toggle-person="${esc(person.id)}">${person.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-person="${esc(person.id)}">حذف</button></div></div>
      <details class="personal-reply-editor"><summary>إعداد الرد التلقائي لهذا الشخص</summary><form class="personal-reply-form" data-person-reply-form="${esc(person.id)}">
        <div class="form-grid two"><label>وضع الرد<select data-person-profile-mode><option value="inherit" ${mode === 'inherit' ? 'selected' : ''}>استخدم القواعد العامة</option><option value="custom" ${mode === 'custom' ? 'selected' : ''}>قواعد وردود خاصة</option><option value="disabled" ${mode === 'disabled' ? 'selected' : ''}>تعطيل الرد لهذا الشخص</option></select></label><label>فترة التهدئة بين الردود (ثانية)<input data-person-profile-cooldown type="number" min="0" max="86400" value="${Number.isFinite(Number(profile.cooldownSec)) ? Math.max(0, Math.min(86400, Number(profile.cooldownSec))) : 45}"></label></div>
        <label class="toggle-box"><input data-person-profile-enabled type="checkbox" ${profile.enabled === false ? '' : 'checked'}><span>السماح بالرد التلقائي لهذا الشخص</span></label>
        <label>الرد الافتراضي عند عدم تطابق قاعدة شخصية<textarea data-person-profile-default rows="3" maxlength="4000" placeholder="اتركه فارغًا لاستخدام خيار الرجوع إلى القواعد العامة">${esc(profile.defaultReply || '')}</textarea></label>
        <label class="toggle-box"><input data-person-profile-fallback type="checkbox" ${profile.fallbackToGlobal === false ? '' : 'checked'}><span>الرجوع إلى القواعد العامة إذا لم تطابق قاعدة شخصية ولم يوجد رد افتراضي</span></label>
        <div class="personal-rules-head"><div><b>قواعد الرد الخاصة</b><small>حد أقصى 30 قاعدة للشخص. الأنواع مدعومة محليًا ولا تحتاج API خارجي.</small></div><span class="release-pill"><span data-person-rule-count>${rules.length}</span>/30</span></div>
        <div class="personal-rules-list" data-person-rules>${rules.map((rule,i)=>personalRuleEditor(rule,i)).join('') || '<div class="empty" data-person-rules-empty>لا توجد قواعد شخصية؛ يمكن استخدام الرد الافتراضي أو القواعد العامة.</div>'}</div>
        <div class="action-bar"><button type="button" class="btn" data-add-person-rule>＋ إضافة قاعدة</button><button type="submit" class="btn primary">حفظ إعداد الرد الشخصي</button></div>
      </form></details></article>`;
  }

  function pageGroups(data) {
    const filter = state.groupFilter.trim().toLocaleLowerCase('ar');
    const groups = (data.groups || []).filter((group) => `${group.name || ''} ${group.gid || ''}`.toLocaleLowerCase('ar').includes(filter));
    const current = state.selectedGroup && (data.groups || []).find((group) => group.gid === state.selectedGroup);
    return `<section class="page-title"><p class="eyebrow">المجموعات</p><h1>المجموعات هذه الجلسة</h1><p>اكتشاف وربط وتحليل وحفظ المجموعة في الجلسة الحالية، ثم استخدامها كهدف مستقل في الإرسال والتفاعل.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>ربط أو اكتشاف</h2><p>ضع GID أو رابط دعوة وسيُحلل تلقائيًا.</p></div></div>
          <label>GID أو رابط الدعوة<input id="groupValue" placeholder="120363...@g.us أو chat.whatsapp.com/..." value=""></label>
          <div class="action-bar"><button class="btn primary" id="connectGroupBtn">ربط وتحليل</button><button class="btn" id="discoverGroupsBtn">اكتشاف</button><button class="btn" id="refreshGroupsBtn">تحديث الكل</button></div>
          <div id="groupResult" class="result-box">سيتم عرض نتيجة التحليل هنا.</div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>المجموعات المحفوظة</h2><p>${groups.length} مجموعة.</p></div></div><input id="groupSearch" value="${esc(state.groupFilter)}" placeholder="ابحث باسم المجموعة أو GID..."><div class="group-list">${groups.length ? groups.map((group) => groupRow(group, current?.gid === group.gid)).join('') : '<div class="empty">لا توجد مجموعات محفوظة.</div>'}</div></article>
      </section>
      <section class="panel"><div class="panel-head"><div><h2>تفاصيل المجموعة</h2><p>اعرض البيانات الكاملة المتاحة، ثم استخدم المجموعة مباشرة في الإرسال.</p></div></div><div id="groupDetail">${groupDetails(current)}</div></section>`;
  }

  function groupRow(group, selected) {
    return `<article class="group-row ${selected ? 'selected' : ''}"><div class="group-main"><b>${esc(group.name || group.gid)}</b><small>${esc(group.gid || '')}</small></div><div class="group-meta"><span>${Number(group.participantsCount || group.participants?.length || 0)} عضو</span><span>${Number(group.admins?.length || 0)} مشرف</span><span class="mini-state ${group.enabled === false ? 'off' : ''}">${group.enabled === false ? 'متوقفة' : 'مفعّلة'}</span></div><div class="row-actions"><button class="btn small" data-show-group="${esc(group.gid)}">عرض</button><button class="btn small" data-send-group="${esc(group.id)}">إرسال</button><button class="btn small" data-copy-group="${esc(group.gid)}">نسخ GID</button><button class="btn small" data-toggle-group="${esc(group.id)}">${group.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-group="${esc(group.id)}">حذف</button></div></article>`;
  }

  function groupDetails(group) {
    if (!group) return '<div class="empty">اختر مجموعة من القائمة.</div>';
    const members = Array.isArray(group.participants) ? group.participants : [];
    const admins = Array.isArray(group.admins) ? group.admins : members.filter((item) => item.admin);
    return `<div class="info-grid six"><div><span>الاسم</span><b>${esc(group.name || '')}</b></div><div><span>GID</span><b class="mono">${esc(group.gid || '')}</b></div><div><span>الأعضاء</span><b>${Number(group.participantsCount || members.length || 0)}</b></div><div><span>المشرفون</span><b>${admins.length}</b></div><div><span>المالك</span><b class="mono">${esc(group.owner || 'غير متاح')}</b></div><div><span>رمز الدعوة</span><b>${esc(group.inviteCode || 'غير متاح')}</b></div></div><div class="detail-line"><strong>الوصف:</strong> ${esc(group.description || 'لا يوجد وصف')}</div><details class="member-details"><summary>الأعضاء (${members.length})</summary>${members.length ? `<div class="table-wrap"><table><thead><tr><th>#</th><th>الاسم</th><th>المعرف</th><th>الدور</th></tr></thead><tbody>${members.map((member, index) => `<tr><td>${index + 1}</td><td>${esc(member.name || 'بدون اسم')}</td><td class="mono">${esc(member.id || '')}</td><td>${member.admin ? 'مشرف' : 'عضو'}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لم يوفر WhatsApp قائمة الأعضاء.</div>'}</details>`;
  }

  function pageInteraction(data) {
    const interaction = data.interaction || {};
    const rules = interaction.rules || [];
    const counters = interaction.counterTriggers || [];
    const counterState = interaction.counterState || {};
    const recent = interaction.recent || [];
    const selected = new Set((data.settings?.interactionChatIds || []).map(String));
    const candidates = activeTargets(data);
    const conflictMode = data.settings?.interactionConflictMode || 'first-match';
    const threshold = Number(data.settings?.interactionSimilarityThreshold ?? .68);
    return `<section class="page-title"><p class="eyebrow">التفاعل</p><h1>محرك الردود الذكي</h1><p>ردود متغيرة، مطابقة سياقية وتقريبية، أولوية للأوامر، ومنع للتعارض داخل كل جلسة.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>تحكم المالك</h2><p>كل الميزات قابلة للإيقاف والتخصيص محليًا.</p></div></div>
          <div class="toggle-list"><label class="toggle-row"><input id="interactionEnabled" type="checkbox" ${data.settings?.interactionEnabled !== false ? 'checked' : ''}><span><b>التفاعل التلقائي</b><small>تشغيل أو إيقاف محرك القواعد والعدادات.</small></span></label><label class="toggle-row"><input id="groupAssistantEnabled" type="checkbox" ${data.settings?.groupAssistantEnabled !== false ? 'checked' : ''}><span><b>مساعد المجموعات</b><small>أوامر GID والتحليل داخل المجموعات.</small></span></label><label class="toggle-row"><input id="interactionIgnoreOwn" type="checkbox" ${data.settings?.interactionIgnoreOwn !== false ? 'checked' : ''}><span><b>منع حلقات الرد</b><small>تجاهل رسائل الحساب ما عدا إدخال النفس الصريح المدعوم.</small></span></label></div>
          <div class="action-bar"><button class="btn primary" id="saveInteractionSettings">حفظ إعدادات المحرك</button></div>
          <details class="advanced-panel"><summary>المطابقة والتعارض والنطاق</summary><div class="form-grid two"><label>سياسة تعارض الردود<select id="interactionConflictMode"><option value="first-match" ${conflictMode==='first-match'?'selected':''}>أول قاعدة ناجحة حسب الأولوية</option><option value="highest-score" ${conflictMode==='highest-score'?'selected':''}>أعلى دقة مطابقة وأولوية</option><option value="allow-multiple" ${conflictMode==='allow-multiple'?'selected':''}>السماح بعدة إجراءات غير متعارضة</option></select></label><label>عتبة التشابه <output id="interactionSimilarityOutput">${Math.round(threshold*100)}%</output><input id="interactionSimilarityThreshold" type="range" min="0.30" max="0.98" step="0.01" value="${threshold}"></label><label>النطاق العام<select id="interactionScope"><option value="all" ${data.settings?.interactionScope === 'all' ? 'selected' : ''}>كل المحادثات</option><option value="groups" ${data.settings?.interactionScope === 'groups' ? 'selected' : ''}>المجموعات</option><option value="private" ${data.settings?.interactionScope === 'private' ? 'selected' : ''}>الخاص</option><option value="selected" ${data.settings?.interactionScope === 'selected' ? 'selected' : ''}>أهداف محددة</option></select></label><label>الحد الأقصى للأفعال/الدقيقة<input id="maxActionsPerMinute" type="number" min="1" max="1000" value="${Number(data.settings?.maxActionsPerMinute || 20)}"></label><label class="toggle-box"><input id="interactionQuietEnabled" type="checkbox" ${data.settings?.interactionQuietEnabled ? 'checked' : ''}><span>فترة هدوء</span></label><label>من<input id="interactionQuietStart" type="time" value="${esc(data.settings?.interactionQuietStart || '23:00')}"></label><label>إلى<input id="interactionQuietEnd" type="time" value="${esc(data.settings?.interactionQuietEnd || '07:00')}"></label><label>السلوك أثناء الهدوء<select id="interactionQuietAction"><option value="silence" ${(data.settings?.interactionQuietAction || 'silence') === 'silence' ? 'selected' : ''}>لا ترد نهائيًا</option><option value="reply" ${data.settings?.interactionQuietAction === 'reply' ? 'selected' : ''}>رد برسالة مخصصة</option><option value="rules" ${data.settings?.interactionQuietAction === 'rules' ? 'selected' : ''}>شغّل القواعد المسموح بها فقط</option></select></label><label>نص رد الهدوء<input id="interactionQuietReply" maxlength="1000" value="${esc(data.settings?.interactionQuietReply || 'أنا في فترة الهدوء الآن، سأرد عليك لاحقًا.')}"></label><label>فاصل تكرار رد الهدوء (ثانية)<input id="interactionQuietCooldownSec" type="number" min="0" max="86400" value="${Number(data.settings?.interactionQuietCooldownSec ?? 300)}"></label></div><div class="help-note">الأوامر النصية التي تبدأ بـ ! أو / تقدم تلقائيًا في الترتيب. «أعلى دقة» يقارن نوع المطابقة وقيمتها والأولوية؛ و«متعدد» يزيل الإجراءات المتطابقة.</div><div class="target-picker"><b>الأهداف المحددة</b>${candidates.length ? candidates.map((target) => `<label><input type="checkbox" class="rule-target" value="${esc(chatIdForTarget(target))}" ${selected.has(chatIdForTarget(target)) ? 'checked' : ''}><span>${esc(target.name || target.gid || target.phone || '')}</span><small>${typeLabel(target)}</small></label>`).join('') : '<div class="empty">لا توجد أهداف في الجلسة.</div>'}</div></details>
        </article>
        <article class="panel"><div class="panel-head"><div><h2 id="ruleEditorTitle">${state.interactionEditingRule ? 'تعديل القاعدة' : 'إنشاء قاعدة رد'}</h2><p>كل سطر في حقل الرد يعد صيغة مستقلة، ويُدوّر المحرك بينها لتجنب التكرار المباشر.</p></div></div>
          <details class="section-editor" id="ruleEditorDisclosure" ${state.interactionEditingRule ? 'open' : ''}><summary>${state.interactionEditingRule ? 'تعديل بيانات القاعدة' : '＋ إنشاء أو تعديل قاعدة رد'}</summary>
          <div class="form-grid two"><label>اسم القاعدة<input id="ruleName" placeholder="ترحيب"></label><label>الحدث<select id="ruleEvent"><option value="message">رسالة</option><option value="reaction">Reaction</option></select></label><label>نوع المطابقة<select id="ruleMatch"><option value="contains">يحتوي على عبارة</option><option value="exact">مطابقة تامة</option><option value="starts">يبدأ بعبارة</option><option value="ends">ينتهي بعبارة</option><option value="regex">Regex</option><option value="similarity">تشابه تقريبي</option><option value="intent">نية الرسالة</option><option value="any">أي رسالة / حدث</option></select></label><label>العبارة أو النية أو Regex<input id="ruleValue" placeholder="مرحبا أو greeting أو !help"></label><label>النطاق<select id="ruleScope"><option value="all">الكل</option><option value="groups">المجموعات</option><option value="private">الخاص</option><option value="selected">أهداف محددة</option></select></label><label>الإجراء<select id="ruleAction"><option value="reply">رد نصي متغير</option><option value="reaction">Reaction</option><option value="both">رد + Reaction</option></select></label></div>
          <div class="form-grid two"><label id="ruleReplyWrap">صيغ الرد — كل رد في سطر<textarea id="ruleReply" rows="5" placeholder="أهلًا {{sender}} ✨&#10;مرحبًا بك يا {{firstName}}&#10;نورتنا {{sender}} 🌟&#10;أهلًا وسهلًا بك!"></textarea><small>متغيرات: {{message}} · {{sender}} · {{firstName}} · {{chat}} · {{time}} · {{count}} · {{lastMessage}} · {{lastIntent}} · {{intent}} · {{day}}</small></label><label id="ruleEmojiWrap">Reaction<input id="ruleEmoji" placeholder="👍"></label></div>
          <div class="preset-row"><span>قوالب جاهزة:</span><button class="btn small" data-rule-preset="welcome">ترحيب</button><button class="btn small" data-rule-preset="help">مساعدة</button><button class="btn small" data-rule-preset="reaction">Reaction</button></div>
          <details class="advanced-panel"><summary>الأولوية والاختبار وجدولة القاعدة</summary><div class="form-grid three"><label>الأولوية<input id="rulePriority" type="number" min="-1000" max="1000" value="10"></label><label>منع التكرار (ثانية)<input id="ruleCooldown" type="number" min="0" max="86400" value="45"></label><label class="toggle-box"><input id="ruleStop" type="checkbox" checked><span>أوقف القواعد التالية بعد نجاح التنفيذ</span></label><label class="toggle-box"><input id="ruleCommandPriority" type="checkbox"><span>اجعلها أمرًا عالي الأولوية</span></label><label>مجموعة تعارض اختيارية<input id="ruleConflictGroup" placeholder="welcome-replies"></label></div><details class="advanced-panel"><summary>جدول تشغيل هذه القاعدة</summary><div class="form-grid three"><label class="toggle-box"><input id="ruleScheduleEnabled" type="checkbox"><span>تفعيل وقت محدد للقاعدة</span></label><label>من الساعة<input id="ruleScheduleStart" type="time" value="09:00"></label><label>إلى الساعة<input id="ruleScheduleEnd" type="time" value="17:00"></label></div><div class="rule-days-grid"><b>أيام التشغيل</b><div class="check-grid"><label><input type="checkbox" class="rule-schedule-day" value="0" checked> الأحد</label><label><input type="checkbox" class="rule-schedule-day" value="1" checked> الاثنين</label><label><input type="checkbox" class="rule-schedule-day" value="2" checked> الثلاثاء</label><label><input type="checkbox" class="rule-schedule-day" value="3" checked> الأربعاء</label><label><input type="checkbox" class="rule-schedule-day" value="4" checked> الخميس</label><label><input type="checkbox" class="rule-schedule-day" value="5" checked> الجمعة</label><label><input type="checkbox" class="rule-schedule-day" value="6" checked> السبت</label></div></div></details><label class="test-field">رسالة الاختبار<textarea id="ruleTestMessage" rows="3" placeholder="اكتب الرسالة التي تريد اختبارها"></textarea></label><label class="test-field">إيموجي الاختبار<input id="ruleTestEmoji" placeholder="👍"></label><div class="action-bar"><button class="btn" id="testRuleBtn">اختبار المطابقة</button></div></details>
          <div class="action-bar"><button class="btn primary" id="addRuleBtn">${state.interactionEditingRule ? 'حفظ التعديلات' : 'حفظ القاعدة'}</button><button class="btn" id="cancelRuleEditBtn" ${state.interactionEditingRule ? '' : 'hidden'}>إلغاء التعديل</button></div></details>
        </article>
      </section>
      <section class="content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>القواعد الحالية</h2><p>${rules.length} قاعدة محفوظة لهذه الجلسة.</p></div></div><div class="rule-list">${rules.length ? rules.map(ruleRow).join('') : '<div class="empty">لا توجد قواعد بعد.</div>'}</div></article><article class="panel"><div class="panel-head"><div><h2>آخر التفاعلات</h2><p>سجل إجراءات المحرك الفعلية.</p></div></div><div class="interaction-list">${recent.length ? recent.slice().reverse().map(interactionRow).join('') : '<div class="empty">لا يوجد تفاعل حتى الآن.</div>'}</div></article></section>
      <section class="panel"><div class="panel-head"><div><h2>عدادات الرسائل والإجراءات التلقائية</h2><p>تمت معالجة <b>${Number(counterState.totalCount || 0).toLocaleString('ar-OM')}</b> رسالة في هذه الجلسة. نفّذ إجراءً عند بلوغ 100 أو 500 أو 1000 أو أي حد يحدده المالك.</p></div><button class="btn small" id="resetCountersBtn">تصفير العدادات</button></div>
        <div class="content-grid two-col"><article><details class="section-editor" id="counterEditorDisclosure" ${state.interactionEditingCounter ? 'open' : ''}><summary>${state.interactionEditingCounter ? 'تعديل محفّز العداد' : '＋ إعداد محفّز عدّاد الرسائل (اختياري)'}</summary><div class="form-grid two"><label>اسم المحفز<input id="counterName" placeholder="مكافأة 100 رسالة"></label><label>عدد الرسائل<input id="counterThreshold" type="number" min="1" max="100000000" value="100"></label><label>نطاق العداد<select id="counterScope"><option value="session">كل الجلسة</option><option value="chat">كل محادثة منفردة</option></select></label><label>الأولوية<input id="counterPriority" type="number" min="-1000" max="1000" value="5"></label><label>نوع الإجراء<select id="counterActionType"><option value="reply">إرسال رد</option><option value="reaction">إضافة Reaction</option><option value="log">تسجيل الحدث فقط</option></select></label><label id="counterEmojiWrap">إيموجي الإجراء<input id="counterEmoji" placeholder="🎉"></label><label id="counterRepliesWrap" class="wide">الردود — كل صيغة في سطر<textarea id="counterReplies" rows="3" placeholder="وصلنا إلى {{count}} رسالة 🎉&#10;شكرًا على تفاعلك! وصلت المحادثة إلى {{count}} رسالة"></textarea></label></div><div class="action-bar"><button class="btn primary" id="saveCounterBtn">${state.interactionEditingCounter ? 'حفظ تعديل العداد' : 'إضافة محفز عداد'}</button><button class="btn" id="cancelCounterEditBtn" ${state.interactionEditingCounter ? '' : 'hidden'}>إلغاء التعديل</button></div><p class="help-note">يُنفَّذ كل محفز مرة واحدة عند عبور الحد المحدد لكل نطاق. بعد التعديل، لا يُعاد إطلاقه إلا عند عبور الحد وفق حالة العداد الجديدة؛ «تصفير» يعيد تسليح المحفزات.</p></details></article><article><div class="rule-list">${counters.length ? counters.map(counterRow).join('') : '<div class="empty">لا توجد محفزات للعداد بعد.</div>'}</div></article></div>
      </section>`;
  }

  function ruleRow(rule) {
    const variants = Array.isArray(rule.then?.replies) && rule.then.replies.length ? rule.then.replies : [rule.then?.reply || ''];
    const action = [variants.filter(Boolean).length > 1 ? `${variants.filter(Boolean).length} صيغ رد` : (variants[0] || ''), rule.then?.reaction || ''].filter(Boolean).join(' · ');
    const days = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
    const schedule = rule.schedule?.enabled ? `وقت ${rule.schedule.start || '09:00'}–${rule.schedule.end || '17:00'} · ${(Array.isArray(rule.schedule.days) && rule.schedule.days.length ? rule.schedule.days.map(day => days[Number(day)]).filter(Boolean).join('، ') : 'كل الأيام')}` : 'طوال الوقت';
    const command = rule.commandPriority || /^\s*[!/]/.test(String(rule.when?.value || '')) ? ' · أمر عالي الأولوية' : '';
    return `<div class="rule-row"><div><b>${esc(rule.name || 'قاعدة')}</b><small>${esc(rule.when?.type || 'message')} · ${esc(rule.when?.match || '')} · ${esc(rule.when?.value || 'أي')} · أولوية ${Number(rule.priority || 0)}${esc(command)} · ${esc(schedule)}</small><span>${esc(action || 'بدون إجراء')}</span></div><div class="row-actions"><button class="btn small" data-edit-rule="${esc(rule.id)}">تعديل</button><button class="btn small" data-toggle-rule="${esc(rule.id)}">${rule.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-rule="${esc(rule.id)}">حذف</button></div></div>`;
  }

  function counterRow(trigger) {
    const action = trigger.actionType === 'log' ? 'تسجيل فقط' : trigger.actionType === 'reaction' ? `Reaction ${trigger.then?.reaction || ''}` : `${(trigger.then?.replies || []).length || (trigger.then?.reply ? 1 : 0)} صيغة رد`;
    return `<div class="rule-row"><div><b>${esc(trigger.name || 'عداد رسائل')}</b><small>عند ${Number(trigger.threshold || 0).toLocaleString('ar-OM')} رسالة · ${trigger.scope === 'chat' ? 'لكل محادثة' : 'الجلسة كلها'} · أولوية ${Number(trigger.priority || 0)}</small><span>${esc(action)}</span></div><div class="row-actions"><button class="btn small" data-edit-counter="${esc(trigger.id)}">تعديل</button><button class="btn small" data-toggle-counter="${esc(trigger.id)}">${trigger.enabled === false ? 'تشغيل' : 'إيقاف'}</button><button class="btn danger small" data-delete-counter="${esc(trigger.id)}">حذف</button></div></div>`;
  }

  function interactionRow(item) {
    const when = item.at ? new Date(item.at) : null;
    return `<div class="interaction-row"><div><b>${esc(item.ruleName || item.ruleId || 'قاعدة')}</b><span>${esc(item.status || '')}</span></div><small>${esc(item.chatId || '')} · ${when && !Number.isNaN(when.getTime()) ? esc(when.toLocaleString('ar-OM')) : ''}</small></div>`;
  }

  function pageSession(data) {
    const runtime = data.whatsapp || {};
    const status = runtime.ready ? 'متصل' : (runtime.status === 'qr' ? 'بانتظار QR' : runtime.status || 'غير متصل');
    return `<section class="page-title"><p class="eyebrow">الجلسة</p><h1>اتصال وإدارة الحساب</h1><p>كل جلسة مستقلة بحسابها وأهدافها وسجلها.</p></section><section class="content-grid two-col">
      <article class="panel"><div class="panel-head"><div><h2>اتصال WhatsApp</h2><p>اربط الحساب أو أوقفه في أي وقت.</p></div></div><div class="status-panel"><span>الحالة</span><b>${esc(status)}</b>${runtime.info?.wid?.user ? `<small>+${esc(runtime.info.wid.user)}</small>` : ''}</div>${runtime.qr ? `<div class="qr-box"><p>امسح الرمز من WhatsApp.</p><img src="${esc(runtime.qr)}" class="session-qr" alt="QR"></div>` : ''}<div class="action-bar"><button class="btn primary" id="connectSessionBtn">ربط / تشغيل</button><button class="btn" id="stopSessionBtn">إيقاف</button><button class="btn danger" id="unlinkSessionBtn">فصل الحساب</button></div></article>
      <article class="panel"><div class="panel-head"><div><h2>إعداد الجلسة</h2><p>الاسم يتغير فقط في الجلسة الحالية.</p></div></div><label>اسم الجلسة<input id="sessionName" value="${esc(data.session?.name || '')}" placeholder="الجلسة الرئيسية"></label><div class="action-bar"><button class="btn primary" id="saveSessionBtn">حفظ الاسم</button><button class="btn" id="newSessionBtn">جلسة جديدة</button><button class="btn danger" id="deleteSessionBtn">حذف الجلسة</button></div><div class="info-grid"><div><span>الحساب</span><b>${esc(runtime.info?.wid?.user || 'غير معروف')}</b></div><div><span>الاسم</span><b>${esc(runtime.info?.pushname || 'غير معروف')}</b></div><div><span>المجموعات</span><b>${(data.groups || []).length}</b></div><div><span>الأشخاص</span><b>${(data.recipients || []).length}</b></div></div></article>
    </section><section class="panel"><div class="panel-head"><div><h2>سجل الجلسة</h2><p>هذا السجل يخص هذه الجلسة وحدها.</p></div><button class="btn small" id="sessionRefreshLog">تحديث</button></div><div class="log-list tall">${(data.logs || []).map(logRow).join('') || '<div class="empty">السجل فارغ.</div>'}</div></section>`;
  }

  const bgNames = { aurora: 'الشفق', nebula: 'السديم', meteor: 'النيزك', matrix: 'المصفوفة', 'cyber-grid': 'الشبكة', plasma: 'البلازما', starfield: 'النجوم', vortex: 'الدوامة', galaxy: 'المجرة', ocean: 'الموجة' };
  function pageAppearance(data) {
    const background = data.background || {};
    const cfg = background.settings || {};
    const a = data.settings?.appearance || {};
    const visiblePresets = [['mint','نعناعي'],['ocean','بحري'],['violet','بنفسجي'],['sunset','غروب']];
    return `<section class="page-title"><p class="eyebrow">المظهر</p><h1>المظهر والخلفيات</h1><p>غيّر اللون والخلفية بسهولة، والتخصيص الكامل موجود داخل الخيارات المتقدمة.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>لون الواجهة</h2><p>اختر لونًا جاهزًا أو لونك الخاص.</p></div></div>
          <div class="theme-preview"><span class="theme-dot" id="themeDot1"></span><div><b>chat BOT</b><small>لون واحد واضح للواجهة</small></div></div>
          <div class="preset-row">${visiblePresets.map(([id,label]) => `<button class="btn small" data-ui-preset="${id}">${label}</button>`).join('')}</div>
          <label>اللون الأساسي<input id="uiAccent" type="color" value="${esc(a.accent || '#5ed6c1')}"></label>
          <details class="advanced-panel"><summary>تفاصيل الواجهة</summary><div class="form-grid two"><label>لون مساعد<input id="uiAccent2" type="color" value="${esc(a.accent2 || '#8b7cf6')}"></label>${rangeControl('uiPanelOpacity','وضوح البطاقات',a.panelOpacity ?? .94,.78,.97,.01)}${rangeControl('uiPanelBlur','نعومة البطاقات',a.panelBlur ?? 0,0,12,1)}${rangeControl('uiRadius','استدارة العناصر',a.radius ?? 13,10,24,1)}${rangeControl('uiGlow','وهج اللون',a.glow ?? .28,0,.8,.05)}</div></details>
          <div class="action-bar"><button class="btn primary" id="saveUiThemeBtn">حفظ اللون</button><button class="btn" id="resetUiThemeBtn">إعادة الافتراضي</button></div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الخلفية</h2><p>خلفيات جميلة وخفيفة على الجهاز.</p></div></div>
          <div class="bg-picker">${Object.entries(bgNames).map(([id,name]) => `<button class="bg-choice ${background.mode === id ? 'selected' : ''}" data-bg-mode="${id}"><span class="bg-swatch bg-${id}"></span><b>${name}</b></button>`).join('')}</div>
          <div class="upload-box"><input id="customBackground" type="file" accept="image/png,image/jpeg,image/webp"><label for="customBackground"><span>＋</span> اختيار صورة</label><small>الصورة تحفظ لهذه الجلسة فقط.</small></div>
          ${background.imageUrl ? `<div class="custom-current"><img src="${esc(background.imageUrl)}" alt="الخلفية الحالية"><span>الخلفية الحالية</span></div><div class="action-bar"><button class="btn danger" id="removeCustomBackgroundBtn">إزالة الصورة</button></div>` : ''}
          <details class="advanced-panel"><summary>تخصيص الخلفية بالتفصيل</summary><div class="range-grid">${rangeControl('bgSpeed','السرعة',cfg.speed, .1,2,.05)}${rangeControl('bgDensity','الكثافة',cfg.density,.2,1.6,.05)}${rangeControl('bgGlow','التوهج',cfg.glow,0,1,.05)}${rangeControl('bgIntensity','القوة',cfg.intensity,.2,1.5,.05)}${rangeControl('bgMouse','تأثير المؤشر',cfg.mouseStrength,0,1.5,.05)}${rangeControl('bgBrightness','السطوع',cfg.brightness,.6,1.4,.05)}${rangeControl('bgContrast','التباين',cfg.contrast,.7,1.4,.05)}${rangeControl('bgSaturation','التشبع',cfg.saturation,.5,1.6,.05)}${rangeControl('bgHue','تغيير اللون',cfg.hueRotate,0,360,1)}${rangeControl('bgBlur','التمويه',cfg.blur,0,6,.25)}${rangeControl('bgOpacity','الشفافية',background.opacity ?? .22,.08,.60,.01)}</div><div class="toggle-list"><label class="toggle-row"><input id="bgInteractive" type="checkbox" ${cfg.interactive !== false ? 'checked' : ''}><span><b>التفاعل</b><small>استجابة بسيطة للمؤشر والنقر.</small></span></label><label class="toggle-row"><input id="bgTrail" type="checkbox" ${cfg.trail !== false ? 'checked' : ''}><span><b>أثر الحركة</b><small>يعطي نعومة إضافية.</small></span></label></div></details>
          <div class="action-bar"><button class="btn primary" id="saveBackgroundBtn">حفظ الخلفية</button><button class="btn" id="resetBackgroundBtn">إعادة الافتراضي</button></div>
        </article>
      </section>`;
  }

  function pageSettings(data) {
    const active = state.settingsView === 'operation' ? 'operation' : 'appearance';
    return `<section class="settings-shell">
      <div class="settings-switch" role="tablist" aria-label="أقسام الإعدادات">
        <button class="settings-tab ${active === 'appearance' ? 'active' : ''}" data-settings-view="appearance" role="tab" aria-selected="${active === 'appearance'}">المظهر والخلفيات</button>
        <button class="settings-tab ${active === 'operation' ? 'active' : ''}" data-settings-view="operation" role="tab" aria-selected="${active === 'operation'}">التشغيل المتقدم</button>
      </div>
      <div class="settings-content">${active === 'appearance' ? pageAppearance(data) : pageOperation(data)}</div>
    </section>`;
  }

  function rangeControl(id, label, value, min, max, step) {
    const safe = Number.isFinite(Number(value)) ? Number(value) : Number(min);
    return `<label class="range-item"><span>${esc(label)} <output id="${id}Out">${safe.toFixed(step < 1 ? 2 : 0)}</output></span><input id="${id}" type="range" min="${min}" max="${max}" step="${step}" value="${safe}"></label>`;
  }

  function pageOperation(data) {
    const settings = data.settings || {};
    return `<section class="page-title"><p class="eyebrow">التشغيل</p><h1>إعدادات التشغيل</h1><p>الإعدادات الأساسية ظاهرة، والتفاصيل الإضافية داخل أقسام واضحة.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>الأساسيات</h2><p>هذه أهم الخيارات للاستخدام اليومي.</p></div></div>
          <div class="form-grid two"><label>المنطقة الزمنية<input id="opTimezone" value="${esc(settings.timezone || 'Asia/Muscat')}" placeholder="Asia/Muscat"></label><label>ترتيب الإرسال<select id="opSendOrder"><option value="target-first" ${settings.sendOrder === 'target-first' ? 'selected' : ''}>هدف ثم ملفاته</option><option value="image-first" ${settings.sendOrder === 'image-first' ? 'selected' : ''}>ملف ثم الأهداف</option></select></label></div>
          <div class="toggle-list"><label class="toggle-row"><input id="opAutoStart" type="checkbox" ${settings.autoStartSession !== false ? 'checked' : ''}><span><b>تشغيل الجلسة تلقائيًا</b><small>استعادة الحساب المحفوظ عند بدء البوت.</small></span></label><label class="toggle-row"><input id="opAutomation" type="checkbox" ${settings.automationEnabled !== false ? 'checked' : ''}><span><b>التشغيل التلقائي</b><small>تشغيل المواعيد المحفوظة لهذه الجلسة.</small></span></label></div>
          <div class="action-bar"><button class="btn primary" id="saveOperationMain">حفظ</button></div>
        </article>
        <article class="panel"><div class="panel-head"><div><h2>الخصوصية والتشغيل</h2><p>المعلومات التي تحتاجها فقط.</p></div></div><div class="privacy-box"><p>المشروع يعمل محليًا وتبقى بيانات الجلسات والوسائط والسجل على الجهاز.</p><p>التشغيل المعتاد عبر <code>run.py</code> والمنفذ 7005.</p></div><div class="action-bar"><button class="btn" data-go="session">إدارة الجلسة</button><button class="btn" data-go="dashboard">الرئيسية</button></div></article>
      </section>
      <section class="content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>الموثوقية</h2><p>خيارات متقدمة، لا تحتاج تغييرها غالبًا.</p></div></div><details class="advanced-panel"><summary>إظهار إعدادات الموثوقية (اختياري)</summary><div class="form-grid two"><label>التأخير بين الإرسال (مللي ثانية)<input id="opDelay" type="number" min="0" max="60000" value="${Number(settings.sendDelayMs || 700)}"></label><label>مهلة الإرسال (مللي ثانية)<input id="opTimeout" type="number" min="5000" max="180000" value="${Number(settings.sendTimeoutMs || 30000)}"></label><label>عدد المحاولات<input id="opRetryAttempts" type="number" min="1" max="4" value="${Number(settings.retryAttempts || 2)}"></label><label>التأخير بين المحاولات (مللي ثانية)<input id="opRetryDelay" type="number" min="250" max="120000" value="${Number(settings.retryDelayMs || 1600)}"></label><label>أقصى حجم للملف MB<input id="opMaxSize" type="number" min="1" max="250" value="${Number(settings.maxImageSizeMB || 100)}"></label></div><div class="action-bar"><button class="btn primary" id="saveOperationReliability">حفظ</button></div></details></article>
        <article class="panel"><div class="panel-head"><div><h2>فترة هدوء التفاعل</h2><p>أوقف الردود التلقائية خلال وقت تحدده.</p></div></div><details class="advanced-panel"><summary>إظهار إعدادات فترة الهدوء</summary><div class="form-grid three"><label class="toggle-box"><input id="opQuietEnabled" type="checkbox" ${settings.interactionQuietEnabled ? 'checked' : ''}><span>تفعيل</span></label><label>من<input id="opQuietStart" type="time" value="${esc(settings.interactionQuietStart || '23:00')}"></label><label>إلى<input id="opQuietEnd" type="time" value="${esc(settings.interactionQuietEnd || '07:00')}"></label><label>السلوك<select id="opQuietAction"><option value="silence" ${(settings.interactionQuietAction || 'silence') === 'silence' ? 'selected' : ''}>لا ترد</option><option value="reply" ${settings.interactionQuietAction === 'reply' ? 'selected' : ''}>رد مخصص</option><option value="rules" ${settings.interactionQuietAction === 'rules' ? 'selected' : ''}>القواعد</option></select></label><label>الرد المخصص<input id="opQuietReply" maxlength="1000" value="${esc(settings.interactionQuietReply || 'أنا في فترة الهدوء الآن، سأرد عليك لاحقًا.')}"></label><label>تكرار الرد (ثانية)<input id="opQuietCooldownSec" type="number" min="0" max="86400" value="${Number(settings.interactionQuietCooldownSec ?? 300)}"></label></div><div class="action-bar"><button class="btn primary" id="saveOperationQuiet">حفظ</button></div></details></article></section>`;
  }

  function pageTools() {
    return `<section class="page-title"><p class="eyebrow">TOOLS • LOCAL ENGINES</p><h1>المحركات الذكية</h1><p>واجهة موحّدة للأدوات الجديدة: صحة البنية، قاموس المصطلحات، وتحليل أوامر مكتوبة أو مفرّغة من الصوت. هذه الأدوات لا تنفّذ الأوامر الخطرة تلقائيًا.</p></section>
      <section class="stats-grid tools-stats">
        <article class="stat-card"><span>ناقل الأحداث</span><b>Event Bus</b><small>أحداث داخلية بحدود للذاكرة والتزامن</small></article>
        <article class="stat-card"><span>محرك الأوامر</span><b>Command Engine</b><small>صلاحيات وتحقق من المدخلات</small></article>
        <article class="stat-card"><span>قاموس النصوص</span><b>Dictionary</b><small>تطبيع عربي وبحث تقريبي</small></article>
        <article class="stat-card"><span>الأوامر الصوتية</span><b>Voice Parser</b><small>تحليل النص المفرّغ فقط</small></article>
      </section>
      <section class="content-grid two-col tools-grid">
        <article class="panel"><div class="panel-head"><div><h2>حالة البنية</h2><p>قراءة مباشرة من الخادم المحلي، وليست فحصًا خارجيًا.</p></div><button class="btn small" id="refreshArchitecture">تحديث الحالة</button></div><div id="architectureStatus" class="architecture-status"><div class="empty">اضغط «تحديث الحالة» لجلب حالة المحركات.</div></div><div class="privacy-box tools-note"><p><b>ملاحظة تشغيلية:</b> حفظ الجلسات الحالي محلي، ولا يعني أن تشغيل عدة نسخ أو ملايين الرسائل جاهز تلقائيًا.</p><p>التوسّع الإنتاجي يحتاج قاعدة بيانات دائمة، وطابور مهام موزّعًا، وقفل جدولة مشتركًا واختبارات تحميل.</p></div></article>
        <article class="panel"><div class="panel-head"><div><h2>تحليل أمر صوتي</h2><p>الصق ما قاله المستخدم أو النص الذي أخرجه محوّل الكلام إلى نص.</p></div><span class="mini-tag">لا يسجّل الميكروفون</span></div><label class="tools-label" for="voiceTranscript">النص المُفرّغ</label><textarea id="voiceTranscript" maxlength="1000" placeholder="مثال: الحالة أو مساعدة أو اكتم إشعارات المجموعة"></textarea><div class="form-grid two tools-fields"><label>الثقة (0–1)<input id="voiceConfidence" type="number" min="0" max="1" step="0.05" value="1"></label><label>اللغة<select id="voiceLocale"><option value="ar">العربية</option><option value="en">English</option></select></label></div><div class="action-bar"><button class="btn primary" id="voiceParseBtn">تحليل النص</button><button class="btn" id="voiceClearBtn">مسح</button></div><div id="voiceParseResult" class="result-box" aria-live="polite">لم يتم تحليل أي نص بعد.</div><p class="help tools-footnote">النتيجة تفسير للنية فقط؛ لا يتم تنفيذ كتم أو حذف أو أي إجراء في واتساب من هذه الشاشة.</p></article>
      </section>
      <section class="content-grid two-col tools-grid">
        <article class="panel"><div class="panel-head"><div><h2>قاموس المصطلحات</h2><p>بحث عربي يدعم تطبيع الهمزات والتشكيل وبعض المطابقات التقريبية.</p></div><span class="mini-tag">محلي</span></div><form id="dictionaryForm" class="dictionary-form"><label class="tools-label" for="dictionaryQuery">كلمة أو مصطلح</label><div class="dictionary-search"><input id="dictionaryQuery" maxlength="160" placeholder="اكتب المصطلح المراد البحث عنه"><button class="btn primary" type="submit">بحث</button></div></form><div id="dictionaryResult" class="result-box" aria-live="polite">أدخل مصطلحًا لبدء البحث.</div><div id="dictionaryMeta" class="help">القاموس الحالي فارغ ما لم تُضَف له بيانات عبر التطبيق أو الخادم.</div></article>
        <article class="panel"><div class="panel-head"><div><h2>خريطة المحركات</h2><p>ترتيب الإضافات الجديدة داخل بنية واحدة.</p></div></div><div class="engine-list">
          <div class="engine-row"><span class="engine-icon">↔</span><div><b>Event Bus</b><small>تمرير أحداث الرسائل والأنشطة بين الوحدات.</small></div><span class="engine-tag">أحداث</span></div>
          <div class="engine-row"><span class="engine-icon">⌘</span><div><b>Command Engine</b><small>تسجيل الأوامر والتحقق من الصلاحيات والمدخلات.</small></div><span class="engine-tag">أوامر</span></div>
          <div class="engine-row"><span class="engine-icon">Aa</span><div><b>Dictionary Engine</b><small>توحيد النص العربي والبحث عن المصطلحات والمرادفات.</small></div><span class="engine-tag">نصوص</span></div>
          <div class="engine-row"><span class="engine-icon">◖</span><div><b>Voice-to-Command</b><small>تحويل النص المفرّغ إلى نية مفهومة مع عتبة ثقة.</small></div><span class="engine-tag">تحليل</span></div>
        </div></article>
      </section>`;
  }

  function pageGuide() {
    return `<section class="page-title"><p class="eyebrow">HELP • QUICK GUIDE</p><h1>الدليل والمساعدة</h1><p>دليل مختصر للبدء الآمن، إدارة الجلسات، الإرسال، الأتمتة، والميزات الجديدة. الواجهة محلية وتعرض حالة النظام عند طلب التحديث أو تنفيذ إجراء.</p></section>
      <section class="content-grid two-col">
        <article class="panel"><div class="panel-head"><div><h2>ابدأ من هنا</h2><p>خطوات الاستخدام اليومية بالترتيب.</p></div></div><div class="guide-list">
          <div class="guide-card"><span class="guide-number">01</span><div><b>اربط الجلسة</b><p>افتح «الجلسة» ثم ابدأ الاتصال وامسح رمز QR من WhatsApp على هاتفك.</p></div></div>
          <div class="guide-card"><span class="guide-number">02</span><div><b>جهّز الأشخاص والمجموعات</b><p>أضف أرقامًا بصيغة دولية أو اكتشف المجموعات من الجلسة المتصلة، ثم راجع الأهداف قبل الإرسال.</p></div></div>
          <div class="guide-card"><span class="guide-number">03</span><div><b>جرّب قبل التنفيذ</b><p>ابدأ بهدف واحد، راجع السجل، ثم استخدم الجدولة أو قواعد التفاعل بعد التأكد من الإعدادات.</p></div></div>
          <div class="guide-card"><span class="guide-number">04</span><div><b>افحص المحركات الجديدة</b><p>من «المحركات الذكية» يمكنك فحص صحة البنية، تجربة البحث في القاموس، وتحليل نص أمر صوتي دون تنفيذه.</p></div></div>
        </div></article>
        <article class="panel"><div class="panel-head"><div><h2>الخصوصية وحدود التشغيل</h2><p>معلومات مهمة قبل الاعتماد على النظام.</p></div></div><div class="guide-callouts"><div class="privacy-box"><b>البيانات محلية</b><p>بيانات الجلسات والإعدادات والوسائط تُدار محليًا في المشروع. احمِ ملفات مجلد البيانات ولا تشاركها لأنها قد تحتوي على معلومات خاصة.</p></div><div class="privacy-box"><b>لا توجد خدمة ذكاء اصطناعي خارجية</b><p>محرك الأوامر الحالي يعتمد على قواعد محلية؛ ومحلل الصوت يعالج نصًا مفرغًا فقط ولا يسجل الصوت أو يحوّله بنفسه.</p></div><div class="privacy-box"><b>التوسع الإنتاجي يحتاج تجهيزًا إضافيًا</b><p>النسخة الحالية ليست بعدُ نظامًا موزعًا جاهزًا لملايين الرسائل. قبل التوسع يلزم تخزين دائم، طابور موزع، مراقبة، صلاحيات، نسخ احتياطية واختبارات تحميل.</p></div></div><div class="action-bar"><button class="btn primary" data-go="session">إدارة الجلسة</button><button class="btn" data-go="tools">فتح المحركات الذكية</button><button class="btn" data-go="settings">الإعدادات</button></div></article>
      </section>`;
  }

  function pageUpdates() {
    const releases = [
      { version: 'v9.8.0', title: 'إصلاح الاستدعاء الفوري وصور الحساب وتفاصيل أخطاء الإرسال', date: 'مراجعة وظيفية إضافية', state: 'مضاف', items: ['إصلاح اختيار جهة WhatsApp المستوردة: تتحول قائمة الإرسال من وضع «الكل» إلى تحديد الجهات التي أضافها المستخدم فقط، لمنع الإرسال غير المقصود إلى بقية الأشخاص.', 'قبول صورة الملف الشخصي بعد التحقق من ترويسة الملف حتى عندما يرسل CDN نوع MIME عامًا مثل application/octet-stream، مع إبقاء فحص التوقيع والحجم والتحويلات الموثوقة.', 'السماح بخدمة ملفات AVIF المحفوظة في مسار الصور الشخصي، بدل رفضها بسبب امتداد الملف.', 'توسيع تصنيف أخطاء الإذن إلى HTTP 401/403 وبيانات statusCode ورسائل إدارة المجموعات، وتوضيح عدم اتصال WhatsApp بالعربية.', 'إصلاح حساب عدد المستلمين الفاشلين من كامل قائمة النتائج حتى عندما تُعرض تفاصيل أول ثمانية فقط، وإبقاء الإرسال الجزئي قابلًا للفحص من الواجهة.', 'فصل خيار السماح بإعادة إرسال رسالة مكررة عن خيار استبدال ملف مكرر، وعرض خيار الإعادة في صف واضح كامل العرض.'] },
      { version: 'v9.7.0', title: 'إصلاح الإرسال والأذونات واستدعاء جهات WhatsApp', date: 'تصحيح المسارات الحرجة', state: 'مضاف', items: ['تصنيف أخطاء الصلاحيات والاتصال والمستلم غير المتحقق منه إلى رسائل عربية واضحة مع رمز خطأ، وعدم إعادة المحاولة للأخطاء غير القابلة للتكرار.', 'إصلاح ترتيب إرسال ملف ثم نص عند اختيار «كل ملف ثم جميع الأهداف»؛ ترتيب الوظائف داخل كل هدف أصبح يطابق الاختيار الفعلي مع حفظ حالة كل جزء لتجنب التكرار.', 'استعادة الرجوع من معرّف الهاتف إلى معرّف LID الموثّق عند فشل طلب صورة الملف الشخصي المباشر، بدل التوقف عند أول استجابة فارغة.', 'ضبط تخطيط صف جهة WhatsApp حتى يظهر زر الإضافة مع الصورة والاسم والرقم، ويتحول لتخطيط صغير على الشاشات الضيقة.', 'إبقاء الاسم المحلي كما هو، وتخزين الاسم الظاهر واسم دفتر WhatsApp والصورة في حقول منفصلة.'] },
      { version: 'v9.6.0', title: 'إصلاح صور WhatsApp والإرسال واستدعاء جهات الاتصال', date: 'مراجعة تشغيلية ووسائط', state: 'مضاف', items: ['عرض صورة ملف WhatsApp الحالية في قائمة الاستدعاء وبطاقات الأشخاص عبر نقطة نهاية محلية آمنة، مع تحميل كسول وتخزين مؤقت للصورة بدل كشف رابط CDN منتهي الصلاحية.', 'تحسين اختيار الاسم الظاهر: الاسم المحفوظ في دفتر WhatsApp للجهة المحفوظة، واسم الملف الشخصي/الاسم الظاهر لغير المحفوظة، مع إبقاء الاسم المحلي للمشروع دون تغيير افتراضيًا.', 'تحسين تنزيل الصور لدعم التحويلات الموثقة على نطاقات WhatsApp/Facebook المسموحة، وفحص نوع المحتوى وبصمة الصورة وحجمها ورفض التحويل إلى نطاق غير موثوق.', 'إصلاح رسالة نتيجة الإرسال التي كانت تحوّل مصفوفة الرسائل إلى NaN، وعرض تفاصيل الفشل لكل مستلم مع الاحتفاظ بتحديد الأهداف التي فشلت بدل تحديد الجميع مجددًا.', 'استعادة حلّ معرف المستلم عند امتلاك السجل القديم لحقل digits أو WhatsApp JID الموثق فقط، والتحقق من أن الملف المحدد موجود وصالح قبل إرسال الوسائط.', 'إضافة اختبارات فعلية لمسار إدارة صور الملفات الشخصية وتدفق إرسال الوسائط المحلي ومعرفات المستلمين القديمة.'] },
      { version: 'v9.5.0', title: 'استعادة محادثة النفس ومزامنة WhatsApp وتقليل ازدحام الإعدادات', date: 'إصلاحات واستعادة الوظائف', state: 'مضاف', items: ['إعادة ربط رسائل «الرسائل إلى نفسك» بمساعد محلي حواري: دليل، حالة، إضافة جهة، إرسال بتأكيد، موعد، رد تلقائي، ومزامنة جهات.', 'إرسال دليل الاستخدام بعد اتصال الجلسة، مع منع تكرار إرساله عند ورود حالات اتصال متزامنة.', 'استعادة استدعاء جهات WhatsApp من الجلسة، والاختيار قبل المزامنة، واستيراد الجهات الرقمية وصور الملف الشخصي مع المحافظة على الأسماء المحلية افتراضيًا.', 'إخفاء محررات الأتمتة والردود والإعدادات الإضافية افتراضيًا، وفتح المحرر تلقائيًا عند اختيار تعديل.', 'إضافة اختبارات مستقلة لمسار الحوار ومزامنة جهات الاتصال والواجهات المرتبطة.'] },
      { version: 'v9.4.0', title: 'إكمال إدارة الأشخاص والردود الشخصية', date: 'تحديث وظيفي ومرئي', state: 'مضاف', items: ['إضافة تحديد متعدد للأشخاص وحذف جماعي مع تنظيف أهداف الجدولة والأتمتة المرتبطة.', 'إضافة وضع الرد لكل شخص: الوراثة من القواعد العامة، أو قواعد شخصية، أو تعطيل الرد، مع رد افتراضي وفترة تهدئة.', 'رفع حد الملف القابل للضبط إلى 250 ميجابايت، والقيمة الافتراضية 100 ميجابايت، مع بقاء فحص حجم الملف مفعّلًا.', 'الحفاظ على القائمة الجانبية المرجعية وأقسام المحركات الذكية وسجل التعديلات.'] },
      { version: 'v9.3.0', title: 'استعادة تخطيط الواجهة الجانبية المرجعي', date: 'تحديث سابق', state: 'مضاف', items: ['إعادة ترتيب الصفحة حول رأس علوي وقائمة جانبية رأسية مقسمة إلى مجموعات ومساحة محتوى رئيسية.', 'إبقاء صفحات التشغيل الأساسية، مع مجموعة مستقلة للمحركات الذكية والدليل وسجل التعديلات.', 'إضافة مبدل فاتح/داكن محفوظ محليًا، وروبوت مرئي لعرض إشعارات الحالة وفتح الدليل.', 'الاحتفاظ بقائمة «إعدادات إضافية» وروابطها إلى الإعدادات المتقدمة والمظهر والميزات الجديدة.'] },
      { version: 'v9.2.0', title: 'قائمة الإعدادات الإضافية وسجل التغييرات', date: 'تحديث سابق', state: 'مضاف', items: ['قائمة إضافية للوصول إلى الإعدادات المتقدمة والمظهر والمحركات والدليل.', 'إضافة صفحة سجل التعديلات وحدود الميزات.'] },
      { version: 'v9.0.0', title: 'محركات البنية الجديدة', date: 'معمارية محلية قابلة للتوسعة', state: 'مضاف', items: ['ناقل أحداث داخلي محدود السجل والتزامن.', 'محرك أوامر مع التحقق من المدخلات والصلاحيات.', 'قاموس عربي مع تطبيع النصوص والبحث التقريبي.', 'محلل نص أوامر صوتية؛ يحلل نصًا مكتوبًا/مفرغًا ولا يقوم بالتعرف على الصوت نفسه.', 'واجهات فحص الحالة والقاموس وتحليل الأمر.'] },
      { version: 'v8.9.0', title: 'الأتمتة والجدولة', date: 'تحسينات تشغيلية', state: 'مضاف', items: ['تطوير محرك المهام والمواعيد وربطها بالجلسة الحالية.', 'تحسين إدارة القواعد وسجل النشاط ومسارات التفاعل.', 'إضافة اختبارات للتحقق من الأتمتة والتوافق وحفظ البيانات.'] },
      { version: 'ملاحظات تشغيل', title: 'حدود معروفة بشفافية', date: 'ما يحتاج إلى استكمال', state: 'قيد التطوير', items: ['التخزين الحالي محلي وليس قاعدة بيانات موزعة.', 'لا يوجد طابور رسائل موزع أو قفل جدولة مشترك بين عدة نسخ.', 'القاموس الجديد في الذاكرة ولا يضمن الاحتفاظ بالإضافات بعد إعادة التشغيل.', 'التعرف على الصوت يحتاج مكوّن تحويل صوت إلى نص مستقل.', 'لا ينبغي وصف النظام بأنه جاهز لملايين الرسائل قبل إضافة التخزين والطوابير والمراقبة واختبارات الضغط.'] },
    ];
    return `<section class="page-title"><p class="eyebrow">سجل التغييرات</p><h1>التعديلات والإضافات</h1><p>ملخص واضح للتغييرات التي أضيفت إلى المشروع، مع الفصل بين الميزات الموجودة والاحتياجات التي لم تكتمل بعد.</p></section>
      <section class="updates-summary content-grid two-col"><article class="panel"><div class="panel-head"><div><h2>ما أضيف إلى الواجهة</h2><p>مداخل واضحة بدل تكديس الخيارات في صفحة واحدة.</p></div><span class="release-pill">واجهة</span></div><ul class="update-list"><li>رأس علوي لاختيار الجلسة ومراجعة حالة الاتصال والتبديل بين الوضعين.</li><li>قائمة جانبية رأسية مقسّمة حسب مساحة العمل وجهات الإرسال والتحكم والإضافات الجديدة.</li><li>قائمة «إعدادات إضافية» للوصول إلى المظهر والتشغيل المتقدم.</li><li>صفحة مستقلة لسجل التعديلات وحدود الميزات، مع المحركات الذكية والدليل.</li></ul></article><article class="panel"><div class="panel-head"><div><h2>حالة التحقق</h2><p>ما يمكن تأكيده من الاختبارات الحالية.</p></div><span class="release-pill">محلي</span></div><div class="update-status"><b>اختبارات المشروع</b><p>تم إعداد اختبارات آلية لمحركات البنية والتوافق والانحدار والأتمتة. نجاحها لا يعني اختبار اتصال WhatsApp حي أو اختبار أحمال ضخمة.</p></div><div class="action-bar"><button class="btn primary" data-go="tools">فحص المحركات</button><button class="btn" data-go="guide">قراءة حدود التشغيل</button></div></article></section>
      <section class="release-list">${releases.map((release) => `<article class="panel release-card"><div class="release-heading"><div><span class="release-version">${esc(release.version)}</span><h2>${esc(release.title)}</h2><small>${esc(release.date)}</small></div><span class="release-state ${release.state === 'قيد التطوير' ? 'pending' : ''}">${esc(release.state)}</span></div><ul class="update-list">${release.items.map((item) => `<li>${esc(item)}</li>`).join('')}</ul></article>`).join('')}</section>`;
  }

  function render() {
    const data = state.data || { session: {}, sessions: [], whatsapp: {} };
    let content = pageDashboard(data);
    if (state.page === 'send') content = pageSend(data);
    else if (state.page === 'owner-center') content = pageOwnerCenter(data);
    else if (state.page === 'assistant') content = pageAssistant(data);
    else if (state.page === 'people') content = pagePeople(data);
    else if (state.page === 'groups') content = pageGroups(data);
    else if (state.page === 'interaction') content = pageInteraction(data);
    else if (state.page === 'automation') content = pageAutomation(data);
    else if (state.page === 'session') content = pageSession(data);
    else if (state.page === 'settings') content = pageSettings(data);
    else if (state.page === 'tools') content = pageTools();
    else if (state.page === 'guide') content = pageGuide();
    else if (state.page === 'updates') content = pageUpdates();
    else if (state.page === 'appearance') { state.page = 'settings'; state.settingsView = 'appearance'; content = pageSettings(data); }
    else if (state.page === 'operation') { state.page = 'settings'; state.settingsView = 'operation'; content = pageSettings(data); }
    applyInterfaceTheme(data);
    $('#app').innerHTML = shell(content);
    setupBackground();
    bindCommon();
    bindPage();
  }

  if (!document.documentElement.dataset.moreMenuOutsideBound) {
    document.addEventListener('click', (event) => {
      if (event.target.closest('.more-settings-wrap')) return;
      const menu = $('#moreSettingsMenu');
      if (menu) menu.hidden = true;
      $('#moreSettingsBtn')?.setAttribute('aria-expanded', 'false');
    });
    document.documentElement.dataset.moreMenuOutsideBound = '1';
  }

  function bindCommon() {
    $$('.navbtn').forEach((button) => { button.onclick = () => go(button.dataset.page); });
    const moreButton = $('#moreSettingsBtn');
    const moreMenu = $('#moreSettingsMenu');
    moreButton?.addEventListener('click', (event) => { event.stopPropagation(); const open = moreMenu?.hidden !== false; if (moreMenu) moreMenu.hidden = !open; moreButton.setAttribute('aria-expanded', String(open)); });
    $('#modeToggleBtn')?.addEventListener('click', () => {
      state.uiMode = state.uiMode === 'dark' ? 'light' : 'dark';
      try { localStorage.setItem('chatbot-ui-mode', state.uiMode); } catch { /* Theme remains active for this page view. */ }
      document.documentElement.dataset.theme = state.uiMode;
      render();
    });
    $('#assistantRobotButton')?.addEventListener('click', () => {
      const bubble = $('#assistantSpeech');
      const bubbleText = $('#assistantSpeechText');
      if (!bubble) return;
      if (bubble.hidden && bubbleText && !bubbleText.textContent.trim()) bubbleText.textContent = 'افتح «المساعد المحلي» للسؤال عن حالة النظام والتنقل بين صفحات البرنامج. هذا المساعد يستخدم قواعد محلية ولا يستدعي API خارجيًا.';
      bubble.hidden = !bubble.hidden;
      $('#assistantRobotButton')?.classList.toggle('robot-talk', !bubble.hidden);
    });
    $('#assistantSpeechClose')?.addEventListener('click', () => { const bubble = $('#assistantSpeech'); if (bubble) bubble.hidden = true; $('#assistantRobotButton')?.classList.remove('robot-talk'); });
    $('#assistantSpeechOpen')?.addEventListener('click', () => go('assistant'));
    $$('[data-go]').forEach((button) => { button.onclick = () => go(button.dataset.go); });
    $('#refreshBtn')?.addEventListener('click', () => load(true).catch((e) => notify(e.message, 'error')));
    $('#dashboardRefresh')?.addEventListener('click', () => load(true).catch((e) => notify(e.message, 'error')));
    $('#sessionRefreshLog')?.addEventListener('click', () => load(true).catch((e) => notify(e.message, 'error')));
    $('#sessionSelect')?.addEventListener('change', async (event) => {
      try {
        await api('/api/sessions/switch', { method: 'POST', body: JSON.stringify({ sessionId: event.target.value }) });
        state.pendingTargets = null;
        state.selectedRecipientIds.clear();
        state.selectedGroup = null;
        state.whatsappContacts = null; state.whatsappContactsSession = ''; state.whatsappContactsSelected.clear(); state.whatsappContactFilter = '';
        state.whatsappContactsOpen = false; state.whatsappContactsBusy = false;
        await load(true);
      } catch (error) { notify(error.message, 'error'); }
    });
  }

  async function bindPage() {
    if (state.page === 'send') bindSend();
    if (state.page === 'assistant') bindAssistant();
    if (state.page === 'owner-center') $('#ownerCenterRefresh')?.addEventListener('click', () => load(true).catch(error => notify(error.message, 'error')));
    if (state.page === 'people') bindPeople();
    if (state.page === 'groups') bindGroups();
    if (state.page === 'interaction') bindInteraction();
    if (state.page === 'automation') bindAutomation();
    if (state.page === 'session') bindSession();
    if (state.page === 'appearance') bindAppearance();
    if (state.page === 'tools') bindTools();
    if (state.page === 'settings') {
      bindSettings();
      if (state.settingsView === 'operation') bindOperation(); else bindAppearance();
    }
  }

  async function bindTools() {
    const healthBox = $('#architectureStatus');
    const healthButton = $('#refreshArchitecture');
    const refreshHealth = async () => {
      if (!healthBox) return;
      healthButton?.classList.add('loading');
      healthBox.innerHTML = '<div class="empty">جارٍ قراءة حالة البنية…</div>';
      try {
        const result = await api('/api/architecture/health');
        const modules = result.modules || {};
        const rows = [
          ['ناقل الأحداث', typeof modules.eventBus === 'object' ? 'نشط' : 'متاح', typeof modules.eventBus === 'object' ? `${Number(modules.eventBus.types || 0)} أنواع أحداث · ${Number(modules.eventBus.history || 0)} أحداث في السجل` : 'لم تتوفر تفاصيل'],
          ['محرك الأوامر', 'متاح', `${Number(modules.commandEngine || 0)} أمر مسجل`],
          ['قاموس المصطلحات', 'متاح', `${Number(modules.dictionaryEngine || 0)} مدخل/مفتاح في الذاكرة`],
          ['محلل الأوامر الصوتية', modules.voiceParser ? 'متاح' : 'غير متاح', 'يحلل النص ولا يحوّل الصوت إلى نص'],
          ['الحفظ', 'محلي', String(modules.persistence || 'غير محدد')],
          ['التوسع الموزّع', 'غير مهيأ', String(modules.productionScaleAdapter || 'غير محدد')],
        ];
        healthBox.innerHTML = `<div class="architecture-head"><span class="mini-tag">الإصدار ${esc(result.version || '—')}</span><span class="mini-tag">فحص محلي</span></div><div class="architecture-grid">${rows.map(([name, status, detail]) => `<div class="architecture-item"><span class="architecture-check">${status === 'نشط' || status === 'متاح' || status === 'محلي' ? '✓' : '!'}</span><div><b>${esc(name)}</b><small>${esc(detail)}</small></div><span class="architecture-state ${status === 'غير مهيأ' ? 'warning' : ''}">${esc(status)}</span></div>`).join('')}</div>`;
      } catch (error) {
        healthBox.innerHTML = `<div class="empty">تعذر جلب الحالة: ${esc(error.message)}</div>`;
      } finally { healthButton?.classList.remove('loading'); }
    };
    healthButton?.addEventListener('click', refreshHealth);
    await refreshHealth();

    $('#voiceParseBtn')?.addEventListener('click', async () => {
      const transcript = $('#voiceTranscript')?.value.trim() || '';
      if (!transcript) return notify('أدخل النص أولًا.', 'error');
      const output = $('#voiceParseResult');
      output.textContent = 'جارٍ تحليل النص…';
      try {
        const confidence = Math.max(0, Math.min(1, Number($('#voiceConfidence')?.value ?? 1)));
        const result = await api('/api/voice/parse', { method: 'POST', body: JSON.stringify({ transcript, confidence, locale: $('#voiceLocale')?.value || 'ar' }) });
        const parsed = result.parsed || {};
        if (parsed.accepted) {
          output.innerHTML = `<div class="tool-result-title"><span class="result-status success">تم التعرف على النية</span><b>${esc(parsed.intent || '—')}</b></div><dl class="tool-result-dl"><dt>الهدف النصي</dt><dd>${esc(parsed.targetText || 'لا يوجد هدف محدد')}</dd><dt>الثقة</dt><dd>${Math.round(Number(parsed.confidence || 0) * 100)}%</dd><dt>النص الموحّد</dt><dd>${esc(parsed.normalized || parsed.transcript || '')}</dd></dl>${parsed.requiresConfirmation ? '<div class="callout">يتطلب هذا النوع تأكيدًا صريحًا. لم يتم تنفيذ أي إجراء.</div>' : '<div class="help">تم التحليل فقط؛ لا يوجد تنفيذ تلقائي.</div>'}`;
        } else {
          const reason = parsed.reason === 'low-confidence' ? 'مستوى الثقة أقل من الحد المطلوب.' : parsed.reason === 'empty' ? 'النص فارغ.' : 'لم يتم التعرف على أمر مدعوم.';
          output.innerHTML = `<span class="result-status warning">لم يتم قبول الأمر</span><p>${esc(reason)}</p><small>${esc(parsed.transcript || transcript)}</small>`;
        }
      } catch (error) { output.textContent = `تعذر تحليل النص: ${error.message}`; }
    });
    $('#voiceClearBtn')?.addEventListener('click', () => { $('#voiceTranscript').value = ''; $('#voiceParseResult').textContent = 'لم يتم تحليل أي نص بعد.'; });

    $('#dictionaryForm')?.addEventListener('submit', async (event) => {
      event.preventDefault();
      const query = $('#dictionaryQuery')?.value.trim() || '';
      if (!query) return notify('اكتب مصطلحًا للبحث.', 'error');
      const output = $('#dictionaryResult');
      output.textContent = 'جارٍ البحث…';
      try {
        const result = await api(`/api/dictionary/lookup?q=${encodeURIComponent(query)}`);
        if (result.entry) {
          const entry = result.entry;
          output.innerHTML = `<div class="tool-result-title"><span class="result-status success">عُثر على مصطلح</span><b>${esc(entry.term || query)}</b></div><p>${esc(entry.definition || 'لا يوجد تعريف مسجل لهذا المصطلح.')}</p>${entry.aliases?.length ? `<div class="tool-tags">${entry.aliases.map(alias => `<span>${esc(alias)}</span>`).join('')}</div>` : ''}`;
        } else output.innerHTML = `<span class="result-status warning">لا توجد نتيجة</span><p>لم يُعثر على «${esc(query)}» في القاموس المحلي الحالي.</p><small>محرك القاموس موجود، لكن بياناته لا تُحمّل تلقائيًا ولا تُحفَظ بين مرات التشغيل في هذه النسخة.</small>`;
        const all = await api('/api/dictionary?limit=1');
        if ($('#dictionaryMeta')) $('#dictionaryMeta').textContent = `عدد المصطلحات الحالية: ${(all.entries || []).length ? 'يوجد محتوى' : '0'} · القاموس في الذاكرة ويحتاج مصدر بيانات دائمًا مستقبلًا.`;
      } catch (error) { output.textContent = `تعذر البحث: ${error.message}`; }
    });
  }

  function currentTargetKeys() {
    return $$('.target:checked').map((input) => input.value);
  }

  function selectedMediaIds() {
    return $$('.send-media:checked').map((input) => input.value);
  }

  async function bindSend() {
    await loadCountries().then(() => {
      const country = $('#recipientCountry');
      if (country) country.innerHTML = countryOptions(country.value || 'OM');
    }).catch(() => {});
    $$('.target').forEach((checkbox) => checkbox.addEventListener('change', () => { state.pendingTargets = currentTargetKeys(); }));
    $('#selectAllTargets')?.addEventListener('click', () => { $$('.target').forEach((input) => { input.checked = true; }); state.pendingTargets = currentTargetKeys(); });
    $('#clearTargets')?.addEventListener('click', () => { $$('.target').forEach((input) => { input.checked = false; }); state.pendingTargets = []; });
    $('#mediaFiles')?.addEventListener('change', uploadMediaFiles);
    $$('[data-delete-media]').forEach((button) => button.addEventListener('click', async (event) => {
      event.preventDefault();
      try { await api(`/api/media/${encodeURIComponent(button.dataset.deleteMedia)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (error) { notify(error.message, 'error'); }
    }));
    $('#sendNowBtn')?.addEventListener('click', sendNow);
    bindSchedule();
  }

  async function uploadMediaFiles(event) {
    const files = [...(event.target.files || [])];
    if (!files.length) return;
    const form = new FormData();
    files.forEach((file) => form.append('files', file));
    form.append('sessionId', sid());
    form.append('replaceDuplicates', $('#replaceDuplicates')?.checked ? 'true' : 'false');
    try {
      const result = await api('/api/media', { method: 'POST', body: form });
      notify(result.message || `تم رفع ${result.saved?.length || 0} ملف`, 'success');
      await load(true);
    } catch (error) { notify(error.message, 'error'); }
    finally { event.target.value = ''; }
  }

  async function sendNow() {
    const targets = currentTargetKeys();
    const mediaIds = selectedMediaIds();
    const text = String($('#sendText')?.value || '').trim();
    const extraPreText = String($('#sendPreText')?.value || '').trim();
    const defaultPreText = String($('#defaultPreText')?.value || '').trim();
    // The old default was the literal brand label "chat BOT", which accidentally
    // overrode the message the user typed. Combine actual user-entered text first.
    const preText = [extraPreText, text].filter(Boolean).join('\n') || (mediaIds.length ? defaultPreText : '');
    const postText = String($('#sendPostText')?.value || '').trim();
    if (!targets.length) return notify('حدد شخصًا أو مجموعة واحدة على الأقل.', 'error');
    if (!preText.trim() && !postText.trim() && !mediaIds.length) return notify('اكتب رسالة أو اختر ملفًا.', 'error');
    try {
      const result = await api('/api/send', { method: 'POST', body: JSON.stringify({
        sessionId: sid(), targetKeys: targets, text: '', preText, postText, mediaIds,
        sendOrder: $('#sendOrder')?.value || 'target-first', repeatGuard: $('#repeatGuard')?.value !== 'off', replaceDuplicate: $('#replaceSendDuplicate')?.checked === true
      }) });
      const failed = Array.isArray(result.failed) ? result.failed : [];
      const sentCount = Number.isFinite(Number(result.sentCount)) ? Number(result.sentCount) : (Array.isArray(result.sent) ? result.sent.length : 0);
      // Only transient failures may be preselected for a retry. Permission,
      // rate-limit, duplicate-guard and uncertain outcomes require user review first.
      const failedKeys = [...new Set(failed.filter(item => item.targetId && item.retryable === true && item.code !== 'SEND_UNCERTAIN').map(item => `${item.kind === 'group' ? 'g' : 'r'}:${item.targetId}`))];
      state.pendingTargets = failedKeys;
      const details = failed.slice(0, 4).map(item => `${item.target || 'مستلم'}: ${item.error || 'تعذر الإرسال'}`).join(' | ');
      const hasNeedsReview = failed.some(item => item.retryable !== true || item.code === 'SEND_UNCERTAIN');
      const summary = result.message || `تمت ${sentCount} عملية إرسال${failed.length ? `، وفشلت ${failed.length}` : ''}.`;
      const review = hasNeedsReview ? ' الأخطاء غير القابلة لإعادة المحاولة لم تُحدّد تلقائيًا؛ راجعها قبل محاولة جديدة.' : '';
      notify(details ? `${summary} ${details}${review}` : `${summary}${review}`, failed.length ? 'warning' : 'success');
      await load(true);
    } catch (error) { notify(error.message, 'error'); }
  }

  function bindSchedule() {
    $('#scheduleMode')?.addEventListener('change', (event) => {
      const value = event.target.value;
      $('.schedule-date')?.toggleAttribute('hidden', value !== 'once');
      $('.schedule-day')?.toggleAttribute('hidden', value !== 'weekly');
      $('.schedule-dom')?.toggleAttribute('hidden', !['monthly', 'yearly'].includes(value));
      $('.schedule-month')?.toggleAttribute('hidden', value !== 'yearly');
    });
    $$('[data-delete-task]').forEach((button) => button.addEventListener('click', async () => {
      try { await api(`/api/automation/task/${encodeURIComponent(button.dataset.deleteTask)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); }
    }));
    $$('[data-toggle-task]').forEach((button) => button.addEventListener('click', async () => {
      try { await api(`/api/automation/task/${encodeURIComponent(button.dataset.toggleTask)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); }
    }));
    $$('[data-run-task]').forEach((button) => button.addEventListener('click', async () => {
      try { const result = await api(`/api/automation/task/${encodeURIComponent(button.dataset.runTask)}/run`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم التشغيل.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    }));
    $$('[data-edit-task]').forEach((button) => button.addEventListener('click', () => loadTaskIntoEditor(button.dataset.editTask)));
    $('#scheduleBtn')?.addEventListener('click', createOrUpdateTask);
    $('#cancelScheduleEditBtn')?.addEventListener('click', () => { state.editingTaskId = null; render(); });
  }

  async function loadTaskIntoEditor(taskId) {
    const task = (state.data?.automation?.tasks || []).find((item) => item.id === taskId);
    if (!task) return notify('الموعد غير موجود.', 'error');
    $('#scheduleName').value = task.name || '';
    $('#scheduleTime').value = task.time || '17:30';
    $('#scheduleMode').value = task.mode || 'weekly';
    $('#scheduleDate').value = task.date || '';
    $('#scheduleDay').value = String(task.day ?? 5);
    $('#scheduleDayOfMonth').value = String(task.dayOfMonth ?? 1);
    $('#scheduleMonth').value = String(task.month || 1);
    $('#scheduleText').value = task.preText || '';
    $('#schedulePostText').value = task.postText || '';
    $('#scheduleMediaMode').value = task.mediaMode || 'selected';
    $('#scheduleGroupsEnabled').checked = task.scheduledGroupsEnabled !== false;
    state.editingTaskId = task.id;
    if ($('#sendScheduleDisclosure')) { $('#sendScheduleDisclosure').open = true; $('#sendScheduleDisclosure').scrollIntoView({ behavior: 'smooth', block: 'center' }); }
    const scheduleButton = $('#scheduleBtn'); if (scheduleButton) scheduleButton.textContent = 'حفظ تعديل الموعد';
    const cancelButton = $('#cancelScheduleEditBtn'); if (cancelButton) cancelButton.hidden = false;
    state.pendingTargets = Array.isArray(task.targetKeys) ? [...task.targetKeys] : [];
    $$('.target').forEach((input) => { input.checked = state.pendingTargets.includes(input.value); });
    $$('.send-media').forEach((input) => { input.checked = (task.mediaIds || []).includes(input.value); });
    notify('تم تحميل الموعد للتعديل. عدّل ثم اضغط حفظ.', 'info');
  }

  async function createOrUpdateTask() {
    const targets = currentTargetKeys();
    const mediaIds = selectedMediaIds();
    const mode = $('#scheduleMode').value;
    const text = $('#scheduleText').value.trim() || $('#sendText')?.value.trim() || '';
    if (!targets.length) return notify('حدد أهداف الموعد.', 'error');
    if (!text && !mediaIds.length && $('#scheduleMediaMode').value !== 'cycle') return notify('أضف نصًا أو ملفًا للموعد.', 'error');
    const payload = {
      sessionId: sid(), name: $('#scheduleName').value.trim() || 'موعد جديد', mode, time: $('#scheduleTime').value,
      date: $('#scheduleDate').value, day: Number($('#scheduleDay').value), dayOfMonth: Number($('#scheduleDayOfMonth').value), month: Number($('#scheduleMonth').value),
      targetKeys: targets, mediaIds, mediaMode: $('#scheduleMediaMode').value, preText: text, postText: $('#schedulePostText').value.trim(), sendOrder: $('#sendOrder')?.value || 'target-first',
      scheduledGroupsEnabled: $('#scheduleGroupsEnabled').checked
    };
    try {
      const url = state.editingTaskId ? `/api/automation/task/${encodeURIComponent(state.editingTaskId)}` : '/api/automation/task';
      const method = state.editingTaskId ? 'PUT' : 'POST';
      const result = await api(url, { method, body: JSON.stringify(payload) });
      notify(result.message || 'تم حفظ الموعد.', 'success');
      state.editingTaskId = null;
      await load(true);
    } catch (error) { notify(error.message, 'error'); }
  }

  function bindAutomation() {
    $('#automationRuleForm')?.addEventListener('submit', async (event) => {
      event.preventDefault();
      const triggerType = $('#autoRuleTrigger').value;
      const targetMode = $('#autoRuleTargetMode').value;
      const action = triggerType === 'message-age' ? 'cleanup-old-messages' : $('#autoRuleAction').value;
      const payload = {
        sessionId: sid(), name: $('#autoRuleName').value.trim(), priority: Number($('#autoRulePriority').value || 0), triggerType,
        matchMode: $('#autoRuleMatch').value, pattern: $('#autoRulePattern').value,
        action, targetMode, targetKeys: $$('.automation-target:checked').map(input => input.value),
        targetChatIds: $('#autoRuleChatIds').value.split(/[\n,;\s]+/).map(x => x.trim()).filter(Boolean),
        cooldownSec: Number($('#autoRuleCooldown').value || 0), threshold: Number($('#autoRuleThreshold').value || 50),
        countScope: $('#autoRuleCountScope').value, ageHours: Number($('#autoRuleAgeHours').value || 24),
        time: $('#autoRuleTime').value || '22:00', mode: $('#autoRuleMode').value, date: $('#autoRuleDate').value,
        day: Number($('#autoRuleDay').value), dayOfMonth: Number($('#autoRuleDayOfMonth').value || 1), month: Number($('#autoRuleMonth').value || 1), timezone: state.data?.settings?.timezone || 'Asia/Muscat',
        minMessageCount: Number($('#autoRuleMinCount').value || 0), maxMessageCount: Number($('#autoRuleMaxCount').value || 0), conditionContains: $('#autoRuleConditionContains').value.trim(),
        repeatCount: $('#autoRuleRepeatCount').checked, requireGroupAdmin: $('#autoRuleRequireAdmin').checked,
        deleteForEveryone: $('#autoRuleDeleteEveryone').checked, confirmDestructive: $('#autoRuleConfirmDestructive').checked,
        mutePermanent: $('#autoRuleMutePermanent').checked, muteMinutes: Number($('#autoRuleMuteMinutes').value || 60),
      };
      if (['time','message-age'].includes(triggerType) && payload.targetMode === 'current' && action !== 'log') return notify('اختر أهدافًا محددة أو كل الأهداف للقاعدة المجدولة.', 'error');
      if (triggerType === 'message-age' && !payload.confirmDestructive) return notify('أكد إجراء تنظيف الرسائل القديمة قبل الحفظ.', 'error');
      if (payload.mode === 'once' && !payload.date) return notify('اختر تاريخ تشغيل القاعدة.', 'error');
      try {
        const editing = state.editingAutomationRuleId;
        const result = await api(editing ? `/api/automation/rules/${encodeURIComponent(editing)}` : '/api/automation/rules', { method: editing ? 'PUT' : 'POST', body: JSON.stringify(payload) });
        state.editingAutomationRuleId = '';
        notify(result.message || 'تم حفظ قاعدة الأتمتة.', 'success');
        await load(true);
      } catch (error) { notify(error.message, 'error'); }
    });
    $('#autoRuleTrigger')?.addEventListener('change', () => {
      const trigger = $('#autoRuleTrigger').value;
      if (trigger === 'message-age') $('#autoRuleAction').value = 'cleanup-old-messages';
      if (['time','message-age'].includes(trigger) && $('#autoRuleTargetMode').value === 'current') $('#autoRuleTargetMode').value = 'selected';
      if (trigger === 'group-message') $('#autoRuleRequireAdmin').checked = true;
    });
    $('#autoRuleTargetMode')?.addEventListener('change', () => {
      const mode = $('#autoRuleTargetMode').value;
      const trigger = $('#autoRuleTrigger').value;
      if (['time','message-age'].includes(trigger) && mode === 'current') notify('القاعدة المجدولة تحتاج أهدافًا محددة أو كل الأهداف.', 'info');
    });
    $('#cancelAutoRuleEdit')?.addEventListener('click', () => { state.editingAutomationRuleId = ''; render(); });
    $$('[data-edit-auto-rule]').forEach(button => button.addEventListener('click', () => { state.editingAutomationRuleId = button.dataset.editAutoRule; render(); $('#automationRuleForm')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }));
    $$('[data-toggle-auto-rule]').forEach(button => button.addEventListener('click', async () => { try { await api(`/api/automation/rules/${encodeURIComponent(button.dataset.toggleAutoRule)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-auto-rule]').forEach(button => button.addEventListener('click', async () => { if (!confirm('حذف قاعدة الأتمتة نهائيًا؟')) return; try { await api(`/api/automation/rules/${encodeURIComponent(button.dataset.deleteAutoRule)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); if (state.editingAutomationRuleId === button.dataset.deleteAutoRule) state.editingAutomationRuleId = ''; await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-run-auto-rule]').forEach(button => button.addEventListener('click', async () => { if (!confirm('تنفيذ الإجراء الآن على الأهداف المحددة؟ قد يؤدي ذلك إلى حذف بيانات أو تغيير حالة المحادثة.')) return; try { const result = await api(`/api/automation/rules/${encodeURIComponent(button.dataset.runAutoRule)}/run`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم التنفيذ.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $('#saveAutomationPermissions')?.addEventListener('click', async () => { const payload = { sessionId: sid() }; $$('.automation-permission').forEach(input => { payload[input.dataset.permission] = input.checked; }); try { const result = await api('/api/automation/group-permissions', { method: 'POST', body: JSON.stringify(payload) }); notify(result.message || 'تم الحفظ.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#muteSavedTarget')?.addEventListener('change', () => { if ($('#muteSavedTarget').value) $('#muteChatId').value = $('#muteSavedTarget').value; });
    $('#muteMode')?.addEventListener('change', () => { $('#muteMinutes').disabled = $('#muteMode').value === 'permanent'; });
    $('#automationMuteForm')?.addEventListener('submit', async (event) => { event.preventDefault(); const chatId = $('#muteChatId').value.trim(); const mode = $('#muteMode').value; if (!chatId) return notify('أدخل معرّف المحادثة.', 'error'); if (mode === 'permanent' && !confirm('سيظل الكتم قائمًا حتى تلغيه يدويًا. هل تريد المتابعة؟')) return; try { const target = activeTargets(state.data || {}).find(t => chatIdForTarget(t) === chatId); const result = await api('/api/automation/mutes', { method: 'POST', body: JSON.stringify({ sessionId: sid(), chatId, chatName: target?.name || chatId, mode, minutes: Number($('#muteMinutes').value || 60) }) }); notify(result.message || 'تم تطبيق الكتم.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $$('[data-unmute-record]').forEach(button => button.addEventListener('click', async () => { if (!confirm('إلغاء كتم هذه المحادثة؟')) return; try { const result = await api(`/api/automation/mutes/${encodeURIComponent(button.dataset.unmuteRecord)}/unmute`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم إلغاء الكتم.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-mute]').forEach(button => button.addEventListener('click', async () => { if (!confirm('حذف إعداد الكتم؟ إذا كان نشطًا سيُلغى الكتم أولًا.')) return; try { const result = await api(`/api/automation/mutes/${encodeURIComponent(button.dataset.deleteMute)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم حذف السجل.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $('#refreshAutomationBtn')?.addEventListener('click', () => load(true).catch(e => notify(e.message, 'error')));
  }

  function bindPeopleSearch() {}
  function bindGroupSearch() {}

  function bindPeople() {
    loadCountries().then(() => {
      const country = $('#recipientCountry');
      if (country) country.innerHTML = countryOptions(country.value || 'OM');
    }).catch(() => {});
    $('#recipientPhone')?.addEventListener('blur', async () => {
      const value = $('#recipientPhone').value.trim();
      if (!value) return;
      try { const result = await api('/api/phone/validate', { method: 'POST', body: JSON.stringify({ phone: value, country: $('#recipientCountry').value }) }); $('#phonePreview').textContent = `سيُحفظ كـ ${result.phone?.international || result.phone?.e164 || 'رقم صالح'}`; } catch (error) { $('#phonePreview').textContent = error.message; }
    });
    $('#addRecipientBtn')?.addEventListener('click', async () => {
      try { const result = await api('/api/recipient', { method: 'POST', body: JSON.stringify({ sessionId: sid(), name: $('#recipientName').value.trim(), phone: $('#recipientPhone').value, country: $('#recipientCountry').value }) }); notify(`تمت إضافة ${result.recipient?.name || 'الشخص'}`, 'success'); await load(true); } catch (error) { notify(error.message, 'error'); }
    });
    $('#bulkAddBtn')?.addEventListener('click', async () => {
      try { const result = await api('/api/recipients/bulk', { method: 'POST', body: JSON.stringify({ sessionId: sid(), lines: $('#bulkRecipients').value, country: $('#recipientCountry').value }) }); notify(`أضيف ${result.added?.length || 0} رقم${result.failed?.length ? `، وتعذر ${result.failed.length}` : ''}`, result.failed?.length ? 'info' : 'success'); await load(true); } catch (error) { notify(error.message, 'error'); }
    });
    $('#loadWhatsAppContactsBtn')?.addEventListener('click', () => loadWhatsAppContacts());
    $('#whatsappContactFilter')?.addEventListener('input', event => {
      state.whatsappContactFilter = event.target.value;
      const list = $('#whatsappContactsList'); if (list) list.innerHTML = whatsappContactRows();
      bindWhatsAppContactCheckboxes();
      bindWhatsAppContactImportButtons();
    });
    $('#selectAllWhatsAppContacts')?.addEventListener('click', () => {
      const needle = String(state.whatsappContactFilter || '').trim().toLocaleLowerCase('ar');
      (state.whatsappContacts || []).filter(contact => `${contact.name || ''} ${contact.pushname || ''} ${contact.notifyName || ''} ${contact.digits || ''} ${contact.jid || ''}`.toLocaleLowerCase('ar').includes(needle)).forEach(contact => state.whatsappContactsSelected.add(contact.jid));
      refreshWhatsAppSelectionUI();
    });
    $('#clearWhatsAppContacts')?.addEventListener('click', () => { state.whatsappContactsSelected.clear(); refreshWhatsAppSelectionUI(); });
    $('#syncWhatsAppContactsBtn')?.addEventListener('click', async () => {
      const jids = [...state.whatsappContactsSelected];
      if (!jids.length) return notify('حدد جهات WhatsApp التي تريد مزامنتها.', 'warning');
      const pictures = $('#syncWhatsAppUpdatePictures')?.checked !== false;
      const max = pictures ? 100 : 500;
      if (jids.length > max) return notify(`حد هذه الدفعة ${max} جهة${pictures ? ' عند مزامنة الصور' : ''}. حدّد عددًا أقل ثم تابع بدفعات متعددة.`, 'warning');
      if (!confirm(`ستتم مزامنة ${jids.length} جهة إلى الجلسة الحالية. ${$('#syncWhatsAppUpdateNames')?.checked ? 'قد تتغير الأسماء المحلية حسب خيار التحديث.' : 'ستظل الأسماء المحلية الحالية كما هي.'} المتابعة؟`)) return;
      const button = $('#syncWhatsAppContactsBtn'); if (button) { button.disabled = true; button.textContent = 'جارٍ المزامنة…'; }
      try {
        const result = await api('/api/whatsapp/contacts/sync', { method: 'POST', body: JSON.stringify({ sessionId: sid(), jids, importMissing: true, updateNames: $('#syncWhatsAppUpdateNames')?.checked === true, updatePictures: pictures }) });
        const recipientIds = queueRecipientsForSending(result);
        state.whatsappContactsSelected.clear(); state.whatsappContactsOpen = true;
        notify(`${result.message || 'اكتملت إضافة جهات WhatsApp.'}${recipientIds.length ? ` تمت إضافتها/تحديثها في قائمة الإرسال (${recipientIds.length}).` : ''}`, 'success');
        await load(true);
      } catch (error) { notify(error.message, 'error'); if (button) { button.disabled = false; button.textContent = `إضافة المحدد إلى قائمة الإرسال (${jids.length})`; } }
    });
    bindWhatsAppContactCheckboxes();
    bindWhatsAppContactImportButtons();
    $('#selectVisiblePeople')?.addEventListener('change', event => {
      const ids = $$('.person-select').map(box => String(box.dataset.personSelect));
      if (event.target.checked) ids.forEach(id => state.selectedRecipientIds.add(id)); else ids.forEach(id => state.selectedRecipientIds.delete(id));
      updatePeopleSelection();
    });
    $('#deleteSelectedPeopleBtn')?.addEventListener('click', async () => {
      const ids = [...state.selectedRecipientIds];
      if (!ids.length) return notify('حدد شخصًا واحدًا على الأقل.', 'warning');
      if (!confirm(`سيُحذف ${ids.length} شخصًا من الجلسة الحالية، وستُنظف أهدافهم المرتبطة بالجدولة والأتمتة. لا يمكن التراجع عن الحذف من داخل التطبيق. متابعة؟`)) return;
      try {
        const result = await api('/api/recipients/bulk', { method: 'DELETE', body: JSON.stringify({ sessionId: sid(), ids }) });
        for (const id of (result.removedIds || ids)) state.selectedRecipientIds.delete(String(id));
        notify(result.message || `تم حذف ${result.deleted?.length || 0} شخصًا.`, 'success');
        await load(true);
      } catch (error) { notify(error.message, 'error'); }
    });
    $('#peopleSearch')?.addEventListener('input', (event) => { state.peopleFilter = event.target.value; clearTimeout(bindPeopleSearch.timer); bindPeopleSearch.timer = setTimeout(() => { const list = $('.people-list'); if (list) { const filter = state.peopleFilter.trim().toLocaleLowerCase('ar'); const rows = (state.data?.recipients || []).filter((item) => `${item.name || ''} ${item.international || ''} ${item.e164 || ''}`.toLocaleLowerCase('ar').includes(filter)); list.innerHTML = rows.length ? rows.map(personRow).join('') : '<div class="empty">لا توجد نتائج.</div>'; bindPeopleRows(); } }, 120); });
    bindPeopleRows();
  }

  async function loadWhatsAppContacts() {
    if (state.whatsappContactsBusy) return;
    state.whatsappContactsOpen = true; state.whatsappContactsBusy = true;
    const status = $('#whatsappContactsStatus'); if (status) status.textContent = 'جارٍ استدعاء جهات WhatsApp من الجلسة المتصلة…';
    const button = $('#loadWhatsAppContactsBtn'); if (button) { button.disabled = true; button.textContent = 'جارٍ الاستدعاء…'; }
    try {
      const result = await api(`/api/whatsapp/contacts?sessionId=${encodeURIComponent(sid())}`);
      state.whatsappContacts = Array.isArray(result.contacts) ? result.contacts : [];
      state.whatsappContactsSession = sid(); state.whatsappContactsSelected.clear(); state.whatsappContactFilter = '';
      notify(result.message || `تم استدعاء ${state.whatsappContacts.length} جهة.`, 'success');
    } catch (error) {
      state.whatsappContacts = null;
      notify(error.message, 'error');
    } finally {
      state.whatsappContactsBusy = false;
      render();
      if (state.page === 'people') { $('#whatsappContactsDisclosure')?.setAttribute('open', ''); bindWhatsAppContactCheckboxes(); bindWhatsAppContactImportButtons(); }
    }
  }

  function queueRecipientsForSending(result) {
    const ids = [...new Set([...(result?.imported || []), ...(result?.updated || [])].map(person => String(person.id || '')).filter(Boolean))];
    // null means "select every recipient" in the send view. After an explicit
    // import action, switch to a deliberate selection instead of accidentally
    // targeting every saved contact when the user only added one from WhatsApp.
    const previous = Array.isArray(state.pendingTargets) ? state.pendingTargets : [];
    state.pendingTargets = [...new Set([...previous, ...ids.map(id => `r:${id}`)])];
    return ids;
  }

  function bindWhatsAppContactImportButtons() {
    $$('[data-import-wa-contact]').forEach(button => {
      if (button.dataset.bound === '1') return;
      button.dataset.bound = '1';
      button.addEventListener('click', async () => {
        const jid = String(button.dataset.importWaContact || '').trim().toLowerCase();
        if (!/^\d{5,25}@c\.us$/.test(jid)) return notify('معرّف جهة غير صالح. أعد استدعاء قائمة WhatsApp.', 'error');
        const label = button.textContent;
        button.disabled = true; button.textContent = 'جارٍ الإضافة…';
        try {
          const result = await api('/api/whatsapp/contact/import', { method: 'POST', body: JSON.stringify({ sessionId: sid(), jid }) });
          const ids = queueRecipientsForSending({ imported: result.imported, updated: result.updated });
          state.whatsappContactsSelected.delete(jid); state.whatsappContactsOpen = true;
          notify(`${result.message || 'تمت إضافة جهة WhatsApp.'}${ids.length ? ` أصبحت ضمن قائمة الإرسال (${ids.length}).` : ''}`, 'success');
          await load(true);
          // Keep the retrieved list visible so the user can add more contacts without repeating the query.
          $('#whatsappContactsDisclosure')?.setAttribute('open', '');
          bindWhatsAppContactCheckboxes(); bindWhatsAppContactImportButtons();
        } catch (error) { notify(error.message, 'error'); button.disabled = false; button.textContent = label; }
      });
    });
  }

  function bindWhatsAppContactCheckboxes() {
    $$('[data-wa-contact-select]').forEach(box => {
      if (box.dataset.bound === '1') return;
      box.dataset.bound = '1';
      box.addEventListener('change', () => {
        const jid = String(box.dataset.waContactSelect || '');
        if (box.checked) state.whatsappContactsSelected.add(jid); else state.whatsappContactsSelected.delete(jid);
        refreshWhatsAppSelectionUI();
      });
    });
  }

  function refreshWhatsAppSelectionUI() {
    $$('[data-wa-contact-select]').forEach(box => { box.checked = state.whatsappContactsSelected.has(String(box.dataset.waContactSelect || '')); });
    const count = $('#whatsappSelectedCount'); if (count) count.textContent = String(state.whatsappContactsSelected.size);
    const button = $('#syncWhatsAppContactsBtn'); if (button) { button.disabled = state.whatsappContactsSelected.size === 0; button.textContent = `إضافة المحدد إلى قائمة الإرسال (${state.whatsappContactsSelected.size})`; }
  }

  function updatePeopleSelection() {
    const selected = state.selectedRecipientIds.size;
    const visibleBoxes = $$('.person-select');
    const visibleSelected = visibleBoxes.filter(box => box.checked).length;
    const selectAll = $('#selectVisiblePeople');
    if (selectAll) { selectAll.checked = visibleBoxes.length > 0 && visibleSelected === visibleBoxes.length; selectAll.indeterminate = visibleSelected > 0 && visibleSelected < visibleBoxes.length; selectAll.disabled = visibleBoxes.length === 0; }
    const deleteButton = $('#deleteSelectedPeopleBtn');
    if (deleteButton) { deleteButton.disabled = selected === 0; deleteButton.textContent = `حذف المحدد (${selected})`; }
    const count = $('#peopleSelectedCount'); if (count) count.textContent = String(selected);
  }

  function bindPeopleRows() {
    $$('.person-select').forEach((box) => box.addEventListener('change', () => {
      const id = String(box.dataset.personSelect || '');
      if (box.checked) state.selectedRecipientIds.add(id); else state.selectedRecipientIds.delete(id);
      updatePeopleSelection();
    }));
    $$('[data-toggle-person]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/recipient/${encodeURIComponent(button.dataset.togglePerson)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-person]').forEach((button) => button.addEventListener('click', async () => { if (!confirm('حذف الشخص من هذه الجلسة وتنظيف أهدافه المرتبطة؟')) return; try { await api(`/api/recipient/${encodeURIComponent(button.dataset.deletePerson)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); state.selectedRecipientIds.delete(String(button.dataset.deletePerson)); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-add-person-rule]').forEach(button => button.addEventListener('click', () => {
      const form = button.closest('form[data-person-reply-form]'); const list = form?.querySelector('[data-person-rules]');
      if (!form || !list) return;
      const existing = list.querySelectorAll('[data-person-rule-row]');
      if (existing.length >= 30) return notify('الحد الأقصى 30 قاعدة رد لكل شخص.', 'warning');
      list.querySelector('[data-person-rules-empty]')?.remove();
      list.insertAdjacentHTML('beforeend', personalRuleEditor({ id: `pr-${Date.now()}-${Math.random().toString(16).slice(2,7)}`, name: `قاعدة ${existing.length + 1}`, match: 'contains', value: '', reply: '', enabled: true }, existing.length));
      const counter = form.querySelector('[data-person-rule-count]'); if (counter) counter.textContent = String(existing.length + 1);
      bindPersonalRuleDeletes(list);
    }));
    $$('[data-person-reply-form]').forEach(form => form.addEventListener('submit', async event => {
      event.preventDefault();
      const personId = String(form.dataset.personReplyForm || '');
      const rules = [...form.querySelectorAll('[data-person-rule-row]')].map(row => ({
        id: row.dataset.ruleId || `pr-${Date.now()}-${Math.random().toString(16).slice(2,7)}`,
        name: row.querySelector('[data-person-rule-name]')?.value.trim() || '',
        match: row.querySelector('[data-person-rule-match]')?.value || 'contains',
        value: row.querySelector('[data-person-rule-value]')?.value || '',
        reply: row.querySelector('[data-person-rule-reply]')?.value || '',
        enabled: row.querySelector('[data-person-rule-enabled]')?.checked !== false,
      }));
      const profile = {
        mode: form.querySelector('[data-person-profile-mode]')?.value || 'inherit',
        enabled: form.querySelector('[data-person-profile-enabled]')?.checked !== false,
        fallbackToGlobal: form.querySelector('[data-person-profile-fallback]')?.checked !== false,
        defaultReply: form.querySelector('[data-person-profile-default]')?.value || '',
        cooldownSec: Number(form.querySelector('[data-person-profile-cooldown]')?.value || 45),
        rules,
      };
      try {
        const result = await api(`/api/recipient/${encodeURIComponent(personId)}/reply-profile`, { method: 'PUT', body: JSON.stringify({ sessionId: sid(), profile }) });
        notify(result.message || 'تم حفظ إعداد الرد الشخصي.', 'success'); await load(true);
      } catch (error) { notify(error.message, 'error'); }
    }));
    $$('[data-person-rules]').forEach(bindPersonalRuleDeletes);
    updatePeopleSelection();
  }

  function bindPersonalRuleDeletes(list) {
    $$('[data-delete-person-rule]', list).forEach(button => {
      if (button.dataset.boundDeleteRule === '1') return;
      button.dataset.boundDeleteRule = '1';
      button.addEventListener('click', () => {
        const form = button.closest('form');
        button.closest('[data-person-rule-row]')?.remove();
        const rules = form?.querySelector('[data-person-rules]');
        const remaining = rules?.querySelectorAll('[data-person-rule-row]').length || 0;
        if (rules && remaining === 0) rules.innerHTML = '<div class="empty" data-person-rules-empty>لا توجد قواعد شخصية؛ يمكن استخدام الرد الافتراضي أو القواعد العامة.</div>';
        const counter = form?.querySelector('[data-person-rule-count]'); if (counter) counter.textContent = String(remaining);
        if (rules) bindPersonalRuleDeletes(rules);
      });
    });
  }

  function bindGroups() {
    $('#connectGroupBtn')?.addEventListener('click', async () => {
      const value = $('#groupValue').value.trim();
      if (!value) return notify('أدخل GID أو رابط دعوة.', 'error');
      $('#groupResult').textContent = 'جاري الربط والتحليل…';
      try { const result = await api('/api/groups/connect', { method: 'POST', body: JSON.stringify({ sessionId: sid(), value }) }); state.selectedGroup = result.group?.gid || null; notify(result.message || 'تم الربط.', 'success'); await load(true); } catch (error) { $('#groupResult').textContent = error.message; notify(error.message, 'error'); }
    });
    $('#discoverGroupsBtn')?.addEventListener('click', async () => {
      try { const result = await api('/api/groups/discover', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم الاكتشاف.', 'success'); await load(true); } catch (error) { notify(error.message, 'error'); }
    });
    $('#refreshGroupsBtn')?.addEventListener('click', async () => {
      try { const result = await api('/api/groups/refresh-all', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم التحديث.', result.failed?.length ? 'info' : 'success'); await load(true); } catch (error) { notify(error.message, 'error'); }
    });
    $('#groupSearch')?.addEventListener('input', (event) => { state.groupFilter = event.target.value; clearTimeout(bindGroupSearch.timer); bindGroupSearch.timer = setTimeout(() => { const list = $('.group-list'); if (list) { const filter = state.groupFilter.trim().toLocaleLowerCase('ar'); const groups = (state.data?.groups || []).filter((group) => `${group.name || ''} ${group.gid || ''}`.toLocaleLowerCase('ar').includes(filter)); const current = state.selectedGroup && (state.data?.groups || []).find((group) => group.gid === state.selectedGroup); list.innerHTML = groups.length ? groups.map((group) => groupRow(group, current?.gid === group.gid)).join('') : '<div class="empty">لا توجد نتائج.</div>'; bindGroupRows(); } }, 120); });
    bindGroupRows();
  }

  function bindGroupRows() {
    $$('[data-show-group]').forEach((button) => button.addEventListener('click', () => { state.selectedGroup = button.dataset.showGroup; render(); }));
    $$('[data-send-group]').forEach((button) => button.addEventListener('click', () => { state.pendingTargets = [`g:${button.dataset.sendGroup}`]; go('send'); }));
    $$('[data-copy-group]').forEach((button) => button.addEventListener('click', async () => { try { await navigator.clipboard.writeText(button.dataset.copyGroup); notify('تم نسخ GID.', 'success'); } catch { notify('تعذر النسخ من المتصفح.', 'error'); } }));
    $$('[data-toggle-group]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/groups/${encodeURIComponent(button.dataset.toggleGroup)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-group]').forEach((button) => button.addEventListener('click', async () => { if (!confirm('حذف المجموعة من هذه الجلسة؟')) return; try { await api(`/api/groups/${encodeURIComponent(button.dataset.deleteGroup)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); state.selectedGroup = null; await load(true); } catch (e) { notify(e.message, 'error'); } }));
  }

  function applyRulePreset(name) {
    const presets = {
      welcome: { name:'ترحيب جديد', event:'message', match:'contains', value:'السلام عليكم', action:'reply', reply:'وعليكم السلام {{sender}} 👋', emoji:'' },
      help: { name:'مساعدة', event:'message', match:'contains', value:'مساعدة', action:'reply', reply:'اكتب كلمة أو أمرًا وسأرد حسب القواعد التي أنشأتها.', emoji:'' },
      reaction: { name:'تفاعل بالإعجاب', event:'reaction', match:'any', value:'', action:'reaction', reply:'', emoji:'👍' },
    };
    const p = presets[name]; if (!p) return;
    if ($('#ruleEditorDisclosure')) $('#ruleEditorDisclosure').open = true;
    if ($('#ruleName')) $('#ruleName').value=p.name; if ($('#ruleEvent')) $('#ruleEvent').value=p.event; if ($('#ruleMatch')) $('#ruleMatch').value=p.match; if ($('#ruleValue')) $('#ruleValue').value=p.value; if ($('#ruleAction')) $('#ruleAction').value=p.action; if ($('#ruleReply')) $('#ruleReply').value=p.reply; if ($('#ruleEmoji')) $('#ruleEmoji').value=p.emoji;
    $('#ruleAction')?.dispatchEvent(new Event('change')); $('#ruleEvent')?.dispatchEvent(new Event('change'));
    notify('تم تحميل القالب ويمكنك تعديله قبل الحفظ.', 'info');
  }

  function fillRuleForm(rule) {
    if (!rule) return;
    state.interactionEditingRule = rule.id;
    if ($('#ruleEditorDisclosure')) $('#ruleEditorDisclosure').open = true;
    $('#ruleEditorTitle').textContent = 'تعديل القاعدة';
    $('#addRuleBtn').textContent = 'حفظ التعديلات'; $('#cancelRuleEditBtn').hidden = false;
    $('#ruleName').value = rule.name || '';
    $('#ruleEvent').value = rule.when?.type || 'message';
    $('#ruleMatch').value = rule.when?.match || 'contains';
    $('#ruleValue').value = rule.when?.value || '';
    $('#ruleScope').value = rule.scope || 'all';
    $('#ruleAction').value = rule.then?.reaction && (rule.then?.replies?.length || rule.then?.reply) ? 'both' : rule.then?.reaction ? 'reaction' : 'reply';
    $('#ruleReply').value = (Array.isArray(rule.then?.replies) && rule.then.replies.length ? rule.then.replies : [rule.then?.reply || '']).filter(Boolean).join('\n');
    $('#ruleEmoji').value = rule.then?.reaction || '';
    $('#rulePriority').value = Number(rule.priority || 0); $('#ruleCooldown').value = Number(rule.cooldownSec || 0);
    $('#ruleStop').checked = rule.then?.stopAfter !== false; $('#ruleCommandPriority').checked = rule.commandPriority === true;
    $('#ruleConflictGroup').value = rule.conflictGroup || '';
    $('#ruleScheduleEnabled').checked = rule.schedule?.enabled === true;
    $('#ruleScheduleStart').value = rule.schedule?.start || '09:00'; $('#ruleScheduleEnd').value = rule.schedule?.end || '17:00';
    $$('.rule-schedule-day').forEach((input) => { input.checked = Array.isArray(rule.schedule?.days) && rule.schedule.days.map(Number).includes(Number(input.value)); });
    $('#ruleAction').dispatchEvent(new Event('change')); $('#ruleEvent').dispatchEvent(new Event('change'));
    $('#ruleName').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  function resetRuleForm() {
    state.interactionEditingRule = '';
    if ($('#ruleEditorDisclosure')) $('#ruleEditorDisclosure').open = false;
    $('#ruleEditorTitle').textContent = 'إنشاء قاعدة رد'; $('#addRuleBtn').textContent = 'حفظ القاعدة'; $('#cancelRuleEditBtn').hidden = true;
    $('#ruleName').value = ''; $('#ruleValue').value = ''; $('#ruleReply').value = ''; $('#ruleEmoji').value = '';
    $('#rulePriority').value = '10'; $('#ruleCooldown').value = '45'; $('#ruleCommandPriority').checked = false; $('#ruleConflictGroup').value = '';
    $('#ruleStop').checked = true; $('#ruleScheduleEnabled').checked = false;
    $$('.rule-schedule-day').forEach(input => { input.checked = true; });
    $('#ruleAction').value = 'reply'; $('#ruleEvent').value = 'message'; $('#ruleMatch').value = 'contains'; $('#ruleScope').value = 'all';
    $('#ruleAction').dispatchEvent(new Event('change'));
  }
  function fillCounterForm(trigger) {
    if (!trigger) return;
    state.interactionEditingCounter = trigger.id;
    if ($('#counterEditorDisclosure')) $('#counterEditorDisclosure').open = true;
    $('#counterName').value = trigger.name || ''; $('#counterThreshold').value = Number(trigger.threshold || 100);
    $('#counterScope').value = trigger.scope || 'session'; $('#counterPriority').value = Number(trigger.priority || 0);
    $('#counterActionType').value = trigger.actionType || 'reply';
    $('#counterReplies').value = (trigger.then?.replies?.length ? trigger.then.replies : [trigger.then?.reply || '']).filter(Boolean).join('\n');
    $('#counterEmoji').value = trigger.then?.reaction || '';
    $('#saveCounterBtn').textContent = 'حفظ تعديل العداد'; $('#cancelCounterEditBtn').hidden = false;
    $('#counterActionType').dispatchEvent(new Event('change'));
    $('#counterName').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  function resetCounterForm() {
    state.interactionEditingCounter = '';
    if ($('#counterEditorDisclosure')) $('#counterEditorDisclosure').open = false;
    $('#counterName').value = ''; $('#counterThreshold').value = '100'; $('#counterScope').value = 'session'; $('#counterPriority').value = '5';
    $('#counterActionType').value = 'reply'; $('#counterReplies').value = ''; $('#counterEmoji').value = '';
    $('#saveCounterBtn').textContent = 'إضافة محفز عداد'; $('#cancelCounterEditBtn').hidden = true;
    $('#counterActionType').dispatchEvent(new Event('change'));
  }

  function bindInteraction() {
    $$('[data-rule-preset]').forEach((button) => button.addEventListener('click', () => applyRulePreset(button.dataset.rulePreset)));
    $('#saveInteractionSettings')?.addEventListener('click', saveInteractionSettings);
    $('#interactionSimilarityThreshold')?.addEventListener('input', () => { const out = $('#interactionSimilarityOutput'); if (out) out.textContent = `${Math.round(Number($('#interactionSimilarityThreshold').value) * 100)}%`; });
    const refreshActionFields = () => {
      const action = $('#ruleAction')?.value || 'reply';
      $('#ruleReplyWrap')?.toggleAttribute('hidden', action === 'reaction');
      $('#ruleEmojiWrap')?.toggleAttribute('hidden', action === 'reply');
    };
    const refreshCounterFields = () => {
      const action = $('#counterActionType')?.value || 'reply';
      $('#counterRepliesWrap')?.toggleAttribute('hidden', action !== 'reply');
      $('#counterEmojiWrap')?.toggleAttribute('hidden', action !== 'reaction');
    };
    $('#ruleAction')?.addEventListener('change', refreshActionFields); refreshActionFields();
    $('#counterActionType')?.addEventListener('change', refreshCounterFields); refreshCounterFields();
    $('#addRuleBtn')?.addEventListener('click', async () => {
      try {
        const action = $('#ruleAction').value, scope = $('#ruleScope').value;
        const replies = action === 'reaction' ? [] : [...new Set($('#ruleReply').value.split(/\r?\n/).map(value => value.trim()).filter(Boolean))];
        const body = {
          sessionId: sid(), name: $('#ruleName').value.trim() || 'قاعدة',
          when: { type: $('#ruleEvent').value, match: $('#ruleMatch').value, value: $('#ruleValue').value },
          then: { reply: replies[0] || '', replies, reaction: action === 'reply' ? '' : $('#ruleEmoji').value.trim(), stopAfter: $('#ruleStop').checked },
          scope, chatIds: scope === 'selected' ? $$('.rule-target:checked').map((input) => input.value) : [],
          priority: Number($('#rulePriority').value) || 0, cooldownSec: Number($('#ruleCooldown').value) || 0,
          commandPriority: $('#ruleCommandPriority').checked, conflictGroup: $('#ruleConflictGroup').value.trim(),
          schedule: { enabled: $('#ruleScheduleEnabled').checked, start: $('#ruleScheduleStart').value, end: $('#ruleScheduleEnd').value, days: $$('.rule-schedule-day:checked').map(input => Number(input.value)) }
        };
        const editing = state.interactionEditingRule;
        await api(editing ? `/api/interaction/rules/${encodeURIComponent(editing)}` : '/api/interaction/rules', { method: editing ? 'PUT' : 'POST', body: JSON.stringify(body) });
        resetRuleForm(); notify(editing ? 'تم تحديث القاعدة.' : 'تم حفظ القاعدة.', 'success'); await load(true);
      } catch (error) { notify(error.message, 'error'); }
    });
    $('#cancelRuleEditBtn')?.addEventListener('click', resetRuleForm);
    $$('[data-edit-rule]').forEach((button) => button.addEventListener('click', () => fillRuleForm((state.data?.interaction?.rules || []).find(rule => rule.id === button.dataset.editRule))));
    $('#testRuleBtn')?.addEventListener('click', async () => {
      try {
        const type = $('#ruleEvent').value, replies = $('#ruleReply').value.split(/\r?\n/).map(value => value.trim()).filter(Boolean);
        const rule = { when: { type, match: $('#ruleMatch').value, value: $('#ruleValue').value, threshold: Number($('#interactionSimilarityThreshold')?.value || .68) }, then: { reply: replies[0] || '', replies, reaction: $('#ruleEmoji').value }, schedule: { enabled: $('#ruleScheduleEnabled').checked, start: $('#ruleScheduleStart').value, end: $('#ruleScheduleEnd').value, days: $$('.rule-schedule-day:checked').map(input => Number(input.value)) } };
        const result = await api('/api/interaction/test', { method: 'POST', body: JSON.stringify({ sessionId: sid(), message: $('#ruleTestMessage').value, emoji: $('#ruleTestEmoji').value, sender: 'مستخدم الاختبار', rule }) });
        const score = Number.isFinite(Number(result.score)) ? ` · دقة ${Math.round(Number(result.score) * 100)}%` : '';
        const detectedIntent = result.intent && result.intent !== 'unknown' ? ` · النية: ${result.intent}` : '';
        notify(result.matched ? `${result.rendered || 'مطابقة ناجحة'}${score}${detectedIntent}` : `${result.message || 'لا توجد مطابقة.'}${score}${detectedIntent}`, result.matched ? 'success' : 'info');
      } catch (error) { notify(error.message, 'error'); }
    });
    $$('[data-toggle-rule]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/interaction/rules/${encodeURIComponent(button.dataset.toggleRule)}/toggle`, { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); await load(true); } catch (e) { notify(e.message, 'error'); } }));
    $$('[data-delete-rule]').forEach((button) => button.addEventListener('click', async () => { try { await api(`/api/interaction/rules/${encodeURIComponent(button.dataset.deleteRule)}`, { method: 'DELETE', body: JSON.stringify({ sessionId: sid() }) }); if (state.interactionEditingRule === button.dataset.deleteRule) resetRuleForm(); await load(true); } catch (e) { notify(e.message, 'error'); } }));

    $('#saveCounterBtn')?.addEventListener('click', async () => {
      try {
        const actionType = $('#counterActionType').value;
        const replies = actionType === 'reply' ? [...new Set($('#counterReplies').value.split(/\r?\n/).map(value => value.trim()).filter(Boolean))] : [];
        const body = { sessionId: sid(), name: $('#counterName').value.trim() || `عداد ${$('#counterThreshold').value}`, threshold: Number($('#counterThreshold').value), scope: $('#counterScope').value, priority: Number($('#counterPriority').value) || 0, actionType, replies, reaction: actionType === 'reaction' ? $('#counterEmoji').value.trim() : '' };
        const editing = state.interactionEditingCounter;
        await api(editing ? `/api/interaction/counters/${encodeURIComponent(editing)}` : '/api/interaction/counters', { method: editing ? 'PUT' : 'POST', body: JSON.stringify(body) });
        resetCounterForm(); notify(editing ? 'تم تحديث محفز العداد.' : 'تم حفظ محفز العداد.', 'success'); await load(true);
      } catch (error) { notify(error.message, 'error'); }
    });
    $('#cancelCounterEditBtn')?.addEventListener('click', resetCounterForm);
    $('#resetCountersBtn')?.addEventListener('click', async () => {
      if (!confirm('تصفير عدد الرسائل وإعادة تسليح جميع محفزات العدادات؟')) return;
      try { await api('/api/interaction/counters/reset', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify('تم تصفير العدادات.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $$('[data-edit-counter]').forEach(button => button.addEventListener('click', () => fillCounterForm((state.data?.interaction?.counterTriggers || []).find(trigger => trigger.id === button.dataset.editCounter))));
    $$('[data-toggle-counter]').forEach(button => button.addEventListener('click', async () => { try { await api(`/api/interaction/counters/${encodeURIComponent(button.dataset.toggleCounter)}/toggle`, { method:'POST', body:JSON.stringify({sessionId:sid()}) }); await load(true); } catch(e) { notify(e.message,'error'); } }));
    $$('[data-delete-counter]').forEach(button => button.addEventListener('click', async () => { try { await api(`/api/interaction/counters/${encodeURIComponent(button.dataset.deleteCounter)}`, { method:'DELETE', body:JSON.stringify({sessionId:sid()}) }); if (state.interactionEditingCounter === button.dataset.deleteCounter) resetCounterForm(); await load(true); } catch(e) { notify(e.message,'error'); } }));
  }

  async function saveInteractionSettings() {
    try {
      await api('/api/settings', { method: 'POST', body: JSON.stringify({
        sessionId: sid(), interactionEnabled: $('#interactionEnabled').checked, groupAssistantEnabled: $('#groupAssistantEnabled').checked, interactionIgnoreOwn: $('#interactionIgnoreOwn').checked,
        interactionScope: $('#interactionScope').value, interactionChatIds: $$('.rule-target:checked').map((input) => input.value), interactionQuietEnabled: $('#interactionQuietEnabled').checked,
        interactionQuietStart: $('#interactionQuietStart').value, interactionQuietEnd: $('#interactionQuietEnd').value,
        interactionQuietAction: $('#interactionQuietAction').value, interactionQuietReply: $('#interactionQuietReply').value,
        interactionQuietCooldownSec: Number($('#interactionQuietCooldownSec').value || 0), maxActionsPerMinute: Number($('#maxActionsPerMinute').value || 20),
        interactionConflictMode: $('#interactionConflictMode').value, interactionSimilarityThreshold: Number($('#interactionSimilarityThreshold').value || .68)
      }) });
      notify('تم حفظ إعدادات التفاعل.', 'success'); await load(true);
    } catch (error) { notify(error.message, 'error'); }
  }

  function bindSession() {
    $('#connectSessionBtn')?.addEventListener('click', async () => { try { const result = await api('/api/session/connect', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify(result.message || 'تم بدء الاتصال.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#stopSessionBtn')?.addEventListener('click', async () => { try { await api('/api/session/stop', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify('تم إيقاف الجلسة.', 'info'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#unlinkSessionBtn')?.addEventListener('click', async () => { if (!confirm('فصل الحساب من هذه الجلسة؟')) return; try { await api('/api/session/unlink', { method: 'POST', body: JSON.stringify({ sessionId: sid() }) }); notify('تم فصل الحساب.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#saveSessionBtn')?.addEventListener('click', async () => { try { await api(`/api/sessions/${encodeURIComponent(sid())}`, { method: 'PUT', body: JSON.stringify({ name: $('#sessionName').value.trim() }) }); notify('تم حفظ الاسم.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#newSessionBtn')?.addEventListener('click', async () => { try { await api('/api/sessions', { method: 'POST', body: JSON.stringify({ name: 'جلسة جديدة' }) }); notify('تم إنشاء الجلسة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
    $('#deleteSessionBtn')?.addEventListener('click', async () => { if (!confirm('حذف هذه الجلسة نهائيًا؟')) return; try { await api(`/api/sessions/${encodeURIComponent(sid())}`, { method: 'DELETE' }); state.page = 'dashboard'; state.pendingTargets = null; notify('تم حذف الجلسة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); } });
  }

  function applyUiPreset(name) {
    const presets = {
      mint: { accent: '#5ed6c1', accent2: '#8b7cf6', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .28 },
      ocean: { accent: '#56c9ff', accent2: '#57e5cf', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .25 },
      violet: { accent: '#9b86ff', accent2: '#e18aff', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .27 },
      sunset: { accent: '#ff9a6a', accent2: '#ff6fb1', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .24 },
    };
    const p = presets[name]; if (!p) return;
    if ($('#uiAccent')) $('#uiAccent').value = p.accent;
    if ($('#uiAccent2')) $('#uiAccent2').value = p.accent2;
    if ($('#uiPanelOpacity')) $('#uiPanelOpacity').value = p.panelOpacity;
    if ($('#uiPanelBlur')) $('#uiPanelBlur').value = p.panelBlur;
    if ($('#uiRadius')) $('#uiRadius').value = p.radius;
    if ($('#uiGlow')) $('#uiGlow').value = p.glow;
    ['uiPanelOpacity','uiPanelBlur','uiRadius','uiGlow'].forEach(updateRangeOutput);
    applyInterfaceLive();
    notify('تم تطبيق المظهر الجاهز. اضغط حفظ الواجهة لتثبيته.', 'info');
  }

  function bindAppearance() {
    const uiControls = ['uiPanelOpacity', 'uiPanelBlur', 'uiRadius', 'uiGlow'];
    uiControls.forEach((id) => $(`#${id}`)?.addEventListener('input', () => { updateRangeOutput(id); applyInterfaceLive(); }));
    $('#uiAccent')?.addEventListener('input', applyInterfaceLive);
    $('#uiAccent2')?.addEventListener('input', applyInterfaceLive);
    const syncThemeDots = () => { const a = readInterfaceForm(); if ($('#themeDot1')) $('#themeDot1').style.background = a.accent; if ($('#themeDot2')) $('#themeDot2').style.background = a.accent2; };
    syncThemeDots();
    $$('[data-ui-preset]').forEach((button) => button.addEventListener('click', () => applyUiPreset(button.dataset.uiPreset)));
    ['uiAccent','uiAccent2','uiPanelOpacity','uiPanelBlur','uiRadius','uiGlow'].forEach((id) => $(`#${id}`)?.addEventListener('input', syncThemeDots));
    $('#saveUiThemeBtn')?.addEventListener('click', async () => {
      try { await api('/api/settings', { method: 'POST', body: JSON.stringify({ sessionId: sid(), appearance: readInterfaceForm() }) }); notify('تم حفظ هوية الواجهة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#resetUiThemeBtn')?.addEventListener('click', async () => {
      const defaults = { accent: '#5ed6c1', accent2: '#8b7cf6', panelOpacity: .94, panelBlur: 0, radius: 13, glow: .28 };
      try { await api('/api/settings', { method: 'POST', body: JSON.stringify({ sessionId: sid(), appearance: defaults }) }); notify('تمت استعادة هوية الواجهة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    const controls = ['bgSpeed', 'bgDensity', 'bgGlow', 'bgIntensity', 'bgMouse', 'bgBrightness', 'bgContrast', 'bgSaturation', 'bgHue', 'bgBlur', 'bgOpacity'];
    controls.forEach((id) => $(`#${id}`)?.addEventListener('input', () => { updateRangeOutput(id); applyBackgroundLive(); }));
    $$('[data-bg-mode]').forEach((button) => button.addEventListener('click', () => { $$('[data-bg-mode]').forEach((item) => item.classList.remove('selected')); button.classList.add('selected'); applyBackgroundLive(); }));
    $('#bgInteractive')?.addEventListener('change', applyBackgroundLive);
    $('#bgTrail')?.addEventListener('change', applyBackgroundLive);
    $('#saveBackgroundBtn')?.addEventListener('click', async () => {
      try { const payload = readBackgroundForm(); await api('/api/settings/background', { method: 'POST', body: JSON.stringify({ sessionId: sid(), ...payload }) }); notify('تم حفظ وتطبيق المظهر.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#resetBackgroundBtn')?.addEventListener('click', async () => {
      try { await api('/api/settings/background', { method: 'POST', body: JSON.stringify({ sessionId: sid(), mode: 'aurora', settings: { speed: 1, density: 1, glow: .6, intensity: 1, mouseStrength: 1, brightness: 1, contrast: 1, saturation: 1, hueRotate: 0, blur: 0, interactive: true, trail: true }, opacity: .22, removeImage: true }) }); notify('تمت استعادة المظهر الافتراضي.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#removeCustomBackgroundBtn')?.addEventListener('click', async () => {
      if (!confirm('إزالة صورة الخلفية المخصصة؟')) return;
      try { await api('/api/settings/background', { method: 'POST', body: JSON.stringify({ sessionId: sid(), mode: state.data?.background?.mode || 'aurora', settings: state.data?.background?.settings || {}, opacity: state.data?.background?.opacity ?? .22, removeImage: true }) }); notify('تمت إزالة الصورة المخصصة.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    });
    $('#customBackground')?.addEventListener('change', async (event) => {
      const file = event.target.files?.[0]; if (!file) return;
      const form = new FormData(); form.append('file', file); form.append('sessionId', sid());
      try { const result = await api('/api/background', { method: 'POST', body: form }); notify(result.message || 'تم تطبيق الخلفية.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
      finally { event.target.value = ''; }
    });
  }

  function updateRangeOutput(id) {
    const input = $(`#${id}`), output = $(`#${id}Out`); if (!input || !output) return;
    const step = Number(input.step || 1);
    output.value = Number(input.value).toFixed(step < 1 ? 2 : 0);
  }

  function readBackgroundForm() {
    return {
      mode: $('.bg-choice.selected')?.dataset.bgMode || state.data?.background?.mode || 'aurora',
      opacity: Number($('#bgOpacity').value),
      settings: {
        speed: Number($('#bgSpeed').value), density: Number($('#bgDensity').value), glow: Number($('#bgGlow').value), intensity: Number($('#bgIntensity').value), mouseStrength: Number($('#bgMouse').value),
        brightness: Number($('#bgBrightness').value), contrast: Number($('#bgContrast').value), saturation: Number($('#bgSaturation').value), hueRotate: Number($('#bgHue').value), blur: Number($('#bgBlur').value),
        interactive: $('#bgInteractive').checked, trail: $('#bgTrail').checked
      }
    };
  }

  function applyBackgroundLive() {
    if (state.bgLivePending) return;
    state.bgLivePending = requestAnimationFrame(() => {
      state.bgLivePending = 0;
      const data = readBackgroundForm();
      if (state.bgEngine) state.bgEngine.set(data);
    });
  }

  function bindSettings() {
    $$('[data-settings-view]').forEach((button) => button.addEventListener('click', () => {
      state.settingsView = button.dataset.settingsView === 'operation' ? 'operation' : 'appearance';
      render();
    }));
  }

  function bindOperation() {
    const save = async (payload) => {
      try { await api('/api/settings', { method: 'POST', body: JSON.stringify({ sessionId: sid(), ...payload }) }); notify('تم حفظ الإعدادات.', 'success'); await load(true); } catch (e) { notify(e.message, 'error'); }
    };
    $('#saveOperationMain')?.addEventListener('click', () => save({ timezone: $('#opTimezone').value.trim(), sendOrder: $('#opSendOrder').value, autoStartSession: $('#opAutoStart').checked, automationEnabled: $('#opAutomation').checked }));
    $('#saveOperationReliability')?.addEventListener('click', () => save({ sendTimeoutMs: Number($('#opTimeout').value || 30000), retryAttempts: Number($('#opRetryAttempts').value || 2), retryDelayMs: Number($('#opRetryDelay').value || 1600), maxImageSizeMB: Number($('#opMaxSize').value || 100) }));
    $('#saveOperationQuiet')?.addEventListener('click', () => save({ interactionQuietEnabled: $('#opQuietEnabled').checked, interactionQuietStart: $('#opQuietStart').value, interactionQuietEnd: $('#opQuietEnd').value, interactionQuietAction: $('#opQuietAction').value, interactionQuietReply: $('#opQuietReply').value, interactionQuietCooldownSec: Number($('#opQuietCooldownSec').value || 0) }));
  }

  function go(page) {
    const next = ['appearance', 'operation'].includes(page) ? 'settings' : page;
    if (page === 'appearance') state.settingsView = 'appearance';
    if (page === 'operation') state.settingsView = 'operation';
    state.page = next || 'dashboard';
    location.hash = state.page;
    render();
    const active = $$(`.navbtn[data-page=\"${String(state.page).replace(/[^a-z-]/g, '')}\"]`)[0];
    try { active?.scrollIntoView({ behavior: 'auto', inline: 'nearest', block: 'nearest' }); } catch {}
    if (state.page === 'people' || state.page === 'send') loadCountries().catch(() => {});
  }

  class BackgroundEngine {
    constructor(canvas) {
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d');
      this.mode = 'aurora';
      this.cfg = { speed: 1, density: 1, glow: .6, intensity: 1, mouseStrength: 1, brightness: 1, contrast: 1, saturation: 1, hueRotate: 0, blur: 0, interactive: true, trail: true };
      this.pointer = { x: .5, y: .5, down: false };
      this.reducedMotion = matchMedia?.('(prefers-reduced-motion: reduce)')?.matches || false;
      if (this.reducedMotion) this.cfg.interactive = false;
      this.t = 0; this.last = 0; this.lastDrawAt = 0; this.frameInterval = 100;
      this.resize = this.resize.bind(this); this.frame = this.frame.bind(this);
      addEventListener('resize', this.resize);
      this.pointerMovePending = false;
      addEventListener('pointermove', (event) => {
        if (this.pointerMovePending || !this.cfg.interactive) return;
        this.pointerMovePending = true;
        requestAnimationFrame(() => { this.pointerMovePending = false; this.pointer.x = event.clientX / innerWidth; this.pointer.y = event.clientY / innerHeight; });
      }, { passive: true });
      addEventListener('pointerdown', () => { this.pointer.down = true; });
      addEventListener('pointerup', () => { this.pointer.down = false; });
      this.resize(); requestAnimationFrame(this.frame);
    }
    resize() { const scale = 1; const w = innerWidth, h = innerHeight; if (w === this.w && h === this.h) return; this.w = w; this.h = h; this.canvas.width = Math.max(1, Math.floor(this.w * scale)); this.canvas.height = Math.max(1, Math.floor(this.h * scale)); this.ctx.setTransform(scale, 0, 0, scale, 0, 0); }
    set(data) {
      if (!data) return;
      this.mode = data.mode || this.mode;
      const scene = $('#bgScene'); if (scene) scene.dataset.mode = this.mode;
      this.cfg = { ...this.cfg, ...(data.settings || {}) };
      const filter = `brightness(${this.cfg.brightness ?? 1}) contrast(${this.cfg.contrast ?? 1}) saturate(${this.cfg.saturation ?? 1}) hue-rotate(${this.cfg.hueRotate ?? 0}deg) blur(${this.cfg.blur ?? 0}px)`;
      this.canvas.style.filter = filter;
      const image = $('#bgImageLayer');
      if (image) {
        image.style.opacity = String(data.opacity ?? .22);
        image.style.filter = filter;
        if (Object.prototype.hasOwnProperty.call(data, 'imageUrl')) image.style.backgroundImage = data.imageUrl ? `url("${String(data.imageUrl).replace(/"/g, '%22')}")` : '';
      }
    }
    frame(ms) { if (document.hidden) { requestAnimationFrame(this.frame); return; } if (ms - this.lastDrawAt >= this.frameInterval) { const dt = Math.min(50, ms - (this.last || ms)); this.last = ms; this.lastDrawAt = ms; this.t += dt * .001 * Number(this.cfg.speed || 1); this.draw(); } requestAnimationFrame(this.frame); }
    clear() { this.ctx.fillStyle = `rgba(4,8,18,${this.cfg.trail ? .13 : .25})`; this.ctx.fillRect(0, 0, this.w, this.h); }
    draw() {
      const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, px = .5 + (this.pointer.x - .5) * Number(c.mouseStrength ?? 1), py = .5 + (this.pointer.y - .5) * Number(c.mouseStrength ?? 1);
      x.save(); this.clear(); x.globalCompositeOperation = 'source-over';
      if (this.mode === 'aurora') this.aurora(px, py); else if (this.mode === 'nebula') this.nebula(px, py); else if (this.mode === 'meteor') this.meteor(px, py); else if (this.mode === 'matrix') this.matrix(px, py); else if (this.mode === 'cyber-grid') this.grid(px, py); else if (this.mode === 'plasma') this.plasma(px, py); else if (this.mode === 'starfield') this.stars(px, py); else if (this.mode === 'vortex') this.vortex(px, py); else if (this.mode === 'galaxy') this.galaxy(px, py); else this.ocean(px, py);
      if (c.interactive) { x.beginPath(); x.arc(px * w, py * h, 18 + Math.sin(t * 4) * 5, 0, Math.PI * 2); x.strokeStyle = `rgba(170,235,255,${.08 * c.intensity})`; x.lineWidth = 1.2 + c.glow * 1.4; x.stroke(); if (this.pointer.down) { x.beginPath(); x.arc(px * w, py * h, 42 + Math.sin(t * 9) * 8, 0, Math.PI * 2); x.strokeStyle = `rgba(210,160,255,${.16 * c.intensity})`; x.stroke(); } } x.restore();
    }
    aurora(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, shift = (px - .5) * 80; for (let k = 0; k < Math.max(2, Math.round(2 + c.density * 2)); k++) { x.beginPath(); for (let i = 0; i <= w; i += 12) x.lineTo(i, h * (.22 + k * .16) + (py - .5) * 45 + Math.sin(i * .008 + t * (.7 + k * .2) + shift * .003) * 35 + Math.sin(i * .002 - t * .35) * 24); x.strokeStyle = `hsla(${165 + k * 45},90%,65%,${.055 * c.intensity})`; x.lineWidth = 55; x.shadowBlur = 24 * c.glow; x.stroke(); } }
    nebula(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(34 * c.density); for (let i = 0; i < n; i++) { const a = (i * 12.9898) % 6.283, r = ((i * 37.13) % 1) * Math.min(w, h) * .48, q = t * (.2 + (i % 7) / 35), cx = w * (.5 + (px - .5) * .08), cy = h * (.5 + (py - .5) * .08), vx = cx + Math.cos(a + q) * r, vy = cy + Math.sin(a + q * .8) * r * .65, z = 2 + ((i * 17) % 8); x.fillStyle = `hsla(${205 + (i % 4) * 32},90%,70%,${.12 * c.intensity})`; x.beginPath(); x.arc(vx, vy, z, 0, Math.PI * 2); x.fill(); } }
    meteor(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(18 * c.density), bias = (px - .5) * 80; for (let i = 0; i < n; i++) { const speed = 70 + (i % 9) * 18, vx = (i * 97 + t * speed * 1.8 + bias) % (w + 300) - 150, vy = (i * 43 + t * speed * .7 + (py - .5) * 50) % (h + 120) - 60; x.beginPath(); x.moveTo(vx, vy); x.lineTo(vx - speed * .28, vy - speed * .11); x.strokeStyle = `hsla(${185 + (i % 5) * 25},95%,70%,${.18 * c.intensity})`; x.lineWidth = 1 + (i % 3); x.stroke(); } }
    matrix(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, cols = Math.floor(58 * c.density), step = Math.max(13, w / Math.max(cols, 1)); x.font = '15px monospace'; for (let i = 0; i < cols; i++) { const y = (i * 79 + t * (55 + (i % 7) * 6) + (py - .5) * 100) % (h + 220) - 220; x.fillStyle = `rgba(110,231,249,${.2 * c.intensity})`; x.fillText(String.fromCharCode(0x30a0 + (i * 13) % 90), i * step, y); } }
    grid(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, step = Math.max(38, 112 - c.density * 45), oy = (t * 35 + (py - .5) * 50) % step, ox = (t * 18 + (px - .5) * 50) % step; x.strokeStyle = `rgba(110,231,249,${.09 * c.intensity})`; for (let y = -step + oy; y < h + step; y += step) { x.beginPath(); x.moveTo(0, y); x.lineTo(w, y); x.stroke(); } for (let xx = -step + ox; xx < w + step; xx += step) { x.beginPath(); x.moveTo(xx, 0); x.lineTo(xx, h); x.stroke(); } }
    plasma(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg; for (let k = 0; k < Math.max(3, Math.round(4 + c.density * 4)); k++) { x.beginPath(); for (let i = 0; i <= w; i += 10) x.lineTo(i, h * (.15 + k * .12) + (py - .5) * 35 + Math.sin(i * .012 + t * (1 + k * .07) + (px - .5)) * 26 + Math.sin(i * .004 - t * .6) * 22); x.strokeStyle = `hsla(${190 + k * 24},85%,62%,${.07 * c.intensity})`; x.lineWidth = 18; x.stroke(); } }
    stars(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(56 * c.density); for (let i = 0; i < n; i++) { const z = ((i * 31 + t * 14) % 100) / 100, r = .3 + z * 2.5, vx = (i * 97.31 + (px - .5) * 40) % w, vy = (i * 47.21 + (py - .5) * 40) % h; x.fillStyle = `rgba(220,240,255,${.15 + z * .6})`; x.beginPath(); x.arc(vx, vy, r, 0, Math.PI * 2); x.fill(); } }
    vortex(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(52 * c.density), cx = w * (.5 + (px - .5) * .18), cy = h * (.5 + (py - .5) * .12); for (let i = 0; i < n; i++) { const p = i / n, a = p * Math.PI * 10 + t * (.3 + p), r = p * Math.min(w, h) * .42, vx = cx + Math.cos(a) * r, vy = cy + Math.sin(a) * r * .62; x.fillStyle = `hsla(${190 + p * 130},95%,68%,${.11 * c.intensity})`; x.beginPath(); x.arc(vx, vy, 1 + p * 2.5, 0, Math.PI * 2); x.fill(); } }
    galaxy(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg, n = Math.floor(72 * c.density), cx = w * (.5 + (px - .5) * .14), cy = h * (.5 + (py - .5) * .1); for (let i = 0; i < n; i++) { const p = i / n, a = i * .55 + t * (.45 + p), r = p * Math.min(w, h) * .46 + Math.sin(i * 2.7) * 4, vx = cx + Math.cos(a) * r, vy = cy + Math.sin(a) * r * .42; x.fillStyle = `hsla(${190 + (i % 6) * 22},90%,72%,${.08 + c.intensity * .08})`; x.beginPath(); x.arc(vx, vy, .5 + p * 2.2, 0, Math.PI * 2); x.fill(); } }
    ocean(px, py) { const x = this.ctx, w = this.w, h = this.h, t = this.t, c = this.cfg; for (let k = 0; k < 3; k++) { x.beginPath(); for (let i = 0; i <= w; i += 10) x.lineTo(i, h * (.52 + k * .07) + (py - .5) * 40 + Math.sin(i * .009 + t * (.65 + k * .05) + px * 2) * 18 + Math.sin(i * .003 - t * .45) * 10); x.strokeStyle = `hsla(${180 + k * 8},85%,65%,${.055 * c.intensity})`; x.lineWidth = 10 + c.glow * 10; x.stroke(); } }
  }

  function applyInterfaceTheme(data = state.data) {
    const a = data?.settings?.appearance || {};
    const root = document.documentElement;
    root.dataset.theme = state.uiMode || 'dark';
    root.style.setProperty('--accent', a.accent || '#5ed6c1');
    root.style.setProperty('--accent-2', a.accent2 || '#8b7cf6');
    root.style.setProperty('--panel-opacity', String(a.panelOpacity ?? .88));
    root.style.setProperty('--panel-blur', `${Number(a.panelBlur ?? 14)}px`);
    root.style.setProperty('--radius', `${Number(a.radius ?? 18)}px`);
    root.style.setProperty('--ui-glow', String(Number(a.glow ?? .55)));
  }

  function readInterfaceForm() {
    return {
      accent: $('#uiAccent')?.value || '#5ed6c1',
      accent2: $('#uiAccent2')?.value || '#8b7cf6',
      panelOpacity: Number($('#uiPanelOpacity')?.value || .88),
      panelBlur: Number($('#uiPanelBlur')?.value || 14),
      radius: Number($('#uiRadius')?.value || 18),
      glow: Number($('#uiGlow')?.value || .55),
    };
  }

  function applyInterfaceLive() { applyInterfaceTheme({ settings: { appearance: readInterfaceForm() } }); }

  function setupBackground() {
    const canvas = $('#bgCanvas'); if (!canvas) return;
    if (!state.bgEngine) state.bgEngine = new BackgroundEngine(canvas);
    if (state.data?.background) state.bgEngine.set(state.data.background);
  }

  async function boot() {
    try {
      await loadCountries().catch(() => null);
      await load();
      addEventListener('hashchange', () => { state.page = location.hash.slice(1) || 'dashboard'; render(); });
    } catch (error) {
      document.body.innerHTML = `<div class="fatal"><h1>تعذر تشغيل الواجهة</h1><p>${esc(error.message)}</p><button class="btn primary" onclick="location.reload()">إعادة المحاولة</button></div>`;
    }
  }

  boot();
})();
