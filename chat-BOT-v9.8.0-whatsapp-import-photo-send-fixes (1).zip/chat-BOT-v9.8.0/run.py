from __future__ import annotations
import os
import shutil
import subprocess
import sys
import re
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BROWSER_CACHE = ROOT / '.cache' / 'puppeteer'
BROWSER_MARKER = ROOT / '.browser-path'

def run(cmd, env=None):
    try:
        return subprocess.call(cmd, cwd=ROOT, env=env)
    except FileNotFoundError:
        return 127

def capture(cmd, env=None):
    try:
        return subprocess.run(cmd, cwd=ROOT, env=env, text=True, capture_output=True).stdout.strip()
    except Exception:
        return ''

def node_ok(node):
    raw = capture([node, '--version'])
    m = re.match(r'v(\d+)\.', raw)
    return bool(m) and int(m.group(1)) >= 20

def load_browser_marker():
    try:
        value = BROWSER_MARKER.read_text(encoding='utf-8').strip()
        return value if value and Path(value).is_file() else ''
    except Exception:
        return ''

def main():
    os.environ.setdefault('PORT', '7005')
    os.environ.setdefault('PUPPETEER_CACHE_DIR', str(BROWSER_CACHE))
    BROWSER_CACHE.mkdir(parents=True, exist_ok=True)

    npm = shutil.which('npm.cmd') or shutil.which('npm')
    node = shutil.which('node')
    if not npm or not node:
        print('لم يتم العثور على Node.js/npm. ثبّت Node.js 20 أو أحدث ثم شغّل run.py مرة أخرى.')
        raise SystemExit(127)
    print(f'Node: {capture([node, "--version"])}')
    if not node_ok(node):
        print('إصدار Node.js غير مدعوم. استخدم Node.js 20 أو أحدث.')
        raise SystemExit(2)

    required_wweb = '1.34.7'
    required_puppeteer = '24.38.0'
    pkg_file = ROOT / 'node_modules' / 'whatsapp-web.js' / 'package.json'
    puppeteer_file = ROOT / 'node_modules' / 'puppeteer' / 'package.json'
    installed_wweb = None
    installed_puppeteer = None
    if pkg_file.exists():
        try:
            installed_wweb = json.loads(pkg_file.read_text(encoding='utf-8')).get('version')
        except Exception:
            pass
    if puppeteer_file.exists():
        try:
            installed_puppeteer = json.loads(puppeteer_file.read_text(encoding='utf-8')).get('version')
        except Exception:
            pass

    needs_install = (
        installed_wweb != required_wweb or
        installed_puppeteer != required_puppeteer or
        not (ROOT / 'node_modules').exists()
    )
    if needs_install:
        detail = []
        if installed_wweb and installed_wweb != required_wweb: detail.append(f'WhatsApp {installed_wweb}→{required_wweb}')
        if installed_puppeteer and installed_puppeteer != required_puppeteer: detail.append(f'Puppeteer {installed_puppeteer}→{required_puppeteer}')
        print('جارٍ تجهيز الاعتمادات' + (f' ({"، ".join(detail)})' if detail else '') + '…')
        # Do not disable dependency install scripts here. Puppeteer may need them,
        # while the project postinstall only performs a safe WhatsApp compatibility cleanup.
        code = run([npm, 'install', '--no-audit', '--no-fund'], env=os.environ.copy())
        if code != 0:
            print('فشل تثبيت الاعتمادات. لم يبدأ البوت.')
            raise SystemExit(code)

    try:
        installed_wweb = json.loads(pkg_file.read_text(encoding='utf-8')).get('version')
    except Exception:
        installed_wweb = None
    try:
        installed_puppeteer = json.loads(puppeteer_file.read_text(encoding='utf-8')).get('version')
    except Exception:
        installed_puppeteer = None
    if installed_wweb != required_wweb:
        print(f'تعذر تثبيت whatsapp-web.js {required_wweb}؛ النسخة الموجودة: {installed_wweb or "غير معروفة"}.')
        raise SystemExit(3)
    if installed_puppeteer != required_puppeteer:
        print(f'تعذر تثبيت Puppeteer {required_puppeteer}؛ النسخة الموجودة: {installed_puppeteer or "غير معروفة"}.')
        raise SystemExit(4)

    print('جارٍ تجهيز متصفح WhatsApp…')
    browser = load_browser_marker()
    if not browser:
        code = run([node, str(ROOT / 'scripts' / 'ensure-browser.js')], env=os.environ.copy())
        if code != 0:
            print('تعذر تجهيز Chrome/Chromium. لم يبدأ البوت.')
            raise SystemExit(code)
        browser = load_browser_marker()
    if browser:
        os.environ['CHROME_PATH'] = browser
        os.environ['PUPPETEER_EXECUTABLE_PATH'] = browser
        print(f'Browser: {browser}')

    print('جارٍ فحص توافق whatsapp-web.js…')
    repair = run([npm, 'run', 'repair-whatsapp'], env=os.environ.copy())
    if repair != 0:
        print('تعذر فحص توافق whatsapp-web.js. لم يبدأ البوت حتى لا يعمل بحالة غير سليمة.')
        raise SystemExit(repair)
    verify = run([npm, 'run', 'verify'], env=os.environ.copy())
    if verify != 0:
        print('فشل فحص سلامة المشروع. لم يبدأ البوت.')
        raise SystemExit(verify)
    raise SystemExit(run([npm, 'start'], env=os.environ.copy()))

if __name__ == '__main__':
    main()
