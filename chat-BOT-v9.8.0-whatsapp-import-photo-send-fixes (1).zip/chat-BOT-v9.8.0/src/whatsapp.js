"use strict";
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
function patchUtilsForWhatsApp(){
  const out = { ok:true, changed:false, notes:[] };
  try {
    const pkgRoot = path.dirname(require.resolve('whatsapp-web.js/package.json'));
    const utils = path.join(pkgRoot,'src','util','Injected','Utils.js');
    if (!fs.existsSync(utils)) return out;
    const before = fs.readFileSync(utils,'utf8');
    let text = before.replace(/(^|\r?\n)\s*(?:if\s*\(message\s*&&\s*message\.__x_id\)\s*delete\s+message\.__x_id\s*;?|message\.__x_id\s*=.*?;)(?=\r?\n|$)/g,'\n');
    text = text.replace(/(^|\r?\n)\s*\/\*\s*CHAT_BOT_[^*]*COMPAT[^*]*\*\/\s*/g,'\n');
    for (const [a,b] of [
      ['window.Store.Msg.get(newMsgKey._serialized)','window.Store.Msg.get(newMsgKey._serialized || newMsgKey.$1)'],
      ['window.Store.Msg.get(msg.id._serialized)','window.Store.Msg.get(msg.id._serialized || msg.id.$1)'],
      ['window.Store.Msg.get(chat.lastReceivedKey._serialized)','window.Store.Msg.get(chat.lastReceivedKey._serialized || chat.lastReceivedKey.$1)'],
      ['window.Store.WidFactory.createWid(chat.id._serialized)','window.Store.WidFactory.createWid(chat.id._serialized || chat.id.$1)'],
    ]) text = text.replaceAll(a,b);
    try { new vm.Script(text,{filename:utils}); } catch(e) { throw new Error('إصلاح Utils.js أنتج صياغة غير صالحة: '+e.message); }
    if (text!==before) { const tmp=utils+'.chatbot.tmp'; fs.writeFileSync(tmp,text,'utf8'); fs.renameSync(tmp,utils); out.changed=true; out.notes.push('تم تنظيف patch قديم وإصلاح توافق IDs بأمان.'); }
    return out;
  } catch(e) { out.ok=false; out.notes.push(e.message||String(e)); return out; }
}
const patchResult = patchUtilsForWhatsApp();
if (!patchResult.ok) throw new Error(patchResult.notes.join(' | '));
const browserMarker = path.join(path.resolve(__dirname, '..'), '.browser-path');
function detectSystemBrowser() {
  const candidates = [];
  if (process.env.PUPPETEER_EXECUTABLE_PATH) candidates.push(process.env.PUPPETEER_EXECUTABLE_PATH);
  if (process.env.CHROME_PATH) candidates.push(process.env.CHROME_PATH);
  if (process.platform === 'win32') {
    const roots = [process.env.LOCALAPPDATA, process.env.PROGRAMFILES, process.env['PROGRAMFILES(X86)']].filter(Boolean);
    for (const root of roots) {
      candidates.push(path.join(root, 'Google', 'Chrome', 'Application', 'chrome.exe'));
      candidates.push(path.join(root, 'Microsoft', 'Edge', 'Application', 'msedge.exe'));
      candidates.push(path.join(root, 'Chromium', 'Application', 'chrome.exe'));
    }
  } else if (process.platform === 'linux') {
    candidates.push('/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser');
  } else if (process.platform === 'darwin') {
    candidates.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', '/Applications/Chromium.app/Contents/MacOS/Chromium');
  }
  for (const candidate of candidates) {
    try { if (candidate && fs.existsSync(candidate)) return candidate; } catch {}
  }
  return '';
}
let detectedChrome = '';
try { const marked = fs.readFileSync(browserMarker, 'utf8').trim(); if (marked && fs.existsSync(marked)) detectedChrome = marked; } catch {}
if (!detectedChrome) detectedChrome = detectSystemBrowser();
if (detectedChrome && !fs.existsSync(browserMarker)) { try { fs.writeFileSync(browserMarker, detectedChrome, 'utf8'); } catch {} }
process.env.PUPPETEER_CACHE_DIR = process.env.PUPPETEER_CACHE_DIR || path.join(path.resolve(__dirname, '..'), '.cache', 'puppeteer');
const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const EventEmitter = require('node:events');

function safeError(e) { return String(e?.message || e || 'خطأ غير معروف'); }
const { toUserFacingError } = require('./whatsapp-errors');
function withTimeout(promise, ms, label) {
  let timer;
  const timeout = new Promise((_, reject) => { timer = setTimeout(() => reject(Object.assign(new Error(`${label || 'العملية'} تجاوزت المهلة.`), { code: 'SEND_TIMEOUT' })), Math.max(1000, Number(ms) || 30000)); });
  return Promise.race([Promise.resolve(promise), timeout]).finally(() => clearTimeout(timer));
}
function idSerialized(id) {
  if (!id) return '';
  if (typeof id === 'string') return id;
  if (id._serialized) return String(id._serialized);
  if (id.$1) return String(id.$1);
  if (id.remote) return idSerialized(id.remote);
  return id.id !== undefined ? String(id.id) : '';
}
function chatIdFromMessage(msg) {
  // id.remote is the chat address for both incoming and outgoing messages.
  // For outgoing messages, `from` may be our own account, not the destination.
  const candidates = [msg?.id?.remote, msg?._data?.id?.remote, msg?.msgId?.remote, msg?._data?.chatId, msg?.chatId, msg?.fromMe ? msg?.to : msg?.from, msg?.from, msg?.to, msg?.id?._serialized, msg?.id?.$1];
  for (const value of candidates) { const id = idSerialized(value).trim().toLowerCase(); if (id.endsWith('@g.us') || id.endsWith('@c.us') || id.endsWith('@lid')) return id; }
  return '';
}
function groupFromMessage(msg) { const id = chatIdFromMessage(msg); return id.endsWith('@g.us') ? id : null; }
function ackIsDelivered(ack) { return Number(ack) >= 2; }

class WhatsAppManager extends EventEmitter {
  constructor({ store, log }) { super(); this.store = store; this.log = log; this.clients = new Map(); this.pending = new Map(); this.outgoingIntents = new Map(); this.programmaticMessages = new Map(); }
  entry(id) {
    const sid = this.store.safeSessionId(id);
    if (!this.clients.has(sid)) this.clients.set(sid, { client: null, status: 'idle', ready: false, qr: null, browser: '', info: null, lastAck: null, lastSent: null, starting: null, liveGroups: new Map(), stopping: false, reconnectTimer: null, reconnects: 0, generation: 0, readyProbe: null, connectedAt: null });
    return this.clients.get(sid);
  }
  selfChatId(id) {
    const e = this.entry(id), wid = e.info?.wid || e.client?.info?.wid || e.info?.me || e.client?.info?.me;
    let value = idSerialized(wid).toLowerCase();
    if (!value && wid?.user) value = `${String(wid.user)}@c.us`.toLowerCase();
    return value;
  }
  async isSelfChatMessage(id, msg) {
    if (!msg?.fromMe) return false;
    const self = this.selfChatId(id);
    if (!self) return false;
    let actual = '';
    try { if (typeof msg.getChat === 'function') actual = idSerialized((await msg.getChat())?.id).toLowerCase(); } catch {}
    if (!actual) actual = idSerialized(msg?.id?.remote || msg?.to || msg?._data?.id?.remote || msg?._data?.to).toLowerCase();
    if (!actual) return false;
    if (actual === self) return true;
    const digits = value => value.replace(/@(?:c\.us|lid)$/i, '').replace(/[^0-9]/g, '');
    return actual.endsWith('@c.us') && self.endsWith('@c.us') && digits(actual) && digits(actual) === digits(self);
  }
  outboundIntentKey(sid, chatId) { return `${this.store.safeSessionId(sid)}|${String(chatId || '').toLowerCase()}`; }
  trackOutgoingIntent(sid, chatId, text, label = '') {
    const key = this.outboundIntentKey(sid, chatId), item = { token: `${Date.now()}-${Math.random().toString(36).slice(2)}`, at: Date.now(), text: String(text || '').trim(), expectsMedia: /وسائط|ملف|صورة|مرفق/i.test(String(label || '')) };
    const list = this.outgoingIntents.get(key) || []; list.push(item); this.outgoingIntents.set(key, list.slice(-30)); return { key, token:item.token };
  }
  removeOutgoingIntent(ref) {
    if (!ref?.key) return;
    const list = this.outgoingIntents.get(ref.key) || [], next = list.filter(item => item.token !== ref.token);
    if (next.length) this.outgoingIntents.set(ref.key, next); else this.outgoingIntents.delete(ref.key);
  }
  rememberProgrammaticMessage(sid, msgOrId) {
    const id = idSerialized(msgOrId?.id || msgOrId?.messageId || msgOrId);
    if (!id) return;
    const now = Date.now(); this.programmaticMessages.set(`${this.store.safeSessionId(sid)}|${id}`, now + 120000);
    if (this.programmaticMessages.size > 5000) for (const [key, expires] of this.programmaticMessages) if (expires < now) this.programmaticMessages.delete(key);
  }
  consumeProgrammaticOutgoing(sid, msg) {
    const session = this.store.safeSessionId(sid), msgId = idSerialized(msg?.id || msg?._data?.id);
    if (msgId) {
      const expires = this.programmaticMessages.get(`${session}|${msgId}`);
      if (expires && expires >= Date.now()) { this.programmaticMessages.delete(`${session}|${msgId}`); return true; }
    }
    const chatId = chatIdFromMessage(msg).toLowerCase();
    if (!chatId) return false;
    const key = this.outboundIntentKey(session, chatId), now = Date.now(), list = this.outgoingIntents.get(key) || [];
    const fresh = list.filter(item => now - item.at < 8000);
    const body = String(msg?.body || msg?.caption || '').trim();
    const isMedia = Boolean(msg?.hasMedia || msg?._data?.mimetype || ['image','video','audio','document','sticker'].includes(String(msg?.type || '').toLowerCase()));
    const index = fresh.findIndex(item => item.text ? (body === item.text || body.includes(item.text.slice(0, Math.min(24, item.text.length)))) : item.expectsMedia && isMedia);
    if (index < 0) { if (fresh.length) this.outgoingIntents.set(key, fresh); else this.outgoingIntents.delete(key); return false; }
    fresh.splice(index, 1); if (fresh.length) this.outgoingIntents.set(key, fresh); else this.outgoingIntents.delete(key);
    return true;
  }
  isProgrammaticOutgoing(sid, msg) {
    if (msg?.__chatBotProgrammatic === true || msg?._chatBotProgrammatic === true) return true;
    return this.consumeProgrammaticOutgoing(sid, msg);
  }
  hasSavedAuth(id) {
    const dir = this.store.getPaths(id).auth;
    try { return fs.existsSync(dir) && fs.readdirSync(dir, { withFileTypes: true }).some(x => x.isDirectory() || x.isFile()); } catch { return false; }
  }
  emitStatus(id) { this.emit('status', id, this.listRuntime(id)); }
  clearReadyProbe(e) { if (e.readyProbe) { clearInterval(e.readyProbe); e.readyProbe = null; } }
  startReadyProbe(sid, client, generation) {
    const e = this.entry(sid); this.clearReadyProbe(e); let attempts = 0;
    e.readyProbe = setInterval(async () => {
      if (generation !== e.generation || e.stopping || e.ready) return this.clearReadyProbe(e);
      if (++attempts > 120) return this.clearReadyProbe(e);
      try { const state = typeof client.getState === 'function' ? await client.getState() : null; if (state === 'CONNECTED') this.markReady(sid, client, generation, 'state'); } catch {}
    }, 1000);
  }
  markReady(sid, client, generation, source = 'ready') {
    const e = this.entry(sid); if (generation !== e.generation || e.stopping) return;
    e.ready = true; e.status = 'ready'; e.qr = null; e.browser = 'Chromium/Puppeteer'; e.info = client.info || e.info; e.reconnects = 0; e.connectedAt ||= new Date().toISOString(); this.clearReadyProbe(e);
    this.log(sid, 'INFO', `جلسة WhatsApp جاهزة للإرسال والاستقبال (${source}).`); this.emitStatus(sid);
  }
  async start(id) {
    const sid = this.store.safeSessionId(id), e = this.entry(sid); e.stopping = false;
    if (e.ready && e.client) return this.listRuntime(sid);
    if (e.starting) return e.starting;
    if (e.client) { try { await e.client.destroy(); } catch {} e.client = null; }
    const generation = ++e.generation; e.status = 'starting'; e.qr = null; e.ready = false; e.connectedAt = null;
    e.starting = (async () => {
      const p = this.store.getPaths(sid); this.store.ensureDir?.(sid); fs.mkdirSync(p.auth, { recursive: true });
      const client = new Client({
        authStrategy: new LocalAuth({ clientId: sid, dataPath: p.auth }),
        puppeteer: { headless: String(process.env.HEADLESS || 'true') !== 'false', executablePath: detectedChrome || undefined, args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-background-networking', '--disable-background-timer-throttling', '--disable-renderer-backgrounding'], timeout: 60000 },
        authTimeoutMs: 60000, takeoverOnConflict: false,
      });
      e.client = client;
      client.on('qr', async qr => { if (generation !== e.generation) return; e.qr = qr; e.status = 'qr'; try { e.qr = await require('qrcode').toDataURL(qr, { margin: 1, width: 260 }); } catch {} this.emitStatus(sid); });
      client.on('authenticated', () => { if (generation !== e.generation) return; e.status = 'authenticated'; e.qr = null; this.startReadyProbe(sid, client, generation); this.emitStatus(sid); });
      client.on('ready', () => this.markReady(sid, client, generation, 'event'));
      client.on('change_state', state => { if (generation !== e.generation) return; if (state === 'CONNECTED' && !e.ready) this.startReadyProbe(sid, client, generation); });
      client.on('auth_failure', msg => { if (generation !== e.generation) return; e.ready = false; e.status = 'auth_failure'; this.clearReadyProbe(e); this.log(sid, 'ERROR', `فشل توثيق WhatsApp: ${safeError(msg)}`); this.emitStatus(sid); });
      client.on('disconnected', reason => {
        if (generation !== e.generation) return; e.ready = false; e.status = 'disconnected'; e.client = null; this.clearReadyProbe(e); this.log(sid, 'WARN', `انفصلت جلسة WhatsApp: ${safeError(reason)}`); this.emitStatus(sid);
        if (!e.stopping && this.hasSavedAuth(sid) && e.reconnects < 4) { const wait = [2500, 5000, 10000, 20000][Math.min(e.reconnects, 3)]; e.reconnects++; clearTimeout(e.reconnectTimer); e.reconnectTimer = setTimeout(() => { if (generation !== e.generation || e.stopping) return; this.start(sid).catch(err => this.log(sid, 'ERROR', `فشل إعادة الاتصال: ${safeError(err)}`)); }, wait); }
      });
      client.on('message', async msg => {
        const gid = groupFromMessage(msg); if (gid) { const rt = this.entry(sid); let info = { gid, name: gid }; try { const chat = typeof msg.getChat === 'function' ? await msg.getChat() : null; if (chat) info = await this.groupInfoFromChat(chat); } catch {} rt.liveGroups.set(gid, info); }
        this.emit('message', sid, msg);
      });
      client.on('message_ack', (msg, ack) => { e.lastAck = { at: new Date().toISOString(), id: idSerialized(msg?.id || msg), chatId: chatIdFromMessage(msg), ack, level: Number(ack) >= 4 ? 'read' : Number(ack) >= 3 ? 'delivered' : Number(ack) >= 2 ? 'server' : Number(ack) === 1 ? 'pending' : 'error' }; this.resolvePending('ack', sid, e.lastAck); this.emit('ack', sid, e.lastAck); });
      client.on('message_create', msg => { if (msg?.fromMe) { if (this.consumeProgrammaticOutgoing(sid, msg)) msg.__chatBotProgrammatic = true; this.resolvePending('message', sid, msg); this.emit('message_create', sid, msg); } });
      client.on('message_reaction', reaction => { this.emit('reaction', sid, { ...reaction, chatId: idSerialized(reaction?.chatId || reaction?.msgId?.remote || reaction?.id?.remote || reaction?.messageId?.remote || ''), emoji: String(reaction?.reaction || reaction?.emoji || reaction?.value || ''), msgId: reaction?.msgId || reaction?.messageId || reaction?.id || reaction?.message?.id || null, fromMe: !!reaction?.fromMe }); });
      await withTimeout(client.initialize(), 180000, 'تهيئة WhatsApp');
      return this.listRuntime(sid);
    })().catch(async err => { if (generation === e.generation && e.client) { try { await e.client.destroy(); } catch {} e.client = null; } e.status = 'error'; e.ready = false; this.clearReadyProbe(e); this.log(sid, 'ERROR', `فشل تشغيل الجلسة: ${safeError(err)}`); throw err; }).finally(() => { e.starting = null; });
    return e.starting;
  }
  async ensureReady(id) { const sid = this.store.safeSessionId(id), e = this.entry(sid); if (e.ready && e.client) return e.client; await this.start(sid); const after = this.entry(sid); if (!after.ready || !after.client) throw new Error(`جلسة WhatsApp ليست جاهزة. الحالة الحالية: ${after.status}`); return after.client; }
  async stop(id, { clearAuth = false } = {}) { const sid = this.store.safeSessionId(id), e = this.entry(sid); e.stopping = true; ++e.generation; clearTimeout(e.reconnectTimer); this.clearReadyProbe(e); if (e.client) { try { await withTimeout(e.client.destroy(), 10000, 'إيقاف الجلسة'); } catch {} } e.client = null; e.ready = false; e.qr = null; e.status = 'stopped'; if (clearAuth) { try { fs.rmSync(this.store.getPaths(sid).auth, { recursive: true, force: true }); } catch {} } e.stopping = false; e.reconnects = 0; this.emitStatus(sid); }
  async stopAll(opts = {}) { for (const sid of this.clients.keys()) await this.stop(sid, opts); }
  listRuntime(id) { const e = this.entry(id); return { status: e.status, ready: e.ready, qr: e.qr, browser: e.browser, info: e.info, lastAck: e.lastAck, lastSent: e.lastSent, reconnects: e.reconnects || 0, connectedAt: e.connectedAt, liveGroups: [...e.liveGroups.values()] }; }
  waitForEvent(kind, sid, matcher, timeoutMs) {
    const key = `${sid}|${kind}`, list = this.pending.get(key) || [], match = typeof matcher === 'function' ? matcher : value => { const want = String(matcher || '').toLowerCase(); return !want || String(kind === 'ack' ? value?.chatId : chatIdFromMessage(value)).toLowerCase() === want; };
    this.pending.set(key, list); let done = false, timer, item;
    const promise = new Promise(resolve => { const finish = value => { if (done) return; done = true; clearTimeout(timer); const index = list.indexOf(item); if (index >= 0) list.splice(index, 1); if (!list.length) this.pending.delete(key); resolve(value); }; item = { match, resolve: finish }; timer = setTimeout(() => finish(null), Math.max(500, Number(timeoutMs) || 5000)); list.push(item); });
    promise.cancel = () => item?.resolve(null); return promise;
  }
  resolvePending(kind, sid, value) { const list = this.pending.get(`${sid}|${kind}`) || []; const item = list.find(x => { try { return x.match(value); } catch { return false; } }); if (item) item.resolve(value); }
  async sendConfirmed(sid, chatId, operation, timeoutMs, label, expectedText = '') {
    const normalizedChat = String(chatId || '').toLowerCase(), started = Date.now();
    const outboundIntent = this.trackOutgoingIntent(sid, normalizedChat, expectedText, label);
    const ackWait = this.waitForEvent('ack', sid, value => String(value?.chatId || '').toLowerCase() === normalizedChat && ackIsDelivered(value?.ack), 5000);
    const expectsMedia = /وسائط|ملف|صورة|مرفق/i.test(String(label || ''));
    const createdWait = this.waitForEvent('message', sid, msg => {
      if (String(chatIdFromMessage(msg)).toLowerCase() !== normalizedChat) return false;
      if (expectedText) { const body = String(msg?.body || '').trim(); return body === expectedText || body.includes(expectedText.slice(0, Math.min(30, expectedText.length))); }
      return expectsMedia && Boolean(msg?.hasMedia || msg?._data?.mimetype || ['image','video','audio','document','sticker'].includes(String(msg?.type || '').toLowerCase()));
    }, 5000);
    try {
      const result = await withTimeout(operation(), timeoutMs, label);
      if (!result) {
        const event = await Promise.race([ackWait, createdWait]);
        this.removeOutgoingIntent(outboundIntent);
        if (event) { const confirmed = event?.ack !== undefined && ackIsDelivered(event.ack); this.rememberProgrammaticMessage(sid, event); return { result: event, __chatBotAck: { status: confirmed ? 'confirmed' : 'created', mode: confirmed ? 'ack' : 'message_create', waitedMs: Date.now() - started } }; }
        throw Object.assign(new Error(`تم طلب ${label || 'الإرسال'} لكن لم يظهر تأكيد.`), { code: 'SEND_UNCERTAIN' });
      }
      const id = idSerialized(result?.id || result?.messageId || result);
      // Use the returned message ID for late message_create events; remove the text/media intent
      // immediately so the user's next manual self-chat message is not mistaken for bot output.
      this.removeOutgoingIntent(outboundIntent);
      if (id) this.rememberProgrammaticMessage(sid, result);
      const earlyAck = await Promise.race([ackWait, createdWait, new Promise(resolve => setTimeout(() => resolve(null), 700))]);
      if (earlyAck?.ack !== undefined && ackIsDelivered(earlyAck.ack)) { ackWait.cancel(); createdWait.cancel(); return { result, __chatBotAck: { status: 'confirmed', mode: 'ack', id, waitedMs: Date.now() - started } }; }
      if (earlyAck?.body !== undefined || idSerialized(earlyAck?.id)) { ackWait.cancel(); createdWait.cancel(); return { result, __chatBotAck: { status: 'created', mode: 'message_create', id, waitedMs: Date.now() - started } }; }
      // The library returned a Message object, which means the operation created a send.
      // Mark it as created, not falsely as delivered, and never retry it automatically.
      ackWait.cancel(); createdWait.cancel();
      return { result, __chatBotAck: { status: 'created', mode: 'return', id, waitedMs: Date.now() - started } };
    } catch (e) {
      if (e.code === 'SEND_TIMEOUT') { const event = await Promise.race([ackWait, createdWait]); this.removeOutgoingIntent(outboundIntent); if (event) { const confirmed = event?.ack !== undefined && ackIsDelivered(event.ack); this.rememberProgrammaticMessage(sid, event); return { result: event, __chatBotAck: { status: confirmed ? 'confirmed' : 'created', mode: confirmed ? 'ack' : 'message_create', waitedMs: Date.now() - started } }; } throw Object.assign(new Error(`لم نتأكد من نتيجة ${label || 'الإرسال'}؛ لم تتم إعادة الإرسال لمنع التكرار.`), { code: 'SEND_UNCERTAIN' }); }
      this.removeOutgoingIntent(outboundIntent); ackWait.cancel(); createdWait.cancel(); throw e;
    }
  }
  async resolveChatId(id, target) {
    const sid = this.store.safeSessionId(id), client = await this.ensureReady(sid);
    if (target.kind === 'group' || String(target.gid || '').toLowerCase().endsWith('@g.us')) { const gid = String(target.gid || '').trim().toLowerCase(); if (!/^\d+(?:-\d+)*@g\.us$/.test(gid)) throw new Error('معرف المجموعة غير صالح.'); try { const chat = await client.getChatById(gid); return idSerialized(chat?.id) || gid; } catch { return gid; } }
    // Older imported recipients may contain only `digits` or a verified WhatsApp JID.
    const savedJid = String(target.whatsappJid || '').trim().toLowerCase();
    const savedJidDigits = savedJid.match(/^(\d{5,25})@c\.us$/)?.[1] || '';
    const digits = String(target.e164 || target.phone || target.digits || target.number || savedJidDigits || '').replace(/\D/g, '');
    if (!digits) throw new Error(`رقم المستلم مفقود${target.name ? `: ${String(target.name).slice(0, 80)}` : ''}. افتح «الأشخاص» وأعد مزامنة جهات WhatsApp.`);
    if (savedJidDigits && savedJidDigits === digits && typeof client.getContactById === 'function') {
      try { const c = await withTimeout(client.getContactById(savedJid), 10000, 'التحقق من جهة WhatsApp'); if (idSerialized(c?.id).toLowerCase() === savedJid) return savedJid; } catch {}
    }
    const n = await withTimeout(client.getNumberId(digits), 20000, 'فحص رقم WhatsApp');
    if (!n) throw new Error(`الرقم ${digits} (${target.name || 'المستلم'}) غير مسجل على WhatsApp. حدّث جهة الاتصال من حساب WhatsApp أو تحقّق من رمز الدولة.`);
    const resolved = idSerialized(n);
    if (!/^\d{5,25}@c\.us$/i.test(resolved)) throw new Error(`لم يُرجع WhatsApp معرّف هاتف مؤكدًا للمستلم ${target.name || digits}.`);
    return resolved;
  }
  async sendText(id, chatId, text, { timeoutMs = 30000 } = {}) {
    const client = await this.ensureReady(id), content = String(text || '').trim();
    if (!content) throw new Error('النص فارغ.');
    if (!chatId) throw new Error('لم يتم تحديد محادثة WhatsApp للإرسال.');
    const r = await this.sendConfirmed(this.store.safeSessionId(id), chatId, () => client.sendMessage(chatId, content), timeoutMs, 'إرسال النص', content);
    this.entry(id).lastSent = { at: new Date().toISOString(), chatId, kind: 'text' }; return r;
  }
  async sendMedia(id, chatId, file, { timeoutMs = 30000, asDocument = false } = {}) {
    const client = await this.ensureReady(id), sid = this.store.safeSessionId(id);
    if (!chatId) throw new Error('لم يتم تحديد محادثة WhatsApp للإرسال.');
    if (!file || !fs.existsSync(file) || !fs.statSync(file).isFile()) throw new Error('ملف الإرسال غير موجود؛ أعد رفعه من صفحة «الإرسال».');
    const st = fs.statSync(file);
    if (!st.size) throw new Error('الملف المحدد فارغ ولا يمكن إرساله.');
    if (st.size > 250 * 1024 * 1024) throw new Error('حجم الملف تجاوز الحد الأقصى 250 ميجابايت.');
    let media;
    try { media = MessageMedia.fromFilePath(file); }
    catch (e) { throw new Error(`تعذر تجهيز الملف للإرسال: ${safeError(e)}`); }
    const r = await this.sendConfirmed(sid, chatId, () => client.sendMessage(chatId, media, { sendMediaAsDocument: Boolean(asDocument) }), timeoutMs, asDocument ? 'إرسال الملف كمستند' : 'إرسال الصورة أو الوسائط');
    this.entry(id).lastSent = { at: new Date().toISOString(), chatId, kind: asDocument ? 'document' : 'media', filename: path.basename(file), bytes: st.size };
    return r;
  }
  async replyToMessage(id, message, text) { await this.ensureReady(id); const content = String(text || '').trim(); if (!content) return null; const chatId = chatIdFromMessage(message); try { if (typeof message?.reply === 'function') return await this.sendConfirmed(this.store.safeSessionId(id), chatId, () => message.reply(content), 30000, 'الرد', content); } catch (e) { if (e.code === 'SEND_UNCERTAIN') throw e; } if (!chatId) throw new Error('تعذر تحديد المحادثة للرد.'); return this.sendText(id, chatId, content); }
  async reactToMessage(id, messageId, emoji) { const client = await this.ensureReady(id), mid = idSerialized(messageId); if (!mid) throw new Error('معرف الرسالة غير متاح.'); const m = await withTimeout(client.getMessageById(mid), 15000, 'البحث عن الرسالة'); if (!m) throw new Error('لم أجد الرسالة المطلوبة للـReaction.'); await withTimeout(m.react(String(emoji || '👍')), 15000, 'إرسال Reaction'); return { __chatBotAck: { status: 'confirmed', mode: 'reaction' } }; }
  async getChatSafe(id, chatId) {
    const client = await this.ensureReady(id), wanted = String(chatId || '').trim().toLowerCase();
    if (!/^(?:\d{5,25}(?:-\d+)*@g\.us|\d{5,25}@c\.us|\d{5,25}@lid)$/i.test(wanted)) throw new Error('معرّف المحادثة غير صالح.');
    try { const chat = await withTimeout(client.getChatById(wanted), 15000, 'فتح المحادثة'); if (chat && idSerialized(chat.id).toLowerCase() === wanted) return chat; } catch (error) { if (/معرّف المحادثة/.test(error.message)) throw error; }
    const chats = await withTimeout(client.getChats(), 30000, 'البحث في المحادثات');
    const found = (chats || []).find(chat => idSerialized(chat?.id).toLowerCase() === wanted);
    if (!found) throw new Error('المحادثة غير موجودة في حساب WhatsApp الحالي.');
    return found;
  }
  async actOnChat(id, chatId, action, options = {}) {
    const chat = await this.getChatSafe(id, chatId);
    if (action === 'archive') {
      if (typeof chat.archive !== 'function') throw new Error('هذه النسخة من WhatsApp لا تدعم أرشفة المحادثة.');
      await withTimeout(chat.archive(), 15000, 'أرشفة المحادثة'); return { action, chatId: idSerialized(chat.id) };
    }
    if (action === 'delete') {
      if (typeof chat.delete !== 'function') throw new Error('هذه النسخة من WhatsApp لا تدعم حذف المحادثة.');
      const ok = await withTimeout(chat.delete(), 20000, 'حذف المحادثة');
      if (ok === false) throw new Error('لم يؤكد WhatsApp حذف المحادثة.');
      return { action, chatId: idSerialized(chat.id), confirmed: true };
    }
    if (action === 'mute') {
      if (typeof chat.mute !== 'function') throw new Error('هذه النسخة من WhatsApp لا تدعم كتم الإشعارات.');
      let until = null;
      if (options.until instanceof Date && Number.isFinite(options.until.getTime())) until = options.until;
      else if (options.permanent !== true) {
        const minutes = Math.max(1, Math.min(525600, Number(options.minutes) || 60));
        until = new Date(Date.now() + minutes * 60000);
      }
      const result = until ? await withTimeout(chat.mute(until), 15000, 'كتم الإشعارات') : await withTimeout(chat.mute(), 15000, 'كتم الإشعارات');
      return { action, chatId: idSerialized(chat.id), isMuted: result?.isMuted !== false, muteExpiration: result?.muteExpiration ?? null };
    }
    if (action === 'unmute') {
      if (typeof chat.unmute !== 'function') throw new Error('هذه النسخة من WhatsApp لا تدعم إلغاء كتم الإشعارات.');
      const result = await withTimeout(chat.unmute(), 15000, 'إلغاء كتم الإشعارات');
      return { action, chatId: idSerialized(chat.id), isMuted: result?.isMuted === true };
    }
    throw new Error('إجراء المحادثة غير معروف.');
  }
  async deleteMessage(id, messageOrId, options = {}) {
    const client = await this.ensureReady(id);
    let msg = messageOrId && typeof messageOrId.delete === 'function' ? messageOrId : null;
    if (!msg) {
      const mid = idSerialized(messageOrId);
      if (!mid) throw new Error('معرّف الرسالة غير متاح.');
      msg = await withTimeout(client.getMessageById(mid), 15000, 'البحث عن الرسالة');
    }
    if (!msg || typeof msg.delete !== 'function') throw new Error('لم يتم العثور على رسالة قابلة للحذف.');
    const expectedChat = options.chatId ? String(options.chatId).toLowerCase() : '';
    const actualChat = chatIdFromMessage(msg).toLowerCase();
    if (expectedChat && actualChat && expectedChat !== actualChat) throw new Error('تم إيقاف الحذف لأن الرسالة لا تتطابق مع المحادثة المستهدفة.');
    const mid = idSerialized(msg.id || msg);
    if (!mid) throw new Error('لا يمكن التحقق من معرّف الرسالة.');
    const result = await withTimeout(msg.delete(options.everyone === true), 20000, 'حذف الرسالة');
    return { messageId: mid, chatId: actualChat, everyone: options.everyone === true, result: result ?? true };
  }
  async deleteMessagesOlderThan(id, chatId, cutoffMs, options = {}) {
    const chat = await this.getChatSafe(id, chatId);
    if (typeof chat.fetchMessages !== 'function') throw new Error('تعذر قراءة رسائل المحادثة في هذا الإصدار.');
    const limit = Math.max(1, Math.min(1000, Number(options.limit) || 500));
    const messages = await withTimeout(chat.fetchMessages({ limit }), 45000, 'قراءة الرسائل القديمة');
    const cutoff = Number(cutoffMs);
    if (!Number.isFinite(cutoff) || cutoff <= 0) throw new Error('وقت الاحتفاظ بالرسائل غير صالح.');
    const old = (messages || []).filter(m => {
      const stamp = Number(m?.timestamp || m?._data?.t || m?.t || 0);
      const ms = stamp > 1e12 ? stamp : stamp * 1000;
      return ms > 0 && ms < cutoff && typeof m?.delete === 'function' && !m?.isRevoked;
    });
    let deleted = 0, failed = 0; const errors = [];
    for (const msg of old.slice(0, limit)) {
      try { await this.deleteMessage(id, msg, { everyone: options.everyone === true, chatId }); deleted++; }
      catch (error) { failed++; if (errors.length < 8) errors.push(String(error?.message || error).slice(0, 250)); }
    }
    return { scanned: (messages || []).length, matched: old.length, deleted, failed, errors, limitReached: (messages || []).length >= limit };
  }
  async getContactProfilePictureUrl(id, jid) {
    const sid = this.store.safeSessionId(id), normalized = String(jid || '').trim().toLowerCase();
    if (!/^\d{5,25}@c\.us$/.test(normalized)) throw new Error('معرّف جهة WhatsApp غير صالح أو لا يرتبط برقم مؤكد.');
    if (normalized === String(this.selfChatId(sid) || '').toLowerCase()) return '';
    const client = await this.ensureReady(sid);
    const profileUrl = async (contact, rawId) => {
      if (typeof contact?.getProfilePicUrl === 'function') {
        try {
          const url = await withTimeout(contact.getProfilePicUrl(), 8000, 'جلب صورة حساب WhatsApp');
          if (typeof url === 'string' && /^https:\/\//i.test(url)) return url;
        } catch {}
      }
      if (typeof client.getProfilePicUrl === 'function') {
        for (const candidate of [...new Set([rawId, normalized].filter(Boolean))]) {
          if (!candidate) continue;
          try {
            const url = await withTimeout(client.getProfilePicUrl(candidate), 8000, 'جلب صورة حساب WhatsApp');
            if (typeof url === 'string' && /^https:\/\//i.test(url)) return url;
          } catch {}
        }
      }
      return '';
    };

    let contact = null, rawJid = normalized;
    if (typeof client.getContactById === 'function') {
      try { contact = await withTimeout(client.getContactById(normalized), 10000, 'قراءة جهة WhatsApp'); } catch {}
      if (contact && idSerialized(contact?.id).toLowerCase() !== normalized) contact = null;
    }
    if (contact) {
      const direct = await profileUrl(contact, normalized);
      if (direct) return direct;
      // Do not stop at an empty result from the direct PN lookup. On current
      // WhatsApp Web builds, the profile thumbnail may be bound to the mapped LID.
    }

    if (typeof client.getContacts !== 'function') return profileUrl(contact, normalized);
    let contacts = [];
    try { contacts = await withTimeout(client.getContacts(), 30000, 'البحث عن جهة WhatsApp'); } catch {}
    contact = (Array.isArray(contacts) ? contacts : []).find(item => idSerialized(item?.id).toLowerCase() === normalized) || null;
    if (contact) {
      const direct = await profileUrl(contact, normalized);
      if (direct) return direct;
    }

    // Newer WhatsApp accounts may expose a LID for a contact. First ask the
    // library to resolve this exact verified phone ID, avoiding a full contacts
    // scan for every image shown in the UI.
    if (typeof client.getContactLidAndPhone === 'function') {
      try {
        const pairs = await withTimeout(client.getContactLidAndPhone([normalized]), 10000, 'ربط معرف جهة WhatsApp');
        for (const pair of Array.isArray(pairs) ? pairs : []) {
          let pn = idSerialized(pair?.pn || pair?.phone).toLowerCase();
          if (/^\d{5,25}$/.test(pn)) pn = `${pn}@c.us`;
          const lid = idSerialized(pair?.lid).trim().toLowerCase();
          if (pn !== normalized || !/^\d{5,25}@lid$/.test(lid)) continue;
          let mapped = (Array.isArray(contacts) ? contacts : []).find(item => idSerialized(item?.id).toLowerCase() === lid) || null;
          if (!mapped && typeof client.getContactById === 'function') {
            try { mapped = await withTimeout(client.getContactById(lid), 8000, 'قراءة جهة WhatsApp المرتبطة'); } catch {}
          }
          const mappedUrl = await profileUrl(mapped, lid);
          if (mappedUrl) return mappedUrl;
        }
      } catch {}

      // Last fallback: scan LIDs already returned by getContacts, in bounded
      // batches. Never derive a phone number from the opaque LID itself.
      const lidContacts = (Array.isArray(contacts) ? contacts : []).filter(item => /^\d{5,25}@lid$/i.test(idSerialized(item?.id)));
      for (let offset = 0; offset < lidContacts.length; offset += 80) {
        const batch = lidContacts.slice(offset, offset + 80);
        try {
          const pairs = await withTimeout(client.getContactLidAndPhone(batch.map(item => idSerialized(item.id))), 15000, 'ربط معرّفات جهات WhatsApp');
          for (const pair of Array.isArray(pairs) ? pairs : []) {
            let pn = idSerialized(pair?.pn || pair?.phone).toLowerCase();
            if (/^\d{5,25}$/.test(pn)) pn = `${pn}@c.us`;
            if (pn !== normalized) continue;
            const lid = idSerialized(pair?.lid).toLowerCase();
            if (!/^\d{5,25}@lid$/.test(lid)) continue;
            const found = batch.find(item => idSerialized(item?.id).toLowerCase() === lid);
            if (!found) continue;
            const mappedUrl = await profileUrl(found, lid);
            if (mappedUrl) return mappedUrl;
          }
        } catch {}
      }
    }
    return profileUrl(contact, rawJid);
  }

  async listContacts(id, { includeProfilePictures = false, onlyJids = null, limit = 2000 } = {}) {
    const sid = this.store.safeSessionId(id), client = await this.ensureReady(sid);
    if (typeof client.getContacts !== 'function') throw new Error('إصدار مكتبة WhatsApp الحالي لا يوفر استدعاء جهات الاتصال.');
    const all = await withTimeout(client.getContacts(), 30000, 'استدعاء جهات WhatsApp');
    const wanted = Array.isArray(onlyJids) ? new Set(onlyJids.map(v => String(v || '').trim().toLowerCase())) : null;
    const self = this.selfChatId(sid), byJid = new Map();
    const max = Math.max(1, Math.min(2000, Number(limit) || 2000));
    const localNameOf = contact => String(contact?.name || '').trim().slice(0, 100);
    const pushNameOf = contact => String(contact?.pushname || '').trim().slice(0, 100);
    const notifyNameOf = contact => String(contact?.notifyName || contact?._data?.notifyName || '').trim().slice(0, 100);
    const add = (contact, verifiedJid, rawJid) => {
      const jid = String(verifiedJid || '').trim().toLowerCase();
      if (!/^\d{5,25}@c\.us$/.test(jid) || jid === self || (wanted && !wanted.has(jid))) return;
      const digits = jid.slice(0, jid.indexOf('@'));
      const localName = localNameOf(contact), pushname = pushNameOf(contact), notifyName = notifyNameOf(contact);
      const shortName = String(contact?.shortName || '').trim().slice(0, 100);
      const looksLikePhone = value => { const v = String(value || '').replace(/[\s()+.-]/g, ''); return !!v && /^\d+$/.test(v) && v.replace(/^0+/, '') === digits.replace(/^0+/, ''); };
      const names = contact?.isMyContact ? [localName, pushname, notifyName, shortName] : [pushname, notifyName, localName, shortName];
      const displayName = names.find(value => value && !looksLikePhone(value)) || localName || pushname || notifyName || shortName || `+${digits}`;
      const rawContactId = idSerialized(contact?.id).trim().toLowerCase() || rawJid || jid;
      const exactPhoneId = rawContactId === jid;
      const rank = (exactPhoneId ? 4 : 0) + (contact?.isMyContact === true ? 2 : 0) + (displayName && !/^\+?\d+$/.test(displayName) ? 1 : 0);
      const previous = byJid.get(jid);
      if (previous && previous._rank >= rank) return;
      byJid.set(jid, {
        jid, digits, name: displayName, pushname, notifyName, isMyContact: contact?.isMyContact === true,
        isWAContact: contact?.isWAContact !== false, isBusiness: contact?.isBusiness === true,
        profilePicUrl: '', _contactForPicture: contact, _contactIdForPicture: rawContactId, _rank: rank,
      });
    };

    const rows = [];
    const lids = [];
    for (const contact of (Array.isArray(all) ? all : [])) {
      const rawJid = idSerialized(contact?.id).trim().toLowerCase();
      if (/^\d{5,25}@c\.us$/.test(rawJid)) add(contact, rawJid, rawJid);
      else if (/^\d{5,25}@lid$/.test(rawJid)) lids.push({ contact, rawJid });
      if (byJid.size >= max && (!wanted || [...wanted].every(jid => byJid.has(jid)))) break;
    }

    // Do not infer phone numbers from LID digits. Only use the official mapping
    // supplied by WhatsApp, which is the supported path for newer contact IDs.
    if (lids.length && typeof client.getContactLidAndPhone === 'function') {
      for (let offset = 0; offset < lids.length; offset += 80) {
        const batch = lids.slice(offset, offset + 80);
        try {
          const pairs = await withTimeout(client.getContactLidAndPhone(batch.map(item => item.rawJid)), 20000, 'ربط معرّفات جهات WhatsApp');
          const lidToPn = new Map();
          for (const pair of Array.isArray(pairs) ? pairs : []) {
            const lid = idSerialized(pair?.lid).trim().toLowerCase();
            let pn = idSerialized(pair?.pn || pair?.phone).trim().toLowerCase();
            if (/^\d{5,25}$/.test(pn)) pn = `${pn}@c.us`;
            if (/^\d{5,25}@lid$/.test(lid) && /^\d{5,25}@c\.us$/.test(pn)) lidToPn.set(lid, pn);
          }
          for (const item of batch) {
            const pn = lidToPn.get(item.rawJid);
            if (pn) add(item.contact, pn, item.rawJid);
          }
        } catch (error) {
          this.log(sid, 'WARN', `تعذر ربط بعض معرّفات WhatsApp الحديثة؛ لم يتم تخمين الأرقام. ${safeError(error).slice(0, 180)}`);
        }
      }
    }

    const selectedRows = [...byJid.values()].slice(0, max);
    if (includeProfilePictures && selectedRows.length) {
      let cursor = 0;
      const workers = Array.from({ length: Math.min(5, selectedRows.length) }, async () => {
        while (cursor < selectedRows.length) {
          const index = cursor++, row = selectedRows[index], contact = row._contactForPicture;
          try {
            let url = typeof contact?.getProfilePicUrl === 'function'
              ? await withTimeout(contact.getProfilePicUrl(), 8000, 'صورة جهة WhatsApp') : '';
            if (typeof url !== 'string' || !/^https:\/\//i.test(url)) {
              if (typeof client.getProfilePicUrl === 'function') url = await withTimeout(client.getProfilePicUrl(row._contactIdForPicture || row.jid), 8000, 'صورة جهة WhatsApp');
            }
            if (typeof url === 'string' && /^https:\/\//i.test(url)) row.profilePicUrl = url;
          } catch {}
        }
      });
      await Promise.all(workers);
    }
    return selectedRows.map(({ _contactForPicture, _contactIdForPicture, _rank, ...item }) => item)
      .sort((a, b) => Number(b.isMyContact) - Number(a.isMyContact) || a.name.localeCompare(b.name, 'ar'));
  }

  async listGroups(id) {
    const client = await this.ensureReady(id), e = this.entry(id), out = [], seen = new Set();
    let chats = [];
    try { chats = await withTimeout(client.getChats(), 30000, 'قراءة محادثات WhatsApp'); }
    catch (e2) { this.log(id, 'WARN', `تعذر قراءة محادثات WhatsApp: ${safeError(e2)}`); }
    for (const chat of chats || []) {
      const gid = idSerialized(chat?.id).toLowerCase();
      if (!gid.endsWith('@g.us') && !chat?.isGroup) continue;
      try {
        const info = await this.groupInfoFromChat(chat);
        if (!/^\d+(?:-\d+)*@g\.us$/.test(info.gid) || seen.has(info.gid)) continue;
        seen.add(info.gid); e.liveGroups.set(info.gid, info); out.push(info);
      } catch (err) {
        if (gid.endsWith('@g.us')) e.liveGroups.set(gid, { gid, name: String(chat?.name || chat?.subject || gid), description:'', owner:'', participantsCount:null, participants:[], admins:[], inviteCode:'' });
        this.log(id, 'WARN', `تعذر تحليل مجموعة ${gid || 'غير معروفة'}: ${safeError(err)}`);
      }
    }
    for (const [gid, info] of e.liveGroups) if (!seen.has(gid) && /@g\.us$/.test(gid)) out.push(info);
    const unique = new Map(out.filter(x => x?.gid).map(x => [x.gid, x]));
    return [...unique.values()];
  }
  async groupInfoFromChat(chat) { let inviteCode = ''; try { if (typeof chat.getInviteCode === 'function') inviteCode = await chat.getInviteCode(); } catch {} const gid = idSerialized(chat?.id).toLowerCase(); const raw = Array.isArray(chat?.participants) ? chat.participants : (Array.isArray(chat?.groupMetadata?.participants) ? chat.groupMetadata.participants : []); const participants = raw.map(p => ({ id: idSerialized(p?.id || p).toLowerCase(), name: String(p?.name || p?.pushname || p?.notifyName || '').slice(0,120), admin: Boolean(p?.isAdmin || p?.isSuperAdmin || p?.admin) })).filter(p => p.id).slice(0,2000); const admins = participants.filter(p => p.admin).slice(0,500); return { gid, name: String(chat?.name || chat?.subject || 'مجموعة').slice(0, 120), description: String(chat?.description || '').slice(0, 1000), owner: idSerialized(chat?.groupMetadata?.owner), participantsCount: participants.length || (Array.isArray(raw) ? raw.length : null), participants, admins, inviteCode }; }
  async getGroupInfo(id, gid) { const client = await this.ensureReady(id), want = String(gid || '').trim().toLowerCase(); if (!/^\d+(?:-\d+)*@g\.us$/.test(want)) throw new Error('GID غير صالح.'); try { const chat = await client.getChatById(want); if (chat) return this.groupInfoFromChat(chat); } catch {} try { const chats = await client.getChats(); const chat = (chats || []).find(c => idSerialized(c?.id).toLowerCase() === want); if (chat) return this.groupInfoFromChat(chat); } catch {} const live = this.entry(id).liveGroups.get(want); if (live) return live; throw new Error('لم أستطع الوصول إلى هذه المجموعة داخل الجلسة الحالية. افتح المجموعة أو نفّذ اكتشاف المجموعات ثم أعد المحاولة.'); }
  async analyzeGroupInvite(id, code) { const client = await this.ensureReady(id), c = String(code || '').trim(); if (!c) throw new Error('رابط الدعوة غير صالح.'); if (typeof client.getInviteInfo !== 'function') throw new Error('إصدار المكتبة الحالي لا يوفر تحليل رابط الدعوة من دون فتح المجموعة.'); const info = await withTimeout(client.getInviteInfo(c), 20000, 'تحليل الدعوة'); return { gid: idSerialized(info?.id), name: String(info?.subject || info?.name || 'مجموعة عبر دعوة'), description: String(info?.description || ''), participantsCount: Number.isFinite(Number(info?.size)) ? Number(info.size) : null, inviteCode: c }; }
  async getGroupInfoFromMessage(id, msg) { let chat = null; try { if (typeof msg?.getChat === 'function') chat = await msg.getChat(); } catch {} if (chat) return this.groupInfoFromChat(chat); const gid = groupFromMessage(msg); if (!gid) throw new Error('الرسالة الحالية ليست من مجموعة.'); return this.getGroupInfo(id, gid); }
}
module.exports = { WhatsAppManager, safeError, idSerialized, groupFromMessage, chatIdFromMessage, patchResult };
