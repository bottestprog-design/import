"use strict";
const crypto = require('node:crypto');
const { scanImages, safePath } = require('./media');
const { classifyWhatsAppError, toUserFacingError } = require('./whatsapp-errors');
const sleep = ms => new Promise(resolve => setTimeout(resolve, Math.max(0, Number(ms) || 0)));
const safeError = e => String(e?.message || e || 'خطأ غير معروف');
function renderTemplate(text, v) {
  return String(text || '')
    .replace(/\{\{recipient\}\}/gi, v.recipient || '')
    .replace(/\{\{sender\}\}/gi, v.recipient || '')
    .replace(/\{\{phone\}\}/gi, v.phone || '')
    .replace(/\{\{number\}\}/gi, v.phone || '')
    .replace(/\{\{image\}\}/gi, v.image || '')
    .replace(/\{\{date\}\}/gi, v.date || '')
    .replace(/\{\{time\}\}/gi, v.time || '')
    .trim();
}
function hashText(v) { return crypto.createHash('sha1').update(String(v || ''), 'utf8').digest('hex').slice(0, 16); }
function nowVars(target, image, tz) { return { recipient: target.name || '', phone: target.phone || '', image: image?.filename || '', date: new Intl.DateTimeFormat('ar-OM', { timeZone: tz, dateStyle: 'short' }).format(new Date()), time: new Intl.DateTimeFormat('ar-OM', { timeZone: tz, hour: '2-digit', minute: '2-digit' }).format(new Date()) }; }
function key(stage, text, image) { return stage === 'image' ? `image:${image.id}:${image.size || 0}` : `${stage}:${hashText(text)}`; }
function assertUsable(result, label) {
  const status = result?.__chatBotAck?.status;
  if (status === 'uncertain') throw Object.assign(new Error(`${label}: لم يتم تأكيد النتيجة، لذلك لم تتم إعادة المحاولة لمنع التكرار.`), { code: 'SEND_UNCERTAIN' });
  return result;
}
class DeliveryService {
  constructor({ store, whatsapp, log }) { this.store = store; this.whatsapp = whatsapp; this.log = log; this.busy = new Set(); }
  session(id) { return this.store.loadSession(id); }
  files(id) { const s = this.session(id); return scanImages(this.store.getPaths(id).images, s.settings.maxImageSizeMB).files; }
  images(id) { return this.files(id).filter(x => x.isImage); }
  syncCycle(id) { const s = this.session(id), imgs = this.images(id), ids = imgs.map(x => x.id), old = s.cycle.imageOrder || [], current = old[s.cycle.currentIndex]; s.cycle.imageOrder = ids; const map = {}; for (const iid of ids) map[iid] = s.cycle.delivery?.[iid] || {}; s.cycle.delivery = map; if (!ids.length) s.cycle.currentIndex = 0; else if (current && ids.includes(current)) s.cycle.currentIndex = ids.indexOf(current); else s.cycle.currentIndex = Math.min(Number(s.cycle.currentIndex) || 0, ids.length - 1); this.store.saveSession(s); return s; }
  targets(s, scheduled = false, selected = null) { const recipients = s.recipients.filter(x => x.enabled !== false).map(x => ({ ...x, kind: 'recipient', targetId: x.id })); const explicitGroupSelection = Array.isArray(selected) && selected.some(k => String(k).startsWith('g:')); const groups = (!scheduled || s.settings.scheduledGroupsEnabled || explicitGroupSelection) ? s.groups.filter(x => x.enabled !== false).map(x => ({ ...x, kind: 'group', targetId: x.id, phone: '' })) : []; const all = [...recipients, ...groups]; if (!Array.isArray(selected) || !selected.length) return all; const set = new Set(selected.map(String)); return all.filter(x => set.has(`${x.kind === 'group' ? 'g' : 'r'}:${x.id}`) || set.has(x.id)); }
  state(s, image, target) { s.cycle.delivery = s.cycle.delivery || {}; s.cycle.delivery[image.id] = s.cycle.delivery[image.id] || {}; const m = s.cycle.delivery[image.id]; m[target.targetId] = m[target.targetId] || { pre: false, image: false, post: false, preKey: null, imageKey: null, postKey: null, lastError: null, round: s.cycle.round }; return m[target.targetId]; }
  done(st, flag, k) { return st[flag] === true && (!st[`${flag}Key`] || st[`${flag}Key`] === k); }
  async retry(fn, label, s, id) {
    let last;
    const attempts = Math.max(1, Number(s.settings.retryAttempts) || 1);
    for (let i = 0; i < attempts; i++) {
      try { return await fn(); }
      catch (error) {
        last = error;
        const info = classifyWhatsAppError(error, label);
        // Permission, invalid-recipient, rate-limit, media validation, and uncertain
        // outcomes are definitive/sensitive failures: repeating them makes things worse
        // and can duplicate a message if the client failed after creating it.
        if (!info.retryable || error?.code === 'SEND_UNCERTAIN') throw toUserFacingError(error, label);
        if (i + 1 >= attempts) throw toUserFacingError(error, label);
        this.log(id, 'WARN', `${label}: تعذر اتصال مؤقت؛ إعادة محاولة ${i + 1}/${attempts - 1}.`);
        await sleep(Number(s.settings.retryDelayMs) || 800);
      }
    }
    throw toUserFacingError(last, label);
  }
  async sequence(id, target, image, { scheduled = true, preText, postText, sendOrder = 'target-first', countTowardCycle = true } = {}) {
    const s = this.session(id), vars = nowVars(target, image, s.settings.timezone), pre = renderTemplate(preText ?? s.settings.preText, vars), post = renderTemplate(postText ?? s.settings.postText, vars), p = this.store.getPaths(id), chatId = await this.whatsapp.resolveChatId(id, target), file = image ? safePath(p.images, image.filename) : null, st = countTowardCycle && image ? this.state(s, image, target) : { pre: false, image: false, post: false };
    if (!image && !pre && !post) throw new Error('اكتب رسالة أو اختر ملفًا واحدًا على الأقل.');
    const preK = image ? key('pre', preText ?? s.settings.preText, image) : `text:${hashText(preText ?? s.settings.preText)}`, imgK = image ? key('image', '', image) : '', postK = image ? key('post', postText ?? s.settings.postText, image) : '';
    const sendPre = async () => {
      if (!pre || this.done(st, 'pre', preK)) return;
      const r = assertUsable(await this.retry(() => this.whatsapp.sendText(id, chatId, pre, { timeoutMs: s.settings.sendTimeoutMs }), 'الرسالة النصية', s, id), 'الرسالة النصية');
      st.pre = true; st.preKey = preK; s.stats.sentMessages++;
      if (r.__chatBotAck?.status === 'confirmed') s.stats.confirmedAcks++;
      if (r.__chatBotAck?.status === 'created') s.stats.createdSends++;
      this.store.saveSession(s); await sleep(s.settings.sendDelayMs);
    };
    const sendImage = async () => {
      if (!image || this.done(st, 'image', imgK)) return;
      const r = assertUsable(await this.retry(() => this.whatsapp.sendMedia(id, chatId, file, { timeoutMs: s.settings.sendTimeoutMs, asDocument: !image.isImage }), 'الوسائط', s, id), 'الوسائط');
      st.image = true; st.imageKey = imgK; image.isImage ? s.stats.sentImages++ : s.stats.sentFiles++;
      if (r.__chatBotAck?.status === 'confirmed') s.stats.confirmedAcks++;
      if (r.__chatBotAck?.status === 'created') s.stats.createdSends++;
      this.store.saveSession(s); await sleep(s.settings.sendDelayMs);
    };
    const sendPost = async () => {
      if (!post || this.done(st, 'post', postK)) return;
      const r = assertUsable(await this.retry(() => this.whatsapp.sendText(id, chatId, post, { timeoutMs: s.settings.sendTimeoutMs }), 'النص الختامي', s, id), 'النص الختامي');
      st.post = true; st.postKey = postK; s.stats.sentMessages++;
      if (r.__chatBotAck?.status === 'confirmed') s.stats.confirmedAcks++;
      if (r.__chatBotAck?.status === 'created') s.stats.createdSends++;
      this.store.saveSession(s);
    };
    try {
      // image-first means each selected file precedes its associated text, not merely
      // that the outer job array is reordered. Keep stage flags for safe partial resume.
      if (image && sendOrder === 'image-first') { await sendImage(); await sendPre(); }
      else { await sendPre(); await sendImage(); }
      await sendPost();
      return st;
    } catch (e) { if (e.code === 'SEND_UNCERTAIN') s.stats.uncertainSends++; st.lastError = safeError(e); this.store.saveSession(s); throw e; }
  }
  allComplete(s, image, targets, { preText = s.settings.preText, postText = s.settings.postText } = {}) { return targets.every(t => { const st = s.cycle.delivery?.[image.id]?.[t.targetId] || {}, vars = nowVars(t, image, s.settings.timezone), pre = renderTemplate(preText, vars), post = renderTemplate(postText, vars); return this.done(st, 'image', key('image', '', image)) && (!pre || this.done(st, 'pre', key('pre', preText, image))) && (!post || this.done(st, 'post', key('post', postText, image))); }); }
  advance(id, { preText, postText, selectedTargets = null } = {}) { const s = this.syncCycle(id), imgs = this.images(id), cur = imgs[s.cycle.currentIndex]; if (!cur) return false; const targets = this.targets(s, true, Array.isArray(selectedTargets) ? selectedTargets : s.settings.scheduleTargetKeys); if (!targets.length || !this.allComplete(s, cur, targets, { preText: preText ?? s.settings.preText, postText: postText ?? s.settings.postText })) return false; if (s.cycle.currentIndex >= imgs.length - 1) { s.cycle.round++; s.cycle.roundStartedAt = new Date().toISOString(); s.cycle.currentIndex = 0; s.cycle.delivery = {}; s.cycle.manualGuard = {}; this.store.saveSession(s); this.log(id, 'INFO', `اكتملت دورة الملفات وبدأت الجولة ${s.cycle.round}.`); } else { s.cycle.currentIndex++; this.store.saveSession(s); } return true; }
  scheduleImage(id) { const s = this.syncCycle(id), files = this.files(id); if (s.settings.scheduleMediaId) { const fixed = files.find(x => x.id === s.settings.scheduleMediaId); if (fixed) return { image: fixed, fixed: true }; } const imgs = this.images(id); return { image: imgs[s.cycle.currentIndex] || imgs[0] || null, fixed: false }; }
  async scheduledRun(id) { const sid = this.store.safeSessionId(id); if (this.busy.has(sid)) return { ok: false, message: 'يوجد إرسال قيد التنفيذ.' }; this.busy.add(sid); try { const s0 = this.session(sid), { image, fixed } = this.scheduleImage(sid), targets = this.targets(s0, true, s0.settings.scheduleTargetKeys), preText = s0.settings.schedulePreText !== '' ? s0.settings.schedulePreText : s0.settings.preText, postText = s0.settings.schedulePostText !== '' ? s0.settings.schedulePostText : s0.settings.postText; if (!image && !String(preText || '').trim() && !String(postText || '').trim()) return { ok: false, retry: false, message: 'أضف ملفًا أو نصًا للجدولة.' }; if (!targets.length) return { ok: false, retry: false, message: 'لا توجد أهداف مفعلة للجدولة.' }; await this.whatsapp.ensureReady(sid); const sent = [], failed = []; for (const target of targets) { try { await this.sequence(sid, target, image, { scheduled: true, preText, postText, sendOrder: s0.settings.sendOrder || 'target-first', countTowardCycle: !fixed }); sent.push({ target: target.name, targetId: target.targetId, kind: target.kind, image: image?.filename || null }); } catch (e) { const actionable = toUserFacingError(e, `الإرسال إلى ${target.name || target.phone || 'المستلم'}`); failed.push({ target: target.name, kind: target.kind, error: safeError(actionable), code: actionable.code || e.code || null, retryable: actionable.retryable === true }); const fresh = this.session(sid); fresh.stats.failedSends++; this.store.saveSession(fresh); } } const s = this.session(sid); const complete = fixed ? failed.length === 0 : (image ? this.allComplete(s, image, targets, { preText, postText }) : failed.length === 0); if (complete && !fixed && image) this.advance(sid, { preText, postText, selectedTargets: s.settings.scheduleTargetKeys }); const fresh = this.session(sid); fresh.lastRun = { at: new Date().toISOString(), type: 'scheduled', image: image?.filename || null, round: fresh.cycle.round, sent, failed, complete }; complete ? fresh.stats.successfulRuns++ : fresh.stats.failedRuns++; this.store.saveSession(fresh); return { ok: failed.length === 0, retry: failed.length > 0, sent, failed, complete, image: image?.filename || null, round: fresh.cycle.round }; } finally { this.busy.delete(sid); } }
  cleanupManualGuard(s, windowMs) { const guard = s.cycle.manualGuard || {}, now = Date.now(); for (const [k, v] of Object.entries(guard)) { const at = typeof v === 'number' ? v : Number(v?.at || 0); if (!at || now - at > windowMs) delete guard[k]; } s.cycle.manualGuard = guard; }
  async sendNow(id, { targetKeys = [], targets = [], recipientIds = [], groupIds = [], mediaId, filename, mediaIds = [], text, beforeText, afterText, preText, postText, sendOrder = 'target-first', countTowardCycle = false, repeatGuard = true, replaceDuplicate = false } = {}) {
    const sid = this.store.safeSessionId(id); if (this.busy.has(sid)) throw new Error('يوجد إرسال آخر قيد التنفيذ.'); this.busy.add(sid);
    try {
      let s = this.session(sid), files = this.files(sid), requested = [...(Array.isArray(mediaIds) ? mediaIds : []), mediaId, filename].filter(Boolean).map(String); requested = [...new Set(requested)];
      const mediaList = requested.map(x => files.find(f => f.id === x)).filter(Boolean); if (requested.length !== mediaList.length) throw new Error('بعض الملفات المحددة غير موجودة.');
      const selectedKeys = Array.isArray(targetKeys) && targetKeys.length ? targetKeys : (Array.isArray(targets) && targets.length ? targets : [...recipientIds.map(x => `r:${x}`), ...groupIds.map(x => `g:${x}`)]);
      preText = preText ?? beforeText ?? text; postText = postText ?? afterText;
      const targetList = this.targets(s, false, selectedKeys); if (!targetList.length) throw new Error('حدد مستلمًا أو مجموعة واحدة على الأقل.');
      if (!mediaList.length && !String(preText || '').trim() && !String(postText || '').trim()) throw new Error('اكتب رسالة أو اختر ملفًا واحدًا على الأقل.');
      this.cleanupManualGuard(s, 90000); this.store.saveSession(s); const sent = [], failed = [], jobs = [];
      if (sendOrder === 'image-first' && mediaList.length) { for (const image of mediaList) for (const target of targetList) jobs.push({ image, target }); } else { for (const target of targetList) { if (mediaList.length) for (const image of mediaList) jobs.push({ image, target }); else jobs.push({ image: null, target }); } }
      for (const job of jobs) {
        const { image, target } = job, fingerprint = crypto.createHash('sha1').update(JSON.stringify([target.targetId, image?.id || 'text', preText ?? s.settings.preText, postText ?? s.settings.postText]), 'utf8').digest('hex');
        if (repeatGuard && s.cycle.manualGuard?.[fingerprint] && !replaceDuplicate) { failed.push({ target: target.name, kind: target.kind, image: image?.filename || null, error: 'تم منع إرسال مطابق خلال آخر 90 ثانية.', code: 'DUPLICATE_GUARD' }); continue; }
        try { await this.sequence(sid, target, image, { scheduled: false, preText, postText, sendOrder, countTowardCycle }); sent.push({ target: target.name, targetId: target.targetId, kind: target.kind, image: image?.filename || null }); s = this.session(sid); s.cycle.manualGuard = s.cycle.manualGuard || {}; s.cycle.manualGuard[fingerprint] = { at: Date.now(), target: target.name, image: image?.filename || null }; this.store.saveSession(s); } catch (e) { const actionable = toUserFacingError(e, `الإرسال إلى ${target.name || target.phone || 'المستلم'}`); failed.push({ target: target.name, targetId: target.targetId, kind: target.kind, image: image?.filename || null, error: safeError(actionable), code: actionable.code || e.code || null, retryable: actionable.retryable === true }); const fresh = this.session(sid); fresh.stats.failedSends++; this.store.saveSession(fresh); }
      }
      return { ok: failed.length === 0, sent, failed, images: mediaList.map(x => x.filename) };
    } finally { this.busy.delete(sid); }
  }
  async scheduledTaskRun(id, task) { let targets = Array.isArray(task.targetKeys) ? task.targetKeys.filter(Boolean) : []; if (task.scheduledGroupsEnabled === false) targets = targets.filter(k => !String(k).startsWith('g:')); if (!targets.length) throw new Error(`الموعد «${task.name || 'بدون اسم'}» لا يحتوي أهدافًا.`); const s = this.session(id); let mediaIds = Array.isArray(task.mediaIds) ? task.mediaIds.filter(Boolean) : []; if (task.mediaMode === 'cycle' && !mediaIds.length) { const current = this.currentImage(id); if (current) mediaIds = [current.id]; } if (!mediaIds.length && !String(task.preText || '').trim() && !String(task.postText || '').trim()) throw new Error(`الموعد «${task.name || 'بدون اسم'}» لا يحتوي رسالة أو ملفات.`); const result = await this.sendNow(id, { targetKeys: targets, mediaIds, preText: task.preText, postText: task.postText, sendOrder: task.sendOrder || 'target-first', repeatGuard: false, countTowardCycle: false }); if (task.mediaMode === 'cycle' && result.ok && mediaIds.length) { const fresh = this.session(id), imgs = this.images(id), idx = imgs.findIndex(x => x.id === mediaIds[0]); if (idx >= 0) { fresh.cycle.imageOrder = imgs.map(x => x.id); fresh.cycle.currentIndex = (idx + 1) % Math.max(1, imgs.length); if (idx === imgs.length - 1) { fresh.cycle.round++; fresh.cycle.delivery = {}; } this.store.saveSession(fresh); } } return { ...result, complete: result.ok, taskId: task.id }; }
  currentImage(id) { const s = this.syncCycle(id), imgs = this.images(id); return imgs[s.cycle.currentIndex] || imgs[0] || null; }
}
module.exports = { DeliveryService, renderTemplate, hashText, safeError };
