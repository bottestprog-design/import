'use strict';

const crypto = require('node:crypto');
const recipientManagement = require('./recipient-management');
const whatsappContacts = require('./whatsapp-contacts');

const WELCOME_GUIDE = `أهلًا بك في chat BOT 🤖
أنا مساعدك المحلي داخل محادثة «الرسائل إلى نفسك». لا أستخدم API ذكاء اصطناعي خارجيًا؛ أفهم الأوامر المحلية وأدير حوارات قصيرة خطوة بخطوة.

ابدأ بكتابة أحد الأوامر:
• مساعدة — عرض الأوامر.
• الحالة — حالة الاتصال والأعداد.
• عايز أضيف شخص جديد — حوار إضافة اسم ودولة ورقم، مع معالجة التكرار.
• أرسل رسالة — اختيار مستلم، كتابة الرسالة، ثم تأكيد الإرسال.
• أنشئ موعد — إعداد رسالة مجدولة خطوة بخطوة.
• أنشئ رد تلقائي — تحديد العبارة والرد ثم تأكيد الحفظ.
• استدعاء جهات واتساب — معاينة جهات WhatsApp؛ ثم اكتب «تأكيد المزامنة» لاستيراد الجهات الرقمية الجديدة.
• قائمة الأشخاص / قائمة المجموعات / سجل النشاط / اعرض المواعيد / اعرض الوسائط.
• أوامر مباشرة: أرسل الآن | إلى=أحمد | الرسالة=مرحبًا، وأضف موعد | الاسم=تذكير | التكرار=مرة | التاريخ=2026-11-01 | الوقت=17:30 | إلى=أحمد | الرسالة=النص.
• مساعدة الإرسال / مساعدة المواعيد / مساعدة التفاعل / مساعدة المجموعات.
• دليل الاستخدام — إعادة عرض هذه الرسالة.

يمكنك كتابة «إلغاء» أثناء أي حوار لإيقافه. الإرسال والحذف وتشغيل موعد يدويًا يتطلب تأكيدًا صريحًا. إدارة الأسماء والردود والمواعيد مرتبطة بالجلسة الحالية فقط.
للاستدعاء الانتقائي للأسماء والصور وتحديث الملف الشخصي، افتح لوحة chat BOT ثم «الأشخاص» ← «استدعاء ومزامنة جهات WhatsApp».`;

function normalize(value) {
  return String(value || '').normalize('NFKC').toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[إأآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
    .replace(/[ـ\u200e\u200f]/g, '').replace(/[،؛.!؟?]/g, ' ').replace(/\s+/g, ' ').trim();
}
function isCancel(text) { return /^(?:الغاء|الغاء الامر|تراجع|وقف|الغاء الحوار|cancel|stop)$/u.test(normalize(text)); }
function isConfirm(text) { return /^(?:تاكيد|اكد|نعم|موافق|نفذ|نفذ الان|ارسل|تاكيد الارسال|تاكيد الحفظ|اكد المزامنه|تاكيد المزامنه|موافقه)$/u.test(normalize(text)); }
function phoneDigits(person) { return String(person?.digits || person?.phone || person?.e164 || '').replace(/\D/g, ''); }
function ownTarget(session, target) {
  if (target?.type === 'group') return { key: `g:${target.id}`, chatId: String(target.gid || '').toLowerCase(), label: target.name || target.gid };
  const digits = phoneDigits(target);
  return { key: `r:${target.id}`, chatId: digits ? `${digits}@c.us` : String(target?.chatId || '').toLowerCase(), label: target?.name || target?.international || digits };
}
function countryCode(value) {
  const input = normalize(value).toUpperCase();
  const map = new Map([
    ['OM','OM'],['عمان','OM'],['سلطنة عمان','OM'],['oman','OM'],
    ['SA','SA'],['السعوديه','SA'],['السعودية','SA'],['saudi arabia','SA'],
    ['AE','AE'],['الامارات','AE'],['الإمارات','AE'],['uae','AE'],
    ['EG','EG'],['مصر','EG'],['egypt','EG'],['QA','QA'],['قطر','QA'],
    ['KW','KW'],['الكويت','KW'],['BH','BH'],['البحرين','BH'],
    ['JO','JO'],['الاردن','JO'],['الأردن','JO'],['IQ','IQ'],['العراق','IQ'],
    ['US','US'],['امريكا','US'],['الولايات المتحده','US'],['GB','GB'],['بريطانيا','GB'],
    ['IN','IN'],['الهند','IN'],['PK','PK'],['باكستان','PK'],
  ]);
  return map.get(input) || (/^[A-Z]{2}$/.test(input) ? input : '');
}

class OwnerAssistant {
  constructor({ store, whatsapp, phones, log }) {
    this.store = store; this.whatsapp = whatsapp; this.phones = phones; this.log = log;
    this.contactSync = whatsappContacts;
    this.welcomeInFlight = new Set();
  }
  session(id) {
    const session = this.store.loadSession(id);
    session.ownerAssistant ||= { flow: null, welcomeSentAt: '', recent: [] };
    session.ownerAssistant.recent = Array.isArray(session.ownerAssistant.recent) ? session.ownerAssistant.recent.slice(-50) : [];
    return session;
  }
  save(session) { this.store.saveSession(session); }
  async reply(id, text) {
    const chatId = this.whatsapp.selfChatId(id);
    if (!chatId) throw new Error('لم أستطع تأكيد معرّف محادثة النفس. تحقق من اتصال WhatsApp ثم أعد المحاولة.');
    return this.whatsapp.sendText(id, chatId, String(text || '').slice(0, 60000));
  }
  async maybeSendWelcome(id) {
    const sessionId = this.store.safeSessionId(id);
    if (this.welcomeInFlight.has(sessionId)) return false;
    this.welcomeInFlight.add(sessionId);
    try {
      const s = this.session(sessionId);
      if (s.ownerAssistant.welcomeSentAt) return false;
      if (!this.whatsapp.listRuntime(sessionId)?.ready || !this.whatsapp.selfChatId(sessionId)) return false;
      // Persist only after the local send accepted, so reconnects can retry a failed welcome.
      await this.reply(sessionId, WELCOME_GUIDE);
      const fresh = this.session(sessionId);
      if (fresh.ownerAssistant.welcomeSentAt) return false;
      fresh.ownerAssistant.welcomeSentAt = new Date().toISOString();
      fresh.ownerAssistant.recent.push({ at: fresh.ownerAssistant.welcomeSentAt, type: 'welcome-guide-sent' });
      this.save(fresh);
      return true;
    } finally {
      this.welcomeInFlight.delete(sessionId);
    }
  }
  async handleSelfChatMessage(id, msg) {
    const text = String(msg?.body || msg?._data?.body || '').trim();
    if (!text || text.length > 60000) return { handled: false, fallback: true };
    const s = this.session(id), assistant = s.ownerAssistant;
    if (isCancel(text)) {
      if (!assistant.flow) return { handled: false, fallback: true };
      assistant.flow = null; this.save(s); await this.reply(id, 'تم إلغاء الحوار. لم يُرسل شيء ولم تُحفظ تغييرات هذا الحوار.'); return { handled: true };
    }
    if (assistant.flow) {
      const handled = await this.stepFlow(id, s, text);
      if (handled) return { handled: true };
    }
    const p = normalize(text);
    if (/^(?:مساعده|ساعدني|الاوامر|الاوامر المتاحه|help|دليل الاستخدام|ارسل الدليل)$/u.test(p) || /^(?:دليل الاستخدام|مساعدة البوت)$/u.test(p)) {
      await this.reply(id, WELCOME_GUIDE); return { handled: true };
    }
    if (/^(?:الحاله|حاله النظام|حاله الاتصال|status|هل انت متصل)$/u.test(p)) {
      const current = this.session(id), runtime = this.whatsapp.listRuntime(id);
      const status = runtime.ready ? 'متصل' : runtime.status === 'qr' ? 'بانتظار مسح QR' : (runtime.status || 'غير متصل');
      await this.reply(id, `حالة الجلسة «${current.name}»: ${status}.\nالأشخاص: ${current.recipients.length}، المجموعات: ${current.groups.length}.\nقواعد التفاعل: ${(current.interaction.rules || []).filter(x => x.enabled !== false).length} مفعّلة.\nالمواعيد: ${(current.automation.tasks || []).filter(x => x.enabled !== false).length} مفعّلة.\nالأتمتة: ${current.settings.automationEnabled === false ? 'متوقفة' : 'مفعّلة'}.`);
      return { handled: true };
    }
    if (/(?:قائمه|اعرض|اسماء|عدد|كم).*(?:الاشخاص|المستلمين|جهات الارسال)|^(?:الاشخاص|المستلمين|قائمة الاشخاص)$/u.test(p)) {
      const list = s.recipients.slice(0, 50).map((x, i) => `${i + 1}. ${x.name || 'بدون اسم'} — ${x.international || x.e164 || x.phone || ''}${x.enabled === false ? ' (متوقف)' : ''}`);
      await this.reply(id, `الأشخاص المحفوظون: ${s.recipients.length}.${list.length ? `\n${list.join('\n')}` : '\nلا توجد جهات محفوظة.'}${s.recipients.length > list.length ? `\n... وهناك ${s.recipients.length - list.length} جهة إضافية.` : ''}`);
      return { handled: true };
    }
    if (/(?:قائمه|اعرض|عدد|كم).*(?:المجموعات)|^(?:المجموعات|قائمة المجموعات)$/u.test(p)) {
      const list = s.groups.slice(0, 50).map((x, i) => `${i + 1}. ${x.name || 'مجموعة'} — ${x.gid}`);
      await this.reply(id, `المجموعات المحفوظة: ${s.groups.length}.${list.length ? `\n${list.join('\n')}` : '\nلا توجد مجموعات محفوظة.'}`); return { handled: true };
    }
    if (/(?:سجل النشاط|اخر العمليات|اخر الاخطاء|السجل)$/u.test(p)) {
      const list = (s.logs || []).slice(-12).reverse().map(x => `• ${x.at || x.time || ''} ${x.level || ''} ${x.message || x.text || ''}`.trim());
      await this.reply(id, list.length ? `آخر النشاطات:\n${list.join('\n')}` : 'لا توجد نشاطات مسجلة بعد.'); return { handled: true };
    }
    if (/(?:اضافه|اضيف|ضيف|اضف|سجل).*(?:شخص|مستخدم|رقم|جهة)|(?:شخص|مستخدم|رقم جديد|جهة اتصال جديدة)/u.test(p)) {
      assistant.flow = { type: 'add-recipient', step: 'name', data: {} }; this.save(s);
      await this.reply(id, 'حوار إضافة شخص (1/3)\nما اسم الشخص الذي تريد إضافته؟'); return { handled: true };
    }
    if (/(?:استدعاء|مزامنه|مزامنة|سحب).*(?:جهات|اشخاص|اسماء).*(?:واتساب|whatsapp)|^(?:استدعاء جهات واتساب|مزامنة واتساب|مزامنه واتساب)$/u.test(p)) {
      const contacts = await this.whatsapp.listContacts(id, { limit: 1000 });
      if (!contacts.length) { await this.reply(id, 'لم أعثر على جهات رقمية قابلة للاستدعاء في الجلسة المتصلة. تأكد من اكتمال مزامنة WhatsApp ومنح الجلسة وقتًا لتحميل جهات الاتصال.'); return { handled: true }; }
      assistant.flow = { type: 'sync-confirm', step: 'confirm', data: { jids: contacts.slice(0, 100).map(x => x.jid), totalAvailable: contacts.length } }; this.save(s);
      const preview = contacts.slice(0, 12).map((x, i) => `${i + 1}. ${x.name} — +${x.digits}`).join('\n');
      await this.reply(id, `وجدت ${contacts.length} جهة رقمية في WhatsApp. لأمانك، ستُضاف بحد أقصى 100 جهة جديدة في هذا الأمر؛ لن أستبدل أسماءك المخصصة ولن أنفّذ إرسالًا.\n${preview}${contacts.length > 12 ? '\n…' : ''}\n\nاكتب «تأكيد المزامنة» للمتابعة أو «إلغاء» للإلغاء. للمزامنة الانتقائية والصور استخدم صفحة الأشخاص في لوحة التحكم.`);
      return { handled: true };
    }
    if (/(?:ارسل|ابعث|ابعت|ارسال|ابعاث).*(?:رساله|رسالة)|^(?:ارسل رسالة|ابعت رسالة|ارسال رساله)$/u.test(p)) {
      assistant.flow = { type: 'send-message', step: 'target', data: {} }; this.save(s);
      await this.reply(id, 'حوار إرسال رسالة (1/3)\nاكتب اسم الشخص أو المجموعة المحفوظة، أو رقمًا دوليًا مثل ‎+968…‎.'); return { handled: true };
    }
    if (/(?:انشئ|انشاء|اعمل|سوي|سجل|اضف).*(?:موعد|جدول|رساله مجدوله)|^(?:موعد جديد|إنشاء موعد)$/u.test(p)) {
      assistant.flow = { type: 'schedule', step: 'target', data: {} }; this.save(s);
      await this.reply(id, 'حوار إنشاء موعد (1/5)\nلمن تريد إرسال الرسالة؟ اكتب اسم شخص/مجموعة محفوظة أو رقمًا دوليًا.'); return { handled: true };
    }
    if (/(?:انشئ|انشاء|اعمل|سوي|اضف|اضافه).*(?:رد تلقائي|قاعدة رد|تفاعل تلقائي)|^(?:رد تلقائي جديد|قاعدة رد جديدة)$/u.test(p)) {
      assistant.flow = { type: 'auto-reply', step: 'trigger', data: {} }; this.save(s);
      await this.reply(id, 'حوار إنشاء رد تلقائي (1/3)\nما العبارة التي ينبغي أن يبحث عنها البوت في الرسالة الواردة؟'); return { handled: true };
    }
    if (/^(?:السلام عليكم|مرحبا|مرحباً|اهلا|اهلا وسهلا|صباح الخير|مساء الخير|hi|hello)$/u.test(p)) {
      await this.reply(id, 'وعليكم السلام وأهلًا بك! اكتب «مساعدة» لعرض الأوامر، أو ابدأ بعبارة «عايز أضيف شخص جديد» أو «أرسل رسالة».'); return { handled: true };
    }
    return { handled: false, fallback: true };
  }
  async resolveTarget(session, value) {
    const query = normalize(value);
    if (!query) throw new Error('لم تكتب اسم الجهة أو رقمها.');
    const all = [
      ...session.recipients.map(x => ({ ...ownTarget(session, x), type: 'recipient', source: x })),
      ...session.groups.map(x => ({ ...ownTarget(session, { ...x, type: 'group' }), type: 'group', source: x })),
    ];
    const exact = all.filter(x => normalize(x.label) === query || normalize(x.chatId) === query);
    const found = exact.length ? exact : all.filter(x => normalize(x.label).includes(query) || normalize(x.chatId).includes(query));
    if (found.length === 1) return found[0];
    if (found.length > 1) throw new Error(`الاسم يطابق أكثر من جهة:\n${found.slice(0, 8).map(x => `• ${x.label}`).join('\n')}\nاكتب الاسم الكامل.`);
    if (/^\d{5,25}@g\.us$/i.test(value.trim())) return { key: '', chatId: value.trim().toLowerCase(), label: value.trim(), type: 'group' };
    try {
      const parsed = this.phones.parse(value, 'OM');
      const chatId = await this.whatsapp.resolveChatId(session.id, { e164: parsed.e164, phone: parsed.digits });
      return { key: '', chatId, label: parsed.international, type: 'recipient' };
    } catch (error) {
      throw new Error(`لم أعثر على جهة مطابقة «${value}». استخدم الاسم المحفوظ كما هو أو رقمًا دوليًا صالحًا. ${error.message}`);
    }
  }
  async stepFlow(id, session, text) {
    const assistant = session.ownerAssistant, flow = assistant.flow, value = String(text || '').trim(), p = normalize(value), d = flow.data || (flow.data = {});
    if (flow.type === 'sync-confirm') {
      if (!isConfirm(value) && !/^(?:تأكيد المزامنه|تأكيد المزامنة|تاكيد المزامنه|موافق)$/u.test(p)) { await this.reply(id, 'اكتب «تأكيد المزامنة» للمتابعة أو «إلغاء» للتراجع.'); return true; }
      const result = await this.contactSync.syncContacts({ store: this.store, whatsapp: this.whatsapp, phones: this.phones, sessionId: id, jids: d.jids, importMissing: true, updateNames: false, updatePictures: true });
      // Contact sync saves its own fresh session snapshot. Reload it before clearing this flow so imports aren't overwritten.
      const latest = this.session(id); latest.ownerAssistant.flow = null; latest.ownerAssistant.recent.push({ at: new Date().toISOString(), type: 'whatsapp-contact-sync', imported: result.imported.length, updated: result.updated.length }); this.save(latest);
      await this.reply(id, `${result.message}\nحافظت على الأسماء المحلية التي كتبتها بنفسك، وتم تحديث أسماء WhatsApp ونسخ الصور المتاحة إلى ملف المشروع. لعرض الصور والبحث والاختيار الانتقائي افتح «الأشخاص» في لوحة التحكم.`); return true;
    }
    if (flow.type === 'add-recipient') {
      if (flow.step === 'name') {
        if (value.length < 2 || value.length > 80) { await this.reply(id, 'اكتب اسمًا واضحًا من حرفين إلى 80 حرفًا.'); return true; }
        d.name = value; flow.step = 'country'; this.save(session);
        await this.reply(id, `تم تسجيل الاسم: ${d.name}.\nحوار إضافة شخص (2/3)\nاكتب الدولة (مثل: عمان، السعودية، الإمارات، مصر) أو رمز الدولة مثل OM.`); return true;
      }
      if (flow.step === 'country') {
        let cc = countryCode(value);
        if (!cc && value.startsWith('+')) { d.rawPhone = value; d.country = 'OM'; flow.step = 'phone'; this.save(session); await this.finishAddRecipient(id, session, d.rawPhone); return true; }
        if (!cc) { await this.reply(id, 'لم أتعرف على الدولة. اكتب الاسم أو رمز ISO من حرفين، مثل OM أو SA، أو اكتب الرقم مع + ورمز الدولة مباشرة.'); return true; }
        d.country = cc; flow.step = 'phone'; this.save(session);
        await this.reply(id, 'حوار إضافة شخص (3/3)\nاكتب رقم الهاتف. يمكن أن تكتبه محليًا للدولة المحددة أو بصيغة دولية تبدأ بـ +.'); return true;
      }
      if (flow.step === 'phone') { await this.finishAddRecipient(id, session, value); return true; }
      if (flow.step === 'duplicate') {
        if (/^(?:استبدال|غير الاسم|تحديث الاسم|استبدل الاسم|1)$/u.test(p)) {
          const person = session.recipients.find(x => x.id === d.existingId);
          if (person) { person.name = d.name; Object.assign(person, d.parsed); person.whatsappSyncedAt = new Date().toISOString(); }
          assistant.flow = null; this.save(session); await this.reply(id, `تم تحديث جهة الرقم ${d.parsed.international} بالاسم «${d.name}».`); return true;
        }
        if (/^(?:احتفظ|الاسم الحالي|احتفاظ|2)$/u.test(p)) {
          const person = session.recipients.find(x => x.id === d.existingId);
          if (person) Object.assign(person, d.parsed);
          assistant.flow = null; this.save(session); await this.reply(id, 'تم الاحتفاظ بالاسم المحفوظ وتحديث الرقم المعياري فقط.'); return true;
        }
        await this.reply(id, 'اكتب «استبدال الاسم» أو «الاحتفاظ بالاسم» أو «إلغاء».'); return true;
      }
    }
    if (flow.type === 'send-message') {
      if (flow.step === 'target') {
        try { d.target = await this.resolveTarget(session, value); flow.step = 'text'; this.save(session); await this.reply(id, `المستلم: ${d.target.label}.\nحوار إرسال رسالة (2/3)\nاكتب نص الرسالة كاملًا.`); }
        catch (error) { await this.reply(id, `${error.message}\nحاول مرة أخرى أو اكتب «إلغاء».`); }
        return true;
      }
      if (flow.step === 'text') {
        if (!value || value.length > 60000) { await this.reply(id, 'اكتب رسالة من 1 إلى 60,000 حرف.'); return true; }
        d.message = value; flow.step = 'confirm'; this.save(session);
        await this.reply(id, `حوار إرسال رسالة (3/3)\nإلى: ${d.target.label}\nالنص:\n${value.slice(0, 1500)}${value.length > 1500 ? '\n… (سيتم إرسال النص كاملًا)' : ''}\n\nلم يُرسل شيء بعد. اكتب «تأكيد الإرسال» للتنفيذ أو «إلغاء».`); return true;
      }
      if (flow.step === 'confirm') {
        if (!isConfirm(value)) { await this.reply(id, 'لم يتم الإرسال. اكتب «تأكيد الإرسال» للتنفيذ أو «إلغاء» للتوقف.'); return true; }
        const target = d.target;
        if (!target?.chatId) { assistant.flow = null; this.save(session); await this.reply(id, 'أوقفت الإرسال لأن معرّف المستلم غير صالح.'); return true; }
        try {
          const result = await this.whatsapp.sendText(id, target.chatId, d.message);
          const latest = this.session(id); latest.ownerAssistant.flow = null; latest.ownerAssistant.recent.push({ at: new Date().toISOString(), type: 'send-message', target: target.label, chars: d.message.length }); this.save(latest);
          await this.reply(id, `تم تمرير طلب الإرسال إلى WhatsApp. الحالة: ${result?.__chatBotAck?.status || 'قبول الإرسال'}، المستلم: ${target.label}. راجع حالة الرسالة من WhatsApp إذا كنت تحتاج تأكيد وصولها.`);
        } catch (error) {
          // A transport failure can be uncertain: clear confirmation to avoid accidental duplicate sends.
          const latest = this.session(id); latest.ownerAssistant.flow = null; latest.ownerAssistant.recent.push({ at: new Date().toISOString(), type: 'send-message-failed', target: target.label, error: String(error?.message || error).slice(0, 300) }); this.save(latest);
          await this.reply(id, `تعذر تأكيد الإرسال: ${error.message}\nأوقفت المحاولة حتى لا تتكرر الرسالة عند عدم وضوح الحالة. تحقق من المحادثة في WhatsApp قبل إنشاء طلب جديد.`);
        }
        return true;
      }
    }
    if (flow.type === 'schedule') {
      if (flow.step === 'target') {
        try { d.target = await this.resolveTarget(session, value); flow.step = 'message'; this.save(session); await this.reply(id, `المستلم: ${d.target.label}.\nحوار الموعد (2/5)\nاكتب الرسالة التي ستُرسل في الموعد.`); }
        catch (error) { await this.reply(id, `${error.message}\nحاول مرة أخرى أو اكتب «إلغاء».`); }
        return true;
      }
      if (flow.step === 'message') {
        if (!value || value.length > 60000) { await this.reply(id, 'اكتب رسالة من 1 إلى 60,000 حرف.'); return true; }
        d.message = value; flow.step = 'mode'; this.save(session); await this.reply(id, 'حوار الموعد (3/5)\nاختر: مرة واحدة، يومي، أو أسبوعي.'); return true;
      }
      if (flow.step === 'mode') {
        if (/مرة|واحد|one/i.test(value)) d.mode = 'once'; else if (/يوم|daily/i.test(value)) d.mode = 'daily'; else if (/اسبوع|weekly/i.test(p)) d.mode = 'weekly'; else { await this.reply(id, 'اكتب «مرة واحدة» أو «يومي» أو «أسبوعي».'); return true; }
        flow.step = 'time'; this.save(session); await this.reply(id, 'حوار الموعد (4/5)\nاكتب الوقت بصيغة 24 ساعة، مثل 17:30.'); return true;
      }
      if (flow.step === 'time') {
        if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(value)) { await this.reply(id, 'الوقت غير صالح. استخدم HH:MM مثل 17:30.'); return true; }
        d.time = value;
        if (d.mode === 'once') { flow.step = 'date'; this.save(session); await this.reply(id, 'اكتب التاريخ بصيغة YYYY-MM-DD، مثل 2026-11-01.'); }
        else { d.date = ''; flow.step = 'confirm'; this.save(session); await this.showScheduleConfirmation(id, d); }
        return true;
      }
      if (flow.step === 'date') {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || Number.isNaN(Date.parse(`${value}T12:00:00Z`))) { await this.reply(id, 'التاريخ غير صالح. استخدم YYYY-MM-DD، أو «إلغاء».'); return true; }
        d.date = value; flow.step = 'confirm'; this.save(session); await this.showScheduleConfirmation(id, d); return true;
      }
      if (flow.step === 'confirm') {
        if (!isConfirm(value)) { await this.reply(id, 'لم أحفظ الموعد بعد. اكتب «تأكيد الحفظ» أو «إلغاء».'); return true; }
        if (!d.target?.key) { assistant.flow = null; this.save(session); await this.reply(id, 'لا يمكن إنشاء موعد تلقائي لهذا الهدف لأنه غير محفوظ في قائمة الأشخاص أو المجموعات. احفظ الهدف أولًا ثم أعد المحاولة.'); return true; }
        const task = this.store.normalizeAutomationTask({ id: crypto.randomUUID(), name: `موعد من محادثة WhatsApp - ${d.target.label}`.slice(0, 100), enabled: true, mode: d.mode, time: d.time, date: d.date || '', day: new Date().getDay(), dayOfMonth: 1, month: new Date().getMonth()+1, year: new Date().getFullYear(), targetKeys: [d.target.key], mediaIds: [], mediaMode: 'selected', preText: d.message, postText: '', scheduledGroupsEnabled: true, sendOrder: 'target-first' });
        session.automation.tasks.push(task); session.automation.enabled = true; assistant.flow = null; assistant.recent.push({ at: new Date().toISOString(), type: 'schedule-created', taskId: task.id }); this.save(session);
        await this.reply(id, `تم حفظ الموعد «${task.name}».\nالتكرار: ${task.mode}، الوقت: ${task.time}${task.date ? `، التاريخ: ${task.date}` : ''}.\nلم يتم الإرسال الآن؛ سينفّذ المجدول الموعد في وقته إذا ظلت الجلسة متصلة والأتمتة مفعّلة.`); return true;
      }
    }
    if (flow.type === 'auto-reply') {
      if (flow.step === 'trigger') {
        if (value.length < 2 || value.length > 500) { await this.reply(id, 'اكتب عبارة مطابقة من حرفين إلى 500 حرف.'); return true; }
        d.trigger = value; flow.step = 'reply'; this.save(session); await this.reply(id, `عبارة المطابقة: «${value}».\nحوار الرد التلقائي (2/3)\nاكتب الرد الذي سيرسله البوت. يمكنك استخدام {{sender}} و{{message}} و{{chat}} و{{time}}.`); return true;
      }
      if (flow.step === 'reply') {
        if (!value || value.length > 4000) { await this.reply(id, 'اكتب ردًا من 1 إلى 4,000 حرف.'); return true; }
        d.reply = value; flow.step = 'confirm'; this.save(session);
        await this.reply(id, `حوار الرد التلقائي (3/3)\nعند وصول رسالة تحتوي: «${d.trigger}»\nسيرد البوت: «${value.slice(0, 1200)}${value.length > 1200 ? '…' : ''}»\n\nاكتب «تأكيد الحفظ» لإضافة القاعدة أو «إلغاء».`); return true;
      }
      if (flow.step === 'confirm') {
        if (!isConfirm(value)) { await this.reply(id, 'اكتب «تأكيد الحفظ» أو «إلغاء».'); return true; }
        const rule = { id: crypto.randomUUID(), name: `قاعدة من WhatsApp: ${d.trigger.slice(0, 50)}`, enabled: true, priority: 10, when: { type: 'message', match: 'contains', value: d.trigger }, then: { reply: d.reply, replies: [d.reply], stopAfter: true }, scope: 'all', chatIds: [], cooldownSec: 45, commandPriority: false, conflictGroup: '' };
        session.interaction.rules.push(rule); session.interaction.rules = session.interaction.rules.slice(-500); assistant.flow = null; assistant.recent.push({ at: new Date().toISOString(), type: 'reply-rule-created', ruleId: rule.id }); this.save(session);
        await this.reply(id, `تم حفظ قاعدة الرد «${rule.name}». ستطابق الرسائل الواردة في المحادثات التي يسمح بها نطاق التفاعل. راجع صفحة «التفاعل» لتغيير النطاق أو إيقافها.`); return true;
      }
    }
    return false;
  }
  async finishAddRecipient(id, session, input) {
    const flow = session.ownerAssistant.flow, data = flow?.data || {};
    let parsed;
    try { parsed = this.phones.parse(input, data.country || 'OM'); }
    catch (error) { await this.reply(id, `رقم الهاتف غير صالح: ${error.message}\nاكتب الرقم مجددًا، أو «إلغاء».`); return; }
    const existing = session.recipients.find(x => String(x.digits || x.phone || '').replace(/\D/g, '') === parsed.digits || String(x.e164 || '') === parsed.e164);
    if (existing) {
      flow.step = 'duplicate'; Object.assign(data, { existingId: existing.id, parsed }); this.save(session);
      await this.reply(id, `هذا الرقم موجود بالفعل باسم «${existing.name}» (${parsed.international}).\nاكتب «استبدال الاسم» لتغييره إلى «${data.name}»، أو «الاحتفاظ بالاسم» للإبقاء على الاسم الحالي، أو «إلغاء».`); return;
    }
    const person = { id: crypto.randomUUID(), name: String(data.name || parsed.international).slice(0, 80), ...parsed, enabled: true };
    session.recipients.push(person); session.setupComplete = true; session.ownerAssistant.flow = null; session.ownerAssistant.recent.push({ at: new Date().toISOString(), type: 'recipient-added', recipientId: person.id }); this.save(session);
    await this.reply(id, `تمت إضافة «${person.name}» بنجاح.\nالرقم المحفوظ: ${parsed.international}\nيمكنك الآن كتابة «أرسل رسالة» لاختيار مستلم وإرسال رسالة بعد تأكيدك.`);
  }
  async showScheduleConfirmation(id, d) {
    await this.reply(id, `راجع الموعد قبل حفظه:\nالهدف: ${d.target.label}\nالرسالة: ${d.message.slice(0, 1000)}${d.message.length > 1000 ? '…' : ''}\nالتكرار: ${d.mode}\nالوقت: ${d.time}${d.date ? `\nالتاريخ: ${d.date}` : ''}\n\nاكتب «تأكيد الحفظ» لإنشاء الموعد، أو «إلغاء».`);
  }
}

module.exports = { OwnerAssistant, WELCOME_GUIDE, normalize, isCancel, isConfirm };
