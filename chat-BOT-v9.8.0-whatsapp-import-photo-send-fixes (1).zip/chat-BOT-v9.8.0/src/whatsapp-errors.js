'use strict';

/**
 * Translate common WhatsApp/Puppeteer failures into actionable, non-sensitive
 * messages. This does not bypass account, contact, group, or platform limits.
 */
function rawError(error) {
  return String(error?.message || error || 'خطأ غير معروف')
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/(?:[A-Za-z]:\\(?:[^\\\s]+\\)*[^\s,;]*)/g, '[مسار محلي]')
    .replace(/(?:\/[^\s,;]+){2,}/g, '[مسار محلي]')
    .replace(/https?:\/\/[^\s]+/gi, '[رابط خدمة]')
    .slice(0, 420);
}

function classifyWhatsAppError(error, action = 'الإرسال') {
  if (error?.originalError && typeof error.retryable === 'boolean' && error.code) {
    return { code: String(error.code), retryable: error.retryable, message: rawError(error), detail: '' };
  }
  const raw = rawError(error);
  const text = raw.toLowerCase();
  const suppliedCode = String(error?.code || '');
  const httpStatus = Number(error?.statusCode ?? error?.status ?? error?.response?.status ?? error?.originalError?.statusCode ?? 0);
  const normalizedCode = suppliedCode.toUpperCase();
  if (suppliedCode === 'SEND_UNCERTAIN' || /send_uncertain|لم نتأكد من نتيجة|لم يتم تأكيد النتيجة/.test(text)) {
    return { code: 'SEND_UNCERTAIN', retryable: false, message: `${action}: لم أستطع التحقق من النتيجة بشكل آمن. لم أكرر العملية حتى لا تصل الرسالة مرتين. افحص المحادثة المستهدفة قبل المحاولة مرة أخرى.`, detail: raw };
  }
  if (httpStatus === 401 || httpStatus === 403 || ['401','403','EACCES','EPERM','ERR_PERMISSION_DENIED','WHATSAPP_PERMISSION_DENIED'].includes(normalizedCode) || /permission denied|access denied|not authorized|unauthorized|forbidden|not allowed|not permitted|no permission|permission.*(?:denied|revoked|missing|not granted)|insufficient permission|only admins? can send|blocked by policy|recipient.*blocked|message not allowed|\b(?:http\s*)?(?:401|403)\b|صلاحيات? غير كافيه|صلاحيات? غير كافية|أذونات? غير كافية|ممنوع|غير مسموح|غير مصرح|تم رفض الوصول|لا تملك صلاحيه|ليس لديك صلاحية|لا تملك الإذن|الإذن مرفوض|رفض الوصول|action is not allowed/.test(text)) {
    return { code: 'WHATSAPP_PERMISSION_DENIED', retryable: false, message: `${action}: رفض WhatsApp العملية بسبب الصلاحيات أو قيود الحساب/المحادثة. تأكد من اتصال الحساب وصلاحية الإرسال إلى هذا الشخص أو المجموعة؛ لا يمكن للبرنامج تجاوز قيود WhatsApp.`, detail: raw };
  }
  if (httpStatus === 429 || normalizedCode === '429' || /rate.?limit|too many requests|\b429\b|slow down|throttl/.test(text)) {
    return { code: 'WHATSAPP_RATE_LIMIT', retryable: false, message: `${action}: يبدو أن WhatsApp حدّ من وتيرة الطلبات. أوقف المحاولات المتتابعة، وانتظر قليلًا ثم افحص حالة الجلسة قبل إعادة الإرسال.`, detail: raw };
  }
  if (/not registered|not on whatsapp|number.*(?:whatsapp|exist)|invalid wid|invalid jid|no lid for user|wid error|user not found|غير مسجل على واتساب|رقم.*غير صالح/.test(text)) {
    return { code: 'WHATSAPP_RECIPIENT_UNVERIFIED', retryable: false, message: `${action}: لم يتمكن WhatsApp من التحقق من المستلم. استدعِ جهات WhatsApp مجددًا واختر الاسم والرقم الظاهرين هناك، أو صحح رمز الدولة.`, detail: raw };
  }
  if (['AUTH_FAILURE','WHATSAPP_SESSION_NOT_READY'].includes(normalizedCode) || /session whatsapp.*not ready|not connected|disconnected|auth_failure|authentication failure|session is not ready|unauthenticated|logged out|session closed|جلسة واتساب ليست جاهزة|جلسة واتساب غير متصلة|جلسة whatsapp غير متصلة|واتساب غير متصل|الواتساب غير متصل|الجلسة غير متصلة|لم يتم تسجيل الدخول|امسح رمز qr|مسح رمز qr|تعذر الاتصال بواتساب/.test(text)) {
    return { code: 'WHATSAPP_SESSION_NOT_READY', retryable: false, message: `${action}: جلسة WhatsApp غير جاهزة. افتح صفحة «الجلسة»، وأكمل الاتصال أو امسح QR، ثم أعد الفحص قبل الإرسال.`, detail: raw };
  }
  if (suppliedCode === 'ENOENT' || /file.*not found|no such file or directory|الملف المحدد غير موجود/.test(text)) {
    return { code: 'MEDIA_FILE_MISSING', retryable: false, message: `${action}: الملف المطلوب غير موجود في مخزن الجلسة. ارفع الملف مجددًا وحدده من قائمة الوسائط.`, detail: raw };
  }
  if (/timeout|timed out|econnreset|econnrefused|eai_again|network|fetch failed|net::err_|protocol error|target closed|connection closed|socket hang up|temporary failure|temporarily unavailable/.test(text) || ['SEND_TIMEOUT', 'ETIMEDOUT', 'ECONNRESET', 'ECONNREFUSED', 'EAI_AGAIN', 'EPIPE', 'ECONNABORTED'].includes(suppliedCode)) {
    return { code: suppliedCode || 'WHATSAPP_TEMPORARY_CONNECTION', retryable: true, message: `${action}: تعذر إكمال الاتصال مؤقتًا. افحص اتصال الإنترنت وحالة WhatsApp. إذا كانت هذه محاولة إرسال، تحقق من سجل النتيجة قبل إعادة المحاولة لتجنب التكرار.`, detail: raw };
  }
  return { code: suppliedCode || 'WHATSAPP_OPERATION_FAILED', retryable: false, message: `${action}: تعذر إكمال العملية. راجع اتصال الجلسة والمستلم والملف المحدد.`, detail: raw };
}

function toUserFacingError(error, action = 'الإرسال') {
  if (error?.originalError && typeof error.retryable === 'boolean' && error.code) return error;
  const info = classifyWhatsAppError(error, action);
  const message = info.detail && info.detail !== info.message ? `${info.message}\nالتفاصيل: ${info.detail}` : info.message;
  return Object.assign(new Error(message), { code: info.code, retryable: info.retryable, originalError: error });
}

function isRetryableWhatsAppError(error) {
  return classifyWhatsAppError(error).retryable === true && error?.code !== 'SEND_UNCERTAIN';
}

module.exports = { rawError, classifyWhatsAppError, toUserFacingError, isRetryableWhatsAppError };
