'use strict';

const crypto = require('node:crypto');

function normalize(value) {
  return String(value || '').normalize('NFKC').toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[إأآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
    .replace(/[\u200e\u200f]/g, '').replace(/[،؛.!؟?]/g, ' ').replace(/\s+/g, ' ').trim();
}
function isConfirm(value) { return /^(?:تأكيد|تاكيد|نعم|موافق|نفذ|نفذ الان|تأكيد الارسال|تاكيد الارسال|تأكيد الحفظ|تاكيد الحفظ|تأكيد الحذف|تاكيد الحذف|تأكيد المزامنه|تاكيد المزامنه|موافقه|yes|confirm)$/u.test(normalize(value)); }
function isCancel(value) { return /^(?:الغاء|الغاء الامر|تراجع|وقف|الغاء الحوار|cancel|stop)$/u.test(normalize(value)); }
function parseFields(raw) {
  const parts = String(raw || '').split('|').map(x => x.trim()).filter(Boolean);
  const head = parts.shift() || '';
  const fields = {};
  let lastKey = '';
  for (const part of parts) {
    const match = part.match(/^([^=:\uFF1A]{1,40})\s*[:=\uFF1A]\s*([\s\S]*)$/u);
    if (match) {
      const key = normalize(match[1]).replace(/\s+/g, '');
      const value = String(match[2] || '').trim();
      const aliases = {
        'الى': 'targets', 'الي': 'targets', 'ل': 'targets', 'المستلم': 'targets', 'المستلمين': 'targets', 'الهدف': 'targets', 'الاهداف': 'targets', 'targets': 'targets', 'to': 'targets',
        'الرساله': 'message', 'الرسالهالنصيه': 'message', 'النص': 'message', 'الرسالة': 'message', 'message': 'message', 'text': 'message', 'الرد': 'reply', 'reply': 'reply',
        'ملف': 'files', 'الملف': 'files', 'ملفات': 'files', 'الملفات': 'files', 'وسائط': 'files', 'media': 'files', 'file': 'files', 'files': 'files',
        'النصبعد': 'postText', 'رسالهبعدالملف': 'postText', 'النصبعد': 'postText', 'posttext': 'postText',
        'الاسم': 'name', 'اسم': 'name', 'name': 'name', 'الدوله': 'country', 'الدولة': 'country', 'country': 'country', 'رقم': 'phone', 'الرقم': 'phone', 'رقمالهاتف': 'phone', 'الهاتف': 'phone', 'phone': 'phone', 'التكرار': 'mode', 'mode': 'mode', 'repeat': 'mode',
        'التاريخ': 'date', 'date': 'date', 'الوقت': 'time', 'time': 'time', 'اليوم': 'day', 'day': 'day', 'يومالشهر': 'dayOfMonth', 'dayofmonth': 'dayOfMonth', 'الشهر': 'month', 'month': 'month', 'السنه': 'year', 'year': 'year',
        'المطابقه': 'match', 'match': 'match', 'عندما': 'when', 'اذا': 'when', 'trigger': 'when', 'when': 'when', 'النطاق': 'scope', 'scope': 'scope', 'priority': 'priority', 'الاولويه': 'priority',
        'تاكيد': 'confirm', 'confirm': 'confirm', 'التاكيد': 'confirm', 'المنطقه': 'timezone', 'المنطقهالزمنيه': 'timezone', 'timezone': 'timezone',
        'الترتيب': 'sendOrder', 'sendorder': 'sendOrder', 'وضعالنص': 'textMode', 'textmode': 'textMode', 'معرف': 'gid', 'gid': 'gid', 'رابط': 'url', 'الرابط': 'url', 'invite': 'url'
      };
      lastKey = aliases[key] || key;
      if (Object.prototype.hasOwnProperty.call(fields, lastKey) && ['targets','files'].includes(lastKey)) fields[lastKey] = `${fields[lastKey]}, ${value}`;
      else fields[lastKey] = value;
    } else if (lastKey === 'message' || lastKey === 'postText' || lastKey === 'reply') {
      fields[lastKey] = `${fields[lastKey]} | ${part}`;
    }
  }
  return { head, fields };
}
function splitList(value) { return [...new Set(String(value || '').split(/[،,;\n]+/).map(x => x.trim()).filter(Boolean))]; }
function unique(values) { return [...new Set(values)]; }

class LocalCommandBridge {
  constructor({ store, whatsapp, delivery, phones, log, saveGroup, normalizeAutomationPayload }) {
    this.store = store; this.whatsapp = whatsapp; this.delivery = delivery; this.phones = phones; this.log = log || (() => {});
    this.saveGroup = saveGroup; this.normalizeAutomationPayload = normalizeAutomationPayload;
  }
  session(id) { return this.store.loadSession(id); }
  save(s) { return this.store.saveSession(s); }
  result(response, extra = {}) { return { handled: true, response: String(response || ''), ...extra }; }
  setPending(s, pending) { s.commandBridge ||= {}; s.commandBridge.pending = pending; this.save(s); }
  clearPending(s) { s.commandBridge ||= {}; s.commandBridge.pending = null; this.save(s); }
  help(topic = '') {
    const base = `الأوامر المباشرة المتاحة في محادثة «الرسائل إلى نفسك»:
• أرسل الآن | إلى=أحمد | الرسالة=مرحبًا | ملف=img.1.jpg
• أضف موعد | الاسم=تذكير | التكرار=مرة | التاريخ=2026-11-01 | الوقت=17:30 | إلى=أحمد | الرسالة=النص
• أضف قاعدة تفاعل | الاسم=ترحيب | عندما=السلام عليكم | المطابقة=يحتوي | الرد=وعليكم السلام {{sender}}
• اعرض الأشخاص / اعرض المجموعات / اعرض المواعيد / اعرض قواعد التفاعل / اعرض الوسائط
• اكتشف المجموعات / معلومات المجموعة | GID=120…@g.us
• فعّل التفاعل / أوقف التفاعل / فعّل الأتمتة / أوقف الأتمتة
• اضبط المنطقة الزمنية | المنطقة=Asia/Muscat
الأوامر التي ترسل أو تنشئ/تحذف شيئًا تنتظر تأكيدًا واضحًا. اكتب «إلغاء» لإلغاء الأمر المعلّق. الأسماء المحلية لا تُستبدل عند مزامنة WhatsApp إلا بطلب صريح.`;
    const p = normalize(topic);
    if (/ارسال|رساله|وسائط|ملفات/u.test(p)) return `الإرسال:
• أرسل الآن | إلى=أحمد | الرسالة=صباح الخير
• أرسل الآن | إلى=أحمد | ملف=report.pdf | الرسالة=أرفقت الملف
• إلى يمكن أن يكون اسمًا محفوظًا، رقمًا دوليًا مؤكّدًا، GID مجموعة، أو «الكل».
• يجب أن يكون الملف مرفوعًا مسبقًا في صفحة الإرسال. يعرض البوت ملخصًا قبل الإرسال؛ أكّد بـ «تأكيد الإرسال».
• راجع نتيجة النجاح والفشل لكل مستلم ولا تكرر الطلب إذا كانت نتيجة الإرسال غير مؤكدة.`;
    if (/موعد|جدول|اتمته/u.test(p)) return `المواعيد:
• أضف موعد | الاسم=تذكير | التكرار=أسبوعي | الوقت=17:30 | اليوم=الخميس | إلى=أحمد | الرسالة=النص
• للموعد لمرة واحدة أضف التاريخ=YYYY-MM-DD والتكرار=مرة.
• اعرض المواعيد، فعّل الموعد الاسم، أوقف الموعد الاسم، احذف الموعد الاسم.
• حذف الموعد أو تشغيله الآن يحتاج تأكيدًا. يحتاج التشغيل التلقائي بقاء الجهاز والخادم والجلسة متصلة.`;
    if (/تفاعل|رد|قاعده/u.test(p)) return `قواعد التفاعل:
• أضف قاعدة تفاعل | الاسم=ترحيب | عندما=السلام عليكم | المطابقة=يحتوي | الرد=وعليكم السلام {{sender}}
• اعرض قواعد التفاعل، فعّل قاعدة التفاعل ترحيب، أوقف قاعدة التفاعل ترحيب، احذف قاعدة التفاعل ترحيب.
• المتغيرات المدعومة تشمل {{sender}} و{{message}} و{{chat}} و{{time}}. تحقق من النطاق وفاصل التكرار قبل التشغيل.`;
    if (/مجموعه|جروب|group/u.test(p)) return `المجموعات:
• اكتشف المجموعات — استدعاء المجموعات الموجودة في جلسة WhatsApp وإضافتها للمشروع (بطلب صريح فقط).
• معلومات المجموعة | GID=120363…@g.us
• حلل رابط دعوة | رابط=https://chat.whatsapp.com/…
• لا تُضاف أي مجموعة إلى المشروع لمجرد وصول رسالة عادية منها.`;
    if (/شخص|جهات|واتساب|مزامنه|مزامنة/u.test(p)) return `جهات WhatsApp:
• استدعاء جهات واتساب — معاينة الجهات ثم «تأكيد المزامنة».
• مزامن ملفات WhatsApp | إلى=أحمد، سارة — تحديث الاسم الحالي في WhatsApp والصور مع الاحتفاظ بأسمائك المحلية.
• الاسم الظاهر في WhatsApp وصورة الملف الشخصي يُحفظان منفصلين عن الاسم المخصص داخل المشروع.
• يدعم النظام الأرقام المؤكدة فقط؛ لا يخمّن رقمًا من LID غير مرتبط برقم معروف.`;
    return base;
  }
  async handle(id, raw) {
    const text = String(raw || '').trim();
    if (!text || text.length > 60000) return { handled: false };
    let s = this.session(id); s.commandBridge ||= { pending: null };
    const pending = s.commandBridge.pending;
    if (pending) {
      if (Date.now() - Number(pending.createdAt || 0) > 10 * 60 * 1000) {
        s.commandBridge.pending = null; this.save(s);
        return this.result('انتهت صلاحية الأمر المعلّق بعد 10 دقائق؛ لم أنفّذه. أعد كتابة الأمر لمراجعته من جديد.');
      }
      if (isCancel(text)) { s.commandBridge.pending = null; this.save(s); return this.result('تم إلغاء الأمر المعلّق. لم يُنفّذ أي إرسال أو حذف.'); }
      if (!isConfirm(text)) return this.result(`لديك أمر معلّق: ${pending.label || pending.type}. لم أنفّذه بعد.
اكتب «تأكيد الإرسال» أو «تأكيد الحفظ» للمتابعة، أو «إلغاء» للتراجع.`);
      s.commandBridge.pending = null; this.save(s);
      try { return this.result(await this.executePending(id, pending)); }
      catch (error) { this.log(id, 'ERROR', `فشل أمر محادثة مباشر: ${error.message || error}`); return this.result(`تعذّر تنفيذ الأمر: ${String(error.message || error)}\nلم أطلب إعادة محاولة تلقائية؛ راجع الحالة أولًا لتجنب التكرار.`); }
    }

    const p = normalize(text);
    const helpMatch = p.match(/^(?:مساعدة|دليل)(?:\s+(.+))?$/u);
    if (helpMatch && helpMatch[1]) return this.result(this.help(helpMatch[1]));

    const parsed = parseFields(text), head = normalize(parsed.head), f = parsed.fields;
    if (text.includes('|') && /^(?:اضف شخص|اضف مستخدم|اضف جهه اتصال|add recipient)$/u.test(head)) return this.stageAddRecipient(id, s, f);
    if (text.includes('|') && /^(?:ارسل الان|ارسال الان|send now|add send)$/u.test(head)) return this.stageSend(id, s, f);
    if (text.includes('|') && /^(?:اضف موعد|انشئ موعد|انشاء موعد|add schedule)$/u.test(head)) return this.stageSchedule(id, s, f);
    if (text.includes('|') && /^(?:اضف قاعده تفاعل|انشئ رد تلقائي|اضف رد تلقائي|add interaction rule)$/u.test(head)) return this.stageInteractionRule(id, s, f);
    if (text.includes('|') && /^(?:معلومات المجموعه|حلل معلومات المجموعه|group info)$/u.test(head)) return this.groupInfo(id, f.gid || f.targets || f.name);
    if (text.includes('|') && /^(?:حلل رابط دعوه|حلل دعوه|analyze invite)$/u.test(head)) return this.analyzeInvite(id, f.url || f.gid || f.targets);
    if (text.includes('|') && /^(?:مزامن ملفات واتساب|مزامن ملفات whatsapp|مزامنة ملفات واتساب|مزامنة ملفات whatsapp|زامن ملفات واتساب|زامن ملف واتساب|sync whatsapp contacts)$/u.test(head)) return this.stageSyncWhatsappContacts(id, s, f.targets || f.name || '');
    if (text.includes('|') && /^(?:اضبط المنطقه الزمنيه|اضبط المنطقه|set timezone)$/u.test(head)) return this.setTimezone(id, f.timezone || f.name);
    const editTaskHead = parsed.head.match(/^(?:عدّل|عدل)\s+الموعد\s+(.+)$/u);
    if (text.includes('|') && editTaskHead) return this.stageEditTask(id, s, editTaskHead[1].trim(), f);
    const editRuleHead = parsed.head.match(/^(?:عدّل|عدل)\s+قاعده التفاعل\s+(.+)$/u);
    if (text.includes('|') && editRuleHead) return this.stageEditRule(id, s, editRuleHead[1].trim(), f);
    if (text.includes('|')) return { handled: false };

    if (/^(?:مساعدة الارسال|دليل الارسال)$/u.test(p)) return this.result(this.help('الإرسال'));
    if (/^(?:مساعدة المواعيد|دليل المواعيد|مساعدة الجدوله)$/u.test(p)) return this.result(this.help('المواعيد'));
    if (/^(?:مساعدة التفاعل|دليل التفاعل)$/u.test(p)) return this.result(this.help('التفاعل'));
    if (/^(?:مساعدة المجموعات|دليل المجموعات)$/u.test(p)) return this.result(this.help('المجموعات'));
    if (/^(?:مساعدة جهات واتساب|دليل جهات واتساب)$/u.test(p)) return this.result(this.help('جهات WhatsApp'));
    if (/^(?:اعرض الاشخاص|قائمة الاشخاص|الاشخاص|قائمة جهات الاتصال|اعرض جهات الاتصال)$/u.test(p)) return this.listPeople(id);
    if (/^(?:اعرض المجموعات|قائمة المجموعات|المجموعات)$/u.test(p)) return this.listGroups(id);
    if (/^(?:اعرض المواعيد|قائمة المواعيد|المواعيد)$/u.test(p)) return this.listTasks(id);
    if (/^(?:اعرض قواعد التفاعل|قائمة قواعد التفاعل|قواعد التفاعل)$/u.test(p)) return this.listInteractionRules(id);
    if (/^(?:اعرض ملفات|اعرض الوسائط|قائمة الوسائط|ملفات الوسائط)$/u.test(p)) return this.listMedia(id);
    if (/^(?:اكتشف المجموعات|استدعاء المجموعات|زامن المجموعات|اكتشاف المجموعات)$/u.test(p)) return this.discoverGroups(id);
    if (/^(?:فعّل التفاعل|فعل التفاعل|شغل التفاعل|أوقف التفاعل|اوقف التفاعل|عطل التفاعل|فعّل الأتمتة|فعل الاتمته|أوقف الأتمتة|اوقف الاتمته)$/u.test(p)) return this.toggleSystem(id, p);

    const recipientDelete = text.match(/^(?:احذف|حذف)\s+(?:الشخص|جهة الاتصال|المستلم)\s+(.+)$/u);
    if (recipientDelete) return this.stageDeleteRecipient(id, recipientDelete[1].trim());
    const groupDelete = text.match(/^(?:احذف|حذف)\s+(?:المجموعه|المجموعة|الجروب)\s+(.+)$/u);
    if (groupDelete) return this.stageDeleteGroup(id, groupDelete[1].trim());
    const groupToggle = text.match(/^(فعّل|فعل|شغّل|شغل|أوقف|اوقف)\s+(?:المجموعه|المجموعة|الجروب)\s+(.+)$/u);
    if (groupToggle) return this.toggleGroup(id, normalize(groupToggle[1]), groupToggle[2].trim());
    let taskCommand = text.match(/^(شغّل الموعد الآن|شغل الموعد الآن|شغل الموعد الان|شغّل الموعد الان|فعّل الموعد|فعل الموعد|أوقف الموعد|اوقف الموعد|عطّل الموعد|عطل الموعد|احذف الموعد|حذف الموعد|شغّل|شغل|فعّل|فعل|أوقف|اوقف|عطّل|عطل|احذف|حذف)\s+(.+)$/u);
    if (taskCommand) {
      const actionText = normalize(taskCommand[1]);
      const rawName = taskCommand[2].replace(/^(?:الموعد\s+)/u, '').trim();
      if (/موعد|الان/u.test(actionText)) {
        const destructive = /^(?:احذف|حذف)/u.test(actionText);
        const runNow = /(?:الان|الآن)/u.test(actionText);
        const verb = actionText.startsWith('فعّل') || actionText.startsWith('فعل') || actionText.startsWith('شغل') ? 'شغّل' : actionText.startsWith('أوقف') || actionText.startsWith('اوقف') || actionText.startsWith('عطل') ? 'أوقف' : actionText.split(' ')[0];
        return this.taskAction(id, verb, rawName, destructive, runNow);
      }
    }
    const ruleCommand = text.match(/^(?:فعّل|فعل|شغّل|شغل|أوقف|اوقف|عطّل|عطل|احذف|حذف)\s+قاعدة التفاعل\s+(.+)$/u);
    if (ruleCommand) return this.ruleAction(id, normalize(text.split(/\s+/)[0]), ruleCommand[1].trim());
    if (/^(?:اضبط|غيّر|غير)\s+(?:المنطقه الزمنيه|المنطقه)/u.test(p)) return this.result('لتحديد المنطقة الزمنية استخدم: اضبط المنطقة الزمنية | المنطقة=Asia/Muscat');

    return { handled: false };
  }
  savePending(s, pending) {
    s.commandBridge ||= {}; s.commandBridge.pending = { ...pending, createdAt: Date.now() }; this.save(s);
    return this.result(`${pending.preview}\n\nلم يُنفّذ الأمر بعد. ${pending.confirmPrompt || 'اكتب «تأكيد الحفظ» للمتابعة أو «إلغاء» للتراجع.'}`);
  }
  async resolveTargets(s, raw) {
    const targets = splitList(raw);
    if (!targets.length) throw new Error('حدد هدفًا في الحقل إلى=، واستخدم اسمًا محفوظًا أو رقمًا دوليًا صالحًا.');
    const recipientKeys = [], groupKeys = [], directTargets = [], labels = [];
    for (const targetText of targets) {
      const q = normalize(targetText);
      if (/^(?:الكل|الجميع|كل الاشخاص والمجموعات)$/u.test(q)) {
        recipientKeys.push(...s.recipients.filter(x => x.enabled !== false).map(x => `r:${x.id}`));
        groupKeys.push(...s.groups.filter(x => x.enabled !== false).map(x => `g:${x.id}`));
        labels.push('كل الجهات المفعّلة'); continue;
      }
      const entries = [
        ...s.recipients.filter(x => x.enabled !== false).map(x => ({ kind: 'recipient', key: `r:${x.id}`, label: x.name || x.international || x.phone, source: x })),
        ...s.groups.filter(x => x.enabled !== false).map(x => ({ kind: 'group', key: `g:${x.id}`, label: x.name || x.gid, source: x })),
      ];
      const exact = entries.filter(x => normalize(x.label) === q || normalize(x.source.gid) === q || normalize(x.source.whatsappJid) === q || String(x.source.id) === targetText.trim());
      const found = exact.length ? exact : entries.filter(x => normalize(x.label).includes(q) || normalize(x.source.gid).includes(q));
      if (found.length === 1) {
        const match = found[0]; (match.kind === 'group' ? groupKeys : recipientKeys).push(match.key); labels.push(match.label); continue;
      }
      if (found.length > 1) throw new Error(`الهدف «${targetText}» يطابق أكثر من جهة: ${found.slice(0, 6).map(x => x.label).join('، ')}. اكتب الاسم الكامل.`);
      if (/^\d+(?:-\d+)*@g\.us$/i.test(targetText.trim())) {
        const group = s.groups.find(x => x.gid.toLowerCase() === targetText.trim().toLowerCase());
        if (!group) throw new Error('هذه المجموعة غير محفوظة. استخدم «معلومات المجموعة | GID=...@g.us» لحفظها أولًا.');
        groupKeys.push(`g:${group.id}`); labels.push(group.name || group.gid); continue;
      }
      let parsed;
      try { parsed = this.phones.parse(targetText, 'OM'); }
      catch { throw new Error(`لم أعثر على «${targetText}». احفظ الاسم من استدعاء WhatsApp أو أدخل رقمًا دوليًا مؤكدًا.`); }
      const jid = await this.whatsapp.resolveChatId(s.id, { e164: parsed.e164, digits: parsed.digits, phone: parsed.digits, name: parsed.international });
      directTargets.push({ chatId: jid, label: parsed.international, phone: parsed.digits }); labels.push(parsed.international);
    }
    return { targetKeys: unique([...recipientKeys, ...groupKeys]), directTargets, labels: unique(labels) };
  }
  stageAddRecipient(id, s, f) {
    const name = String(f.name || '').trim();
    const rawPhone = String(f.phone || '').trim();
    if (name.length < 2 || name.length > 80) throw new Error('اكتب الاسم من حرفين إلى 80 حرفًا.');
    if (!rawPhone) throw new Error('أدخل الرقم في الحقل الرقم= أو الهاتف=.');
    let parsed;
    try { parsed = this.phones.parse(rawPhone, String(f.country || 'OM').trim().toUpperCase()); }
    catch (error) { throw new Error(`رقم الهاتف غير صالح: ${error.message || error}`); }
    const digits = String(parsed.digits || parsed.phone || '').replace(/\D/g, '');
    if (!digits) throw new Error('لم ينتج عن التحقق رقم دولي صالح.');
    if (s.recipients.some(x => String(x.digits || x.phone || x.e164 || '').replace(/\D/g, '') === digits)) throw new Error('هذا الرقم موجود بالفعل في الجلسة؛ لم أضف سجلًا مكررًا.');
    const recipient = { id: crypto.randomUUID(), name, ...parsed, digits, phone: digits, enabled: true, source: 'owner-command', createdAt: new Date().toISOString() };
    return this.savePending(s, { type: 'create-recipient', label: `إضافة الشخص ${name}`, payload: { recipient }, preview: `مراجعة إضافة شخص:\nالاسم: ${name}\nالرقم الدولي: ${parsed.international || parsed.e164 || digits}\nلن يتم حذف أو تعديل أي جهة موجودة.`, confirmPrompt: 'اكتب «تأكيد الحفظ» لإضافة الشخص أو «إلغاء». لم تُحفظ الجهة بعد.' });
  }
  async stageSend(id, s, f) {
    const targets = await this.resolveTargets(s, f.targets || '');
    const mediaValues = splitList(f.files || '');
    const files = this.delivery.files(id);
    const picked = mediaValues.map(value => {
      const q = normalize(value), found = files.filter(file => file.id === value || file.filename === value || normalize(file.filename) === q || file.filename.toLowerCase().includes(value.toLowerCase()));
      if (found.length !== 1) throw new Error(found.length ? `اسم الملف «${value}» غير فريد؛ اكتب اسم الملف كاملًا.` : `الملف «${value}» غير موجود. ارفعه أولًا من صفحة الإرسال ثم اكتب «اعرض الوسائط».`);
      return found[0];
    });
    const message = String(f.message || '').trim(), postText = String(f.postText || '').trim();
    if (!picked.length && !message && !postText) throw new Error('أضف الرسالة= أو ملف= قبل الإرسال.');
    if (message.length > 60000 || postText.length > 60000) throw new Error('حد الرسالة 60,000 حرف. قسّم النص إلى رسائل أصغر.');
    const payload = { targetKeys: targets.targetKeys, directTargets: targets.directTargets, labels: targets.labels, mediaIds: picked.map(x => x.id), mediaFiles: picked.map(x => ({ id: x.id, filename: x.filename, isImage: x.isImage })), message, postText, sendOrder: normalize(f.sendOrder) === 'الصوره اولا' || normalize(f.sendOrder) === 'image first' ? 'image-first' : 'target-first' };
    return this.savePending(s, { type: 'send', label: 'إرسال نص/وسائط', payload, preview: `مراجعة الإرسال:
إلى: ${targets.labels.join('، ')}
النص: ${message ? message.slice(0, 1000) + (message.length > 1000 ? '… (سيُرسل كاملًا)' : '') : 'لا يوجد'}
الملفات: ${picked.length ? picked.map(x => `${x.filename} (${x.isImage ? 'صورة' : 'ملف'})`).join('، ') : 'لا يوجد'}
ترتيب الإرسال: ${payload.sendOrder === 'image-first' ? 'الملف ثم النص' : 'النص ثم الملف'}
${targets.labels.some(x => /كل الجهات/.test(x)) ? 'تحذير: سيستهدف هذا الأمر جميع الأشخاص والمجموعات المفعّلة.' : ''}`, confirmPrompt: 'اكتب «تأكيد الإرسال» للتنفيذ أو «إلغاء».' });
  }
  async executeSend(id, payload) {
    const outcomes = [];
    if (payload.targetKeys?.length) {
      const r = await this.delivery.sendNow(id, { targetKeys: payload.targetKeys, mediaIds: payload.mediaIds, preText: payload.message, postText: payload.postText, sendOrder: payload.sendOrder, repeatGuard: true });
      outcomes.push(...(r.sent || []).map(x => ({ ok: true, label: x.target, file: x.image || '' })), ...(r.failed || []).map(x => ({ ok: false, label: x.target, error: x.error })));
    }
    for (const target of payload.directTargets || []) {
      try {
        if (payload.sendOrder !== 'image-first' && payload.message) await this.whatsapp.sendText(id, target.chatId, payload.message);
        for (const file of payload.mediaFiles || []) {
          const fullPath = require('node:path').join(this.store.getPaths(id).media, file.filename);
          await this.whatsapp.sendMedia(id, target.chatId, fullPath, { asDocument: !file.isImage });
        }
        if (payload.sendOrder === 'image-first' && payload.message) await this.whatsapp.sendText(id, target.chatId, payload.message);
        if (payload.postText) await this.whatsapp.sendText(id, target.chatId, payload.postText);
        outcomes.push({ ok: true, label: target.label });
      } catch (error) { outcomes.push({ ok: false, label: target.label, error: String(error.message || error) }); }
    }
    const success = outcomes.filter(x => x.ok), failures = outcomes.filter(x => !x.ok);
    return `انتهت محاولة الإرسال.
نجح: ${success.length}
فشل/تم منعه: ${failures.length}${success.length ? `

نجح الإرسال إلى:
${success.slice(0, 30).map(x => `• ${x.label}${x.file ? ` — ${x.file}` : ''}`).join('\n')}` : ''}${failures.length ? `

راجع هذه النتائج قبل إعادة المحاولة:
${failures.slice(0, 30).map(x => `• ${x.label}: ${x.error}`).join('\n')}` : ''}

تنبيه: قبول WhatsApp للطلب لا يضمن قراءة الرسالة من المستلم. إذا كانت النتيجة غير مؤكدة، تحقق من WhatsApp قبل الإرسال مجددًا.`;
  }
  async stageSchedule(id, s, f) {
    const targetInfo = await this.resolveTargets(s, f.targets || '');
    if (targetInfo.directTargets.length) throw new Error('الموعد يحتاج أشخاصًا أو مجموعات محفوظة بالمشروع. استدعِ الرقم واحفظه أولًا.');
    if (!targetInfo.targetKeys.length) throw new Error('حدد هدفًا محفوظًا للموعد.');
    const modeIn = normalize(f.mode || 'weekly');
    const mode = /^(?:مره|مرهواحده|once|one time)$/.test(modeIn) ? 'once' : /يومي|daily/.test(modeIn) ? 'daily' : /اسبوع|weekly/.test(modeIn) ? 'weekly' : /شهري|monthly/.test(modeIn) ? 'monthly' : /سنوي|yearly/.test(modeIn) ? 'yearly' : modeIn;
    if (!['once','daily','weekly','monthly','yearly'].includes(mode)) throw new Error('التكرار غير معروف. استخدم مرة أو يومي أو أسبوعي أو شهري أو سنوي.');
    const time = String(f.time || '').trim();
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) throw new Error('أدخل الوقت بصيغة 24 ساعة مثل 17:30.');
    const date = String(f.date || '').trim();
    if (mode === 'once' && (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(Date.parse(`${date}T12:00:00Z`)))) throw new Error('للموعد مرة واحدة، أدخل تاريخًا صالحًا بصيغة YYYY-MM-DD.');
    const mediaValues = splitList(f.files || ''), available = this.delivery.files(id);
    const picked = mediaValues.map(value => {
      const found = available.filter(x => x.id === value || x.filename === value || normalize(x.filename) === normalize(value));
      if (found.length !== 1) throw new Error(`تعذر تحديد الملف «${value}». استخدم اسم ملف فريدًا من «اعرض الوسائط».`);
      return found[0];
    });
    const message = String(f.message || '').trim();
    if (!message && !picked.length) throw new Error('الموعد يحتاج الرسالة= أو ملفًا واحدًا على الأقل.');
    const raw = { id: crypto.randomUUID(), name: String(f.name || 'موعد من محادثة WhatsApp').slice(0, 100), enabled: true, mode, time, date: mode === 'once' ? date : '', day: this.weekday(f.day), dayOfMonth: Number(f.dayOfMonth || 1), month: Number(f.month || new Date().getMonth() + 1), year: Number(f.year || new Date().getFullYear()), targetKeys: targetInfo.targetKeys, mediaIds: picked.map(x => x.id), mediaMode: 'selected', preText: message, postText: String(f.postText || ''), sendOrder: /image|صوره.*اولا/u.test(normalize(f.sendOrder || '')) ? 'image-first' : 'target-first', scheduledGroupsEnabled: true };
    if (typeof this.normalizeAutomationPayload === 'function') this.normalizeAutomationPayload(id, raw, null);
    return this.savePending(s, { type: 'create-task', label: `حفظ الموعد ${raw.name}`, payload: raw, preview: `مراجعة الموعد قبل الحفظ:
الاسم: ${raw.name}
الهدف: ${targetInfo.labels.join('، ')}
التكرار: ${mode}، الوقت: ${time}${raw.date ? `، التاريخ: ${raw.date}` : ''}
الرسالة: ${message ? message.slice(0, 800) + (message.length > 800 ? '…' : '') : 'لا توجد رسالة'}
الملفات: ${picked.map(x => x.filename).join('، ') || 'لا يوجد'}`, confirmPrompt: 'اكتب «تأكيد الحفظ» لحفظ الموعد أو «إلغاء». في حالة الموعد المتكرر سيتم التنفيذ ما دامت الجلسة والخادم يعملان.' });
  }
  async stageEditTask(id, s, query, f) {
    const q = normalize(query), found = (s.automation.tasks || []).filter(t => normalize(t.name) === q || normalize(t.name).includes(q));
    if (found.length !== 1) throw new Error(found.length ? `اسم الموعد يطابق أكثر من عنصر: ${found.map(x => x.name).join('، ')}.` : `لم أجد موعدًا باسم «${query}». استخدم «اعرض المواعيد».`);
    const task = found[0], updates = {};
    if (f.name) updates.name = String(f.name).slice(0, 100);
    if (f.time) updates.time = String(f.time).trim();
    if (f.mode) {
      const v = normalize(f.mode);
      updates.mode = /^(?:مره|مرهواحده|once)$/.test(v) ? 'once' : /يومي|daily/.test(v) ? 'daily' : /اسبوع|weekly/.test(v) ? 'weekly' : /شهري|monthly/.test(v) ? 'monthly' : /سنوي|yearly/.test(v) ? 'yearly' : v;
    }
    if (f.date !== undefined) updates.date = String(f.date).trim();
    if (f.message !== undefined) updates.preText = String(f.message).trim();
    if (f.postText !== undefined) updates.postText = String(f.postText).trim();
    if (f.day !== undefined) updates.day = this.weekday(f.day);
    if (f.dayOfMonth !== undefined) updates.dayOfMonth = Number(f.dayOfMonth);
    if (f.month !== undefined) updates.month = Number(f.month);
    if (f.year !== undefined) updates.year = Number(f.year);
    if (f.files !== undefined) {
      const files = this.delivery.files(id), values = splitList(f.files);
      updates.mediaIds = values.map(value => {
        const hit = files.filter(x => x.id === value || x.filename === value || normalize(x.filename) === normalize(value));
        if (hit.length !== 1) throw new Error(`تعذر تحديد الملف «${value}».`);
        return hit[0].id;
      });
    }
    if (f.targets !== undefined) {
      const targets = await this.resolveTargets(s, f.targets);
      if (targets.directTargets.length || !targets.targetKeys.length) throw new Error('تعديلات الموعد تستخدم أهدافًا محفوظة داخل المشروع فقط.');
      updates.targetKeys = targets.targetKeys;
    }
    if (!Object.keys(updates).length) throw new Error('اكتب حقلًا واحدًا على الأقل مثل الوقت=18:00 أو الرسالة=النص.');
    const preview = { ...task, ...updates, id: task.id };
    if (typeof this.normalizeAutomationPayload === 'function') this.normalizeAutomationPayload(id, preview, task);
    return this.savePending(s, { type: 'update-task', label: `تعديل الموعد ${task.name}`, payload: { id: task.id, updates }, preview: `مراجعة تعديل الموعد «${task.name}»:
${Object.entries(updates).map(([key, value]) => `• ${key}: ${Array.isArray(value) ? value.join('، ') : value}`).join('\n')}`, confirmPrompt: 'اكتب «تأكيد الحفظ» لتطبيق التعديل أو «إلغاء». لم يتم تغيير الموعد بعد.' });
  }
  async stageEditRule(id, s, query, f) {
    const q = normalize(query), found = (s.interaction.rules || []).filter(rule => normalize(rule.name) === q || normalize(rule.name).includes(q));
    if (found.length !== 1) throw new Error(found.length ? `اسم القاعدة يطابق أكثر من عنصر: ${found.map(x => x.name).join('، ')}.` : `لم أجد قاعدة باسم «${query}». استخدم «اعرض قواعد التفاعل».`);
    const rule = found[0], updates = {};
    if (f.name) updates.name = String(f.name).slice(0, 100);
    if (f.when !== undefined) updates.when = { ...(rule.when || {}), value: String(f.when).trim() };
    if (f.match !== undefined) {
      const v = normalize(f.match); const match = /exact|تمام|يطابق/u.test(v) ? 'exact' : /يبدأ|starts/u.test(v) ? 'starts' : /ينتهي|ends/u.test(v) ? 'ends' : /any|اي رساله/u.test(v) ? 'any' : 'contains';
      updates.when = { ...(updates.when || rule.when || {}), match };
    }
    if (f.reply !== undefined) updates.then = { ...(rule.then || {}), reply: String(f.reply).trim(), replies: [String(f.reply).trim()] };
    if (f.scope !== undefined) updates.scope = ['all','private','groups','selected'].includes(normalize(f.scope)) ? normalize(f.scope) : 'all';
    if (!Object.keys(updates).length) throw new Error('اكتب حقلًا مثل الرد=، عندما=، المطابقة=، أو النطاق=.');
    const preview = { ...rule, ...updates, id: rule.id };
    return this.savePending(s, { type: 'update-rule', label: `تعديل قاعدة التفاعل ${rule.name}`, payload: { id: rule.id, updates }, preview: `مراجعة تعديل قاعدة «${rule.name}»:
${updates.when ? `• المطابقة: ${updates.when.match} «${updates.when.value}»
` : ''}${updates.then ? `• الرد: ${updates.then.reply}
` : ''}${updates.name ? `• الاسم: ${updates.name}
` : ''}${updates.scope ? `• النطاق: ${updates.scope}` : ''}`, confirmPrompt: 'اكتب «تأكيد الحفظ» لتطبيق التعديل أو «إلغاء». لم يتم تغيير القاعدة بعد.' });
  }
  stageDeleteRecipient(id, query) {
    const s = this.session(id), q = normalize(query), found = s.recipients.filter(p => normalize(p.name) === q || normalize(p.name).includes(q) || String(p.digits || p.phone || p.e164 || '').replace(/\D/g, '') === String(query).replace(/\D/g, ''));
    if (found.length !== 1) throw new Error(found.length ? `الاسم يطابق أكثر من شخص: ${found.map(x => x.name).join('، ')}.` : `لم أجد شخصًا باسم «${query}». استخدم «قائمة الأشخاص».`);
    const person = found[0];
    return this.savePending(s, { type: 'delete-recipient', label: `حذف الشخص ${person.name}`, payload: { id: person.id }, preview: `هل تريد حذف الشخص «${person.name}» (${person.international || person.e164 || person.phone || ''}) من المشروع؟
سيُزال من قوائم الإرسال والمراجع المجدولة المرتبطة، لكن لن تُحذف جهته من دفتر WhatsApp.`, confirmPrompt: 'اكتب «تأكيد الحذف» أو «إلغاء».' });
  }
  stageDeleteGroup(id, query) {
    const s = this.session(id), q = normalize(query), found = s.groups.filter(g => normalize(g.name) === q || normalize(g.name).includes(q) || normalize(g.gid) === q);
    if (found.length !== 1) throw new Error(found.length ? `الاسم يطابق أكثر من مجموعة: ${found.map(x => x.name).join('، ')}.` : `لم أجد مجموعة باسم «${query}». استخدم «اعرض المجموعات» أو «اكتشف المجموعات».`);
    const group = found[0];
    return this.savePending(s, { type: 'delete-group', label: `حذف المجموعة ${group.name}`, payload: { id: group.id }, preview: `هل تريد إزالة المجموعة «${group.name}» (${group.gid}) من المشروع؟ لن يتم مغادرة المجموعة أو حذفها من WhatsApp.`, confirmPrompt: 'اكتب «تأكيد الحذف» أو «إلغاء».' });
  }
  toggleGroup(id, verb, query) {
    const s = this.session(id), q = normalize(query), found = s.groups.filter(g => normalize(g.name) === q || normalize(g.name).includes(q) || normalize(g.gid) === q);
    if (found.length !== 1) throw new Error(found.length ? `الاسم يطابق أكثر من مجموعة: ${found.map(x => x.name).join('، ')}.` : `لم أجد مجموعة باسم «${query}».`);
    const group = found[0]; group.enabled = /^(?:فعّل|فعل|شغل)/u.test(verb); this.save(s);
    return this.result(`تم ${group.enabled ? 'تفعيل' : 'إيقاف'} المجموعة «${group.name}» داخل قوائم الإرسال. لم يتغير انضمام حساب WhatsApp إليها.`);
  }
  async stageInteractionRule(id, s, f) {
    const name = String(f.name || '').trim(), when = String(f.when || '').trim(), reply = String(f.reply || '').trim();
    if (!name || !when || !reply) throw new Error('اكتب الاسم=، عندما=، والرد= لإنشاء قاعدة تفاعل.');
    if (reply.length > 4000 || when.length > 500) throw new Error('عبارة المطابقة لا تتجاوز 500 حرف والرد لا يتجاوز 4,000 حرف.');
    if ((s.interaction.rules || []).some(x => normalize(x.name) === normalize(name))) throw new Error(`توجد قاعدة باسم «${name}» بالفعل. اختر اسمًا آخر.`);
    if ((s.interaction.rules || []).filter(x => String(x.ownerRecipientId || '') === '').length >= 500) throw new Error('بلغت القواعد العامة الحد الأقصى 500 قاعدة.');
    const matchRaw = normalize(f.match || 'contains');
    const match = /^(?:exact|تمام|يطابقتماما|مطابق)$/.test(matchRaw) ? 'exact' : /يبد|starts/.test(matchRaw) ? 'starts' : /ينته|ends/.test(matchRaw) ? 'ends' : /any|اي.?رساله/.test(matchRaw) ? 'any' : 'contains';
    const rule = { id: crypto.randomUUID(), name: name.slice(0, 100), enabled: true, priority: Number(f.priority) || 10, when: { type: 'message', match, value: when }, then: { reply, replies: [reply], stopAfter: true }, scope: ['all','private','groups','selected'].includes(normalize(f.scope)) ? normalize(f.scope) : 'all', chatIds: [], cooldownSec: 45, commandPriority: false, conflictGroup: '' };
    return this.savePending(s, { type: 'create-interaction-rule', label: `حفظ قاعدة التفاعل ${name}`, payload: rule, preview: `مراجعة قاعدة الرد:
الاسم: ${name}
تطابق: ${when} (${match})
الرد: ${reply.slice(0, 1000)}${reply.length > 1000 ? '…' : ''}
النطاق: ${rule.scope}`, confirmPrompt: 'اكتب «تأكيد الحفظ» لإضافة القاعدة أو «إلغاء». القاعدة لن ترسل رسائل إلا عندما تكون إعدادات التفاعل ونطاقه مفعّلين.' });
  }
  weekday(value) {
    const p = normalize(value);
    const map = { 'الاحد':0,'الأحد':0,'sunday':0,'الاثنين':1,'monday':1,'الثلاثاء':2,'tuesday':2,'الاربعاء':3,'wednesday':3,'الخميس':4,'thursday':4,'الجمعة':5,'friday':5,'السبت':6,'saturday':6 };
    if (value === undefined || value === null || value === '') return 5;
    if (/^\d+$/.test(String(value))) return Math.min(6, Math.max(0, Number(value)));
    if (map[p] !== undefined) return map[p];
    throw new Error('اليوم غير معروف. اكتب الأحد إلى السبت.');
  }
  async executePending(id, pending) {
    const s = this.session(id), p = pending.payload || {};
    if (pending.type === 'send') return this.executeSend(id, p);
    if (pending.type === 'create-recipient') {
      const fresh = this.session(id), person = p.recipient;
      const digits = String(person?.digits || person?.phone || '').replace(/\D/g, '');
      if (!digits) throw new Error('رقم الشخص غير صالح.');
      if (fresh.recipients.some(x => String(x.digits || x.phone || x.e164 || '').replace(/\D/g, '') === digits)) throw new Error('هذا الرقم موجود بالفعل في الجلسة؛ لم أضف سجلًا مكررًا.');
      fresh.recipients.push(person); fresh.setupComplete = true; this.save(fresh);
      return `تمت إضافة «${person.name}» برقم ${person.international || person.e164 || person.phone}. لم أغيّر دفتر WhatsApp.`;
    }
    if (pending.type === 'sync-contacts') return this.syncSelectedWhatsappContacts(id, p.jids || []);
    if (pending.type === 'create-task') {
      const task = typeof this.normalizeAutomationPayload === 'function' ? this.normalizeAutomationPayload(id, p, null) : this.store.normalizeAutomationTask(p);
      const fresh = this.session(id); fresh.automation.tasks.push(task); fresh.automation.enabled = true; this.save(fresh);
      return `تم حفظ الموعد «${task.name}» داخل الجلسة ${fresh.name}. لم يتم الإرسال الآن؛ سينفذه المجدول في موعده إذا كان الخادم وWhatsApp يعملان.`;
    }
    if (pending.type === 'create-interaction-rule') {
      const fresh = this.session(id); fresh.interaction.rules.push(p); fresh.interaction.rules = fresh.interaction.rules.slice(-500); this.save(fresh);
      return `تم حفظ قاعدة «${p.name}» وهي ${p.enabled ? 'مفعّلة' : 'متوقفة'}. راجع نطاق التفاعل وفترة الهدوء من صفحة «التفاعل».`;
    }
    if (pending.type === 'update-task') {
      const fresh = this.session(id), task = fresh.automation.tasks.find(t => t.id === p.id);
      if (!task) throw new Error('الموعد لم يعد موجودًا.');
      const merged = { ...task, ...(p.updates || {}), id: task.id };
      const updated = typeof this.normalizeAutomationPayload === 'function' ? this.normalizeAutomationPayload(id, merged, task) : this.store.normalizeAutomationTask(merged);
      Object.assign(task, updated, { id: task.id, updatedAt: new Date().toISOString() }); this.save(fresh);
      return `تم تعديل الموعد «${task.name}» وحفظه. راجع وقت التشغيل التالي في صفحة الأتمتة.`;
    }
    if (pending.type === 'update-rule') {
      const fresh = this.session(id), rule = fresh.interaction.rules.find(x => x.id === p.id);
      if (!rule) throw new Error('قاعدة التفاعل لم تعد موجودة.');
      Object.assign(rule, p.updates || {}, { id: rule.id }); this.save(fresh);
      return `تم تعديل قاعدة التفاعل «${rule.name}». راجع نطاقها وتفعيلها قبل الاعتماد عليها.`;
    }
    if (pending.type === 'delete-recipient') {
      const fresh = this.session(id), result = recipientManagement.deleteRecipients(fresh, [p.id]); this.save(fresh);
      return `تم حذف ${result.deleted.length} شخص من المشروع: ${result.deleted.map(x => x.name).join('، ')}. تم تنظيف أهداف الجدولة المرتبطة؛ لم تُحذف الجهة من دفتر WhatsApp.`;
    }
    if (pending.type === 'delete-group') {
      const fresh = this.session(id), group = fresh.groups.find(x => x.id === p.id);
      if (!group) throw new Error('المجموعة لم تعد موجودة.');
      fresh.groups = fresh.groups.filter(x => x.id !== p.id);
      const key = `g:${group.id}`; fresh.settings.scheduleTargetKeys = (fresh.settings.scheduleTargetKeys || []).filter(x => x !== key);
      if (!(fresh.settings.scheduleTargetKeys || []).length) fresh.settings.scheduleEnabled = false;
      fresh.settings.interactionChatIds = (fresh.settings.interactionChatIds || []).filter(x => String(x).toLowerCase() !== String(group.gid || '').toLowerCase());
      fresh.automation.tasks = (fresh.automation.tasks || []).map(task => ({ ...task, targetKeys: (task.targetKeys || []).filter(x => x !== key) })).filter(task => task.targetKeys.length || task.preText || task.postText || (task.mediaIds || []).length);
      this.save(fresh); return `تمت إزالة المجموعة «${group.name}» من المشروع وتنظيف المواعيد المرتبطة بها. لم يتم حذف المجموعة من WhatsApp.`;
    }
    if (pending.type === 'delete-task') {
      const fresh = this.session(id), index = fresh.automation.tasks.findIndex(t => t.id === p.id);
      if (index < 0) throw new Error('الموعد لم يعد موجودًا.'); const [removed] = fresh.automation.tasks.splice(index, 1); this.save(fresh); return `تم حذف الموعد المحلي «${removed.name}». لم يحذف أي رسالة سابقة من WhatsApp.`;
    }
    if (pending.type === 'toggle-task') {
      const fresh = this.session(id), task = fresh.automation.tasks.find(t => t.id === p.id); if (!task) throw new Error('الموعد غير موجود.'); task.enabled = p.enabled; task.updatedAt = new Date().toISOString(); this.save(fresh); return `تم ${task.enabled ? 'تفعيل' : 'إيقاف'} الموعد «${task.name}».`;
    }
    if (pending.type === 'run-task') {
      const fresh = this.session(id), task = fresh.automation.tasks.find(t => t.id === p.id); if (!task) throw new Error('الموعد غير موجود.');
      const r = await this.delivery.scheduledTaskRun(id, task);
      return `تم تشغيل الموعد يدويًا: ${task.name}\nنجح: ${(r.sent || []).length}\nفشل: ${(r.failed || []).length}${(r.failed || []).length ? `\n${r.failed.slice(0, 10).map(x => `• ${x.target}: ${x.error}`).join('\n')}` : ''}`;
    }
    if (pending.type === 'delete-rule') {
      const fresh = this.session(id), index = fresh.interaction.rules.findIndex(t => t.id === p.id); if (index < 0) throw new Error('قاعدة التفاعل لم تعد موجودة.'); const [removed] = fresh.interaction.rules.splice(index, 1); this.save(fresh); return `تم حذف القاعدة المحلية «${removed.name}».`;
    }
    return 'نوع الأمر المعلّق غير معروف؛ لم أغيّر البيانات.';
  }
  listPeople(id) {
    const s = this.session(id), people = s.recipients || [];
    return this.result(`الأشخاص المحفوظون: ${people.length}\n${people.slice(0, 60).map(person => `• ${person.name || 'بدون اسم'} — ${person.international || person.e164 || person.phone || 'بدون رقم'}${person.whatsappPushname ? ` — اسم WhatsApp: ${person.whatsappPushname}` : ''}`).join('\n') || 'لا توجد أشخاص محفوظون.'}\n\nللاستدعاء من الحساب اكتب «استدعاء جهات واتساب» أو استخدم «مزامن ملفات WhatsApp | إلى=الاسم».`);
  }
  listGroups(id) {
    const s = this.session(id), groups = s.groups || [];
    return this.result(`المجموعات المحفوظة: ${groups.length}\n${groups.slice(0, 60).map(group => `• ${group.name || 'مجموعة'} — ${group.gid} — ${group.enabled === false ? 'متوقفة' : 'مفعّلة'}`).join('\n') || 'لا توجد مجموعات محفوظة.'}\n\nاكتب «اكتشف المجموعات» للاستدعاء أو «معلومات المجموعة | GID=...@g.us» لقراءة بيانات محددة.`);
  }
  async listTasks(id) {
    const s = this.session(id), tasks = s.automation.tasks || [];
    return this.result(`المواعيد المحفوظة: ${tasks.length}\n${tasks.slice(0, 40).map(t => `• ${t.name} — ${t.enabled === false ? 'متوقف' : 'مفعّل'} — ${t.mode} ${t.time}${t.date ? ` — ${t.date}` : ''} — ${t.targetKeys?.length || 0} هدف`).join('\n') || 'لا توجد مواعيد.'}\n\nأوامر: فعّل الموعد الاسم، أوقف الموعد الاسم، احذف الموعد الاسم، شغّل الموعد الآن الاسم.`);
  }
  async listInteractionRules(id) {
    const s = this.session(id), rules = s.interaction.rules || [];
    return this.result(`قواعد التفاعل: ${rules.length}\n${rules.slice(0, 40).map(r => `• ${r.name} — ${r.enabled === false ? 'متوقفة' : 'مفعّلة'} — ${r.when?.match || 'contains'} «${r.when?.value || ''}» → ${(r.then?.reply || '').slice(0, 90)}`).join('\n') || 'لا توجد قواعد.'}\n\nأوامر: فعّل قاعدة التفاعل الاسم، أوقف قاعدة التفاعل الاسم، احذف قاعدة التفاعل الاسم.`);
  }
  listMedia(id) {
    const files = this.delivery.files(id);
    return this.result(`الوسائط المرفوعة: ${files.length}\n${files.slice(0, 100).map(f => `• ${f.filename} — ${f.isImage ? 'صورة' : f.ext || 'ملف'} — ${(Number(f.size) / (1024 * 1024)).toFixed(2)} MB`).join('\n') || 'لا توجد وسائط.'}\nلاستخدام ملف اكتب اسمه في الحقل ملف= ضمن أمر «أرسل الآن».`);
  }
  async discoverGroups(id) {
    const found = await this.whatsapp.listGroups(id), saved = found.map(info => this.saveGroup(id, info));
    return this.result(`اكتشاف مجموعات WhatsApp اكتمل بطلب صريح. عُثر على ${found.length} مجموعة، وحُفظ/حُدّث ${saved.length} منها داخل الجلسة.
${saved.slice(0, 30).map(x => `• ${x.name} — ${x.gid}`).join('\n') || 'لم يتم العثور على مجموعات.'}`);
  }
  async groupInfo(id, raw) {
    const gid = String(raw || '').trim(); if (!/^\d+(?:-\d+)*@g\.us$/i.test(gid)) throw new Error('أدخل GID صالحًا في الحقل GID، مثل 120363000000-123@g.us.');
    const info = await this.whatsapp.getGroupInfo(id, gid), saved = this.saveGroup(id, info);
    return this.result(`تم استدعاء بيانات المجموعة وحفظها داخل المشروع:
الاسم: ${saved.name}
GID: ${saved.gid}
الأعضاء: ${saved.participantsCount ?? 'غير معروف'}
الوصف: ${saved.description || '—'}
رابط الدعوة: ${saved.inviteCode ? `https://chat.whatsapp.com/${saved.inviteCode}` : 'غير متاح'}`);
  }
  async analyzeInvite(id, raw) {
    const url = String(raw || '').trim(), match = url.match(/(?:https?:\/\/)?chat\.whatsapp\.com\/([A-Za-z0-9_-]{6,64})/i);
    const code = match ? match[1] : url;
    if (!/^[A-Za-z0-9_-]{6,64}$/.test(code)) throw new Error('رابط الدعوة غير صالح.');
    const info = await this.whatsapp.analyzeGroupInvite(id, code);
    if (!info?.gid || !/^\d+(?:-\d+)*@g\.us$/.test(String(info.gid).toLowerCase())) return this.result(`نجح تحليل الدعوة، لكن WhatsApp لم يعط معرّف مجموعة موثوقًا؛ لم أضف مجموعة تلقائيًا. الاسم المتاح: ${info.name || 'غير معروف'}.`);
    const saved = this.saveGroup(id, info);
    return this.result(`تم تحليل الدعوة وحفظ المجموعة «${saved.name}»\nGID: ${saved.gid}\nالأعضاء: ${saved.participantsCount ?? 'غير معروف'}`);
  }
  async stageSyncWhatsappContacts(id, _session, raw) {
    const s = this.session(id);
    const contacts = await this.whatsapp.listContacts(id, { limit: 2000 });
    let jids;
    if (/^(?:الكل|الجميع)$/u.test(normalize(raw))) jids = contacts.slice(0, 100).map(x => x.jid);
    else {
      const queries = splitList(raw); if (!queries.length) throw new Error('حدد أسماء جهات مثل: مزامن ملفات WhatsApp | إلى=أحمد، سارة.');
      jids = unique(queries.flatMap(query => {
        const q = normalize(query), saved = s.recipients.filter(p => normalize(p.name) === q || normalize(p.whatsappName) === q || normalize(p.whatsappPushname) === q || String(p.digits || p.phone || p.e164 || '').replace(/\D/g, '') === query.replace(/\D/g, ''));
        if (saved.length > 1) throw new Error(`الاسم «${query}» يطابق جهات محلية متعددة؛ استخدم الرقم الدولي للتحديد.`);
        if (!saved.length) {
          const live = contacts.filter(c => normalize(c.name) === q || normalize(c.pushname) === q || normalize(c.notifyName) === q || `+${c.digits}` === query);
          if (live.length > 1) throw new Error(`الاسم «${query}» يطابق جهات WhatsApp متعددة؛ اكتب الاسم الكامل أو الرقم.`);
          return live.map(c => c.jid);
        }
        const person = saved[0];
        const jid = String(person.whatsappJid || '').toLowerCase();
        return jid && contacts.some(c => c.jid === jid) ? [jid] : contacts.filter(c => String(c.digits) === String(person.digits || person.phone || person.e164 || '').replace(/\D/g, '')).map(c => c.jid);
      }));
    }
    jids = jids.slice(0, 100);
    if (!jids.length) throw new Error('لم أجد جهات مطابقة بأرقام WhatsApp مؤكدة. لا أخمّن الأرقام من معرّفات LID.');
    const selected = contacts.filter(c => jids.includes(String(c.jid || '').toLowerCase()));
    const preview = selected.slice(0, 18).map((c, i) => `${i + 1}. ${c.name || c.pushname || `+${c.digits}`} — +${c.digits}${c.pushname && c.pushname !== c.name ? ` (اسم الملف: ${c.pushname})` : ''}`).join('\n');
    return this.savePending(s, { type: 'sync-contacts', label: `مزامنة ${jids.length} جهة WhatsApp`, payload: { jids }, preview: `مراجعة مزامنة جهات WhatsApp:\nسيتم تحديث الاسم الظاهر من WhatsApp ونسخ الصور المتاحة للجهات المختارة.\nلن أستبدل أسماء الأشخاص المحلية المخصصة.\n\n${preview}${selected.length > 18 ? `\n… و${selected.length - 18} جهات أخرى` : ''}`, confirmPrompt: 'اكتب «تأكيد المزامنة» للمتابعة أو «إلغاء». لم تتغير البيانات بعد.' });
  }
  async syncSelectedWhatsappContacts(id, jids) {
    const { syncContacts } = require('./whatsapp-contacts');
    const safeJids = [...new Set((Array.isArray(jids) ? jids : []).map(x => String(x || '').toLowerCase()).filter(x => /^\d{5,25}@c\.us$/.test(x)))].slice(0, 100);
    if (!safeJids.length) throw new Error('قائمة جهات المزامنة لم تعد صالحة. أعد استدعاء WhatsApp.');
    const result = await syncContacts({ store: this.store, whatsapp: this.whatsapp, phones: this.phones, sessionId: id, jids: safeJids, importMissing: true, updateNames: false, updatePictures: true });
    return `${result.message}\nلم أستبدل الأسماء المحلية المخصصة. تم تخزين اسم WhatsApp وصورة الملف المتاحة في حقول مستقلة. إذا لم تظهر صورة جهة ما فقد أخفاها صاحب الحساب أو لم تكن متاحة من WhatsApp.`;
  }
  setTimezone(id, timezone) {
    const value = String(timezone || '').trim();
    try { new Intl.DateTimeFormat('en', { timeZone: value }).format(new Date()); } catch { throw new Error('المنطقة الزمنية غير معروفة. استخدم منطقة IANA مثل Asia/Muscat أو Asia/Dubai.'); }
    const s = this.session(id); s.settings.timezone = value; this.save(s); return this.result(`تم ضبط المنطقة الزمنية على ${value}. ستستخدمها الجداول والردود التي تعتمد الوقت.`);
  }
  toggleSystem(id, p) {
    const s = this.session(id); const turnOn = /^(?:فعّل|فعل|شغل)/u.test(p);
    if (/التفاعل/u.test(p)) { s.settings.interactionEnabled = turnOn; s.interaction.enabled = turnOn; this.save(s); return this.result(`تم ${turnOn ? 'تفعيل' : 'إيقاف'} التفاعل التلقائي. ${turnOn ? 'تأكد أيضًا أن القاعدة نفسها مفعّلة.' : 'لن تُشغّل قواعد الرد أثناء توقف النظام.'}`); }
    s.settings.automationEnabled = turnOn; s.automation.enabled = turnOn; this.save(s); return this.result(`تم ${turnOn ? 'تفعيل' : 'إيقاف'} الأتمتة. ${turnOn ? 'تحتاج المواعيد جلسة WhatsApp متصلة واستمرار تشغيل الخادم.' : 'لن يعمل المجدول أثناء الإيقاف.'}`);
  }
  async taskAction(id, verb, rawName, destructive, runNow = false) {
    const s = this.session(id), q = normalize(rawName.replace(/^الموعد\s+/u, '').trim());
    const found = s.automation.tasks.filter(t => normalize(t.name) === q || normalize(t.name).includes(q));
    if (found.length !== 1) throw new Error(found.length ? `الاسم يطابق مواعيد متعددة: ${found.map(t => t.name).join('، ')}.` : `لم أجد موعدًا باسم «${rawName}». اكتب «اعرض المواعيد».`);
    const task = found[0];
    if (destructive || runNow) {
      const pending = { type: destructive ? 'delete-task' : 'run-task', label: `${destructive ? 'حذف' : 'تشغيل'} الموعد ${task.name}`, payload: { id: task.id }, preview: destructive ? `هل تريد حذف الموعد المحلي «${task.name}»؟ لن يُحذف أي شيء من WhatsApp.` : `هل تريد تشغيل الموعد «${task.name}» الآن؟\nالأهداف: ${task.targetKeys.length}\nالرسالة: ${(task.preText || '').slice(0, 500)}\nقد يرسل هذا الأمر رسائل فعلية إلى المستلمين.`, confirmPrompt: destructive ? 'اكتب «تأكيد الحذف» (أو «نعم») للحذف، أو «إلغاء».' : 'اكتب «تأكيد الإرسال» للتشغيل الآن أو «إلغاء».' };
      return this.savePending(s, pending);
    }
    const enabled = /^(?:فعّل|فعل|شغّل|شغل)/u.test(verb); task.enabled = enabled; task.updatedAt = new Date().toISOString(); this.save(s); return this.result(`تم ${enabled ? 'تفعيل' : 'إيقاف'} الموعد «${task.name}».`);
  }
  async ruleAction(id, verb, rawName) {
    const s = this.session(id), q = normalize(rawName), found = (s.interaction.rules || []).filter(r => normalize(r.name) === q || normalize(r.name).includes(q));
    if (found.length !== 1) throw new Error(found.length ? `الاسم يطابق قواعد متعددة: ${found.map(x => x.name).join('، ')}.` : `لم أجد قاعدة باسم «${rawName}». اكتب «اعرض قواعد التفاعل».`);
    const rule = found[0];
    if (/^(?:احذف|حذف)/u.test(verb)) return this.savePending(s, { type: 'delete-rule', label: `حذف قاعدة التفاعل ${rule.name}`, payload: { id: rule.id }, preview: `هل تريد حذف قاعدة التفاعل «${rule.name}»؟`, confirmPrompt: 'اكتب «تأكيد الحذف» أو «إلغاء».' });
    rule.enabled = /^(?:فعّل|فعل|شغّل|شغل)/u.test(verb); this.save(s); return this.result(`تم ${rule.enabled ? 'تفعيل' : 'إيقاف'} قاعدة التفاعل «${rule.name}».`);
  }
}

module.exports = { LocalCommandBridge, normalizeCommand: normalize, parseCommandFields: parseFields, isCommandConfirm: isConfirm, isCommandCancel: isCancel };
