"use strict";
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const BAD_LINE = /(^|\r?\n)\s*(?:if\s*\(message\s*&&\s*message\.__x_id\)\s*delete\s+message\.__x_id\s*;?|message\.__x_id\s*=.*?;)(?=\r?\n|$)/g;
const MARKERS = /(^|\r?\n)\s*\/\*\s*CHAT_BOT_[^*]*COMPAT[^*]*\*\/\s*/g;

function syntaxOk(source, filename) {
  try { new vm.Script(String(source), { filename }); return true; }
  catch { return false; }
}

function patchUtilsText(source) {
  let out = String(source);
  const before = out;
  // Never write a known malformed object-field injection back into the library.
  // Older chat BOT builds inserted executable code inside the message object.
  // Remove only that known broken line/marker. Never inject statements into Utils.js.
  out = out.replace(BAD_LINE, '\n').replace(MARKERS, '\n');

  // Safe compatibility fallbacks for message IDs used by newer WhatsApp Web builds.
  const replacements = [
    ['window.Store.Msg.get(newMsgKey._serialized)', 'window.Store.Msg.get(newMsgKey._serialized || newMsgKey.$1)'],
    ['window.Store.Msg.get(msg.id._serialized)', 'window.Store.Msg.get(msg.id._serialized || msg.id.$1)'],
    ['window.Store.Msg.get(chat.lastReceivedKey._serialized)', 'window.Store.Msg.get(chat.lastReceivedKey._serialized || chat.lastReceivedKey.$1)'],
    ['window.Store.Msg.getMessagesById([chat.lastReceivedKey._serialized])', 'window.Store.Msg.getMessagesById([chat.lastReceivedKey._serialized || chat.lastReceivedKey.$1])'],
    ['window.Store.WidFactory.createWid(chat.id._serialized)', 'window.Store.WidFactory.createWid(chat.id._serialized || chat.id.$1)'],
  ];
  for (const [from, to] of replacements) out = out.replaceAll(from, to);

  // WhatsApp Web 2.3000.x can expose MediaData.__x_id as an enumerable
  // private field. In v1.34.7 it is spread into the outgoing message object
  // and can overwrite the real Msg id. Remove it only after the message object
  // has been assembled; never reference an out-of-scope mediaOptions variable.
  if (out.includes('const message = {') && !out.includes('CHAT_BOT_MEDIA_ID_SAFE')) {
    const marker = "        };\n        // Bot's won't reply if canonicalUrl is set (linking)";
    const replacement = "        };\n        /* CHAT_BOT_MEDIA_ID_SAFE */\n        delete message.__x_id;\n        // Bot's won't reply if canonicalUrl is set (linking)";
    out = out.replace(marker, replacement);
  }

  out = out.replaceAll('WAWebCollections.Msg.get(newMsgKey._serialized)', 'WAWebCollections.Msg.get(newMsgKey._serialized || newMsgKey.$1)');

  if (!syntaxOk(out, 'whatsapp-web.js/src/util/Injected/Utils.js')) {
    return { text: before, changed: [], ok: false, note: 'النص الناتج من إصلاح Utils.js غير صالح نحويًا؛ لم يتم الكتابة على المكتبة.' };
  }
  const changed = out !== before ? ['Utils.js-sanitized'] : [];
  return { text: out, changed, ok: true };
}

function packageRoot() {
  try { return path.dirname(require.resolve('whatsapp-web.js/package.json')); }
  catch { return null; }
}

function patch() {
  const result = { ok: true, changed: [], notes: [], packageVersion: null };
  try {
    const root = packageRoot();
    if (!root) {
      result.notes.push('whatsapp-web.js غير مثبت بعد. سيتم تنفيذ الإصلاح بعد تثبيت الاعتماديات.');
      return result;
    }
    try {
      const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
      result.packageVersion = pkg.version || null;
    } catch {}

    const utils = path.join(root, 'src', 'util', 'Injected', 'Utils.js');
    if (!fs.existsSync(utils)) {
      result.notes.push('Utils.js غير موجود.');
      return result;
    }
    const before = fs.readFileSync(utils, 'utf8');
    const fixed = patchUtilsText(before);
    if (!fixed.ok) {
      result.ok = false;
      result.notes.push(fixed.note || 'تعذر إصلاح Utils.js بأمان.');
      return result;
    }
    if (fixed.text !== before) {
      const tmp = `${utils}.chatbot.tmp`;
      fs.writeFileSync(tmp, fixed.text, 'utf8');
      // Validate the exact bytes before replacing the real library file.
      if (!syntaxOk(fixed.text, utils)) {
        fs.rmSync(tmp, { force: true });
        result.ok = false;
        result.notes.push('فشل فحص الصياغة بعد الإصلاح؛ تم إلغاء الكتابة.');
        return result;
      }
      fs.renameSync(tmp, utils);
      result.changed.push(...fixed.changed);
    }
    result.notes.push(fixed.changed.length ? 'تم تنظيف أي patch قديم غير صالح دون حقن كود داخل Utils.js.' : 'Utils.js سليم ولا يحتاج تعديلًا خطيرًا.');
    return result;
  } catch (e) {
    result.ok = false;
    result.notes.push(e?.message || String(e));
    return result;
  }
}

if (require.main === module) {
  const r = patch();
  console.log(JSON.stringify(r, null, 2));
  if (!r.ok) process.exitCode = 1;
}

module.exports = { patch, patchUtilsText, syntaxOk };
