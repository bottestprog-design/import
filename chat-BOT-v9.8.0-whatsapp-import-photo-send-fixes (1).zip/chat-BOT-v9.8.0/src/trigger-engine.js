"use strict";

function normalizeArabic(value) {
  return String(value ?? '').normalize('NFKC')
    .replace(/[\u0640]/g, '')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي')
    .replace(/[\u200e\u200f\u202a-\u202e]/g, '')
    .trim().toLocaleLowerCase('ar');
}
function compact(value) { return normalizeArabic(value).replace(/[\s\p{P}\p{S}]+/gu, ' ').trim(); }

const INTENTS = {
  greeting: ['مرحبا','مرحباً','اهلا','اهلا وسهلا','السلام عليكم','صباح الخير','مساء الخير','هلا','يا هلا','hi','hello','hey','good morning','good evening'],
  thanks: ['شكرا','شكرًا','مشكور','مشكورة','تسلم','يعطيك العافية','جزاك الله خيرا','thanks','thank you','thx'],
  farewell: ['مع السلامة','الى اللقاء','اشوفك لاحقا','باي','تصبح على خير','في امان الله','bye','goodbye','see you'],
  help: ['مساعدة','ساعدني','كيف استخدم','كيف اعمل','شرح','help','support','how do i','how to'],
  price: ['السعر','كم السعر','بكم','التكلفة','كم يكلف','price','cost','how much'],
  availability: ['متوفر','متاحة','عندكم','هل يوجد','موجود','availability','available','in stock'],
  complaint: ['مشكلة','شكوى','سيء','سيئ','ما يشتغل','لا يعمل','متضايق','غير راضي','problem','complaint','broken','does not work'],
  confirmation: ['نعم','ايوه','أيوه','تمام','موافق','أكيد','اكيد','بالضبط','yes','yeah','ok','okay','sure'],
  negation: ['لا','لأ','مش','مو','غير صحيح','ما اريد','لا اريد','no','nope','not'],
  question: ['كيف','متى','اين','وين','لماذا','ليه','كم','هل','ما هو','what','when','where','why','how','which']
};

function inferIntent(value) {
  const text = ` ${compact(value)} `;
  if (!text.trim()) return 'unknown';
  const order = ['greeting','thanks','farewell','complaint','price','availability','help','confirmation','negation','question'];
  for (const key of order) {
    if (INTENTS[key].some(phrase => {
      const candidate = compact(phrase);
      return text.includes(` ${candidate} `) || text.trim() === candidate;
    })) return key;
  }
  return 'unknown';
}

function tokens(value) { return compact(value).split(' ').filter(Boolean); }
function bigrams(value) {
  const s = compact(value).replace(/\s+/g, ' ');
  if (s.length < 2) return s ? [s] : [];
  const out = []; for (let i = 0; i < s.length - 1; i++) out.push(s.slice(i, i + 2)); return out;
}
function dice(a, b) {
  if (!a.length || !b.length) return 0;
  const counts = new Map(); for (const x of a) counts.set(x, (counts.get(x) || 0) + 1);
  let common = 0; for (const x of b) { const n = counts.get(x) || 0; if (n > 0) { common++; counts.set(x, n - 1); } }
  return 2 * common / (a.length + b.length);
}
function editSimilarity(a, b) {
  if (!a || !b) return 0;
  if (a === b) return 1;
  const longest = Math.max(a.length, b.length);
  // Keep the edit-distance work bounded for large incoming messages/rule sets.
  if (longest > 180) return 0;
  let previous = Array.from({ length: b.length + 1 }, (_, index) => index);
  for (let i = 1; i <= a.length; i++) {
    const current = [i];
    for (let j = 1; j <= b.length; j++) current[j] = Math.min(current[j - 1] + 1, previous[j] + 1, previous[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    previous = current;
  }
  return Math.max(0, 1 - previous[b.length] / longest);
}
function localSimilarity(a, b) {
  if (!a || !b) return 0;
  if (a === b) return 1;
  if (a.includes(b) || b.includes(a)) {
    const ratio = Math.min(a.length, b.length) / Math.max(a.length, b.length);
    return Math.max(.72, .82 + .18 * ratio);
  }
  const char = dice(bigrams(a), bigrams(b));
  const word = dice(tokens(a), tokens(b));
  const edit = Math.max(a.length, b.length) <= 36 ? editSimilarity(a, b) * .92 : 0;
  return Math.min(1, Math.max(char * .68 + word * .32, edit));
}
function similarityScore(a, b) {
  const x = compact(a), y = compact(b);
  if (!x || !y) return 0;
  if (x === y) return 1;
  // Exact phrase hits are cheap and very reliable even within a longer sentence.
  if (x.includes(y) || y.includes(x)) return localSimilarity(x, y);
  // Search a bounded set of local windows so a typo can match within a sentence
  // without making fuzzy matching unbounded for long pasted messages.
  if (x.length > y.length + 2 && y.length <= 80) {
    let best = 0;
    const minLen = Math.max(1, y.length - 2), maxLen = Math.min(x.length, y.length + 2);
    for (let size = minLen; size <= maxLen; size++) {
      const stride = Math.max(1, Math.ceil((x.length - size + 1) / 180));
      for (let i = 0; i + size <= x.length; i += stride) {
        best = Math.max(best, localSimilarity(x.slice(i, i + size), y));
        if (best >= .999) return 1;
      }
    }
    return best;
  }
  return localSimilarity(x, y);
}

const MODE_ALIASES = {
  'contains phrase': 'contains', contains_phrase: 'contains', 'starts with': 'starts', starts_with: 'starts',
  'ends with': 'ends', ends_with: 'ends', 'exact match': 'exact', exact_match: 'exact',
  similar: 'similarity', fuzzy: 'similarity', intent_match: 'intent'
};
function canonicalMode(mode) { const raw = String(mode || '').trim().toLowerCase(); return MODE_ALIASES[raw] || raw; }
function regexIsRisky(pattern) { const value = String(pattern || ''); return /\([^)]*[+*{][^)]*\)[+*{]/.test(value) || /(?:\.\*|\.\+).*(?:\.\*|\.\+)/.test(value); }

function matchTrigger(rule, event, text, emoji, options = {}) {
  if (rule?.when?.type && rule.when.type !== event) return { matched: false, score: 0, intent: event === 'message' ? inferIntent(text) : 'unknown' };
  const source = event === 'reaction' ? String(emoji || '') : String(text || '');
  const input = normalizeArabic(source), rawValue = String(rule?.when?.value ?? ''), value = normalizeArabic(rawValue);
  const mode = canonicalMode(rule?.when?.match || 'contains');
  const intent = event === 'message' ? inferIntent(source) : 'unknown';
  if (mode === 'any') return { matched: Boolean(input), score: Boolean(input) ? .1 : 0, intent };
  if (!value.trim()) return { matched: false, score: 0, intent };
  switch (mode) {
    case 'exact': return { matched: input === value, score: input === value ? 1 : 0, intent };
    case 'contains': { const yes = input.includes(value); return { matched: yes, score: yes ? Math.min(1, .75 + value.length / Math.max(1, input.length) * .25) : 0, intent }; }
    case 'starts': { const yes = input.startsWith(value); return { matched: yes, score: yes ? .88 + Math.min(.12, value.length / Math.max(1, input.length) * .12) : 0, intent }; }
    case 'ends': { const yes = input.endsWith(value); return { matched: yes, score: yes ? .88 + Math.min(.12, value.length / Math.max(1, input.length) * .12) : 0, intent }; }
    case 'regex': {
      if (rawValue.length > 240 || regexIsRisky(rawValue)) return { matched: false, score: 0, intent };
      try { const yes = new RegExp(rawValue, rule.when.ignoreCase === false ? 'u' : 'iu').test(source); return { matched: yes, score: yes ? .78 : 0, intent }; } catch { return { matched: false, score: 0, intent }; }
    }
    case 'similarity': {
      const score = similarityScore(source, rawValue);
      const threshold = Math.max(.30, Math.min(.98, Number(rule?.when?.threshold ?? options.threshold ?? .68)));
      return { matched: score >= threshold, score, intent };
    }
    case 'intent': {
      const requested = compact(rawValue).replace(/\s+/g, '_');
      const aliases = { 'تحية':'greeting', 'ترحيب':'greeting', 'شكر':'thanks', 'وداع':'farewell', 'مساعدة':'help', 'سعر':'price', 'استفسار_عن_السعر':'price', 'توفر':'availability', 'شكوى':'complaint', 'تأكيد':'confirmation', 'رفض':'negation', 'سؤال':'question' };
      const wanted = aliases[requested.replace(/_/g, ' ')] || aliases[requested] || requested;
      const known = Object.prototype.hasOwnProperty.call(INTENTS, wanted);
      const yes = known ? intent === wanted : similarityScore(source, rawValue) >= Math.max(.35, Math.min(.98, Number(rule?.when?.threshold ?? options.threshold ?? .68)));
      return { matched: yes, score: yes ? (known ? .84 : similarityScore(source, rawValue)) : 0, intent };
    }
    default: return { matched: false, score: 0, intent };
  }
}
function validateTrigger(rule) {
  if (!['message', 'reaction'].includes(rule?.when?.type)) throw new Error('نوع الحدث غير مدعوم.');
  const mode = canonicalMode(rule?.when?.match);
  if (!['any','contains','exact','starts','ends','regex','similarity','intent'].includes(mode)) throw new Error('نوع المطابقة غير مدعوم.');
  if (mode !== 'any' && !String(rule?.when?.value || '').trim()) throw new Error('اكتب قيمة المطابقة أو اسم النية.');
  if (mode === 'regex') {
    if (String(rule.when.value).length > 240) throw new Error('نمط Regex طويل جدًا؛ الحد 240 حرفًا.');
    const pattern = String(rule.when.value);
    if (regexIsRisky(pattern)) throw new Error('نمط Regex قد يكون مكلفًا جدًا؛ بسّطه لتجنب تجميد المعالجة.');
    new RegExp(pattern, rule.when.ignoreCase === false ? 'u' : 'iu');
  }
  if (mode === 'similarity' && rule.when.threshold !== undefined && (!Number.isFinite(Number(rule.when.threshold)) || Number(rule.when.threshold) < .30 || Number(rule.when.threshold) > .98)) throw new Error('عتبة التشابه يجب أن تكون بين 0.30 و0.98.');
  return true;
}
module.exports = { normalizeArabic, compact, inferIntent, similarityScore, matchTrigger, validateTrigger, canonicalMode, regexIsRisky, INTENTS };
