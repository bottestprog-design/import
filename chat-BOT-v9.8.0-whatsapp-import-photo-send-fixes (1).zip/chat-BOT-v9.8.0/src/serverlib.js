"use strict";
const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');const {MIME,MEDIA_EXT,nextImageName,safePath}=require('./media');
function logFactory(store){return (id,level,message,extra=null)=>{const now=new Date(), line=`[${now.toISOString()}] [${level}] ${message}${extra?` ${JSON.stringify(extra)}`:''}`;console.log(id?`[${id}] ${line}`:line);if(id&&store.listSessionIds().includes(store.safeSessionId(id))){const s=store.loadSession(id);s.logs=[...s.logs,{at:now.toISOString(),time:now.toISOString(),level,message,extra}].slice(-400);store.saveSession(s);try{fs.appendFileSync(store.getPaths(id).logFile,line+'\n','utf8')}catch{}}else{try{fs.appendFileSync(path.join(store.DATA_DIR,'system.log'),line+'\n','utf8')}catch{}}}}
function replyError(res,e,status=400){
  const raw = String(e?.message || e || 'خطأ غير معروف').replace(/[\r\n\t]+/g,' ').slice(0,900);
  const { classifyWhatsAppError } = require('./whatsapp-errors');
  const known = e?.code || /permission denied|access denied|not authorized|unauthorized|forbidden|not connected|disconnected|auth_failure|\b(?:401|403|429)\b|not registered|not on whatsapp|econnreset|econnrefused|timeout|timed out|target closed|session is not ready|file.*not found|no such file/i.test(raw);
  if (!known) return res.status(status).json({ok:false,error:raw});
  const info = classifyWhatsAppError(e, 'طلب WhatsApp');
  const isRecognized = info.code !== 'WHATSAPP_OPERATION_FAILED';
  if (!isRecognized) return res.status(status).json({ok:false,error:raw});
  return res.status(status).json({ok:false,error:info.message,code:info.code,retryable:info.retryable,detail:info.detail || undefined});
}
function randomId(){return crypto.randomUUID()}
module.exports={logFactory,replyError,randomId,MIME,MEDIA_EXT,nextImageName,safePath};
