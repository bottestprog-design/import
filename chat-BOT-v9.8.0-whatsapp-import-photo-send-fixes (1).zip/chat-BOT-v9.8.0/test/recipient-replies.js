'use strict';
const assert = require('node:assert/strict');
const { InteractionEngine } = require('../src/interaction');
const { normalizeReplyProfile, validateReplyProfile, matchPersonalRule, recipientForChat } = require('../src/recipient-replies');

function makeSession() {
  return {
    id: 'personal-session', timezone: 'Asia/Muscat',
    settings: { interactionEnabled: true, interactionIgnoreOwn: true, interactionScope: 'all', interactionChatIds: [], interactionQuietEnabled: false, maxActionsPerMinute: 100, interactionCooldownCapSec: 86400, timezone: 'Asia/Muscat' },
    recipients: [], interaction: { enabled: true, rules: [], counterTriggers: [], variantState: {}, contextByChat: {}, counterState: {}, recent: [] },
    automation: { tasks: [], rules: [], mutes: [] }, stats: { interactionActions: 0, interactionErrors: 0 }, logs: [],
  };
}
function message(id, body, chatId) {
  return { fromMe: false, body, notifyName: 'اسم وارد', id: { _serialized: id, remote: { _serialized: chatId } }, from: chatId, to: chatId, getChat: async () => ({ id: { _serialized: chatId }, name: 'اسم وارد' }) };
}
function rig(session) {
  const sent = [];
  const store = { loadSession: () => session, saveSession: value => Object.assign(session, value) };
  const whatsapp = { replyToMessage: async (sid, msg, text) => { sent.push({ chatId: msg.from, text }); return {}; }, sendText: async () => ({}), reactToMessage: async () => ({}) };
  return { engine: new InteractionEngine({ store, whatsapp, log: () => {} }), sent, session };
}
(async () => {
  assert.equal(matchPersonalRule({ match: 'contains', value: 'السعر', enabled: true }, 'كم السعر لو سمحت؟'), true);
  assert.equal(matchPersonalRule({ match: 'exact', value: 'مرحبا' }, 'مرحبا بك'), false);
  assert.equal(matchPersonalRule({ match: 'startsWith', value: 'مرحبا' }, 'مرحبا بك'), true);
  assert.equal(matchPersonalRule({ match: 'endsWith', value: 'تمام' }, 'حسنًا، تمام'), true);
  assert.equal(matchPersonalRule({ match: 'any', value: '' }, 'أي نص'), true);
  assert.equal(normalizeReplyProfile({ mode: 'other', cooldownSec: 999999, rules: [{ match: 'bad' }] }).mode, 'inherit');
  assert.equal(normalizeReplyProfile({ cooldownSec: 999999 }).cooldownSec, 86400);
  assert.throws(() => validateReplyProfile({ mode: 'custom', rules: Array.from({ length: 31 }, () => ({ match: 'any', reply: 'x' })) }), /30/);

  const s = makeSession();
  s.recipients.push({ id: 'p1', name: 'عميل', digits: '96890000000', phone: '96890000000', e164: '+96890000000', enabled: true, replyProfile: {
    mode: 'custom', enabled: true, cooldownSec: 3600, fallbackToGlobal: false, defaultReply: '',
    rules: [{ id: 'price', name: 'السعر', enabled: true, match: 'contains', value: 'السعر', reply: 'مرحبًا {{sender}}، الرسالة: {{message}}' }],
  } });
  assert.equal(recipientForChat(s, '96890000000@c.us').id, 'p1');
  assert.equal(recipientForChat(s, '12345@lid'), null, 'must never infer the recipient from an unresolved LID');
  s.interaction.rules.push({ id: 'global', name: 'قاعدة عامة', enabled: true, priority: 10, cooldownSec: 0, when: { type: 'message', match: 'any', value: '' }, then: { reply: 'رد عام' }, scope: 'all', chatIds: [] });
  const testRig = rig(s);
  const first = await testRig.engine.onMessage(s.id, message('p-msg-1', 'كم السعر؟', '96890000000@c.us'));
  assert.equal(first.action, 'reply');
  assert.equal(first.personalReply, true);
  assert.equal(testRig.sent.length, 1);
  assert.match(testRig.sent[0].text, /مرحبًا اسم وارد، الرسالة: كم السعر؟/);
  const second = await testRig.engine.onMessage(s.id, message('p-msg-2', 'كم السعر؟', '96890000000@c.us'));
  assert.equal(second.action, 'cooldown');
  assert.equal(testRig.sent.length, 1, 'personal cooldown must prevent a repeated reply');

  const fallback = makeSession();
  fallback.recipients.push({ id: 'p2', digits: '96891111111', replyProfile: { mode: 'custom', fallbackToGlobal: true, rules: [] } });
  fallback.interaction.rules.push({ id: 'global', name: 'قاعدة عامة', enabled: true, priority: 1, cooldownSec: 0, when: { type: 'message', match: 'contains', value: 'مساعدة' }, then: { reply: 'رد عام مساعد' }, scope: 'all', chatIds: [] });
  const fallbackRig = rig(fallback);
  const globalResult = await fallbackRig.engine.onMessage(fallback.id, message('fallback-1', 'أحتاج مساعدة', '96891111111@c.us'));
  assert.equal(globalResult.handled, true);
  assert.equal(fallbackRig.sent[0].text, 'رد عام مساعد');

  const disabled = makeSession();
  disabled.recipients.push({ id: 'p3', digits: '96892222222', replyProfile: { mode: 'disabled', rules: [] } });
  disabled.interaction.rules.push({ id: 'global', name: 'قاعدة عامة', enabled: true, cooldownSec: 0, when: { type: 'message', match: 'any', value: '' }, then: { reply: 'رد عام' }, scope: 'all', chatIds: [] });
  const disabledRig = rig(disabled);
  const disabledResult = await disabledRig.engine.onMessage(disabled.id, message('disabled-1', 'مرحبا', '96892222222@c.us'));
  assert.equal(disabledResult.action, 'disabled');
  assert.equal(disabledRig.sent.length, 0, 'an explicit personal disable must suppress global replies to that person');

  const inherited = makeSession();
  inherited.recipients.push({ id: 'p4', digits: '96893333333', replyProfile: { mode: 'inherit' } });
  inherited.interaction.rules.push({ id: 'global', name: 'قاعدة عامة', enabled: true, cooldownSec: 0, when: { type: 'message', match: 'any', value: '' }, then: { reply: 'رد عام' }, scope: 'all', chatIds: [] });
  const inheritedRig = rig(inherited);
  await inheritedRig.engine.onMessage(inherited.id, message('inherit-1', 'مرحبا', '96893333333@c.us'));
  assert.equal(inheritedRig.sent[0].text, 'رد عام');
  console.log('recipient-replies: ok (normalization, safe matching, verified contact lookup, personal responses, cooldown, inheritance, global fallback and explicit disable)');
})().catch(error => { console.error(error); process.exitCode = 1; });
