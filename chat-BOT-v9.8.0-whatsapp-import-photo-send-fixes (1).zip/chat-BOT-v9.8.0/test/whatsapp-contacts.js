'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { syncContacts, digitsFromJid, downloadProfile } = require('../src/whatsapp-contacts');
const clone = value => JSON.parse(JSON.stringify(value));
(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-wa-contacts-'));
  try {
    let saved = {
      id: 'main', recipients: [{ id: 'local-1', name: 'الاسم المحلي المخصص', digits: '96890000000', e164: '+96890000000', country: 'OM' }],
      groups: [], settings: {}, automation: { tasks: [], rules: [] }, interaction: { rules: [] }, logs: [],
    };
    const store = {
      safeSessionId: value => String(value || 'main'),
      loadSession: () => clone(saved),
      saveSession: session => { saved = clone(session); return clone(saved); },
      getPaths: () => ({ dir: root, profiles: path.join(root, 'profiles') }),
    };
    const whatsapp = { listContacts: async (_id, opts) => [
      { jid: '96890000000@c.us', digits: '96890000000', name: 'اسم WhatsApp جديد', pushname: 'اسم ظاهر', isMyContact: true },
      { jid: '96891111111@c.us', digits: '96891111111', name: 'سارة من WhatsApp', isMyContact: true },
    ].filter(contact => !opts.onlyJids || opts.onlyJids.includes(contact.jid)) };
    const phones = { parse: value => { const digits = String(value).replace(/\D/g, ''); return { digits, e164: `+${digits}`, international: `+${digits}`, formatted: `+${digits}`, country: 'OM' }; } };

    assert.equal(digitsFromJid('96890000000@c.us'), '96890000000');
    assert.equal(digitsFromJid('fake123@lid'), '', 'LID must never be interpreted as a phone number');
    const result = await syncContacts({ store, whatsapp, phones, sessionId: 'main', jids: ['96890000000@c.us', '96891111111@c.us'], importMissing: true, updateNames: false, updatePictures: false });
    assert.equal(result.imported.length, 1);
    assert.equal(result.updated.length, 1);
    assert.equal(saved.recipients.find(person => person.id === 'local-1').name, 'الاسم المحلي المخصص', 'local names are preserved by default');
    assert.equal(saved.recipients.find(person => person.digits === '96891111111').name, 'سارة من WhatsApp');
    assert.ok(saved.recipients.every(person => person.whatsappSyncedAt), 'sync metadata is recorded');
    await assert.rejects(() => syncContacts({ store, whatsapp, phones, sessionId: 'main', jids: ['12345678@lid'] }), /حدد/);
    assert.equal(await downloadProfile('https://evil.example/image.jpg', path.join(root, 'profile')), false, 'profile photo downloader rejects non-WhatsApp hostnames');
    console.log('whatsapp-contacts: ok (numeric JID allowlist, import/update, local-name preservation, sync metadata, unsafe profile URL rejection)');
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
})().catch(error => { console.error(error); process.exitCode = 1; });
