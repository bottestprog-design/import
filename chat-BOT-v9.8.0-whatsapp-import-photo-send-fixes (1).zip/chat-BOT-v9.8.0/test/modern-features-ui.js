'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'public/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'public/styles.css'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const store = fs.readFileSync(path.join(root, 'src/store.js'), 'utf8');
const checks = [
  ['8.6-style grouped vertical sidebar', app.includes('class="workspace-layout"') && app.includes('class="sidebar"') && app.includes("title: 'مساحة العمل'") && app.includes("title: 'الإضافات الجديدة'")],
  ['legacy header session and connection status preserved', app.includes('id="sessionSelect"') && app.includes('class="status-pill') && app.includes('id="modeToggleBtn"')],
  ['new sections remain in navigation', app.includes("['tools', '⌘', 'المحركات الذكية']") && app.includes("['updates', '↗', 'التعديلات والإصدارات']") && app.includes("['assistant', '✧', 'المساعد المحلي']")],
  ['local assistant page UI is present', app.includes('id="localAssistantForm"') && app.includes('id="localAssistantMessages"') && app.includes('data-assistant-prompt')],
  ['local assistant endpoint is present', server.includes("app.post('/api/assistant/local'") && server.includes("source: 'local-rules'")],
  ['bulk recipient deletion UI and endpoint are wired', app.includes('id="deleteSelectedPeopleBtn"') && app.includes("api('/api/recipients/bulk', { method: 'DELETE'") && server.includes("app.delete('/api/recipients/bulk'")],
  ['personal reply settings UI and endpoint are wired', app.includes('data-person-reply-form') && app.includes('data-person-rule-match') && server.includes("app.put('/api/recipient/:id/reply-profile'")],
  ['personal replies enforce 30-rule limit', app.includes('existing.length >= 30') && server.includes('recipientReplies.validateReplyProfile')],
  ['upload maximum is 250 MiB and configurable default is 100 MiB', server.includes('fileSize: 250 * 1024 * 1024') && /maxImageSizeMB:\s*100/.test(store) && /maxImageSizeMB[^\n]*1, 250/.test(store)],
  ['release log includes 9.4 and 9.5 repairs', app.includes("version: 'v9.4.0'") && app.includes("version: 'v9.5.0'") && app.includes('حذف جماعي') && app.includes('مزامنة جهات WhatsApp') && app.includes('ردود شخصية')],
  ['sidebar and assistant responsive styles are included', css.includes('.sidebar{') && css.includes('.workspace-layout{display:grid;grid-template-columns:228px minmax(0,1fr)') && css.includes('@media(max-width:850px)') && css.includes('.assistant-companion')],
  ['assistant helper opens assistant page', app.includes("$('#assistantSpeechOpen')?.addEventListener('click', () => go('assistant'))")],
];
let failed = false;
for (const [label, ok] of checks) {
  console.log(`${ok ? 'OK' : 'FAIL'} modern feature ${label}`);
  if (!ok) failed = true;
}
if (failed) process.exit(1);
