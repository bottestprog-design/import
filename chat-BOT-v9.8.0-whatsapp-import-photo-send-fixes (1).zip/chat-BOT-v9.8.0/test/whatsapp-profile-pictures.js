'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { ensureContactPicture, downloadProfile, isAllowedProfileUrl, profileKey, syncContacts } = require('../src/whatsapp-contacts');

function headers(values) { return { get: name => values[String(name).toLowerCase()] || null }; }
function response({ status = 200, contentType = 'image/jpeg', location = '', bytes = Buffer.from([0xff, 0xd8, 0xff, 0xd9]) } = {}) {
  return { status, ok: status >= 200 && status < 300, headers: headers({ 'content-type': contentType, 'content-length': String(bytes.length), location }), arrayBuffer: async () => bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) };
}
(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-wa-photo-'));
  const originalFetch = global.fetch;
  try {
    assert.equal(isAllowedProfileUrl('https://pps.whatsapp.net/profile'), true);
    assert.equal(isAllowedProfileUrl('https://cdn.fbcdn.net/profile'), true);
    assert.equal(isAllowedProfileUrl('https://evil.example/photo.jpg'), false);
    assert.equal(isAllowedProfileUrl('http://pps.whatsapp.net/photo.jpg'), false);
    assert.equal(isAllowedProfileUrl('https://127.0.0.1/photo.jpg'), false);

    let fetchCount = 0;
    global.fetch = async url => {
      fetchCount++;
      if (String(url) === 'https://pps.whatsapp.net/start') return response({ status: 302, location: 'https://media.whatsapp.net/profile.jpg' });
      if (String(url) === 'https://media.whatsapp.net/profile.jpg') return response();
      throw new Error('unexpected URL');
    };
    const profileDir = path.join(root, 'profiles');
    const store = {
      safeSessionId: value => String(value || 'main'),
      getPaths: () => ({ dir: root, profiles: profileDir }),
    };
    const whatsapp = { getContactProfilePictureUrl: async (_id, jid) => { assert.match(jid, /^9689000000\d@c\.us$/); return 'https://pps.whatsapp.net/start'; } };
    const picture = await ensureContactPicture({ store, whatsapp, sessionId: 'main', jid: '96890000000@c.us' });
    assert.equal(picture.filename, `${profileKey('96890000000@c.us')}.jpg`);
    assert.equal(picture.cached, false);
    assert.ok(fs.statSync(path.join(profileDir, picture.filename)).size > 0);
    const again = await ensureContactPicture({ store, whatsapp, sessionId: 'main', jid: '96890000000@c.us' });
    assert.equal(again.cached, true);
    assert.equal(fetchCount, 2, 'cached profile must avoid repeated CDN calls');
    const concurrentStart = fetchCount;
    const concurrentJid = '96890000001@c.us';
    const parallel = await Promise.all([
      ensureContactPicture({ store, whatsapp, sessionId: 'main', jid: concurrentJid, refresh: true }),
      ensureContactPicture({ store, whatsapp, sessionId: 'main', jid: concurrentJid, refresh: true }),
    ]);
    assert.ok(parallel.every(item => item?.filename), 'concurrent avatar requests should return the cached local picture');
    assert.equal(fetchCount - concurrentStart, 2, 'identical concurrent profile requests must share one CDN redirect/download chain');
    await assert.rejects(() => ensureContactPicture({ store, whatsapp, sessionId: 'main', jid: '112233@lid' }), /غير صالح/);

    let maliciousFetchCount = 0;
    global.fetch = async () => { maliciousFetchCount++; return response({ status: 302, location: 'https://evil.example/collect' }); };
    const rejected = await downloadProfile('https://pps.whatsapp.net/redirect', path.join(profileDir, 'untrusted'));
    assert.equal(rejected, false);
    assert.equal(maliciousFetchCount, 1, 'must refuse an untrusted redirect without following it');

    // A CDN may return a real JPEG with a generic MIME type. Its validated binary
    // signature should take precedence, so valid avatars do not disappear.
    global.fetch = async () => response({ contentType: 'application/octet-stream' });
    const genericMimePhoto = await downloadProfile('https://pps.whatsapp.net/generic-mime', path.join(profileDir, 'generic-mime-photo'));
    assert.equal(genericMimePhoto, 'generic-mime-photo.jpg');
    assert.ok(fs.statSync(path.join(profileDir, genericMimePhoto)).size > 0);

    // Exercise selected-contact synchronization, including avatar files and current profile names.
    const syncRoot = path.join(root, 'sync');
    const syncProfileDir = path.join(syncRoot, 'profiles');
    let activeFetches = 0, maxFetches = 0;
    global.fetch = async url => {
      activeFetches++;
      maxFetches = Math.max(maxFetches, activeFetches);
      await new Promise(resolve => setTimeout(resolve, 8));
      activeFetches--;
      assert.match(String(url), /^https:\/\/pps\.whatsapp\.net\//);
      return response();
    };
    const syncJids = Array.from({ length: 7 }, (_, i) => `9689000000${i}@c.us`);
    let syncedSession = { id: 'main', recipients: [], groups: [], settings: {}, automation: { tasks: [], rules: [] }, interaction: { rules: [] }, logs: [] };
    const syncStore = {
      safeSessionId: value => String(value || 'main'),
      loadSession: () => JSON.parse(JSON.stringify(syncedSession)),
      saveSession: value => { syncedSession = JSON.parse(JSON.stringify(value)); return JSON.parse(JSON.stringify(syncedSession)); },
      getPaths: () => ({ dir: syncRoot, profiles: syncProfileDir }),
    };
    const syncWhatsApp = {
      listContacts: async (_id, options) => syncJids.filter(jid => options.onlyJids.includes(jid)).map((jid, i) => ({
        jid, digits: jid.split('@')[0], name: `اسم الدفتر ${i}`, pushname: `اسم الملف الحالي ${i}`,
        isMyContact: true, profilePicUrl: `https://pps.whatsapp.net/avatar-${i}.jpg`,
      })),
    };
    const syncPhones = { parse: value => { const digits = String(value).replace(/\D/g, ''); return { digits, e164: `+${digits}`, international: `+${digits}`, formatted: `+${digits}`, country: 'OM' }; } };
    const synced = await syncContacts({ store: syncStore, whatsapp: syncWhatsApp, phones: syncPhones, sessionId: 'main', jids: syncJids, importMissing: true, updateNames: false, updatePictures: true });
    assert.equal(synced.imported.length, syncJids.length);
    assert.equal(synced.photosUpdated, syncJids.length, 'every valid WhatsApp avatar should be saved locally during sync');
    assert.ok(maxFetches > 1 && maxFetches <= 4, `profile download pool must use bounded parallelism (observed ${maxFetches})`);
    assert.ok(syncedSession.recipients.every(person => fs.existsSync(path.join(syncProfileDir, person.whatsappProfilePhoto))), 'synced profile photos must exist in session storage');
    assert.equal(syncedSession.recipients[0].whatsappPushname, 'اسم الملف الحالي 0', 'current WhatsApp profile name must be preserved separately from address-book name');
    const overLimitJids = Array.from({ length: 101 }, (_, i) => `${96890000000 + i}@c.us`);
    await assert.rejects(() => syncContacts({ store: syncStore, whatsapp: syncWhatsApp, phones: syncPhones, sessionId: 'main', jids: overLimitJids, importMissing: true, updateNames: false, updatePictures: true }), /100 جهة/);

    const whatsappSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'whatsapp.js'), 'utf8');
    assert.match(whatsappSource, /async getContactProfilePictureUrl\(id, jid\)/, 'WhatsApp manager must resolve profile pictures from the real client');
    assert.match(whatsappSource, /getContactById\(normalized\)/, 'profile lookup should query the exact verified contact first');
    assert.match(whatsappSource, /const names = contact\?\.isMyContact \? \[localName, pushname, notifyName, shortName\] : \[pushname, notifyName, localName, shortName\]/, 'saved contacts prefer their address-book name while unsaved contacts prefer their profile name');
    assert.match(whatsappSource, /if \(direct\) return direct;[\s\S]{0,240}mapped LID/, 'an empty direct profile lookup must continue to the verified LID fallback');
    assert.match(whatsappSource, /Promise\.all\(workers\)/, 'bulk profile lookup uses bounded concurrency');
    console.log('whatsapp-profile-pictures: ok (profile URLs, safe redirects/cache, verified JIDs, current names, bounded parallel photo sync, and selected-contact limits)');
  } finally {
    global.fetch = originalFetch;
    fs.rmSync(root, { recursive: true, force: true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
