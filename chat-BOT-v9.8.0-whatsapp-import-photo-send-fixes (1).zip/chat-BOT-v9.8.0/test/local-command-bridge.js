'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { LocalCommandBridge, parseCommandFields } = require('../src/local-command-bridge');
const clone = x => JSON.parse(JSON.stringify(x));
function harness() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chatbot-command-bridge-'));
  let saved = {
    id: 'main', name: 'الرئيسية', recipients: [
      { id: 'ahmed', name: 'أحمد', digits: '96890000000', phone: '96890000000', e164: '+96890000000', international: '+968 9000 0000', enabled: true },
      { id: 'sara', name: 'سارة', digits: '96891111111', e164: '+96891111111', enabled: true },
    ],
    groups: [{ id: 'family', name: 'العائلة', gid: '120363000000-123@g.us', enabled: true }],
    settings: { timezone: 'Asia/Muscat', interactionEnabled: true, automationEnabled: true, maxImageSizeMB: 100 },
    interaction: { enabled: true, rules: [] }, automation: { enabled: true, tasks: [] },
    cycle: { manualGuard: {} }, stats: {}, logs: [],
  };
  const store = {
    safeSessionId: v => String(v || 'main'),
    loadSession: () => clone(saved), saveSession: x => { saved = clone(x); return clone(saved); },
    getPaths: () => ({ dir: root, media: root, images: root, profiles: path.join(root, 'profiles') }),
    normalizeAutomationTask: x => ({ ...clone(x), id: x.id || 'task-1', targetKeys: [...(x.targetKeys || [])], mediaIds: [...(x.mediaIds || [])] }),
    current: () => clone(saved),
  };
  const calls = { sends: [], media: [], scheduled: [], groups: [], savedGroups: [], profileSync: [] };
  const whatsapp = {
    resolveChatId: async (_id, target) => `${target.digits || target.phone}@c.us`,
    sendText: async (id, jid, text) => { calls.sends.push({ id, jid, text }); return { __chatBotAck: { status: 'confirmed' } }; },
    sendMedia: async (id, jid, file, opts) => { calls.media.push({ id, jid, file, opts }); return { __chatBotAck: { status: 'confirmed' } }; },
    listGroups: async () => [{ gid: '120363000001-22@g.us', name: 'فريق' }],
    getGroupInfo: async (_id, gid) => ({ gid, name: 'العائلة', participantsCount: 5 }),
    analyzeGroupInvite: async () => ({ gid: '120363000001-22@g.us', name: 'فريق', participantsCount: 3 }),
    listContacts: async () => [{ jid: '96892222222@c.us', digits: '96892222222', name: 'ريم', pushname: 'Reem WA', notifyName: 'Reem', isMyContact: true }],
  };
  const delivery = {
    files: () => [{ id: 'img.1.jpg', filename: 'img.1.jpg', isImage: true, size: 1200, ext: '.jpg' }, { id: 'guide.pdf', filename: 'guide.pdf', isImage: false, size: 8192, ext: '.pdf' }],
    sendNow: async (id, options) => { calls.scheduled.push({ id, ...clone(options) }); return { ok: true, sent: [{ target: 'أحمد', image: options.mediaIds?.[0] || '' }], failed: [] }; },
    scheduledTaskRun: async (_id, task) => ({ sent: [{ target: 'أحمد' }], failed: [], taskId: task.id }),
  };
  const phones = { parse: raw => { const digits = String(raw).replace(/\D/g, ''); if (digits.length < 8) throw new Error('bad number'); return { digits, e164: `+${digits}`, international: `+${digits}` }; } };
  const bridge = new LocalCommandBridge({ store, whatsapp, delivery, phones, log: () => {}, saveGroup: (_id, group) => { calls.savedGroups.push(group); return group; }, normalizeAutomationPayload: (_id, task) => store.normalizeAutomationTask(task) });
  return { root, store, bridge, calls };
}
(async () => {
  const parsed = parseCommandFields('أرسل الآن | إلى=أحمد، سارة | الرسالة=مرحبًا | ملف=img.1.jpg');
  assert.equal(parsed.fields.targets, 'أحمد، سارة');
  assert.equal(parsed.fields.message, 'مرحبًا');
  assert.equal(parsed.fields.files, 'img.1.jpg');

  const h = harness();
  let r = await h.bridge.handle('main', 'أرسل الآن | إلى=أحمد | الرسالة=مرحبًا من الأمر المباشر | ملف=img.1.jpg');
  assert.equal(r.handled, true);
  assert.match(r.response, /لم يُنفّذ الأمر بعد/);
  assert.equal(h.calls.sends.length, 0, 'sending must wait for explicit confirmation');
  assert.equal(h.calls.scheduled.length, 0);
  r = await h.bridge.handle('main', 'تأكيد الإرسال');
  assert.equal(r.handled, true);
  assert.match(r.response, /نجح: 1/);
  assert.equal(h.calls.scheduled.length, 1);
  assert.deepEqual(h.calls.scheduled[0].targetKeys, ['r:ahmed']);
  assert.deepEqual(h.calls.scheduled[0].mediaIds, ['img.1.jpg']);

  r = await h.bridge.handle('main', 'أضف شخص | الاسم=ليلى | الدولة=OM | الرقم=+96894444444');
  assert.match(r.response, /لم تُحفظ الجهة بعد/);
  assert.equal(h.store.current().recipients.length, 2, 'single-line recipient creation must wait for confirmation');
  r = await h.bridge.handle('main', 'تأكيد الحفظ');
  assert.match(r.response, /تمت إضافة «ليلى»/);
  assert.ok(h.store.current().recipients.some(person => person.name === 'ليلى' && person.digits === '96894444444'));
  assert.match((await h.bridge.handle('main', 'اعرض الأشخاص')).response, /ليلى/);
  assert.match((await h.bridge.handle('main', 'اعرض المجموعات')).response, /العائلة/);

  await h.bridge.handle('main', 'أضف موعد | الاسم=تذكير | التكرار=مرة | التاريخ=2026-11-01 | الوقت=17:30 | إلى=أحمد | الرسالة=رسالة الموعد');
  assert.equal(h.store.current().automation.tasks.length, 0, 'task waits for confirmation');
  r = await h.bridge.handle('main', 'تأكيد الحفظ');
  assert.match(r.response, /تم حفظ الموعد/);
  assert.equal(h.store.current().automation.tasks.length, 1);
  assert.equal(h.store.current().automation.tasks[0].date, '2026-11-01');

  await h.bridge.handle('main', 'أضف قاعدة تفاعل | الاسم=ترحيب | عندما=السلام عليكم | المطابقة=يحتوي | الرد=وعليكم السلام {{sender}}');
  assert.equal(h.store.current().interaction.rules.length, 0, 'interaction rule waits for confirmation');
  await h.bridge.handle('main', 'تأكيد الحفظ');
  assert.equal(h.store.current().interaction.rules[0].name, 'ترحيب');
  assert.equal(h.store.current().interaction.rules[0].when.value, 'السلام عليكم');

  r = await h.bridge.handle('main', 'اعرض المواعيد');
  assert.match(r.response, /تذكير/);
  r = await h.bridge.handle('main', 'اعرض الوسائط');
  assert.match(r.response, /img\.1\.jpg/);

  // Direct-to-number sends use a verified chat JID and send media as well as text.
  r = await h.bridge.handle('main', 'أرسل الآن | إلى=+96893333333 | الرسالة=رسالة مباشرة | ملف=guide.pdf');
  assert.match(r.response, /لم يُنفّذ الأمر بعد/);
  assert.equal(h.calls.sends.length, 0);
  r = await h.bridge.handle('main', 'تأكيد الإرسال');
  assert.match(r.response, /نجح: 1/);
  assert.equal(h.calls.sends.length, 1);
  assert.equal(h.calls.sends[0].jid, '96893333333@c.us');
  assert.equal(h.calls.sends[0].text, 'رسالة مباشرة');
  assert.equal(h.calls.media.length, 1);
  assert.equal(h.calls.media[0].opts.asDocument, true, 'PDF is sent as a document');

  // WhatsApp contact sync requires confirmation and saves profile names separately.
  r = await h.bridge.handle('main', 'مزامن ملفات WhatsApp | إلى=ريم');
  assert.match(r.response, /لم تتغير البيانات بعد/);
  assert.equal(h.store.current().recipients.length, 3, 'sync preview must not import before confirmation');
  r = await h.bridge.handle('main', 'تأكيد المزامنة');
  assert.match(r.response, /اكتملت المزامنة/);
  const reem = h.store.current().recipients.find(person => person.digits === '96892222222');
  assert.ok(reem, 'WhatsApp profile must be imported after explicit confirmation');
  assert.equal(reem.name, 'ريم');
  assert.equal(reem.whatsappPushname, 'Reem WA', 'current WhatsApp name stays in a separate field');
  assert.equal(h.store.current().recipients.find(person => person.id === 'ahmed').name, 'أحمد');

  r = await h.bridge.handle('main', 'فعّل тفاعل');
  assert.equal(r.handled, false, 'unknown typo must not mutate settings');
  r = await h.bridge.handle('main', 'اضبط المنطقة الزمنية | المنطقة=Asia/Dubai');
  assert.match(r.response, /Asia\/Dubai/);
  assert.equal(h.store.current().settings.timezone, 'Asia/Dubai');

  r = await h.bridge.handle('main', 'اكتشف المجموعات');
  assert.match(r.response, /عُثر على 1 مجموعة/);
  assert.equal(h.calls.savedGroups.length, 1);
  r = await h.bridge.handle('main', 'معلومات المجموعة | GID=120363000000-123@g.us');
  assert.match(r.response, /الأعضاء: 5/);

  r = await h.bridge.handle('main', 'احذف الموعد تذكير');
  assert.match(r.response, /هل تريد حذف الموعد/);
  await h.bridge.handle('main', 'إلغاء');
  assert.equal(h.store.current().automation.tasks.length, 1, 'cancel protects tasks from unintended deletion');

  // A selected sync uses live JIDs, requests photos and never overwrites local names.
  const syncRoot = h.root;
  const contactsModule = require('../src/whatsapp-contacts');
  // The command path is verified separately through the injected listContacts adapter and module contract.
  assert.equal(typeof contactsModule.syncContacts, 'function');
  fs.rmSync(syncRoot, { recursive: true, force: true });
  console.log('local-command-bridge: ok (confirmed text/media sends, contact import/sync, schedules, interaction rules, group retrieval, settings, lists and safe cancellation)');
})().catch(error => { console.error(error); process.exitCode = 1; });
