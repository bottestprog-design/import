"use strict";

const fs = require('node:fs');
const path = require('node:path');
const express = require('express');
const multer = require('multer');

const store = require('./src/store');
const media = require('./src/media');
const phones = require('./src/phones');
const groups = require('./src/groups');
const backgrounds = require('./src/backgrounds');
const { WhatsAppManager, safeError, groupFromMessage } = require('./src/whatsapp');
const { DeliveryService } = require('./src/delivery');
const { InteractionEngine } = require('./src/interaction');
const { ReliableScheduler, nextRun, due, dueForItem, nextRunForItem } = require('./src/scheduler');
const { AutomationEngine, normalizeAutomationRule, normalizeMute } = require('./src/automation-engine');
const { logFactory, replyError, randomId } = require('./src/serverlib');
const { EventBus } = require('./src/event-bus');
const { CommandEngine } = require('./src/command-engine');
const { DictionaryEngine, normalizeDictionaryText } = require('./src/dictionary-engine');
const { parseVoiceCommand } = require('./src/voice-to-command');
const recipientReplies = require('./src/recipient-replies');
const recipientManagement = require('./src/recipient-management');
const { OwnerAssistant } = require('./src/owner-assistant');
const { LocalCommandBridge } = require('./src/local-command-bridge');
const whatsappContacts = require('./src/whatsapp-contacts');

const HOST = process.env.HOST || '127.0.0.1';
const PORT = store.toInt(process.env.PORT, 7005, 1, 65535);
const TEMP = path.join(store.DATA_DIR, '_temp');
fs.mkdirSync(TEMP, { recursive: true });

const log = logFactory(store);
const eventBus = new EventBus({ maxHistory: 500, logger: (type, detail) => log(null, 'WARN', `${type}: ${JSON.stringify(detail)}`) });
const commandEngine = new CommandEngine({ audit: entry => eventBus.publish('command.audit', entry).catch(() => {}) });
const dictionaryEngine = new DictionaryEngine();
const whatsapp = new WhatsAppManager({ store, log });
const delivery = new DeliveryService({ store, whatsapp, log });
const interaction = new InteractionEngine({ store, whatsapp, log });
const ownerAssistant = new OwnerAssistant({ store, whatsapp, phones, log });
const localCommandBridge = new LocalCommandBridge({ store, whatsapp, delivery, phones, log, saveGroup, normalizeAutomationPayload });
const automationEngine = new AutomationEngine({ store, whatsapp, log });
const scheduler = new ReliableScheduler({ store, run: id => delivery.scheduledRun(id), runTask: (id, task) => delivery.scheduledTaskRun(id, task), runAutomation: (id, now) => automationEngine.runDueRules(id, now, dueForItem), log });

function sid(req) {
  return store.safeSessionId(req.body?.sessionId || req.query?.sessionId || store.activeSessionId());
}
function boolValue(value, fallback = false) {
  if (value === undefined || value === null) return fallback;
  if (typeof value === 'boolean') return value;
  const x = String(value).trim().toLowerCase();
  if (['true', '1', 'yes', 'on', 'نعم', 'تشغيل', 'مفعّل'].includes(x)) return true;
  if (['false', '0', 'no', 'off', 'لا', 'إيقاف', 'متوقف'].includes(x)) return false;
  return fallback;
}
function uniqueStrings(values) {
  return [...new Set((Array.isArray(values) ? values : []).map(v => String(v || '').trim()).filter(Boolean))];
}
function validTargetKeys(session, keys) {
  const allowed = new Set([
    ...session.recipients.map(x => `r:${x.id}`),
    ...session.groups.map(x => `g:${x.id}`),
  ]);
  return uniqueStrings(keys).filter(k => allowed.has(k));
}
function normalizeRuleChatIds(chatIds) {
  return uniqueStrings(chatIds).map(v => v.toLowerCase());
}
function validIsoDate(value) {
  const x = String(value || '').trim(), m = x.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return false;
  const y = Number(m[1]), mo = Number(m[2]), d = Number(m[3]);
  if (mo < 1 || mo > 12 || d < 1 || d > 31) return false;
  const dt = new Date(Date.UTC(y, mo - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === mo - 1 && dt.getUTCDate() === d;
}
function saveGroup(id, info) {
  const s = store.loadSession(id);
  const n = store.normalizeGroup(info);
  n.gid = groups.normalizeGid(n.gid);
  if (!groups.isGroupId(n.gid)) throw new Error('GID المجموعة غير صالح.');
  const old = s.groups.find(x => x.gid === n.gid);
  if (old) {
    const enabled = old.enabled;
    const discoveredAt = old.discoveredAt;
    const before = JSON.stringify({ name: old.name, gid: old.gid, inviteCode: old.inviteCode, description: old.description, owner: old.owner, participantsCount: old.participantsCount, participants: old.participants, admins: old.admins, enabled });
    Object.assign(old, n, { enabled, discoveredAt, updatedAt: old.updatedAt || new Date().toISOString() });
    const after = JSON.stringify({ name: old.name, gid: old.gid, inviteCode: old.inviteCode, description: old.description, owner: old.owner, participantsCount: old.participantsCount, participants: old.participants, admins: old.admins, enabled });
    if (before !== after) { old.updatedAt = new Date().toISOString(); store.saveSession(s); log(id, 'INFO', `تم تحديث بيانات المجموعة: ${old.name || old.gid}`); }
    return old;
  }
  s.groups.push(n);
  s.setupComplete = true;
  store.saveSession(s);
  log(id, 'INFO', `تم ربط مجموعة جديدة: ${n.name || n.gid}`);
  return n;
}
function removeTargetFromSchedule(s, key) {
  const current = Array.isArray(s.settings.scheduleTargetKeys) ? s.settings.scheduleTargetKeys : [];
  const hadExplicitTargets = current.length > 0;
  s.settings.scheduleTargetKeys = current.filter(x => x !== key);
  if (hadExplicitTargets && s.settings.scheduleTargetKeys.length === 0) s.settings.scheduleEnabled = false;
}
function snapshot(id) {
  const s = store.loadSession(id);
  const scan = media.scan(store.getPaths(id).media, s.settings.maxImageSizeMB);
  return {
    version: store.APP_VERSION,
    session: { id: s.id, name: s.name, setupComplete: s.setupComplete },
    media: scan.files.map(x => ({ ...x, url: `/media/${encodeURIComponent(x.filename)}?sessionId=${encodeURIComponent(id)}` })),
    activeSessionId: store.activeSessionId(),
    sessions: store.listSessionIds().map(x => {
      const ss = store.loadSession(x);
      const runtime = whatsapp.listRuntime(x);
      const summary = media.quickSummary(store.getPaths(x).media);
      return { id: ss.id, name: ss.name, status: runtime.status, ready: runtime.ready, recipients: ss.recipients.filter(y => y.enabled !== false).length, groups: ss.groups.filter(y => y.enabled !== false).length, images: summary.images, files: summary.files };
    }),
    recipients: s.recipients,
    groups: s.groups,
    images: scan.images.map(x => ({ ...x, url: `/media/${encodeURIComponent(x.filename)}?sessionId=${encodeURIComponent(id)}` })),
    invalidImages: scan.invalid,
    duplicates: scan.duplicates,
    currentImage: delivery.currentImage(id),
    cycle: s.cycle,
    settings: s.settings,
    interaction: s.interaction,
    whatsapp: whatsapp.listRuntime(id),
    schedule: { ...due(new Date(), s), nextRun: nextRun(s) },
    automation: { enabled: s.automation.enabled !== false, tasks: (s.automation.tasks || []).map(t => ({ ...t, nextRun: nextRunForItem({ ...t, timezone: s.settings.timezone }) })), rules: s.automation.rules || [], mutes: s.automation.mutes || [], eventState: { totalMessages: Number(s.automation.eventState?.totalMessages || 0), chatCount: Object.keys(s.automation.eventState?.byChat || {}).length }, groupPermissions: s.settings.automationGroupPermissions || {}, recent: s.automation.recent || [] },
    background: {
      mode: s.settings.backgroundMode,
      imageName: s.settings.backgroundImage,
      imageUrl: s.settings.backgroundImage ? `/background/${encodeURIComponent(s.settings.backgroundImage)}?sessionId=${encodeURIComponent(id)}&v=${encodeURIComponent(s.updatedAt)}` : null,
      opacity: s.settings.backgroundOpacity,
      settings: s.settings.backgroundSettings,
    },
    stats: s.stats,
    lastRun: s.lastRun,
    logs: s.logs.slice(-60).reverse(),
  };
}

function localAssistantResponse(id, prompt) {
  const raw = String(prompt || '').trim().slice(0, 1000);
  if (!raw) throw new Error('اكتب سؤالك أو الأمر المحلي أولًا.');
  const query = normalizeDictionaryText(raw).replace(/[،.!؟?]+/gu, '').trim();
  const s = store.loadSession(id);
  const runtime = whatsapp.listRuntime(id);
  const p = query.replace(/\s+/g, ' ');
  const pageTargets = [
    { page: 'dashboard', words: ['الرئيسيه','الرئيسية','الداشبورد','dashboard'] },
    { page: 'send', words: ['الارسال','الإرسال','ارسال','send'] },
    { page: 'people', words: ['الاشخاص','الأشخاص','المستلمين','جهات الارسال','جهات الإرسال','people'] },
    { page: 'groups', words: ['المجموعات','groups'] },
    { page: 'interaction', words: ['التفاعل','الردود التلقائيه','الردود التلقائية','interaction'] },
    { page: 'automation', words: ['الاتمته','الأتمتة','الجدوله','الجدولة','automation'] },
    { page: 'session', words: ['الجلسه','الجلسة','الاتصال','واتساب','session'] },
    { page: 'settings', words: ['الاعدادات','الإعدادات','settings'] },
    { page: 'tools', words: ['المحركات الذكيه','المحركات الذكية','المحركات','tools'] },
    { page: 'guide', words: ['الدليل','المساعده','المساعدة','guide'] },
    { page: 'updates', words: ['التعديلات','الاصدارات','الإصدارات','سجل التغييرات','updates'] },
    { page: 'assistant', words: ['المساعد المحلي','المساعد','assistant'] },
    { page: 'owner-center', words: ['مركز المساعد','لوحة المساعد','owner center'] },
    { page: 'appearance', words: ['المظهر','الخلفيات'] },
    { page: 'operation', words: ['التشغيل المتقدم','اعدادات التشغيل','إعدادات التشغيل'] },
  ];
  const openMatch = p.match(/^(?:افتح|انتقل(?:\s+إلى)?|اذهب(?:\s+إلى)?|روح(?:\s+ل)?|وديني(?:\s+إلى)?|اعرض\s+صفحة)\s*(.*)$/u);
  if (openMatch) {
    const target = normalizeDictionaryText(openMatch[1]);
    const found = pageTargets.find(item => item.words.some(word => target === normalizeDictionaryText(word) || target.includes(normalizeDictionaryText(word))));
    if (found) return { reply: `سأفتح صفحة «${found.words[0]}». لم يتم تنفيذ أي إرسال أو تغيير خارجي.`, navigate: found.page };
    return { reply: 'لم أتعرف على اسم الصفحة. جرّب: الرئيسية، الإرسال، الأشخاص، المجموعات، التفاعل، الأتمتة، الجلسة، الإعدادات، المحركات الذكية، أو التعديلات.' };
  }

  if (/(?:الحاله|حاله النظام|حاله الاتصال|متصل|الاتصال|status)/u.test(p)) {
    const status = runtime.ready ? 'متصل' : runtime.status === 'qr' ? 'بانتظار مسح رمز QR' : runtime.status || 'غير متصل';
    const enabledRecipients = s.recipients.filter(x => x.enabled !== false).length;
    const enabledGroups = s.groups.filter(x => x.enabled !== false).length;
    return { reply: `حالة الجلسة «${s.name}»: ${status}.\nالأشخاص المفعّلون: ${enabledRecipients}/${s.recipients.length}.\nالمجموعات المفعّلة: ${enabledGroups}/${s.groups.length}.\nقواعد الرد: ${(s.interaction.rules || []).filter(x => x.enabled !== false).length} مفعّلة.\nمهام الأتمتة: ${(s.automation.tasks || []).filter(x => x.enabled !== false).length} مفعّلة.` };
  }
  if (/(?:كم|عدد|قائمة|اعرض|اسماء).*(?:الاشخاص|المستلمين|جهات الارسال)|(?:الاشخاص|المستلمين|جهات الارسال).*(?:كم|عدد|قائمة|اسماء)/u.test(p)) {
    const list = s.recipients.slice(0, 15).map(x => `• ${x.name || 'بدون اسم'} — ${x.international || x.e164 || x.phone || ''}${x.enabled === false ? ' (متوقف)' : ''}`);
    return { reply: `لديك ${s.recipients.length} شخص محفوظ في الجلسة الحالية.${list.length ? `\n${list.join('\n')}${s.recipients.length > list.length ? `\n... و${s.recipients.length - list.length} إضافي` : ''}` : '\nلم تضف أشخاصًا بعد.'}` };
  }
  if (/(?:كم|عدد|قائمة|اعرض|اسماء).*(?:المجموعات)|(?:المجموعات).*(?:كم|عدد|قائمة|اسماء)/u.test(p)) {
    const list = s.groups.slice(0, 15).map(x => `• ${x.name || x.gid} — ${x.gid || ''}`);
    return { reply: `لديك ${s.groups.length} مجموعة محفوظة.${list.length ? `\n${list.join('\n')}${s.groups.length > list.length ? `\n... و${s.groups.length - list.length} إضافي` : ''}` : '\nلم تربط أي مجموعة بعد.'}` };
  }
  if (/(?:قواعد|الردود|التفاعل)/u.test(p)) {
    const rules = s.interaction.rules || [];
    return { reply: `قواعد التفاعل في الجلسة الحالية: ${rules.length}.\nالمفعّل: ${rules.filter(x => x.enabled !== false).length}.\nالمتوقف: ${rules.filter(x => x.enabled === false).length}.\nيمكنك فتح صفحة «التفاعل» لمراجعة القواعد وتعديلها.` , navigate: /(?:افتح|انتقل)/u.test(p) ? 'interaction' : undefined };
  }
  if (/(?:المواعيد|مهام الاتمته|الجدوله|الجدولة|الاتمته|الأتمتة|automation)/u.test(p)) {
    return { reply: `لديك ${(s.automation.tasks || []).length} موعدًا محفوظًا، و${(s.automation.rules || []).length} قاعدة أتمتة.\nلا أغيّر المواعيد من هذه المحادثة؛ افتح صفحة الأتمتة لمراجعتها قبل تعديلها.`, navigate: 'automation' };
  }
  if (/(?:سجل النشاط|اخر العمليات|آخر العمليات|السجل)/u.test(p)) {
    const rows = (s.logs || []).slice(-6).reverse().map(x => `• ${x.at || x.time || ''} ${x.level || ''} ${x.message || x.text || ''}`.trim());
    return { reply: rows.length ? `آخر الأنشطة المسجلة:\n${rows.join('\n')}` : 'لا توجد أنشطة مسجلة في هذه الجلسة حتى الآن.', navigate: 'owner-center' };
  }
  const defMatch = p.match(/^(?:ما معنى|معنى|تعريف|عرف|اشرح مصطلح)\s+(.+)$/u);
  if (defMatch) {
    const entry = dictionaryEngine.lookup(defMatch[1]);
    return entry ? { reply: `${entry.term}\n${entry.definition || 'لا يوجد تعريف محفوظ لهذا المصطلح.'}` } : { reply: `لم أجد تعريفًا محفوظًا لـ «${defMatch[1]}» في القاموس المحلي الحالي. القاموس لا يخترع تعريفات غير موجودة.` };
  }
  if (/^(?:مساعدة|الاوامر|ساعدني|help)$/u.test(p)) {
    return { reply: 'أنا مساعد محلي يعتمد على أوامر وقواعد معروفة، ولا أتصل بخدمة ذكاء اصطناعي خارجية.\nجرّب: «الحالة»، «قائمة الأشخاص»، «قائمة المجموعات»، «قواعد التفاعل»، «الأتمتة»، «سجل النشاط»، أو «افتح الإعدادات».\nيمكن تحليل أوامر مكتوبة أو مفرّغة من الصوت في صفحة المحركات الذكية. لا أنفّذ حذفًا أو إرسالًا من هذه المحادثة.' };
  }
  const parsed = parseVoiceCommand(raw, { locale: 'ar', confidence: 1, minConfidence: .72 });
  if (parsed.accepted) {
    const description = { mute: 'كتم الإشعارات', unmute: 'إلغاء الكتم', archive: 'أرشفة محادثة', 'delete-message': 'حذف رسالة', help: 'مساعدة', status: 'حالة النظام' }[parsed.intent] || parsed.intent;
    return { reply: `تعرفت على الأمر: ${description}${parsed.targetText ? `\nالهدف النصي: ${parsed.targetText}` : ''}.\nهذا تحليل فقط؛ لم يتم تنفيذ أي إجراء على WhatsApp.${parsed.requiresConfirmation ? '\nهذا الإجراء يحتاج مراجعة وتأكيدًا صريحًا.' : ''}`, parsed, navigate: parsed.intent === 'status' ? 'owner-center' : undefined };
  }
  return { reply: 'لم أتعرف على هذا السؤال ضمن الأوامر المحلية المدعومة. افتح «الدليل والمساعدة» أو اختر أحد الأوامر المقترحة. هذا المساعد لا يدّعي إجابة عامة ولا يستدعي API خارجيًا.' };
}

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '6mb' }));
app.use(express.urlencoded({ extended: true, limit: '6mb' }));
app.use(express.static(path.join(store.ROOT, 'public')));

app.get('/api/health', (_req, res) => res.json({ ok: true, version: store.APP_VERSION, time: new Date().toISOString(), node: process.version }));
app.get('/api/architecture/health', (_req, res) => res.json({ ok: true, version: store.APP_VERSION, modules: { eventBus: eventBus.stats(), commandEngine: commandEngine.list().length, dictionaryEngine: dictionaryEngine.entries.size, voiceParser: true, persistence: 'session-json-local', productionScaleAdapter: 'not configured' } }));
app.post('/api/voice/parse', (req, res) => { try { const parsed = parseVoiceCommand(req.body?.transcript, { locale: req.body?.locale || 'ar', confidence: req.body?.confidence ?? 1, minConfidence: req.body?.minConfidence ?? .72 }); res.json({ ok: true, parsed, message: parsed.requiresConfirmation ? 'يتطلب هذا الأمر تأكيدًا صريحًا قبل التنفيذ.' : undefined }); } catch (e) { replyError(res, e, 422); } });
app.post('/api/assistant/local', (req, res) => { try { const result = localAssistantResponse(sid(req), req.body?.prompt); res.json({ ok: true, ...result, source: 'local-rules' }); } catch (e) { replyError(res, e, 422); } });
app.get('/api/dictionary/lookup', (req, res) => { const entry = dictionaryEngine.lookup(req.query?.q); res.json({ ok: true, entry }); });
app.get('/api/dictionary', (req, res) => res.json({ ok: true, entries: dictionaryEngine.list({ query: req.query?.q || '', limit: Number(req.query?.limit) || 100, offset: Number(req.query?.offset) || 0 }) }));
app.get('/api/state', (req, res) => { try { res.json({ ok: true, ...snapshot(sid(req)) }); } catch (e) { replyError(res, e, 500); } });
app.get('/api/countries', (_req, res) => { try { res.json({ ok: true, countries: phones.countries() }); } catch (e) { replyError(res, e, 500); } });
app.post('/api/phone/validate', (req, res) => { try { const country = String(req.body?.country || 'OM').toUpperCase(); const phone = phones.parse(req.body?.phone || '', country); res.json({ ok: true, valid: true, phone }); } catch (e) { res.status(422).json({ ok: false, valid: false, error: safeError(e) }); } });
app.get('/api/whatsapp/contacts', async (req, res) => {
  try {
    const id = sid(req), contacts = await whatsapp.listContacts(id, { limit: 2000 });
    // Do not expose expiring CDN links to the browser. The browser requests a cached local image lazily.
    res.json({ ok: true, sessionId: id, count: contacts.length, contacts: contacts.map(({ profilePicUrl, ...item }) => ({ ...item, pictureUrl: `/api/whatsapp/contact-picture?sessionId=${encodeURIComponent(id)}&jid=${encodeURIComponent(item.jid)}` })), message: `تم استدعاء ${contacts.length} جهة من WhatsApp، مع الاسم الظاهر في واتساب ورابط محلي آمن للصورة الشخصية.` });
  } catch (e) { replyError(res, e, 422); }
});
app.get('/api/whatsapp/contact-picture', async (req, res) => {
  const id = sid(req), jid = String(req.query?.jid || '').trim().toLowerCase();
  if (!/^\d{5,25}@c\.us$/.test(jid)) return res.status(400).end();
  try {
    const picture = await whatsappContacts.ensureContactPicture({ store, whatsapp, sessionId: id, jid, refresh: req.query?.refresh === '1' });
    if (!picture?.filename) { res.setHeader('Cache-Control', 'no-store'); res.setHeader('X-Chat-BOT-Photo', 'unavailable-or-private'); return res.status(404).end(); }
    const file = media.safePath(store.getPaths(id).profiles, picture.filename);
    if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return res.status(404).end();
    res.setHeader('Cache-Control', 'private, max-age=3600');
    res.type(path.extname(file));
    res.sendFile(file, error => { if (error && !res.headersSent) res.status(404).end(); });
  } catch (e) {
    log(id, 'DEBUG', `صورة جهة WhatsApp غير متاحة (${jid}): ${safeError(e)}`);
    res.setHeader('Cache-Control', 'no-store');
    res.status(404).end();
  }
});
app.post('/api/whatsapp/contact/import', async (req, res) => {
  try {
    const id = sid(req), jid = String(req.body?.jid || '').trim().toLowerCase();
    if (!/^\d{5,25}@c\.us$/.test(jid)) throw new Error('معرّف جهة WhatsApp غير صالح. استدعِ القائمة واختر جهة ظاهرة فيها.');
    const result = await whatsappContacts.syncContacts({ store, whatsapp, phones, sessionId: id, jids: [jid], importMissing: true, updateNames: false, updatePictures: true });
    const ids = [...new Set([...(result.imported || []), ...(result.updated || [])].map(person => String(person.id || '')).filter(Boolean))];
    log(id, 'INFO', `إضافة جهة من قائمة WhatsApp: ${result.imported.length} جديدة، ${result.updated.length} موجودة، صور ${result.photosUpdated}.`);
    res.json({ ok: true, ...result, addedToSendList: ids });
  } catch (e) { replyError(res, e, 422); }
});
app.post('/api/whatsapp/contacts/sync', async (req, res) => {
  try {
    const id = sid(req), jids = uniqueStrings(req.body?.jids).slice(0, 500);
    const updatePictures = boolValue(req.body?.updatePictures, false);
    if (!jids.length) throw new Error('حدد جهات WhatsApp للمزامنة أولًا.');
    if (updatePictures && jids.length > 100) throw new Error('مزامنة الصور محدودة بـ 100 جهة في المرة الواحدة؛ قسّم الاختيارات إلى دفعات.');
    const result = await whatsappContacts.syncContacts({ store, whatsapp, phones, sessionId: id, jids, importMissing: boolValue(req.body?.importMissing, true), updateNames: boolValue(req.body?.updateNames, false), updatePictures });
    log(id, 'INFO', `مزامنة جهات WhatsApp: جديد ${result.imported.length}، حدّث ${result.updated.length}، صور ${result.photosUpdated}.`);
    res.json({ ok: true, ...result });
  } catch (e) { replyError(res, e, 422); }
});

app.get('/api/diagnostics', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), p = store.getPaths(id), scan = media.scan(p.media, s.settings.maxImageSizeMB), runtime = whatsapp.listRuntime(id);
    res.json({ ok: true, version: store.APP_VERSION, checks: {
      session: true, mediaFolder: fs.existsSync(p.media), authFolder: fs.existsSync(p.auth), mediaCount: scan.files.length,
      groups: s.groups.length, recipients: s.recipients.length, interactionRules: s.interaction.rules.length, whatsapp: !!runtime.ready,
      scheduleTargets: validTargetKeys(s, s.settings.scheduleTargetKeys).length, compatPatched: true,
    }, runtime, dependency: 'whatsapp-web.js 1.34.7' });
  } catch (e) { replyError(res, e, 500); }
});

const upload = multer({ dest: TEMP, limits: { files: 100, fileSize: 250 * 1024 * 1024 } });
const bgUpload = multer({ dest: TEMP, limits: { fileSize: 15 * 1024 * 1024, files: 1 } });

app.post('/api/sessions', (req, res) => { try { const s = store.createSession(req.body?.name); res.json({ ok: true, session: { id: s.id, name: s.name } }); } catch (e) { replyError(res, e); } });
app.post('/api/sessions/switch', async (req, res) => {
  try {
    const target = store.safeSessionId(req.body?.sessionId);
    if (!store.listSessionIds().includes(target)) throw new Error('الجلسة غير موجودة.');
    const s = store.setActiveSession(target);
    if (s.settings.autoStartSession && whatsapp.hasSavedAuth(target) && !whatsapp.listRuntime(target).ready) whatsapp.start(target).catch(err => log(target, 'WARN', `تعذر تشغيل الجلسة عند التبديل: ${safeError(err)}`));
    res.json({ ok: true, session: s.id });
  } catch (e) { replyError(res, e); }
});
app.put('/api/sessions/:id', (req, res) => { try { res.json({ ok: true, session: store.renameSession(req.params.id, req.body?.name) }); } catch (e) { replyError(res, e); } });
app.delete('/api/sessions/:id', async (req, res) => { try { await whatsapp.stop(req.params.id, { clearAuth: true }); res.json({ ok: true, ...store.deleteSession(req.params.id) }); } catch (e) { replyError(res, e); } });

app.post('/api/session/connect', async (req, res) => { try { const runtime = await whatsapp.start(sid(req)); res.json({ ok: true, runtime, message: runtime.ready ? 'الجلسة جاهزة.' : 'تم بدء الاتصال؛ امسح QR إذا ظهر.' }); } catch (e) { replyError(res, e); } });
app.post('/api/session/stop', async (req, res) => { try { await whatsapp.stop(sid(req)); res.json({ ok: true }); } catch (e) { replyError(res, e); } });
app.post('/api/session/unlink', async (req, res) => { try { await whatsapp.stop(sid(req), { clearAuth: true }); res.json({ ok: true }); } catch (e) { replyError(res, e); } });

app.post('/api/recipient', (req, res) => {
  try {
    const s = store.loadSession(sid(req));
    const parsed = phones.parse(req.body?.phone, String(req.body?.country || 'OM'));
    const name = String(req.body?.name || '').trim();
    if (!name) throw new Error('اكتب اسم المستلم.');
    if (s.recipients.some(x => x.phone === parsed.digits || x.e164 === parsed.e164)) throw new Error('الرقم مكرر في الجلسة.');
    const recipient = { id: randomId(), name: name.slice(0, 80), ...parsed, enabled: true };
    s.recipients.push(recipient); s.setupComplete = true;
    store.saveSession(s); res.json({ ok: true, recipient });
  } catch (e) { replyError(res, e); }
});
app.post('/api/recipients/bulk', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), parsed = phones.parseMany(req.body?.lines, String(req.body?.country || 'OM'));
    const added = [];
    for (const item of parsed.out) {
      if (s.recipients.some(x => x.phone === item.digits || x.e164 === item.e164)) continue;
      const { name, ...number } = item;
      added.push({ id: randomId(), name, ...number, enabled: true });
    }
    s.recipients.push(...added); if (added.length) s.setupComplete = true; store.saveSession(s);
    res.json({ ok: true, added, failed: parsed.failed, skippedDuplicates: parsed.out.length - added.length });
  } catch (e) { replyError(res, e); }
});
app.post('/api/recipient/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), r = s.recipients.find(x => x.id === req.params.id); if (!r) throw new Error('المستلم غير موجود.'); r.enabled = !r.enabled; store.saveSession(s); res.json({ ok: true, enabled: r.enabled }); } catch (e) { replyError(res, e); } });
app.get('/api/recipient/:id/reply-profile', (req, res) => { try { const s = store.loadSession(sid(req)), r = s.recipients.find(x => x.id === req.params.id); if (!r) throw new Error('المستلم غير موجود.'); res.json({ ok: true, profile: recipientReplies.normalizeReplyProfile(r.replyProfile) }); } catch (e) { replyError(res, e); } });
app.put('/api/recipient/:id/reply-profile', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), r = s.recipients.find(x => x.id === req.params.id);
    if (!r) throw new Error('المستلم غير موجود.');
    r.replyProfile = recipientReplies.validateReplyProfile(req.body?.profile);
    store.saveSession(s);
    res.json({ ok: true, profile: r.replyProfile, message: 'تم حفظ إعداد الرد الخاص بالشخص.' });
  } catch (e) { replyError(res, e, 422); }
});
app.delete('/api/recipients/bulk', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), result = recipientManagement.deleteRecipients(s, req.body?.ids);
    store.saveSession(s);
    log(s.id, 'INFO', `حذف جماعي: تم حذف ${result.deleted.length} شخصًا وتنظيف الأهداف المرتبطة.${result.scheduleDisabledToPreventWidening ? ' تم إيقاف الجدولة لأن جميع أهدافها المحددة حُذفت.' : ''}`);
    res.json({ ok: true, ...result, message: `تم حذف ${result.deleted.length} شخصًا وتنظيف الأهداف المرتبطة بالجدولة والأتمتة.${result.scheduleDisabledToPreventWidening ? ' أوقفت الجدولة تلقائيًا لأن أهدافها المحددة حُذفت، لتجنب توسيعها وإرسالها لجهات أخرى.' : ''}` });
  } catch (e) { replyError(res, e, 422); }
});
app.delete('/api/recipient/:id', (req, res) => {
  try { const s = store.loadSession(sid(req)), key = `r:${req.params.id}`, before = s.recipients.length; s.recipients = s.recipients.filter(x => x.id !== req.params.id); if (before === s.recipients.length) throw new Error('المستلم غير موجود.'); removeTargetFromSchedule(s, key); s.automation.tasks = (s.automation.tasks || []).map(t => ({ ...t, targetKeys: (t.targetKeys || []).filter(k => k !== key) })); store.saveSession(s); res.json({ ok: true }); }
  catch (e) { replyError(res, e); }
});

app.post('/api/groups/discover', async (req, res) => { try { const id = sid(req), found = await whatsapp.listGroups(id), saved = found.filter(x => x.gid).map(x => saveGroup(id, x)); res.json({ ok: true, found: found.length, saved, message: `تم اكتشاف ${saved.length} مجموعة في هذه الجلسة.` }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/refresh-all', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), saved = [], failed = [];
    for (const g of s.groups) { try { saved.push(saveGroup(id, await whatsapp.getGroupInfo(id, g.gid))); } catch (e) { failed.push({ id: g.id, name: g.name, error: safeError(e) }); } }
    res.json({ ok: true, saved, failed, message: failed.length ? `تم تحديث ${saved.length} مجموعة، وتعذر تحديث ${failed.length}.` : 'تم تحديث المجموعات.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/groups/add-gid', async (req, res) => { try { const id = sid(req), gid = groups.normalizeGid(req.body?.gid); if (!groups.isGroupId(gid)) throw new Error('GID المجموعة غير صالح.'); const info = await whatsapp.getGroupInfo(id, gid); res.json({ ok: true, group: saveGroup(id, info), message: 'تمت إضافة المجموعة إلى هذه الجلسة.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/connect', async (req, res) => {
  try {
    const id = sid(req), value = String(req.body?.value || '').trim();
    if (!value) throw new Error('أدخل GID أو رابط دعوة.');
    let info;
    if (/chat\.whatsapp\.com\//i.test(value)) {
      info = await whatsapp.analyzeGroupInvite(id, groups.extractInviteCode(value));
      if (info?.gid) { try { info = await whatsapp.getGroupInfo(id, groups.normalizeGid(info.gid)); } catch {} }
    } else {
      info = await whatsapp.getGroupInfo(id, groups.normalizeGid(value));
    }
    if (!info?.gid) throw new Error('لم أستطع الحصول على GID للمجموعة من WhatsApp.');
    const group = saveGroup(id, info);
    res.json({ ok: true, group, message: 'تم الربط والتحليل داخل الجلسة الحالية.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/groups/save', (req, res) => { try { const id = sid(req), g = req.body?.group || {}; if (!groups.isGroupId(g.gid)) throw new Error('GID المجموعة غير صالح.'); res.json({ ok: true, group: saveGroup(id, g), message: 'تم حفظ المجموعة داخل الجلسة الحالية.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/add-invite', async (req, res) => {
  try {
    const id = sid(req), code = groups.extractInviteCode(req.body?.url || req.body?.code), info = await whatsapp.analyzeGroupInvite(id, code);
    if (!info.gid) throw new Error('تم تحليل الدعوة لكن WhatsApp لم يعطِ GID لهذه المجموعة؛ افتح المجموعة أو استخدم الاكتشاف من الجلسة ثم أضفها.');
    res.json({ ok: true, group: saveGroup(id, info), message: 'تمت إضافة المجموعة إلى هذه الجلسة.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/groups/analyze-gid', async (req, res) => { try { const id=sid(req), info=await whatsapp.getGroupInfo(id, groups.normalizeGid(req.body?.gid)); res.json({ ok:true, group:saveGroup(id, info), message:'تم تحديث بيانات المجموعة داخل الجلسة.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/analyze-invite', async (req, res) => { try { const id=sid(req), info=await whatsapp.analyzeGroupInvite(id, groups.extractInviteCode(req.body?.url || req.body?.code)); res.json({ ok:true, group: info?.gid ? saveGroup(id, info) : info, message: info?.gid ? 'تم تحديث بيانات المجموعة.' : 'تم تحليل الدعوة؛ لم يوفر WhatsApp GID.' }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), g = s.groups.find(x => x.id === req.params.id); if (!g) throw new Error('المجموعة غير موجودة.'); g.enabled = !g.enabled; store.saveSession(s); res.json({ ok: true, enabled: g.enabled }); } catch (e) { replyError(res, e); } });
app.post('/api/groups/:id/refresh', async (req, res) => { try { const id = sid(req), s = store.loadSession(id), g = s.groups.find(x => x.id === req.params.id); if (!g) throw new Error('المجموعة غير موجودة.'); res.json({ ok: true, group: saveGroup(id, await whatsapp.getGroupInfo(id, g.gid)) }); } catch (e) { replyError(res, e); } });
app.delete('/api/groups/:id', (req, res) => {
  try { const s = store.loadSession(sid(req)), key = `g:${req.params.id}`, removed = s.groups.find(x => x.id === req.params.id); if (!removed) throw new Error('المجموعة غير موجودة.'); s.groups = s.groups.filter(x => x.id !== req.params.id); removeTargetFromSchedule(s, key); const removedGid = String(removed.gid || '').toLowerCase(); s.settings.interactionChatIds = (s.settings.interactionChatIds || []).filter(x => String(x).toLowerCase() !== removedGid); s.automation.tasks = (s.automation.tasks || []).map(t => ({ ...t, targetKeys: (t.targetKeys || []).filter(k => k !== key) })).filter(t => (t.targetKeys || []).length || (t.preText || t.postText || (t.mediaIds || []).length)); store.saveSession(s); res.json({ ok: true }); }
  catch (e) { replyError(res, e); }
});

app.post('/api/media', upload.array('files', 100), (req, res) => {
  try {
    const id = sid(req), dir = store.getPaths(id).media, saved = [], duplicates = [], rejected = [];
    const replaceDuplicates = boolValue(req.body?.replaceDuplicates, false);
    const existing = new Map();
    for (const entry of media.scan(dir, store.loadSession(id).settings.maxImageSizeMB).files) {
      try { existing.set(`${entry.size}:${media.hashFile(media.safePath(dir, entry.filename))}`, entry.filename); } catch {}
    }
    for (const file of req.files || []) {
      const ext = path.extname(file.originalname || '').toLowerCase();
      if (!media.MEDIA_EXT.has(ext)) { rejected.push({ filename: file.originalname, error: 'نوع غير مدعوم' }); fs.rmSync(file.path, { force: true }); continue; }
      const hash = media.hashFile(file.path);
      const duplicateName = existing.get(`${fs.statSync(file.path).size}:${hash}`);
      if (duplicateName && !replaceDuplicates) {
        duplicates.push({ incoming: file.originalname, existing: duplicateName }); fs.rmSync(file.path, { force: true }); continue;
      }
      if (duplicateName && replaceDuplicates) {
        fs.renameSync(file.path, media.safePath(dir, duplicateName)); saved.push(duplicateName); continue;
      }
      const name = media.IMAGE_EXT.has(ext) ? media.nextImageName(dir, ext) : media.uniqueFileName(dir, path.basename(file.originalname, path.extname(file.originalname)), ext);
      fs.renameSync(file.path, media.safePath(dir, name));
      existing.set(`${fs.statSync(media.safePath(dir, name)).size}:${media.hashFile(media.safePath(dir, name))}`, name);
      saved.push(name);
    }
    res.json({ ok: true, saved, duplicates, rejected, message: duplicates.length ? `تم رفع ${saved.length} ملف، ووجدت ${duplicates.length} ملفًا مكررًا لم يتم استبداله.` : `تم رفع ${saved.length} ملف.` });
  } catch (e) {
    for (const f of req.files || []) { try { fs.rmSync(f.path, { force: true }); } catch {} }
    replyError(res, e);
  }
});
app.delete('/api/media/:filename', (req, res) => { try { const id = sid(req), name = decodeURIComponent(req.params.filename); fs.rmSync(media.safePath(store.getPaths(id).media, name), { force: true }); const s = store.loadSession(id); s.automation.tasks = (s.automation.tasks || []).map(t => ({ ...t, mediaIds: (t.mediaIds || []).filter(x => String(x) !== name) })); if (s.settings.scheduleMediaId === name) s.settings.scheduleMediaId = ''; store.saveSession(s); res.json({ ok: true, message: 'تم حذف الملف.' }); } catch (e) { replyError(res, e); } });
app.get('/media/:filename', (req, res) => { try { res.sendFile(media.safePath(store.getPaths(sid(req)).media, decodeURIComponent(req.params.filename))); } catch { res.status(404).end(); } });

app.post('/api/send', async (req, res) => {
  try {
    const result = await delivery.sendNow(sid(req), req.body || {});
    // DeliveryService returns per-target arrays, not numeric counts. Number([object]) yields NaN.
    const sentCount = Array.isArray(result.sent) ? result.sent.length : Number(result.sent || result.success || 0);
    const failed = Array.isArray(result.failed) ? result.failed : [];
    const failedCount = Array.isArray(result.failed) ? failed.length : Number(result.failed || 0);
    const failedDetails = failed.slice(0, 8).map(item => ({ target: item.target || 'مستلم', targetId: item.targetId || '', kind: item.kind || '', error: String(item.error || 'تعذر الإرسال').slice(0, 420), code: item.code || '', retryable: item.retryable === true }));
    const sent = Array.isArray(result.sent) ? result.sent : [];
    const uniqueTargetKey = item => `${item.kind || 'recipient'}:${item.targetId || item.target || ''}`;
    const sentRecipientCount = new Set(sent.map(uniqueTargetKey)).size;
    const failedRecipientCount = new Set(failed.filter(item => item.targetId || item.target).map(uniqueTargetKey)).size;
    res.json({ ...result, ok: true, deliveryOk: result.ok === true, sentCount, failedCount, sentRecipientCount, failedRecipientCount, failedDetails, message: failedCount ? `اكتملت ${sentCount} عملية إرسال إلى ${sentRecipientCount} مستلم، وفشلت ${failedCount} عملية تشمل ${failedRecipientCount} مستلم. راجع الأخطاء قبل إعادة المحاولة.` : `اكتملت ${sentCount} عملية إرسال إلى ${sentRecipientCount} مستلم بنجاح.` });
  } catch (e) { replyError(res, e); }
});
app.post('/api/schedule', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), b = req.body || {}, time = String(b.scheduleTime || '17:30'), tm = time.match(/^(\d{2}):(\d{2})$/);
    const mode = ['weekly', 'monthly', 'once'].includes(b.scheduleMode) ? b.scheduleMode : 'weekly';
    if (!tm || Number(tm[1]) > 23 || Number(tm[2]) > 59) throw new Error('وقت الجدولة غير صالح.');
    if (mode === 'once' && !validIsoDate(b.scheduleDate)) throw new Error('أدخل تاريخًا تقويميًا صالحًا للجدولة مرة واحدة.');
    if (mode === 'monthly' && !(Number(b.scheduleMonthDay) >= 1 && Number(b.scheduleMonthDay) <= 31)) throw new Error('اختر يومًا صحيحًا من 1 إلى 31 للجدولة الشهرية.');
    const requestedTargets = Array.isArray(b.scheduleTargetKeys) ? b.scheduleTargetKeys : []; const targetKeys = validTargetKeys(s, requestedTargets.length ? requestedTargets : [...s.recipients.filter(x => x.enabled !== false).map(x => `r:${x.id}`), ...s.groups.filter(x => x.enabled !== false).map(x => `g:${x.id}`)]);
    Object.assign(s.settings, {
      scheduleMode: mode, scheduleTime: time,
      scheduleDay: store.toInt(b.scheduleDay, 5, 0, 6),
      scheduleMonthDay: store.toInt(b.scheduleMonthDay, 1, 1, 31),
      scheduleDate: String(b.scheduleDate || ''), scheduleEnabled: boolValue(b.scheduleEnabled, true),
      scheduledGroupsEnabled: true, scheduleTargetKeys: targetKeys,
      scheduleMediaId: String(b.scheduleMediaId || ''), schedulePreText: String(b.schedulePreText ?? ''), schedulePostText: String(b.schedulePostText ?? ''),
    });
    if (!targetKeys.length) throw new Error('أضف رقمًا أو مجموعة للجدولة.');
    if (s.settings.scheduleMediaId && !media.scan(store.getPaths(s.id).media, s.settings.maxImageSizeMB).files.some(x => x.id === s.settings.scheduleMediaId)) throw new Error('ملف الجدولة المحدد غير موجود.');
    s.scheduleState.lastRunKey = '';
    store.saveSession(s);
    res.json({ ok: true, nextRun: nextRun(s), targets: targetKeys.length, message: 'تم حفظ الجدولة.' });
  } catch (e) { replyError(res, e); }
});

function normalizeInteractionRulePayload(s, body, existing = null) {
  const b = body || {}, previous = existing || {};
  const whenIn = { ...(previous.when || {}), ...(b.when || {}) };
  const thenIn = { ...(previous.then || {}), ...(b.then || {}) };
  let rawReplies = thenIn.replies ?? thenIn.replyVariants;
  if (rawReplies == null || (Array.isArray(rawReplies) && rawReplies.length === 0 && String(thenIn.reply || '').trim())) rawReplies = thenIn.reply ? String(thenIn.reply).split(/\r?\n/) : [];
  if (!Array.isArray(rawReplies)) rawReplies = [rawReplies];
  const replies = [...new Set(rawReplies.map(x => String(x ?? '').trim()).filter(Boolean))].slice(0, 80).map(x => x.slice(0, 1500));
  const singleReply = String(thenIn.reply || '').trim().slice(0, 1500);
  if (singleReply && !replies.includes(singleReply) && !Array.isArray(thenIn.replies) && !Array.isArray(thenIn.replyVariants)) replies.unshift(singleReply);
  const scheduleInput = b.schedule && typeof b.schedule === 'object' ? { ...(previous.schedule || {}), ...b.schedule } : (previous.schedule || {});
  const scheduleDays = Array.isArray(scheduleInput.days) ? [...new Set(scheduleInput.days.map(Number))] : [];
  const rule = {
    ...previous,
    id: previous.id || randomId(),
    name: String(b.name ?? previous.name ?? 'قاعدة').trim().slice(0, 100) || 'قاعدة',
    enabled: b.enabled === undefined ? (previous.enabled !== false) : boolValue(b.enabled, true),
    priority: store.toInt(b.priority, Number(previous.priority) || 0, -1000, 1000),
    commandPriority: b.commandPriority === undefined ? previous.commandPriority === true : boolValue(b.commandPriority, false),
    conflictGroup: String(b.conflictGroup ?? previous.conflictGroup ?? '').trim().slice(0, 80),
    when: {
      type: whenIn.type === 'reaction' ? 'reaction' : 'message',
      match: ['any','contains','exact','starts','ends','regex','similarity','intent'].includes(require('./src/trigger-engine').canonicalMode(whenIn.match)) ? require('./src/trigger-engine').canonicalMode(whenIn.match) : 'contains',
      value: String(whenIn.value ?? '').slice(0, 500),
      ignoreCase: whenIn.ignoreCase !== false,
      ...(whenIn.threshold !== undefined ? { threshold: Math.max(.30, Math.min(.98, Number(whenIn.threshold) || .68)) } : {}),
    },
    then: {
      reply: replies[0] || singleReply,
      replies,
      reaction: String(thenIn.reaction ?? '').trim().slice(0, 24),
      stopAfter: thenIn.stopAfter !== false,
    },
    scope: ['all','groups','private','selected'].includes(b.scope ?? previous.scope) ? (b.scope ?? previous.scope) : 'all',
    chatIds: normalizeRuleChatIds(b.chatIds === undefined ? previous.chatIds : b.chatIds),
    cooldownSec: store.toInt(b.cooldownSec, Number(previous.cooldownSec ?? 30), 0, 86400),
    schedule: {
      enabled: boolValue(scheduleInput.enabled, false),
      start: String(scheduleInput.start || '09:00'), end: String(scheduleInput.end || '17:00'),
      days: scheduleDays, timezone: String(scheduleInput.timezone || s.settings.timezone || 'Asia/Muscat'),
    },
  };
  if (!rule.then.reply && !rule.then.reaction) throw new Error('أضف ردًا واحدًا على الأقل أو Reaction.');
  require('./src/interaction').valid(rule);
  return rule;
}

app.post('/api/interaction/rules', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), r = normalizeInteractionRulePayload(s, req.body || {});
    s.interaction.rules.push(r); store.saveSession(s); res.json({ ok: true, rule: r, message: 'تم حفظ القاعدة.' });
  } catch (e) { replyError(res, e); }
});
app.put('/api/interaction/rules/:id', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), existing = s.interaction.rules.find(x => x.id === req.params.id);
    if (!existing) throw new Error('القاعدة غير موجودة.');
    const updated = normalizeInteractionRulePayload(s, req.body || {}, existing);
    Object.assign(existing, updated, { id: existing.id, updatedAt: new Date().toISOString() });
    store.saveSession(s); res.json({ ok: true, rule: existing, message: 'تم تحديث القاعدة.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/interaction/rules/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), r = s.interaction.rules.find(x => x.id === req.params.id); if (!r) throw new Error('القاعدة غير موجودة.'); r.enabled = !r.enabled; store.saveSession(s); res.json({ ok: true, enabled: r.enabled }); } catch (e) { replyError(res, e); } });
app.delete('/api/interaction/rules/:id', (req, res) => { try { const s = store.loadSession(sid(req)), before = s.interaction.rules.length; s.interaction.rules = s.interaction.rules.filter(x => x.id !== req.params.id); if (before === s.interaction.rules.length) throw new Error('القاعدة غير موجودة.'); store.saveSession(s); res.json({ ok: true }); } catch (e) { replyError(res, e); } });

function makeCounterTrigger(s, body, existing = null) {
  const b = body || {}, previous = existing || {}, priorThen = previous.then || {};
  const rawReplies = b.replies ?? b.then?.replies ?? b.then?.replyVariants ?? b.reply ?? b.then?.reply ?? priorThen.replies ?? priorThen.reply ?? '';
  let repliesInput = Array.isArray(rawReplies) ? rawReplies : String(rawReplies).split(/\r?\n/);
  if (!repliesInput.length && String(b.reply ?? b.then?.reply ?? priorThen.reply ?? '').trim()) repliesInput = String(b.reply ?? b.then?.reply ?? priorThen.reply).split(/\r?\n/);
  const replies = [...new Set(repliesInput.map(x => String(x ?? '').trim()).filter(Boolean))].slice(0, 80).map(x => x.slice(0, 1500));
  const actionType = ['reply','reaction','log'].includes(b.actionType ?? previous.actionType) ? (b.actionType ?? previous.actionType) : 'reply';
  const threshold = store.toInt(b.threshold, Number(previous.threshold) || 100, 1, 100000000);
  const state = s.interaction.counterState || { totalCount: 0, byChat: {}, fired: {}, pending: {} };
  const scope = (b.scope ?? previous.scope) === 'chat' ? 'chat' : 'session';
  const current = scope === 'session' ? Number(state.totalCount || 0) : 0;
  const trigger = {
    ...previous, id: previous.id || randomId(), name: String(b.name ?? previous.name ?? `عداد ${threshold}`).trim().slice(0, 100) || `عداد ${threshold}`,
    enabled: b.enabled === undefined ? previous.enabled !== false : boolValue(b.enabled, true), threshold,
    priority: store.toInt(b.priority, Number(previous.priority) || 0, -1000, 1000), scope, actionType,
    then: { reply: replies[0] || '', replies, reaction: String(b.reaction ?? b.then?.reaction ?? priorThen.reaction ?? '').trim().slice(0, 24) },
    armedAtCount: existing ? current : (Number(previous.armedAtCount) || current), updatedAt: new Date().toISOString(),
  };
  if (actionType === 'reply' && !trigger.then.replies.length) throw new Error('أضف ردًا واحدًا على الأقل لإجراء العداد.');
  if (actionType === 'reaction' && !trigger.then.reaction) throw new Error('أضف إيموجي للعداد.');
  return trigger;
}
app.post('/api/interaction/counters', (req, res) => {
  try { const s = store.loadSession(sid(req)), trigger = makeCounterTrigger(s, req.body || {}); s.interaction.counterTriggers ||= []; s.interaction.counterTriggers.push(trigger); store.saveSession(s); res.json({ ok: true, trigger, message: 'تم حفظ عداد الرسائل.' }); }
  catch (e) { replyError(res, e); }
});
app.put('/api/interaction/counters/:id', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), trigger = (s.interaction.counterTriggers || []).find(x => x.id === req.params.id);
    if (!trigger) throw new Error('العداد غير موجود.');
    const next = makeCounterTrigger(s, req.body || {}, trigger);
    Object.assign(trigger, next, { id: trigger.id });
    const cs = s.interaction.counterState ||= { totalCount: 0, byChat: {}, fired: {}, pending: {} };
    for (const map of [cs.fired, cs.pending]) for (const group of Object.values(map || {})) for (const key of Object.keys(group || {})) if (key.startsWith(`${trigger.id}:`)) delete group[key];
    store.saveSession(s); res.json({ ok: true, trigger, message: 'تم تحديث العداد.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/interaction/counters/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), t = (s.interaction.counterTriggers || []).find(x => x.id === req.params.id); if (!t) throw new Error('العداد غير موجود.'); t.enabled = !t.enabled; store.saveSession(s); res.json({ ok: true, enabled: t.enabled }); } catch (e) { replyError(res, e); } });
app.delete('/api/interaction/counters/:id', (req, res) => { try { const s = store.loadSession(sid(req)), before = (s.interaction.counterTriggers || []).length; s.interaction.counterTriggers = s.interaction.counterTriggers.filter(x => x.id !== req.params.id); if (before === s.interaction.counterTriggers.length) throw new Error('العداد غير موجود.'); store.saveSession(s); res.json({ ok: true }); } catch (e) { replyError(res, e); } });
app.post('/api/interaction/counters/reset', (req, res) => {
  try {
    const s = store.loadSession(sid(req));
    s.interaction.counterState = { totalCount: 0, byChat: {}, fired: {}, pending: {} };
    for (const trigger of s.interaction.counterTriggers || []) trigger.armedAtCount = 0;
    store.saveSession(s); res.json({ ok: true, message: 'تم تصفير العدادات وإعادة تسليح المحفزات.' });
  } catch (e) { replyError(res, e); }
});


function normalizeAutomationPayload(id, b, existing = null) {
  const base = existing || {};
  const raw = { ...base, ...(b || {}) };
  const mode = ['daily', 'weekly', 'monthly', 'yearly', 'once'].includes(String(raw.mode || '')) ? String(raw.mode) : 'weekly';
  const time = String(raw.time || '17:30');
  if (!/^\d{2}:\d{2}$/.test(time) || Number(time.slice(0, 2)) > 23 || Number(time.slice(3)) > 59) throw new Error('وقت الموعد غير صالح.');
  if (mode === 'once' && !validIsoDate(raw.date)) throw new Error('أدخل تاريخًا تقويميًا صالحًا.');
  if (mode !== 'once' && mode !== 'weekly' && !(Number(raw.dayOfMonth) >= 1 && Number(raw.dayOfMonth) <= 31)) throw new Error('يوم الشهر يجب أن يكون بين 1 و31.');
  if (mode === 'yearly' && !(Number(raw.month) >= 1 && Number(raw.month) <= 12)) throw new Error('اختر الشهر السنوي.');
  const s = store.loadSession(id), targets = validTargetKeys(s, Array.isArray(raw.targetKeys) ? raw.targetKeys : []), mediaIds = uniqueStrings(raw.mediaIds);
  const available = new Set(media.scan(store.getPaths(id).media, s.settings.maxImageSizeMB).files.map(x => x.id));
  const mediaOk = mediaIds.filter(x => available.has(x));
  if (mediaIds.length !== mediaOk.length) throw new Error('بعض ملفات الموعد غير موجودة.');
  if (!targets.length) throw new Error('اختر مستلمًا أو مجموعة للموعد.');
  const mediaMode = raw.mediaMode === 'cycle' ? 'cycle' : 'selected';
  const hasCycleImages = mediaMode === 'cycle' && media.scan(store.getPaths(id).media, s.settings.maxImageSizeMB).images.length > 0;
  if (!mediaOk.length && !String(raw.preText || '').trim() && !String(raw.postText || '').trim() && !hasCycleImages) throw new Error('أضف نصًا أو ملفًا للموعد، أو فعّل دورة الصور مع وجود صور.');
  return store.normalizeAutomationTask({ ...raw, id: base.id || undefined, name: raw.name, mode, time, date: raw.date, day: store.toInt(raw.day, 5, 0, 6), dayOfMonth: store.toInt(raw.dayOfMonth, 1, 1, 31), month: raw.month === '' ? '' : store.toInt(raw.month, 1, 1, 12), year: raw.year === '' ? '' : store.toInt(raw.year, new Date().getFullYear(), 2020, 2100), targetKeys: targets, mediaIds: mediaOk });
}
app.get('/api/automation/rules', (req, res) => { try { const s = store.loadSession(sid(req)); res.json({ ok: true, rules: s.automation.rules || [], mutes: s.automation.mutes || [], groupPermissions: s.settings.automationGroupPermissions || {}, eventState: { totalMessages: Number(s.automation.eventState?.totalMessages || 0), byChat: s.automation.eventState?.byChat || {} }, recent: s.automation.recent || [] }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/rules', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), rule = normalizeAutomationRule(req.body || {}, s);
    try { new Intl.DateTimeFormat('en-US', { timeZone: rule.timezone }).format(); } catch { throw new Error('المنطقة الزمنية غير صالحة.'); }
    if (rule.mode === 'once' && !validIsoDate(rule.date)) throw new Error('تاريخ القاعدة لمرة واحدة غير صالح.');
    if (['time','message-age'].includes(rule.triggerType) && rule.targetMode === 'current' && rule.action !== 'log') throw new Error('اختر هدفًا محددًا أو كل الأهداف للقاعدة المجدولة.');
    if (rule.triggerType === 'message-age' && rule.action !== 'cleanup-old-messages') throw new Error('قاعدة عمر الرسائل تستخدم إجراء تنظيف الرسائل القديمة.');
    s.automation.rules.push(rule); s.automation.rules = s.automation.rules.slice(-500); s.automation.enabled = true; store.saveSession(s);
    res.json({ ok: true, rule, message: 'تم حفظ قاعدة الأتمتة.' });
  } catch (e) { replyError(res, e); }
});
app.put('/api/automation/rules/:id', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), index = (s.automation.rules || []).findIndex(x => x.id === req.params.id);
    if (index < 0) throw new Error('قاعدة الأتمتة غير موجودة.');
    const rule = normalizeAutomationRule({ ...s.automation.rules[index], ...(req.body || {}), id: req.params.id, createdAt: s.automation.rules[index].createdAt }, s);
    try { new Intl.DateTimeFormat('en-US', { timeZone: rule.timezone }).format(); } catch { throw new Error('المنطقة الزمنية غير صالحة.'); }
    if (rule.mode === 'once' && !validIsoDate(rule.date)) throw new Error('تاريخ القاعدة لمرة واحدة غير صالح.');
    if (['time','message-age'].includes(rule.triggerType) && rule.targetMode === 'current' && rule.action !== 'log') throw new Error('اختر هدفًا محددًا أو كل الأهداف للقاعدة المجدولة.');
    if (rule.triggerType === 'message-age' && rule.action !== 'cleanup-old-messages') throw new Error('قاعدة عمر الرسائل تستخدم إجراء تنظيف الرسائل القديمة.');
    s.automation.rules[index] = { ...rule, id: req.params.id, createdAt: s.automation.rules[index].createdAt }; store.saveSession(s);
    res.json({ ok: true, rule: s.automation.rules[index], message: 'تم تحديث قاعدة الأتمتة.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/automation/rules/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), r = (s.automation.rules || []).find(x => x.id === req.params.id); if (!r) throw new Error('قاعدة الأتمتة غير موجودة.'); r.enabled = !r.enabled; r.updatedAt = new Date().toISOString(); store.saveSession(s); res.json({ ok: true, enabled: r.enabled }); } catch (e) { replyError(res, e); } });
app.delete('/api/automation/rules/:id', (req, res) => { try { const s = store.loadSession(sid(req)), before = s.automation.rules.length; s.automation.rules = s.automation.rules.filter(x => x.id !== req.params.id); if (s.automation.rules.length === before) throw new Error('قاعدة الأتمتة غير موجودة.'); store.saveSession(s); res.json({ ok: true, message: 'تم حذف قاعدة الأتمتة.' }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/rules/:id/run', async (req, res) => { try { const id = sid(req), s = store.loadSession(id), r = (s.automation.rules || []).find(x => x.id === req.params.id); if (!r) throw new Error('قاعدة الأتمتة غير موجودة.'); if (r.triggerType === 'message' || r.triggerType === 'group-message' || r.triggerType === 'message-count') throw new Error('هذه القاعدة تحتاج رسالة حدث؛ اختبرها بإرسال رسالة مطابقة.'); const result = await automationEngine.executeRule(id, r, { event: 'manual', scheduledAt: new Date().toISOString() }); res.json({ ok: true, result, message: 'اكتمل تنفيذ القاعدة اليدوي.' }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/group-permissions', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), b = req.body || {}, prior = s.settings.automationGroupPermissions || {};
    const keys = ['allowDeleteMessage','allowDeleteChat','allowArchive','allowMute','adminsOnly'];
    s.settings.automationGroupPermissions = { ...prior };
    for (const key of keys) if (b[key] !== undefined) s.settings.automationGroupPermissions[key] = boolValue(b[key], prior[key] === true);
    store.saveSession(s); res.json({ ok: true, groupPermissions: s.settings.automationGroupPermissions, message: 'تم حفظ صلاحيات الأتمتة للمجموعات.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/automation/mutes', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), mute = normalizeMute(req.body || {});
    const target = mute.chatId;
    // Owner-selected targets are checked against saved contacts/groups or accepted as a syntactically valid JID.
    await whatsapp.actOnChat(id, target, 'mute', { permanent: mute.mode === 'permanent', until: mute.expiresAt ? new Date(mute.expiresAt) : null, minutes: mute.minutes });
    const old = (s.automation.mutes || []).find(m => m.chatId === target && m.enabled !== false);
    if (old) Object.assign(old, mute, { id: old.id, createdAt: old.createdAt, updatedAt: new Date().toISOString() }); else s.automation.mutes.push(mute);
    s.automation.mutes = s.automation.mutes.slice(-1000); store.saveSession(s);
    automationEngine.muteApplied.set(`${id}|${old?.id || mute.id}`, `${target}|${mute.expiresAt || 'permanent'}`);
    res.json({ ok: true, mute: old || mute, message: mute.mode === 'permanent' ? 'تم كتم المحادثة حتى الإلغاء يدويًا.' : 'تم كتم المحادثة مؤقتًا.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/automation/mutes/:id/unmute', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), mute = (s.automation.mutes || []).find(x => x.id === req.params.id);
    if (!mute) throw new Error('إعداد الكتم غير موجود.');
    await whatsapp.actOnChat(id, mute.chatId, 'unmute'); mute.enabled = false; mute.updatedAt = new Date().toISOString(); mute.expiredAt = new Date().toISOString(); store.saveSession(s);
    automationEngine.muteApplied.delete(`${id}|${mute.id}`); res.json({ ok: true, message: 'تم إلغاء كتم المحادثة.' });
  } catch (e) { replyError(res, e); }
});
app.delete('/api/automation/mutes/:id', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), mute = (s.automation.mutes || []).find(x => x.id === req.params.id);
    if (!mute) throw new Error('إعداد الكتم غير موجود.');
    if (mute.enabled !== false) await whatsapp.actOnChat(id, mute.chatId, 'unmute');
    s.automation.mutes = s.automation.mutes.filter(x => x.id !== req.params.id); store.saveSession(s); automationEngine.muteApplied.delete(`${id}|${mute.id}`);
    res.json({ ok: true, message: 'تم إلغاء الكتم وحذف الإعداد.' });
  } catch (e) { replyError(res, e); }
});

app.get('/api/automation/tasks', (req, res) => { try { const s = store.loadSession(sid(req)); res.json({ ok: true, tasks: (s.automation.tasks || []).map(t => ({ ...t, nextRun: nextRunForItem({ ...t, timezone: s.settings.timezone }) })) }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/task', (req, res) => { try { const id = sid(req), s = store.loadSession(id), task = normalizeAutomationPayload(id, req.body || {}); s.automation.tasks.push(task); s.automation.enabled = true; store.saveSession(s); res.json({ ok: true, task: { ...task, nextRun: nextRunForItem({ ...task, timezone: s.settings.timezone }) }, message: 'تم حفظ الموعد داخل الجلسة الحالية.' }); } catch (e) { replyError(res, e); } });
app.put('/api/automation/task/:id', (req, res) => { try { const id = sid(req), s = store.loadSession(id), task = s.automation.tasks.find(x => x.id === req.params.id); if (!task) throw new Error('الموعد غير موجود.'); const updated = normalizeAutomationPayload(id, req.body || {}, task); Object.assign(task, updated, { id: task.id, updatedAt: new Date().toISOString() }); store.saveSession(s); res.json({ ok: true, task: { ...task, nextRun: nextRunForItem({ ...task, timezone: s.settings.timezone }) }, message: 'تم تحديث الموعد.' }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/task/:id/toggle', (req, res) => { try { const s = store.loadSession(sid(req)), t = s.automation.tasks.find(x => x.id === req.params.id); if (!t) throw new Error('الموعد غير موجود.'); t.enabled = !t.enabled; t.updatedAt = new Date().toISOString(); store.saveSession(s); res.json({ ok: true, enabled: t.enabled, message: t.enabled ? 'تم تشغيل الموعد.' : 'تم إيقاف الموعد.' }); } catch (e) { replyError(res, e); } });
app.delete('/api/automation/task/:id', (req, res) => { try { const s = store.loadSession(sid(req)), before = s.automation.tasks.length; s.automation.tasks = s.automation.tasks.filter(x => x.id !== req.params.id); if (before === s.automation.tasks.length) throw new Error('الموعد غير موجود.'); store.saveSession(s); res.json({ ok: true, message: 'تم حذف الموعد.' }); } catch (e) { replyError(res, e); } });
app.post('/api/automation/task/:id/run', async (req, res) => { try { const s = store.loadSession(sid(req)), t = s.automation.tasks.find(x => x.id === req.params.id); if (!t) throw new Error('الموعد غير موجود.'); res.json({ ok: true, ...(await delivery.scheduledTaskRun(s.id, t)), message: 'تم تنفيذ الموعد.' }); } catch (e) { replyError(res, e); } });

app.post('/api/interaction/test', async (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), body = String(req.body?.message || ''), chatId = String(req.body?.chatId || 'test@c.us').toLowerCase();
    const rule = req.body?.rule || {};
    if (!body && rule.when?.type === 'message' && rule.when?.match !== 'any') throw new Error('اكتب رسالة اختبار.');
    const interaction = require('./src/interaction');
    const triggerEngine = require('./src/trigger-engine');
    triggerEngine.validateTrigger(rule);
    const matchResult = triggerEngine.matchTrigger(rule, rule.when?.type === 'reaction' ? 'reaction' : 'message', body, String(req.body?.emoji || ''), { threshold: s.settings.interactionSimilarityThreshold });
    const syntaxMatch = matchResult.matched;
    const activeNow = interaction.ruleActiveNow(rule, s.settings, new Date());
    const matched = syntaxMatch && activeNow;
    const replyEngine = require('./src/reply-engine');
    const reply = replyEngine.pickReply(rule, {}, 'test');
    res.json({ ok: true, matched, syntaxMatch, activeNow, intent: matchResult.intent, score: matchResult.score, rendered: interaction.render(reply || rule.then?.reply || '', { message: body, sender: String(req.body?.sender || 'مستخدم'), chat: chatId, type: rule.when?.type || 'message', emoji: String(req.body?.emoji || ''), intent: matchResult.intent }, s.settings.timezone), message: !syntaxMatch ? 'الرسالة لا تطابق الشرط.' : !activeNow ? 'الشرط مطابق، لكن القاعدة خارج وقت التشغيل المحدد.' : 'الشرط والوقت مطابقان.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/settings', (req, res) => {
  try {
    const s = store.loadSession(sid(req)), b = req.body || {};
    for (const key of ['timezone', 'sendOrder', 'interactionScope', 'interactionQuietStart', 'interactionQuietEnd']) {
      if (b[key] === undefined) continue;
      const value = String(b[key]).trim();
      if (key === 'timezone') { try { new Intl.DateTimeFormat('en-US', { timeZone: value }).format(); } catch { throw new Error('المنطقة الزمنية غير صالحة. استخدم اسمًا مثل Asia/Muscat.'); } }
      if (['interactionQuietStart', 'interactionQuietEnd'].includes(key) && !/^([01]\d|2[0-3]):[0-5]\d$/.test(value)) throw new Error('وقت الهدوء يجب أن يكون بصيغة HH:MM.');
      s.settings[key] = value;
    }
    if (b.interactionQuietAction !== undefined) {
      const action = String(b.interactionQuietAction);
      if (!['silence', 'reply', 'rules'].includes(action)) throw new Error('اختر سلوكًا صحيحًا لفترة الهدوء.');
      s.settings.interactionQuietAction = action;
    }
    if (b.interactionQuietReply !== undefined) s.settings.interactionQuietReply = String(b.interactionQuietReply).slice(0, 1000);
    if (b.interactionQuietCooldownSec !== undefined) s.settings.interactionQuietCooldownSec = store.toInt(b.interactionQuietCooldownSec, 300, 0, 86400);
    if (Array.isArray(b.interactionChatIds)) s.settings.interactionChatIds = normalizeRuleChatIds(b.interactionChatIds);
    if (b.interactionConflictMode !== undefined) { const mode = String(b.interactionConflictMode); if (!['first-match','highest-score','allow-multiple'].includes(mode)) throw new Error('وضع حل التعارض غير صالح.'); s.settings.interactionConflictMode = mode; }
    if (b.interactionSimilarityThreshold !== undefined) { const threshold = Number(b.interactionSimilarityThreshold); if (!Number.isFinite(threshold) || threshold < .30 || threshold > .98) throw new Error('عتبة التشابه يجب أن تكون بين 0.30 و0.98.'); s.settings.interactionSimilarityThreshold = threshold; }
    if (b.appearance && typeof b.appearance === 'object') {
      const a = b.appearance, isHex = v => /^#[0-9a-f]{6}$/i.test(String(v || ''));
      const current = s.settings.appearance || {};
      s.settings.appearance = {
        ...current,
        accent: isHex(a.accent) ? String(a.accent) : current.accent,
        accent2: isHex(a.accent2) ? String(a.accent2) : current.accent2,
        panelOpacity: Number.isFinite(Number(a.panelOpacity)) ? Math.max(.72, Math.min(.97, Number(a.panelOpacity))) : current.panelOpacity,
        panelBlur: Number.isFinite(Number(a.panelBlur)) ? Math.max(4, Math.min(28, Number(a.panelBlur))) : current.panelBlur,
        radius: Number.isFinite(Number(a.radius)) ? Math.max(12, Math.min(28, Number(a.radius))) : current.radius,
        glow: Number.isFinite(Number(a.glow)) ? Math.max(0, Math.min(1, Number(a.glow))) : current.glow,
      };
    }
    for (const key of ['sendTimeoutMs', 'sendDelayMs', 'retryAttempts', 'retryDelayMs', 'maxImageSizeMB', 'maxActionsPerMinute']) if (b[key] !== undefined) { const max = key === 'retryAttempts' ? 4 : key === 'maxImageSizeMB' ? 250 : key === 'sendTimeoutMs' ? 180000 : key === 'sendDelayMs' ? 60000 : key === 'retryDelayMs' ? 120000 : 1000; s.settings[key] = store.toInt(b[key], s.settings[key], key === 'sendDelayMs' ? 0 : 1, max); }
    for (const key of ['interactionEnabled', 'groupAssistantEnabled', 'interactionIgnoreOwn', 'interactionQuietEnabled', 'autoStartSession', 'automationEnabled']) if (b[key] !== undefined) s.settings[key] = boolValue(b[key], s.settings[key]);
    if (b.interactionEnabled !== undefined) s.interaction.enabled = boolValue(b.interactionEnabled, s.interaction.enabled);
    if (b.automationEnabled !== undefined) s.automation.enabled = boolValue(b.automationEnabled, s.automation.enabled);
    store.saveSession(s); res.json({ ok: true, message: 'تم حفظ الإعدادات.' });
  } catch (e) { replyError(res, e); }
});
app.post('/api/settings/background', (req, res) => {
  try {
    const id = sid(req), s = store.loadSession(id), b = req.body || {}, n = backgrounds.normalize(b.mode, b.settings, b.opacity);
    s.settings.backgroundMode = n.mode; s.settings.backgroundSettings = n.settings; s.settings.backgroundOpacity = n.opacity;
    if (b.removeImage && s.settings.backgroundImage) { try { fs.rmSync(media.safePath(store.getPaths(id).backgrounds, s.settings.backgroundImage), { force: true }); } catch {} s.settings.backgroundImage = ''; }
    store.saveSession(s); res.json({ ok: true, message: 'تم تطبيق المظهر فعليًا.' });
  } catch (e) { replyError(res, e); }
});
app.get('/profile/:filename', (req, res) => {
  try {
    const name = String(req.params.filename || '');
    if (!/^[a-f0-9]{24}\.(?:jpg|jpeg|png|webp|gif|avif)$/i.test(name)) return res.status(404).end();
    const file = media.safePath(store.getPaths(sid(req)).profiles, name);
    if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return res.status(404).end();
    res.setHeader('Cache-Control', 'private, max-age=3600');
    res.type(path.extname(name));
    res.sendFile(file);
  } catch { res.status(404).end(); }
});

app.post('/api/background', bgUpload.single('file'), (req, res) => {

  try {
    const id = sid(req), file = req.file; if (!file) throw new Error('اختر صورة خلفية.');
    const ext = path.extname(file.originalname || '').toLowerCase(); if (!['.jpg', '.jpeg', '.png', '.webp'].includes(ext)) throw new Error('صيغة الخلفية غير مدعومة.');
    const s = store.loadSession(id), dir = store.getPaths(id).backgrounds, name = `background${ext}`;
    for (const oldExt of ['.jpg','.jpeg','.png','.webp']) { const oldName = `background${oldExt}`; if (oldName !== name) { try { fs.rmSync(media.safePath(dir, oldName), { force: true }); } catch {} } }
    fs.renameSync(file.path, media.safePath(dir, name)); s.settings.backgroundImage = name; store.saveSession(s); res.json({ ok: true, message: 'تم رفع الخلفية وتطبيقها.' });
  } catch (e) { try { if (req.file) fs.rmSync(req.file.path, { force: true }); } catch {} replyError(res, e); }
});
app.get('/background/:filename', (req, res) => { try { const s = store.loadSession(sid(req)), name = decodeURIComponent(req.params.filename); if (s.settings.backgroundImage !== name) return res.status(404).end(); res.sendFile(media.safePath(store.getPaths(s.id).backgrounds, name)); } catch { res.status(404).end(); } });

whatsapp.on('status', (id, runtime) => {
  if (runtime?.ready) ownerAssistant.maybeSendWelcome(id).catch(error => log(id, 'WARN', `تعذر إرسال دليل محادثة النفس: ${safeError(error)}`));
});

whatsapp.on('message', async (id, msg) => {
 eventBus.publish('message.received', { sessionId: id, chatId: String(msg?.from || ''), messageId: String(msg?.id?._serialized || msg?.id || ''), fromMe: !!msg?.fromMe, type: String(msg?.type || 'chat'), timestamp: Number(msg?.timestamp || Date.now() / 1000) }).catch(() => {}); try { await automationEngine.handleMessage(id, msg); } catch (e) { log(id, 'ERROR', `محرك الأتمتة: ${safeError(e)}`); } const results = await Promise.allSettled([interaction.onMessage(id, msg), groupCommand(id, msg)]); results.filter(x => x.status === 'rejected').forEach(x => log(id, 'ERROR', safeError(x.reason))); });
whatsapp.on('message_create', async (id, msg) => {
  try {
    if (!msg?.fromMe || msg.__chatBotProgrammatic || msg._chatBotProgrammatic) return;
    if (typeof whatsapp.isProgrammaticOutgoing === 'function' && whatsapp.isProgrammaticOutgoing(id, msg)) return;
    if (typeof whatsapp.isSelfChatMessage !== 'function' || !await whatsapp.isSelfChatMessage(id, msg)) return;
    // Keep both conversational wizards and the original compact one-line command style.
    // An active owner wizard keeps priority, while an already-pending one-line command
    // takes priority so its confirmation cannot be interpreted as a different action.
    const current = store.loadSession(id);
    const bridgePending = Boolean(current.commandBridge?.pending);
    const ownerFlow = Boolean(current.ownerAssistant?.flow);
    if (bridgePending || !ownerFlow) {
      let commandResult;
      try { commandResult = await localCommandBridge.handle(id, msg?.body || msg?._data?.body || ''); }
      catch (error) {
        log(id, 'ERROR', `تعذر تنفيذ الأمر المباشر: ${safeError(error)}`);
        await ownerAssistant.reply(id, `لم أنفّذ الأمر بسبب خطأ: ${safeError(error)}\nتحقق من الاسم والحقول ثم أعد المحاولة. لم أغيّر بيانات الأمر قبل تأكيده.`);
        return;
      }
      if (commandResult?.handled) {
        await ownerAssistant.reply(id, commandResult.response);
        return;
      }
    }
    const result = await ownerAssistant.handleSelfChatMessage(id, msg);
    if (result?.handled && !result?.fallback) return;
    const input = Object.create(Object.getPrototypeOf(msg) || Object.prototype);
    Object.assign(input, msg);
    Object.defineProperty(input, 'fromMe', { configurable: true, enumerable: true, value: false });
    Object.defineProperty(input, '__chatBotSelfInput', { configurable: true, enumerable: true, value: true });
    await interaction.onMessage(id, input);
  } catch (error) { log(id, 'ERROR', `تعذر معالجة رسالة محادثة النفس: ${safeError(error)}`); }
});
whatsapp.on('reaction', (id, reaction) => interaction.onReaction(id, reaction).catch(e => log(id, 'ERROR', safeError(e))));

async function groupCommand(id, msg) {
  try {
    if (msg?.fromMe) return;
    const gid = groupFromMessage(msg); if (!gid) return;
    const s = store.loadSession(id);
    if (!s.settings.groupAssistantEnabled) return;
    const body = String(msg?.body || '').trim();
    const command = /^(?:!|\/)?(?:gid|group\s*id|groupid|group\s*info|group\s*analysis|معرف\s*(?:المجموعة|القروب)|تحليل\s*(?:المجموعة|القروب)|معلومات\s*(?:المجموعة|القروب)|معلومات\s*الجروب)(?=\s|$)/iu;
    const invite = body.match(/(?:https?:\/\/)?chat\.whatsapp\.com\/[A-Za-z0-9_-]+/i);
    const gidMention = body.match(/(?:^|[\s(])\d{5,25}(?:-\d+)*@g\.us(?=$|[\s)])/i);
    // Critical privacy/behavior rule from v8.6.0: a normal group message must not
    // discover or persist a group. Continue only for an explicit group command,
    // an invite link, or an explicit GID mention.
    if (!command.test(body) && !invite && !gidMention) return;
    let info = null;
    try { info = await whatsapp.getGroupInfoFromMessage(id, msg); } catch {}
    let target = invite ? invite[0] : gidMention ? gidMention[0] : body.replace(command, '').trim();
    if (!target) target = gid;
    if (groups.isGroupId(target)) info = await whatsapp.getGroupInfo(id, groups.normalizeGid(target));
    else if (invite) info = await whatsapp.analyzeGroupInvite(id, groups.extractInviteCode(target));
    else info = info || await whatsapp.getGroupInfo(id, gid);
    if (info?.gid) saveGroup(id, info);
    await whatsapp.replyToMessage(id, msg, `تحليل المجموعة\n${groups.formatGroupAnalysis(info)}`);
  } catch (e) {
    try { if (msg && !msg.fromMe) await whatsapp.replyToMessage(id, msg, `تعذر تحليل المجموعة: ${safeError(e)}`); } catch {}
  }
}

app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  const message = err?.code === 'LIMIT_FILE_SIZE' ? 'حجم الملف أكبر من الحد المسموح.' : err?.code === 'LIMIT_FILE_COUNT' ? 'عدد الملفات أكبر من الحد المسموح.' : safeError(err);
  res.status(Number(err?.status) || 400).json({ ok: false, error: message });
});
process.on('unhandledRejection', reason => log(null, 'ERROR', `Unhandled Promise Rejection: ${safeError(reason)}`));

async function shutdown(signal) {
  log(null, 'INFO', `إيقاف الخادم (${signal})…`);
  scheduler.stop();
  eventBus.close();
  await whatsapp.stopAll().catch(() => {});
  process.exit(0);
}
process.once('SIGINT', () => shutdown('SIGINT'));
process.once('SIGTERM', () => shutdown('SIGTERM'));

app.listen(PORT, HOST, () => { log(null, 'INFO', `لوحة التحكم تعمل على http://${HOST}:${PORT}`); setTimeout(() => { for (const id of store.listSessionIds()) { const s = store.loadSession(id); if (s.settings.autoStartSession && whatsapp.hasSavedAuth(id) && !whatsapp.listRuntime(id).ready) whatsapp.start(id).catch(err => log(id, 'WARN', `التشغيل التلقائي للجلسة لم يكتمل: ${safeError(err)}`)); } }, 500); });
